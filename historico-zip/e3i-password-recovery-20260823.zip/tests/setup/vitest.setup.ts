import '@testing-library/jest-dom';
import { vi, beforeEach } from 'vitest';

process.env.DATABASE_URL = process.env.DATABASE_URL || 'file:./dev.db';
process.env.GEMINI_MODEL_FAST = process.env.GEMINI_MODEL_FAST || 'gemini-2.5-flash';
process.env.GEMINI_MODEL_BALANCED = process.env.GEMINI_MODEL_BALANCED || 'gemini-2.5-flash';

beforeEach(() => {
  vi.clearAllMocks();
});
