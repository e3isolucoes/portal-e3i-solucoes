# Arquitetura Técnica - E3I Processos Inteligentes

Este artefato mapeia a arquitetura sistêmica, segurança de acessos, métodos quantitativos, e fluxo de dados do ecossistema empresarial **E3I Processos Inteligentes**.

---

## 🏗️ 1. Pilha de Tecnologia e Integrações

A solução é desenvolvida como uma plataforma web full-stack, projetada para suportar ambientes de alta concorrência operacional, análises probabilísticas pesadas e compliance internacional.

*   **Frontend**: React 19 executado sob o compilador Vite de alto desempenho, estilizado via classes utilitárias do Tailwind CSS.
*   **Controle de Estado**: React Hooks nativos integrados ao custom hook `useBusinessContext` para consistência atômica multidimensional.
*   **Análises Gráficas**: D3.js e Recharts para plotagem de limites estatísticos CEP, histogramas de dispersão, e capacidade de processo ($\sigma$).
*   **Bancos de Dados & Segurança**: Firestore Database com auditoria RBAC detalhada e segurança baseada em tokens autoritativos (`firestore.rules`).
*   **AI Co-Pilot**: Integração server-side segura utilizando a suite `@google/genai` (Gemini model family), eliminando vazamento de chaves secretas para o cliente web.

---

## 🧮 2. Computação Estocástica e Simulação

A E3I destaca-se por incorporar um mecanismo matemático nativo para análise quantitativa de cadeias de valor, modelando a variabilidade típica da vida real.

### A. Geração de Ruído de Variabilidade (Método Box-Muller)
Para simular o tempo real de processamento de cada item em um posto de trabalho, a plataforma converte números aleatórios de distribuição uniforme em desvios Gaussianos (normais):

$$Z_0 = \sqrt{-2 \ln U_1} \cos(2\pi U_2)$$

Onde $U_1, U_2$ são variáveis uniformes em $(0,1]$ e $Z_0$ é o ruído com média zero e variância unitária, escalado posteriormente para a média e desvio padrão definidos para o posto de trabalho.

### B. Cálculo de Capacidade e Fila (Modelagem Allen-Cunneen G/G/1)
A estimativa estatística de tempo de fila ($W_q$) é obtida através de aproximações estocásticas que consideram tempos de processamento e intervalos de chegada não exatos:

$$W_q \approx \left( \frac{C_a^2 + C_s^2}{2} \right) \left( \frac{\rho}{1 - \rho} \right) E(s)$$

Onde $C_a$ é o coeficiente de variação de chegada, $C_s$ o de atendimento, $\rho$ a utilização e $E(s)$ o tempo médio de ciclo. Isso previne crashes e divisões por zero na saturação de postos através de travas adaptativas que limitam $\rho \le 0.999$.

---

## 🔐 3. Segurança Flutuante e Trilha de Auditoria (RBAC)

O controle de conformidade robustecido da plataforma garante que cada nível hierárquico atue apenas em seu escopo de direitos delegados:

1.  **Matriz RBAC**: Uma chave multidimensional mapeia 9 tipos de credenciais (Administrador, Executivo, Gestor de Portfólio, Dono do Processo, Líder do Projeto, Analista, Colaborador, Auditor, Visualizador) aos direitos reais de rotas e ações.
2.  **Trilha de Auditoria Temporal**: Registro contínuo de alterações com identificador do usuário, descrição do evento e carimbo de tempo, blindado contra manipulações diretas de estado.
3.  **Mecanismo de Delegação**: Chaveamento temporário de papéis por ausências eletivas com validação estrita de intervalo de datas.
