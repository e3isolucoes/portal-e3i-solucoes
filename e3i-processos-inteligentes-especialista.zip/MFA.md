# Políticas de Autenticação Multifator (MFA) - E3I

Este documento define as diretrizes de autenticação em duas etapas para contas de privilégio elevado implementadas na **Fase 9**.

## Perfis com MFA Obrigatório

Para o funcionamento do portal multifuncional, contas que possuem acesso a painéis estratégicos ou manipulação de recursos confidenciais são submetidas a mandatos estritos de verificação secundária:

- **Administradores globais LSS** (acesso a segredos corporativos, configurações de SMTP e licenças);
- **Auditores Independentes** (acesso a dados de variabilidade e relatórios estatísticos);
- **Gestores com permissão de Exportação de Dados** (bloqueio à saída de relatórios e planilhas sem validação).

## Tecnologias e Mecanismos

1. **TOTP (Time-based One-time Password)**: O usuário utiliza aplicativos de autenticação (Google Authenticator, Microsoft Authenticator) para escanear um segredo e gerar tokens de 6 dígitos que expiram a cada 30 segundos.
2. **Códigos de Recuperação Únicos**: São criados códigos hexadecimais imutáveis de recuperação ("E3I-XXXX-XXXX") que o usuário deve exportar com segurança e usar caso perca o dispositivo principal. Cada código é descartado após a utilização.
3. **Mapeamento de Dispositivos Confiáveis**: Possibilidade de salvar o computador de uso rotineiro do funcionário para omitir checagem diária por no máximo 30 dias.

## Mitigação de Ataques de Força Bruta

O motor de segurança limita consecutivas falhas a fim de impedir ataques de adivinhação:
- Após **5 tentativas incorretas** consecutivas de códigos multifator, o perfil do usuário entra em Lockout de 3 minutos imediatos.
- Tentativas durante o período de Lockout registram incidentes na trilha geral de auditoria e reiniciam o contador de tempo restante.
