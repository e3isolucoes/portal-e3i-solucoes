# Protocolo de Assinatura Digital e Carimbo de Tempo (E3I)

Para processos críticos que definem capabilidade produtiva de chão de fábrica ou que afetam diretamente faturamento corporativo, a governança exige a aplicação de uma **Assinatura Digital Verificável baseada em Infraestrutura de Chaves Públicas (ICP)** e integração com **Autoridades de Carimbo de Tempo (TSA)**.

---

## 1. Arquitetura de Assinatura Digital no Cofre KMS / HSM

A submissão de um documento para aprovação final envolve o empacotamento criptográfico de sua integridade:

1. **Geração pela API / Backend**: O processo de coleta de assinaturas é executado em nível de backend isolado do cliente. As chaves privadas de aprovação ficam salvas em cofres virtuais dedicados (KMS) ou módulos de hardware físico criptográfico (HSM).
2. **Fórmula de Assinatura**: O hash do documento (`doc.hash`) é processado junto com a chave secreta vinculada do módulo HSM e as coordenadas do certificado emissor (`certId`):
   $$\text{Aprovador-Match} = \operatorname{SHA-256}(\text{doc.hash} \mathbin{\Vert} \text{"KMS-PRIVATE-KEY-SECRET-HSM-CHAIN-AUTH"} \mathbin{\Vert} \text{certId} \mathbin{\Vert} \text{signedAt})$$
3. **Cachê e Bloqueio**: Uma vez assinado, o documento tem seu status reclassificado de `Rascunho`/`Em Validação` para `Aprovado`. Qualquer modificação posterior rompe o vínculo matemático da assinatura.

---

## 2. Controle e Revogação de Certificados (CRL)

O sistema de auditoria possui integração nativa com o barômetro de controle de chaves corporativo (Certificate Revocation List).

```text
E3I HSM Trusted Certification Root
  ├── KMS-HSM-CERT-001 (Ativo: Marco Miranda, Master Black Belt)
  ├── KMS-HSM-CERT-012 (Ativo: Pedro Filho, Auditor Corporativo)
  └── KMS-HSM-CERT-REVOKED (REVOGADO/CANCELADO: Ex-Colaborador)
```

### Regras de Auditoria de Chave Emissora:
* Se um colaborador que possui poder de assinatura for desligado, seu código de certificado (`certificateId`) é instantaneamente inserido na Lista de Revogação de Certificados (CRL).
* Qualquer averiguação no **Portal de Verificação de Autenticidade** para documentos assinados anteriormente com aquela credencial apontará falha crítica: `FALHA: O certificado digital responsável pela assinatura foi revogado/cancelado na cadeia de custódia`.

---

## 3. Integração com Autoridade de Carimbo de Tempo (TSA)

Para evidências que exigem comprovação técnica perante órgãos ambientais, fiscais ou tribunais cíveis, a autenticidade conta com uma integração estrita a uma Autoridade Fiduciária de Carimbo de Tempo (TSA - Timestamping Authority) qualificada sob a **ICP-Brasil** (como Cora TSA):

O carimbo cronológico anexa ao documento um metadado unívoco atestando e assinando a existência temporal firme do arquivo:

```typescript
type TimestampRecord = {
  certifiedAt: string;        // Data/Hora com precisão garantida por GPS fiduciário e relógio atômico
  authority: string;          // Nome exato da autoridade emissora (ex: Cora TSA / ICP-Brasil)
  token: string;              // Token SHA-256 combinando data fiduciária e metadados
  policy: string;             // Política aplicada (ex: AD-RB_PROV_TS_N1)
  validationResult: "VALID";  // Resultado da validação
};
```

Qualquer distorção entre a hora de assinatura local e a hora carimbada fisicamente pela autoridade temporal gera alertas preventivos de "backdating" e cancela o selo de conformidade da melhoria DMAIC.
