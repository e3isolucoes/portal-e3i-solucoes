# Diagnóstico Técnico e Tecnológico - E3I Processos Inteligentes

**Versão:** 1.0  
**Autor:** Especialista em Arquitetura de Software & UX  
**Status:** Concluído (Fase 1 - Descobrimento e Análise)

Este documento apresenta a análise profunda da arquitetura atual da ferramenta **E3I Processos Inteligentes**, identificando a pilha de tecnologias instaladas, estrutura de diretórios, regras de negócio em vigor, mecânicas de persistência e simulação, além do mapa de logs e vulnerabilidades operacionais.

---

## 1. Estruturação de Pastas (Folder Structuring)

A organização do código está bem estruturada e segue os padrões modernos de aplicações web modularizadas em React, utilizando arquitetura orientada a serviços e separação clara de responsabilidades.

```text
/
├── .env.example                     # Declaração padronizada de variáveis de ambiente
├── firestore.rules                  # Regras de segurança e controle de acesso do FireStore
├── firebase-applet-config.json       # Configurações de conexão para o Firebase client
├── firebase-blueprint.json          # Blueprint de validação de dados da plataforma
├── metadata.json                    # Atributos de metadados externos do applet
├── package.json                     # Manifesto do projeto e dependênciasnpm
├── server.ts                        # Servidor Express.js (Vite Dev Middleware e API Gemini)
├── vite.config.ts                   # Ajustes do bundler Vite
├── src/
│   ├── App.tsx                      # Componente central, estado global e roteamento
│   ├── firebase.ts                  # Inicialização do módulo client do Firebase
│   ├── main.tsx                     # Ponto de entrada do DOM do React
│   ├── presets.ts                   # Presets estáticos das indústrias e templates padrão
│   ├── types.ts                     # Definições estritas de tipos e interfaces do domínio LSS
│   ├── utils.ts                     # Biblioteca principal de cálculos de Filas e Monte Carlo
│   ├── index.css                    # Ponto de entrada de estilo com Tailwind CSS
│   ├── components/                  # Coleção com os 35 componentes visuais e modulares
│   ├── repositories/                # Camada de comunicação com bancos de dados
│   │   ├── UserRepository.ts        # Subsistema de perfis de usuários e sincronização
│   │   └── CompanyProjectRepository.ts # Subsistema de empresas, projetos e dados LSS
│   ├── services/                     # Serviços de Integração de Terceiros e Backend
│   │   ├── AiService.ts             # Cliente de comunicação com endpoints de Inteligência Artificial
│   │   ├── firebaseAdmin.ts         # Wrapper para conexões seguras sob tokens e credenciais
│   │   └── firebaseConfig.ts        # Configurações adicionais
│   └── utils/
│       └── areaPresets.ts           # Definição e pré-configurações de áreas corporativas
```

---

## 2. Pilha de Tecnologia (Tech Stack)

A plataforma E3I Processos Inteligentes adota as seguintes tecnologias para garantir desempenho de alto nível, segurança integrada e escalabilidade imediata:

### Frontend (User Interface)
*   **React 18 & Vite:** Garante compilação ultra veloz do frontend, processamento baseado em reconciliação do DOM eficiente e carregamento sob demanda através de carregamento assíncrono programático (`Suspense` e `lazy`).
*   **TypeScript 5.x:** Tipagem sólida por todo o sistema (modelos como `ProcessStep`, `ControlPlan` e `ProjectCharter`), mitigando erros clássicos do runtime de JavaScript e estabelecendo contratos rígidos.
*   **Tailwind CSS v4:** Aplicação nativa de estilos baseados em classes utilitárias de alta velocidade de desenho e fácil manutenção.
*   **Recharts:** Renderização fluida, baseada em SVG e responsiva de gráficos de Controle Estatístico de Processo (CEP), histogramas de Monte Carlo e dispersão de tempos de cycle.
*   **Lucide React:** Coleção integrada de alta legibilidade gráfica para consistência dos botões e painéis administrativos corporativos.

### Backend (Process Server)
*   **Node.js & Express:** Servidor back-end robusto, responsável por expor rotas estruturadas de segurança, manipulação das requisições pesadas de IA, formatação de relatórios avançados e controle de acessos não-autenticados.
*   **Firebase Client & Admin SDKs:** Autenticação unificada de usuários, persistência dinâmica em tempo real no cloud banco Firestore e aplicação de logs para conformidade de auditorias.
*   **@google/genai SDK (Gemini):** Mecanismo de Inteligência Artificial no lado do servidor utilizando o modelo **Gemini 3.5 Flash** para as análises avançadas de DMAIC e modelagem estocástica através de engenharia de prompts estruturada de retorno em formato JSON.

---

## 3. Fluxos de Autenticação, Perfis de Usuário e Permissões (RBAC)

A segurança operacional da plataforma baseia-se em políticas estritas de autenticação, controle de acessos baseados em papéis (**RBAC**) e validação server-side.

```text
Logon do Usuário (AuthCover) -> Validação Firebase Client -> Carregamento de Documento de Perfil (/users/{uid})
                                                                ├─> Se perfil não existe (Novo Usuário) -> Criação Automática
                                                                └─> Carregamento das Configurações de Workspace (WorkspaceData)
```

### Perfis de Acesso e Metodologia Científica
O perfil do usuário é gerenciado pelo `UserRepository` e complementado por atributos LSS:
*   **Cargos Suportados:** Engenheiro de Processo, Consultor Lean Six Sigma, Administrador de Sistemas, Coordenador de Célula, entre outros.
*   **Metodologias (Módulos Base):** O projeto prevê travas que limitam recursos dependendo do plano ou cargo (configurado em tempo de execução pelo administrador de conta via `AdminPanel.tsx` habilitando módulos empresariais específicos para cada filial da empresa).
*   **Belts (Certificações Lean Six Sigma):** 
    *   **Yellow Belt:** Acesso básico a mapeamentos e quadros Kanban simples.
    *   **Green Belt:** Permissão para análise de causa raiz, planos de controle locais e sugestões Kaizen básicas.
    *   **Black Belt / Master Black Belt:** Liberação total de ferramentas de simulação estocástica (Monte Carlo), modelagem avançada de Pesquisa Operacional (OR) e controle total de segurança e configuração de filiais/empresas.

### Regras de Segurança Unificadas (`firestore.rules`)
As proteções de segurança física e relacional no nível de banco de dados são garantidas por regras estritas:
1.  **Isolamento Absoluto do Inquilino (SaaS Tenant Isolation):** Empresas e seus sub-projetos são guardados com chaves `ownerId == request.auth.uid`. Usuários não autorizados de outros escopos não conseguem listar ou ler documentos.
2.  **Append-Only Seguros (`access_logs`):** Logs de sistema criados durante conexões, alteração de parâmetros críticos ou acessos a portais são gravados em modo apenas inserção (não modificáveis, não deletáveis, não consultáveis a partir do cliente).
3.  **Controle Estrito de Validação de Input:** Funções internas do Firestore barram a inserção de strings enormes (como Buffer overflow attacks), verificam o formato léxico do campo (Regex de IDs de sistema) e validam campos obrigatórios de enums preestabelecidos.

---

## 4. Estrutura de Persistência e Replicação (SaaS Cloud Sync)

A persistência do estado da aplicação opera sob um modelo híbrido tolerante a falhas que combina o controle de estado nativo do React com sincronização assíncrona em nuvem:

```text
[Operação Visual UI] 
       │
       ▼ (Ajuste das propriedades do Twin)
[Estado React Local (useState)] ───► Componentes Visuais Reativos (Vite Renders)
       │
       ▼ (Alterações no Workspace)
[Caches Estáticos e Notificadores do CompanyProjectRepository]
       │
       ├── Se "Sandbox / Modo Treinamento" Ativo ──► Apenas salva em Memória Local
       │
       └── Se Conectado em Nuvem Clássica ──► Firestore Realtime Cloud Pushes
                                                ├─► update doc `users`
                                                ├─► set doc `companies`
                                                └─► set doc `projects` (dados LSS aninhados)
```

1.  **Padrão Repository (DDD / DAO):** Todo acesso ao Firestore é abstraído em métodos estáticos das classes `UserRepository` e `CompanyProjectRepository`. O frontend nunca escreve diretamente no banco do Firebase.
2.  **Mecanismo de Escuta Reativa (Realtime Subscriptions):** O repositório monitora alterações nas coleções a partir do Firestore via `onSnapshot`. Modificações feitas em múltiplos terminais são refletidas nos painéis visualizados instantaneamente.
3.  **Modo Sandbox de Treinamento (Offline Sandbox):** Quando a flag `lss_training_mode` no LocalStorage está ativa, todo o fluxo de atualização em nuvem é interceptado e cancelado. A ferramenta funciona como um playground científico sem gravar dados ruidosos no ambiente produtivo Firestore de clientes corporativos.

---

## 5. Simulações, Modelos de Decisão e Relatórios Matemáticos

E3I apoia as decisões empresariais em algoritmos clássicos de Pesquisa Operacional (Operations Research) e Estatística Industrial Six Sigma:

```text
Passagem dos Steps ──► Teoria das Filas (G/G/c de Allen-Cunneen) ──► Tempo de Fila Médio, WIP Local e Saturações (Capacity)
       │
       ▼ (Simulação de 20 Ciclos Estocásticos diários)
Modelagem de Monte Carlo ──► Box-Muller (Transformada de Var) ──► Histogramas de Probabilidades, Nível Sigma Real e DPMO
```

### Motor de Análises de Filas e Produção (`utils.ts`)
*   **Modelo de Servidores G/G/c (Allen-Cunneen):** Calcula os atrasos locais de fila em setups com múltiplos atendentes/computadores paralelos de forma dinâmica usando o coeficiente de variação acumulado da etapa anterior, permitindo modelar variabilidades reais e gargalos que simulações estáticas padrão de Excel falham em estimar.
*   **Lei de Little:** Estima a quantidade média de unidades paradas em processamento intermediário (WIP) multiplicando o tempo médio total de permanência no sistema (lead time) pela taxa de chegada efetiva de demanda externa.

### Simulador de Monte Carlo e Geração de Telemetrias
*   **Algoritmo de Box-Muller:** Transforma números pseudo-aleatórios uniformes em pontos seguindo a Curva de Distribuição Normal Gaussiana com base nas propriedades de média de ciclo e desvio padrão de cada máquina configurada, mitigando outliers negativos.
*   **Telemetrias Estocásticas:** A simulação roda instantaneamente 20 ciclos corporativos gerando relatórios de medições diárias capazes de alimentar o subportal "Controle Estatístico de Processo (CEP)" com dados operacionais realistas, sem exigir integrações iniciais complexas com ERPs dos parceiros empresariais.

### Relatório Preditivo Sigma e Cálculo de DPMO
*   **Função Probit (Wichura's Approximation):** Emprega aproximações polinomiais de frações decimais em tempo contínuo para mapear a taxa compounding de primeiras passagens de qualidade (yield generalizado de ponta a ponta) para o index de desvio de Nível Sigma corporativo, aplicando o desvio de correção padrão industrial de **+1.5σ shift**.

---

## 6. Principais Débitos Técnicos e Vulnerabilidades de Produto

Apesar de robusta e repleta de recursos matemáticos, a fase de análise profunda revelou fragilidades estruturais e de UX que devem ser sanadas nas próximas etapas:

1.  **Monolito de Estado em `App.tsx` (Alta Complexidade Cíclica):**
    O arquivo `App.tsx` acumulou mais de 8.400 linhas de código, acumulando variáveis de estado para mais de 15 módulos visuais, lógicas de interface do robô, roteadores improvisados de tabs, manipuladores de cliques de botões e presets de visualizadores gráficos. Isto eleva o risco de regressões e dificulta manutenções.
2.  **Inexistência de Estados Vazios (Empty States) Confortáveis:**
    Caso o usuário selecione um sub-projeto em andamento zerado, o sistema tenta renderizar gráficos, limites matemáticos de Controle Estatístico e estimativas de DPMO sobre arrays vazios de etapas. O resultado atual oscila entre valores estáticos bizarros (como DPMO: 0 e Nível Sigma: 1.0σ), erros silenciosos no console ou botões de simulação e melhoria por IA que disparam alertas.
3.  **Gerenciamento Manual do Estado no LocalStorage:**
    Configurações como planos liberados, visualizações de telas e status corporativos são resgatados por strings diretas do LocalStorage durante o carregamento, gerando o risco de Dessincronização de Estado caso o cargo do usuário mude de administrador para consultor basico em outro aba do navegador.
4.  **Fragilidade ao Operar sem Conexão (Null-Safety de Firestore):**
    Quando ocorrem timeouts ou intermitências com a rede externa, o carregamento do Firestore silenciosamente nega ou atrasa o retorno de snapshots, mantendo spinners estáticos rodando na área central de análise sem dar um diagnóstico ou permitir trabalho local no modo Sandbox preventivo de forma explícita.
