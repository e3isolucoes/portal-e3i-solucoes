# Análise de Riscos de UX, Acessibilidade e Gaps de Produto

**Versão:** 1.0  
**Autor:** Especialista em UX/UI & Product Designer  
**Status:** Concluído (Fase 1 - Descobrimento e Análise)

Este documento descreve as fragilidades de Experiência do Usuário (UX/UI), acessibilidade e comportamento de layout encontradas na plataforma **E3I Processos Inteligentes**, definindo as dores de produto que requerem foco nas fases futuras.

---

## 1. Ausência de Tratamento e Design para Estados Vazios (Empty States)

```text
[Seleção de Projeto Vazio] ──► Renderiza Canvas/Tabela sem Etapas ──► Sem Ilustração de Ajuda
                                                                       ├─► Gráficos exibem eixos de valor zerados (Escalas Incompreensíveis)
                                                                       ├─► Alertas de erro silenciosos de NaN no motor estatístico
                                                                       └─► Botão de "Simulação" e "Análise de IA" em destaque continuam ativos
```

*   **Impacto no Usuário:** Quando um consultor cria um projeto do zero, ele pousa em uma viewport cinza desértica repleta de cartões, botões e gráficos de CEP vazios. Isso causa forte ansiedade de uso ("efeito folha em branco"), pois não há ilustrações explicativas, guias preventivos ou avisos de que ele primeiro precisa adicionar postos de trabalho no menu lateral para que os limites UCL/LCL comecem a calcular.
*   **Decorações de IA Ativas:** Os botões para "Sugerir Estrutura com IA" continuam acendendo com sparkles coloridos mesmo em fluxos já maduros, o que pode induzir o usuário a sobrescrever acidentalmente suas calibrações de campo reais por estruturas propostas de forma descuidada.

---

## 2. Inconsistência de Fluxo sem Empresa ou Projeto Selecionado

*   **O Comportamento Desejado:** Um usuário novinho em folha, recém-autenticado, deve ser compelido e guiado a preencher o setup inicial da sua empresa e projeto.
*   **O Risco de UX:** Atualmente, se um usuário burla os gatilhos visuais usando caches passados do LocalStorage ou cliques rápidos nos menus laterais, a ferramenta abre as abas de engenharia (como DMAIC ou KANBAN) sem uma Empresa Ativa definida de verdade. O resultado são cartões de dados LSS que recarregam indefinidamente ou relatórios de ROI que quebram, pois as funções internas tentam varrer e-mails e metadados de sub-coleções inexistentes.

---

## 3. Desafios de Acessibilidade (WCAG Compliance Gaps)

A plataforma E3I, voltada ao ambiente B2B corporativo, carece de controles de acessibilidade adequados, o que viola diretrizes internacionais (*WCAG 2.1*):
*   **Baixo Contraste Cromático de Elementos de Destaque:**
    Alguns badges e botões informativos usam textos laranjas finos sob fundos cinzas ou rótulos amarelos dourados sob cartões brancos que não alcançam a barreira mínima de contraste de cores de **4.5:1** para fontes normais.
*   **Falta de Suporte a Leitores de Tela (ARIA Attributes):**
    As formas geométricas do canvas SVG corporativo (`VisualProcessMapper`) que moldam o fluxo de valor são renderizadas sem atributos ARIA adequados (`aria-label` ou descrições alternativas). Usuários com deficiência visual completa que dependem de navegadores assistivos escutarão apenas listas de vetores de caminhos de conexão incompreensíveis sem receberem informação inteligível sobre o fluxo logístico modelado.
*   **Operabilidade Pura por Teclado Bloqueada:**
    Não é possível caminhar pelas etapas ou acionar os modais de controle de setup de máquinas utilizando apenas as teclas `Tab` e `Enter` do teclado. O usuário é obrigado a recorrer ao mouse para manipular os limites do aplicativo.

---

## 4. Quebras e Gargalos de Responsividade (Mobile Viewport Gaps)

A aplicação tenta comprimir tabelas estatísticas corporativas densas em displays reduzidos sem as táticas necessárias de scroll adaptativo:
*   **Saturação do Kanban de WIP no Mobile:**
    O quadro visual de WIP expande horizontalmente com colunas fixas por posto. Em telas menores de celulares, o usuário sofre clipping lateral, onde as colunas se fundem ou exigem toques bruscos desajeitados para rolagem horizontal, ocultando cards cruciais na beirada.
*   **Tabelas de Limites de Controle Incompreensíveis:**
    A listagem com os desvios, frequências de amostragem e planos de reação CEP quebra suas colunas em smartphones, sobrepondo os limites decimais de UCL e LCL sobre as descrições de providência técnica.
*   **Ocultamento de Botões de Navegação Claves:**
    Como a barra lateral de abas é fixa verticalmente na esquerda da tela desktop, em larguras menores ela é ocultada repentinamente por gavetas pretas sem prover um menu hambúrguer amigável de fácil acesso com o polegar.

---

## 5. Inconsistência Linguística e Estética de Layout (Visual System Noise)

*   **Variação Exagerada de Padding e Densidade:**
    Algumas visualizações apresentam bento-grids com margens internas e externas de 32px (generosas e vazias), enquanto outras seções espremem dezenas de tabelas e botões em vãos de 8px sem um alinhamento lógico claro. Isso interfere na harmonia visual e quebra o ritmo do produto.
*   **Mistura Linguística nos Relatórios Automatizados:**
    Algumas colunas de relatórios utilizam nomenclaturas acadêmicas em inglês (ex: *WIP*, *Cycle Time*, *Yield Rate*) que entram em atrito com termos corporativos tradicionais traduzidos em português em abas vizinhas (ex: *Estoque em Processo*, *Rendimento da Etapa*). O sistema precisa unificar seu glossário empresarial técnico detalhado para evitar perturbar consultores seniores.
