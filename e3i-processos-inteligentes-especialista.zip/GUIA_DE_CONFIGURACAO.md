# ⚙️ Guia de Configuração — E3I Processos Inteligentes

Este documento detalha todas as políticas de configuração, variáveis de ambiente configuráveis e parametrização do ecossistema E3I para manter uma operação estável e alinhada às melhores práticas de segurança corporativa.

---

## 🔑 Variáveis de Ambiente (`.env`)

A plataforma centraliza suas definições em um arquivo `.env` localizado na raiz do projeto. Nenhuma chave secreta ou credencial de produção deve ser embutida diretamente no código.

Abaixo está o descritivo de cada variável exigida:

```env
# ==========================================
# 1. CORE AI INTEGRATION (GEMINI API)
# ==========================================
# Chave secreta de acesso para o motor cognitivo Gemini (Google GenAI SDK)
# Nunca adicione o prefixo VITE_ aqui para impedir vazamento no client-side.
GEMINI_API_KEY=sua_chave_secreta_gemini_aqui

# ==========================================
# 2. FIREBASE CLOUDPERSISTENCE CONFIG
# ==========================================
# Credenciais corporativas para isolamento e salvamento de dados via Firestore
# Estas variáveis podem ser expostas com segurança via injeção eletrônica.
# Elas são carregadas em tempo de build a partir do firebase-applet-config.json
VITE_FIREBASE_API_KEY=sua_apiKey_firebase
VITE_FIREBASE_AUTH_DOMAIN=seu_auth_domain
VITE_FIREBASE_PROJECT_ID=seu_project_id
VITE_FIREBASE_STORAGE_BUCKET=seu_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=seu_sender_id
VITE_FIREBASE_APP_ID=seu_app_id
```

---

## 🏢 Parametrização Multi-Tenant & Isolação

A plataforma impede o compartilhamento cruzado ou injeção de dados de terceiros por meio de uma arquitetura de metadados rígida no Firestore:

1. **Documento do Usuário (`/users/{uid}`)**: Carrega o perfil corporativo, Belt correspondente e referências de licenciamento.
2. **Documento da Empresa (`/companies/{companyId}`)**: Toda transação de criação de projetos valida se o `ownerId` do criador é estritamente equivalente ao `uid` autenticado no Firebase Authentication.
3. **Coleção de Evidências Técnicas**: Qualquer arquivo ou metadado anexado nas fases possui chave composta contendo `companyId` e `projectId`.

---

## 🔒 Parâmetros de Segurança do Upload de Arquivos

Para customizar as restrições logísticas de rede para evidências técnicas, consulte `/src/utils/uploadValidator.ts`:

* **Tamanho Máximo Consumido**: `15 * 1024 * 1024` (15 Megabytes).
* **Formatos de Extensões de Arquivos Homologadas**: `['.pdf', '.png', '.jpg', '.jpeg', '.xlsx', '.docx', '.zip', '.csv']`.
* **Tipos de MIME Homologados**: Bloqueia executáveis (`.exe`, `.sh`, `.bat`) de forma imperativa para conter ameaças cibernéticas.

---

*Nota: Em ambientes de treinamento intensivo ou sandbox temporária, a plataforma pode ser executada em **Training Mode (lss_training_mode: true)**. Nesse cenário, todas as chamadas de banco de dados são emuladas localmente no state interno do navegador, suspendendo requisições à nuvem para poupar requisições e proteger rascunhos em progresso.*
