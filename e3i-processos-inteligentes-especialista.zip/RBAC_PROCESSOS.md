# 🛡️ Especificação Técnica de RBAC — E3I Processos

Este documento detalha o mapeamento funcional de permissões e as melhores práticas implementadas para a segurança reativa e governança no módulo de **Processos Inteligentes E3I**.

---

## 1. Abordagem de Permissões Granulares

Anteriormente, o sistema realizava avaliações de privilégios de forma insegura utilizando comparações de string diretas contra o cargo selecionado (ex: `currentCargo === "Admin"`). 

Na Fase 15.1, essa abordagem foi substituída por um motor de **Controle de Acesso Baseado em Função (RBAC)** estritamente tipado, que converte a identidade do usuário em permissões explícitas.

### Tipagem Granular de Permissões
As seguintes ações granulares (`Permission`) governam o ciclo de vida do mapeamento e simulação de processos:

- `process:view`: Permite ler os dashboards de visualização simples ("Modo Simplificado").
- `process:advanced-analysis`: Permite ler dados microscópicos, estatísticas avançadas, saturação de filas, DPMO reais e alternar para o "Modo Especialista".
- `process:create`: Permite adicionar novos postos de trabalho ou etapas na cadeia de valor.
- `process:edit`: Permite alterar taxas de serviço, tempos de ciclo unitários, gargalos, capacidades locais e POPs de rotina.
- `process:delete`: Permite deletar postos de trabalho e redefinir o gêmeo digital.
- `process:export`: Permite extrair mapas e KPIs quantitativos para auditorias de terceiros ou relatórios de faturamento.
- `process:approve`: Permite homologar alterações em Project Charters reais.
- `process:manage-settings`: Permite a administradores travar a tela no modo simplificado para visualização do cliente ou ativá-lo para desenvolvedores.
- `process:use-ai`: Permite invocar as mutações sugeridas pelo motor cognitivo do E3I Assistant.

---

## 2. Matriz de Mapeamento de Funções (Roles)

Cada perfil foi mapeado de acordo com seu papel de negócios no Lean Six Sigma corporativo, garantindo o princípio do menor privilégio (POLP):

| Função (Role) | Perfil Compatível | Permissões Mapeadas |
|---|---|---|
| **Administrador** | Administrador | Todas as permissões liberadas (`process:*`) |
| **Executivo** | Executivo | `process:view`, `process:export`, `process:approve` |
| **Gestor de Portfólio** | Gestor de Portfólio | `process:view`, `process:advanced-analysis`, `process:export` |
| **Dono do Processo** | Dono do Processo | `process:view`, `process:advanced-analysis`, `process:edit`, `process:export` |
| **Líder do Projeto** | Líder do Projeto | `process:view`, `process:advanced-analysis`, `process:create`, `process:edit`, `process:export` |
| **Analista** | Analista / Black Belt | `process:view`, `process:advanced-analysis`, `process:create`, `process:edit`, `process:delete`, `process:use-ai`, `process:export` |
| **Colaborador** | Colaborador / Júnior | `process:view` *(Apenas visualização comum)* |
| **Auditor** | Auditor | `process:view`, `process:advanced-analysis`, `process:export`, `process:approve` |
| **Visualizador** | Visualizador / Cliente | `process:view` |

---

## 3. Segurança Contra Modificação Livre de Perfil

O simulador de função e seletor de "Perfil de Função" (`persona-role-selector`) foi robustecido com as seguintes travas de engenharia:
1. **Verificação de Identidade Concreta**: O dropdown de alteração de simulação é desabilitado por padrão (`disabled={!canSimulateRoles}`) para usuários finais que não sejam Administradores ou Black Belts verificados.
2. **Trilha de Auditoria Automática**: Toda alteração de simulação realizada por auditores e engenheiros autorizados dispara um evento central persistido em banco contendo dados de IP, usuário ativo, e detalhamento de transição.
3. **Erros Tratados Amigavelmente**: Tentativas de burlar as travas por depuração no console retornam alertas impeditivos detalhando conformidade com as regras de menor privilégio.
