# Análise de Riscos Técnicos e Fragilidades Estruturais

**Versão:** 1.0  
**Autor:** Principal Security & Systems Architect  
**Status:** Concluído (Fase 1 - Descobrimento e Análise)

Este documento descreve os riscos técnicos identificados na arquitetura atual da ferramenta **E3I Processos Inteligentes**, classificando as fragilidades quanto à performance, concorrência, limitações de iframe e casos de borda matemáticos.

---

## 1. Gargalos de Desempenho e Gargalos de Renderização (Performance)

*   **Renderizações em Avalanche (App.tsx Monolithic State):**
    Uma vez que o arquivo raiz `App.tsx` possui o controle de dezenas de estados flutuantes (Active Company, Active Project, Steps, Charter, Copilot History, UI View Mode, etc.), qualquer caractere digitado em um painel isolado (Ex: alterando a descrição do SIPOC) aciona a execução de re-render do arquivo `App.tsx` por inteiro. Isso obriga a árvore virtual do React a recalcular dinamicamente todos os charts, limites estatísticos do CEP e posições de bento-grids, gerando atrasos em computadores de menor rendimento ou navegadores móveis mais antigos.
*   **Volatilidade em Gráficos Dinâmicos Recharts:**
    Os gráficos interativos de CEP e Monte Carlo renderizam dezenas de nós no SVG. Em processos com grande quantidade de etapas (Ex: mais de 10 passos) rodando a simulação dinamicamente no mesmo frame, a taxa de quadros por segundo (FPS) cai consideravelmente durante redimensionamentos de tela devido ao redesenho de vetores em loop na tela.

---

## 2. Concorrência e Sincronização de Estado (Concurrency & Race Conditions)

*   **Corrida entre Sincronizações Remotas e Locais (onSnapshot Race Conditions):**
    A classe `CompanyProjectRepository` expõe assinaturas em tempo real do banco Firestore via `onSnapshot` e as repassa de volta ao aplicativo. No entanto, o fluxo de salvamento de dados operacionais `saveProjectDataStore` dispara chamadas assíncronas assíncronas `setDoc` de escrita em nuvem. Se houver intermitência leve de rede, um evento de snapshot com dados antigos pode ser recebido do Firestore imediatamente após uma edição local, sobrescrevendo alterações que o operador acabou de digitar na tela.
*   **Gerenciamento Manual de Identificadores Órfãos (State Desynchronization):**
    Ao excluir uma Empresa ou Projeto, se outro terminal de usuário estiver conectado na mesma conta com este projeto selecionado como ativo, o console registrará uma cascata de falhas de leitura ou nulos, pois a chave residual de projeto ativo (`activeProjectId`) apontará para um ID inexistente no Firestore. O sistema requer proteções automáticas de limpeza de ponteiros órfãos em cascata.

---

## 3. Restrições do Ambiente Sandboxed Iframe (Platform Sandbox Limits)

Uma vez que a aplicação roda de forma hospedada dentro de um iframe seguro (Sandbox Iframe) no console de parceiros ou canais integrados de B2B, surgem impactos sérios:
*   **Bloqueios de Popups e Redirecionamentos de Login:**
    Navegadores como Chrome e Safari bloqueiam tentativas de abertura de modais de login baseados em popup (`signInWithPopup` do Firebase Auth) de dentro de iframes externos sem políticas explícitas de escopo. O fluxo atual utiliza métodos de login baseados em formulário interno (`signInWithEmailAndPassword`) justamente para mitigar essa vulnerabilidade.
*   **Bloqueios de Cookies de Terceiros (Third-Party Cookies Blocking):**
    O login do Firebase Client armazena cookies seguros do domínio do Google de autenticação. Se o navegador do cliente final barrar de forma estrita cookies de terceiros (padrão de proteção avançada no Safari e Firefox), a sincronização do token cai intermitentemente, forçando o logoff inesperadamente.

---

## 4. Casos de Borda Não Tratados e Falhas de Domínio Matemático

*   **Divisão por Zero na Saturação de Postos de Trabalho (Arriving Surcharge):**
    A equação de cálculo de tempos acumulados de filas em redes de Allen-Cunneen baseia-se na fração de ocupação (`rho = arrivalRate / capacityPerHour`). Se o operador reduzir a quantidade de funcionários de uma etapa para ` resourceCount = 0 ` ou elevar a taxa de chegada acima do limite de vazão técnica, a variável `rho` alcança ou ultrapassa ` 1.0 `. Nesse cenário limítrofe, as equações de queue dividem por zeros ou retornam infinitos, o que causa NaN (Not a Number) em gráficos locais de CEP e quebra as somas cumulativas de WIP nas tabelas.
*   **Estouro de Limite de Cota da API Gemini (Rate-Limit Crashes):**
    O backend Express em `server.ts` se comunica diretamente com o endpoint Gemini 3.5 Flash sem um mecanismo inteligente de cache semântico intermediário. Se múltiplos usuários decidirem rodar análises de IA em múltiplos processos simultaneamente, os limites de chamadas por minuto (RPM) da chave Gemini serão excedidos, retornando erros crus de status "429 Too Many Requests" diretamente na viewport dos consultores.
*   **Comportamento Sem Rede (Offline Fallback Resilience):**
    O banco de dados Firestore está configurado sem política explícita de persistência offline habilitada (`enableIndexedDbPersistence`). Caso o cliente sofra flutuação rápida na conexão em visitas a chão de fábrica, a interface congela em spinners insolúveis em vez de transitar de forma amigável para o modo Sandbox persistido localmente.
