# Decisões Arquiteturais (ADRs) - E3I Processos Inteligentes

Este documento registra as decisões de arquitetura de software feitas durante o ciclo de consolidação técnica da Fase 7 e seus motivadores.

---

## 🏛️ ADR 01: Centralização de Configurações e Inicializadores Estáticos

### Contexto
O componente raiz `/src/App.tsx` continha mais de 500 linhas de dados estáticos complexos estruturando presets industriais de soldagem SMT, dicionários multissetoriais de tradução corporativa e presets padrão DMAIC. Isso inchava o arquivo, reduzia a velocidade de leitura para manutenção, piorava o tempo de build e consumia janelas desnecessárias de tokens no IDE.

### Decisão
Movemos todas as configurações estáticas, presets e funções geradoras puras (como `generateDefaultDeliverables`) para o arquivo dedicado `/src/shared/utils/initialStates.ts`.

### Consequências
- **Positivas**: Tamanho físico de `/src/App.tsx` reduzido em mais de 500 linhas de código. Reutilização simples dessas estruturas por outros módulos analíticos.
- **Neutras**: Para manter total retrocompatibilidade e evitar quebras de integração, o `/src/App.tsx` re-exporta as constantes, garantindo que components importem sem sofrer impactos de re-pathing.

---

## 🏛️ ADR 02: Roteamento Baseado em Code Splitting e Lazy Loading Estratégico

### Contexto
O sistema possui mais de 35 visualizações interativas complexas (incluindo renderização de simulações Monte Carlo, gráficos de dispersão, mineradores de processos por eventos, painéis FMEA, etc.). Carregar todos esses módulos instantaneamente causava latência de carregamento inicial.

### Decisão
Substituímos todas as cargas estáticas de componentes de alta inteligência e grandes bibliotecas (como painéis integrados, guias onboarding, painéis de cálculo de ROI e diagramadores BPMN) por importações assíncronas do React (`lazy(() => import(...))`) encapsuladas em barreiras de `<Suspense />` reativas.

### Consequências
- **Positivas**: Tempo de carregamento do cluster de bundles principais reduzido. Navegação inicial instantânea e renderização fluida ao alternar abas analíticas.
- **Neutras**: Exibe esporadicamente o componente elegante de transição dinâmica (`<LoadingFallback />`) quando uma rota pesada é solicitada pela primeira vez na sessão do usuário.

---

## 🏛️ ADR 03: Provedor Consensual de Contexto e Switches de Domínio Seguros

### Contexto
Cada aba operava com caches e estados duplicados e difusos de empresas ativas, projetos e processos. Quando o usuário trocava de empresa e abria os painéis, as rotas quebravam ou retinham referências a projetos órfãos da empresa antiga.

### Decisão
Arquitetamos um contexto reativo centralizado (`BusinessContext`) e criamos rotinas específicas de limpeza em cascata ao comutar opções:
1. **Trocar Empresa**: Reseta unidade de negócio, processo atual e projeto atual selecionado, evitando vazamento de dados de clientes anteriores.
2. **Trocar Projeto**: Limpa o repositório de processos e reseta a tabela de controle CEP, preenchendo automaticamente com os entregáveis DMAIC obrigatórios de amostragem.
3. **Empty States**: Os guardiões redirecionam views órfãs para a interface padronizada `<EmptyState />` contendo mensagens esclarecedoras e link para o onboarding.

### Consequências
- **Positivas**: Eliminação definitiva de crashes por estados indefinidos, e integridade absoluta na segregação de dados corporativos de clientes distintos.
