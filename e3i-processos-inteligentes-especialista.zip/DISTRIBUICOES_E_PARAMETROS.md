# Guia de Distribuições Estatísticas & Amostragem Estocástica

O E3I simula tempos e comportamentos operacionais através de **9 modelos probabilísticos avançados**, fornecendo robustez para representar desde entregas cronometradas lineares até falhas de componentes baseadas em fadiga física.

## 1. Constante (Constant)
Retorna sempre o valor nominal parametrizado, simulando tempos rigidamente estruturados de esteiras automáticas ou robóticas.
- **Parâmetros**: `value` (em minutos).

## 2. Uniforme (Uniform)
Distribuição de densidade contínua onde todos os tempos dentro do espectro configurado possuem espectro de amostragem idêntico.
- **Parâmetros**: `min`, `max`.

## 3. Triangular (Triangular)
Excelente aproximação para modelar estimativas subjetivas baseadas na engenharia de chão de fábrica. Concentra os sorteios estatísticos em proximidade à moda empírica.
- **Parâmetros**: `min`, `max`, `mode`.

## 4. Normal / Gaussiana (Normal)
Amostrada de forma ultra precisa através de transformações polares de **Box-Muller** para evitar distorções estatísticas. Modelagem de trabalhos manuais complexos com estabilidade.
- **Parâmetros**: `mean`, `standardDeviation`.

## 5. Exponencial (Exponential)
Usada prevalentemente para taxas de atendimento consecutivas e tempos de quebras de equipamentos físicos ou instabilidades operacionais.
- **Parâmetros**: `rate` (taxa de eventos lambda).

## 6. Poisson (Poisson)
Aborda a frequência de eventos aleatórios independentes em um determinado horizonte cronometrado fixo.
- **Parâmetros**: `lambda`.

## 7. Beta (Beta)
Distribuição de alta flexibilidade para simular a variação do rendimento humano (yield) e produtividade de times internos entre 0 e 100%.
- **Parâmetros**: `alpha`, `beta`, `min`, `max`.

## 8. Weibull (Weibull)
Previsão científica com base na confiabilidade física, fadiga de componentes mecânicos e picos de falha operativa.
- **Parâmetros**: `scale` (η), `shape` (β).

## 9. Empírica (Empirical)
Garante que o motor use exclusivamente uma amostragem direta de registros pretéritos do negócio, retirando qualquer margem de aproximação teórica.
- **Parâmetros**: `observations` (Array de números decimais ordenados cronologicamente).
