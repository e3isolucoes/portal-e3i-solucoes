# Arquitetura de Navegação Unificada - E3I Processos Inteligentes

**Versão:** 2.0 (Fase 3 - Arquitetura Empresarial Unificada)  
**Status:** Implementado  

Este documento detalha o design de navegação simplificado da plataforma E3I Processos Inteligentes, que elimina menus concorrentes e unifica todos os recursos estratégicos, analíticos e operacionais sob uma única árvore hierárquica clara e responsiva.

---

## 1. Princípio de Navegação Única

Para mitigar a desorientação de usuários finais e otimizar fluxos corporativos, a E3I abandonou os múltiplos cabeçalhos por metodologia ou persona. Agora, todo o sistema é roteado por uma barra lateral padrão (Sidebar) no desktop ou por um menu do tipo gaveta (Drawer) com barra inferior fixa (Bottom Navigation) em dispositivos móveis.

---

## 2. Estrutura de Menus Unificada (As 8 Chaves de Sucesso)

O sistema centraliza-se sob 8 rotas mestras protegidas por privilégios de certificação e licenciamento corporativo:

1.  **Visão Executiva:**
    *   *Objetivo:* Apresentar semáforos de saúde geral de processos em linguagem amigável (Modo Simplificado) e gráficos de tendência estatística de qualidade (Modo Especialista).
    *   *Componente:* `DashboardLeigo` e `SigmaTrendDashboard`.
2.  **Portfólio:**
    *   *Objetivo:* Cadastro, seleção e governança de organizações, filiais e subprojetos em aberto.
    *   *Componente:* `CompanyProjectsModule`.
3.  **Processos:**
    *   *Objetivo:* Modelagem de postos físicos de trabalho da organização e biblioteca de manuais operacionais (SOPs).
    *   *Componente:* `VisualProcessMapper` e `BpmDocumentSuite`.
4.  **Projetos de Melhoria:**
    *   *Objetivo:* Execução guiada da metodologia Lean Six Sigma (DMAIC) dividida em abas integradas de ciclo de vida.
    *   *Sub-Navegação de Projeto:*
        *   *Visão Geral:* Alinhamento de escopos e metas.
        *   *Definir (Charter):* Diagnóstico guiado de causas e termo de abertura.
        *   *Medir (Sipoc):* Mapeamento de entradas, saídas e fornecedores.
        *   *Analisar (Gargalos):* Teoria das Filas avançada G/G/c de fluxo estável e controle SPC.
        *   *Melhorar (Co-Piloto):* Recomendação de balanceamento de capacidades guiada por IA Generativa.
        *   *Controlar:* Planos de controle de Shewhart e simulação "What-If" preditiva de faturamento.
        *   *Resultados (ROI):* Gráficos dinâmicos de retorno sobre investimento.
        *   *Evidências:* Repositório rastreável de documentos suportando drag-and-drop.
        *   *Histórico:* Log cronológico de modificações corporativas (auditoria interna).
5.  **Operação:**
    *   *Objetivo:* Acompanhamento real de cartas operacionais de trabalho acumulado em andamento (WIP).
    *   *Componente:* `WipKanbanBoard`.
6.  **Riscos e Controles:**
    *   *Objetivo:* Análises preditivas de quebras de SLA e prevenção de conformidade jurídica.
    *   *Componente:* `RiskAuditor`.
7.  **Relatórios:**
    *   *Objetivo:* Exportação de apresentações para conselhos consultivos de alta governança.
    *   *Componente:* `ReportPresentationGenerator`.
8.  **Administração:**
    *   *Objetivo:* Configurações gerais, simulação de perfis de cargos e sandbox do banco de dados.
    *   *Componente:* `AdminPanel`.

---

## 3. Navegação Mobile Responsiva

Para assegurar acessibilidade absoluta e conforto táctil:
*   **Cabeçalho Mobile:** Botão Hamburger na esquerda (revela Menu Drawer), E3I Logo centralizado e seletor compacto de filial ativa.
*   **Bottom Navigation Bar:** Barra inferior fixa contendo atalhos diretos e tácteis de alta frequência:
    *   `Início` -> Redireciona para **Visão Executiva**.
    *   `Projetos` -> Redireciona para **Projetos de Melhoria**.
    *   `Tarefas` -> Redireciona para **Operação**.
    *   `Mais` -> Provoca o deslizamento lateral reativo do Menu Drawer para as demais configurações de plataforma.
