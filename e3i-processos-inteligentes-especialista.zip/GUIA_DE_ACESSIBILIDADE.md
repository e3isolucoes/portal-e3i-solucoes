# E3I Processos Inteligentes - GUIA DE ACESSIBILIDADE E GOVERNANÇA

A ferramenta **E3I Processos Inteligentes** atua como um sistema corporativo B2B crítico para auditorias e certificações. Como tal, a **acessibilidade (a11y) e a clareza técnica** são requisitos de produto fundamentais, não apenas periféricos.

Este guia orienta engenheiros de software e designers nos critérios implementados para garantir conformidade técnica com o padrão **WCAG 2.1 AA (Web Content Accessibility Guidelines)**.

---

## 1. Navegação por Teclado e Foco Visível

Qualquer usuário deve conseguir operar de forma integral os fluxos de modelagem, simulações e auditoria usando apenas o teclado (`Tab`, `Shift + Tab`, `Enter`, `Space` e setas de direção).

### Diretrizes de Implementação

1.  **Anel de Foco Unificado**:
    *   Toda tag interativa (`button`, `input`, `select`, `textarea`, `a`) deve receber a classe utilitária do Design System: `focus:ring-2 focus:ring-[#1E3A8A] focus:outline-none`.
    *   **Nunca desative o contorno sem fornecer um anel reativo substituto.** O anel deve ter alto contraste contra fundos de dados claros ou escuros.
2.  **Ordem de Tabulação Lógica**:
    *   Alinhe o layout de forma que a tabulação siga estritamente a orientação de leitura natural (esquerda para direita, cima para baixo).
    *   Evite o uso de valores positivos no atributo `tabindex` para não quebrar o fluxo padrão do navegador.
3.  **Fechamento Ágil**:
    *   Telas modais (`Dialog`) ou gavetas laterais de configurações (`Drawer`) devem fechar imediatamente ao detectar o acionamento de `Escape`.
    *   Ao abrir uma janela de diálogo (`dialog`), posicione o foco automaticamente no primeiro elemento editável para evitar rolagem invisível indesejada.

---

## 2. Estrutura de Documento e Semântica HTML

O código deve se comunicar de forma transparente com leitores de tela populares (como NVDA ou JAWS) através de marcas estruturais explícitas:

*   **Identificadores Exclusivos (`id`)**:
    *   Campos de formulários possuem `id` exclusivos acoplados ao `htmlFor` do `label` correspondente. Isso garante que, ao ler o formulário, o leitor vocalize imediatamente o nome correto do campo.
*   **Hierarquia de Títulos**:
    *   Use apenas um título principal `h1` na aplicação.
    *   As seções operacionais devem seguir hierarquia `h2` a `h5` de forma aninhada lógica. Nunca salte de um `h2` diretamente para um `h4`.
*   **Marcos de Layout (Landmarks)**:
    *   Agrupe sessões transversais sob tags corretas como `<header>`, `<main>`, `<section>`, `<nav>` e `<footer>`.

---

## 3. Contraste de Cores e Adaptação Física

*   **Critério de Contraste WCAG AA**:
    *   Texto regular deve manter uma taxa de contraste mínima de **4.5:1** contra o fundo.
    *   Texto grande de destaque deve possuir pelo menos **3:1**.
*   **Modificações sem Cores (Acessibilidade Cromática)**:
    *   Informações críticas de desvios operacionais (como limites estourados) não são transmitidas apenas pela cor vermelha. Elas são obrigatoriamente acompanhadas por ícones semânticos (ex: ⚠️ ou 🚫) e textos descritivos textuais (ex: "Excedido UCL").

---

## 4. Gerenciamento de Feedbacks Assíncronos e Live-Regions

Ao atualizar gráficos de simulação ou disparar feedbacks de rede, o usuário de leitor de tela precisa ser notificado de forma não-intrusiva:

*   **Toasts e Alertas**:
    *   A barra de alertas e toasts inclui o atributo `role="alert"`. O navegador relata instantaneamente o novo texto de erro ou sucesso na voz do leitor de tela.
*   **Ancoragem de Estados de Carregamento**:
    *   O substituto visual de carregamento (`Skeleton` ou rodas tridimensionais) possui o atributo `aria-busy="true"` no container pai correspondente, indicando que novos resultados estão sendo sintonizados.
