# Mapa de Rotas, Autorizações e Pipeline de Dados LSS

**Versão:** 2.0 (Fase 3 - Arquitetura de Redirecionamento Unificado)  
**Status:** Concluído  

Este documento descreve a estrutura de roteamento reativo baseada em estado do aplicativo **E3I Processos Inteligentes**, detalhando as novas 8 rotas unificadas da Fase 3 e os mecanismos de autorização integrados.

---

## 1. Roteamento Reativo Unificado (State-Driven Routing)

Para obtermos altíssima performance livre de atrasos de requisições de página inteira, a E3I adota roteamento reativo baseado em estado. A chave central reside na propriedade `currentWorkspaceView` localizada no componente principal `App.tsx`.

### Mapeamento das 8 Novas Rotas e Visualizadores de Negócio:

*   **Página Pública de Entrada:**
    *   `PUBLIC_SALES`: Landing de vendas B2B e captação de leads.
*   **As 8 Chaves de Entrada do Cliente:**
    *   `EXECUTIVE`: Painel de indicadores de semáforos fáceis e análises de tendências.
    *   `PORTFOLIO`: Gestão de empresas parceiras, auditoria interna e criação de projetos.
    *   `PROCESSES`: Biblioteca BPM de fluxogramas e modelagem visual de postos físicos de trabalho.
    *   `IMPROVEMENTS`: O Roteiro DMAIC unificado de termos de abertura, SIPOC, evocações de IA e repositório de evidências jurídicas das melhorias.
    *   `OPERATIONS`: Quadro Kanban de trabalho em andamento (WIP) e tempos de espera por posto.
    *   `COMPLIANCE`: Identificação preditiva de riscos operacionais e auditor de fila estável.
    *   `REPORTS`: Exportador dinâmico de lâminas de apresentação para reuniões deliberativas.
    *   `ADMINISTRATION`: Gestão de quotas corporativas, simulação de privilégios de cargo e ativação de Sandbox.

---

## 2. Compatibilidade Retroativa (Fallback Interceptor)

Para prevenir qualquer quebra visual de subcomponentes legados ou caminhos alternativos que acionavam rotas antigas (`DIAGNOSTIC`, `MAP`, `DMAIC`, `KANBAN`, `BPM`, `OR_HUB`, `REPORT`, etc.), o setter de estado `setCurrentWorkspaceView` intercepta os gatilhos antigos e mapeia automaticamente para nossa nova estrutura:

```text
[Chamada Legada: "MAP"] ──► Interceptador setter `setCurrentWorkspaceView`
                                        │
                                        ▼ Redirecionamento Inteligente
                       Mapeia sub-visão: setProcessSubView("MAPPER")
                       Altera rota mestre: currentWorkspaceViewRaw("PROCESSES")
```

---

## 3. Guardiões de Permissão (Permission Guards & RBAC)

A autorização de tela opera de forma combinada baseada no plano ativo da empresa inquilina e na função do operador (Cargo):

1.  **Guardião de Ativação de Módulo (Module Activation Guard):**
    A Sidebar omite de forma elegante e reativa botões para os quais o inquilino não contratou licenciamento prévio ou acesso administrativo.
2.  **Guardião de Ativação por Cargo (RBAC Guard):**
    A visualização administrativa `ADMINISTRATION` é estritamente proibida para cargos inferiores a "Admin", instanciando bloqueios de segurança amigáveis de desvio.
