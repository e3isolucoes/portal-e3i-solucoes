# 🛡️ Relatório de Diretivas de Segurança — E3I Processos Inteligentes

Este relatório descreve as medidas de segurança, mitigação de ameaças e integridade e proteção de dados implementados no núcleo da plataforma E3I Processos Inteligentes.

---

## 🔒 Princípios de Segurança da Informação (CIA)

Nossa arquitetura prioriza a **Confidencialidade**, **Integridade** e **Disponibilidade** dos dados corporativos:

1. **Confidencialidade**: Os dados corporativos das empresas contratantes são isolados de forma imperativa. Chaves de filtragem lógica garantem que concorrentes nunca cruzem chamadas ou tenham visibilidade de diagramas BPMN de terceiros.
2. **Integridade**: Garantia de cálculos matemáticos sem vieses arbitrários e controle de escrita em tabelas via políticas de acesso granulares (RBAC).
3. **Disponibilidade**: Integração nativa com infraestrutura em Nuvem redundante e auto-escalável (Google Cloud Run), assegurando alta tolerância a falhas.

---

## 📂 Diretiva de Proteção e Blindagem de Uploads

O carregamento de evidências de auditoria no repositório técnico central de cada projeto foi blindado contra invasões ou injeções de arquivos prejudiciais através de uma suíte de verificação integrada (`/src/utils/uploadValidator.ts`):

* **Sanitização de Nomes (Anti-Path-Traversal)**: O validador reescreve o nome de arquivos recebidos, substituindo barras e contra-barras por caracteres inofensivos. Caso o nome tente ocultar o arquivo por caminhos ocultos de diretório (`../`), o validador reprime a ação e atribui uma máscara segura criptografada e datada (`compliance_attachment_{current_time}_secured.pdf`).
* **Enforcamento de Tamanho (Oversize Block)**: Bloqueio imperativo a uploads maiores do que **15MB**, blindando o servidor contra ataques de negação de serviço (DoS) por saturação de armazenamento de disco.
* **Validação de Extensões e Assinatura de MIME**: Arquivos são validados por verificação dupla:
  * Verificação de extensão em whitelist rígida (`.pdf`, `.png`, `.jpg`, `.jpeg`, `.xlsx`, `.docx`, `.zip`, `.csv`).
  * Validação assinatura MIME do navegador, filtrando terminantemente pacotes executáveis de risco como `.exe`, `.sh` ou `.bat`.
* **Privilégios RBAC Estritos**: Apenas usuários com status de permissão correspondente a `editar` ou `criar` sob o projeto ativo podem interagir com o repositório central.

---

## 👤 Proteção de Credenciais e Bloqueio de Chaves Públicas

Em observância aos requisitos de integridade do ecossistema AI Studio:
* **Não mantemos** nenhuma chave secreta ou segredo público estático no código.
* Toda a comunicação com a API do Gemini é proxyzada de forma segura através de rotas do servidor backend Express, garantindo que o token `GEMINI_API_KEY` permaneça invisível no lado do cliente.
* O Firebase é inicializado através de metadados de credenciais dinâmicas injetadas diretamente em tempo de build a partir da raiz segura do servidor.
* **Sem Contas Administrativas Fixas**: Todas as sessões administrativas passam pelo controle fiduciário de autenticação multifatorial. O acesso demonstrativo (Demo Mode) opera em Sandbox de Treinamento local isolado, sem comunicação com a nuvem, protegendo a segurança das credenciais dinâmicas do usuário final.
