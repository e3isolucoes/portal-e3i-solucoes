# E3I Processos Inteligentes - Modelo de Entregáveis

Este documento apresenta a modelagem técnica dos entregáveis e suas associações com o ciclo de vida DMAIC.

## Interface TypeScript

O tipo `Deliverable` é definido em `src/types.ts` com as seguintes características estruturais:

```typescript
export type DeliverableStatus =
  | "not_started"
  | "in_progress"
  | "waiting_approval"
  | "approved"
  | "rejected"
  | "blocked";

export interface Deliverable {
  id: string;
  projectId: string;
  processId?: string;
  stepId?: string;
  createdAt: string;
  
  // Phase 4 strict fields
  phaseId: string;                 // e.g., "DEFINE", "MEASURE", "ANALYZE"
  name: string;                    // Nome do entregável
  description?: string;            // Descrição detalhada do objetivo
  required: boolean;               // Obrigatoriedade (regras de conclusão)
  weight: number;                  // Peso relativo do entregável na fase (1 a 3)
  status: DeliverableStatus;       // Estado operacional
  responsibleUserId: string | null;// ID/Nome do responsável
  dueDate: string | null;          // Prazo de expiração
  approvedBy: string | null;       // Auditor responsável pela aprovação
  approvedAt: string | null;       // Timestamp do consentimento
  evidenceIds: string[];           // IDs de mídias de comprovação
  blockerReason?: string;          // Motivo técnica de eventual bloqueio
  comments?: {                     // Comentários de correção e debate
    id: string;
    user: string;
    text: string;
    date: string;
  }[];
}
```

## Entregáveis Padrão por Fase

Ao criar um plano de melhorias, as etapas abaixo são recomendadas como linha de amostragem padrão (Templates):

### 1. D - Definir (DEFINE)
- **Charter do Projeto** (*Obrigatorio, Peso 3*)
- **Mapeamento SIPOC de Alto Nível** (*Obrigatorio, Peso 2*)

### 2. M - Medir (MEASURE)
- **Coleta de Dados e Cronoanálise** (*Obrigatorio, Peso 2*)
- **Garantia de Sistema de Medição (Gage R&R)** (*Opcional, Peso 1*)

### 3. A - Analisar (ANALYZE)
- **Cálculo de Eficiência e Identificação de Gargalos** (*Obrigatorio, Peso 3*)
- **Diagrama de Ishikawa & 5 Porquês** (*Obrigatorio, Peso 2*)

### 4. I - Melhorar (IMPROVE)
- **Plano de Ações Corretivas** (*Obrigatorio, Peso 3*)
- **Design de Experimentos / Simulação** (*Opcional, Peso 2*)

### 5. C - Controlar (CONTROL)
- **Planos de Controle CEP (SPC)** (*Obrigatorio, Peso 3*)
- **FMEA / Padronização de SOPs** (*Opcional, Peso 1*)
