# 📘 Documentação Funcional — E3I Processos Inteligentes

Esta documentação detalha as capacidades funcionais, módulos operacionais e fluxos de uso da **Plataforma E3I Processos Inteligentes**, um ecossistema corporativo completo de Gestão de Excelência de Processos baseado em Lean Six Sigma, Teoria das Filas e Pesquisa Operacional.

---

## 🧭 Visão Geral da Jornada do Usuário

A plataforma guia executivos, engenheiros de processo, líderes de projeto e auditores do diagnóstico inicial à sustentação matemática:

1. **Onboarding & Setup**: Configuração do perfil corporativo, escolha de setor industrial ou de serviços e definição de metas.
2. **Diagnóstico Estratégico (Wizard)**: Avaliação da maturidade operacional, identificando perdas financeiras (CopQ) e gerando o Project Charter e SIPOC de alto nível.
3. **Mapeamento de Fluxo (BPMN Studio)**: Modelagem visual de fases com tempo de ciclo, setup de máquina, rendimento (Yield) e servidores produtivos.
4. **Simulação de Monte Carlo**: Teste de estresse estocástico convertendo inputs dinâmicos em cenários reais através de amostragem de Box-Muller e modelagem de filas.
5. **Otimização de Linha (OrQuality Hub)**: Solver linear Simplex integrado para encontrar o "Mix de Produtos Ótimo", maximizando a receita sob limites de tempo.
6. **Controle Ativo (DMAIC Dashboard - Phase 4)**: Acompanhamento de entregáveis em formato de portfólio de auditoria, acompanhado por Cartas de Controle Shewhart (CEP/SPC), detecção automática de desvios via Regras de Nelson, e upload seguro de evidências técnicas de conformidade.

---

## 🛠️ Detalhamento dos Módulos Principais

### 1. Mapeador BPMN (BpmDocumentSuite & ProcessDesignRoom)
* **Modelagem Estocástica**: Cada etapa do processo não possui um tempo estático, mas sim parâmetros estatísticos: Média, Desvio Padrão (Variabilidade), e Tempo de Setup.
* **Mapeamento de Restrições**: Permite configurar a quantidade de funcionários ou máquinas dedicados em cada posto (*Resource Count*).
* **Visão de Cadeia de Clientes (SIPOC)**: Rastreamento transparente de Fornecedores, Entradas, Processos, Saídas e Clientes para cada macro-etapa.

### 2. Motor de Simulação Estocástica de Monte Carlo
* **Transformada de Box-Muller**: Converte números pseudo-aleatórios uniformes em uma distribuição normal realista, simulando variações de fila de forma científica sem gerar valores impossíveis ou negativos.
* **Fórmula de Allen-Cunneen (Fila G/G/c)**: Calcula o tempo de fila e acúmulo esperado em cada posto de trabalho sob alta variabilidade e múltiplos servidores produtivos.
* **Deteção de Saturação (Utilização %)**: Alerta imediato e colorização brutalista em vermelho caso a utilização passe de 100% (indicador de fila infinita e gargalo crônico).

### 3. Otimização Linear e Pesquisa Operacional (OrQuality Hub)
* **Algoritmo Simplex**: Executa um Solver matemático no lado do cliente que resolve equações lineares de maximização de lucros sujeitas a restrições de horas ou capacidade produtiva.
* **Teoria das Restrições (TOC)**: Identifica o gargalo do sistema e orienta o balanceamento para transferir excedentes operacionais aos postos sub-utilizados.

### 4. Controle Estatístico e Sustentação (CEP/SPC)
* **Cartas de Controle Shewhart**: Gráfico interativo que plota a tendência de refugo ou o tempo de ciclo em tempo real.
* **Zonas Estatísticas (1σ, 2σ, 3σ)**: Demarca limites flutuantes calculados com base no desvio padrão clássico de flutuação natural do processo.
* **Regras de Nelson (WECO)**: Verifica anomalias estatísticas como:
  * Ponto fora do limite de controle de 3 sigma (Causa Especial imediata).
  * 9 pontos consecutivos do mesmo lado da linha média (Mudança de nível de processo).
* **Plano de Controle / Reaction Plan**: Configuração eletrônica de contramedidas com Pokayokes acionáveis caso os alarmes estatísticos sejam disparados.

---

## 📂 Repositório de Evidências e Governança

* **Aprovações Formais**: Fluxo robusto de submissão e análise técnica onde Auditores ou Administradores reavaliam os entregáveis concluídos de cada fase do DMAIC.
* **Upload Protegido**: Ápice da segurança de conformidade em auditoria Lean. Permite anexar diagramas de fluxo, relatórios e vistorias físicas nos layouts aceitos (PDF, PNG, XLSX, etc.) sob profunda validação lógica de tipo e tamanho de arquivo.
* **Histórico de Auditoria Rastreável**: Linha de tempo cronológica imutável que registra cada evento de acesso, edição, upload, e alteração de prazo ou status corporativo.

---

*Para dúvidas operacionais avançadas ou solicitações de customização de fórmulas estatísticas, acione o canal corporativo via Administração.*
