# Políticas de Segurança de Arquivos - E3I Processos Inteligentes

Este documento descreve as políticas de segurança de dados e o encanamento do pipeline de quarentena de upload de arquivos implementado na **Fase 9**.

## Fluxo do Pipeline Seguro

Quando um usuário anexa evidências comprobatórias aos projetos Lean Six Sigma, os arquivos percorrem o seguinte pipeline isolado de segurança (SLA em Tempo Real):

```
Usuário Envia Arquivo 
   ↓
Validação Inicial (Tamanho, Tipo, Perfil, Escopo)
   ↓
Quarentena Temporária (Prevenção de Ingressos Diretos)
   ↓
Varredura Antimalware (Mecanismo Equivalente ao ClamAV)
   ↓
Validação de Assinatura MIME Binária Real
   ↓
Cifragem Autenticada (AES-256-GCM Envelope)
   ↓
Armazenamento Permanente Blindado
   ↓
Registro Auditório de Compliance (Append-Only)
```

## Regras de Validação Estritas

1. **Associação de Escopo**: O arquivo deve estar associado de forma indissociável a uma empresa e um projeto ativos no ecossistema multi-tenant.
2. **Checagem de Extensão**: Somente extensões confiáveis são aceitas (`.pdf`, `.png`, `.jpg`, `.jpeg`, `.xlsx`, `.docx`, `.zip`, `.csv`).
3. **MIME Type Coerente**: Impede táticas de "Double Extension" (ex: `relatorio.pdf.exe`) analisando assinaturas binárias internas.
4. **Resguardo de Tamanho**: Limite máximo fixado em 15MB por arquivo.
5. **Mitigação de Descompressão Recursiva (ZIP Bomb)**: Arquivos compactados contendo mais de 5 arquivos internos ou rácios extraordinários de tamanho são barrados preventivamente.
6. **Controle Quarentenário**: O arquivo permanece em estado de quarentena (inacessível para qualquer usuário/auditor) até que a varredura conclua e o considere `approved`.
