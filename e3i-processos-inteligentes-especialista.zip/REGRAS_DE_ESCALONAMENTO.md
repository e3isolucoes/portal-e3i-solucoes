# Regras de Escalonamento e Alertas de Prazos (Fase 13)

Para evitar gargalos no ciclo de melhoria contínua DMAIC, o e3i provê uma régua estocástica de cronogramas e escalonamento para alertas de proximidade e estouro de prazos.

## 1. Funcionamento da Régua de Atraso

A régua de disparo e os respectivos destinatários são estruturados de forma progressiva conforme demonstrado nos testes de homologação:

| Condição Reativa | Destinatário Principal | Alvos em Cópia / Escalonamento |
| :--- | :--- | :--- |
| **3 Dias antes do vencimento** | Operador Responsável | Nenhum |
| **No dia do vencimento** | Operador Responsável | Líder do Projeto |
| **1 Dia em atraso** | Operador Responsável | Líder imediato & Gestor da área |
| **3 Dias em atraso** | Operador Responsável & Líder | Gestor e seu substituto legal |
| **7 Dias em atraso** | Todos os anteriores | Stakeholder / Patrocinador do Projeto |

---

## 2. Ajustes Fuso Horário e Dias Úteis

As rotinas avaliam o fuso horário da respectiva holding (ex. `America/Sao_Paulo`) e restringem disparos não compulsórios aos fins de semana e feriados (parâmetro `weekdaysOnly: true`). 

- O envio segue a hora configurada pelo administrador (ex. `09:00h` locais).
- Caso o usuário defina a preferência de **Resumo Diário (Daily Digest)**, os alertas não críticos do fuso anterior acumulam-se em fila e transmitem-se em um único e-mail consolidado ao final do expediente (ex. `18:00h`).
