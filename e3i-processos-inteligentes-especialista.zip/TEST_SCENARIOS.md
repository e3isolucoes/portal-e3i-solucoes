# 🧪 Roteiro de Testes e Cenários de Homologação (E3I Lean Six Sigma)

Este documento descreve detalhadamente o passo a passo para a homologação das duas principais jornadas de usuários do sistema E3I (Empresa Nova vs. Empresa Existente), garantindo a robustez da plataforma e a validação do Role-Based Access Control (RBAC), do motor de Teoria de Filas e dos fluxos auxiliados pelo Assistente Inteligente E3I.

---

## 🏢 CENÁRIO 1: Jornada de uma "Empresa Nova" (Onboarding & Configuração Inicial)
*Objetivo: Validar o fluxo de ponta a ponta desde o cadastro de uma nova organização, criação de projetos, seleção de presets industriais até o projeto DMAIC ser estabelecido.*

### Passo 1: Cadastro e Onboarding da Organização
1. Abra a aplicação no navegador em um estado limpo (ou após limpar cookies/localStorage).
2. Na página inicial ou de identificação de Workspace, clique no botão **"Nova Empresa / Cliente"** ou localize a opção correspondente ao preencher os dados de primeira ativação.
3. Insira o nome de uma organização fictícia (ex: `"Logística Expressa Alfa"`) e selecione o segmento industrial (ex: `"Faturamento, Logística ou Serviços"`).
4. Insira um nome de projeto inicial coerente (ex: `"Aprimoramento do Fluxo de Envios"`).
5. Clique em **"Criar Empresa & Inicializar"**.
6. **Resultado Esperado**:
   * O sistema deve provisionar e persistir no banco de dados a nova entidade de empresa e o projeto.
   * O usuário ativo é automaticamente direcionado ao dashboard com a empresa `"Logística Expressa Alfa"` visível no cabeçalho como a atual organização selecionada.

### Passo 2: Seleção de Presets por Área Corporativa
1. Na tela de Onboarding/Galeria de Presets, explore as opções baseadas no segmento de negócio.
2. Selecione o preset: **"Aceleração do Picking / Logística de E-commerce"** ou similar.
3. Clique em **"Aplicar Preset de Mapeamento"**.
4. **Resultado Esperado**:
   * O sistema deve pré-configurar o fluxo de processo com dados operacionais coerentes, tais como:
     * Taxa de chegada ($\lambda$) com distribuição adequada;
     * Pelo menos 4 a 5 etapas estruturadas na cadeia de serviço (ex: *Recebimento*, *Picking*, *Embalagem*, *Despacho*, *Qualidade*);
     * Capacidade instalada (Staff), tempos médios de operação, variabilidade por posto e qualidade intrínseca (*First Pass Yield*).
   * Os painéis exibem estatísticas operacionais calculadas por Teoria das Filas imediatamente (sem requisições vazias ou travamentos).

### Passo 3: Definição de Metas (Project Charter - Fase DEFINE)
1. Certifique-se de que está na fase **DEFINE** do ciclo DMAIC.
2. Abra a seção do **Project Charter**.
3. Adicione dados específicos à meta do negócio (ex: *Elevar nível Sigma de 3.2 para 4.8 e reduzir WIP em 30%*). Suprima quaisquer dados pendentes de escopo e restrições.
4. Salve as informações preenchidas.
5. **Resultado Esperado**:
   * As metas do projeto atualizam instantaneamente e alimentam os painéis operacionais.
   * Não ocorre erro de re-renderização infinita ou mensagens genéricas de falhas.

---

## ⚡ CENÁRIO 2: Jornada de uma "Empresa Existente" (Estabilidade, Melhoria e Navegação DMAIC)
*Objetivo: Validar a governança, a segurança, o controle de acesso com RBAC, a navegação entre views do DMAIC e a simulação de otimizações usando o Assistente Inteligente E3I.*

### Passo 1: Autenticação, RBAC e Seleção de Contexto Ativo
1. Acesse o sistema e selecione na tela inicial (ou no menu de seleção rápida) uma empresa com dados previamente carregados (ex: `"Indústria de Manufatura Beta"` ou utilizar o projeto padrão existente).
2. Na barra do usuário, mude o perfil de acesso ou valide as permissões concedidas.
3. **Validação de Permissões (RBAC)**:
   * Acesse a tela de **Administração / Governança** da plataforma.
   * Se o usuário logado dispõe da permissão `admin:view` (atribuída ao cargo de *"Administrador"*), o sistema deve renderizar o painel de governança completo, auditorias do banco de dados e logs em tempo real.
   * Se o usuário logado tiver seu cargo alterado para um papel restrito (ex: *"Colaborador"* ou *"Visualizador"* que não dispõe da permissão `admin:view`), o acesso à rota/painel de administração deve ser bloqueado imediatamente pelo `PermissionGuard`, exibindo uma mensagem limpa e polida de acesso restrito (ex: *"Acesso Reservado"*), sem causar crash do React ou bugs visuais.
   * **Resultado Esperado**: O `PermissionGuard` bloqueia ou concede acesso dinamicamente com base nas credenciais reais do usuário em vez de usar hardcoded checks.

### Passo 2: Navegando pelas Fases DMAIC & KPIs de Gargalos
1. No menu principal da plataforma, navegue sequencialmente entre as fases do ciclo de melhoria contínua DMAIC:
   * **D (Define)**: Visualização do Project Charter e justificativa econômica.
   * **M (Measure)**: Mapeamento detalhado visual em diagrama de fluxo livre BPMN, layout estofado de filas e matriz SIPOC.
   * **A (Analyze)**: Análise de Capabilidade estatística integrada e painel de diagnóstico de Gargalo por Teoria de Filas.
   * **I (Improve)**: Alocação do co-piloto científico para aplicação de melhorias e simulações.
   * **C (Control)**: Relatórios de sustentabilidade e Gráficos de CEP (Controle Estatístico de Processo - cartas de Shewhart).
2. Em cada mudança de etapa, inspecione se os KPIs globais estão atualizados acima da dobra de maneira compacta de acordo com o contexto operacional.
3. **Resultado Esperado**: Uma transição de tela amigável exibindo dados integrados consistentes em cada fase, sem lag de dados e de fácil interpretação.

### Passo 3: Utilização das Melhores Práticas de Otimização (Assistente Inteligente E3I)
1. Na barra superior ou no canto inferior direito, clique em **Assistente Inteligente E3I** para abrir o novo hub unificado.
2. Examine o diagnóstico de saúde operacional feito pela IA, apontando de forma automática a restrição física limitante (O gargalo ativo do processo).
3. Na área de sugestões rápidas, clique alternadamente nos botões de melhoria (ações Kaizen):
   * **Equilibrar Fluxo do Gargalo**: Redistribui tempos médios dos postos de trabalho para aumentar a vazão operacional máxima.
   * **Mitigar Variabilidade (SMED)**: Reduz em até 30% os desvios-padrão de tempos, diminuindo filas e mitigando o tempo total de travessia do WIP.
   * **Blindagem de Qualidade (Poka-Yoke)**: Aumenta a taxa de passagem direta do processo nas etapas mais críticas de conferência.
   * **Incrementar Staff**: Adiciona operadores adicionais paralelos para expandir a vazão pontual do gargalo.
4. **Resultado Esperado**:
   * Cada clique simula e atualiza os KPIs principais e gráficos CEP em tempo real de forma interconectada.
   * Um banner sutil de celebração (Celebration Flash) confirma visualmente a aplicação.
   * O registro de histórico de melhoria é gravado no log do Assistente contendo a data operacional aplicável.

### Passo 4: Chamada Preditiva de IA (Gemini)
1. Dentro do Assistente Inteligente E3I, acesse a aba ou opção de análise do Gemini e solicite o **Diagnóstico Preditivo DMAIC**.
2. **Resultado Esperado**: A IA deve consumir os metadados do fluxo (etapas, estatísticas, gargalos) e devolver e expor de forma textual estruturada recomendações Lean Six Sigma reais, precisas e aplicáveis ao contexto da empresa.
