# 🎨 Relatório de Evidências Visuais e Reflow — E3I Processos

Este documento detalha o padrão estético, layout, e o fluxo de telas homologados para o módulo de **Processos Inteligentes E3I**, comprovando visualmente a execução dos critérios de design e UX.

---

## 1. Grid Visual e Visualização de Indicadores (KPIs)

Os 5 principais indicadores corporativos (Performance, Gargalo Crítico, Qualidade Yield, Tempo de Ciclo Média, WIP) foram dispostos de forma a aparecerem **100% acima da dobra** ao carregar a página:

- **Estilo de Cards**: Fundo branco em contraponto ao fundo cinza claro (`#F7F8FA`) do layout principal, bordas arredondadas e suavizadas (`rounded-xl border-[#E4E7EC]`), oferecendo profundidade clássica de baixa fadiga visual.
- **Hierarquia Tipográfica**:
  - Rótulos em caixa alta de tamanho mínimo (`text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider`) posicionados no topo do card.
  - Valores em destaque display serifado sólido (`text-2xl font-serif font-black text-[#0F1728]`) no centro.
  - Micro-indicadores de tendência ou de metas complementares na linha inferior.

---

## 2. Esqueleto de Carregamento (Loading Skeleton)

Para evitar desníveis ou saltos de layout abruptos (Cumulative Layout Shift) durante cargas pesadas de dados:
- **Componentes Pulsantes de Carga**: Renderiza contêineres temporários idênticos à arquitetura física dos cards com animações cíclicas de opacidade de entrada e saída (`h-64 bg-slate-150 animate-pulse rounded-lg`), oferecendo fluidez e controle psicológico de tempo para o usuário.

---

## 3. Estado Vazio (No Data / Empty States)

Cenários onde não há dados populados no escopo do projeto ativo exibem ilustrações vetoriais limpas acompanhadas de mensagens humanas, humble e acionáveis:
- **Mensagem Sem Dados**: *"Nenhum Posto Criado. Comece modelando seu fluxo industrial adicionando a primeira atividade na aba BPMN superior."*
- **Ação Rápida**: Presença de botão com bordas de alto destaque douradas para que o engenheiro carregue imediatamente o preset de SMT ou Linha de Montagem de exemplos em 1 clique.

---

## 4. Ocultação do Copiloto IA Secundário

- Quando o usuário entra na visualização `PROCESSES`, o motor cognitivo desativa a renderização do botão flutuante Copiloto (`floating-lss-copilot-trigger`) para evitar poluição visual, acoplamentos inseguros e sobreposição de tabelas de dados.
- O diálogo interativo do Assistente reside de forma discreta na TopBar superior, abrindo um painel lateral fluido (drawer lateral) que empurra a viewport de forma adaptativa.
