# ♿ Certificação de Acessibilidade (WCAG 2.1) — E3I Processos

Este documento detalha o checklist de conformidade e as correções estruturais de acessibilidade aplicadas na tela de **Processos Inteligentes E3I**.

---

## 1. Organização Semântica e WAI-ARIA nas Abas

A navegação interna da página (Visão Geral, Mapeamento BPMN, Indicadores, Melhorias, Documentos, Histórico) foi reformulada para seguir estritamente o padrão de design de abas de acessibilidade do **W3C WAI-ARIA**:

1. **Role `tablist`**: O container principal das abas foi configurado para informar leitores de tela de que se trata de uma lista interativa de agrupamento de telas.
2. **Role `tab`**: Cada botão individual se apresenta com a semântica correta nas ferramentas de assistência auditiva.
3. **Propriedade `aria-selected`**: Atualizado dinamicamente para `true` na aba focada/ativa ou `false` nas demais.
4. **Propriedade `aria-controls`**: Linca fisicamente cada cabeçalho de aba (`id="tab-overview"`) ao seu respectivo container de conteúdo (`id="panel-overview"`), permitindo que leitores pulem diretamente para o início dos dados operacionais.
5. **Role `tabpanel`**: Atribuído dinamicamente ao container ativo com rótulo semântico `aria-labelledby="tab-..."`.

---

## 2. Navegação por Teclado e Foco Visor Sequencial

Para usuários que dependem exclusivamente do teclado para navegação no sistema:

- **Foco Seqüencial (`tabIndex`)**: A aba ativa recebe `tabIndex={0}` para que possa ser selecionada na ordem natural da tecla `Tab`. Abas inativas recebem `tabIndex={-1}` evitando ruídos adicionais e permitindo saltos limpos.
- **Micro-indicador de Foco**: Todos os botões receberam classes utilitárias de contorno visual de destaque (`focus:outline-none focus:ring-2 focus:ring-[#D4A547] focus:ring-offset-1`), garantindo que a borda dourada de alta visibilidade marque com precisão onde o cursor de teclado se encontra.

---

## 3. Eliminação de Bloqueadores e Sobreposições de IA

A inteligência de acessibilidade removeu o botão flutuante discreto fixed no canto inferior direito. Suas consequências negativas incluíam:
- **Sobreposição Física**: O botão cobria dados quantitativos ou formulários em resoluções menores.
- **Falta de Área de Escape**: Usuários navegando por cliques ou toque frequentemente clicavam no assistente sem intenção ao tentar rolar tabelas.
- **Bypass de Leitor**: O foco flutuante confunde o caminho natural de varredura sequencial.

**Solução Aplicada**: O acionamento da IA foi migrado com área de escape estrita diretamente para as ações fixas da **TopBar compacta**, residindo de forma segura e não obstrutiva.

---

## 4. Contraste e Fontes Recomendadas
- **Legibilidade de Dados**: Todo o texto numérico importante, KPIs, e unidades adotaram cores escuras de alto contraste sobre fundo claro (ex: `#0F1728` sobre off-white, oferecendo índice de contraste superior a `7:1`).
- **Fontes Flexíveis**: Utilização do design padrão escalável em tamanhos baseados em `rem`/`em` (`text-xs`, `text-sm`, `text-base`), permitindo o redimensionamento nativo do navegador sob ferramentas de ampliação (zoom) sem quebra ou empilhamento inseguro de contêineres.
