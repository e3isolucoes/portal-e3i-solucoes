# 🚀 Guia de Deploy — E3I Processos Inteligentes

Este guia instrui sobre o processo de empacotamento, compilação de produção e deploy em nuvem (Cloud Run/GCP ou servidores privados virtuais) da plataforma E3I Processos Inteligentes.

---

## 📦 Estratégia de Compilação de Produção

A plataforma E3I foi desenhada utilizando um ecossistema full-stack híbrido. Durante a fase de build, o sistema divide-se de forma inteligente:

1. **Frontend (Vite / React 19)**:
   Compila os arquivos estáticos e otimiza o bundle aplicando técnicas de *tree-shaking*, otimização de imagens vetoriais e minificação de arquivos CSS e JS para a pasta `dist`.

2. **Backend (Node.js Express / TypeScript)**:
   Compila o servidor `server.ts` em formato CommonJS de um único arquivo bundled autônomo localizado em `dist/server.cjs` via **esbuild**. Isto poupa ciclos de inicialização I/O em containers frios, eliminando buscas redundantes em `node_modules`.

---

## 🏗️ Executando a Compilação de Produção

Para realizar a compilação completa para produção, execute no seu pipeline CI/CD:
```bash
npm run build
```
O resultado gerado constará na pasta `dist/`:
* `dist/index.html` (Entrypoint do SPA)
* `dist/assets/` (Código e estilos do frontend compactados)
* `dist/server.cjs` (O servidor Express empacotado para servir a API e os arquivos estáticos)

---

## 🐳 Deploy via Container Docker (Cloud Run Recomendado)

Como o porto padrão exigido pela arquitetura nginx do sistema é o porto **3000**, o deploy em container é ideal para escalabilidade automática.

### Exemplo de Dockerfile de Produção Harmonizado
```dockerfile
FROM node:20-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

# Stage de Execução ultra-leve
FROM node:20-alpine

WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000

COPY package*.json ./
RUN npm ci --only=production

COPY --from=builder /app/dist ./dist

EXPOSE 3000

CMD ["node", "dist/server.cjs"]
```

---

## 🚀 Passo a Passo para Deploy na GCP (Google Cloud Run)

### Passo 1: Autenticar e Configurar o Projeto GCP
```bash
gcloud auth login
gcloud config set project <id-do-projeto-gcp>
```

### Passo 2: Construir e Enviar Imagem Docker para o Artifact Registry
```bash
gcloud builds submit --tag gcr.io/<id-do-projeto-gcp>/e3i-platform:latest
```

### Passo 3: Executar Deploy no Cloud Run
```bash
gcloud run deploy e3i-platform \
  --image gcr.io/<id-do-projeto-gcp>/e3i-platform:latest \
  --platform managed \
  --region us-east1 \
  --allow-unauthenticated \
  --port 3000 \
  --set-env-vars GEMINI_API_KEY="seu_segredo_gemini_aqui"
```
*Garante conformidade com o porto standard 3000 do gateway de rede externa.*
