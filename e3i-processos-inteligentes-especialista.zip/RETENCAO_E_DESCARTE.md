# Políticas de Retenção e Descarte Seguro de Ativos (E3I)

Para assegurar conformidade com legislações fiscais, ambientais e trabalhistas, o sistema **E3I** incorpora um módulo automatizado de cálculo de preservação biunívoca baseado nas classificações de documentos integrados à governança corporativa.

---

## 1. Prazos de Preservação e Retenção por Classe Documental

As regras de expiração do tempo de vida útil dos ativos de gestão de qualidade e processos operacionais são divididas em 4 diretrizes centrais:

| Tipo Documental | Prazo de Retenção | Descrição Regulamentar | Anonimização |
| :--- | :---: | :--- | :---: |
| **SOP / POP** | **5 Anos** | Procedimento Operacional Padrão de Engenharia de Fábrica e Chão de Processos. | **Sim** |
| **Manual Geral** | **10 Anos** | Manuais do Sistema de Gestão de Qualidade (SGQ) Geral de Auditoria ISO 9001. | **Não** |
| **Checklist** | **1 Ano** | Listas de verificação rápida de turnos e segurança imediata de maquinário. | **Sim** |
| **Formulário** | **2 Anos** | Planilhas e formulários coletados durante as etapas de Medição Lean Sigma. | **Sim** |

Ao exceder o prazo acima calculado a partir de `generatedAt`, o sistema marca o documento visualmente como "Qualificado para Expurgo".

---

## 2. Abstração de Bloqueio Legal (Legal Hold)

O **Bloqueio Legal (Legal Hold)** constitui uma premissa prioritária de segurança que suspende sumariamente qualquer direito ou prazo de expiração ou exclusão:

* Quando ativado perante um documento crítico, o Bloqueio Legal congela o ativo.
* **Bloqueio Inviolável**: Mesmo que o arquivo tenha superado os 10 anos de retenção padrão ou o usuário logado possua perfil máximo de administrador, qualquer requisição de descarte é abortada com o erro: `FALHA NO REQUISITO DE RETENÇÃO: Bloqueio Legal (Legal Hold) ativo impede o descarte do documento fiscal ou operacional`.
* O descarte só é desbloqueado se um auditor habilitado desligar formalmente o switch de Legal Hold nas preferências internas do Portal BPM Document Suite.

---

## 3. Mecanismo de Expurgo Seguro e Anonimização (LGPD)

Quando um documento elegível para descarte passa pelo fluxo de eliminação autorizada:

1. **Validação de Permissão**: O sistema exige que o solicitante porte as chaves de direitos `DOCUMENT_DISPOSAL`, `MASTER_BLACK_BELT` ou `ADMIN`. Caso contrário, a exclusão é abortada de imediato com um log correspondente na cadeia de custódia.
2. **Flag de Soft-Delete**: O procedimento padrão é removido dos painéis de visualização ordinários, marcando o atributo `isDeleted` como `true` no banco de dados. No entanto, o seu registro agregador é preservado permanentemente.
3. **Destruição de Dados Pessoais (LGPD)**: Para os tipos documentais configurados com obrigação de anonimização (como SOPs, Checklists e Formulários), todos os dados do autor original (nome legível, email gerador, telefone) são expurgados do objeto do documento e substituídos por strings genéricas neutras:
   * Autor $\to$ `"AUDITED_ANONYMIZED_USER"`
   * Email $\to$ `"ANONYMIZED_EMAIL"`
4. **Log de Exclusão**: É adicionada uma linha ao ledger imutável de custódia relatando o descarte, o auditor autorizador, endereço IP e data exata de destruição lógica dos dados.
