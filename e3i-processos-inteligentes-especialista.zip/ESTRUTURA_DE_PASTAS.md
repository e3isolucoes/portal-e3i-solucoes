# Estrutura de Pastas - E3I Processos Inteligentes

Este documento descreve a organização física e arquitetural do código-fonte do sistema **E3I Processos Inteligentes** após as melhorias da Fase 7 (Otimização e Centralização).

---

## 📂 Visão Geral da Nova Estrutura

Nossos módulos foram estruturados seguindo práticas limpas (Clean Architecture), separando as responsabilidades de infraestrutura global da plataforma, dos módulos de negócio especializados (DMAIC, Mapeador, FMEA, etc.) e das configurações e componentes comuns.

```
src/
├── app/
│   ├── router/          # Regras de roteamento e comutadores reativos de abas
│   ├── providers/       # Provedores Globais de Contexto (Contexto de Negócios)
│   ├── layouts/         # Templates de layout global e barras de ferramentas
│   └── guards/          # Guardiões de exibição de abas e assinaturas
├── modules/
│   ├── companies/       # Organizações, empresas reais e gerenciamento de CNPJ
│   ├── processes/       # Modelagem de postos, passos SMT e algoritmos de fila
│   ├── projects/        # Escopo, progresso ponderado, metas e charter
│   ├── dmaic/           # Auditoria Black Belt, entregáveis, trackers e blockers
│   └── reports/         # Geração de apresentações e exportadores estatísticos
├── shared/
│   ├── components/      # Coleção unificada de 26 componentes reaproveitáveis
│   ├── services/        # IA Co-Pilot (AiService.ts) e integrações
│   ├── types/           # Index central de tipagem e interfaces de domínio
│   ├── utils/           # Inicializadores estáticos, cálculos e RBAC central
│   └── design-system/   # Tokens estritos de cores, fontes, tabelas e botões
└── tests/               # Suítes de testes unitários, segurança e responsividade
```

---

## 📑 Detalhamento por Camada

### 1. `src/app/`
Gerencia a inicialização global, controle de sessão, roteamento do shell principal e distribuição de dados transacionais.
- **`providers/`**: Contém o `<BusinessContextProvider>` (`/src/contexts/BusinessContext.tsx`), que centraliza os switches de Empresa, Unidade e Projeto e propaga de forma reativa a todas as ferramentas.

### 2. `src/modules/`
Aloja a lógica funcional rica e especializada de cada segmento das metodologias Lean Six Sigma e Pesquisa Operacional.
- **`processes/`**: Scripts e modais para análise de gargalos (saturação de postos), cronoanálise estocástica (métodos Box-Muller) e Teoria de Filas de Allen-Cunneen ($G/G/1$).
- **`dmaic/`**: Painéis de controle de fases, fluxos de aprovação com bloqueios (Blocker Reasons), timelines de trilha de auditoria e lista de ações preventivas.

### 3. `src/shared/`
Contém recursos reutilizáveis e livres de estado de negócio acoplado direto, promovendo a máxima coesão eDRY (Don't Repeat Yourself).
- **`components/`**: Arquivo `/src/components/StandardComponents.tsx` unificando visualmente botões, modais, timelines, checklists, e inputs de alta legibilidade conforme as diretrizes de acessibilidade corporativa.
- **`types/`**: `/src/shared/types/index.ts` fornecendo tipagem consensual e protegida para as entidades de negócio.
- **`utils/`**: `/src/shared/utils/initialStates.ts` abrigando o dicionário corporativo multissetorial de postos de trabalho e presets industriais (aliviando a carga inicial de `src/App.tsx`).
- **`design-system/`**: `/src/shared/design-system/index.ts` mapeando os tokens de cores (#0F172A e #1E3A8A) para assegurar o alinhamento de visual nas 35+ visualizações.
