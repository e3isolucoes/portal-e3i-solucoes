# E3I Processos Inteligentes - PADRÕES E DIRETRIZES MOBILE

Para assegurar eficiência de operação no chão de fábrica (indústrias) ou em trânsito executivo (serviços e saúde), a ferramenta **E3I Processos Inteligentes** é totalmente adaptativa e otimizada para dispositivos com telas táteis reduzidas.

Este documento formaliza as práticas para manter a consistência de navegação em celulares, tablets e notebooks compactos.

---

## 1. Responsividade Fluida e Breakpoints de Layout

Usamos o conceito de design fluido integrado com classes adaptativas do Tailwind CSS. Nossos limites de redimensionamento de janela são:

*   **Celulares Pequenos/Médios (`xs`/`sm`)**: `< 640px` (Interface empilhada verticalmente de uma coluna).
*   **Tablets e Interfaces Compactas (`md`)**: `640px` a `1023px` (Abas em duas vias, grades bento-box em duas colunas).
*   **Desktops e Laptops Primários (`lg`/`xl`)**: `1024px` ou maior (Visão plena com painel duplo integrado e tabelas amplas).

### Práticas Obrigatórias de CSS Adaptativo

*   **Não use larguras fixas**: Evite classes como `w-[500px]`. Prefira estruturas como `w-full max-w-lg mx-auto` para permitir adaptabilidade e resiliência a redimensionamentos dinâmicos.
*   **Contenção do iFrame**: Como o sistema é carregado em ambiente sandbox de preview em iframe e telas incorporadas, todas as áreas Canvas de gráficos de controle estatístico observam o redimensionamento do container circundante através de monitores de redimensionamento (`ResizeObserver`).

---

## 2. Área de Toque Mínima (Touch Target Design)

Em interfaces móveis, cliques de mouse são substituídos pelo toque de dedos, que exigem áreas receptoras maiores:

*   **Tamanho Mínimo**: Todos os botões clicáveis, links de abas e seletores de tabela devem ter tamanho de contato de pelo menos **44px por 44px** (ou incluir preenchimento equivalente). No nosso Design System, definimos a classe `ACCESSIBILITY.touchTarget` para este fito.
*   **Espaço Interceptor**: Deixe pelo menos **8px** de margem física desativada entre botões vizinhos, evitando que o toque acidental execute uma rota indesejada pelo usuário.

---

## 3. Menu Adaptativo de Gaveta (Mobile Drawer Menu)

Para evitar poluição do topo principal de controle permanente, as opções do menu corporativo e o alternador de cargo/permissão são transferidos para uma gaveta deslizante (`Drawer` lateral) ativada por um botão Hamburger visível apenas abaixo de telas de `1024px`.

*   **Vantagem**: Reduz a carga mental inicial em telas pequenas de 360px de largura, liberando o espaço de foco do usuário diretamente para a lista do checklist funcional de melhoria sob o DMAIC.
*   **Controle de Estado**: Gerenciado de forma síncrona pelo estado `isMobileMenuOpen` no arquivo principal da aplicação.

---

## 4. Transformação Dinâmica de Dados e Tabelas

Tabelas tradicionais de dezenas de colunas representam um dos maiores gargalos de usabilidade em celulares. Na E3I:

*   **Estratatégia de Rolagem Controlada**: Envolvemos qualquer tag `<table>` dentro de uma div com classe `overflow-x-auto w-full max-w-full block`. Isso evita que a lateral direita do aplicativo quebre e estoure a margem física da janela.
*   **Estratégia de Empilhamento Card-Block**: Para telas de altíssima densidade operacional em smartphones, as colunas secundárias de tabelas são ocultas por meio utilitários de exibição responsiva (ex: `hidden md:table-cell`). As colunas ocultas podem ser expandidas ou representadas em formato de cartões curtos empilhados.
