# Plano Real de Reestruturação e Evolução de Produto (E3I Suite)

**Versão:** 1.0  
**Autor:** Especialista em Arquitetura de Software & UX  
**Status:** Concluído (Fase 1 - Descobrimento e Análise)

Este roteiro estratégico apresenta as fases incrementais propostas para a evolução da plataforma **E3I Processos Inteligentes**, focando em desmembrar débitos técnicos e otimizar a experiência corporativa do cliente B2B nas fases seguintes.

---

## 1. Abordagem Incremental por Fases (Phase-by-Phase Roadmap)

Dada a alta densidade funcional do sistema atual e em obediência às diretrizes de controle de regressão, propomos um roteiro incremental estruturado em três fases adicionais de trabalho técnico:

```text
       ┌────────────────────────────────────────────────────────┐
       │   FASE 1: DESCOBRIMENTO E ANÁLISE COMPLETA (ATUAL)     │
       └───────────────────────────┬────────────────────────────┘
                                   │
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │   FASE 2: REESTRUTURAÇÃO DE ARQUITETURA E ESTADO       │ (Global Store, Isolamento de App.tsx,
       └───────────────────────────┬────────────────────────────┘  Modularização Fina, Single-Responsibility)
                                   │
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │   FASE 3: UX, ACESSIBILIDADE E RESPONSIVIDADE (MOBILE) │ (Empty States, Contraste de Cores,
       └───────────────────────────┬────────────────────────────┘  Melhorias WCAG/ARIA, Redesign Dinâmico)
                                   │
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │   FASE 4: GOVERNANÇA DE INTEGRAÇÃO DE IA E PERSISTÊNCIA│ (Cache de Chamadas Gemini, Robustez Offline,
       └────────────────────────────────────────────────────────┘  Limpeza de Dados em Cascata, CEP Autônomo)
```

### Fase 2: Reestruturação de Arquitetura e Engenharia de Estado (Foco Técnico)
*   **Separar App.tsx (Modularização de Estado):**  
    Extrair a lógica monolítica do arquivo raiz `App.tsx` para um Store centralizado de estado global utilizando **Zustand** ou a API nativa **React Context**. Isso reduzirá o tamanho do arquivo central de 8.400 linhas para menos de 600 linhas, desacoplando visualizadores de rotas das regras rígidas do motor estatístico.
*   **Isolamento de Componentes de Rotas:**  
    Garantir que cada visual de aba principal (ex: `DiagnosticWizard`, `DmaicWizard` e `SigmaTrendDashboard`) possua controle de formulários autônomo, evitando re-renders globais no canvas SVG a cada clique ou digitação.
*   **Encapsulamento de APIs:**  
    Consolidar as requisições AJAX e tratamento de exceções do Gemini em módulos de serviços isolados, aplicando tratamento unificado de payloads e interceptores contra falhas na rede.

### Fase 3: Experiência do Usuário (UX), Acessibilidade e Mobilidade (Foco Produto)
*   **Design de Estados Vazios (Empty States):**  
    Introduzir ilustrações vetoriais informativas em projetos zerados com dicas passo a passo (ex: "Sua jornada LSS começa aqui! Clique à esquerda e adicione o primeiro posto de atividade para ativar as medições estatísticas").
*   **WCAG 2.1 Compliance / Acessibilidade Estrita:**  
    Garantir contraste de cor mínimo de 4.5:1 em todos os badges e botões dourados, vincular tags `aria-label` às formas geométricas do SVG Flowchart e habilitar navegação integral do menu por teclado (`Tab`, `Esc` e `Enter`).
*   **Adaptação ao Mobile (Responsividade Avançada):**  
    Implementar contêineres de scroll lateral suave no quadro Kanban e tabelas CEP para visualização segura em smartphone, além de recolher o menu lateral em um menu hambúrguer responsivo.

### Fase 4: Otimização Geral e Integração Inteligente com IA (Foco Engenharia)
*   **Cache Semântico Local para Gemini:**  
    Implementar armazenamento em memória ou Firestore cache de sugestões já respondidas para o mesmo padrão e porte de indústria, evitando chamadas desnecessárias que causem custos extras ou estourem os limites Rate Limit da API.
*   **Modo de Sincronização Desconectada (Offline First):**  
    Ativar cache híbrido no Firebase Client (`enableIndexedDbPersistence`). Caso a rede caia no chão de fábrica, a plataforma entra no modo de persistência local silenciosamente, enviando as modificações em lote ao restaurar a conexão.
*   **Garantia de Integridade de Dados em Cascata:**  
    Garantir que a exclusão de empresas ou sub-projetos acione scripts que limpem dados órfãos, mitigando quebras ou travamentos de ponteiros nulos em outros terminais logados.

---

## 2. Matriz de Priorização (Prioritization Matrix)

A tabela abaixo prioriza os desvios técnicos, de UX e arquitetura mapeados, organizando o plano de ataque e as dependências operacionais para as fases seguintes.

| Problema Identificado | Gravidade | Impacto | Complexidade | Dependências | Fase Recomendada | Solução Proposta |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **Monolito de 8.400+ linhas em `App.tsx`** | **Alta** | **Alto** | **Alta** | Nenhuma | **Fase 2** | Migrar estados de roteamento e modelagem LSS para um Global Store (Zustand ou React Context) descentralizado. |
| **Falta de Estados Vazios em Projetos Zerados** | **Média** | **Alto** | **Baixa** | Nenhuma | **Fase 3** | Incorporar ilustrações nativas nas telas de gráficos com botões de ação onboarding guiados. |
| **Quebra de Responsividade no Kanban & CEP** | **Média** | **Alto** | **Média** | Organização HTML | **Fase 3** | Implementar contêineres móveis com viewport adaptável móvel e rotas com menu hambúrguer compacto. |
| **Divisão por Zero no motor Allen-Cunneen (NaN)**| **Alta** | **Médio** | **Baixa** | Lógica funcional | **Fase 2** | Incluir validações lógicas nas funções de `utils.ts` que barram ou tratam `resourceCount <= 0` e saturação `rho >= 0.999`. |
| **Estouro de Chamadas Gemini (Rate Limit)** | **Média** | **Alto** | **Média** | Integração da API | **Fase 4** | Adicionar barreira de controle no backend com cache local persistido de prompts respondidos anteriormente. |
| **Falta de Contraste e Tags ARIA (WCAG)** | **Média** | **Médio** | **Média** | Elementos visuais | **Fase 3** | Ajustar cores de badges, adicionar classes `contrast-normal` e tags ARIA no canvas gráfico dinâmico. |
| **Persistência de Projeto Órfão ao Deletar** | **Alta** | **Alto** | **Média** | `CompanyProjectRepository` | **Fase 4** | Implementar gatilho em `saveProjects` que reinicia o status e apaga variáveis globais órfãs se o projeto ativo sumir. |
| **Ausência de Fallback Offline no Chão de Fábrica**| **Média** | **Médio** | **Média** | `firebase.ts` | **Fase 4** | Ativar escrita em cache do IndexedDB no client e habilitar chaveadores silenciosos para o Sandbox Mode. |
| **Flashes de UI sem Empresa no Registro** | **Média** | **Alto** | **Baixa** | `AuthCover` | **Fase 3** | Forçar o Onboarding de Setup Inicial impedindo renderização do painel LSS sem ID válido de empresa associada. |
