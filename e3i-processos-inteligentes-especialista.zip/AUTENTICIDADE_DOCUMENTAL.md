# Plano de Autenticidade e Integridade Documental - E3I

O sistema **E3I** estabelece um método rigoroso baseado em criptografia simétrica e determinística para certificar a autencididade de todo e qualquer documento operacional (SOP, Checklists, Manuais, Formulários) gerado a partir do mapeamento Kanban ou do Hub de Processos.

Este plano está alinhado com as diretrizes de governança da **Fase 12** do modelo regulatório corporativo.

---

## 1. Identificação Documental Unívoca

Cada documento publicado no sistema recebe obrigatoriamente um cabeçalho imutável com 12 metadados estruturais de identificação:

| Metadado | Descrição |
| :--- | :--- |
| **Identificador Único (`id`)** | Chave alfanumérica única baseada no hash do momento de criação. |
| **Empresa (`companyId`)** | Razão social vinculada ao tenant operacional. |
| **Projeto (`projectId`)** | Projeto de Melhoria DMAIC ativo na organização. |
| **Processo (`processId`)** | ID do fluxo ou diagrama mapeado. |
| **Versão (`version`)** | Número incremental indicando revisões válidas. |
| **Autor (`author`)** | Nome completo do operador responsável pelo processo. |
| **Data de Geração (`generatedAt`)** | Registro cronológico preciso em formato ISO 8601. |
| **Data de Aprovação (`approvedAt`)** | Registro cronológico da anuência formal do comitê. |
| **Classificação (`classification`)** | Nivelamento de acesso: *Público*, *Uso Interno*, *Confidencial* ou *Restrito*. |
| **Política de Retenção (`retentionPolicy`)** | Definição do plano de conservação. |
| **Hash de Integridade (`hash`)** | Assinatura e comprovação binária de dados sob SHA-256. |
| **Status (`status`)** | Estado no ciclo de vida: *Rascunho*, *Em Validação*, *Aprovado*, *Revogado* ou *Arquivado*. |

---

## 2. Motor de Cálculo de Hash de Integridade (SHA-256)

O hash de integridade desempenha a função de garantir que o conteúdo não sofreu quaisquer modificações desde sua gravação inicial ou geração de versão estável.

O motor matemático concatena de forma determinística os metadados principais e o conteúdo passo a passo sob delimitadores unívocos (`::|::`), convertendo subsequentemente a representação em bytes finais para um hash hexadecimal criptográfico de 256 bits através de um algoritmo **SHA-256** isolado puro:

$$\text{Bytes Serializados} = \text{id} \mathbin{\Vert} \text{companyId} \mathbin{\Vert} \text{projectId} \mathbin{\Vert} \text{processId} \mathbin{\Vert} \text{title} \mathbin{\Vert} \text{objective} \mathbin{\Vert} \text{scope} \mathbin{\Vert} \text{content} \mathbin{\Vert} \text{version} \mathbin{\Vert} \text{classification} \mathbin{\Vert} \text{author} \mathbin{\Vert} \text{generatedAt}$$

$$\text{Hash} = \operatorname{SHA-256}(\text{Bytes Serializados})$$

### Regra de Recalque e Mutabilidade
* **Não recalcule sem criar nova versão**: É uma diretriz proibitiva recalcular o hash de um documento existente mantendo a versão antiga. Se qualquer alteração ocorrer no conteúdo das instruções operacionais, o hash deve ser recusado pelo portal de auditoria caso a versão ou a assinatura não tenham sido incrementados formalmente de forma digital.

---

## 3. Watermark Visual Complementar

Quando habilitado, o sistema projeta uma marca d'água visual em páginas físicas de visualização ou exportações contendo:
```text
[CÓPIA CONTROLADA / NÃO CONTROLADA] Empresa: <companyId> | Doc: <id> (V<version>) | Classif: <classification> | Gerado em: <date> por <author> | Hash SHA256: <shortHash>...
```

### ⚠️ Mandato contra Confiança Cega em Watermark
* **Não trate o watermark visual como prova suficiente de autenticidade**: Um watermark textual pode ser facilmente manipulado ao editar capturas de tela ou PDFs em nível visual de pixels. No E3I, a marca d'água é classificada meramente como uma ferramenta complementar de identificação. A validação jurídica requer obrigatoriamente a comprovação do arquivo hash e a verificação criptográfica do certificado KMS sob o HSM da empresa.
