# 🛡️ PENDÊNCIAS DE SEGURANÇA: Migração de Segredos para Backend Seguro

Este documento detalha as providências técnicas necessárias para migrar o gerenciamento de credenciais e tokens sensíveis (SMTP_PASS, TWILIO_AUTH_TOKEN) do ambiente do cliente para um repositório seguro no backend, em conformidade com as diretrizes de governança e segurança de dados da plataforma E3I.

---

## 🛑 Estado Atual & Mitigação Temporária
Atualmente, por questões de arquitetura cliente-servidor nativa em ambiente React de visualização, as senhas e chaves são manipuladas de forma segura:
* **Remoção de Persistência em WebStorage / LocalStorage**: Nenhuma senha secreta SMTP ou Token do Twilio é gravado de forma persistente no `localStorage` do navegador do usuário.
* **Validação de Formato e Validade Transitória**: Os formulários do Painel Administrativo verificam se os dados preenchidos correspondem ao formato esperado (ex: hostnames válidos, contas padrão do twilio Iniciando com `"AC"`, portas numéricas de correio), mantendo o segredo exclusivamente em memória (State React transitório) enquanto as interações de depuração ocorrem na tela.

---

## 🛠️ Plano Estruturado de Migração (Fase Back-End)

Para as próximas atualizações de conformidade corporativa em produção, execute as seguintes tarefas:

### 1. Provisionamento de Cofre de Chaves (Secret Manager)
* **Solução Recomendada**: Google Cloud Secret Manager (GCP) ou hash simétrico no banco persistente via KMS.
* **Ação**: Criar variáveis e referências exclusivas associadas à holding/ID da organização (`companyId`):
  * `SMTP_PASSWORD_SECRET`
  * `TWILIO_AUTH_TOKEN_SECRET`

### 2. Criação de Endpoints Proxy para Serviços Externos (API routes)
Modifique o arquivo backend (ex: `server.ts`) para incluir rotas autenticadas que realizem o encaminhamento seguro:
* **Ação**: Implementar rota `POST /api/companies/:companyId/smtp/test` no servidor Express.
  * O frontend apenas informa se o usuário deseja salvar uma nova senha.
  * O frontend envia a nova credencial exclusivamente via HTTPS sob payload encriptado para a rota.
  * O backend armazena a senha diretamente no Secret Manager associado ao tenant da empresa e apenas retorna `status: "configured"` (nunca expondo o segredo de volta na consulta GET).

### 3. Integração de Envio em Servidor Privado
* **Ação**: O componente `notificationService.ts` e afins não devem disparar requisições diretas nem computar chaves no lado do browser. Toda notificação deve ser enfileirada no banco de dados corporativo, onde um worker server-side consome as chaves da holding, processa e executa os envios seguros em containers isolados.
