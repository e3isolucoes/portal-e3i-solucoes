# E3I Processos Inteligentes - Fluxo de Aprovação de Entregáveis

O ciclo de vida de um entregável na plataforma E3I segue uma trilha regulada de status operacionais para garantir a auditoria contínua de processos empresariais.

## Máquina de Estados do Entregável

```
       [Não Iniciado]
             │
             ▼
       [Em Andamento] ◄───────┐
             │                │
             ▼                │ (Reajustar / Solicitar Ajuste)
    [Aguardando Aprovação]     │
       /            \         │
      ▼              ▼        │
  [Aprovado]     [Rejeitado] ─┘
```

Se houver uma dependência de terceiros, o entregável pode ser marcado como **[Bloqueado]** a qualquer momento, exigindo registro de justificativa.

## Ações Disponíveis ao Usuário

1. **Preencher Entregável / Salvar Rascunho:**
   - Permite detalhar o escopo, vincular responsáveis e agendar prazos finais (`dueDate`).
   - Move o status para `"in_progress"`.

2. **Anexar Evidências:**
   - Link direto de arquivos comprobatórios. Atualiza a lista `evidenceIds`.

3. **Enviar para Aprovação:**
   - Modifica o status para `"waiting_approval"`, bloqueando novas edições comuns pelo executor.

4. **Aprovar:**
   - Disponível para perfis auditores ou gerentes. Atualiza o status para `"approved"`, preenchendo os tokens `approvedBy` e `approvedAt` com base no usuário logado.

5. **Rejeitar / Solicitar Ajustes:**
   - Define o status como `"rejected"`. O auditor é obrigado a inserir um comentário indicando as correções necessárias para reabertura do fluxo de trabalho.

6. **Registrar Comentários:**
   - Log permanente de discussões associado a cada entregável.
