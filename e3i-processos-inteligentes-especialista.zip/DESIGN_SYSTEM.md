# E3I Processos Inteligentes - DESIGN SYSTEM

Este documento consolida as diretrizes, padrões visuais, paleta de cores e especificações de tokens que regem as decisões estéticas e a arquitetura de interface (UI) da ferramenta **E3I Processos Inteligentes**.

---

## 1. Fundamentos Visuais

Nossa filosofia de design une a **precisão funcional do Lean Six Sigma (LSS)** com uma **identidade visual sóbria, corporativa e premium**. O objetivo do Design System é simplificar o entendimento para usuários novatos enquanto oferece recursos de densidade extrema para engenheiros e analistas especialistas.

### Paleta de Cores de Marca

Definimos quatro tons primários absolutos para a marca. Todos os contrastes de fundo e texto são otimizados conforme o padrão WCAG AA:

*   **Dark Blue/Slate (Escuro Principal)**: `#0F172A` (Slate 900)
    *   *Uso*: Header principal, rodapés, textos primários de alta ênfase, botões em modo escuro e fundos de alta hierarquia.
*   **Royal Blue (Acordo/Ação)**: `#1E3A8A` (Blue 900)
    *   *Uso*: Botões primários de ação, links principais, realce de foco, cabeçalhos de tabelas e estados ativos.
*   **Neutral Gray (Textos e Bordas)**: `#334155` (Slate 700)
    *   *Uso*: Textos secundários, bordas de cards secundários, divisórias, ícones inertes.
*   **Pure White (Fundo Principal)**: `#FFFFFF`
    *   *Uso*: Fundo de cartões de informações reais, campos de inserção de dados, fundos de corpo de aplicação.
*   **Gold E3I (Destaque Premium)**: `#C49746` (Dourado de Realce)
    *   *Uso*: Badges de contexto de aplicação, realces estéticos sob contraste profundo escuro (`#0F172A`), ícones de advertência controlada.

### Cores Semânticas de Negócio

Alinhadas com controle de riscos empresariais e metas analíticas (SOX/DMAIC):

| Semântica | Cor Hex / Classe Tailwind | Significado no LSS |
| :--- | :--- | :--- |
| **Sucesso** | `text-emerald-700 bg-emerald-50` | Etapa sob controle, capabilidade ideal (>1.33) |
| **Atenção** | `text-amber-750 bg-amber-50` | Métrica limite, sob vigilância (Alerta SPC) |
| **Erro / Bloqueio** | `text-rose-600 bg-rose-50` | Processo instável, sem capabilidade, falha de validação |
| **Risco Extremo**| `text-red-900 bg-red-50` | Violação de UCL/LCL de controle de processo estatístico |
| **Informação / Neutro** | `text-slate-700 bg-slate-50` | Parâmetros de contexto operacional, metadados corporativos |

---

## 2. Tipografia

Privilegiamos a clareza e as variações geométricas que comunicam solidez técnica:

*   **Principal (Interface e Fluxos)**: `Inter`, sans-serif.
    *   *Uso*: Dados numéricos, botões, inputs, labels, textos explicativos e dashboards.
*   **Display (Títulos e Enfoque)**: `Space Grotesk` ou Fontes Serifadas em momentos pontuais.
    *   *Uso*: Logotipos, títulos de seções governamentais de topo, badges comemorativos e números grandes de KPI operacionais.
*   **Técnico (Código/Metadados/Mórmulas)**: `JetBrains Mono` ou `Fira Code`.
    *   *Uso*: Fórmulas estatísticas, tempos de ciclo em painéis analíticos, indicadores de log SOX e indicadores de controle de fluxo de fila.

---

## 3. Espaçamento e Margem

Adotamos uma matriz de ritmo de espaçamento flexível e sensível à densidade empresarial. Evitamos espaçamento idêntico sistemático para construir **ritmo visual**:

*   **Layout Externo**: `px-4 sm:px-6 md:px-12 py-5`
*   **Espaçamento entre Cartões**: `gap-4 lg:gap-6`
*   **Padding Interno de Cartão**: `p-4 hover:p-5 transition-all` (Padding dinâmico sutil)
*   **Área de Toque Mínima**: `min-h-[44px]` para interações, compatível com as diretrizes do iOS e Android.

---

## 4. Arquivos e Implementação de Referência

O código real de declaração dos tokens visuais do Design System está centralizado em:
*   `src/utils/designSystem.ts`

Isso permite que qualquer desenvolvedor reutilize classes pré-configuradas de `button`, `input`, `select`, `card`, garantindo consistência técnica em toda a plataforma.
