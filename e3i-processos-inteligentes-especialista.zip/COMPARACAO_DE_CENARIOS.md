# Métricas de Comparação de Cenários (As-Is vs. To-Be)

O módulo de comparação estocástica do E3I fornece análises lado a lado de alto nível conceitual de eficiência e redução de desperdícios Lean Sigma.

## Principais Métricas Comparativas

1. **Lead Time de Ciclo (Cycle Time)**:
   - Mede o tempo médio absoluto entre a admissão do primeiro token e o momento de sua saída pelo gateway terminal nas execuções.

2. **Custo Unitário Consolidade (Average Cost per Transaction)**:
   - Atribui o custo baseado no tempo líquido de locação de recursos (recursos disponíveis de pool) e custos setup predefinidos calculados em R$/minuto.

3. **WIP Teórico por Lei de Little (Little's Law)**:
   - Calcula o estoque em processo teórico médio da linha de fluxo baseando-se no produto direto entre taxa de vazão verificada e tempo médio de residência no sistema:
     $$\text{WIP} = \text{Taxa de Rendimento (Throughput)} \times \text{Cycle Time}$$

4. **Taxas de Gargalos e Saturação (Bottleneck Utilization)**:
   - Analisa e destaca as atividades com maiores tempos de fila física acumulada em decorrência da saturação de capacidade disponível do time asignado.

## Vinculação de Projetos DMAIC

A integração nativa permite salvar os comparativos simulados diretamente para a fase **IMPROVE (Melhoria)** de projetos de escopo Green/Black Belt cadastrados na empresa, estabelecendo indicadores tangíveis e previsões matemáticas robustas para apoiar ações de reengenharia corporativa de processos.
