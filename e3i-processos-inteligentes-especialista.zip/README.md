# 📊 Plataforma Avançada de Excelência Operacional (Lean Six Sigma & DMAIC)

Esta aplicação web full-stack de ponta combina as disciplinas de **Pesquisa Operacional (P.O.)**, **Estatística Avançada**, e a consagrada metodologia **Lean Six Sigma (LSS)** com um motor inteligente baseado na **API do Gemini**.

Desenvolvida com **React 19**, **Vite**, **Tailwind CSS**, **Node.js Express** e **Firebase/Firestore**, a plataforma permite mapear, simular por Monte Carlo, analisar preventivamente com FMEA/Ishikawa, e controlar estatisticamente fluxos de valor de diversos setores (Industrial, Serviços, Logística, Tecnologia, Saúde, etc.).

---

## 🚀 Funcionalidades Principais

1. **Mapeamento de Processos Dinâmico**: Configuração cirúrgica de etapas, tempos de ciclo, tempos de setup, desvio padrão (variabilidade), taxa de rendimento (*yield*) e servidores (*resourceCount*).
2. **Simulação Estocástica de Monte Carlo**: Executa simulações científicas de fluxos operacionais por dias consecutivos, aproximando a variabilidade através da transformada *Box-Muller* e modelagem de filas *Allen-Cunneen G/G/c*.
3. **Módulo de Pesquisa Operacional**: Resolução programada de otimização de mix de produtos por Programação Linear (Simplex), Teoria das Filas e Teoria das Restrições (TOC).
4. **Análises de Qualidade (FMEA & Ishikawa)**: Registro interativo de Modos de Falha e Efeitos (com RPN automático) e diagrama de Causa-Efeito (Espinha de Peixe).
5. **Gargalos e Saturações**: Motor matemático que prevê filas infinitas (Utilização $\ge 100\%$) e sugere o balanceamento ótimo de postos.
6. **WIP Kanban Integrado**: Visualização real baseada na Lei de Little para controle do inventário em processo.

---

## 🛡️ A Fase "Control" (Controle) no DMAIC & CEP

O grande trunfo de sustentabilidade de projetos Lean Six Sigma está na etapa de **Contenção e Controle**. Nossa plataforma implementa esta etapa de forma ativa através de:

* **Cartas de Controle Shewhart (CEP/SPC)**:
  * Cálculo dinâmico ou estático de **LSC/UCL** (Limite Superior de Controle) e **LIC/LCL** (Limite Inferior de Controle) baseados nas zonas clássicas de **$3\sigma$ (Três Sigma)** de desvio padrão.
  * Monitoramento interativo do histórico de dispersão (últimas leituras de campo) e detecção de tendências espúrias.
* **Detecção Automática de Causas Especiais (Regras de Nelson)**:
  * Sinalização preventiva de violações quando um ponto excede os limites em tempo real ou se houver tendências (e.g., 9 pontos consecutivos no mesmo lado da linha média).
* **Matriz de Plano de Controle (Control Plan)**:
  * Associação de alarmes sonoros/visuais para cada métrica CEP de processo.
  * Especificação de "Planos de Reação" formais e mecânicos (ex: Pokayokes de dupla checagem) evitando negligência operacional.
* **Auto-Calibração de Limites por Gargalo**:
  * Botão de calibração eletrônica instantânea que reavalia a flutuação do gargalo atual e realinha seus alarmes estatísticos.

---

## 🛠️ Instalação e Execução

### Pré-requisitos
* Node.js (v18 ou superior)
* npm

### Configurando Variáveis de Ambiente
Crie um arquivo `.env` na raiz do projeto (copiado a partir do preenchimento do `.env.example` completo disponibilizado):

```bash
cp .env.example .env
```

Garanta o preenchimento de:
1. `GEMINI_API_KEY`: Para reativar o consultor de excelência operacional com IA.
2. Credenciais de API do Firebase (se desejar sincronizar banco de dados persistente em Nuvem).

---

## 📖 Instruções de Scripts (package.json)

* **Iniciar Ambiente de Desenvolvimento**:
  ```bash
  npm run dev
  ```
  O servidor Express e a renderização Vite SPA iniciarão em paralelo na porta `3000`.

* **Limpar Builds Anteriores**:
  ```bash
  npm run clean
  ```

* **Build Limpa de Produção**:
  Compila o pacote client-side otimizado e empacota o backend Node/Typescript em CommonJS nativo (`dist/server.cjs`):
  ```bash
  npm run build
  ```

* **Testes Automatizados (Vitest)**:
  Executa a suíte de testes unitários rápidos e determinísticos da engine de cálculos:
  ```bash
  npm run test
  ```

---

## 🧪 Estrutura de Testes Unitários

Nossos testes em `/src/utils.test.ts` cobrem toda a camada estatística do motor utilizando **Vitest**:
1. **Probit API**: Precisão na aproximação polinomial de Wichura para conversão de Rendimento Total para Nível Sigma.
2. **Transformada Box-Muller**: Geração de variabilidade normal realística sem gerar tempos negativos.
3. **Simuladores Estocásticos**: Saneamento de acúmulo de WIP, lead time de Little, e relatórios diários de simulação em 20 dias.

---

*Desenvolvido sob rígidas normas de Arquitetura de Software e Excelência de Design.*
