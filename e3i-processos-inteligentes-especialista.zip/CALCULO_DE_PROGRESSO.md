# E3I Processos Inteligentes - Cálculo de Progresso DMAIC

O cálculo de progresso geral de um projeto DMAIC na E3I obedece a um critério ponderado avançado.

## Resumo das Fórmulas de Progresso

Cada uma das 5 fases DMAIC (`D`, `M`, `A`, `I`, `C`) contribui igualmente com **20%** sobre a nota final do projeto.

O progresso de uma única fase $P_{fase}$ é a soma ponderada dos status dos entregáveis pertencentes àquela fase, distribuídos de acordo com seus respectivos pesos individuais $W_i$:

$$P_{fase} = \frac{\sum_{i=1}^{n} (W_i \times S_i)}{\sum_{i=1}^{n} W_i}$$

Onde $S_i$ representa o multiplicador de progresso associado ao status do entregável $i$:

| Status do Entregável | Multiplicador de Progresso $S_i$ |
| :--- | :--- |
| **Aprovada** (`approved`) | $1.0$ ($100\%$) |
| **Aguardando aprovação** (`waiting_approval`) | $0.7$ ($70\%$) |
| **Em andamento** (`in_progress`) | $0.3$ ($30\%$) |
| **Bloqueada** (`blocked`) | $0.1$ ($10\%$) |
| **Não iniciada** (`not_started`) | $0.0$ ($0\%$) |
| **Rejeitada** (`rejected`) | $0.0$ ($0\%$) |

## Progresso Geral do Projeto ($P_{geral}$)

Obtido pela média simples dos progressos de cada uma das 5 fases:

$$P_{geral} = \sum_{fase=1}^{5} \frac{P_{fase}}{5}$$

### Regras Complementares:
- Bloqueadores agem reduzindo o entregável ao multiplicador mínimo ($10\%$) sem invalidar o cálculo matemático da fase.
- Visualizar uma etapa ou entregável não altera o progresso do projeto ou de suas metas de auditoria.
