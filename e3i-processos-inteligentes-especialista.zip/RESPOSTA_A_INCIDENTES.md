# Guia de Resposta a Incidentes - E3I Processos Inteligentes

Este guia estabelece os planos de contingência contra ameaças digitais projetados para a ferramenta E3I sob conformidade corporativa **Fase 9**.

## Eventos e Gatilhos de Alerta

Os seguintes tipos de eventos ativam planos imediatos de mitigação:

1. **Tentativas Sucedidas/Falhas de Descriptografia (`security_alert`)**
   - *Gatilho*: Erros de checksum SHA256 ou falha matemática na descriptografia via chave de versão KDK.
   - *Contingência*: Suspensão preventiva da exportação de dados até que um Security Admin LSS valide o estado da chave.

2. **Deteção de Malware pelo ClamAV (`malware_alert`)**
   - *Gatilho*: Upload de arquivos infectados ou assinaturas conhecidas (ex: EICAR).
   - *Contingência*: Envio imediato do arquivo para a área física de quarentena isolada. Descarte instantâneo do payload temporário da memória ram e notificação ao canal de segurança.

3. **Bloqueios de Contas por MFA (`blockout`)**
   - *Gatilho*: 5 acessos MFA rejeitados seguidos.
   - *Contingência*: Enquadramento do IP em limite temporário e restrição à geração de novas requisições.

## Procedimento de Resolução (Passo-a-Passo)

- **Triagem**: O auditor avalia os registros através da **Trilha de Auditoria Segura do Admin Panel**.
- **Rotação de Chaves**: Caso suspeite de vazamento físico ou lógico, clique em `Rotacionar Chave KMS` para inutilizar imediatamente novas gravações sob a KDK sob suspeita.
- **Exportação de Evidência**: Baixe o relatório completo de logs corporativos em `.json` clicando em `Exportar Trilha de Auditoria (JSON)` para preservação forense e encaminhamento jurídico.
