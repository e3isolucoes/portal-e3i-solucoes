# E3I Processos Inteligentes - Regras de Evolução DMAIC

Este documento descreve as regras de transição de fase dentro do ciclo DMAIC (Definir, Medir, Analisar, Melhorar, Controlar) na plataforma E3I.

## Regras de Conclusão de Fase
Uma fase do projeto DMAIC só pode ser considerada **Concluída** quando todos os critérios abaixo forem plenamente atendidos:

1. **Entregáveis Obrigatórios Aprovados:**
   - Cada fase possui entregáveis definidos como `required: true`.
   - Todos esses entregáveis devem possuir o status `"approved"`.

2. **Evidências Mínimas Anexadas:**
   - Todo entregável obrigatório deve possuir ao menos 1 (uma) evidência associada no campo `evidenceIds`.
   - Documentos como PDFs de fluxogramas, planilhas estatísticas e planos de simulação servem como prova da atividade exercida.

3. **Aprovação Formal Identificada:**
   - Dados de `approvedBy` (qual usuário aprovou) e `approvedAt` (data exata do evento) precisam estar devidamente preenchidos.

4. **Ausência de Bloqueios (Blockers):**
   - Nenhum entregável da fase analisada pode estar no status `"blocked"`.
   - Se houver impedimentos listados, a fase permanece travada até que o problema seja resolvido e desmarcado.

5. **Campos Obrigatórios Preenchidos:**
   - Todos os detalhes informados no entregável (Responsável, Prazo de Entrega, Nome) devem estar presentes.

## Transição Automatizada
- A barra de progresso da fase atual reflete diretamente a conclusão.
- Quando todas as regras de uma fase são cumpridas, ela é marcada como **Concluída**.
- O sistema emite eventos de histórico registrando a alteração estrutural interna.
