# 📝 Manual de Auditoria e Logs de Conformidade — E3I Processos Inteligentes

Este manual descreve a mecânica técnica, estrutura e governança para a Trilha de Auditoria integrada no núcleo da plataforma E3I Processos Inteligentes.

---

## 🏗️ Estrutura Técnica das Trilhas (`AuditEvent`)

Cada ação crítica de negócios ou de segurança executada por qualquer colaborador gera um registro estruturado na assinatura da interface `AuditEvent` (`/src/utils/auditLogger.ts`):

```typescript
export interface AuditEvent {
  id: string;               // ID único codificado do registro
  organizationId: string;   // Vínculo fiduciário org
  companyId: string;        // Empresa ativa
  projectId?: string;       // Projeto associado
  userId: string;           // E-mail ou UUID do operador
  userEmail: string;        // E-mail do executor
  userName: string;         // Nome completo do operador
  action: string;           // Descrição exata do fato técnico
  entityType: string;       // Tipo da Entidade ("deliverable", "project", etc.)
  entityId: string;         // Chave primária da entidade modificada
  previousValue?: any;      // Estado anterior (para estorno e conferência)
  newValue?: any;           // Novo estado gravado
  createdAt: string;        // Data UTC de registro
}
```

---

## 🔄 Fluxo de Escrita e Segurança Append-Only (Bloqueio à Nuvem)

Para blindar os logs contra adulterações por usuários mal-intencionados, a plataforma estabelece uma rotina sincronizada de persistência:

### 1. Trilha Local Rápida (Memória / Cache local)
O evento de auditoria é anexado de forma instantânea em formato estruturado na pilha local leve (`clientAuditTrail` com limite de 500 registros para evitar travamento de memória). Isto disponibiliza feedbacks visuais e filtros de monitoramento inmediatos no painel corporativo do usuário.

### 2. Bloqueio Assíncrono no Firestore (Nuvem `/access_logs`)
Caso o usuário esteja devidamente autenticado e fora do modo de simulação Sandbox local, a engine despacha o log imediatamente para o Firestore escrevendo na coleção `/access_logs`.
* **Regras de Segurança Rígidas (Firestore rules)**: O arquivo de regras `firestore.rules` possui uma diretiva restrita para a coleção de auditoria. Ela autoriza **apenas o privilégio `create`** caso o payload corresponda exatamente ao `uid` autenticado. Qualquer alteração (`update`) ou exclusão (`delete`) e até mesmo varreduras de leitura (`list`) do cliente são **terminantemente bloqueadas**.
* Isso significa que o log é gravado em formato **Append-Only** (Somente Escrita), operando como uma "caixa preta" inviolável de vistorias técnicas regulatórias.

---

## 🎯 Ações e Modificações Rastreadas de Forma Obrigatória

O sistema grava registros com assinatura de IP virtual para cada um dos seguintes fatos:

1. **Criação / Cadastro**: Novas etapas de ciclo ou projetos DMAIC.
2. **Edição de Processo**: Alteração de metas ou Project Charter.
3. **Exclusão de Entidades**: Cancelamento ou purga de vistorias técnicas.
4. **Análise de Fase (Aprovação / Rejeição)**: Envio para Auditoria, Aprovação formal com data ou Rejeição formal sob justificativa expressa de inconformidade de entregável.
5. **Mudança de Responsabilidade**: Atribuição de novos engenheiros LSS a tarefas.
6. **Mudança de Status ou Prazos (Due Date)**: Modificações de marcos críticos de entrega.
7. **Inclusão de Evidência**: Upload seguro de documentos e relatórios analíticos.
8. **Exportação de Relatórios**: Baixar históricos de auditoria ou dados estatísticos da plataforma.
