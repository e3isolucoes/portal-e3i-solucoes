# 📥 Guia de Instalação — E3I Processos Inteligentes

Este guia instrui administradores e desenvolvedores sobre como configurar, instalar dependências e inicializar a plataforma E3I Processos Inteligentes em seu ecossistema local ou corporativo de forma segura.

---

## 📋 Pré-requisitos Técnicos

Antes de dar início à instalação do projeto, garanta que sua estação ou infraestrutura possua os seguintes componentes previamente instalados:

* **Node.js**: Versão **20.x ou superior** (LTS recomendada).
* **npm**: Versão **10.x ou superior** (geralmente empacotado junto com o Node.js).
* **Git**: Para controle de versão e downloads do repositório físico.

---

## 🛠️ Passo a Passo para Instalação

### Passo 1: Clonar ou Extrair o Repositório
Baixe ou copie os arquivos da aplicação para o seu diretório de desenvolvimento corporativo preferido:
```bash
git clone <url-do-repositorio-e3i>
cd e3i-processos-inteligentes
```

### Passo 2: Instalar as Dependências do Projeto
A plataforma utiliza uma estrutura de pacotes robusta definida no arquivo `package.json`. Execute a instalação limpa de dependências utilizando:
```bash
npm install
```
*Isto criará o diretório `node_modules` com todas as bibliotecas necessárias para a execução do backend Express e do frontend Vite React (e.g. `@google/genai`, `firebase`, `vitest`, `recharts`, `motion`, etc.).*

### Passo 3: Configurar o Arquivo de Credenciais
Copie o arquivo `.env.example` para `.env` no diretório raiz do sistema:
```bash
cp .env.example .env
```
Preencha as chaves e segredos em conformidade com o **Guia de Configuração** (`GUIA_DE_CONFIGURACAO.md`).

---

## 🏁 Inicializando o Sistema

### Modo de Desenvolvimento (Frontend + Backend Concorrido)
Para iniciar a aplicação com recarga instantânea de arquivos e monitoramento duplo:
```bash
npm run dev
```
A aplicação será disponibilizada no canal:
* `http://localhost:3000`

---

## 🧪 Verificando a Integridade da Instalação

Para validar que o seu ambiente foi instalado com total consistência estatística e de compilação, execute a suíte de validação automatizada:

1. **Linting de Tipos (TypeScript)**:
   ```bash
   npm run lint
   ```
2. **Execução de Testes Unitários de Confiabilidade**:
   ```bash
   npm run test
   ```
   *Todos os testes devem constar como Verdes (Green).*

3. **Compilação de Produção Local**:
   ```bash
   npm run build
   ```
   *Garante que o bundle estático do cliente na pasta `dist` e a compilação do servidor `dist/server.cjs` estão livres de inconsistências.*
