# Technical Architecture — Processes Page Refactoring (Phase 15)

## Overview
This document covers the developer-focused technical details of the unified **ProcessesPage** component and layout integration.

---

## 1. Modular Architecture & Directory Map

We adhered strictly to modularity guidelines by splitting responsibilities across specific source files, avoiding code bloating:

1. **/src/components/ProcessesPage.tsx** (New File):
   - Handles localized page state, tabs, user preference persistent storage (local storage), modal forms, dynamic search filters, and layout orchestration.
   2. **/src/types.ts** (Existing):
   - Holds centralized business schema declarations (`ProcessStep`, `Sipoc`, `ProcessMetrics`, `Company`, `WorkspaceProject`).
3. **/src/utils.ts** (Existing):
   - Contains pure statistical and operational research calculations (`calculateProcessMetrics` for Little's Law WIP, Rolled Yield, DPMO, Sigma Level, Capacity, and Bottleneck detections).
4. **/src/components/VisualProcessMapper.tsx** (Existing):
   - Renders the interactive BPMN/layout flow step map.
5. **/src/components/BpmDocumentSuite.tsx** (Existing):
   - Renders the integrated documentation and standard operating procedures.
6. **/src/App.tsx** (Refactored):
   - Mounts the `ProcessesPage` inside the `"PROCESSES"` view frame. Conditional blocks were added to automatically bypass default headers, outer breadcrumbs, and LSS Wizards to present a single, uncluttered working surface.

---

## 2. Secure Access Control (Zero Passwords)

As mandated by strict corporate guidelines:
- We did **NOT** use hardcoded admin/black-belt override keys inside the frontend codebase.
- The `usabilityLocked` status is managed dynamically by checking the user's role/persona (`currentCargo`):
  - Overrides are granted only for users with authorized levels (`"Administrador"`, `"Admin"`, `"Black Belt"`, `"Gestor de Portfólio"`).
  - Unauthenticated prompts and the legacy helper reference to password `'1234'` were completely removed, preventing vulnerabilities.

---

## 3. Local Preference Persistence

To ensure persistent, user-friendly workspaces:
- Language,Term translations, and UX complexity settings are saved in localized browser storage.
- Selection states for `usabilityMode` (`"LAYPERSON"` vs. `"EXPERT"`) and `showGuidance` (`true` vs. `false`) utilize safe default initializers, falling back cleanly to `localStorage` values across browser reload sessions.
