# Serviço de Notificações Centralizado (Fase 13)

Este documento descreve a arquitetura do motor central de mensageria da plataforma e3i, projetado para evitar envios diretos a partir de componentes visuais, favorecendo processamento assíncrono em fila e controle de fluxo avançado.

## 1. Arquitetura da Fila de Mensagens

O ciclo de vida das mensagens segue um fluxo rígido de transição de status para garantir confiabilidade e rastreabilidade:

```
[Evento Gerado] ──> [Fila: Aguardando Envio] ──> [Sucesso] ──> [Enviado]
                        │
                        ├──> [Falha Temporária] ──> [Retry com Backoff]
                        │
                        └──> [Falha Crítica / Excedido] ──> [Dead-Letter Queue (DLQ)]
```

### Características Técnicas:
- **Idempotência**: Cada evento possui uma chave hash de correlação única em `correlationId`. O sistema evita duplicações acidentais em janelas operacionais.
- **Isolamento de holdings**: Mensagens geradas para uma empresa só podem trafegar pelo servidor SMTP e domínios da referida empresa.
- **Veto de preferências**: Respeita de forma estrita as configurações individuais de desativação de alertas (ex. `Tarefa criada`, `prazo próximo`) exceto se for evento de transação compulsória (ex. `Segurança`, `Assinatura de Documento`).

---

## 2. Estrutura do Ledger de Notificações

Cada registro rastreável de transmissão possui os seguintes metadados:

- **ID Único**: UUID incremental prefixado.
- **Canal Utilizado**: Email, Push ou Notificação Interna.
- **Estado**: `Aguardando envio`, `Enviando`, `Entregue`, `Falhou`, `Cancelada`.
- **Controle de Retries**: Número de tentativas atuais e limite máximo.
- **Histórico de Erros**: Trilha cronológica com o descritivo de cada resposta do SMTP.
