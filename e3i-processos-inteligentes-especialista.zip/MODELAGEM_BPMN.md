# Regras de Modelagem BPMN e Validação de Rotas (Fase 10)

O E3I executa uma análise preventiva e determinística na topologia antes de iniciar qualquer execução estocástica de Monte Carlo. Um modelo conceitual só é submetido à execução após ser certificado pelo módulo de compliance estrutural de conexões.

## Tipos de Gateways Suportados

1. **Gateway Exclusivo (XOR - Exclusive Split/Merge)**:
   - Direciona o token integralmente por um único caminho com base em pesos probabilísticos definidos.
   - **Regra de Validação**: A soma de todas as rotas de saída de um Gateway XOR deve atingir exatamente **100%** de probabilidade física. Valores divergentes ou negativos geram erros fatais de barômetro que travam o simulador.

2. **Gateway Paralelo (AND - Parallel Fork/Join)**:
   - Duplica o token, despachando sub-processos paralelos para todas as atividades anexadas à saída.
   - Implementa balanceamento e sincronismo de filas de forma automatizada.

3. **Gateway Inclusivo (OR)**:
   - Permite rotas dinâmicas concorrentes onde mais de uma alternativa de saída é disparada condicionalmente.

## Validação de Topologia e Grafo de Processo

O analisador de integridade verifica as seguintes inconsistências em tempo de edição:

- **Componentes Isolados (Orphan Nodes)**: Elementos que não possuem rotas direcionadas a eles (órfãos de entrada) ou que não possuem destino (órfão de saída).
- **Inexistência de Destino Terminal (Dead End Paths)**: Rotas que entram em nós incapazes de liberar tokens (como tarefas configuradas sem conexões subsequentes).
- **Ciclos Travantes (Infinite Absolute Loops)**: Trechos sem válvula de escape que forçam o aprisionamento de tokens fora das travas de loop por amostragem probabilística inadequada.
- **Soma Inválida XOR**: Gateways XOR que possuem somatórios de distribuição divergentes do espaço amostral unitário (100%).
