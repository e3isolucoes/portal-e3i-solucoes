# 📱 Arquitetura de Responsividade e Reflow — E3I Processos

Este documento detalha o comportamento adaptativo e as diretrizes de visualização responsiva aplicadas à tela de **Processos Inteligentes E3I**.

---

## 1. Grade de Dispositivos e Viewports Homologados

O painel de Processos de Negócio opera de forma estável sob as seguintes resoluções canônicas de mercado:

- **Desktop Extra-Wide / Desktop (`xl` - 1280px ou mais)**: Layout em formato bento-grid modular de alta densidade informativa, com barra lateral de governança reativa, gráficos Recharts estendidos e tabelas de fluxo paralelas.
- **Tablet (`md`/`lg` - 768px a 1024px)**: Empilhamento vertical controlado da coluna de parametrização estocástica para salvar largura de tela horizontal, mantendo a visualização principal do mapa BPMN fluida com controles de arrasto.
- **Mobile (`sm` - 320px a 640px)**: Reflow integral em fluxo vertical único. Barra lateral oculta sob menu sanduíche compacto acessível de 1-toque. 

---

## 2. Reflow das Abas e Componentes Críticos

As tabelas e painéis de dados possuem tratamento de fluido para evitar o surgimento de barras de rolagem globais indesejadas na aplicação:

1. **Grid de KPIs**: O container de indicadores utiliza classes fluidas (`grid grid-cols-2 lg:grid-cols-5 gap-4`). No celular, rearranja-se de forma inteligente em duas colunas confortáveis, permitindo leitura límpida.
2. **Abas Internas**: Configurado com rolagem horizontal implícita de aba única (`overflow-x-auto gap-1 whitespace-nowrap`), permitindo folhear as seções por toque ou arraste gestual nativo no celular sem destruir as dimensões da casca do layout.
3. **Mapeador BPMN Visual**: Equipado com limites flexíveis de palco utilizando `ResizeObserver` com fallbacks para evitar saltos ou crashes de renderização em redimensionamentos dinâmicos bruscos do navegador.

---

## 3. Prevenção de Transbordamento (Overflow) e Truncamento de Fontes

Para garantir a harmonia estética sob variabilidades extremas de nomes e dados reais informados pelo cliente:
- **Truncamento Seguro ($...$)**: Elementos contendo strings inseridas pelo usuário utilizam controladores CSS de contenção (`truncate`, `max-w-[200px]`, `line-clamp-2`), prevenindo que títulos longos de projetos quebrem ou fujam do cabeçalho.
- **Wrap de Dados**: Blocos de textos explicativos de auxílio usam `leading-relaxed` e `break-words` para empilhar conteúdo textual respeitando as divisões corretas das margens do contêiner.
- **Áreas de Toque**: Todos os botões críticos no tablet e mobile possuem área ativa mínima de toque recomendada de `44px` (`py-2 px-4` ou mais), mitigando cliques acidentais em postos ou tarefas concorrentes de fluxo.
