# Matriz de Menus e Perfis (RBAC) - E3I Processos Inteligentes

**Versão:** 2.0 (Fase 3 - Gestão de Acessibilidade & Governança B2B)  
**Status:** Implementado  

Este documento certifica a matriz de rastreabilidade de acessibilidade, delimitando quais visões empresariais são permitidas para cada perfil técnico ou de liderança (Cargo), salvaguardando a integridade regulatória e compliance do ecossistema E3I.

---

## 1. Atribuição de Cargos e Acessos

A plataforma utiliza o perfil de Cargo extraído do contexto seguro de sessão do usuário para habilitar os atalhos de controle correspondentes na Sidebar:

| Módulo de Rota / View | Analista Júnior | Black Belt | Admin (Master Black Belt / TI) |
| :--- | :---: | :---: | :---: |
| **Visão Executiva** | ✔️ | ✔️ | ✔️ |
| **Portfólio** | ✔️ | ✔️ | ✔️ |
| **Processos** | ✔️ | ✔️ | ✔️ |
| **Projetos de Melhoria** | ✔️ (Sem DMAIC avançado) | ✔️ | ✔️ |
| **Operação** | ✔️ | ✔️ | ✔️ |
| **Riscos e Controles** | ❌ (Visualização) | ✔️ | ✔️ |
| **Relatórios** | ✔️ | ✔️ | ✔️ |
| **Administração** | ❌ | ❌ | ✔️ |

---

## 2. Abas Internas de Projetos de Melhoria por Belt

Dentro da visualização corporativa de **Projetos de Melhoria (DMAIC)**, o sistema restringe o acesso cirurgicamente:

*   **Visão Geral & Evidências:** Acesso irrestrito a todos os operadores para cooperação saudável e inserção de arquivos.
*   **Definir & Medir:** Permitido para todos os Belts.
*   **Analisar & Controlar (SPC Gráficos):** Exige nível mínimo de certificação técnica de **Black Belt** ou privilégio de **Admin** para prevenir configurações de Shewhart indevidas por utilizadores não instruídos estatisticamente, além de evitar descalibração de desvios padrão agregados.
*   **Administração do Sistema:** Restrito exclusivamente ao Engenheiro Chefe de TI para provisionamento financeiro e ativação de quotas contratuais de simulação.
