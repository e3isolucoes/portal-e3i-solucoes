# 🧪 Plano de Testes e Homologação — E3I Processos Inteligentes

Este documento descreve as diretivas de testes automatizados, cobertura e homologação integrados no motor matemático e de segurança da plataforma E3I.

---

## 🛠️ Framework de Testes

A plataforma possui uma infraestrutura de testes modular construída sobre o **Vitest**, possibilitando tempos de resposta instantâneos e isolamento de dependências.

---

## 📂 Cobertura Automatizada de Suítes

O ecossistema é homologado de forma estrita através de 4 frentes de teste que contêm **23 Casos de Teste (100% de Aprovação Verde)**:

### 1. Camada de Estatística e Pesquisa Operacional (`/src/utils.test.ts`)
Validação dos modelos preditivos e cálculos DMAIC:
* **Conversor Probit Polinomial (Wichura)**: Homologação contra tabelas z clássicas para garantir que o Nível Sigma gerado condiz perfeitamente com o Rendimento acumulado (*Yield*).
* **Transformada Box-Muller**: Certificação estatística de que o gerador de ruído gaussiano adiciona variabilidade normal estocástica correta sem incitar tempos de ciclo negativos ou impossíveis.
* **Leis de Little e Acúmulos Estocásticos**: Teste de estresse que roda a simulação por 20 dias, atestando o acúmulo lógico de WIP no canal produtivo sob teoria clássica de filas.

### 2. Matriz de Segurança e RBAC (`/src/utils/permissionMatrix.test.ts`)
Validação de regras lógicas de acesso e delegações:
* **Menus por Perfil**: Conferência se cada Perfil possui visibilidade restrita correspondente à sua alçada (ex: Colaborador não enxerga administração, Auditor enxerga relatórios).
* **Permissões de Ação**: Certificação de que Executivo/Auditor podem aprovar entregáveis, mas apenas Administradores ou Líderes podem excluir etapas.
* **Cobertura de Ausência (Delegações Temporárias)**: Teste lógico de atribuições de substituto, verificando se os privilégios cedidos em janelas cronológicas específicas funcionam apenas durante a validade da deleegeação.

### 3. Validador Corporativo de Uploads (`/src/utils/uploadValidator.test.ts`)
Garante proteção técnica rigorosa das evidências de auditoria contra injeções de malware ou invasões:
* **Filtro de Extensões Perigosas**: Impede o envio de vírus executáveis contendo extensões como `.exe` ou `.sh`.
* **Sanitização de Directory Traversal**: Reescreve caminhos de arquivos corrompidos que tentam escapar da sandbox. Trata caminhos ocultos de pontos convertendo-os em novos nomes e templates protegidos.
* **Limitação de Tamanho**: Garante que o sistema rejeita arquivos que superem o teto estabelecido de **15MB**.
* **Controles RBAC de Envio**: Analisa se funções com permissão restrita são proibidas de incluir itens no repositório corporativo.

### 4. Layout e Design Responsivo (`/src/utils/visualAndResponsive.test.ts`)
Conformidade do design system:
* Homologação de limites de containers responsivos, densidade e comportamentos em telas móveis visando touch-targets mínimos e fluidez estética.

---

## 🏁 Executando a Suíte de Testes Localmente

Com o ambiente dev instalado, execute a suíte em lote com o seguinte script do terminal:
```bash
npm run test
```
*Garante total rastreabilidade técnica e manutenção da qualidade operacional em atualizações de código.*

---

## 📋 Rotinas de Testes Manuais & Jornadas de Homologação

Para certificar o correto funcionamento prático e visual das ferramentas de Pesquisa Operacional, Gestão Six Sigma e Inteligência Artificial do ecossistema E3I, siga as jornadas detalhadas de validação abaixo.

### 🏢 JORNADA 1: Validação para Novas Organizações (Onboarding & Setup Inicial)
*Este roteiro simula a jornada de uma empresa que acabou de contratar a plataforma E3I e está configurando seu primeiro fluxo de processos do zero.*

1. **Acesso & Autenticação Inicial**:
   * Acesse a tela de login/autenticação e registre um novo usuário administrativo selecionando uma das organizações padrão ou criando uma nova identidade corporativa.
   * **Critério de Aceite**: O painel do usuário deve exibir as credenciais de segurança e o botão correspondente às permissões estabelecidas para aquela classe específica (ex: Administrador visualiza abas de governança completa).

2. **Ativação do Workspace & Setup da Empresa**:
   * Navegue até o módulo de configuração de workspace e crie/vincule seu novo projeto.
   * Use a ferramenta **Galeria de Presets Corporativos** para selecionar um modelo de processo inicial condizente com o ramo de atuação (ex: *Aceleração do Picking / Logística de E-commerce*).
   * **Critério de Aceite**: O sistema preenche instantaneamente o fluxo de trabalho com as etapas do preset selecionado carregando dados estocásticos realistas de taxa de chegada, tempo médio de atendimento, capacidades individuais de staff e níveis históricos de qualidade (*first pass yield*).

3. **Mapeamento do Project Charter (Fase DEFINE)**:
   * Vá para a aba **Project Charter** localizada na visão DMAIC da plataforma.
   * Preencha a meta do projeto (ex: *Reduzir tempo de ciclo de 28 para 18 minutos*), o escopo (O que está Dentro e Fora), as restrições e salve as configurações originais do projeto.
   * **Critério de Aceite**: Os dados do formulário devem persistir sem falhas e atualizar os badges de meta nos indicadores consolidados do topo do dashboard.

4. **Configuração Matricial do SIPOC (Fase MEASURE)**:
   * Acesse a tela da visão de macroprocesso **SIPOC** (*Suppliers, Inputs, Process, Outputs, Customers*).
   * Insira um fornecedor (ex: *Sistema WMS*), uma entrada (ex: *Lista de Pedidos*), a etapa correspondente e valide a saída descrita.
   * **Critério de Aceite**: A tabela de relacionamentos deve atualizar dinamicamente e salvar as interconexões que alimentam os relatórios de auditoria e governança lean.

5. **Validação do Fluxograma BPMN**:
   * Clique na aba **BPMN / Mapeador Visual de Processos**.
   * Insira uma nova etapa operacional, altere o tempo unitário de tratamento estocástico e reordene os blocos de fluxo de trabalho.
   * **Critério de Aceite**: A renderização visual das raias e conexões sincroniza imediatamente com os inputs alterados e o gráfico estrutural é atualizado sem erros na tela.

---

### ⚡ JORNADA 2: Validação para Empresas Ativas (Projeto Existente & Melhoria Lean)
*Este roteiro simula a jornada de um consultor de melhorias ou gestor de qualidade validando otimizações contínuas sobre um projeto que já conta com histórico consolidado e etapas ativas.*

1. **Inspeção de Saúde do Processo & Detecção de Gargalos**:
   * Abra a visão principal e verifique as métricas globais de eficiência corporativa: Nível Sigma Consolidado, Capacidade Geral do Sistema, Eficiência de Primeira Passagem (*Rolled FPY*) e Tempo Total de Trravessia (*WIP / Lead Time*).
   * Verifique qual etapa do fluxo de trabalho é destacada visualmente com alerta de congestionamento operacional pelo detector automático (ex: *Preparação de Embalagem* ou *Picking Manual*).
   * **Critério de Aceite**: O sistema atualiza os indicadores preditivos baseados em Teoria de Filas clássica ao modificar valores e deve expor de forma clara a etapa que atua como restrição física máxima do processo.

2. **Ativação do Novo Assistente Inteligente E3I Processos**:
   * Localize o botão flutuante **Assistente Inteligente E3I** ou execute as ações pelo atalho de menu lateral nas telas de simulação.
   * Abra o novo painel lateral integrado unificado (**E3I AI Hub**).
   * **Critério de Aceite**: O painel lateral desliza suavemente sobre a tela, exibindo o diagnóstico em tempo real do gargalo ativo e o nível Sigma atualizado sem que o usuário perca o foco do espaço de trabalho principal.

3. **Operação do Assistente via Otimizações de 1-Clique (Kaizen Rápidas)**:
   * Na aba **Copiloto Kaizen** do Assistente Inteligente, realize os seguintes testes sequenciais:
     * **Balanceamento Estocástico**: Clique no botão para equilibrar o gargalo. Certifique-se de que a ociosidade operacional foi redistribuída de forma balanceada.
     * **Redução de Variabilidade (SMED)**: Acione o mitigador de setup. Note que as variâncias e os desvios padrão estocásticos nas filas despencam para desafogar o Lead Time.
     * **Blindagem de Qualidade (Poka-Yoke)**: Acione este mitigador para ver a taxa de passagem direta aumentar e estabilizar o nível Sigma acumulado.
     * **Aumento de Equipe (+1 Operador)**: Verifique se a capacidade de vazão do posto que detém o gargalo foi expandida de forma paralela imediata.
   * **Critério de Aceite**: Cada ação deve disparar um feedback visual instantâneo (*Celebration Flash Banner*), registrar uma nova linha no painel interno de **Histórico de Otimização LSS** com filtros por data operacionais e recalcular todos os gráficos CEP e estatísticos imediatamente em tempo real.

4. **Operação e Diagnóstico Gerencial Gemini (Fase ANALYZE & IMPROVE)**:
   * No painel do Assistente E3I, alterne para a aba **Análise de IA (Gemini)**.
   * Clique em **Disparar Diagnóstico DMAIC**.
   * **Critério de Aceite**: A IA analisa as premissas ativas (etapas, desvios, metas) e retorna em poucos segundos um relatório estruturado contendo:
     * *Problem Statement* do fluxo operacional analisado;
     * Recomendação matemática exata de configuração de filas;
     * Sugestões preditivas e táticas de engenharia Lean Six Sigma;
     * Consolidação automática das fases **Measure** e **Analyze** na governança DMAIC.

5. **Controle Estatístico de Processo e Estabilidade (Fase CONTROL)**:
   * Vá para o módulo de **Sustentabilidade & Gráficos CEP (SPC)**.
   * Valide a geração dinâmica da **Carta de Controle por Variáveis de Shewhart** e dos limites estatísticos de controle: Limite Superior de Controle (LSC/UCL), Média Alvo do Processo e Limite Inferior de Controle (LIC/LCL).
   * **Critério de Aceite**: Os pontos de amostra diários devem ser plotados em tempo real de acordo com as flutuações e alertar caso ocorram violações clássicas das regras de instabilidade de Nelson (pontos fora dos limites calculados de $\pm 3\sigma$).

