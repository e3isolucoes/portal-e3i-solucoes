# Security Specification for OptimaFlow Firestore Database

## 1. Data Invariants
- **Authentication**: All read and write operations on personal workspace/user profiles require being signed in and being the owner of the document (`request.auth.uid == userId`).
- **Identity Integrity**: No user may read or write another user's profile or workspace data (Strict Ownership Isolation).
- **Format Integrity**: User profiles must have `email`, `fullName`, `role`, and `belt` with reasonable string sizes (e.g., email <= 200 chars, name <= 100 chars, role <= 100 chars).
- **Immutability of History**: `createdAt` field is immutable and must equal `request.time` upon creation.
- **Timestamp Integrity**: `updatedAt` must be set to `request.time` on every write/update.
- **Workspace State Typing**: If `workspaceData` is present, it must contain typed objects (`companies` list, `projects` list, `projectDataStore` map, `activeCompanyId` string, `activeProjectId` string, `updatedAt` string).
- **No Global Leakage**: No collection, subcollection, or document path outside `/users/{userId}` is readable or writable.

---

## 2. The "Dirty Dozen" Payloads
Here are 12 specific payloads or operations designed to target vulnerabilities, which the rules will successfully block (returning `PERMISSION_DENIED`):

1. **Spoofed Ownership on Create**: Creating another user's profile (`users/victim_uid`) with the attacker's authentication.
2. **Missing Required Fields**: Creating user profile with a missing required key (e.g., missing `belt`).
3. **Ghost Fields Injection**: Injecting a hidden field like `isAdmin: true` into the user document.
4. **Invalid Enum Value**: Setting a belt level that does not exist (e.g., `Rainbow Belt`).
5. **Too Long String Attack**: Injecting a 1MB string into the `fullName` or `role` to inflate DB search indexing costs.
6. **Immutable Field Tampering**: Modifying the `createdAt` timestamp from a previous value to a false historic date.
7. **Client Timestamp Forgery**: Sending a pre-calculated client timestamp (e.g., set to yesterday) instead of `request.time`.
8. **Malicious Workspace Structure**: Overwriting `workspaceData` with a string value (instead of a map) to crash client loaders.
9. **No Auth Anonymous Modification**: Attempting to read or write any document without a valid auth token.
10. **Victim Project Hijack**: Authenticated attacker querying or reading the workspace data list of a victim user.
11. **Mass Listing Attack**: Attempting to list all users in `/users` without specifying a safe single-document query (Blanket read prevention).
12. **System Root Traversing**: Accessing arbitrary un-mapped collections (e.g., `/admins/config`) to find administrative controls.

---

## 3. The Test Cases Matrix

We will verify this under our rules configuration checking that:
- Any access with missing/incorrect UID yields `PERMISSION_DENIED`.
- Modifying immutable `createdAt` yields `PERMISSION_DENIED`.
- Malformed data shapes yield `PERMISSION_DENIED`.
