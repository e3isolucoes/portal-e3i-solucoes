# E3I Processos Inteligentes - GUIA DE COMPONENTES PADRONIZADOS

Este documento serve como manual técnico de consumo e desenvolvimento para os **componentes de interface baseados no Design System da E3I**. Todos os elementos estão declarados de forma reutilizável, tipada e acessível em `src/components/StandardComponents.tsx`.

---

## 1. Biblioteca de Componentes de Base

### 1. Button (Botão)
Botão reativo com suporte a múltiplos estados semânticos e anel de foco acessível (`focus:ring`).
*   **Variants**: `primary`, `secondary`, `accent`, `danger`, `text`.
*   *Exemplo de uso*:
```tsx
import { Button } from "./components/StandardComponents";
<Button variant="primary">Simular Monte Carlo</Button>
```

### 2. Input (Campo de Entrada)
Entrada de texto acessível com suporte a erros orientados (`aria-invalid` e `aria-describedby`).
```tsx
<Input 
  id="input-arrival-rate" 
  label="Taxa de Chegada (λ)" 
  placeholder="Ex: 12" 
  error={errors.arrivalRate}
/>
```

### 3. Select (Caixa de Seleção)
Seletor padronizado de contexto corporativo.
```tsx
<Select 
  id="select-cargo"
  label="Cargo de Atuação" 
  options={[
    { value: "Analista Júnior", label: "Analista Júnior" },
    { value: "Analista Sênior", label: "Analista Sênior" }
  ]}
  value={currentCargo}
  onChange={(e) => setCargo(e.target.value)}
/>
```

### 4. Textarea (Área de Texto)
Ideal para justificativas técnicas, mapeamento de anomalias ou notas de DMAIC.
```tsx
<Textarea id="text-notes" label="Justificativa de Melhoria" placeholder="Descreva os fatores de gargalo..." />
```

### 5. Checkbox (Caixa de Seleção)
Visual estilizado de 16px por 16px para checklists governamentais de DMAIC.
```tsx
<Checkbox id="check-define-1" label="Problema priorizado com Pareto" checked={checked} onChange={toggle} />
```

### 6. Radio (Seleção Única)
Seletor sutil para visões estatísticas exclusivas.
```tsx
<Radio id="radio-mode-1" label="Modo Histograma" name="mode" value="histogram" />
```

### 7. Date Picker (Seletor de Data)
Entrada nativa estilizada com máscara de data e foco de auto-ajuda.
```tsx
<DatePicker id="date-deadline" label="Prazo Final de Implantação" value={deadline} />
```

---

## 2. Componentes de Estrutura e Mensagens

### 8. Dialog / Modal (Janela de Diálogo)
Diálogo acessível com foco gerenciado, backdrop translúcido e botão de descarte rápido com 'Esc'/'X'.
```tsx
<Dialog isOpen={isModalOpen} onClose={() => setModal(false)} title="Análise detalhada de etapa">
  <p>Tempo médio de ciclo: 8.5 minutos</p>
</Dialog>
```

### 9. Drawer (Painel Deslizante)
Gaveta lateral, perfeito para configurações profundas sem redirecionar o usuário do fluxo.
```tsx
<Drawer isOpen={isDrawerOpen} onClose={() => setDrawer(false)} title="Fórmulas e Métricas" position="right">
  <p>Fórmula de Little: L = λW</p>
</Drawer>
```

### 10. Toast (Alerta Flutuante)
Aviso rápido que desliza na lateral superior direita sobrepondo-se às telas principais.
*   **Types**: `success`, `warning`, `error`, `info`.

### 11. Alert (Estatuto / Banner de Atenção)
Mensagens de cabeçalho com realce colorido focado em desvio estatístico.
```tsx
<Alert type="warning" title="Limites de Controle Ultrapassados">
  A etapa AOI apresentou desvio focal mecânico com fração de rejeitos de 1.05 acima do limite aceitável.
</Alert>
```

### 12. Empty State (Estado de Tela Vazia)
Visual ilustrativo com botão de CTA para guiar novos usuários. Possui suporte nativo para 11 estados diferentes (Carregando, Sem Permissão, Dados Parciais, etc).
```tsx
<EmptyState 
  type="no_data" 
  title="Nenhum indicador registrado" 
  description="Clique para iniciar o gerador Gaussiano de simulação física."
  actionLabel="Preencher Aleatório"
  onAction={handleSeed}
/>
```

### 13. Skeleton (Preenchedor Shimmering)
Instância animada simulando o carregamento de tabelas ou gráficos pesados de forma elegante.

### 14. Card (Cartão)
Caixa de fundo plano off-white com sombras projetadas milimetricamente de alta estética corporativa.

### 15. KPI Card (Indicador Principal)
Exibe valores numéricos gigantescos acompanhados de taxas de variação integradas coloridas.
```tsx
<KpiCard label="Tempo de Atravessamento (Lead Time)" value="15.8 min" variation={{ text: "-11.2%", dir: "down" }} />
```

---

## 3. Navegação e Dados

### 16. Table (Tabela Estilizada)
Grade de dados com bordas suaves e listagem zebrada que evita cansaço de visualização.

### 17. Pagination (Paginação)
Barra de transição de páginas no rodapé com botões táteis `Prev/Next` e leitores de tela adaptados.

### 18. Tabs (Abas Organizacionais)
Divisor horizontal de visões temáticas.
```tsx
<Tabs 
  tabs={[
    { id: "inicio", label: "🌱 Mapeamento Dirigido" },
    { id: "especialist", label: "⚡ Painel Técnico Especialista" }
  ]} 
  activeTab={activeTab} 
  onTabChange={setActiveTab} 
/>
```

### 19. Breadcrumb (Trilha de Navegação)
Trilha de nível estrutural facilitando que o usuário se localize no B2B SaaS complexo.

### 20. Stepper (Passos Executivos)
Indicador com sequenciamento dos passos do DMAIC (`Definir`, `Medir`, `Analisar`, `Melhorar`, `Controlar`).

### 21. Badge (Etiquetas de Status)
Etiqueta semântica colorida compacta para status em tabelas.

### 22. Tooltip (Dica de Ajuda)
Exposição de explicações estatísticas sofisticadas ao passar o cursor ou manter o foco nos termos do Lean Six Sigma.

---

## 4. Componentes Especialistas E3I

### 23. Context Selector (Seletor Superior)
Seletor contextual para Empresa e Projeto integrando botões de acionamento de um só clique.

### 24. Approval Status (Parecer de Aprovação SOX)
Quadro para controle de auditorias que exibe notas assinadas pelo analista sênior ou Black Belt.

### 25. Evidence Attachment (Subida de Provas de Análise)
Área ampla com detecção de Drag & Drop para arrastar fotos ou planilhas de comprovação de causa-raiz.

### 26. Activity Timeline (Histórico de Mudanças)
Linha do tempo vertical ilustrando o histórico de ações documentadas detalhando datas, autores e justificativas.
