# Motor de Simulação Estocástica de Eventos Discretos (DES) - E3I

O E3I opera um motor científico pioneiro escrito em TypeScript puro de acordo com a conformidade corporativa **Fase 10**. O motor separa de formalidade absoluta as regras de domínio matemático e estatístico de qualquer representação visual de interface ou latência da renderização HTML.

## Arquitetura do Simulador

O motor simula processos através de um loop de **Entidades e Eventos Discretos (Discrete Event Simulation - DES)**:

1. **Tokens de Processo (Tokens)**: Carregam a identidade do item em curso, carimbo de data/hora (caracterizando o momento exato de admissão), histórico de transições operacionais (tempos de espera, tempos de processamento e recursos dedicados) e contadores de retrabalho dinâmico.
2. **Eventos de Transição**: São agendados ordenadamente em uma lista de prioridades sincronizada cronologicamente:
   - `arrival`: Entrada de nova demanda regulada pela taxa de chegada configurada.
   - `task_complete`: Liberação de um recurso ocupado e direcionamento de tokens para o nó seguinte.
   - `downtime_start` / `downtime_end`: Flutuações na disponibilidade e quebras de equipamentos simuladas de maneira autônoma com distribuição exponencial.

## Tratamento de Loops de Retrabalho e Limite de Iterações (`loopLimit`)

Para evitar ciclos infinitos que congelariam as execuções em processos com probabilidade de falha crítica (taxas de yield de 0% ou com retorno obrigatório), o motor implementa as seguintes travas analíticas:

- **Contador Dinâmico Individual**: Rastreia consecutivas transições no mesmo componente.
- **Limite de Segurança**: O motor limita as reiterações consecutivas em 3 tentativas seguidas (`loopLimit = 3`).
- **Desvio para Exceção (Breakout Exception)**: Ao alcançar o limite, o token é redirecionado imediatamente para seções de descarte seguro, handler alternativo cadastrado (`exceptionHandlerId`) ou finalizadores de contingência.

## Reprodutibilidade Matemática de Cenários

A governança corporativa exige que as análises de risco e auditorias gerem o mesmo resultado sob idênticos cenários. O simulador implementa isso através de:

- **Mulberry32 PRNG (Pseudo-Random Number Generator)**: Um gerador baseado em semente configurada (`seed`), substituindo métodos matemáticos nativos randômicos do navegador que variariam a cada renderização.
- **Auditoria de Metadados**: O arquivo consolidado de resultados anexa o modelo, versão compilada do motor, IP operacional, data, empresa e usuário responsável.
