# Políticas de Criptografia e Gerenciamento de Chaves (KMS) - E3I

Este documento descreve as políticas criptográficas e a arquitetura de proteção desenvolvida para a ferramenta E3I na **Fase 9**.

## Cifragem Autenticada (AES-256-GCM)

Para garantir confidencialidade absoluta com integridade criptográfica ponta a ponta, todos os relatórios e evidências do sistema são gravados via envelope criptográfico.

- **Algoritmo**: AES-256 no modo GCM (Galois/Counter Mode).
- **Dados Adicionais Assinados (AAD)**: O cabeçalho inclui metadados protegidos como o checksum original do arquivo, permissão mínima exigida, tenant emissor e IDs de controle.
- **Nonces Exclusivos**: Cada operação de cifragem usa um Initialization Vector (IV) de 96 bits aleatório e de única utilização para evitar vazamento de padrões estatísticos em blocos similares.
- **Tags de Verificação GCM**: Uma tag de autenticação de 128 bits valida instantaneamente a integridade dos dados durante a descriptografia. Qualquer bit corrompido ou adulterado anula a legibilidade do arquivo imediatamente, gerando logs de alerta severos no console.

## Gerenciamento do Serviço de Chaves (Cloud KMS)

As chaves criptográficas de proteção de dados (KDKs) são gerenciadas e armazenadas de forma lógica e isolada das tabelas comuns do banco de dados.

- **Chave de Criptografia de Dados (KDK)**: Derivadas de um nó raiz seguro, permitindo rotações granulares.
- **Rotação de Chaves**: Pode ser disparada programaticamente ou sob demanda por administradores no painel avançado (KMS). Chaves antigas são retidas para decifrar arquivos gerados no período ativo de sua versão histórica (Envelope Key Rotation).
- **Sem Segredos em Código**: O frontend E3I interage de forma limpa, não armazenando seeds ou chaves brutas em variáveis expostas do navegador ou no repositório.
