# 🗄️ Modelo de Dados — E3I Processos Inteligentes

Este documento mapeia o esquema das coleções do banco de dados relacional e não-relacional (Firebase Firestore) e as principais interfaces do modelo de dados do ecossistema E3I.

---

## 📂 Visão Geral do Banco de Dados (Firestore)

A plataforma E3I estrutura-se de forma multi-tenant nativa utilizando chaves de associação lógica e isolamento entre coleções.

### 1. Coleção `/users` (Usuários e Workspace)
Armazena Perfis de usuários corporativos e os rascunhos de seus workspaces.
* **id**: UID exclusivo gerado pelo Firebase Authentication.
* **fullName**: string. Nome completo do operador.
* **email**: string. E-mail de cadastro corporativo.
* **role**: UserProfileRole (Administrador, Analista, etc.).
* **belt**: Yellow, Green, Black ou Master Black Belt.
* **workspaceData**: objeto opcional. Cache do estado de rascunhos e projetos associados para recuperação sem latência.
* **createdAt**: timestamp do servidor.
* **updatedAt**: timestamp do servidor.

### 2. Coleção `/companies` (Empresas Locatárias)
Isolamento hierárquico principal:
* **id**: Identificador único da empresa.
* **name**: Razão social ou Fantasia contratante.
* **ownerId**: Identificador do usuário proprietário da empresa.

### 3. Sub-Coleção `/companies/{companyId}/projects` (Projetos de Melhoria LSS)
Os projetos LSS de cada empresa locatária:
* **id**: Identificador único do projeto.
* **companyId**: Vínculo fiduciário.
* **name**: Nome de batismo do projeto DMAIC.
* **status**: Estado (`Planejado`, `Em Andamento`, `Concluído`).
* **ownerId**: UID do Líder criador.

### 4. Coleção Append-Only `/access_logs` (Segurança e Auditoria na Nuvem)
Trilha imutável registrada de forma assíncrona blindando o sistema contra sabotagens ou furos de conformidade:
* **id**: ID único auto-incrementado ou gerado de forma aleatória.
* **userId**: Identificador do executor. Matches com a autenticação ativa.
* **userEmail**: E-mail do executor.
* **action**: Descrição sucinta da ação realizada ("Aprovou entregável", "Excluiu projeto").
* **timestamp**: Horário de gravação imutável capturado no servidor físico.

---

## 📦 Interfaces Principais (TypeScript Model)

Consulte `/src/types.ts` para verificar os tipos centrais utilizados:

```typescript
export interface ProcessStep {
  id: string;
  name: string;
  cycleTimeMean: number;      // Tempo médio de processamento
  cycleTimeStdDev: number;    // Desvio Padrão
  setupTime: number;          // Setup de Maquinário
  yieldRate: number;          // Rendimento estatístico (0-100)
  resourceCount: number;      // Máquinas ou colaboradores dedicados
  description?: string;
}

export interface Deliverable {
  id: string;
  phaseId: "DEFINE" | "MEASURE" | "ANALYZE" | "IMPROVE" | "CONTROL";
  name: string;
  description: string;
  status: "pending" | "in_progress" | "waiting_approval" | "approved" | "rejected" | "blocked";
  responsibleUserId?: string;
  dueDate?: string;
  weight: number;             // Peso para cálculo de progresso ponderado
  comments?: {
    id: string;
    userName: string;
    text: string;
    timestamp: string;
  }[];
}
```
