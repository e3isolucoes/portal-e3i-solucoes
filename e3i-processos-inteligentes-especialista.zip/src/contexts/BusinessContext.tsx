import React, { createContext, useContext, useState, useEffect } from "react";
import { 
  Company, 
  WorkspaceProject, 
  BusinessUnit, 
  Portfolio, 
  Process, 
  Period, 
  BusinessProfile
} from "../types";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";

// === SEGMENTED MULTI-INDUSTRY SYSTEM SYNC PRESETS ===
export interface SegmentConfig {
  segment: "manufatura" | "financeiro" | "contabil" | "fiscal" | "servicos" | "comercio" | "logistica" | "tecnologia" | "saude" | "rh";
  label: string;
  demandUnit: string;
  timeUnit: string;
  financialUnit: string;
  stepTerm: string;
  indicators: string[];
  templates: string[];
  examples: string[];
}

export const SEGMENT_CONFIGS: Record<string, SegmentConfig> = {
  manufatura: {
    segment: "manufatura",
    label: "Indústria / Manufatura",
    demandUnit: "placas",
    timeUnit: "minutos",
    financialUnit: "R$",
    stepTerm: "Posto de Trabalho",
    indicators: ["Lead Time", "Giro de Estoque", "OEE (Eficiência Global)", "Taxa de Refugo", "Nível Sigma"],
    templates: ["Op. SMT", "Lote de Soldagem", "Inspeção AOI", "Montagem Mecânica", "Teste de Estresse"],
    examples: ["Desperdício na Linha de Montagem de Placas PCB", "Capacidade Produtiva de Gabinetes"]
  },
  financeiro: {
    segment: "financeiro",
    label: "Financeiro",
    demandUnit: "faturas",
    timeUnit: "horas",
    financialUnit: "R$",
    stepTerm: "Mesa de Análise",
    indicators: ["Tempo de Processamento", "Divergência de Matching", "Taxa de Pagamento em Atraso", "Nível Sigma de Conciliação"],
    templates: ["Triagem de Notas", "Tri-Way Matching", "Alçada de Custos", "Remessa CNAB", "Conciliação"],
    examples: ["Processo Procure-to-Pay Contas a Pagar", "Gargalo de Aprovação de Despesas"]
  },
  contabil: {
    segment: "contabil",
    label: "Contabilidade",
    demandUnit: "reconciliações",
    timeUnit: "horas",
    financialUnit: "R$",
    stepTerm: "Posto do Razonete",
    indicators: ["Dias para Fechamento (Fast Close)", "Reclassificações Pendentes", "Fração de Erro Societário"],
    templates: ["Conciliação Bancária", "Apropriação de Depreciação", "Consolidação Intercompany", "Variance Analysis"],
    examples: ["Fechamento Contábil Mensal Fast Close", "Eliminação de Partidas Dobradas"]
  },
  fiscal: {
    segment: "fiscal",
    label: "Fiscal / Tributário",
    demandUnit: "documentos",
    timeUnit: "horas",
    financialUnit: "R$",
    stepTerm: "Fase de Validação SPED",
    indicators: ["Inconsistências no Validador SPED", "Tempo de Apuração de Impostos", "Taxa de Erro NCM"],
    templates: ["Saneamento NCM", "Equalização de Créditos ICMS", "Apuração Tributos Diretos", "Validação SPED"],
    examples: ["Auditoria Preventiva de SPED Fiscal / EFD", "Gargalo Tributário de Custos"]
  },
  servicos: {
    segment: "servicos",
    label: "Serviços",
    demandUnit: "chamados",
    timeUnit: "minutos",
    financialUnit: "R$",
    stepTerm: "Estação de Atendimento",
    indicators: ["First Contact Resolution (FCR)", "Satisfação do Cliente (CSAT)", "SLA de Atendimento"],
    templates: ["Triagem de Chamados", "Análise de Suporte", "Escala de Engenharia", "Acompanhamento Backlog"],
    examples: ["Atendimento de Helpdesk TI", "Processamento de Solicitações do Cliente"]
  },
  comercio: {
    segment: "comercio",
    label: "Comércio / Varejo",
    demandUnit: "vendas",
    timeUnit: "minutos",
    financialUnit: "R$",
    stepTerm: "Ponto de Venda/PDV",
    indicators: ["Ticket Médio", "Tempo de Atendimento", "Taxa de Conversão", "Fila do Caixa"],
    templates: ["Atendimento PDV", "Estocagem Reposição", "Fechamento de Caixa", "Fidelização Cliente"],
    examples: ["Atendimento Frente de Loja", "Gargalo Logístico no Cupom Fiscal"]
  },
  logistica: {
    segment: "logistica",
    label: "Logística / Distribuição",
    demandUnit: "pedidos",
    timeUnit: "horas",
    financialUnit: "R$",
    stepTerm: "Doca de Carga",
    indicators: ["On-Time In-Full (OTIF)", "Giro de Estoque", "Tempo de Estadia em Doca", "Custo do Frete"],
    templates: ["Triagem de Pedido", "Picking Automatizado", "Paletização", "Despacho Doca"],
    examples: ["Logística de Entrada Integrada (Inbound)", "Distribuição de Supply Chain Last Mile"]
  },
  tecnologia: {
    segment: "tecnologia",
    label: "Tecnologia / DevOps",
    demandUnit: "cards",
    timeUnit: "dias",
    financialUnit: "USD",
    stepTerm: "Squad Kanban",
    indicators: ["Lead Time de Código", "Vazão de Deploy", "Fração de Bugs em Produção", "Frequência de Deploy"],
    templates: ["Planejamento Sprint", "Desenvolvimento", "Revisão por Par", "CI/CD Pipeline"],
    examples: ["Aceleração do Fluxo Kanban DevOps", "Redução do Lead Time de Deploy"]
  },
  saude: {
    segment: "saude",
    label: "Saúde / Clínico",
    demandUnit: "pacientes",
    timeUnit: "minutos",
    financialUnit: "R$",
    stepTerm: "Posto Clínico",
    indicators: ["Tempo de Espera Manchester", "Satisfação do Paciente (NPS)", "Taxa de Reinternação"],
    templates: ["Triagem Manchester", "Consulta Clínica", "Procedimento Especial", "Emissão de Alta"],
    examples: ["Processo de Pronto Atendimento Clínico", "Gargalo na Higienização de Leitos"]
  },
  rh: {
    segment: "rh",
    label: "Recursos Humanos (RH)",
    demandUnit: "vagas",
    timeUnit: "dias",
    financialUnit: "R$",
    stepTerm: "Etapa do Funil",
    indicators: ["Time-to-Hire", "Custo de Contratação", "Turno de Admissão", "Taxa de Turnover"],
    templates: ["Triagem de CVs", "Entrevista de RH", "Painel Técnico", "Proposta Comercial"],
    examples: ["Aceleração do Fluxo de Candidatos na Engenharia", "Otimização de Onboarding de Talentos"]
  }
};

export interface BusinessContextProps {
  // States
  organizationId: string | null;
  companyId: string | null;
  businessUnitId: string | null;
  portfolioId: string | null;
  projectId: string | null;
  processId: string | null;
  period: Period | null;
  userProfile: BusinessProfile | null;
  permissions: string[];
  isSandbox: boolean;

  // Resolved Entities
  activeCompany: Company | null;
  activeProject: WorkspaceProject | null;
  activeUnit: BusinessUnit | null;
  activePortfolio: Portfolio | null;
  activeProcess: Process | null;

  // Active Segment Configurations
  segmentConfig: SegmentConfig;

  // Actions / Core context switches with cleanups and reloads
  selectCompany: (id: string | null) => void;
  selectProject: (id: string | null) => void;
  setBusinessUnitId: (id: string | null) => void;
  setPortfolioId: (id: string | null) => void;
  setProcessId: (id: string | null) => void;
  setOrganizationId: (id: string | null) => void;
  setPeriod: (period: Period | null) => void;
  setUserProfile: (profile: BusinessProfile | null) => void;
  setPermissions: (permissions: string[]) => void;
  setIsSandbox: (sandbox: boolean) => void;

  // Helper functions
  reloadIndicators: () => void;
  reloadPermissions: () => void;
}

const BusinessContext = createContext<BusinessContextProps | undefined>(undefined);

export const BusinessContextProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [organizationId, setOrganizationIdState] = useState<string | null>(null);
  const [companyId, setCompanyIdState] = useState<string | null>(() => localStorage.getItem("e3i_context_companyId"));
  const [businessUnitId, setBusinessUnitIdState] = useState<string | null>(() => localStorage.getItem("e3i_context_unitId"));
  const [portfolioId, setPortfolioIdState] = useState<string | null>(() => localStorage.getItem("e3i_context_portfolioId"));
  const [projectId, setProjectIdState] = useState<string | null>(() => localStorage.getItem("e3i_context_projectId"));
  const [processId, setProcessIdState] = useState<string | null>(() => localStorage.getItem("e3i_context_processId"));
  const [period, setPeriodState] = useState<Period | null>(null);
  const [userProfile, setUserProfileState] = useState<BusinessProfile | null>(null);
  const [permissions, setPermissionsState] = useState<string[]>([]);
  const [isSandbox, setIsSandboxState] = useState<boolean>(() => localStorage.getItem("lss_training_mode") === "true");

  const [activeCompany, setActiveCompany] = useState<Company | null>(null);
  const [activeProject, setActiveProject] = useState<WorkspaceProject | null>(null);
  const [activeUnit, setActiveUnit] = useState<BusinessUnit | null>(null);
  const [activePortfolio, setActivePortfolio] = useState<Portfolio | null>(null);
  const [activeProcess, setActiveProcess] = useState<Process | null>(null);

  // Resolved Segment Config (default to services)
  const [segmentConfig, setSegmentConfig] = useState<SegmentConfig>(SEGMENT_CONFIGS.servicos);

  // Persistence to LocalStorage for seamless sessions
  useEffect(() => {
    if (companyId) localStorage.setItem("e3i_context_companyId", companyId);
    else localStorage.removeItem("e3i_context_companyId");
  }, [companyId]);

  useEffect(() => {
    if (businessUnitId) localStorage.setItem("e3i_context_unitId", businessUnitId);
    else localStorage.removeItem("e3i_context_unitId");
  }, [businessUnitId]);

  useEffect(() => {
    if (portfolioId) localStorage.setItem("e3i_context_portfolioId", portfolioId);
    else localStorage.removeItem("e3i_context_portfolioId");
  }, [portfolioId]);

  useEffect(() => {
    if (projectId) localStorage.setItem("e3i_context_projectId", projectId);
    else localStorage.removeItem("e3i_context_projectId");
  }, [projectId]);

  useEffect(() => {
    if (processId) localStorage.setItem("e3i_context_processId", processId);
    else localStorage.removeItem("e3i_context_processId");
  }, [processId]);

  useEffect(() => {
    localStorage.setItem("lss_training_mode", String(isSandbox));
  }, [isSandbox]);

  // Synchronize dynamic lists and active entities when IDs or repository caches change
  useEffect(() => {
    const unsubscribe = CompanyProjectRepository.addChangeListener(() => {
      if (companyId) {
        const comps = CompanyProjectRepository.getCompanies();
        const foundComp = comps.find(c => c.id === companyId);
        if (foundComp) {
          setActiveCompany(prev => JSON.stringify(prev) === JSON.stringify(foundComp) ? prev : foundComp);
          
          // Map industry keyword to segment config
          const ind = (foundComp.industry || "servicos").toLowerCase();
          let segKey: keyof typeof SEGMENT_CONFIGS = "servicos";
          if (ind.includes("manuf") || ind.includes("indus") || ind.includes("factor")) segKey = "manufatura";
          else if (ind.includes("finan") || ind.includes("banc") || ind.includes("pagar")) segKey = "financeiro";
          else if (ind.includes("cont") || ind.includes("libro") || ind.includes("reconcil")) segKey = "contabil";
          else if (ind.includes("fisc") || ind.includes("tribut") || ind.includes("sped")) segKey = "fiscal";
          else if (ind.includes("serv") || ind.includes("atend") || ind.includes("helpdesk")) segKey = "servicos";
          else if (ind.includes("comerc") || ind.includes("loja") || ind.includes("varejo")) segKey = "comercio";
          else if (ind.includes("logis") || ind.includes("frete") || ind.includes("doca") || ind.includes("supply")) segKey = "logistica";
          else if (ind.includes("tec") || ind.includes("dev") || ind.includes("software")) segKey = "tecnologia";
          else if (ind.includes("saude") || ind.includes("med") || ind.includes("hosp") || ind.includes("pacien")) segKey = "saude";
          else if (ind.includes("rh") || ind.includes("human") || ind.includes("gente") || ind.includes("contrat")) segKey = "rh";
          
          const targetConfig = SEGMENT_CONFIGS[segKey] || SEGMENT_CONFIGS.servicos;
          setSegmentConfig(prev => JSON.stringify(prev) === JSON.stringify(targetConfig) ? prev : targetConfig);
        } else {
          setActiveCompany(null);
        }
      } else {
        setActiveCompany(null);
      }

      if (projectId) {
        const projs = CompanyProjectRepository.getProjects();
        const foundProj = projs.find(p => p.id === projectId);
        if (foundProj) {
          setActiveProject(prev => JSON.stringify(prev) === JSON.stringify(foundProj) ? prev : foundProj);
        } else {
          setActiveProject(null);
        }
      } else {
        setActiveProject(null);
      }
    });

    return unsubscribe;
  }, [companyId, projectId]);

  // Cleanups and Reloader Trigger Mechanics
  const reloadIndicators = () => {
    console.log(`[CONTEXT TRIGGER] Recarregando indicadores de performance para empresa: ${companyId} e projeto: ${projectId}`);
  };

  const reloadPermissions = () => {
    console.log(`[CONTEXT TRIGGER] Recarregando permissões para o perfil profissional no escopo: ${projectId || companyId}`);
  };

  // 1. Switch Company: Clean unit, project, process, portfolio, reload indicators/perms, isolate old data.
  const selectCompany = (id: string | null) => {
    console.log(`[CONTEXT CHANGE] Selecionando nova empresa ID: ${id}`);
    setCompanyIdState(id);
    
    // Explicit cleanups
    setBusinessUnitIdState(null);
    setProjectIdState(null);
    setProcessIdState(null);
    setPortfolioIdState(null);
    setActiveUnit(null);
    setActiveProject(null);
    setActiveProcess(null);
    setActivePortfolio(null);

    // Dynamic triggers
    reloadIndicators();
    reloadPermissions();
  };

  // 2. Switch Project: Clean process, reload steps, indicators, actions, evidences, permissions.
  const selectProject = (id: string | null) => {
    console.log(`[CONTEXT CHANGE] Selecionando novo projeto ID: ${id}`);
    setProjectIdState(id);

    // Explicit cleanups
    setProcessIdState(null);
    setActiveProcess(null);

    // Dynamic triggers
    reloadIndicators();
    reloadPermissions();
  };

  return (
    <BusinessContext.Provider
      value={{
        organizationId,
        companyId,
        businessUnitId,
        portfolioId,
        projectId,
        processId,
        period,
        userProfile,
        permissions,
        isSandbox,

        activeCompany,
        activeProject,
        activeUnit,
        activePortfolio,
        activeProcess,
        segmentConfig,

        selectCompany,
        selectProject,
        setBusinessUnitId: setBusinessUnitIdState,
        setPortfolioId: setPortfolioIdState,
        setProcessId: setProcessIdState,
        setOrganizationId: setOrganizationIdState,
        setPeriod: setPeriodState,
        setUserProfile: setUserProfileState,
        setPermissions: setPermissionsState,
        setIsSandbox: setIsSandboxState,

        reloadIndicators,
        reloadPermissions
      }}
    >
      {children}
    </BusinessContext.Provider>
  );
};

export const useBusinessContext = () => {
  const context = useContext(BusinessContext);
  if (context === undefined) {
    throw new Error("useBusinessContext deve ser utilizado dentro de um BusinessContextProvider");
  }
  return context;
};
