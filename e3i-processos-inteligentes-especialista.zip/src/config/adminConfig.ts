/**
 * Centralized Admin Configuration & Management
 */

import { Permission } from "../types";

/**
 * Centered RBAC Security Configuration for E3I Processos Inteligentes.
 * In production, permissions should be resolved on the server-side,
 * and we warn the client that any client-side assertions are purely for custom UX-guiding fallback.
 */

// Central map of Roles and Belts to their authorized permission sets
export const ROLE_PERMISSION_MAP: Record<string, Permission[]> = {
  admin: [
    "platform:view", "company:view", "company:manage",
    "project:view", "project:create", "project:edit", "project:delete",
    "process:view", "process:create", "process:edit", "process:delete", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "admin:view", "admin:manage-users", "admin:manage-settings",
    "ai:use", "ai:advanced"
  ],
  "master black belt": [
    "platform:view", "company:view", "company:manage",
    "project:view", "project:create", "project:edit", "project:delete",
    "process:view", "process:create", "process:edit", "process:delete", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "admin:view", "admin:manage-users", "admin:manage-settings",
    "ai:use", "ai:advanced"
  ],
  "black belt": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:create", "process:edit", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "ai:use", "ai:advanced"
  ],
  "green belt": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:create", "process:edit", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action",
    "report:view",
    "ai:use"
  ],
  "yellow belt": [
    "platform:view", "company:view",
    "project:view",
    "process:view",
    "operation:view",
    "report:view",
    "ai:use"
  ]
};

/**
 * Returns the exact list of permissions assigned to a user based on their role and belt.
 */
export function getPermissionsForUser(role?: string, belt?: string): Permission[] {
  const normRole = (role || "").toLowerCase().trim();
  const normBelt = (belt || "").toLowerCase().trim();

  if (normRole === "admin" || normRole === "administrador" || normBelt === "master black belt" || normRole === "master_black_belt") {
    return ROLE_PERMISSION_MAP["admin"];
  }
  if (normBelt === "black belt") {
    return ROLE_PERMISSION_MAP["black belt"];
  }
  if (normBelt === "green belt") {
    return ROLE_PERMISSION_MAP["green belt"];
  }
  // Default fallback (Yellow Belt/Operator permissions)
  return ROLE_PERMISSION_MAP["yellow belt"];
}

/**
 * Central permission check function
 */
export function hasPermission(
  user: { email?: string; role?: string; belt?: string; permissions?: string[] } | null,
  permission: Permission
): boolean {
  if (!user) return false;
  
  // If user profile has explicitly loaded permissions, verify them
  if (user.permissions && Array.isArray(user.permissions)) {
    return user.permissions.includes(permission);
  }

  // Fallback to role-based permission mapping
  const perms = getPermissionsForUser(user.role, user.belt);
  return perms.includes(permission);
}

/**
 * Centralized administrator checker
 * WARNING: Checking role/email strings in the browser is for UX steering only.
 * Production enforcement is executed statelessly inside the API gateway and security layers.
 */
export function isAdmin(user: { email?: string; role?: string; belt?: string } | null, currentCargo?: string): boolean {
  if (!user) return false;
  
  // High-reliability check: Does this user possess administrative view permission?
  return hasPermission(user, "admin:view");
}

/**
 * Audit message warning about local cargo influencing privileges
 */
export const SECURITY_WARNING_NOTICE = 
  "⚠️ AVISO DE GOVERNANÇA: A autorização baseada em cargos locais e WebStorage " +
  "é estritamente demonstrativa. O controle real de acesso deve ser validado via " +
  "tokens JWT assinados por servidor de backend e regras do Firebase Firestore.";

