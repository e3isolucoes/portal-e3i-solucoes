import { describe, it, expect } from "vitest";
import { probit, boxMullerRandom, calculateProcessMetrics, runMonteCarloSimulation } from "./utils";
import { ProcessStep } from "./types";

describe("LSS Core Analytics Utility Suite", () => {
  
  describe("probit() - Numerical Inverse Cumulative Standard Normal Distribution", () => {
    it("should clamp values at extreme boundaries", () => {
      expect(probit(0)).toBe(-4.5);
      expect(probit(0.00000001)).toBe(-4.5);
      expect(probit(1)).toBe(4.5);
      expect(probit(0.99999999)).toBe(4.5);
    });

    it("should return approximately 0 for probability 0.5", () => {
      const result = probit(0.5);
      expect(result).toBeCloseTo(0, 4);
    });

    it("should return proper standard deviation values for standard probabilities", () => {
      // 1-sided Z-score for ~84.13% queue/yield is ~1.0
      expect(probit(0.84134)).toBeCloseTo(1.0, 2);
      // 1-sided Z-score for ~97.72% yield is ~2.0
      expect(probit(0.97725)).toBeCloseTo(2.0, 2);
    });
  });

  describe("boxMullerRandom() - Stochastic Normal Distribution Generator", () => {
    it("should generate values centered around the mean", () => {
      const mean = 10;
      const stdDev = 2;
      const samples: number[] = [];
      
      for (let i = 0; i < 100; i++) {
        samples.push(boxMullerRandom(mean, stdDev));
      }
      
      const sum = samples.reduce((acc, v) => acc + v, 0);
      const computedMean = sum / samples.length;
      
      // Since it's stochastic, we just want to ensure it is in a realistic range and clamped above 0.1
      expect(computedMean).toBeGreaterThan(5);
      expect(computedMean).toBeLessThan(15);
      expect(samples.every(s => s >= 0.1)).toBe(true);
    });
  });

  describe("calculateProcessMetrics() - Queuing Theory & Six Sigma Engine", () => {
    const mockSteps: ProcessStep[] = [
      {
        id: "step1",
        name: "Sorting and Triaging",
        resource: "Clerk",
        resourceCount: 2,
        processingTime: 5, // minutes per unit
        standardDeviation: 1,
        setupTime: 10,
        yieldRate: 0.95 // 95% yield
      },
      {
        id: "step2",
        name: "Manual Inspection",
        resource: "Specialist",
        resourceCount: 1,
        processingTime: 8, // minutes per unit -> 60/8 = 7.5 units/hour capacity
        standardDeviation: 2,
        setupTime: 15,
        yieldRate: 0.98 // 98% yield
      }
    ];

    it("should analyze utilization and identify the bottleneck step", () => {
      const arrivalRate = 4; // units/hour
      const metrics = calculateProcessMetrics(mockSteps, arrivalRate);

      // Step 1 capacity: (60/5) * 2 = 24 units/hour. Utilization: 4/24 = 16.67%
      // Step 2 capacity: (60/8) * 1 = 7.5 units/hour. Utilization: 4/7.5 = 53.33%
      // Bottleneck should be Step 2
      expect(metrics.bottleneckStepName).toBe("Manual Inspection");
      expect(metrics.systemUtilization).toBeCloseTo(53.33, 1);
    });

    it("should compute compounding first-pass rolled yield and Sigma levels", () => {
      const arrivalRate = 3;
      const metrics = calculateProcessMetrics(mockSteps, arrivalRate);

      // Compounded Yield = 0.95 * 0.98 = 0.931 (93.1%)
      expect(metrics.rolledFirstPassYield).toBeCloseTo(0.931, 4);

      // DPMO = (1 - 0.931) * 1,000,000 = 69,000
      expect(metrics.dpmo).toBeCloseTo(69000, 2);

      // Sigma level = probit(0.931) + 1.5 shift
      const expectedSigma = probit(0.931) + 1.5;
      expect(metrics.sigmaLevel).toBeCloseTo(expectedSigma, 2);
    });
  });

  describe("runMonteCarloSimulation() - Stochastically Modeled Execution Simulator", () => {
    const mockSteps: ProcessStep[] = [
      {
        id: "step1",
        name: "Assembly Line",
        resource: "Operator",
        resourceCount: 2,
        processingTime: 10,
        standardDeviation: 2,
        setupTime: 10,
        yieldRate: 0.99
      }
    ];

    it("should run 20 simulation cycles and record daily performance data", () => {
      const result = runMonteCarloSimulation(mockSteps, 5);
      
      expect(result.dailyAverages).toBeInstanceOf(Array);
      expect(result.dailyAverages.length).toBe(20);
      
      // Validate structure of recorded day
      const dayOne = result.dailyAverages[0];
      expect(dayOne).toHaveProperty("day", 1);
      expect(dayOne).toHaveProperty("cycleTime");
      expect(dayOne).toHaveProperty("defectRate");
      expect(dayOne).toHaveProperty("wip");
      
      // Logs should contain transient steps of units simulated on Day 20
      expect(result.logs).toBeInstanceOf(Array);
      if (result.logs.length > 0) {
        expect(result.logs[0]).toHaveProperty("completedAt");
        expect(result.logs[0]).toHaveProperty("duration");
      }
    });
  });
});
