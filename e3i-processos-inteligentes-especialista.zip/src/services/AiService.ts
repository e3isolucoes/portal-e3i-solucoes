import { ProcessStep, ProjectCharter, Sipoc, AiOptimizationResult } from "../types";
import { auth } from "../firebase";

export interface SuggestStructureResult {
  sipoc: Sipoc;
  steps: {
    name: string;
    resource: string;
    resourceCount: number;
    processingTime: number;
    standardDeviation: number;
    yieldRate: number;
    setupTime: number;
  }[];
  orAnalysis: {
    orModel: string;
    problemStatement: string;
    orSuggestions: string;
    recommendedConfiguration: string;
    operationalTip: string;
  };
}

export interface ParseProcessResult {
  gatilho: string;
  atores: string[];
  sistemas: string[];
  entregavelFinal: string;
  mermaidDiagram: string;
  flowchartSteps: {
    id: string;
    label: string;
    actor?: string;
    system?: string;
    type: "start" | "step" | "decision" | "end";
    next: string[];
  }[];
  gapAnalysis: string[];
  interactiveQuestions?: string[];
}

export class AiService {
  /**
   * Resolves the active ID token from current logged-in user or fallback
   */
  private static async getAuthHeaders(authToken?: string): Promise<Record<string, string>> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    
    let resolvedToken = authToken;
    if (!resolvedToken && auth.currentUser) {
      try {
        resolvedToken = await auth.currentUser.getIdToken();
      } catch (err) {
        console.warn("[AiService] Failed to obtain Firebase ID token:", err);
      }
    }
    
    if (resolvedToken) {
      headers["Authorization"] = `Bearer ${resolvedToken}`;
    }
    return headers;
  }

  /**
   * Contacts backend endpoint to run detailed operational study using Gemini.
   */
  static async analyzeProcess(
    steps: ProcessStep[],
    arrivalRate: number,
    charter: ProjectCharter,
    sipoc: Sipoc,
    authToken?: string
  ): Promise<AiOptimizationResult> {
    const headers = await this.getAuthHeaders(authToken);

    const response = await fetch("/api/analyze", {
      method: "POST",
      headers,
      body: JSON.stringify({
        steps,
        arrivalRate,
        charter,
        sipoc,
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Erro ao consultar o serviço de IA.");
    }

    return await response.json();
  }

  /**
   * Contacts backend endpoint to suggest operational structures and SIPOC based on sector text.
   */
  static async suggestStructure(sectorDescription: string, authToken?: string): Promise<SuggestStructureResult> {
    const headers = await this.getAuthHeaders(authToken);

    const response = await fetch("/api/suggest-structure", {
      method: "POST",
      headers,
      body: JSON.stringify({ sectorDescription }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Erro ao gerar sugestão de estrutura.");
    }

    return await response.json();
  }

  /**
   * Contacts backend endpoint to interpret unstructured process descriptions.
   */
  static async parseProcess(
    text: string, 
    feedback?: string, 
    history?: { role: "user" | "model"; content: string }[] | any[],
    authToken?: string
  ): Promise<ParseProcessResult> {
    const headers = await this.getAuthHeaders(authToken);

    const response = await fetch("/api/parse-process", {
      method: "POST",
      headers,
      body: JSON.stringify({ text, feedback, history }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Erro ao interpretar processo com IA.");
    }

    return await response.json();
  }
}
