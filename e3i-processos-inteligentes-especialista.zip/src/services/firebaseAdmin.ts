import admin from "firebase-admin";
import path from "path";
import fs from "fs";

// Load active firebase-applet-config.json dynamically for Firebase Admin credentials or project info
let appletConfig: any = {};
try {
  const configFile = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configFile)) {
    appletConfig = JSON.parse(fs.readFileSync(configFile, "utf-8"));
  }
} catch (err) {
  console.warn("[FirebaseAdmin] Could not load active firebase-applet-config.json:", err);
}

const projectId = process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID || appletConfig.projectId || "gen-lang-client-0360031080";
const rawDatabaseId = process.env.VITE_FIREBASE_DATABASE_ID || process.env.FIREBASE_DATABASE_ID || appletConfig.firestoreDatabaseId;
const databaseId = (rawDatabaseId && !(rawDatabaseId.startsWith("http://") || rawDatabaseId.startsWith("https://") || rawDatabaseId.includes("/") || rawDatabaseId.includes(".com")))
  ? rawDatabaseId
  : undefined;

// Ensure Firebase Admin is initialized exactly once
if (admin.apps.length === 0) {
  admin.initializeApp({
    projectId: projectId,
  });
}

// Instance References
export const adminAuth = admin.auth();

// Support custom Firestore database ID if set in configuration
export const adminDb = databaseId
  ? new admin.firestore.Firestore({
      projectId: projectId,
      databaseId: databaseId,
    })
  : admin.firestore();

/**
 * Interface representing a validated and authorized user profile
 */
export interface AuthorizedUserProfile {
  uid: string;
  email?: string;
  fullName: string;
  role: string;
  belt: string;
}

/**
 * Verifies the incoming Firebase ID Token and returns user details.
 */
export async function verifyIdToken(token: string): Promise<admin.auth.DecodedIdToken> {
  try {
    return await adminAuth.verifyIdToken(token);
  } catch (error) {
    console.error("[FirebaseAdmin] ID Token verification failed:", error);
    throw new Error("Token de autenticação inválido ou expirado.");
  }
}

/**
 * Centrally validates the user profile from Firestore users collection
 */
export async function getUserProfile(uid: string): Promise<AuthorizedUserProfile> {
  try {
    const userSnap = await adminDb.collection("users").doc(uid).get();
    if (!userSnap.exists) {
      return {
        uid,
        fullName: "Usuário",
        role: "Consultor Lean Six Sigma",
        belt: "Green Belt",
      };
    }
    const data = userSnap.data() || {};
    return {
      uid,
      email: data.email,
      fullName: data.fullName || "Usuário",
      role: data.role || "Consultor Lean Six Sigma",
      belt: data.belt || "Green Belt",
    };
  } catch (error) {
    console.error("[FirebaseAdmin] Failed to fetch authorized profile:", error);
    throw new Error("Erro ao carregar o perfil de segurança do usuário.");
  }
}

/**
 * Verifies that the given user has access to a specific organization (company).
 * This uses a centralized ownership check: only the owner/admin can access.
 */
export async function authorizeCompanyAccess(uid: string, companyId: string): Promise<boolean> {
  try {
    const userProfile = await getUserProfile(uid);
    // Admins always have corporate-wide override access
    if (userProfile.role === "Admin") {
      return true;
    }

    const companySnap = await adminDb.collection("companies").doc(companyId).get();
    if (!companySnap.exists) {
      return false;
    }

    const companyData = companySnap.data();
    return companyData?.ownerId === uid;
  } catch (error) {
    console.error(`[FirebaseAdmin] Authorization failed for user ${uid} on company ${companyId}:`, error);
    return false;
  }
}
