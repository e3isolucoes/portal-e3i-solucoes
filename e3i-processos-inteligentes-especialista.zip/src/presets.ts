import { ProcessStep, ProjectCharter, Sipoc, ControlPlan } from "./types";

export interface ProcessTemplate {
  id: string;
  name: string;
  category: "manufatura" | "financeiro" | "contabil" | "fiscal" | "servicos" | "comercio" | "logistica" | "tecnologia" | "saude" | "rh";
  icon: string;
  arrivalRate: number; // units per hour
  unitLabel: string; // e.g., "placas", "faturas", "reconciliações", "documentos"
  unitLabelPlural: string;
  steps: ProcessStep[];
  charter: ProjectCharter;
  sipoc: Sipoc;
  controlPlans: ControlPlan[];
}

export const PROCESS_TEMPLATES: ProcessTemplate[] = [
  {
    id: "manufacturing-pcb",
    name: "Eletrônicos (Painel PCB)",
    category: "manufatura",
    icon: "🏭",
    arrivalRate: 10,
    unitLabel: "placa",
    unitLabelPlural: "placas",
    charter: {
      title: "Construção e Estabilização de Capacidade do Fluxo PCB",
      problemStatement: "A linha de montagem apresenta gargalos intermitentes de vazão e alto índice de retrabalho na inspeção óptica, fazendo com que o Lead Time médio passe de 45 minutos e gerando atrasos crônicos na entrega.",
      goal: "Reduzir o Lead Time total do sistema em 40%, aumentar o nível sigma do processo para após 3.5σ e eliminar filas acumuladas nos postos de montagem mecânica.",
      metric: "cycle_time",
      targetValue: 25
    },
    sipoc: {
      suppliers: "Almoxarifado central, Fornecedor de PCBs e componentes ativos, Fábrica de Injeção Plástica",
      inputs: "Placas virgens, pasta de solda sem chumbo, MCUs, conectores, gabinetes plásticos e parafusos",
      processDescription: "Abastecimento SMT -> Refluxo térmico -> Inspeção óptica/Reparo -> Montagem Mecânica -> Teste Funcional",
      outputs: "Dispositivos PCB integrados prontos para remessa, relatórios de não-conformidade",
      customers: "Distribuidoras regionais, Clientes B2B e canais de exportação"
    },
    steps: [
      {
        id: "step-1",
        name: "SMT - Aplicação de Solda e Componentes",
        resource: "Operador de SMT",
        resourceCount: 1,
        processingTime: 4.0,
        standardDeviation: 0.8,
        yieldRate: 0.98,
        setupTime: 15,
        description: "Montagem em superfície automatizada de placas eletrônicas.",
        requiredInputs: [
          "Placas de Circuito Virgens (Painel FR4)",
          "Pasta de Solda sem chumbo (SAC305)",
          "Bobinas de Componentes SMD (Resistores, Capacitores, ICs)",
          "Stencil Metálico Laser de precisão"
        ],
        stepInstructions: [
          "Efetuar limpeza prévia do Stencil com álcool isopropílico 99%.",
          "Alimentar bobinas de componentes nas gavetas correspondentes nos feeders de SMT.",
          "Programar e carregar o arquivo CAD do circuito PCB na máquina Pick & Place.",
          "Verificar pressão pneumática de raspagem de pasta de solda na impressora semiautomática."
        ],
        automations: [
          {
            title: "Raspador Automático de Pressão Direta",
            type: "Pneumática Proporcional",
            status: "active",
            description: "Garante deposição uniforme da pasta de solda através de reguladores integrados dinâmicos."
          },
          {
            title: "Sensoreamento de Bobina Vazia por RFID",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Alerta preventivo de esgotamento de componente com antecedência de 15 minutos, anulando tempos de máquina vazia (reduz setup residual)."
          }
        ],
        supportDocuments: [
          { name: "SOP-SMT-001: Operação e Setup de Impressão de Pasta de Solda", code: "SOP-SMT-001", type: "SOP", rev: "A.3" },
          { name: "CKL-SMT-14: Verificação de Alinhamento Laser Pick & Place", code: "CKL-SMT-14", type: "Checklist", rev: "B.0" }
        ]
      },
      {
        id: "step-2",
        name: "Forno de Soldagem por Refluxo",
        resource: "Forno/Operador",
        resourceCount: 1,
        processingTime: 4.8,
        standardDeviation: 0.9,
        yieldRate: 0.99,
        setupTime: 5,
        description: "Fixação térmica dos componentes na placa.",
        requiredInputs: [
          "Placas montadas úmidas (recém-saídas da linha SMT)",
          "Sensores térmicos de perfil de temperatura (Kic Thermoprofiler)",
          "Gases inertes (Nitrogênio N2 líquido para controle de oxigênio)"
        ],
        stepInstructions: [
          "Selecionar a curva térmica correta no painel conforme o tipo de solda sem chumbo.",
          "Carregar os painéis de placas na esteira de alimentação de forma contínua.",
          "Monitorar a vazão e estabilização de Nitrogênio para prevenir oxidação das junções de cobre.",
          "Registrar a temperatura de saída da zona de resfriamento estabilizada abaixo de 45°C."
        ],
        automations: [
          {
            title: "Controle PID Dedicado de Curvas de Forno",
            type: "Automação Industrial PLC",
            status: "active",
            description: "Evita o choque térmico regulando a modulação das resistências em cada uma das 7 zonas térmicas."
          },
          {
            title: "Monitoramento Térmico Via Câmera Infravermelho",
            type: "Visão Computacional",
            status: "proposed",
            description: "Altera instantaneamente a velocidade de tração da esteira em caso de flutuação de temperatura nas zonas centrais."
          }
        ],
        supportDocuments: [
          { name: "MNL-RFX-004: Manual de Segurança e Manutenção do Forno", code: "MNL-RFX-004", type: "Manual", rev: "C.1" },
          { name: "SOP-RFX-02: Calibração de Perfil Térmico por Termopar", code: "SOP-RFX-02", type: "SOP", rev: "A.2" }
        ]
      },
      {
        id: "step-3",
        name: "Inspeção Óptica Automática (AOI)",
        resource: "Técnico de Qualidade",
        resourceCount: 1,
        processingTime: 3.2,
        standardDeviation: 1.4,
        yieldRate: 0.93,
        setupTime: 0,
        description: "Inspeção de solda com correção manual por técnico.",
        requiredInputs: [
          "Placas soldadas saídas do forno de refluxo",
          "Gabarito eletrônico de fita de testes",
          "Bancada anti-estática de toque macio (ESD)",
          "Estação de solda manual de retoque rápido"
        ],
        stepInstructions: [
          "Rodar scanner 3D óptico sob o lote em teste procurando pontes de solda ou componentes desalinhados.",
          "Isolar e colocar etiquetas de reprovação em placas que contenham pinos levantados.",
          "Efetuar o re-fluxo manual delicado dos contatos danificados com ferro de solda Weller ESD.",
          "Alimentar o sistema ERP local com os dados estatísticos das falhas por milhão de componentes."
        ],
        automations: [
          {
            title: "Processamento de Imagem 3D Estéreo",
            type: "Machine Vision",
            status: "active",
            description: "Inspeção em nível submícron de juntas de soldagem, capturando desvios de altura de componentes."
          },
          {
            title: "Classificador de Defeitos Baseado em IA Generativa",
            type: "Deep Learning (IA)",
            status: "proposed",
            description: "Zera o número de alarmes falsos da câmera óptica diminuindo o retrabalho desnecessário de operadores em até 70%."
          }
        ],
        supportDocuments: [
          { name: "SOP-AOI-007: Identificação e Retrabalho de Juntas com Solda Fria", code: "SOP-AOI-007", type: "SOP", rev: "D.0" },
          { name: "FRM-QLD-102: Relatório de Não-Conformidade Técnica RNC", code: "FRM-QLD-102", type: "Form", rev: "A.1" }
        ]
      },
      {
        id: "step-4",
        name: "Montagem Mecânica Final",
        resource: "Operador de Bancada",
        resourceCount: 1,
        processingTime: 5.5,
        standardDeviation: 1.1,
        yieldRate: 0.995,
        setupTime: 12,
        description: "Integração final do circuito no gabinete plástico.",
        requiredInputs: [
          "Placas eletrônicas aprovadas no AOI",
          "Gabinete plástico ABS injetado",
          "Kits de parafusos Philips e molas de aterramento",
          "Parafusadeiras pneumáticas de torque digital calibrado"
        ],
        stepInstructions: [
          "Fixar e alinhar a placa eletrônica PCB central nos pinos do chassis guia de ABS.",
          "Conectar o chicote de cabos flexíveis de alimentação e botão liga-desliga.",
          "Parafusar em cruz com torquímetro pneumático calibrado em exatamente 0.8 N.m.",
          "Garantir o perfeito lacre visual do painel frontal evitando falhas de rebarba plástica."
        ],
        automations: [
          {
            title: "Parafusadora Pneumática de Desarmamento Magnético",
            type: "Mecânica Eletromagnética",
            status: "active",
            description: "Corta instantaneamente o torque de parafusagem garantindo que o invólucro plástico não seja espanado ou quebrado."
          },
          {
            title: "Célula de Parafusamento Robotizado (Cobot)",
            type: "Robótica Colaborativa",
            status: "proposed",
            description: "Efetua a inserção e fixação dos parafusos em paralelo, liberando o operador para tarefas de embalagem."
          }
        ],
        supportDocuments: [
          { name: "SOP-MEC-05: Torqueamento e Lacre Mecânico de Gabinetes", code: "SOP-MEC-05", type: "SOP", rev: "C.4" },
          { name: "SOP-SFT-09: Postura Ergonômica e Calçado de Segurança em Células", code: "SOP-SFT-09", type: "SOP", rev: "B.2" }
        ]
      },
      {
        id: "step-5",
        name: "Teste Funcional e Embalagem",
        resource: "Testador e Embalador",
        resourceCount: 1,
        processingTime: 4.2,
        standardDeviation: 0.6,
        yieldRate: 0.97,
        setupTime: 0,
        description: "Validação eletromecânica sob carga de estresse.",
        requiredInputs: [
          "Módulos montados integrados (Gabinete + PCB)",
          "Cabinas de teste com carga resistiva",
          "Leitor de código de barras USB",
          "Etiquetadora industrial Zebra e caixas de papelão corrugado"
        ],
        stepInstructions: [
          "Conectar o cabo de interface serial ao gabarito de testes.",
          "Iniciar a rotina do software enviando comandos elétricos de stress em 12V.",
          "Checar as medições de resposta na tela de teste procurando atenuações de sinal rf.",
          "Confirmada a calibração, escanear o código do produto e lacrar o blister protetor ESD."
        ],
        automations: [
          {
            title: "Gabarito de Teste Pneumático por Cama de Agulhas",
            type: "Eletropneumática",
            status: "active",
            description: "Estabelece contatos térmicos e elétricos instantâneos reduzindo o tempo de conexão estática para 1 segundo."
          },
          {
            title: "Embaladora Holográfica com Impressão de Serial Dinâmico",
            type: "Termofita IoT",
            status: "proposed",
            description: "Integra o teste OK diretamente com a emissão do QR Code de rastreabilidade, acelerando a fase logística."
          }
        ],
        supportDocuments: [
          { name: "SOP-TST-022: Teste Estatístico Paramétrico sob Estresse de Temperatura", code: "SOP-TST-022", type: "SOP", rev: "F.1" },
          { name: "MNL-PKG-101: Normas de Embalagem para Exportações Marítimas", code: "MNL-PKG-101", type: "Manual", rev: "A.0" }
        ]
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "AOI Inspeção",
        metric: "Fração de rejeito em primeira passagem (FPP)",
        lcl: 0.88,
        ucl: 0.99,
        target: 0.96,
        frequency: "A cada lote de produção",
        responsible: "Técnico de Qualidade",
        reactionPlan: "Parar alimentação do forno, recalibrar bicos de deposição e rechecar vácuo.",
        currentReading: 0.94,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Montagem Mecânica",
        metric: "Lead time local da etapa",
        lcl: 3.5,
        ucl: 7.5,
        target: 5.5,
        frequency: "Monitoramento diário por amostra",
        responsible: "Líder de Célula",
        reactionPlan: "Efetuar rodízio de operadores fatigados e examinar ferramentas pneumáticas.",
        currentReading: 5.2,
        enableAlarm: true
      }
    ]
  },
  {
    id: "financial-ap",
    name: "Contas a Pagar (Procure-to-Pay)",
    category: "financeiro",
    icon: "💰",
    arrivalRate: 12,
    unitLabel: "fatura",
    unitLabelPlural: "faturas",
    charter: {
      title: "Otimização e Agilidade no Ciclo de Contas a Pagar",
      problemStatement: "Inconsistências no recebimento físico de mercadorias versus faturas emitidas geram atraso no matching bancário, acarretando juros de mora e perda de descontos para liquidação. Atualmente o Lead Time e filas de validação travam o processo.",
      goal: "Reduzir o tempo total de processamento médio de faturas em 50%, extinguir faturas enviadas à mesa do tesoureiro sem validação PO prévia, e elevar o Sigma das reconciliações a >3.8σ.",
      metric: "cycle_time",
      targetValue: 12
    },
    sipoc: {
      suppliers: "Fornecedores de insumos, prestadores de serviços, equipe de compras (Sourcing), setor de recebimento físico",
      inputs: "Notas fiscais (PDF/XML), Pedidos de Compra (PO), XMLs importados no ERP, canhoto de recebimento físico",
      processDescription: "Triagem de Documentos -> Reconciliação Three-Way -> Aprovação de Centros de Custos -> Agendamento no Banco -> Conciliação e Baixa",
      outputs: "Liquidação no ERP, arquivos bancários CNAB de pagamento, comprovantes salvos no GED, relatórios de provisionamento fiscal",
      customers: "Fornecedores comerciais, acionistas, equipe de controladoria interna, auditores fiscais"
    },
    steps: [
      {
        id: "step-1",
        name: "Triagem e Registro de Faturas",
        resource: "Assistente de Contas a Pagar",
        resourceCount: 1,
        processingTime: 5.0,
        standardDeviation: 1.2,
        yieldRate: 0.94,
        setupTime: 10,
        description: "Recebimento e digitalização prévia de faturas físicas ou recebimento automático de XMLs de faturamento no ERP.",
        requiredInputs: [
          "Notas Fiscais de Produto (NF-e) e Serviços (NFS-e)",
          "PDFs de faturas enviados por e-mail centralizado",
          "Acessos ativos ao ERP Totvs/SAP",
          "Tokens de certificação digital"
        ],
        stepInstructions: [
          "Coletar diariamente os documentos recebidos na caixa fiscal dedicada.",
          "Classificar faturas entre operacionais (OPEX) e bens de capital (CAPEX).",
          "Executar leitura de chave de acesso eletrônico no SEFAZ para confirmar autenticidade.",
          "Preencher cabeçalho inicial de pré-nota contábil com dados do emissor."
        ],
        automations: [
          {
            title: "Leitor OCR de OCR Inteligente de Faturas",
            type: "IA & Visão Contábil",
            status: "active",
            description: "Preenche automaticamente 90% dos dados cadastrais deduzindo CNPJ, valores e datas de vencimento eliminando redigitação manual."
          },
          {
            title: "Importador Direto de XML SEFAZ",
            type: "Robô de Integração API",
            status: "proposed",
            description: "Acopla diretamente no ERP a recepção em tempo real das notas emitidas contra o CNPJ corporativo, cortando o recebimento por papel."
          }
        ],
        supportDocuments: [
          { name: "SOP-FIN-010: Recebimento e Conferência de Documentos Fiscais", code: "SOP-FIN-010", type: "SOP", rev: "A.2" },
          { name: "CKL-FIN-02: Verificação Cadastral de Novos Fornecedores", code: "CKL-FIN-02", type: "Checklist", rev: "B.1" }
        ]
      },
      {
        id: "step-2",
        name: "Reconciliação Three-Way Matching",
        resource: "Analista de Contas a Pagar",
        resourceCount: 1,
        processingTime: 7.5,
        standardDeviation: 2.0,
        yieldRate: 0.88, // Focus of continuous quality improvement!
        setupTime: 5,
        description: "Validação tríplice de conformidade cadastral: Fatura vs. Pedido de Compra (PO) vs. Relatório de Entrada Física de Mercadoria.",
        requiredInputs: [
          "Pré-nota contábil cadastrada",
          "Pedido de compra (PO) ativo emitido pela área de Compras",
          "Comprovante de entrega física carregado pelo Almoxarifado"
        ],
        stepInstructions: [
          "Consultar se o valor bruto e unitário da fatura condiz com o acordado na Ordem de Compra.",
          "Verificar se a quantidade descrita na NF coincide com o saldo físico recebido nas docas.",
          "Em caso de divergência de valores acima de 1% tolerável, paralisar processo de pagamento.",
          "Entrar em contato com o departamento de compras para negociar carta de correção ou estorno."
        ],
        automations: [
          {
            title: "Parelhamento Tríplice Automatizado por ERP",
            type: "Sistemas ERP Core",
            status: "active",
            description: "Gera conciliação computadorizada instantânea em faturas de material produtivo padrão com PO indexado."
          },
          {
            title: "Resolvedor de Disparidades de Frete com Machine Learning",
            type: "Algoritmo de IA",
            status: "proposed",
            description: "Agrupa variabilidades de impostos estaduais em fretes (CT-e) e aprova autonomamente desvios de centavos, diminuindo pilhas em espera."
          }
        ],
        supportDocuments: [
          { name: "SOP-FIN-012: Manual de Resolução de Divergências em Compras", code: "SOP-FIN-012", type: "SOP", rev: "C.3" },
          { name: "FRM-FIN-055: Ficha de Reajuste Tributário em NF com Erros", code: "FRM-FIN-055", type: "Form", rev: "A.0" }
        ]
      },
      {
        id: "step-3",
        name: "Aprovação de Alçada & Centro de Custo",
        resource: "Gerente de Área Responsável",
        resourceCount: 1,
        processingTime: 4.0,
        standardDeviation: 1.5,
        yieldRate: 0.98,
        setupTime: 0,
        description: "Validação gerencial do direcionador financeiro e liberação orçamentária do centro de custos afetado.",
        requiredInputs: [
          "Fatura auditada e sem disparidades",
          "Centro de custos parametrizado adequadamente conforme o plano de contas",
          "Saldo orçamentário mensal livre para débito (Budget)"
        ],
        stepInstructions: [
          "Revisar o descritivo de despesas operacionais.",
          "Classificar despesas conforme contas contábeis de custeio vigentes.",
          "Aprovar a alçada de pagamentos conforme política de governança corporativa.",
          "Submeter documento aprovado eletronicamente para a mesa de agendamento bancário."
        ],
        automations: [
          {
            title: "Fluxo de Alçada Workflow no ERP",
            type: "Gerenciamento BPM",
            status: "active",
            description: "Roteia automaticamente a notificação de despesas para aprovação do respectivo diretor ou CEO conforme limites estabelecidos de valor."
          },
          {
            title: "Aprovação Integrada via Aplicativo Corporativo",
            type: "Notificação Mobile",
            status: "proposed",
            description: "Zera o tempo de espera do gerente enviando cartões de aprovação rápida em 1 clique via canais de mensagens corporativas."
          }
        ],
        supportDocuments: [
          { name: "SOP-CGN-01: Governança e Limites Descritivos de Alçada", code: "SOP-CGN-01", type: "SOP", rev: "E.1" }
        ]
      },
      {
        id: "step-4",
        name: "Agendamento e Liberação Bancária",
        resource: "Tesoureiro",
        resourceCount: 1,
        processingTime: 3.5,
        standardDeviation: 0.8,
        yieldRate: 0.995,
        setupTime: 12,
        description: "Consolidação de faturas em lotes de remessa CNAB para transmissão ao banco conveniado ou cadastramento direto em conta.",
        requiredInputs: [
          "Conjunto de faturas com alçadas gerenciais validadas",
          "Integração bancária via gateway digital ativa",
          "Dispositivo de segurança corporativa (MFA, Smartcards)"
        ],
        stepInstructions: [
          "Compilar as faturas aprovadas com vencimento correspondente às próximas 48h.",
          "Gerar o arquivo magnético padronizado CNAB 240 de pagamento.",
          "Efetuar o upload do arquivo na interface da instituição parceira (Internet Banking).",
          "Executar a validação por assinatura conjunta (duplo fator de controle da tesouraria)."
        ],
        automations: [
          {
            title: "Transmissão Automática de Arquivo API Bancário",
            type: "Integração Open Finance",
            status: "active",
            description: "Transmite as remessas de forma contínua do ERP aos bancos parceiros assim que validadas, descartando transferências de arquivo manuais."
          },
          {
            title: "Auditória Preventiva Anti-Fraude de Boletos",
            type: "Cibersegurança & Dados",
            status: "proposed",
            description: "Valida de forma estocástica e computorizada antes do envio se o beneficiário do boleto confere com o CNPJ cadastrado na NF original, eliminando golpes tributários."
          }
        ],
        supportDocuments: [
          { name: "SOP-TES-04: Fluxos de Segurança Bancária e Conciliação CNAB", code: "SOP-TES-04", type: "SOP", rev: "D.2" }
        ]
      },
      {
        id: "step-5",
        name: "Conciliação e Arquivamento",
        resource: "Auxiliar de Contas a Pagar",
        resourceCount: 1,
        processingTime: 4.5,
        standardDeviation: 1.0,
        yieldRate: 0.98,
        setupTime: 0,
        description: "Importação do extrato de liquidação financeira e amarração fiscal contábil das faturas liquidadas.",
        requiredInputs: [
          "Extrato bancário consolidado de saídas diárias",
          "Relatórios de execução da remessa do tesoureiro",
          "Sistema GED (Gestão de Documentos Digitais) disponível"
        ],
        stepInstructions: [
          "Importar o arquivo de retorno bancário no sistema ERP.",
          "Verificar se o débito em extrato concilia com a baixa contábil provisionada.",
          "Vincular digitalmente o comprovante individual de transação com a nota no servidor.",
          "Arquivar fisicamente os canhotos residuais e atualizar o log diário de compliance financeiro."
        ],
        automations: [
          {
            title: "Baixa Automatizada por Retorno de Retorno Bancário",
            type: "Sistemas EDI",
            status: "active",
            description: "Baixa eletronicamente no sistema SAP/Totvs todas as faturas constantes em arquivo de retorno de liquidação com absoluto rigor."
          },
          {
            title: "Indexador Inteligente em Nuvem (DMS)",
            type: "Content Management",
            status: "proposed",
            description: "Classifica e arquiva os comprovantes correspondentes em pastas na nuvem baseadas em chaves primárias, acelerando futuros acessos de auditoria em 90%."
          }
        ],
        supportDocuments: [
          { name: "SOP-FIN-08: Armazenamento e Rastreabilidade Documental Financeira", code: "SOP-FIN-08", type: "SOP", rev: "B.0" }
        ]
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "Reconciliação Three-Way Matching",
        metric: "Fração de Notas Aprovadas de Primeira no Matching",
        lcl: 0.80,
        ucl: 0.98,
        target: 0.95,
        frequency: "Semanal",
        responsible: "Analista de Contas a Pagar",
        reactionPlan: "Acionar setor de Compras para rever alistamentos e paralisar pedidos se fornecedores recorrentemente errarem faturamento.",
        currentReading: 0.89,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Agendamento Tesouraria",
        metric: "Erros de agendamento ou Boletos rejeitados",
        lcl: 0,
        ucl: 0.05,
        target: 0.01,
        frequency: "Diária",
        responsible: "Tesoureiro-Chefe",
        reactionPlan: "Parar remessa secundária, efetuar varredura de chaves PIX/Código de barras cadastradas incorretamente e punir desvios operacionais.",
        currentReading: 0.02,
        enableAlarm: true
      }
    ]
  },
  {
    id: "accounting-close",
    name: "Fechamento Contábil Mensal (Fast Close)",
    category: "contabil",
    icon: "📈",
    arrivalRate: 8,
    unitLabel: "reconciliação",
    unitLabelPlural: "reconciliações",
    charter: {
      title: "Fast Close: Aceleração do Fechamento Contábil Mensal",
      problemStatement: "O encerramento do livro fiscal e contábil tem demorado até 10 dias úteis (Lead Time excessivo de espera), derivado de conciliações em planilhas desconexas, atrasos na provisão de folha de pagamento e acertos intercompany pendentes.",
      goal: "Otimizar o fluxo de fechamento eliminando tempos mortos, reduzindo o Lead Time para 4.5 dias de trabalho real e estabilizando a assertividade das reconciliações finais acima de 98% de primeira (Nível Sigma >3.7σ).",
      metric: "throughput",
      targetValue: 20
    },
    sipoc: {
      suppliers: "Contabilidade, Tesouraria, Faturamento de Vendas, Departamento Pessoal (DP), Administradores de Subsidiárias",
      inputs: "Extratos bancários consolidados, provisões salariais do RH, inventário de ativos fixos e almoxarifados, balancetes parciais das filiais",
      processDescription: "Ajuste e Conciliação Bancária -> Provisões e Amortizações -> Ajustes Intercompany -> Revisão Analítica de Balancetes -> Publicação de Relatórios Finais",
      outputs: "Livro diário fechado corporativo, Demonstração do Resultado (DRE), Balanço Patrimonial consolidado, Demonstração de Fluxo de Caixa (DFC)",
      customers: "Diretoria executiva (C-Suite), Conselho de Administração, Acionistas e Sócios, Auditores Externos"
    },
    steps: [
      {
        id: "step-1",
        name: "Conciliação Bancária e de Sub-Razões",
        resource: "Assistente de Contabilidade",
        resourceCount: 1,
        processingTime: 8.0,
        standardDeviation: 2.2,
        yieldRate: 0.92,
        setupTime: 20,
        description: "Conferência e match estatístico de lançamentos em contas correntes bancárias versus razonetes internos de conciliação do ERP.",
        requiredInputs: [
          "Extratos bancários em formato OFX/TXT das contas bancárias",
          "Razão acumulado de tesouraria do mês",
          "Política de alocação de tarifas bancárias padrão"
        ],
        stepInstructions: [
          "Importar e cruzar os arquivos de extrato financeiro OFX de todos os bancos com o razão.",
          "Verificar se as saídas para pagamento de fornecedores combinam com tarifas e IOF debitados.",
          "Isolar depósitos não identificados em contas transitórias para apuração posterior.",
          "Estabilizar saldo conciliado batendo centavo por centavo com saldo final de extrato."
        ],
        automations: [
          {
            title: "Conciliador Automático Computacional OFX",
            type: "Robô RPA Contábil",
            status: "active",
            description: "Localiza e efetua o aceite automático de transações com mesmo valor e data correspondente no razão em até 85% dos casos."
          },
          {
            title: "Tratador de Depósitos Identificados por IA",
            type: "IA de Classificação",
            status: "proposed",
            description: "Analisa o descritivo de texto do extrato bancário (ex: transações de clientes) e sugere a contrapartida de recebimento no contas a receber, reduzindo a fila de suspensos contábeis."
          }
        ],
        supportDocuments: [
          { name: "SOP-CON-001: Normas Técnicas para Conciliação de Contas Patrimoniais", code: "SOP-CON-001", type: "SOP", rev: "B.4" },
          { name: "CKL-CON-10: Verificação de Fechamento de Saldos Bancários", code: "CKL-CON-10", type: "Checklist", rev: "A.3" }
        ]
      },
      {
        id: "step-2",
        name: "Lançamento de Provisões, Depreciação e Amortização",
        resource: "Analista de Contabilidade",
        resourceCount: 1,
        processingTime: 10.0,
        standardDeviation: 3.0,
        yieldRate: 0.95,
        setupTime: 15,
        description: "Registro de provisões financeiras, apropriação de despesas antecipadas (Seguros/IPVA) e rodada mensal de cálculo de depreciação e ativo fixo.",
        requiredInputs: [
          "Planilha consolidada de provisões de folha enviada pelo DP",
          "Módulo de Ativo Imobilizado habilitado no ERP",
          "Cronograma de prêmios de seguro e despesas diferidas"
        ],
        stepInstructions: [
          "Checar relatórios de provisão de férias, 13º salário e rescisões contratuais do DP.",
          "Executar o processamento automático da curva de depreciação de bens ativos (máquinas, veículos) no almoxarifado contábil.",
          "Provisionar despesas com serviços prestados e não faturados do mês atual (Accruals).",
          "Bater saldo provisionado com contas de contrapartida de resultado operacional."
        ],
        automations: [
          {
            title: "Rotina de Depreciação Integrada no ERP",
            type: "Sistemas Corporativos SAP/Totvs",
            status: "active",
            description: "Gera trimestral ou mensalmente as depreciações do ativo fixo baseadas na tabela padrão de vidas úteis de forma controlada."
          },
          {
            title: "Apropriação Automatizada de Despesas Diferidas",
            type: "Lógica de Ledger",
            status: "proposed",
            description: "Reconhece o rateio mensal de seguros e assinaturas amortizando instantaneamente o ativo circulante, eximindo o fechamento manual do analista."
          }
        ],
        supportDocuments: [
          { name: "SOP-CON-005: Normas de Depreciação e Apuração de Ativos Fixos", code: "SOP-CON-005", type: "SOP", rev: "C.1" }
        ]
      },
      {
        id: "step-3",
        name: "Ajustes Intercompany & Consolidação",
        resource: "Especialista de Consolidação",
        resourceCount: 1,
        processingTime: 12.0,
        standardDeviation: 4.0,
        yieldRate: 0.88, // Focus of fast close quality issues due to intercompany imbalances!
        setupTime: 30,
        description: "Eliminação de transações recíprocas entre filiais ou coligadas do grupo e equalização cambial de investimentos coligados.",
        requiredInputs: [
          "Balancetes individuais de cada de controle de subsidiárias",
          "Relatório de transações intercompanhia emitidas pelo faturamento",
          "Bordero de acertos cambiais mutúos corporativos"
        ],
        stepInstructions: [
          "Escanear todas as vendas intercompany de matéria prima ou transferência de estoques.",
          "Combinar se a receita registrada pela controladora coincide perfeitamente com o custo de estoque contabilizado pela controlada.",
          "Isolar desvios em contas de trânsito em moeda estrangeira e registrar equivalência patrimonial líquida.",
          "Lançar as eliminações finais no ledger consolidado para expurgar a inflação interna de faturamento corporativo."
        ],
        automations: [
          {
            title: "Gabarito de Eliminação Intercompany no Ledger SAP",
            type: "ERP Multiledger Engine",
            status: "active",
            description: "Identifica chaves recíprocas gerando eliminação patrimonial imediata caso localizadas sem diferença cambial severa."
          },
          {
            title: "Robô de Validação Cruzada Intercompany",
            type: "Robótica de Auditoria",
            status: "proposed",
            description: "Dispara alertas preventivos a cada 48h durante o mês caso detecte faturamento a filiais pendente de aceitação de custo contábil do outro lado, antecipando o gargalo."
          }
        ],
        supportDocuments: [
          { name: "SOP-CON-012: Manual de Práticas de Consolidação e Eliminações", code: "SOP-CON-012", type: "SOP", rev: "D.0" },
          { name: "FRM-CON-022: Relatório de Desvios Intercompany Pendentes", code: "FRM-CON-022", type: "Form", rev: "B.3" }
        ]
      },
      {
        id: "step-4",
        name: "Revisão Analítica de Balancetes e Auditoria",
        resource: "Coordenador de Contabilidade",
        resourceCount: 1,
        processingTime: 6.5,
        standardDeviation: 1.8,
        yieldRate: 0.97,
        setupTime: 0,
        description: "Revisão comparativa das variações do balancete atual contra o mês anterior ou budget histórico (MoM/YoY Variance Analysis).",
        requiredInputs: [
          "Balancete consolidado prévio",
          "Razão contábil analítico integrado",
          "Ferramenta de cruzamento de dados estatísticos (PowerBI / Excel)"
        ],
        stepInstructions: [
          "Gerar comparativo por centro de custo para o mês anterior e o budget previsto.",
          "Avaliar oscilações de despesa maiores que R$ 20.000 ou 10% de flutuação parametrizada.",
          "Intimar os donos de budget setoriais a explicar estouros pontuais de gasto de manutenção ou logística.",
          "Assinar balancete provisório após confirmar correções de reclassificação orçamentária necessárias."
        ],
        automations: [
          {
            title: "Auditoria Paramétrica de Balancete",
            type: "Ciência de Dados & BI",
            status: "active",
            description: "Destaque automático de distorções significativas de saldos contábeis via desvio estatístico do balanço padrão."
          },
          {
            title: "Detetor de Variância Baseado em IA Generativa",
            type: "Deep Learning (IA)",
            status: "proposed",
            description: "Gera notas explicativas preliminares com análise descritiva em texto das oscilações de contas, minimizando esforço de redação técnica."
          }
        ],
        supportDocuments: [
          { name: "SOP-AUD-005: Normas de Revisão Analítica e Variance Analysis", code: "SOP-AUD-005", type: "SOP", rev: "C.4" }
        ]
      },
      {
        id: "step-5",
        name: "Encerramento e Emissão de Demonstrações",
        resource: "Gerente de Controladoria",
        resourceCount: 1,
        processingTime: 5.0,
        standardDeviation: 1.0,
        yieldRate: 0.99,
        setupTime: 5,
        description: "Bloqueio do período fiscal contábil nas transações do banco de dados ERP e emissão oficial dos relatórios financeiros de auditoria.",
        requiredInputs: [
          "Balancete reconciliado e assinado preliminarmente",
          "Plano de Notas Explicativas preliminares",
          "Módulo de encerramento eletrônico e travas executórias ERP"
        ],
        stepInstructions: [
          "Travar o lançamento retroativo no banco de dados ERP impedindo lançamentos manuais no período fechado.",
          "Submeter relatórios finais (Balanço, DRE, DFC) ao validador societário digital.",
          "Despachar as demonstrações aos escritórios de auditoria externa parceiros.",
          "Disponibilizar os resultados consolidados em repositórios da transparência institucional corporativa."
        ],
        automations: [
          {
            title: "Geração Automatizada de Pacote Regulatório",
            type: "Sistemas ERP Consolidation",
            status: "active",
            description: "Formata e expede os dados do Balancete diretamente em padrão societário com total rigor formal em segundos."
          },
          {
            title: "Blockchain Ledger Sign",
            type: "Criptografia Distribuída",
            status: "proposed",
            description: "Sela o livro diário contábil com chaves imutáveis em rede segura interna, garantindo que nenhum ajuste impróprio viole a integridade retroativa pós-fechamento."
          }
        ],
        supportDocuments: [
          { name: "MNL-CON-100: Manual de Divulgação Societária e Relação com Auditores", code: "MNL-CON-100", type: "Manual", rev: "G.1" }
        ]
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "Conciliação Bancária",
        metric: "Fração de contas conciliadas dentro de 48h úteis do dia D",
        lcl: 0.85,
        ucl: 1.0,
        target: 0.98,
        frequency: "Semanal",
        responsible: "Coordenador de Contabilidade",
        reactionPlan: "Acionar auditoria de extratos urgentes de transações não correspondidas junto ao banco e notificar supervisor de tesouraria.",
        currentReading: 0.93,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Revisão do Balancete",
        metric: "Erro contábil material ou reclassificação pós-trava",
        lcl: 0,
        ucl: 0.02,
        target: 0,
        frequency: "Mental por rodada",
        responsible: "Gerente de Controladoria",
        reactionPlan: "Parar a rotina de emissão societária, abrir exceção controlada via auditor de TI e registrar adendo retificador fundamentado.",
        currentReading: 0.01,
        enableAlarm: true
      }
    ]
  },
  {
    id: "tax-compliance",
    name: "Legal e Compliance Fiscal (Tributário)",
    category: "fiscal",
    icon: "⚖️",
    arrivalRate: 6,
    unitLabel: "documento",
    unitLabelPlural: "documentos",
    charter: {
      title: "Compliance Tributário e Saneamento de Documentos Fiscais",
      problemStatement: "Múltiplas notas de entrada capturadas com tributação (alíquotas de ICMS, PIS, COFINS e substituição tributária) incorretas geram travamento no validador oficial do SPED do Governo (PVA), gerando risco severo de multas e pesada carga de retrabalho com retificações operacionais.",
      goal: "Minimizar erros de validação SPED (elevar yield de primeira passagem para > 95%), otimizar os tempos de apuração de tributos indiretos e diretos, e reduzir o desvio padrão de processamento fiscal em 40%.",
      metric: "defect_rate",
      targetValue: 3
    },
    sipoc: {
      suppliers: "Almoxarifado contábil (Faturamento físico), Setor de Faturamento e Vendas, Setor Jurídico, Fornecedores",
      inputs: "Notas fiscais (XML NF-e, CT-e), regras de apuração municipais (ISS), cadastros de NCM (Nomenclatura do Mercosul), tabelas de alíquota",
      processDescription: "Saneamento de Entrada Fiscal -> Apuração de Impostos Indiretos -> Apuração de Impostos Diretos e Retenções -> Geração e Validação do Arquivo SPED -> Emissão de Guias de Arrecadação",
      outputs: "Apurações consolidadas tributárias, arquivos fiscais transmitidos (EFD, SPED Fiscal), declarações de compensação, guias de pagamento (DAS/DARF/GNRE)",
      customers: "Fisco Federal / Estadual / Municipal (Receita Federal), controller corporativo, gestor financeiro da tesouraria"
    },
    steps: [
      {
        id: "step-1",
        name: "Recebimento e Saneamento Tributário de Notas",
        resource: "Assistente Fiscal",
        resourceCount: 1,
        processingTime: 6.0,
        standardDeviation: 2.0,
        yieldRate: 0.91,
        setupTime: 10,
        description: "Captura de XMLs de terceiros e triagem das notas fiscais de entrada cruzando com a base de regras e NCMs corporativos autorizados.",
        requiredInputs: [
          "XMLs de Notas fiscais de produto (NF-e) emitidas contra a empresa",
          "Dossiê cadastral de NCMs e códigos de tributação (CST/CFOP)",
          "Planilha base de alíquotas fiscais ativas"
        ],
        stepInstructions: [
          "Varrer o banco de dados de recepção de notas de mercadorias contratadas.",
          "Verificar se a Classificação Fiscal do NCM cadastrada pelo fornecedor está regular na tabela do IPI.",
          "Examinar se o código de CFOP (Operação) corresponde ao direito a crédito fiscal de ICMS legítimo.",
          "Corrigir cadastros tributários e enviar as notas saneadas para apuração."
        ],
        automations: [
          {
            title: "Auditor Eletrônico de Regras Fiscais",
            type: "Validador de Banco de Dados",
            status: "active",
            description: "Critica automaticamente campos chave da nota (NCM, CST, alíquota de ICMS) cruzando com as bases vigentes antes do registro físico."
          },
          {
            title: "Classificador de Código Tributário Automatizado por NCM",
            type: "Machine Learning (Dados)",
            status: "proposed",
            description: "Analisa a descrição física do produto e auto-associa o CST e alíquotas para crédito, minimizando buscas em manuais do fisco em até 95%."
          }
        ],
        supportDocuments: [
          { name: "SOP-TAX-01: Conferência de NCMs e parametrização de CFOP", code: "SOP-TAX-01", type: "SOP", rev: "A.3" },
          { name: "FRM-TAX-05: Ficha de Ajuste Cadastral de Produtos para Fornecedores", code: "FRM-TAX-05", type: "Form", rev: "B.0" }
        ]
      },
      {
        id: "step-2",
        name: "Apuração de Tributos Indiretos",
        resource: "Analista de Impostos Indiretos",
        resourceCount: 1,
        processingTime: 9.0,
        standardDeviation: 2.5,
        yieldRate: 0.96,
        setupTime: 15,
        description: "Consolidação dos livros de registros de entradas e saídas e cálculo do saldo credor/devedor de impostos não-cumulativos (ICMS, IPI, PIS, COFINS).",
        requiredInputs: [
          "Bancos de dados consolidados de faturamento do mês",
          "Notas saneadas de entradas registradas com direito a creditamento",
          "Tabela de diferimentos e regimes especiais vigentes"
        ],
        stepInstructions: [
          "Consolidar as notas fiscais de vendas e faturamento industrial.",
          "Calcular o montante de débito de ICMS e correlacionar com notas fiscais creditáveis.",
          "Efetuar equalização de PIS e COFINS conforme regime de apuração de lucro real mensal.",
          "Emitir o relatório analítico parcial de débitos e créditos com respectivas conciliações."
        ],
        automations: [
          {
            title: "Calculadora de Indiretos Automática no ERP",
            type: "Mecanismo Fiscal do ERP",
            status: "active",
            description: "Roda rotinas de creditamento e débito integradas ao ledger fiscal do faturamento automaticamente."
          },
          {
            title: "Consolidador Open-Credit Baseado em BI",
            type: "Análise de Processamentos",
            status: "proposed",
            description: "Identifica de forma estocástica e paramétrica possíveis créditos residuais de ICMS monofásico em faturas não computados pelo analista."
          }
        ],
        supportDocuments: [
          { name: "SOP-TAX-04: Apuração e Creditamento de ICMS e IPI", code: "SOP-TAX-04", type: "SOP", rev: "C.1" }
        ]
      },
      {
        id: "step-3",
        name: "Apuração de Impostos Diretos e Retenções",
        resource: "Analista de Impostos Diretos",
        resourceCount: 1,
        processingTime: 11.0,
        standardDeviation: 3.2,
        yieldRate: 0.95,
        setupTime: 20,
        description: "Cálculo de alíquotas corporativas de IRPJ, CSLL com base no Lucro Real Trimestral/Mensal e retenções fiscais na fonte do contas a pagar (CSRF, INSS, IRRF).",
        requiredInputs: [
          "Demonstração do Resultado Contábil (DRE) provisória reconciliada",
          "Relatório de adições e exclusões fiscais (Livro LALUR/LACS)",
          "Boleto analítico de prestação de serviços terceiros na fonte"
        ],
        stepInstructions: [
          "Coletar dados de receitas líquidas contábeis do balancete consolidado.",
          "Lançar adições de provisões não-dedutíveis e exclusões de receitas de equivalência no LALUR digital.",
          "Calcular a parcela de CSLL (9%) e IRPJ progressivo com adicional de 10%.",
          "Gerar relatório consolidado de retenções retidas contra subcontratados do mês."
        ],
        automations: [
          {
            title: "Módulo de Lalur Computadorizado",
            type: "Regulamento Fiscal ERP",
            status: "active",
            description: "Gera a ponte direta das contas do DRE para a base tributada de Lalur de modo integrado e preciso."
          },
          {
            title: "Rastreador de Retenções Inteligente",
            type: "Web Scraper / API",
            status: "proposed",
            description: "Verifica em tempo de matching se as autuações exigem retenção de INSS na fonte e bloqueia o faturamento preventivamente se incorreto, salvaguardando o analista."
          }
        ],
        supportDocuments: [
          { name: "SOP-TAX-10: Apuração de CSLL e IRPJ pelo Lucro Real", code: "SOP-TAX-10", type: "SOP", rev: "A.4" }
        ]
      },
      {
        id: "step-4",
        name: "Geração e Validação do SPED Fiscal e EFD",
        resource: "Especialista Fiscal",
        resourceCount: 1,
        processingTime: 14.0,
        standardDeviation: 4.5,
        yieldRate: 0.85, // Main quality hazard in tax departments!
        setupTime: 40,
        description: "Estruturação dos layouts magnéticos das declarações SPED, cruzamento de blocos de dados internos do SPED e rodadas no PVA para validação.",
        requiredInputs: [
          "Bases consolidadas de livros de indiretos e diretos",
          "Arquivos de movimentação física do estoque (Bloco K)",
          "Software validador oficial do PVA do governo em máquina servidora"
        ],
        stepInstructions: [
          "Exportar arquivos de leiaute magnético EFD ICMS/IPI e EFD Contribuições do ERP.",
          "Efetuar carga dos arquivos no software validador PVA correspondente do governo.",
          "Analisar pontes de divergências de lançamentos fiscais de blocos (ex: Bloco C vs Bloco H).",
          "Apropriar eventuais cartas de correção e sanar inconsistências residuais de chaves de acesso eletrônicos."
        ],
        automations: [
          {
            title: "Integrador SPED Conector",
            type: "Robô de Integração",
            status: "active",
            description: "Transfere os lotes para o portal do governo e simula a validação estrutural do documento sem precisar do PVA manual."
          },
          {
            title: "Auditor Duplo Cruzador Sped Inteligente (AI)",
            type: "Ciência de Dados",
            status: "proposed",
            description: "Prepara auditoria profunda cruzando SPED Fiscal, Sped Contribuições e XMLs em tempo real notificando emissores de erros em 3 segundos."
          }
        ],
        supportDocuments: [
          { name: "SOP-TAX-22: Transmissão de Guias e Validação do Bloco K do SPED", code: "SOP-TAX-22", type: "SOP", rev: "D.3" },
          { name: "CKL-TAX-104: Lista para Checagem Manual de Blocos SPF", code: "CKL-TAX-104", type: "Checklist", rev: "B.0" }
        ]
      },
      {
        id: "step-5",
        name: "Emissão de Guias de Recolhimento e Pagamento",
        resource: "Analista Financeiro / Fiscal",
        resourceCount: 1,
        processingTime: 4.0,
        standardDeviation: 1.1,
        yieldRate: 0.995,
        setupTime: 5,
        description: "Geração das guias de arrecadação compensação governamentais (DARF, GARE, GNRE, DAE) com encaminhamento e baixa na tesouraria bancária bancária.",
        requiredInputs: [
          "Arquivos do SPED e guias homologadas",
          "Portal Sicalc/Sefaz ativo para preenchimento dos códigos",
          "Dispositivo de liberação de pagamentos"
        ],
        stepInstructions: [
          "Acessar os portais estaduais/federais fiscais e emitir guias com os valores de impostos apurados.",
          "Verificar se os códigos de recolhimento tributários estão perfeitamente preenchidos.",
          "Preencher e-mail com guia em anexo e enviar o boleto para agendamento financeiro bancário.",
          "Anexar a guia contendo autenticação eletrônica de pagamento do banco no ledger de controle societário."
        ],
        automations: [
          {
            title: "Emissor de DARF Automático Sicalc API",
            type: "RPA Integration Web",
            status: "active",
            description: "Consome APIs municipais/estaduais fiscais e auto-gera as guias compensáveis em lotes estruturados, eliminando preenchimento manual de site do faturamento."
          },
          {
            title: "Compensador Automático de DCTFWeb",
            type: "Sistemas Digitais Governamentais",
            status: "proposed",
            description: "Conecta o saldo credor de autuações e compensa de forma síncrona na DCTFWeb sem intervenção de pessoal."
          }
        ],
        supportDocuments: [
          { name: "SOP-TAX-30: Conciliação Bancária de Impostos Pagos e Guias de DARF", code: "SOP-TAX-30", type: "SOP", rev: "A.3" }
        ]
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "Apuração e Saneamento de Notas",
        metric: "Fração de NFs recebidas limpas sem reajuste de CST",
        lcl: 0.85,
        ucl: 1.0,
        target: 0.95,
        frequency: "Semanal",
        responsible: "Coordenador de Cadastro Fiscal",
        reactionPlan: "Notificar setor de compras contatando o fornecedor para que altere a matriz tributária de emissão de NF imediatamente.",
        currentReading: 0.91,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Validação SPED Fiscal",
        metric: "Arquivos rejeitados por erro estrutural de bloco PVA",
        lcl: 0,
        ucl: 0.05,
        target: 0,
        frequency: "Por entrega mensal",
        responsible: "Especialista Fiscal Consolidado",
        reactionPlan: "Interromper rotinas acessórias, recalibrar gerador de Bloco K do almoxarifado contábil e rodar auditoria relâmpago de saldos patrimoniais.",
        currentReading: 0.03,
        enableAlarm: true
      }
    ]
  },
  {
    id: "retail-checkout",
    name: "Supermercado / Checkout & PDV",
    category: "comercio",
    icon: "🛒",
    arrivalRate: 35,
    unitLabel: "cliente",
    unitLabelPlural: "clientes",
    charter: {
      title: "Otimização de Fila & Tempo de Espera no Checkout de Vendas",
      problemStatement: "Clientes enfrentam longas filas no checkout nos horários de pico. Isso provoca abandono de carrinhos de compra, sobrecarga dos operadores e queda de 15% no índice local de satisfação NPS.",
      goal: "Reduzir o tempo médio de fila em 45%, estabilizar o tempo de atendimento individual sob 2.2 minutos e atingir 98.7% de transações corretas no caixa sem erros de precificação.",
      metric: "cycle_time",
      targetValue: 2.2
    },
    sipoc: {
      suppliers: "Consumidores finais no recinto, estoquistas de gôndola, suporte de TI de PDV",
      inputs: "Lista de compras físicas, cartões/PIX, sacolas biodegradáveis, bobinas térmicas de cupom",
      processDescription: "Fila de Atendimento -> Identificação de Cadastro -> Escaneamento de Itens -> Pagamento TEF/Dinheiro -> Empacotamento & Entrega",
      outputs: "Clientes faturados liberados, registro fiscal XML transmitido ao Sefaz, baixas de estoque real-time",
      customers: "Compradores locais e famílias da microrregião de comércio"
    },
    steps: [
      {
        id: "step-1",
        name: "Identificação do Cliente & Convênio",
        resource: "Operador de Caixa",
        resourceCount: 5,
        processingTime: 0.6,
        standardDeviation: 0.15,
        yieldRate: 0.99,
        setupTime: 0,
        description: "Coleta do CPF para fins fiscais e ativação de convênios/programas de fidelidade.",
        requiredInputs: ["Documento CPF / App Fidelidade do Cliente", "Terminal PDV ativo integrado ao CRM"],
        stepInstructions: [
          "Cumprimentar cordialmente o cliente com foco no tom prestativo.",
          "Perguntar de forma clara se deseja CPF na nota e programa de pontos locais.",
          "Efetuar a leitura do código de barras do aplicativo no smartphone ou digitar o CPF."
        ],
        automations: [
          {
            title: "Reconhecimento Biométrico/CRM Sutil",
            type: "Fidelidade Digital S/A",
            status: "proposed",
            description: "Permite pré-carregar os dados cadastrais do comprador antes mesmo de atingir a esteira avançando o fluxo."
          }
        ],
        supportDocuments: [
          { name: "SOP-PDV-01: Protocolo de Atendimento e Fidelização", code: "SOP-PDV-01", type: "SOP", rev: "A.1" }
        ],
        x: 100,
        y: 80,
        shapeType: "START",
        nextStepId: "step-2"
      },
      {
        id: "step-2",
        name: "Escaneamento de Sacolas & Contagem",
        resource: "Leitor Óptico / Operador",
        resourceCount: 5,
        processingTime: 1.4,
        standardDeviation: 0.4,
        yieldRate: 0.97,
        setupTime: 1,
        description: "Bipagem mecânica dos produtos da esteira de alimentos ou vestuários no balcão.",
        requiredInputs: ["Itens no carrinho do cliente", "Leitor de código de barras Honeywell laser calibrado", "Balança integrada de pesagem de hortifrúti"],
        stepInstructions: [
          "Puxar os itens do carrinho em direção ao feixe de laser da esteira consecutiva.",
          "Verificar itens sem etiqueta ou com códigos corrompidos ligando para central se necessário.",
          "Pesar itens de mercearia e hortifrúti diretamente na balança homologada do balcão.",
          "Garantir manuseio cuidadoso de vidros e garrafas frágeis."
        ],
        automations: [
          {
            title: "Leitor Omnidirecional Inteligente",
            type: "Visão Laser Inteligente",
            status: "active",
            description: "Lê o código em qualquer ângulo, reduzindo o esforço físico repetitivo de giro de embalagens."
          }
        ],
        supportDocuments: [
          { name: "CKL-PDV-04: Calibração de Precisão de Balança", code: "CKL-PDV-04", type: "Checklist", rev: "B.2" }
        ],
        x: 320,
        y: 80,
        shapeType: "ACTIVITY",
        nextStepId: "step-3"
      },
      {
        id: "step-3",
        name: "Processamento de Pagamento & TEF",
        resource: "Adquirente PinPad",
        resourceCount: 5,
        processingTime: 0.8,
        standardDeviation: 0.25,
        yieldRate: 0.96,
        setupTime: 0,
        description: "Autenticação bancária de cartões de débito, crédito ou geração de QR-Code dinâmico de PIX.",
        requiredInputs: ["Subtotal calculado na tela do PDV", "Dispositivo PinPad homologado PCI integrado", "Banda de rede dedicada estável"],
        stepInstructions: [
          "Anunciar o valor definitivo calculado pelo sistema.",
          "Selecionar o modo de pagamento instruído (Pix, débito, crédito ou vales).",
          "Acompanhar a aprovação bancária real-time sem reter o cartão do consumidor."
        ],
        automations: [
          {
            title: "Aprovação por Aproximação Excedente (NFC/Contactless)",
            type: "Rede Integrada de Pagamento",
            status: "active",
            description: "Reduz o tempo de inserção de senha de cartões para compras de baixo tíquete corporativo."
          }
        ],
        supportDocuments: [
          { name: "SOP-PDV-12: Contingência em Quedas de Rede TEF de Varejo", code: "SOP-PDV-12", type: "SOP", rev: "A.0" }
        ],
        x: 540,
        y: 80,
        shapeType: "DECISION",
        yesStepId: "step-4",
        noStepId: "step-2"
      },
      {
        id: "step-4",
        name: "Empacotamento & Sacolas",
        resource: "Empacotador Colaborador",
        resourceCount: 3,
        processingTime: 1.0,
        standardDeviation: 0.3,
        yieldRate: 0.99,
        setupTime: 2,
        description: "Acomodação ótima das mercadorias em sacolas plásticas ou caixas protetoras.",
        requiredInputs: ["Produtos bipados aprovados", "Sacolas reforçadas disponíveis em bobinas de suporte"],
        stepInstructions: [
          "Separar frios, carnes e químicos de produtos secos de alimentação.",
          "Alocar produtos mais pesados na base do empacotamento para segurança.",
          "Auxiliar ativamente idosos e gestantes a colocar sacolas no carrinho."
        ],
        automations: [
          {
            title: "Bancada Ergonômica Rotativa",
            type: "Equipamentos Gerais Varejo",
            status: "proposed",
            description: "Desliza as sacolas fechadas automaticamente por gravidade diminuindo pausas do operador anterior."
          }
        ],
        supportDocuments: [
          { name: "MNL-ECO-03: Ergonomia e Embalagem Sustentável", code: "MNL-ECO-03", type: "Manual", rev: "C.0" }
        ],
        x: 760,
        y: 80,
        shapeType: "ACTIVITY",
        nextStepId: "step-5"
      },
      {
        id: "step-5",
        name: "Transmissão Fiscal & Entrega de Cupom",
        resource: "Impressora Térmica",
        resourceCount: 5,
        processingTime: 0.4,
        standardDeviation: 0.1,
        yieldRate: 0.99,
        setupTime: 1,
        description: "Impressão da NFC-e e desfecho da jornada com agradecimento.",
        requiredInputs: ["Sinal de aprovação bancária e do servidor fiscal", "Bobina de papel térmico de 80mm"],
        stepInstructions: [
          "Aguardar a ejeção do cupom fiscal emitido.",
          "Entregar a via ao cliente junto aos agradecimentos finais recomendados pela gerência."
        ],
        automations: [],
        supportDocuments: [],
        x: 980,
        y: 80,
        shapeType: "END"
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "Controle de Fila no Pico",
        metric: "Quantidade de Clientes na Fila Principal",
        lcl: 0,
        ucl: 5,
        target: 3,
        frequency: "De Hora em Hora",
        responsible: "Subgerente de Loja",
        reactionPlan: "Acionar gatilho de caixa de apoio volante se houver mais de 4 pessoas em fila consecutiva por mais de 5 minutos.",
        currentReading: 2,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Registro de Sacola Danificada",
        metric: "Índice de retrabalho de empacotamento com rasgo de filme plástico",
        lcl: 0,
        ucl: 0.02,
        target: 0.005,
        frequency: "Diário",
        responsible: "Auditor de Qualidade Comercial",
        reactionPlan: "Substituir lote de bobina de sacolas de fornecedores sob suspeita de baixa resistência ao peso padrão.",
        currentReading: 0.008,
        enableAlarm: true
      }
    ]
  },
  {
    id: "logistics-fulfillment",
    name: "Logística / Fulfillment de E-commerce",
    category: "logistica",
    icon: "📦",
    arrivalRate: 20,
    unitLabel: "pedido",
    unitLabelPlural: "pedidos",
    charter: {
      title: "Estabilização e Compressão do Tempo de Fulfillment de Pedidos",
      problemStatement: "Fulfillment de vendas eletrônicas apresenta elevado tempo total de processamento interno (>110 minutos). Isso provoca quebra de promessa de entrega de frete rápido (OTD), multas com marketplaces e desordem na área operacional.",
      goal: "Reduzir o Lead Time interno para menos de 18 minutos de média, mitigar o desvio padrão de velocidade de expedição e alcançar taxa de erros de separação inferior a 0.5% (Picking Accuracy).",
      metric: "cycle_time",
      targetValue: 18.0
    },
    sipoc: {
      suppliers: "Loja e-commerce integradora, controle de estoque (inventário), compras de suprimentos",
      inputs: "Lista consolidada de pedidos no WMS, códigos de barra imprimíveis, caixas de papelão ondulado, fita adesiva de alta aderência",
      processDescription: "Filtro de Pedido e Geração de Roteiro -> Coleta Física de Produtos (Picking) -> Auditoria & Embalagem (Packing) -> Faturamento com Nota Fiscal -> Paletização & Expedição",
      outputs: "Pedidos consolidados faturados lacrados com Danfe anexada, tracking de embarque de transportadora",
      customers: "Clientes e-commerce varejo e integradores logísticos (Meli, Correios, Loggi)"
    },
    steps: [
      {
        id: "step-1",
        name: "Importação & Filtragem de Lotes WMS",
        resource: "Software WMS / Analista",
        resourceCount: 1,
        processingTime: 1.2,
        standardDeviation: 0.3,
        yieldRate: 0.99,
        setupTime: 5,
        description: "Processamento de carrinho de compras no sistema e aglutinação de itens por corredor geográfico para otimização de rota física.",
        requiredInputs: ["Banco de dados de pedidos aprovados em nuvem XML", "Sistema Warehouse Management System (WMS)"],
        stepInstructions: [
          "Importar lotes de pedidos a cada 15 minutos de forma automática.",
          "Verificar incompatibilidades de SKU cadastral.",
          "Emitir boletim impresso ou digital nos coletores portáteis de picking list."
        ],
        automations: [
          {
            title: "Agrupamento Dinâmico Inteligente por Rota Comercial",
            type: "Algoritmos Dedicados",
            status: "active",
            description: "Aglutina pedidos com SKUs vizinho no armazém, diminuindo a caminhada dos catadores em 30%."
          }
        ],
        supportDocuments: [],
        x: 100,
        y: 80,
        shapeType: "START",
        nextStepId: "step-2"
      },
      {
        id: "step-2",
        name: "Coleta Física de Produtos (Picking)",
        resource: "Operador de Almoxarifado (Picker)",
        resourceCount: 4,
        processingTime: 5.5,
        standardDeviation: 1.2,
        yieldRate: 0.95,
        setupTime: 10,
        description: "Percorrer as prateleiras do armazém coletando e bipando SKUs conforme roteiro do WMS.",
        requiredInputs: ["Coletor de dados sem fio com leitor Zebra", "Carrinho aramado de separação multi-nichos", "Colete de sinalização reflexivo"],
        stepInstructions: [
          "Ir para o corredor e nível indicados pelo visor do coletor de rádio-frequência.",
          "Efetuar bip de endereço para validar integridade da prateleira.",
          "Retirar e bipar o SKU, colocando-o no respectivo nicho de destinação do carrinho.",
          "Avançar para a próxima rota sem retornar à expedição até fechar o lote."
        ],
        automations: [
          {
            title: "Orientação Visual por Luzes (Pick-to-Light)",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Acende LEDs coloridos na posição exata da prateleira onde o produto está, eliminando tempos excessivos de busca."
          }
        ],
        supportDocuments: [
          { name: "SOP-LOG-05: Protocolo Seguro de Operação de Picking Alto", code: "SOP-LOG-05", type: "SOP", rev: "A.2" }
        ],
        x: 320,
        y: 80,
        shapeType: "ACTIVITY",
        nextStepId: "step-3"
      },
      {
        id: "step-3",
        name: "Auditoria & Embalagem (Packing)",
        resource: "Conferente Operacional (Packer)",
        resourceCount: 2,
        processingTime: 3.0,
        standardDeviation: 0.8,
        yieldRate: 0.98,
        setupTime: 5,
        description: "Checagem de modelo, cor e quantidade, seguida da embalagem segura antimpacto.",
        requiredInputs: ["Carrinho com itens coletados do lote", "Malha e filme bolha, fitas de segurança", "Caixas de montagem rápida de papelão ondulado"],
        stepInstructions: [
          "Verificar itens trazidos escanenado-os no computador de mesa do posto de packing.",
          "Selecionar caixa de tamanho ótimo para evitar deslocamento de produto no trajeto.",
          "Adicionar mantas de amortecimento biodegradáveis.",
          "Preencher com fita e selar a caixa com a etiqueta indicadora do WMS."
        ],
        automations: [
          {
            title: "Fechadora e Seladora Corrugada Automática",
            type: "Dispositivos Eletromecânicos",
            status: "active",
            description: "Dobra as abas e aplica fita adesiva Hotmelt em apenas 2 segundos por caixa de forma padronizada."
          }
        ],
        supportDocuments: [
          { name: "CKL-LOG-08: Check de Integridade Contra Avarias na Coleta", code: "CKL-LOG-08", type: "Checklist", rev: "C.1" }
        ],
        x: 540,
        y: 80,
        shapeType: "ACTIVITY",
        nextStepId: "step-4"
      },
      {
        id: "step-4",
        name: "Faturamento & Emissão de Danfe",
        resource: "Faturista / Robô RPA",
        resourceCount: 1,
        processingTime: 1.8,
        standardDeviation: 0.5,
        yieldRate: 0.97,
        setupTime: 0,
        description: "Geração de nota fiscal mercantil e impressão termo-sensível de etiquetas de envio.",
        requiredInputs: ["Checkout de packing finalizado", "Integração API com faturamento e Sebrae/Sefaz", "Etiquetadora Zebra térmica de alto desempenho"],
        stepInstructions: [
          "Verificar a correta transmissão e retorno do XML do governo.",
          "Imprimir em papel autoadesivo a Danfe simplificada de e-commerce e a etiqueta de frete correspondente.",
          "Colar a Danfe e a etiqueta na lateral maior da caixa selada."
        ],
        automations: [
          {
            title: "Emissão RPA Totalmente Autônoma de NF",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Software faturador em nuvem que executa a transação direta Sefaz sem intervenção manual do operador."
          }
        ],
        supportDocuments: [
          { name: "SOP-LOG-12: Contingência para Falha Estrutural de Nota Sefaz", code: "SOP-LOG-12", type: "SOP", rev: "A.3" }
        ],
        x: 760,
        y: 80,
        shapeType: "DECISION",
        yesStepId: "step-5",
        noStepId: "step-3"
      },
      {
        id: "step-5",
        name: "Classificação por Transportadora & Despacho",
        resource: "Operador de Doca (Paleteiro)",
        resourceCount: 2,
        processingTime: 2.5,
        standardDeviation: 0.6,
        yieldRate: 0.99,
        setupTime: 15,
        description: "Segregação de caixas por transportadora em gaiolas dedicadas de embarque marítimo ou rodoviário.",
        requiredInputs: ["Caixas prontas embaladas etiquetadas faturadas", "Gaiolas de ferro estruturais e carrinhos direcionais paleteiros"],
        stepInstructions: [
          "Ler a região/transportadora escrita no topo da etiqueta externa.",
          "Alocar as caixas de forma ordenada nas gaiolas metálicas do pilar correspondente.",
          "Realizar a contagem total de unidades e gerar o manifesto de entrega ao portador."
        ],
        automations: [
          {
            title: "Esteira Classificadora Mecânica (Sorter)",
            type: "Pneumática Proporcional",
            status: "proposed",
            description: "Lê a etiqueta em trânsito e empurra o pacote diretamente na rampa da transportadora correta dispensando o paleteiro manual."
          }
        ],
        supportDocuments: [
          { name: "MNL-SFT-02: Práticas Seguras de Ergonomia em Docas de Carga", code: "MNL-SFT-02", type: "Manual", rev: "B.1" }
        ],
        x: 980,
        y: 80,
        shapeType: "END"
      }
    ],
    controlPlans: [
      {
        id: "cp-1",
        stepName: "Tempo Interno de Linha (Fulfillment)",
        metric: "Tempo de Processamento de Pedido",
        lcl: 5.0,
        ucl: 25.0,
        target: 18.0,
        frequency: "A cada duas horas",
        responsible: "Coordenador de Expedição",
        reactionPlan: "Acionar horas extras de pickers e redistribuir equipe de picking se o tempo médio acumulado de processamento passar de 22 minutos.",
        currentReading: 16.5,
        enableAlarm: true
      },
      {
        id: "cp-2",
        stepName: "Acurácia de Separação (Picking)",
        metric: "Pedidos em Não-Conformidade de SKUs no Packing",
        lcl: 0,
        ucl: 0.01,
        target: 0.003,
        frequency: "Diário",
        responsible: "Quality Auditor de Expedição",
        reactionPlan: "Iniciar contagem cíclica relâmpago de endereços das prateleiras que registraram reincidência de erros de separação.",
        currentReading: 0.004,
        enableAlarm: true
      }
    ]
  },
  {
    id: "saas-software-delivery",
    name: "Desenvolvimento SaaS (Sprints & DevOps)",
    category: "tecnologia",
    icon: "💻",
    arrivalRate: 6,
    unitLabel: "história de usuário",
    unitLabelPlural: "histórias de usuário",
    charter: {
      title: "Garantia de Vazão e Redução de Lead Time de Software",
      problemStatement: "As histórias de usuário e correções de bugs acumulam nas etapas de codificação e revisão de código, gerando atraso nas entregas das Sprints e um Lead Time médio que excede 18 dias úteis por funcionalidade.",
      goal: "Reduzir o Lead Time total do desenvolvimento em 35%, alcançar um nível sigma acima de 3.8σ na taxa de compilação sem falhas e eliminar gargalos estocásticos em QA.",
      metric: "cycle_time",
      targetValue: 8
    },
    sipoc: {
      suppliers: "Clientes, Product Owners, UX Designers, Gestão Estratégica",
      inputs: "Ideias de produto, relatórios de bugs, requisitos de negócios, protótipos de alta fidelidade",
      processDescription: "Refinamento técnico -> Desenho UX -> Codificação de Squad -> Code Review -> Deploy em Produção",
      outputs: "Funcionalidades estáveis publicadas em produção, relatórios de telemetria base SaaS",
      customers: "Usuários finais do software, stakeholders do negócio e equipe de suporte"
    },
    steps: [
      {
        id: "step-1",
        name: "Refinamento e Escopo de Backlog",
        resource: "Product Owner (Backlog)",
        resourceCount: 1,
        processingTime: 3.5,
        standardDeviation: 0.8,
        yieldRate: 0.98,
        setupTime: 120,
        description: "Transformação de ideias de produto em especificações técnicas e histórias prontas (INVEST).",
        requiredInputs: ["Requisitos brutos do negócio", "Feedback de usuários", "Métricas de uso anteriores"],
        stepInstructions: [
          "Criar histórias de usuário detalhadas com critérios de aceitação claros.",
          "Estimar o esforço inicial com o time técnico usando Planning Poker.",
          "Preencher a documentação no Jira / Confluence.",
          "Garantir o cumprimento do Definition of Ready (DoR)."
        ],
        automations: [
          {
            title: "Gerador de Critérios de Aceitação com IA",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Esboça critérios Gherkin automatizados baseados em prompts simples de negócio."
          }
        ],
        supportDocuments: [
          { name: "SOP-PM-01: Framework de Escrita de Histórias saudáveis", code: "SOP-PM-01", type: "SOP", rev: "A.1" }
        ],
        x: 100,
        y: 80,
        shapeType: "START",
        yesStepId: "step-2"
      },
      {
        id: "step-2",
        name: "Desenho da Experiência & UX/UI",
        resource: "Product Designer (Figma)",
        resourceCount: 1,
        processingTime: 4.2,
        standardDeviation: 1.0,
        yieldRate: 0.96,
        setupTime: 60,
        description: "Elaboração de jornadas de usuários, wireframes e protótipos visuais interativos.",
        requiredInputs: ["Documentação técnica refinada", "Padrões do Design System da empresa", "Necessidade visual de fluxos"],
        stepInstructions: [
          "Desenhar wireframes de baixa fidelidade para alinhamento rápido.",
          "Construir os protótipos finais navegáveis no Figma.",
          "Realizar testes rápidos de usabilidade em sessões de co-design.",
          "Gerar o handoff completo com especificações CSS de componentes."
        ],
        automations: [
          {
            title: "Handoff e Tradução Automatizada Figma para Tailwind CSS",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Converte o layout eletrônico diretamente em código limpo de estilos agilizando em 40% o setup de front-end."
          }
        ],
        supportDocuments: [
          { name: "SOP-UX-14: Diretrizes de Acessibilidade Web WCAG 2.1", code: "SOP-UX-14", type: "Checklist", rev: "B.3" }
        ],
        x: 320,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-3"
      },
      {
        id: "step-3",
        name: "Codificação do Squad & Testes Unitários",
        resource: "Engenheiros de Software (React/Node)",
        resourceCount: 2,
        processingTime: 8.5,
        standardDeviation: 2.2,
        yieldRate: 0.91,
        setupTime: 15,
        description: "Desenvolvimento pleno das lógicas de programação e blindagem com testes automatizados.",
        requiredInputs: ["Protótipos aprovados no Figma", "Acesso à API Sandbox", "Especificações de Backlog"],
        stepInstructions: [
          "Instanciar galhos dedicados (git branches) específicos para as tarefas.",
          "Implementar interfaces web limpas e apis rest/graphql correspondentes.",
          "Garantir cobertura mínima de testes unitários superior a 80%.",
          "Executar build local antes do envio do pull request."
        ],
        automations: [
          {
            title: "Auto-completion de Código base IA Generativa",
            type: "Deep Learning (IA)",
            status: "active",
            description: "Antecipa classes, documentação e blocos de validação mitigando defeitos em tempo de digitação."
          }
        ],
        supportDocuments: [
          { name: "SOP-ENG-05: Padrões de Clean Architecture & Lógicas limpas", code: "SOP-ENG-05", type: "Manual", rev: "C.4" }
        ],
        x: 540,
        y: 80,
        shapeType: "DECISION",
        yesStepId: "step-4",
        noStepId: "step-1"
      },
      {
        id: "step-4",
        name: "Revisão de Código (Code Review)",
        resource: "Tech Lead / Desenvolvedor Sênior",
        resourceCount: 1,
        processingTime: 2.8,
        standardDeviation: 0.6,
        yieldRate: 0.94,
        setupTime: 0,
        description: "Validação crítica de arquitetura, segurança e boas práticas antes de mesclar na branch principal.",
        requiredInputs: ["Pull Request aberto no GitHub", "Relatórios de testes de cobertura gerados por CI"],
        stepInstructions: [
          "Verificar se as lógicas atendem perfeitamente aos critérios de aceitação.",
          "Avaliar vulnerabilidades de segurança básicas corporativas (OWASP).",
          "Aprovar ou solicitar alterações com feedbacks de suporte detalhados."
        ],
        automations: [
          {
            title: "Linter e Varredura de Vulnerabilidades CI/CD Automático",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Analisa padrões de sintaxe e dependências expiradas em tempo de build bloqueando falhas."
          }
        ],
        supportDocuments: [
          { name: "SOP-ENG-08: Guia de Boas Práticas do Code Reviewer", code: "SOP-ENG-08", type: "SOP", rev: "A.3" }
        ],
        x: 760,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-5"
      },
      {
        id: "step-5",
        name: "Deploy em Produção (DevOps)",
        resource: "DevOps Engineer / Plataforma",
        resourceCount: 1,
        processingTime: 1.5,
        standardDeviation: 0.3,
        yieldRate: 0.995,
        setupTime: 10,
        description: "Publicação do código de forma automatizada na infraestrutura de nuvem com testes de fumaça.",
        requiredInputs: ["Código mesclado aprovado na branch principal", "Ambientes Docker estáveis", "Credenciais de nuvem ativas"],
        stepInstructions: [
          "Disparar pipeline GitHub Actions para compilação e conteinerização.",
          "Rodar scripts de migração de banco de dados de modo seguro.",
          "Verificar se a aplicação responde saudavelmente aos endpoints de healthcheck.",
          "Informar o time operacional no Slack sobre a nova publicação."
        ],
        automations: [
          {
            title: "Deploy Canary Automatizado",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Direciona 5% de tráfego para a nova versão e avalia taxas de erro antes da expansão total de rede."
          }
        ],
        supportDocuments: [
          { name: "SOP-OPS-12: Manual de Contingência de Deploy e Rollback", code: "SOP-OPS-12", type: "SOP", rev: "A.4" }
        ],
        x: 980,
        y: 80,
        shapeType: "END"
      }
    ],
    controlPlans: [
      {
        id: "cp-saas-1",
        stepName: "Tempo Interno de WIP de Squad",
        metric: "Sprint Lead Time",
        lcl: 2.0,
        ucl: 14.0,
        target: 7.0,
        frequency: "Ao término de cada Sprint",
        responsible: "Scrum Master / Agile Coach",
        reactionPlan: "Caso o tempo médio de ciclo passe de 12 dias no ciclo, realizar dinâmica dos 5 Porquês na Retrospectiva para identificar impedimentos organizacionais.",
        currentReading: 6.8,
        enableAlarm: true
      },
      {
        id: "cp-saas-2",
        stepName: "Densidade de Falhas de Compilação",
        metric: "Taxa de Sucesso dos Builds de Deploy",
        lcl: 0.95,
        ucl: 1.0,
        target: 0.98,
        frequency: "Contínuo / Automatizado",
        responsible: "Time de QA & Engenharia de SRE",
        reactionPlan: "Se os builds falharem mais de 3 vezes em uma semana, reverter a última alteração estrutural nas ferramentas agregadoras e forçar revisão presencial.",
        currentReading: 0.97,
        enableAlarm: true
      }
    ]
  },
  {
    id: "healthcare-patient-flow",
    name: "Eficiência Hospitalar (Pronto Socorro & Triagem)",
    category: "saude",
    icon: "🏥",
    arrivalRate: 14,
    unitLabel: "paciente",
    unitLabelPlural: "pacientes",
    charter: {
      title: "Minimização de Filas e Otimização do Tempo de Atendimento de Saúde",
      problemStatement: "Muitos pacientes aguardam na recepção por mais de 50 minutos até completarem a consulta médica em horários de pico, levando à superlotação do pronto socorro e riscos no agravo de enfermidades.",
      goal: "Reduzir o tempo de permanência total (Door-to-Doctor) dos pacientes em pronto atendimento em 40%, alinhando fluxos para aumentar os padrões de qualidade hospitalar.",
      metric: "cycle_time",
      targetValue: 20
    },
    sipoc: {
      suppliers: "Secretaria de Saúde Coletiva, Fornecedores de Insumos Médicos, Redes de Emergência de SAMU",
      inputs: "Prontuários eletrônicos, leitos móveis, insumos descartáveis, medicamentos de suporte à vida",
      processDescription: "Ficha de Cadastro -> Triagem Manchester -> Consulta Médica -> Exames/Coleta -> Medicação e Alta",
      outputs: "Laudos médicos, diagnósticos conclusivos, planos farmacêuticos e fichas de internação",
      customers: "Pacientes da comunidade, seguradoras de saúde conveniadas e órgãos de auditoria"
    },
    steps: [
      {
        id: "step-1",
        name: "Recepção e Abertura de Ficha",
        resource: "Auxiliar Administrativo",
        resourceCount: 2,
        processingTime: 2.5,
        standardDeviation: 0.6,
        yieldRate: 0.99,
        setupTime: 0,
        description: "Inserção de dados cadastrais básico de identificação civil do paciente no ERP hospitalar.",
        requiredInputs: ["Documento com foto original do paciente", "Ficha do convênio ou cartão do SUS"],
        stepInstructions: [
          "Verificar documentos pessoais e buscar cadastro por CPF.",
          "Verificar dados de cobertura financeira do plano de saúde contratado.",
          "Entregar a pulseira de identificação padrão e direcionar o paciente ao saguão."
        ],
        automations: [
          {
            title: "Check-in de Autoatendimento via Totens Digitais",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Permite leitura automatizada de documentos e validação por reconhecimento facial encurtando o tempo de cadastro administrativo em 60%."
          }
        ],
        supportDocuments: [
          { name: "SOP-ADM-10: Cadastro Seguro e LGPD para Prontuário Médico", code: "SOP-ADM-10", type: "SOP", rev: "A.3" }
        ],
        x: 100,
        y: 80,
        shapeType: "START",
        yesStepId: "step-2"
      },
      {
        id: "step-2",
        name: "Triagem Clínica Manchester",
        resource: "Enfermeiro de Triagem",
        resourceCount: 1,
        processingTime: 3.8,
        standardDeviation: 0.7,
        yieldRate: 0.985,
        setupTime: 0,
        description: "Aferição de sinais vitais básicos e categorização por cores segundo escalas internacionais de prioridade estocástica.",
        requiredInputs: ["Termômetro de precisão, esfigmomanômetro", "Oxímetro de pulso Bluetooth portátil"],
        stepInstructions: [
          "Medir pressão arterial sistólica, saturação de oxigênio e pulsação.",
          "Aplicar o algoritmo de perguntas padrão Manchester para elucidação de gravidade de dores.",
          "Imprimir a etiqueta da cor correspondente de prioridade e colar à pulseira."
        ],
        automations: [
          {
            title: "Triagem Pré-Clínica com Sensores IoT Integrados",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Alimenta os sinais vitais aferidos diretamente na fila para o software do médico gerando relatórios instantâneos de alteração."
          }
        ],
        supportDocuments: [
          { name: "SOP-ENF-02: Protocolo de Manchester para Triagem de Alta Vazão", code: "SOP-ENF-02", type: "SOP", rev: "B.1" }
        ],
        x: 320,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-3"
      },
      {
        id: "step-3",
        name: "Consulta Médica Emergencista",
        resource: "Médicos de Plantão",
        resourceCount: 2,
        processingTime: 12.0,
        standardDeviation: 3.5,
        yieldRate: 0.95,
        setupTime: 0,
        description: "Avaliação do especialista com elaboração clínica de hipóteses de diagnóstico primário de doenças crônicas ou agudas.",
        requiredInputs: ["Estetoscópio calibrado", "Prontuário eletrônico ativo configurado na tela"],
        stepInstructions: [
          "Ouvir relato de sintomas e revisar dados da triagem do enfermeiro.",
          "Realizar exame físico geral direcionado sistemático.",
          "Definir conduta: prescrever medicação local, solicitar exames investigativos ou prescrever alta."
        ],
        automations: [
          {
            title: "Copiloto Clínico de Apoio ao Diagnóstico por IA",
            type: "Deep Learning (IA)",
            status: "active",
            description: "Examina textos do prontuário em busca de contraindicações raras a remédios e alerta sobre perfis alérgicos do paciente."
          }
        ],
        supportDocuments: [
          { name: "SOP-MED-04: Guia de Boas Práticas do Exame de Sintomas", code: "SOP-MED-04", type: "Manual", rev: "A.3" }
        ],
        x: 540,
        y: 80,
        shapeType: "DECISION",
        yesStepId: "step-4",
        noStepId: "step-1"
      },
      {
        id: "step-4",
        name: "Exames Rápidos de Laboratório / Imagem",
        resource: "Técnico de Laboratório / Raio-X",
        resourceCount: 1,
        processingTime: 18.0,
        standardDeviation: 4.5,
        yieldRate: 0.975,
        setupTime: 10,
        description: "Coleta de tubos de sangue ou exames de imagem digital rápidos com transmissão online centralizada de relatórios.",
        requiredInputs: ["Tubos de coleta padrão a vácuo, agulhas de segurança", "Foco de radiação X de alta precisão"],
        stepInstructions: [
          "Verificar identidade na pulseira antes de realizar as punções venosas.",
          "Executar a rotação rápida do lote na centrífuga de laboratório clínico.",
          "Anexar imagens digitais de raio-x do tórax/membros diretamente ao painel do prontuário."
        ],
        automations: [
          {
            title: "Leitura Rápida de Exames de Sangue Point-of-Care (POCT)",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Analisa hemograma completo na própria sala de atendimento em 3 minutos em vez de 35 minutos."
          }
        ],
        supportDocuments: [
          { name: "SOP-LAB-01: Segurança Biológica e Segurança em Coletas Clínicas", code: "SOP-LAB-01", type: "SOP", rev: "D.0" }
        ],
        x: 760,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-5"
      },
      {
        id: "step-5",
        name: "Sala de Medicação, Monitoria & Alta",
        resource: "Técnico de Enfermagem",
        resourceCount: 2,
        processingTime: 6.0,
        standardDeviation: 1.2,
        yieldRate: 0.995,
        setupTime: 5,
        description: "Administração de medicamentos, monitoria de efeitos colaterais adversos e emissão de orientações farmacêuticas de alta.",
        requiredInputs: ["Medicamentos do carrinho clínico", "Ficha física impressa de alta médica com orientações para casa"],
        stepInstructions: [
          "Administrar as dosagens prescritas pelo médico obedecendo às diretrizes dos '9 Certos'.",
          "Manter monitor de batimentos cardíacos ativo nas poltronas de medicação rápida.",
          "Entregar prescrição médica, atestados de horas trabalhadas e realizar a devida alta."
        ],
        automations: [
          {
            title: "Dispensador de Dose Unidirecional RFID de Medicamento",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Guarda-volumes travado que só abre o compartimento com o medicamento após leitura facial do funcionário, reduzindo perdas a zero."
          }
        ],
        supportDocuments: [
          { name: "SOP-ENF-09: Processo Seguro de Medicamentos por Sonda e Veia", code: "SOP-ENF-09", type: "SOP", rev: "A.5" }
        ],
        x: 980,
        y: 80,
        shapeType: "END"
      }
    ],
    controlPlans: [
      {
        id: "cp-med-1",
        stepName: "Tempo de Permanência até o Médico (Door-to-Doctor)",
        metric: "Janela de Atendimento Ambulatorial (min)",
        lcl: 5.0,
        ucl: 45.0,
        target: 20.0,
        frequency: "Contínuo por Dashboard BI de Portaria",
        responsible: "Diretor Clínico Hospitalar de Plantão",
        reactionPlan: "Acionar o médico de backup em sobreaviso de forma imediata quando a fila de espera e o tempo de triagem excederem os 35 minutos de espera em nível grave.",
        currentReading: 15.2,
        enableAlarm: true
      },
      {
        id: "cp-med-2",
        stepName: "Ocorrência de Erros Graves de Dosagem de Medicamento",
        metric: "Indice Correlato de Erros Clínicos de Dispensação",
        lcl: 0,
        ucl: 0.001,
        target: 0.0001,
        frequency: "Semanal",
        responsible: "Auditoria Interna de Enfermagem Hospitalar",
        reactionPlan: "Parar imediatamente a operação das gavetas e realizar auditoria imediata de lote do fornecedor clínico acusado de falhas de embalagem.",
        currentReading: 0.0,
        enableAlarm: true
      }
    ]
  },
  {
    id: "hr-recruitment-funnel",
    name: "Gente & Gestão (Funil de Vagas & Atração)",
    category: "rh",
    icon: "🤝",
    arrivalRate: 5,
    unitLabel: "candidato",
    unitLabelPlural: "candidatos",
    charter: {
      title: "Minimização de SLA de Contratação e Atração de Talentos",
      problemStatement: "O tempo médio de recrutamento de vagas técnicas (Time-to-Hire) ultrapassa 48 dias civis, fazendo com que times internos fiquem desfalcados e ocorrendo perda de talentos para propostas correntes.",
      goal: "Reduzir o Time-to-Hire total em 30% usando metodologias de redução de setup e filtragem ágil sem prejudicar a qualidade técnica final dos contratados.",
      metric: "cycle_time",
      targetValue: 24
    },
    sipoc: {
      suppliers: "Plataformas de Vaga (LinkedIn/Gupy), agências externas, Headhunters profissionais de mercado",
      inputs: "Perfil detalhado de cargo, orçamentos estruturais de salário, base de dados de candidatos",
      processDescription: "Filtro de Currículos -> Entrevista Cultural -> Case Técnico -> Entrevista com Gestores -> Mesclagem e Proposta",
      outputs: "Contratos de trabalho assinados, relatórios de entrevistas de validação, feedback de candidatos",
      customers: "Gerentes de contratação contratantes de áreas específicas, diretores corporativos e profissionais admitidos"
    },
    steps: [
      {
        id: "step-1",
        name: "Triagem de Currículos & Candidatos",
        resource: "Recrutadores (LinkedIn)",
        resourceCount: 2,
        processingTime: 3.5,
        standardDeviation: 0.7,
        yieldRate: 0.25,
        setupTime: 120,
        description: "Mapeamento e leitura de currículos de forma digital, descartando perfis fora do escopo técnico de contratação.",
        requiredInputs: ["LinkedIn Recruiter Licença Ativa", "Perfil de cargo enviado pela área requisitante"],
        stepInstructions: [
          "Verificar palavras-chave alustradas, tecnologias centrais e tempo de experiência relatados.",
          "Filtrar candidatos por pretensão salarial compatível com a vaga.",
          "Encaminhar os perfis qualificados para a fase de contato inicial."
        ],
        automations: [
          {
            title: "Matcher Inteligente Baseado em Redes Semânticas de IA",
            type: "Deep Learning (IA)",
            status: "active",
            description: "Analisa o perfil e ranqueia os talentos que melhor combinam com a vaga reduzindo o screening manual em 75%."
          }
        ],
        supportDocuments: [
          { name: "SOP-HR-02: Guia de Triagem Inclusiva e Diversidade Legal", code: "SOP-HR-02", type: "SOP", rev: "A.3" }
        ],
        x: 100,
        y: 80,
        shapeType: "START",
        yesStepId: "step-2"
      },
      {
        id: "step-2",
        name: "Entrevista de Fit Cultural (Recrutamento)",
        resource: "Business Partner / HR Specialist",
        resourceCount: 1,
        processingTime: 25.0,
        standardDeviation: 4.0,
        yieldRate: 0.45,
        setupTime: 15,
        description: "Entrevista base de alinhamento com os valores de comportamento ético, soft skills e expectativas profissionais.",
        requiredInputs: ["Agenda Google Calendar calibrada", "Guia padrão de perguntas estruturadas sociológicas"],
        stepInstructions: [
          "Apresentar a proposta de valor ao candidato sobre a estrutura de crescimento na empresa.",
          "Avaliar inteligência emocional através do método das perguntas por cenários reais (Scale).",
          "Anotar as respostas conceituais no sistema de gestão ATS de candidatos."
        ],
        automations: [
          {
            title: "Agendador Inteligente Autônomo Integrado de Calendário",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Dispara links personalizados com horários livres e aloca as sessões diretamente nas agendas dos envolvidos."
          }
        ],
        supportDocuments: [
          { name: "SOP-HR-05: Protocolo de Entrevista Estruturada Comportamental", code: "SOP-HR-05", type: "SOP", rev: "B.2" }
        ],
        x: 320,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-3"
      },
      {
        id: "step-3",
        name: "Avaliação Prática / Case Técnico",
        resource: "Tech Leads / Avaliadores Técnicos",
        resourceCount: 1,
        processingTime: 45.0,
        standardDeviation: 10.0,
        yieldRate: 0.50,
        setupTime: 30,
        description: "Aplicação e escrutínio de desafios operacionais focados nas habilidades requeridas de trabalho físico ou analítico.",
        requiredInputs: ["Repositório online de códigos / Desafios práticos", "Grade objetiva de pontuação cruzada"],
        stepInstructions: [
          "Enviar o link do case com instruções e limite de entrega de 5 dias.",
          "Avaliar o portfólio de entrega com foco em conformidade e boas práticas.",
          "Dar feedback detalhado escrito sobre todos os pontos examinados."
        ],
        automations: [
          {
            title: "Sandbox de Correção Assistida de Códigos Técnicos",
            type: "Sistemas Digitais IoT",
            status: "proposed",
            description: "Roda scripts automatizados de checagem de erros compilando resultados e economizando 3 horas semanais dos seniores."
          }
        ],
        supportDocuments: [
          { name: "SOP-HR-10: Critérios de Pontuação e Equidade de Cases Técnicos", code: "SOP-HR-10", type: "SOP", rev: "A.3" }
        ],
        x: 540,
        y: 80,
        shapeType: "DECISION",
        yesStepId: "step-4",
        noStepId: "step-1"
      },
      {
        id: "step-4",
        name: "Entrevista Executiva / Alinhamento de Gestor",
        resource: "Gestor Contratante (Manager / Head)",
        resourceCount: 1,
        processingTime: 30.0,
        standardDeviation: 5.0,
        yieldRate: 0.70,
        setupTime: 0,
        description: "Entrevista profunda focada nas entregas do cargo, governança corporativa e fechamento de acordos.",
        requiredInputs: ["Histórico compilado de entrevistas passadas e nota do case técnico avaliado"],
        stepInstructions: [
          "Validar estilo de liderança compatível e rotina de feedbacks.",
          "Esclarecer dúvidas do candidato sobre as metas de produtividade da equipe.",
          "Definir a classificação de ranking de admissão de candidatos."
        ],
        automations: [
          {
            title: "Sumarizador de Candidatura Assistido por IA",
            type: "Deep Learning (IA)",
            status: "active",
            description: "Gera cartões consolidados inteligentes de histórico técnico para o Head ler em 1 minuto antes de iniciar a sessão."
          }
        ],
        supportDocuments: [
          { name: "SOP-HR-12: Framework de Decisão Segura de Contratação", code: "SOP-HR-12", type: "SOP", rev: "A.1" }
        ],
        x: 760,
        y: 80,
        shapeType: "ACTIVITY",
        yesStepId: "step-5"
      },
      {
        id: "step-5",
        name: "Proposta Comercial & Fechamento",
        resource: "Especialista em Admissões / Remuneração",
        resourceCount: 1,
        processingTime: 15.0,
        standardDeviation: 2.0,
        yieldRate: 0.90,
        setupTime: 15,
        description: "Envio de detalhes de salário contratual, pacote de benefícios e recolhimento de assinaturas digitais de aceite.",
        requiredInputs: ["Carta de benefícios revisada, dados de remuneração homologados pela tesouraria financeira"],
        stepInstructions: [
          "Calcular as fatias de remuneração fixa, variável de cargos e pacote de saúde.",
          "Entrar em contato telefônico para formalizar o envio de proposta.",
          "Coordenar o recebimento de certidões e efetivar admissão em sistema."
        ],
        automations: [
          {
            title: "Geração Autônoma de Contratos com Integração de Plataforma Doc",
            type: "Sistemas Digitais IoT",
            status: "active",
            description: "Usa variáveis pré-aprovadas da vaga para gerar o contrato CLT emitindo link criptográfico único para assinatura."
          }
        ],
        supportDocuments: [
          { name: "SOP-HR-15: Processos de Admissão Digital do Trabalho", code: "SOP-HR-15", type: "SOP", rev: "C.0" }
        ],
        x: 980,
        y: 80,
        shapeType: "END"
      }
    ],
    controlPlans: [
      {
        id: "cp-hr-1",
        stepName: "Média de Lead Time de Contratação (Time-to-Hire)",
        metric: "Ciclo de Desocupação de Vaga Corporativa (dias)",
        lcl: 10.0,
        ucl: 45.0,
        target: 25.0,
        frequency: "Mensal",
        responsible: "Diretor Geral de Atração de Talentos CO",
        reactionPlan: "Se a média ultrapassar 38 dias úteis, disparar plano de contingência para acionamento prioritário de agências assessoras de headhunting extras de suporte.",
        currentReading: 26.2,
        enableAlarm: true
      },
      {
        id: "cp-hr-2",
        stepName: "Taxa de Adequação de Contratados (Turnover 90 Dias)",
        metric: "Indice Correlato de Desligamento Prematuro de Admitidos",
        lcl: 0,
        ucl: 0.08,
        target: 0.03,
        frequency: "Mensal / Trimestral",
        responsible: "Especialista Geral de Employee Experience",
        reactionPlan: "Conduzir entrevistas de desligamento e aplicar recalibração imediata nas grades curriculares de triagem e dinâmicas de fit cultural lideradas.",
        currentReading: 0.04,
        enableAlarm: true
      }
    ]
  }
];

