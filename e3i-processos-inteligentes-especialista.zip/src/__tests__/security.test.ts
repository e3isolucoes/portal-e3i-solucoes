import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { StorageRepository } from "../repositories/StorageRepository";
import { WorkspaceRepository } from "../repositories/WorkspaceRepository";
import { MFAAuth } from "../utils/mfaManager";
import * as crypto from "crypto";

// --- Mocks Setup ---

// Mocking window/localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: vi.fn((key: string) => store[key] || null),
    setItem: vi.fn((key: string, value: string) => {
      store[key] = value.toString();
    }),
    removeItem: vi.fn((key: string) => {
      delete store[key];
    }),
    clear: vi.fn(() => {
      store = {};
    }),
    get length() {
      return Object.keys(store).length;
    },
    key: vi.fn((index: number) => Object.keys(store)[index] || null),
  };
})();

if (typeof window === "undefined") {
  global.window = {} as any;
}
global.localStorage = localStorageMock as any;

// Mock Firebase SDKs
vi.mock("firebase/app", () => ({
  initializeApp: vi.fn(() => ({})),
  getApps: vi.fn(() => []),
  getApp: vi.fn(() => ({})),
}));

vi.mock("firebase/auth", () => ({
  getAuth: vi.fn(() => ({
    currentUser: null,
  })),
}));

vi.mock("firebase/firestore", () => ({
  getFirestore: vi.fn(() => ({})),
  doc: vi.fn(() => ({})),
  getDoc: vi.fn(() => Promise.resolve({
    exists: () => false,
    data: () => null,
  })),
  setDoc: vi.fn(() => Promise.resolve()),
  updateDoc: vi.fn(() => Promise.resolve()),
}));

// Mock the actual project firebase exports so they don't crash
vi.mock("../firebase", () => {
  return {
    db: {},
    auth: {
      currentUser: null,
    },
    handleFirestoreError: vi.fn(),
    OperationType: {
      CREATE: "create",
      UPDATE: "update",
      DELETE: "delete",
      LIST: "list",
      GET: "get",
      WRITE: "write",
    }
  };
});

// Import the mocked auth instance to simulate current user
import { auth as mockedAuth } from "../firebase";

describe("Segurança e Governança do Client-Side e Multi-Tenant", () => {
  beforeEach(() => {
    localStorageMock.clear();
    vi.clearAllMocks();
    (mockedAuth as any).currentUser = null;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // =========================================================================
  // 1. DADOS NÃO SENSÍVEIS VS SENSÍVEIS NO STORAGE (STORAGE REPOSITORY)
  // =========================================================================
  describe("StorageRepository - Gestão de Dados Locais", () => {
    it("deve isolar dados de diferentes tenants (Multi-Tenancy)", () => {
      // Configura tenant como 'empresaA' no localStorage
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantA_id" }));

      // Salva uma preferência de UI (não sensível)
      StorageRepository.setItem("e3i_sidebar_collapsed", true, true);

      // Troca para o tenant 'empresaB'
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantB_id" }));

      // Tenta ler a preferência; deve retornar o valor padrão pois pertence ao tenantA
      const result = StorageRepository.getItem("e3i_sidebar_collapsed", false, true);
      expect(result).toBe(false);
    });

    it("deve recuperar dados salvos corretamente quando no mesmo tenant", () => {
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantA_id" }));

      StorageRepository.setItem("e3i_sidebar_collapsed", true, true);

      const result = StorageRepository.getItem("e3i_sidebar_collapsed", false, true);
      expect(result).toBe(true);
    });

    it("deve logar aviso de segurança ao tentar salvar chaves sensíveis (role, permission, token) no localStorage", () => {
      const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
      
      // Chaves de controle de acesso/roles não devem ser salvas localmente como fonte de verdade
      StorageRepository.setItem("lss_role_permissions", { canExport: true }, true);
      
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining("[StorageRepository Security Warning]"));
      warnSpy.mockRestore();
    });

    it("deve limpar apenas os dados do tenant atual ao executar clearTenantStorage", () => {
      // Cadastra tenant A e salva dados
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantA" }));
      StorageRepository.setItem("theme", "dark", true);
      StorageRepository.setItem("global_view", "on", false); // Global

      // Cadastra tenant B e salva dados
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantB" }));
      StorageRepository.setItem("theme", "light", true);

      // Limpa dados apenas do tenant B
      StorageRepository.clearTenantStorage();

      // O dado do tenant B deve ter sido deletado
      const bTheme = StorageRepository.getItem("theme", "default", true);
      expect(bTheme).toBe("default");

      // O dado global e do tenant A devem permanecer intactos
      localStorageMock.setItem("six_sigma_active_user", JSON.stringify({ uid: "tenantA" }));
      const aTheme = StorageRepository.getItem("theme", "default", true);
      expect(aTheme).toBe("dark");

      const globalView = StorageRepository.getItem("global_view", "off", false);
      expect(globalView).toBe("on");
    });
  });

  // =========================================================================
  // 2. WORKSPACE CONFIGURATION SYNC & FALLBACKS
  // =========================================================================
  describe("WorkspaceRepository - Sincronização Segura e Offline-First", () => {
    it("deve retornar dados locais instantaneamente se offline ou sem usuário logado", async () => {
      const callback = vi.fn();
      (mockedAuth as any).currentUser = null;

      const config = await WorkspaceRepository.getWorkspace(callback);

      // Deve ler o valor padrão do local storage e chamar o callback
      expect(config.businessType).toBe("SERVICES");
      expect(callback).toHaveBeenCalledWith(expect.objectContaining({ businessType: "SERVICES" }));
    });

    it("deve ignorar sincronização com Firestore se em Modo de Treinamento (Sandbox)", async () => {
      localStorageMock.setItem("lss_training_mode", "true");
      (mockedAuth as any).currentUser = { uid: "user123" };
      const callback = vi.fn();

      const config = await WorkspaceRepository.getWorkspace(callback);

      expect(config.businessType).toBe("SERVICES");
      expect(callback).toHaveBeenCalledTimes(1); // Apenas lido do localStorage localmente
    });
  });

  // =========================================================================
  // 3. MULTI-FACTOR AUTHENTICATION (MFA)
  // =========================================================================
  describe("Multi-Factor Authentication (MFA) Engine", () => {
    const userEmail = "auditor@empresa.com";

    beforeEach(() => {
      MFAAuth.revokeMFA(userEmail);
    });

    it("deve exigir MFA obrigatoriamente para perfis críticos (Administrador e Auditor)", () => {
      expect(MFAAuth.isMFARequired("Administrador")).toBe(true);
      expect(MFAAuth.isMFARequired("Auditor")).toBe(true);
      expect(MFAAuth.isMFARequired("Visualizador")).toBe(false);
    });

    it("deve permitir a ativação e confirmação de MFA após challenge correto", () => {
      const configBefore = MFAAuth.getUserConfig(userEmail);
      expect(configBefore.enabled).toBe(false);

      // Inicia Setup do MFA
      const setup = MFAAuth.setupMFA(userEmail, "totp");
      expect(setup.secret).toBeDefined();
      expect(setup.recoveryCodes.length).toBe(8);

      // Confirma com código inválido
      const confirmFail = MFAAuth.confirmMFAActivation(userEmail, "999999_invalido");
      expect(confirmFail).toBe(false);

      // Confirma com código de ativação válido simulado (123456)
      const confirmSuccess = MFAAuth.confirmMFAActivation(userEmail, "123456");
      expect(confirmSuccess).toBe(true);

      const configAfter = MFAAuth.getUserConfig(userEmail);
      expect(configAfter.enabled).toBe(true);
    });

    it("deve bloquear temporariamente o perfil após 5 tentativas consecutivas incorretas (Anti brute-force)", () => {
      // Ativa MFA para o usuário
      MFAAuth.setupMFA(userEmail, "totp");
      MFAAuth.confirmMFAActivation(userEmail, "123456");

      // Faz 5 tentativas inválidas de login com código 999999 (Simula falha)
      for (let i = 0; i < 5; i++) {
        const res = MFAAuth.verifyCode(userEmail, "999999");
        if (i < 4) {
          expect(res.success).toBe(false);
          expect(res.error).toContain(`Tentativa ${i + 1} de 5`);
        } else {
          expect(res.success).toBe(false);
          expect(res.error).toContain("Bloqueio imediato de segurança");
        }
      }

      // 6ª tentativa deve falhar imediatamente devido ao Lockout ativo
      const lockedRes = MFAAuth.verifyCode(userEmail, "123456");
      expect(lockedRes.success).toBe(false);
      expect(lockedRes.error).toContain("Múltiplas tentativas incorretas. Conta bloqueada temporariamente");
    });

    it("deve permitir login usando código de recuperação reserva e consumi-lo de forma imutável", () => {
      // Inicia e confirma MFA
      const setup = MFAAuth.setupMFA(userEmail, "totp");
      MFAAuth.confirmMFAActivation(userEmail, "123456");

      const activeCodes = [...setup.recoveryCodes];
      const testCode = activeCodes[0];

      // Tenta login com o código de recuperação
      const authRes = MFAAuth.verifyCode(userEmail, testCode);
      expect(authRes.success).toBe(true);
      expect(authRes.usedRecoveryCode).toBe(true);

      // Tenta login novamente com o MESMO código (deve ser rejeitado pois foi consumido)
      const authResReused = MFAAuth.verifyCode(userEmail, testCode);
      expect(authResReused.success).toBe(false);
    });
  });

  // =========================================================================
  // 4. AUTORIZAÇÃO, ROLE E CERTIFICATION BELT NO FRONTEND / MIDDLEWARE
  // =========================================================================
  describe("Middleware de Autorização e Restrição de Níveis de Certificação (Belts)", () => {
    // Simulando a lógica de requirePermission utilizada nas rotas críticas do Express backend
    function simulateRequirePermission(
      allowedBelts: string[],
      allowPortalClient: boolean,
      user: any
    ): { status: number; error?: string } {
      if (!user) {
        return { status: 401, error: "Usuário não autenticado." };
      }

      if (user.isPortalClient && allowPortalClient) {
        return { status: 200 };
      }

      if (user.isPortalClient && !allowPortalClient) {
        return {
          status: 403,
          error: "Acesso negado. Clientes externos do portal não possuem permissão para realizar esta operação."
        };
      }

      if (user.role === "Admin") {
        return { status: 200 };
      }

      const hasAccess = allowedBelts.includes(user.belt);
      if (!hasAccess) {
        return {
          status: 403,
          error: `Acesso negado. Esta operação de IA requer nível de certificação mínimo: ${allowedBelts.join(", ")}. Seu nível atual é ${user.belt}.`
        };
      }

      return { status: 200 };
    }

    it("deve negar acesso para usuários sem autenticação", () => {
      const res = simulateRequirePermission(["Green Belt", "Black Belt"], false, null);
      expect(res.status).toBe(401);
      expect(res.error).toBe("Usuário não autenticado.");
    });

    it("deve barrar Yellow Belt em operações reservadas para Green e Black Belt", () => {
      const yellowBeltUser = {
        uid: "user_yellow",
        role: "Analista",
        belt: "Yellow Belt",
        isPortalClient: false,
      };

      const res = simulateRequirePermission(["Green Belt", "Black Belt"], false, yellowBeltUser);
      expect(res.status).toBe(403);
      expect(res.error).toContain("Acesso negado. Esta operação de IA requer nível de certificação mínimo");
    });

    it("deve conceder acesso a Green Belt em operações que permitem Green e Black Belts", () => {
      const greenBeltUser = {
        uid: "user_green",
        role: "Líder de Projeto",
        belt: "Green Belt",
        isPortalClient: false,
      };

      const res = simulateRequirePermission(["Green Belt", "Black Belt"], false, greenBeltUser);
      expect(res.status).toBe(200);
    });

    it("deve permitir super-usuário (Admin) ignorar a barreira de Belt", () => {
      const adminUser = {
        uid: "user_admin",
        role: "Admin",
        belt: "Yellow Belt", // Belt inferior, mas role superior de Admin
        isPortalClient: false,
      };

      const res = simulateRequirePermission(["Green Belt", "Black Belt"], false, adminUser);
      expect(res.status).toBe(200);
    });

    it("deve barrar clientes externos do portal (Client Portal) em rotas internas não autorizadas", () => {
      const portalClient = {
        uid: "portal_user",
        role: "Cliente",
        belt: "Client Belt",
        isPortalClient: true,
      };

      // Tenta acessar uma rota interna que proíbe acesso a portal-client
      const res = simulateRequirePermission(["Green Belt", "Black Belt"], false, portalClient);
      expect(res.status).toBe(403);
      expect(res.error).toContain("Clientes externos do portal não possuem permissão");
    });

    it("deve permitir clientes do portal em rotas compartilhadas autorizadas", () => {
      const portalClient = {
        uid: "portal_user",
        role: "Cliente",
        belt: "Client Belt",
        isPortalClient: true,
      };

      // Acessa rota configurada com allowPortalClient = true
      const res = simulateRequirePermission(["Green Belt", "Black Belt"], true, portalClient);
      expect(res.status).toBe(200);
    });
  });

  // =========================================================================
  // 5. VALIDAÇÃO DE PASSCODE E EXPIRAÇÃO DE LINK DO PORTAL DO CLIENTE
  // =========================================================================
  describe("Client Portal - Token Security & Timing validation", () => {
    const CLIENT_PORTAL_SECRET = "optima-lss-secret-key-2026-corporate";

    function generatePortalToken(payload: any): string {
      const payloadStr = Buffer.from(JSON.stringify(payload)).toString("base64");
      const signature = crypto
        .createHmac("sha256", CLIENT_PORTAL_SECRET)
        .update(payloadStr)
        .digest("base64");
      return `${payloadStr}.${signature}`;
    }

    function verifyPortalToken(token: string): { valid: boolean; user?: any; error?: string } {
      if (!token.includes(".")) return { valid: false, error: "Token malformado." };
      const parts = token.split(".");
      if (parts.length !== 2) return { valid: false, error: "Token malformado." };

      const [payloadStr, signature] = parts;
      const expectedSignature = crypto
        .createHmac("sha256", CLIENT_PORTAL_SECRET)
        .update(payloadStr)
        .digest("base64");

      // Timing-safe comparison simulation
      const bufSig = Buffer.from(signature);
      const bufExpected = Buffer.from(expectedSignature);
      if (bufSig.length !== bufExpected.length) {
        return { valid: false, error: "Assinatura inválida." };
      }
      const match = crypto.timingSafeEqual(bufSig, bufExpected);
      if (!match) return { valid: false, error: "Assinatura inválida." };

      const payload = JSON.parse(Buffer.from(payloadStr, "base64").toString("utf8"));
      if (Date.now() > payload.expiresAt) {
        return { valid: false, error: "Token expirado." };
      }

      return { valid: true, user: payload };
    }

    it("deve validar com sucesso um token legítimo dentro do prazo de validade", () => {
      const payload = {
        tenantId: "company_abc",
        companyName: "Acme Corp",
        scopes: ["client:portal"],
        expiresAt: Date.now() + 60 * 60 * 1000, // 1 hora no futuro
      };

      const token = generatePortalToken(payload);
      const res = verifyPortalToken(token);

      expect(res.valid).toBe(true);
      expect(res.user.companyName).toBe("Acme Corp");
    });

    it("deve rejeitar tokens expirados", () => {
      const payload = {
        tenantId: "company_abc",
        companyName: "Acme Corp",
        scopes: ["client:portal"],
        expiresAt: Date.now() - 1000, // Expirado há 1 segundo
      };

      const token = generatePortalToken(payload);
      const res = verifyPortalToken(token);

      expect(res.valid).toBe(false);
      expect(res.error).toBe("Token expirado.");
    });

    it("deve rejeitar tokens com assinatura violada ou manipulada por invasor", () => {
      const payload = {
        tenantId: "company_abc",
        companyName: "Acme Corp",
        scopes: ["client:portal"],
        expiresAt: Date.now() + 60 * 60 * 1000,
      };

      const token = generatePortalToken(payload);
      const [payloadStr] = token.split(".");
      
      // Assinatura forjada/modificada
      const forgedToken = `${payloadStr}.FORGED_SIGNATURE_DATA`;
      const res = verifyPortalToken(forgedToken);

      expect(res.valid).toBe(false);
    });
  });
});
