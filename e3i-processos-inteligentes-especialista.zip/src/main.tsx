import {StrictMode, Suspense} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { BusinessContextProvider } from './contexts/BusinessContext.tsx';
import { ToastProvider } from './shared/ui/Toast.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Suspense fallback={
      <div className="min-h-screen bg-[#FDFCFB] text-[#1A1A1A] font-sans flex items-center justify-center p-8">
        <div className="text-center space-y-4">
          <div className="w-10 h-10 border-4 border-[#C49746] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs uppercase font-mono tracking-widest text-[#C49746]">Carregando Módulos LSS Optimaflow...</p>
        </div>
      </div>
    }>
      <BusinessContextProvider>
        <ToastProvider>
          <App />
        </ToastProvider>
      </BusinessContextProvider>
    </Suspense>
  </StrictMode>,
);
