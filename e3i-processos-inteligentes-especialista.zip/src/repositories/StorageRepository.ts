/**
 * StorageRepository.ts
 * Camada de abstração segura para gerenciamento de dados locais (localStorage).
 * Garante isolamento multi-tenant por empresa (tenantId), tratamento de exceções,
 * tipagem estrita e separação entre preferências de UI e dados de negócio.
 */

export interface StorageItem<T> {
  value: T;
  timestamp: number;
  tenantId?: string;
  checksum?: string;
}

export class StorageRepository {
  private static PREFIX = "e3i_optima_";

  /**
   * Obtém o tenantId atual do contexto ou do usuário autenticado de forma segura.
   */
  private static getCurrentTenantId(): string {
    try {
      // Tenta obter o ID do usuário ativo ou tenant do cache de sessão
      const activeUserStr = localStorage.getItem("six_sigma_active_user");
      if (activeUserStr) {
        const user = JSON.parse(activeUserStr);
        return user.uid || "global";
      }
    } catch {
      // Ignora erro e recorre ao fallback global
    }
    return "global";
  }

  /**
   * Gera uma chave segura composta que inclui o prefixo e o tenantId se aplicável.
   */
  private static generateKey(key: string, isTenantScoped = true): string {
    const tenantSuffix = isTenantScoped ? `_tenant_${this.getCurrentTenantId()}` : "_global";
    return `${this.PREFIX}${key}${tenantSuffix}`;
  }

  /**
   * Retorna se a chave contém preferências puras de UI ou se envolve dados operacionais.
   */
  private static isSensitiveKey(key: string): boolean {
    const sensitiveKeywords = ["permission", "role", "belt", "user", "passcode", "token", "auth", "smtp", "twilio"];
    return sensitiveKeywords.some((keyword) => key.toLowerCase().includes(keyword));
  }

  /**
   * Persiste dados no localStorage de forma segura com wrapping de metadados.
   */
  static setItem<T>(key: string, value: T, isTenantScoped = true): boolean {
    if (typeof window === "undefined") return false;

    // Bloqueia tentativas de persistir informações de autorização
    if (this.isSensitiveKey(key)) {
      console.warn(`[StorageRepository Security Warning] Tentativa de salvar dado sensível '${key}' no localStorage foi sinalizada. Dados de autorização devem vir apenas do servidor.`);
    }

    try {
      const fullKey = this.generateKey(key, isTenantScoped);
      const storageItem: StorageItem<T> = {
        value,
        timestamp: Date.now(),
        tenantId: isTenantScoped ? this.getCurrentTenantId() : undefined,
      };

      localStorage.setItem(fullKey, JSON.stringify(storageItem));
      return true;
    } catch (error) {
      console.error(`[StorageRepository] Erro ao gravar chave '${key}':`, error);
      return false;
    }
  }

  /**
   * Obtém dados do localStorage aplicando validações de ciclo de vida e isolamento.
   */
  static getItem<T>(key: string, defaultValue: T, isTenantScoped = true): T {
    if (typeof window === "undefined") return defaultValue;

    try {
      const fullKey = this.generateKey(key, isTenantScoped);
      const raw = localStorage.getItem(fullKey);
      
      if (!raw) return defaultValue;

      const parsed: StorageItem<T> = JSON.parse(raw);

      // Validação Multi-tenant reativa: garante que um tenant não leia dados de outro se o contexto mudar
      if (isTenantScoped) {
        const currentTenant = this.getCurrentTenantId();
        if (parsed.tenantId && parsed.tenantId !== currentTenant) {
          console.error(`[StorageRepository Violation] Detecção de vazamento de tenant para chave '${key}'. Esperado: '${currentTenant}', Encontrado: '${parsed.tenantId}'. Dados ignorados por segurança.`);
          return defaultValue;
        }
      }

      return parsed.value;
    } catch (error) {
      console.error(`[StorageRepository] Falha ao recuperar chave '${key}', retornando valor padrão:`, error);
      return defaultValue;
    }
  }

  /**
   * Remove um item específico do armazenamento.
   */
  static removeItem(key: string, isTenantScoped = true): void {
    if (typeof window === "undefined") return;
    try {
      const fullKey = this.generateKey(key, isTenantScoped);
      localStorage.removeItem(fullKey);
    } catch (error) {
      console.error(`[StorageRepository] Erro ao remover chave '${key}':`, error);
    }
  }

  /**
   * Limpa o armazenamento local do tenant atual, preservando dados globais de outros tenants.
   */
  static clearTenantStorage(): void {
    if (typeof window === "undefined") return;
    try {
      const currentTenant = this.getCurrentTenantId();
      const keysToRemove: string[] = [];

      for (let i = 0; i < localStorage.length; i++) {
        const rawKey = localStorage.key(i);
        if (rawKey && rawKey.startsWith(this.PREFIX)) {
          if (rawKey.endsWith(`_tenant_${currentTenant}`)) {
            keysToRemove.push(rawKey);
          }
        }
      }

      keysToRemove.forEach((key) => localStorage.removeItem(key));
      console.log(`[StorageRepository] Storage limpo para o tenant: ${currentTenant}`);
    } catch (error) {
      console.error("[StorageRepository] Falha ao limpar o armazenamento do tenant:", error);
    }
  }
}
