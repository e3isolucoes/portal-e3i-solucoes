/**
 * WorkspaceRepository.ts
 * Gerencia a persistência confiável e multi-tenant das configurações de workspace,
 * incluindo tipos de negócios, matriz RACI, auditorias agendadas e fluxos mapeados.
 * Utiliza o Firestore como Fonte Única de Verdade (Single Source of Truth) e o
 * StorageRepository como cache local seguro para resiliência offline.
 */

import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { StorageRepository } from "./StorageRepository";

export interface WorkspaceConfig {
  businessType: string;
  enabledViews: string[];
  scheduledAudits: any[];
  raciList: any[];
  customKpis?: any[];
  lastSyncedAt?: number;
}

export class WorkspaceRepository {
  private static STORAGE_KEY = "workspace_config_v1";

  /**
   * Obtém as configurações do workspace ativo.
   * Prioriza o cache local para carregamento instantâneo (UX fluida), mas
   * busca a versão atualizada do Firestore em segundo plano para sincronizar.
   */
  static async getWorkspace(
    onUpdate: (config: WorkspaceConfig) => void
  ): Promise<WorkspaceConfig> {
    const defaultConfig: WorkspaceConfig = {
      businessType: "SERVICES",
      enabledViews: ["definir", "medir", "analisar", "melhorar", "controlar"],
      scheduledAudits: [],
      raciList: [],
      customKpis: [],
    };

    // 1. Lê imediatamente do cache local para resposta ultra-rápida (Evita latência visual)
    const cached = StorageRepository.getItem<WorkspaceConfig>(this.STORAGE_KEY, defaultConfig, true);
    onUpdate(cached);

    // Se o usuário não estiver logado ou em Modo de Treinamento, mantém o cache local
    const currentUser = auth.currentUser;
    const isSandbox = typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true";
    
    if (!currentUser || isSandbox) {
      return cached;
    }

    try {
      // 2. Busca do Firestore em background
      const workspaceDocRef = doc(db, "users", currentUser.uid);
      const docSnap = await getDoc(workspaceDocRef);

      if (docSnap.exists()) {
        const cloudData = docSnap.data();
        if (cloudData.workspaceData) {
          const cloudConfig: WorkspaceConfig = {
            ...defaultConfig,
            ...cloudData.workspaceData,
            lastSyncedAt: Date.now(),
          };

          // 3. Atualiza o cache local seguro com os dados do servidor
          StorageRepository.setItem(this.STORAGE_KEY, cloudConfig, true);
          onUpdate(cloudConfig);
          return cloudConfig;
        }
      } else {
        // Se o documento do usuário ainda não existir no Firestore, provisionamos o padrão
        await setDoc(workspaceDocRef, {
          workspaceData: cached,
          updatedAt: new Date()
        }, { merge: true });
      }
    } catch (error) {
      console.warn("[WorkspaceRepository] Falha ao sincronizar com o Firestore (offline?). Usando cache local resiliênte:", error);
    }

    return cached;
  }

  /**
   * Salva as configurações do workspace.
   * Atualiza o cache local imediatamente e enfileira/dispara gravação no Firestore.
   */
  static async saveWorkspace(config: Partial<WorkspaceConfig>): Promise<void> {
    const currentUser = auth.currentUser;
    const isSandbox = typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true";

    // 1. Obtém a configuração ativa completa
    const current = StorageRepository.getItem<WorkspaceConfig>(this.STORAGE_KEY, {
      businessType: "SERVICES",
      enabledViews: ["definir", "medir", "analisar", "melhorar", "controlar"],
      scheduledAudits: [],
      raciList: [],
    }, true);

    const updatedConfig: WorkspaceConfig = {
      ...current,
      ...config,
      lastSyncedAt: Date.now(),
    };

    // 2. Salva no cache local de imediato
    StorageRepository.setItem(this.STORAGE_KEY, updatedConfig, true);

    // Se não estiver logado ou em modo sandbox, encerra aqui
    if (!currentUser || isSandbox) {
      return;
    }

    // 3. Persiste na nuvem de forma assíncrona
    try {
      const workspaceDocRef = doc(db, "users", currentUser.uid);
      await updateDoc(workspaceDocRef, {
        workspaceData: updatedConfig,
        updatedAt: new Date()
      });
    } catch (error) {
      console.warn("[WorkspaceRepository] Erro ao sincronizar gravação do workspace no Firestore (salvo apenas localmente):", error);
    }
  }

  /**
   * Força a sincronização bidirecional em lote dos dados locais remanescentes.
   * Útil para reconexões pós-offline ou após a autenticação inicial do usuário.
   */
  static async forceCloudSync(uid: string): Promise<void> {
    const local = StorageRepository.getItem<WorkspaceConfig | null>(this.STORAGE_KEY, null, true);
    if (!local) return;

    try {
      const workspaceDocRef = doc(db, "users", uid);
      const docSnap = await getDoc(workspaceDocRef);

      if (docSnap.exists()) {
        const cloudData = docSnap.data();
        const cloud = cloudData.workspaceData;

        // Se o servidor tiver dados mais recentes, resolvemos em favor do servidor
        if (cloud && (!local.lastSyncedAt || cloud.lastSyncedAt > local.lastSyncedAt)) {
          StorageRepository.setItem(this.STORAGE_KEY, cloud, true);
        } else {
          // Caso contrário, enviamos o local atualizado para o servidor
          await updateDoc(workspaceDocRef, {
            workspaceData: local,
            updatedAt: new Date()
          });
        }
      } else {
        await setDoc(workspaceDocRef, {
          workspaceData: local,
          updatedAt: new Date()
        }, { merge: true });
      }
      console.log("[WorkspaceRepository] Sincronização em nuvem concluída com sucesso.");
    } catch (error) {
      console.error("[WorkspaceRepository] Falha na sincronização forçada de workspace:", error);
    }
  }
}
