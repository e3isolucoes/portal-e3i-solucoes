import { Company, WorkspaceProject } from "../types";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import { collection, doc, setDoc, deleteDoc, onSnapshot, query, where, getDocs, getDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

export class CompanyProjectRepository {
  private static cachedCompanies: Company[] = [];
  private static cachedProjects: WorkspaceProject[] = [];
  private static cachedProjectDataStore: Record<string, any> = {};
  private static lastSyncedProjectData: Record<string, string> = {};

  private static listeners: Set<() => void> = new Set();
  private static companyUnsubscribe: (() => void) | null = null;
  private static projectUnsubscribers: Record<string, () => void> = {};

  static {
    // Proactively subscribe to auth state changes to trigger real-time Firestore sync
    onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        let isAdmin = false;
        
        // Instant check to avoid wait time for userDoc query
        if (
          firebaseUser.email === "admin@sixsigma.com" ||
          firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
          firebaseUser.email?.toLowerCase().includes("admin")
        ) {
          isAdmin = true;
        }

        if (!isAdmin) {
          try {
            const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
            if (userDoc.exists()) {
              const role = userDoc.data()?.role;
              if (
                role === "Admin" ||
                role === "Administrador" ||
                firebaseUser.email === "admin@sixsigma.com" ||
                firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
                firebaseUser.email?.toLowerCase().includes("admin")
              ) {
                isAdmin = true;
              }
            }
          } catch (e) {
            console.warn("[CompanyProjectRepository] Failed to fetch user role from doc on auth change:", e);
          }
        }

        if (!isAdmin) {
          try {
            const savedProfile = localStorage.getItem(`lss_user_profile_${firebaseUser.uid}`);
            if (savedProfile) {
              const role = JSON.parse(savedProfile).role;
              if (
                role === "Admin" ||
                role === "Administrador" ||
                firebaseUser.email === "admin@sixsigma.com" ||
                firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
                firebaseUser.email?.toLowerCase().includes("admin")
              ) {
                isAdmin = true;
              }
            }
          } catch {}
        }

        this.startFirestoreSync(firebaseUser.uid, isAdmin);
      } else {
        this.clearCache();
      }
    });
  }

  /**
   * Registers a listener to receive cached data update events.
   */
  static addChangeListener(listener: () => void): () => void {
    this.listeners.add(listener);
    // Invoke immediately to initialize state
    listener();
    return () => {
      this.listeners.delete(listener);
    };
  }

  private static notifyListeners() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (err) {
        console.error("[CompanyProjectRepository] Error invoking listener:", err);
      }
    });
  }

  /**
   * Reset in-memory cache and unsubscribe from Firestore updates.
   */
  private static clearCache() {
    if (this.companyUnsubscribe) {
      this.companyUnsubscribe();
      this.companyUnsubscribe = null;
    }
    Object.values(this.projectUnsubscribers).forEach((unsub) => unsub());
    this.projectUnsubscribers = {};

    this.cachedCompanies = [];
    this.cachedProjects = [];
    this.cachedProjectDataStore = {};
    this.notifyListeners();
  }

  /**
   * Spawns listeners for real-time companies list matching the logged-in user uid.
   */
  public static startFirestoreSync(uid: string, isAdmin: boolean = false) {
    if (this.companyUnsubscribe) {
      this.companyUnsubscribe();
    }

    // Instantly load local cache for flawless offline-first usage
    if (typeof window !== "undefined") {
      try {
        const savedComp = localStorage.getItem(`lss_cached_companies_${uid}`);
        if (savedComp) this.cachedCompanies = JSON.parse(savedComp);

        const savedProj = localStorage.getItem(`lss_cached_projects_${uid}`);
        if (savedProj) this.cachedProjects = JSON.parse(savedProj);

        const savedDataStore = localStorage.getItem(`lss_cached_project_datastore_${uid}`);
        if (savedDataStore) this.cachedProjectDataStore = JSON.parse(savedDataStore);

        this.notifyListeners();
      } catch (e) {
        console.warn("[CompanyProjectRepository] Error loading local caches:", e);
      }
    }

    try {
      const qCompanies = isAdmin 
        ? collection(db, "companies")
        : query(collection(db, "companies"), where("ownerId", "==", uid));

      this.companyUnsubscribe = onSnapshot(
        qCompanies,
        (snapshot) => {
          const list: Company[] = [];
          snapshot.forEach((snapDoc) => {
            const data = snapDoc.data();
            list.push({
              id: snapDoc.id,
              name: data.name || "",
              cnpj: data.cnpj || "",
              industry: data.industry || "",
              createdAt: data.createdAt || new Date().toISOString(),
              enabledModules: data.enabledModules || [],
              ownerId: data.ownerId || "",
              diagnosticData: data.diagnosticData || null,
              strategicPlanning: data.strategicPlanning || null,
              kpiConfig: data.kpiConfig || null,
            });
          });

          this.cachedCompanies = list;
          if (typeof window !== "undefined") {
            try {
              localStorage.setItem(`lss_cached_companies_${uid}`, JSON.stringify(list));
            } catch (e) {
              console.warn("[CompanyProjectRepository] Failed to save companies list to local storage:", e);
            }
          }
          this.syncProjectsForCompanies(uid, list, isAdmin);
          this.notifyListeners();
        },
        (err) => {
          console.error("[CompanyProjectRepository] companies subscription failed:", err);
          handleFirestoreError(err, OperationType.GET, "companies");
        }
      );
    } catch (err) {
      console.error("[CompanyProjectRepository] Failed to setup companies sync:", err);
    }
  }

  /**
   * Spawns real-time project subcollection listeners for every company matching the user ownership.
   */
  private static syncProjectsForCompanies(uid: string, companiesList: Company[], isAdmin: boolean = false) {
    const currentCompIds = new Set(companiesList.map((c) => c.id));
    Object.keys(this.projectUnsubscribers).forEach((compId) => {
      if (!currentCompIds.has(compId)) {
        this.projectUnsubscribers[compId]();
        delete this.projectUnsubscribers[compId];
      }
    });

    companiesList.forEach((company) => {
      if (this.projectUnsubscribers[company.id]) return;

      try {
        const projectCollectionRef = isAdmin
          ? collection(db, "companies", company.id, "projects")
          : query(
              collection(db, "companies", company.id, "projects"),
              where("ownerId", "==", uid)
            );

        const unsub = onSnapshot(
          projectCollectionRef,
          (snapshot) => {
            // Unify cleaning of cached projects for this company
            this.cachedProjects = this.cachedProjects.filter((p) => p.companyId !== company.id);

            snapshot.forEach((snapDoc) => {
              const data = snapDoc.data();
              const pId = snapDoc.id;

              const proj: WorkspaceProject = {
                id: pId,
                companyId: company.id,
                name: data.name || "",
                objective: data.objective || "",
                status: data.status || "Planejado",
                createdAt: data.createdAt || new Date().toISOString(),
                ownerId: data.ownerId || "",
                strategicFrontId: data.strategicFrontId || "",
              };

              this.cachedProjects.push(proj);

              // Capture Six Sigma metrics and structured design properties nested securely in project doc
              const projectDataPayload = {
                companyId: company.id,
                steps: data.steps || [],
                arrivalRate: data.arrivalRate || 10,
                charter: data.charter || null,
                sipoc: data.sipoc || null,
                controlPlans: data.controlPlans || [],
                activeAreaId: data.activeAreaId || "core_ops",
                processesByArea: data.processesByArea || null,
                deliverables: data.deliverables || null,
                projectActions: data.projectActions || null,
                projectHistory: data.projectHistory || null,
                projectDetails: data.projectDetails || null,
              };

              this.cachedProjectDataStore[pId] = projectDataPayload;
              this.lastSyncedProjectData[pId] = JSON.stringify(projectDataPayload);
            });

            if (typeof window !== "undefined") {
              try {
                localStorage.setItem(`lss_cached_projects_${uid}`, JSON.stringify(this.cachedProjects));
                localStorage.setItem(`lss_cached_project_datastore_${uid}`, JSON.stringify(this.cachedProjectDataStore));
              } catch (e) {
                console.warn("[CompanyProjectRepository] Failed to save projects/datastore cache:", e);
              }
            }

            this.notifyListeners();
          },
          (err) => {
            console.error(`[CompanyProjectRepository] projects subscription failed for company ${company.id}:`, err);
            handleFirestoreError(err, OperationType.GET, `companies/${company.id}/projects`);
          }
        );

        this.projectUnsubscribers[company.id] = unsub;
      } catch (err) {
        console.error(`[CompanyProjectRepository] Failed to setup projects sync for company ${company.id}:`, err);
      }
    });
  }

  /**
   * Retrieves all companies from corporate in-memory cache.
   */
  static getCompanies(email?: string): Company[] {
    return this.cachedCompanies;
  }

  /**
   * Forcefully fetches all companies from Cloud Firestore immediately.
   * Useful to guarantee that the Admin has access to the most up-to-date and complete list instantly.
   */
  public static async fetchAllCompaniesImmediate(): Promise<Company[]> {
    try {
      const q = collection(db, "companies");
      const snapshot = await getDocs(q);
      const list: Company[] = [];
      snapshot.forEach((snapDoc) => {
        const data = snapDoc.data();
        list.push({
          id: snapDoc.id,
          name: data.name || "",
          cnpj: data.cnpj || "",
          industry: data.industry || "",
          createdAt: data.createdAt || new Date().toISOString(),
          enabledModules: data.enabledModules || [],
          ownerId: data.ownerId || "",
          diagnosticData: data.diagnosticData || null,
          strategicPlanning: data.strategicPlanning || null,
          kpiConfig: data.kpiConfig || null,
        });
      });
      this.cachedCompanies = list;
      this.notifyListeners();
      return list;
    } catch (e) {
      console.warn("[CompanyProjectRepository] Failed to forcefully fetch all companies:", e);
      return this.cachedCompanies;
    }
  }

  /**
   * Syncs custom list of companies to Firestore.
   */
  static saveCompanies(companies: Company[], email?: string): void {
    const uid = auth.currentUser ? auth.currentUser.uid : "guest_user";

    const incomingIds = new Set(companies.map((c) => c.id));
    const toDelete = this.cachedCompanies.filter((c) => !incomingIds.has(c.id));

    this.cachedCompanies = companies;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(`lss_cached_companies_${uid}`, JSON.stringify(companies));
      } catch (e) {
        console.warn("[CompanyProjectRepository] Failed to save companies list to local storage:", e);
      }
    }
    this.notifyListeners();

    if (!auth.currentUser) {
      if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
        console.log("[CompanyProjectRepository] Guest Sandbox/Training Mode without auth active. saveCompanies skipped Firestore sync.");
        return;
      }
      console.warn("[CompanyProjectRepository] No active Firebase Auth user. saveCompanies skipped Firestore remote sync (saved locally).");
      return;
    }

    // Async push to Cloud Firestore
    (async () => {
      try {
        for (const comp of companies) {
          try {
            const companyRef = doc(db, "companies", comp.id);
            await setDoc(
              companyRef,
              {
                id: comp.id,
                name: comp.name,
                cnpj: comp.cnpj || "",
                industry: comp.industry || "",
                createdAt: comp.createdAt || new Date().toISOString(),
                ownerId: comp.ownerId || uid,
                updatedAt: new Date().toISOString(),
                enabledModules: comp.enabledModules || [],
                diagnosticData: comp.diagnosticData || null,
                strategicPlanning: comp.strategicPlanning || null,
                kpiConfig: comp.kpiConfig || null,
              },
              { merge: true }
            );
          } catch (companyError) {
            console.warn(`[CompanyProjectRepository] Skipped/Failed to save company doc for ${comp.id}:`, companyError);
            handleFirestoreError(companyError, OperationType.WRITE, `companies/${comp.id}`);
          }
        }

        for (const comp of toDelete) {
          try {
            // Find and delete all subcollection projects belonging to this deleted company to ensure relational atomicity
            const companyProjects = this.cachedProjects.filter((p) => p.companyId === comp.id);
            for (const proj of companyProjects) {
              const projectRef = doc(db, "companies", comp.id, "projects", proj.id);
              await deleteDoc(projectRef);
              delete this.cachedProjectDataStore[proj.id];
            }

            // Remove company projects from memory cache
            this.cachedProjects = this.cachedProjects.filter((p) => p.companyId !== comp.id);

            // Sync updated projects and datastore cache to local storage
            if (typeof window !== "undefined") {
              localStorage.setItem(`lss_cached_projects_${uid}`, JSON.stringify(this.cachedProjects));
              localStorage.setItem(`lss_cached_project_datastore_${uid}`, JSON.stringify(this.cachedProjectDataStore));
            }

            const companyRef = doc(db, "companies", comp.id);
            await deleteDoc(companyRef);
          } catch (deleteError) {
            console.warn(`[CompanyProjectRepository] Skipped/Failed to delete company doc for ${comp.id}:`, deleteError);
            handleFirestoreError(deleteError, OperationType.DELETE, `companies/${comp.id}`);
          }
        }

        // Notify listeners after complete sync/cleanup
        this.notifyListeners();
      } catch (err) {
        console.warn("[CompanyProjectRepository] Cloud write error in companies (possibly offline):", err);
      }
    })();
  }

  /**
   * Retrieves all projects from cache.
   */
  static getProjects(email?: string): WorkspaceProject[] {
    return this.cachedProjects;
  }

  /**
   * Saves projects inside isolated company workspaces.
   */
  static saveProjects(projects: WorkspaceProject[], email?: string): void {
    const uid = auth.currentUser ? auth.currentUser.uid : "guest_user";

    // Prune invalid or missing companyIds to guarantee strong relational coupling
    const validatedProjects = projects.map((p) => {
      let companyId = p.companyId;
      if (!companyId || companyId.trim() === "") {
        companyId = this.cachedCompanies[0]?.id || "default_company";
      }
      return { ...p, companyId };
    });

    const incomingIds = new Set(validatedProjects.map((p) => p.id));
    const toDelete = this.cachedProjects.filter((p) => !incomingIds.has(p.id));

    this.cachedProjects = validatedProjects;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(`lss_cached_projects_${uid}`, JSON.stringify(validatedProjects));
      } catch (e) {
        console.warn("[CompanyProjectRepository] Failed to save projects list to local storage:", e);
      }
    }
    this.notifyListeners();

    if (!auth.currentUser) {
      if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
        console.log("[CompanyProjectRepository] Guest Sandbox/Training Mode without auth active. saveProjects skipped Firestore sync.");
        return;
      }
      console.warn("[CompanyProjectRepository] No active Firebase Auth user. saveProjects skipped Firestore remote sync (saved locally).");
      return;
    }

    // Async push to Cloud Firestore
    (async () => {
      try {
        for (const proj of validatedProjects) {
          try {
            const projectRef = doc(db, "companies", proj.companyId, "projects", proj.id);
            const pDetails = this.cachedProjectDataStore[proj.id] || {};

            // Atomically ensure the companyId inside pDetails stays linked with the project's companyId
            pDetails.companyId = proj.companyId;
            this.cachedProjectDataStore[proj.id] = pDetails;

            await setDoc(
              projectRef,
              {
                id: proj.id,
                companyId: proj.companyId,
                name: proj.name,
                objective: proj.objective || "",
                status: proj.status || "Planejado",
                createdAt: proj.createdAt || new Date().toISOString(),
                ownerId: proj.ownerId || uid,
                strategicFrontId: proj.strategicFrontId || "",
                updatedAt: new Date().toISOString(),
                ...pDetails,
              },
              { merge: true }
            );
          } catch (projError) {
            console.warn(`[CompanyProjectRepository] Skipped/Failed to save project doc for ${proj.id}:`, projError);
            handleFirestoreError(projError, OperationType.WRITE, `companies/${proj.companyId}/projects/${proj.id}`);
          }
        }

        for (const proj of toDelete) {
          try {
            // Clean up cached analytical process data store key for deleted project
            delete this.cachedProjectDataStore[proj.id];

            // Sync updated datastore cache to local storage
            if (typeof window !== "undefined") {
              localStorage.setItem(`lss_cached_project_datastore_${uid}`, JSON.stringify(this.cachedProjectDataStore));
            }

            const projectRef = doc(db, "companies", proj.companyId, "projects", proj.id);
            await deleteDoc(projectRef);
          } catch (deleteError) {
            console.warn(`[CompanyProjectRepository] Skipped/Failed to delete project doc for ${proj.id}:`, deleteError);
            handleFirestoreError(deleteError, OperationType.DELETE, `companies/${proj.companyId}/projects/${proj.id}`);
          }
        }

        // Notify listeners after complete sync
        this.notifyListeners();
      } catch (err) {
        console.warn("[CompanyProjectRepository] Cloud write error in projects_batch (possibly offline):", err);
      }
    })();
  }

  /**
   * Retrieves detailed project analytical data store mapping.
   */
  static getProjectDataStore(email?: string): Record<string, any> {
    return this.cachedProjectDataStore;
  }

  /**
   * Saves structural Six Sigma modeling configurations under project document workspace.
   */
  static saveProjectDataStore(store: Record<string, any>, email?: string): void {
    const uid = auth.currentUser ? auth.currentUser.uid : "guest_user";

    // Prune orphaned keys in the store that do not belong to any active project
    const activeProjectIds = new Set(this.cachedProjects.map((p) => p.id));
    const prunedStore: Record<string, any> = {};
    for (const [projectId, data] of Object.entries(store)) {
      if (activeProjectIds.has(projectId)) {
        prunedStore[projectId] = data;
      }
    }

    // Optimization check 1: If prunedStore is exactly identical to our current cache, skip the rest!
    if (JSON.stringify(this.cachedProjectDataStore) === JSON.stringify(prunedStore)) {
      return;
    }

    this.cachedProjectDataStore = prunedStore;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(`lss_cached_project_datastore_${uid}`, JSON.stringify(prunedStore));
      } catch (e) {
        console.warn("[CompanyProjectRepository] Failed to save project datastore to local storage:", e);
      }
    }
    this.notifyListeners();

    if (!auth.currentUser) {
      if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
        console.log("[CompanyProjectRepository] Guest Sandbox/Training Mode active. saveProjectDataStore skipped Firestore sync.");
        return;
      }
      console.warn("[CompanyProjectRepository] No active Firebase Auth user. saveProjectDataStore skipped Firestore remote sync (saved locally).");
      return;
    }

    // Async push to Cloud Firestore
    (async () => {
      try {
        for (const [projectId, data] of Object.entries(prunedStore)) {
          let companyId = data?.companyId;
          if (!companyId) {
            const proj = this.cachedProjects.find((p) => p.id === projectId);
            if (proj) {
              companyId = proj.companyId;
              data.companyId = companyId; // Make sure the data payload is linked and updated
            }
          }
          if (!companyId) {
            console.warn(`[CompanyProjectRepository] Skipping datastore write for project ${projectId} due to missing companyId binding.`);
            continue;
          }

          // Build static layout representation of this project's analytical config
          const payload = {
            companyId: companyId,
            steps: data.steps || [],
            arrivalRate: data.arrivalRate || 10,
            charter: data.charter || null,
            sipoc: data.sipoc || null,
            controlPlans: data.controlPlans || [],
            activeAreaId: data.activeAreaId || "core_ops",
            processesByArea: data.processesByArea || null,
            deliverables: data.deliverables || null,
            projectActions: data.projectActions || null,
            projectHistory: data.projectHistory || null,
            projectDetails: data.projectDetails || null,
          };

          const stringifiedPayload = JSON.stringify(payload);
          // Optimization check 2: If payload is identical to the last successfully synced/loaded copy, skip the Firestore write!
          if (this.lastSyncedProjectData[projectId] === stringifiedPayload) {
            continue;
          }

          try {
            const projectRef = doc(db, "companies", companyId, "projects", projectId);
            await setDoc(
              projectRef,
              {
                ...payload,
                updatedAt: new Date().toISOString(),
              },
              { merge: true }
            );
            // Cache successful synchronization
            this.lastSyncedProjectData[projectId] = stringifiedPayload;
          } catch (storeError) {
            console.warn(`[CompanyProjectRepository] Skipped/Failed to save project datastore for ${projectId}:`, storeError);
            handleFirestoreError(storeError, OperationType.WRITE, `companies/${companyId}/projects/${projectId}`);
          }
        }
      } catch (err) {
        console.warn("[CompanyProjectRepository] Cloud write error in projectDataStore (possibly offline):", err);
      }
    })();
  }
}
