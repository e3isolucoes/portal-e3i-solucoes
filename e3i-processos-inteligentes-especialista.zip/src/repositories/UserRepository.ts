import { onAuthStateChanged, signOut as firebaseSignOut, User as FirebaseUser } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, handleFirestoreError, OperationType } from "../firebase";
import { LoggedUser } from "../components/AuthCover";

export class UserRepository {
  /**
   * Subscribes to Firebase Authentication state changes.
   * Wraps the Firebase onAuthStateChanged and handles the loading profile from firestore.
   */
  static subscribeToAuth(
    onUserChanged: (user: LoggedUser | null, rawUser: FirebaseUser | null, cloudData?: any) => void
  ) {
    return onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, "users", firebaseUser.uid);
          // Try to get from localStorage first / fallback on offline
          let localProfile: LoggedUser | null = null;
          let localWorkspaceData: any = null;
          try {
            const savedProfilStr = localStorage.getItem(`lss_user_profile_${firebaseUser.uid}`);
            if (savedProfilStr) localProfile = JSON.parse(savedProfilStr);
            const savedWorkspaceStr = localStorage.getItem(`lss_workspace_data_${firebaseUser.uid}`);
            if (savedWorkspaceStr) localWorkspaceData = JSON.parse(savedWorkspaceStr);
          } catch (e) {
            console.warn("[UserRepository] Failed to parse local storage cache:", e);
          }

          let userDoc;
          try {
            userDoc = await getDoc(userDocRef);
            if (userDoc && userDoc.exists()) {
              const data = userDoc.data();
              let role = data.role || "Consultor Lean Six Sigma";
              let belt: "Green Belt" | "Yellow Belt" | "Black Belt" | "Master Black Belt" = data.belt || "Green Belt";
              if (
                firebaseUser.email === "admin@sixsigma.com" ||
                firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
                firebaseUser.email?.toLowerCase().includes("admin")
              ) {
                role = "Admin";
                belt = "Master Black Belt";
              }
              const profile: LoggedUser = {
                fullName: data.fullName || firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Usuário",
                email: firebaseUser.email || "",
                role,
                belt,
              };
              try {
                localStorage.setItem(`lss_user_profile_${firebaseUser.uid}`, JSON.stringify(profile));
                if (data.workspaceData) {
                  localStorage.setItem(`lss_workspace_data_${firebaseUser.uid}`, JSON.stringify(data.workspaceData));
                }
              } catch (e) {
                console.warn("[UserRepository] Failed to save profile/workspace to localStorage cache:", e);
              }
              onUserChanged(profile, firebaseUser, data.workspaceData || localWorkspaceData);
            } else {
              // New user registration
              const nameVal = firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Usuário";
              let role = "Consultor Lean Six Sigma";
              let belt: "Green Belt" | "Yellow Belt" | "Black Belt" | "Master Black Belt" = "Green Belt";
              if (
                firebaseUser.email === "admin@sixsigma.com" ||
                firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
                firebaseUser.email?.toLowerCase().includes("admin")
              ) {
                role = "Admin";
                belt = "Master Black Belt";
              }
              const profile: LoggedUser = {
                fullName: nameVal,
                email: firebaseUser.email || "",
                role,
                belt,
              };
              try {
                localStorage.setItem(`lss_user_profile_${firebaseUser.uid}`, JSON.stringify(profile));
              } catch (e) {
                console.warn("[UserRepository] Failed to save profile to localStorage:", e);
              }
              try {
                await setDoc(userDocRef, {
                  fullName: nameVal,
                  email: firebaseUser.email || "",
                  role,
                  belt,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp()
                });
              } catch (err) {
                handleFirestoreError(err, OperationType.CREATE, `users/${firebaseUser.uid}`);
                onUserChanged(profile, firebaseUser, localWorkspaceData);
                return;
              }
              onUserChanged(profile, firebaseUser);
            }
          } catch (err) {
            console.warn("[UserRepository] Cloud connection unavailable or timed out. Falling back to offline local profile.", err);
            let fallbackRole = localProfile?.role || "Consultor Lean Six Sigma";
            let fallbackBelt: "Green Belt" | "Yellow Belt" | "Black Belt" | "Master Black Belt" = localProfile?.belt || "Green Belt";
            if (
              firebaseUser.email === "admin@sixsigma.com" ||
              firebaseUser.email === "marcoantoniomiranda713@gmail.com" ||
              firebaseUser.email?.toLowerCase().includes("admin")
            ) {
              fallbackRole = "Admin";
              fallbackBelt = "Master Black Belt";
            }
            const fallbackProfile: LoggedUser = {
              fullName: localProfile?.fullName || firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Usuário",
              email: firebaseUser.email || "",
              role: fallbackRole,
              belt: fallbackBelt,
            };
            onUserChanged(fallbackProfile, firebaseUser, localWorkspaceData);
          }
        } catch (err) {
          console.error("[UserRepository] Error fetching user profile:", err);
          onUserChanged(null, firebaseUser);
        }
      } else {
        onUserChanged(null, null);
      }
    });
  }

  /**
   * Log out active user session.
   */
  static async logout(): Promise<void> {
    try {
      await firebaseSignOut(auth);
    } catch (err) {
      console.error("[UserRepository] Error signing out:", err);
      throw err;
    }
  }

  /**
   * Sync active workspace data to Firestore cloud.
   */
  static async syncWorkspaceData(uid: string, workspaceData: any): Promise<void> {
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(`lss_workspace_data_${uid}`, JSON.stringify(workspaceData));
      } catch (e) {
        console.warn("[UserRepository] Failed to write workspace data to localStorage cache:", e);
      }
    }
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      console.log("[UserRepository] Sandbox/Training Mode is active. syncWorkspaceData skipped Firestore sync.");
      return;
    }
    const userDocRef = doc(db, "users", uid);
    try {
      await setDoc(userDocRef, { workspaceData }, { merge: true });
    } catch (err) {
      console.warn("[UserRepository] Cloud save failed during syncWorkspaceData (possibly offline):", err);
    }
  }
}
