/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProcessStep {
  id: string;
  name: string;
  resource: string; // Responsible person / role / resource pool
  resourceCount: number; // Number of parallel servers/operators
  processingTime: number; // Mean cycle time (minutes)
  standardDeviation: number; // Processing time standard deviation (variability)
  yieldRate: number; // Quality rate (0.0 to 1.0)
  setupTime: number; // Setup time in minutes (for Lean SMED analysis)
  description?: string;
  
  // Operational execution and support assets
  stepInstructions?: string[];
  requiredInputs?: string[];
  automations?: { title: string; type: string; status: 'active' | 'proposed'; description: string }[];
  supportDocuments?: { name: string; code: string; type: 'SOP' | 'Checklist' | 'Manual' | 'Form'; rev: string }[];
  
  // Flowchart specific props for visual mapping
  x?: number; // X position in visual canvas
  y?: number; // Y position in visual canvas
  shapeType?: 'START' | 'END' | 'ACTIVITY' | 'DECISION'; // Node shape
  nextStepId?: string; // Standard next step connection
  yesStepId?: string; // Branch if DECISION is 'Sim'
  noStepId?: string; // Branch if DECISION is 'Não'

  // Sub-processes and Process-to-Process Relationships
  subProcesses?: { id: string; name: string; resource: string; processingTime: number; yieldRate: number; description?: string }[];
  linkedProcesses?: { targetAreaId: string; targetAreaName: string; description: string }[];
  
  // Custom SIPOC fields for each individual process step
  suppliers?: string[];
  outputs?: string[];
  customers?: string[];

  // Calculated properties after analysis
  utilization?: number; // % utilization of this step
  capacityPerHour?: number; // maximum units per hour this step can process
  queueTime?: number; // estimated average waiting time in queue (minutes, using G/G/1 queueing theory)
  wip?: number; // average Work in Progress at this step (units)
  isBottleneck?: boolean;
  completed?: boolean;

  // E3I Evidence tracker origin
  evidenceOrigin?: 'SYSTEM' | 'USER_DECLARATION' | 'DOCUMENT' | 'INFERENCE' | 'PREMISE' | 'BENCHMARK';

  // DMAIC synchronized diagnostic mapping properties
  dmaicProblemScope?: string;
  dmaicProjectGoal?: string;
  dmaicTargetMetric?: number;
  dmaicMeasurements?: number[];
  dmaicIshikawaCauses?: {
    metodo: string[];
    maquina: string[];
    maoDeObra: string[];
    material: string[];
    medida: string[];
    meioAmbiente: string[];
  };
  dmaicEnablePokaYoke?: boolean;
  dmaicEnableSMED?: boolean;
  dmaicEnableBalancing?: boolean;
  dmaicLcl?: number;
  dmaicUcl?: number;
  dmaicCtrlResponsible?: string;
  dmaicCtrlReaction?: string;
  dmaicEvidences?: { id: string; name: string; type: string; url?: string; date: string; valueCount?: number; description?: string }[];
}

export interface Sipoc {
  suppliers: string;
  inputs: string;
  processDescription: string;
  outputs: string;
  customers: string;
}

export interface ProjectCharter {
  title: string;
  problemStatement: string;
  goal: string;
  metric: 'cycle_time' | 'defect_rate' | 'throughput';
  targetValue: number;
}

export interface ControlPlan {
  id: string;
  stepName: string;
  metric: string;
  ucl: number; // Upper Control Limit
  lcl: number; // Lower Control Limit
  target: number;
  frequency: string;
  responsible: string;
  reactionPlan: string;
  currentReading?: number; // Last measured sampled reading
  enableAlarm?: boolean;  // Toggle automatic monitoring and alerts
  warningEmail?: string;  // Email for moderate deviations (e.g. outside target but within UCL/LCL or < 3σ but > 2σ)
  criticalEmail?: string; // Email for critical violations (3σ)
}

export interface ProcessMetrics {
  arrivalRate: number; // Demand rate (units / hour)
  totalSteps: number;
  bottleneckStepName: string;
  systemCapacity: number; // units / hour (determined by bottleneck)
  systemUtilization: number; // overall process utilization %
  leadTime: number; // Total system lead time (processing + queueing times, minutes)
  processingTimeSum: number; // Total core touch time (minutes)
  rolledFirstPassYield: number; // Compound quality (0.0 to 1.0)
  sigmaLevel: number; // Compounded Six Sigma quality level
  dpmo: number; // Defects Per Million Opportunities
  systemWip: number; // Total WIP in the system (using Little's Law: arrivalRate * leadTime)
  stdevProcess: number; // Compound standard deviation
}

// Simulated log entry for Measure phase
export interface SimulationLog {
  timestamp: string;
  unitId: number;
  stepId: string;
  stepName: string;
  duration: number; // actual minutes spent (with variability)
  setupApplied: number; // setup time spent
  defect: boolean; // if this run produced a defect
  queueDuration: number; // calculated queue time before processing
  completedAt: string;
}

// DMAIC Phase definitions
export type DmaicPhaseType = 'DEFINE' | 'MEASURE' | 'ANALYZE' | 'IMPROVE' | 'CONTROL';

export interface DmaicPhaseState {
  currentPhase: DmaicPhaseType;
  completedPhases: DmaicPhaseType[];
}

// AI optimization result
export interface AiOptimizationResult {
  executiveSummary: string;
  dmaicApproach: {
    define: string;
    measure: string;
    analyze: string;
    improve: string;
    control: string;
  };
  orRecommendations: {
    title: string;
    description: string;
    expectedImpact: string;
    leanPrinciple: string;
  }[];
}

export interface Company {
  id: string;
  name: string;
  cnpj?: string;
  industry?: string;
  createdAt: string;
  enabledModules?: string[];
  enabledMethodologies?: string[];
  ownerId?: string;
  diagnosticData?: any;
  strategicPlanning?: StrategicPlanning | null;
  kpiConfig?: {
    showSigma: boolean;
    showLeadTime: boolean;
    showRolledYield: boolean;
    showRoi: boolean;
    showHealthScore: boolean;
  } | null;
}

export interface StrategicObjective {
  id: string;
  title: string;
  target: string;
  indicator: string;
}

export interface StrategicFront {
  id: string;
  name: string;
  description: string;
  objectives: StrategicObjective[];
}

export interface StrategicPlanning {
  mission: string;
  vision: string;
  values: string;
  fronts: StrategicFront[];
}

export interface WorkspaceProject {
  id: string;
  companyId: string;
  name: string;
  objective: string;
  status: "Planejado" | "Em Andamento" | "Concluído";
  createdAt: string;
  ownerId?: string;
  strategicFrontId?: string;
  strategicTower?: "FINANCE" | "CUSTOMER" | "OPERATIONS" | "PEOPLE_INNOVATION" | string;
}

// === CENTRAL BUSINESS CLASS CONTROLLER TYPE LEVEL SYNC ===

export interface Organization {
  id: string;
  name: string;
  createdAt: string;
}

export interface BusinessUnit {
  id: string;
  companyId: string;
  name: string;
  segment: "manufatura" | "financeiro" | "contabil" | "fiscal" | "servicos" | "comercio" | "logistica" | "tecnologia" | "saude" | "rh";
  createdAt: string;
}

export interface Portfolio {
  id: string;
  businessUnitId: string;
  name: string;
  createdAt: string;
}

export interface Process {
  id: string;
  projectId: string;
  name: string;
  segment: "manufatura" | "financeiro" | "contabil" | "fiscal" | "servicos" | "comercio" | "logistica" | "tecnologia" | "saude" | "rh";
  createdAt: string;
  terminologies: {
    demandUnit: string;      // e.g., "placas", "faturas", "chamados"
    timeUnit: string;        // e.g., "minutos", "horas", "dias"
    financialUnit: string;   // e.g., "R$", "USD"
    stepTerm: string;        // e.g., "Posto", "Atividade", "Fase"
  };
}

export type DeliverableStatus =
  | "not_started"
  | "in_progress"
  | "waiting_approval"
  | "approved"
  | "rejected"
  | "blocked";

export interface Deliverable {
  id: string;
  projectId: string;
  processId?: string;
  stepId?: string;
  createdAt: string;
  
  // Phase 4 strict fields
  phaseId: string; // dmaic phase e.g. "DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"
  name: string;
  description?: string;
  required: boolean;
  weight: number;
  status: DeliverableStatus;
  responsibleUserId: string | null;
  dueDate: string | null;
  approvedBy: string | null;
  approvedAt: string | null;
  evidenceIds: string[];
  blockerReason?: string;
  comments?: { id: string; user: string; text: string; date: string }[];
}

export interface Evidence {
  id: string;
  projectId: string;
  processId?: string;
  stepId?: string;
  deliverableId?: string;
  name: string;
  origin: "SYSTEM" | "USER_DECLARATION" | "DOCUMENT" | "INFERENCE" | "PREMISE" | "BENCHMARK";
  fileUrl?: string;
  createdAt: string;
}

export interface Action {
  id: string;
  projectId: string;
  processId?: string;
  stepId?: string;
  evidenceId?: string;
  description: string;
  responsible: string;
  dueDate: string;
  contentType?: string;
  status: "Pendente" | "Em Andamento" | "Concluído";
  createdAt: string;

  // New Phase 4 action properties
  origin: string; // Origem (e.g. "Definir", "Medir", etc.)
  priority: "Baixa" | "Média" | "Alta" | "Crítica";
  dependencies?: string[];
  evidences?: string[]; // proof files names or ids
  comments?: { id: string; user: string; text: string; date: string }[];
}

export interface ProjectHistoryItem {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  description: string;
  type: "phase_change" | "status_change" | "approval" | "rejection" | "deadline_change" | "responsible_change" | "evidence_added" | "indicator_updated" | "other";
  ip?: string;
}

export interface Period {
  startDate: string;
  endDate: string;
}

export interface BusinessProfile {
  fullName: string;
  email: string;
  role: string;
  belt: "Yellow Belt" | "Green Belt" | "Black Belt" | "Master Black Belt";
  permissions: string[];
}

export interface BusinessContext {
  organizationId: string | null;
  companyId: string | null;
  businessUnitId: string | null;
  portfolioId: string | null;
  projectId: string | null;
  processId: string | null;
  period: Period | null;
}

export type Permission =
  | "platform:view"
  | "company:view"
  | "company:manage"
  | "project:view"
  | "project:create"
  | "project:edit"
  | "project:delete"
  | "process:view"
  | "process:create"
  | "process:edit"
  | "process:delete"
  | "process:advanced-analysis"
  | "process:export"
  | "operation:view"
  | "operation:manage-kanban"
  | "operation:create-action"
  | "operation:edit-action"
  | "operation:export"
  | "report:view"
  | "report:export"
  | "admin:view"
  | "admin:manage-users"
  | "admin:manage-settings"
  | "ai:use"
  | "ai:advanced";

export type AuthenticatedUser = {
  id: string;
  name: string;
  email?: string;
  roles: string[];
  permissions: Permission[];
};

export interface ScheduledAudit {
  id: string;
  taskName: string;
  processName: string;
  responsibleId: string;
  responsibleName: string;
  responsibleEmail: string;
  frequency: "Diária" | "Semanal" | "Mensal" | "Trimestral";
  startDate: string;
  status: "Pendente" | "Concluída" | "Atrasada";
  createdAt: string;
}




