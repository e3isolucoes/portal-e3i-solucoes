export interface PdcaStep {
  id: string;
  phase: "P" | "D" | "C" | "A";
  phaseLabel: string;
  label: string;
  subtitle: string;
  whereToClick: string;
  whatToFill: string;
  whereItImpacts: string;
  targetView: string;
}

export const PDCA_STEPS: PdcaStep[] = [
  {
    id: "step-diagnostic",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Diagnóstico 360°",
    subtitle: "Maturidade e Diagnóstico 7S",
    whereToClick: "Menu Lateral ➔ Diagnóstico Inicial ➔ Diagnóstico 360°",
    whatToFill: "Preencha o formulário do Diagnóstico 7S avaliando os eixos de Estrutura, Sistemas, Valores Compartilhados, Equipe, Habilidades, Estilo de Gestão e Estratégia.",
    whereItImpacts: "Alimenta os diagnósticos preliminares de gargalos de governança e direciona as prioridades para o Termo de Abertura (Project Charter).",
    targetView: "DIAGNOSTIC"
  },
  {
    id: "step-strategy",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Estratégia & OKRs",
    subtitle: "Desdobramento Estratégico",
    whereToClick: "Menu Lateral ➔ Estruturar a Empresa ➔ Estratégia & OKRs",
    whatToFill: "Defina os Objetivos Estratégicos (BSC) e associe Key Results (OKRs) de desempenho para as metas macro da corporação.",
    whereItImpacts: "Alinha os indicadores de qualidade e eficiência operacional do projeto aos objetivos estratégicos dos diretores e investidores.",
    targetView: "STRATEGY"
  },
  {
    id: "step-organization",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Organograma & Papéis",
    subtitle: "Estrutura e Responsáveis",
    whereToClick: "Menu Lateral ➔ Estruturar a Empresa ➔ Organograma & Papéis",
    whatToFill: "Monte o organograma operacional do projeto, especificando as lideranças, especialistas (Green Belt, Black Belt) e operadores de linha de frente.",
    whereItImpacts: "Garante rastreabilidade humana na execução das melhorias, conectando responsáveis reais a cada etapa do mapeamento.",
    targetView: "ORGANIZATION"
  },
  {
    id: "step-governance",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Direitos de Decisão",
    subtitle: "Matriz RACI e Governança",
    whereToClick: "Menu Lateral ➔ Estruturar a Empresa ➔ Direitos de Decisão",
    whatToFill: "Preencha a matriz RACI atribuindo quem é Responsável (R), Aprovador (A), Consultado (C) e Informado (I) pelas principais decisões de fluxo.",
    whereItImpacts: "Evita gargalos de decisão de liderança e reduz o tempo de atraso de liberação de pedidos ou conformidade nas filiais.",
    targetView: "GOVERNANCE"
  },
  {
    id: "step-change",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Gestão de Mudança",
    subtitle: "Kotter, ADKAR e Prontidão",
    whereToClick: "Menu Lateral ➔ Estruturar a Empresa ➔ Gestão de Mudança",
    whatToFill: "Avalie a régua de prontidão da equipe técnica (Consciência, Desejo, Conhecimento, Habilidade e Reforço) e mapeie o nível de medo ou resistência interna.",
    whereItImpacts: "Assegura que a implantação do novo layout otimizado não seja sabotada ou abandonada por falta de treinamento ou engajamento operacional.",
    targetView: "CHANGE_MANAGEMENT"
  },
  {
    id: "step-portfolio",
    phase: "P",
    phaseLabel: "Planejar (Plan)",
    label: "Portfólio & Charter",
    subtitle: "Contrato do Projeto (Project Charter)",
    whereToClick: "Menu Lateral ➔ Estruturar o Projeto ➔ Portfólio & Charter",
    whatToFill: "Selecione o projeto ativo, edite o Business Case, formalize o escopo de entrada/saída e estabeleça as metas operacionais (Ex: reduzir tempo de ciclo em 50%).",
    whereItImpacts: "Inicia formalmente o projeto LSS, estabelecendo o benchmark de metas que guiará as simulações e cálculos de capabilidade Sigma.",
    targetView: "PORTFOLIO"
  },
  {
    id: "step-processes",
    phase: "D",
    phaseLabel: "Executar (Do)",
    label: "Mapeamento Processual",
    subtitle: "Desenho do Fluxo BPMN",
    whereToClick: "Menu Lateral ➔ Estruturar o Processo ➔ Mapeamento Processual",
    whatToFill: "Utilize o Mapeador Visual para adicionar/remover postos de atendimento. Informe a quantidade de servidores atuantes e os tempos médios de cada tarefa.",
    whereItImpacts: "Base absoluta para todos os cálculos estocásticos, gráficos de fila e sugestões automatizadas de IA baseadas em gargalos reais.",
    targetView: "PROCESSES"
  },
  {
    id: "step-bistudio",
    phase: "D",
    phaseLabel: "Executar (Do)",
    label: "Simulador de BI & Simulação",
    subtitle: "Simulador Estocástico",
    whereToClick: "Menu Lateral ➔ Dados e BI ➔ Estúdio de BI & Simulação",
    whatToFill: "Ajuste a taxa de chegada de clientes ou ordens e clique em simular para verificar o comportamento da sua empresa frente à oscilação da demanda.",
    whereItImpacts: "Calcula tempos médios de fila, taxa de ocupação de funcionários e o faturamento real esperado sob oscilação probabilística.",
    targetView: "BI_STUDIO"
  },
  {
    id: "step-orhub",
    phase: "C",
    phaseLabel: "Verificar (Check)",
    label: "Pesquisa Operacional",
    subtitle: "Teoria das Filas & Saturação",
    whereToClick: "Menu Lateral ➔ Dados e BI ➔ Pesquisa Operacional",
    whatToFill: "Analise a probabilidade de saturação matemática de cada etapa, verificando o tempo em fila e o dimensionamento ideal sugerido pelo modelo M/M/c.",
    whereItImpacts: "Fornece insights quantitativos sobre a necessidade de remanejar funcionários ou computadores para as etapas que mais geram gargalo no fluxo.",
    targetView: "OR_HUB"
  },
  {
    id: "step-sigmatrend",
    phase: "C",
    phaseLabel: "Verificar (Check)",
    label: "Controle Estatístico",
    subtitle: "SPC, Variabilidade e Desvios",
    whereToClick: "Menu Lateral ➔ Dados e BI ➔ Controle Estatístico",
    whatToFill: "Monitore a carta de controle estatístico de processos (CEP). Avalie os pontos que ultrapassam os limites superior (LSC) e inferior (LIC) de controle.",
    whereItImpacts: "Ajuda a diferenciar desvios de causa comum (ruídos normais) de causas especiais (falhas graves), garantindo a estabilidade operacional antes da padronização.",
    targetView: "SIGMA_TREND"
  },
  {
    id: "step-roi",
    phase: "C",
    phaseLabel: "Verificar (Check)",
    label: "Indicadores de ROI",
    subtitle: "ROI & Impacto de Negócio",
    whereToClick: "Menu Lateral ➔ Resultados ➔ Indicadores de ROI",
    whatToFill: "Insira os custos estimados de investimentos em melhoria e analise o ROI financeiro, o tempo de payback e a economia acumulada anualizada.",
    whereItImpacts: "Traduz as métricas de engenharia (minutos, filas) em linguagem de diretoria (R$ economizados), justificando o orçamento de novos projetos.",
    targetView: "REORGANIZATION_DASHBOARD"
  },
  {
    id: "step-dmaic",
    phase: "A",
    phaseLabel: "Agir (Act)",
    label: "Melhorias DMAIC",
    subtitle: "Roteiro de Ajustes e Refinamentos",
    whereToClick: "Menu Lateral ➔ Otimizar ➔ Melhorias DMAIC",
    whatToFill: "Preencha os planos de contingência, defina ações preventivas para desvios CEP e preencha as lições aprendidas para blindagem do processo.",
    whereItImpacts: "Registra formalmente a solução científica das falhas no banco de inteligência, prevenindo que velhos erros retornem à rotina.",
    targetView: "DMAIC"
  },
  {
    id: "step-reorganization",
    phase: "A",
    phaseLabel: "Agir (Act)",
    label: "Plano de Ação 5W2H",
    subtitle: "Ações de Contenção & Kanban",
    whereToClick: "Menu Lateral ➔ Otimizar ➔ Plano de Ação 5W2H",
    whatToFill: "Cadastre as tarefas no formato 5W2H (O que fazer, Por que, Quem, Quando, Onde, Como e Quanto) e mova os cartões no Kanban físico.",
    whereItImpacts: "Executa operacionalmente as melhorias planejadas, atribuindo prazos e donos para manter o processo no novo rumo otimizado.",
    targetView: "REORGANIZATION"
  },
  {
    id: "step-report",
    phase: "A",
    phaseLabel: "Agir (Act)",
    label: "Apresentação Executiva",
    subtitle: "Relatório LSS & Slides",
    whereToClick: "Menu Lateral ➔ Resultados ➔ Apresentação Executiva",
    whatToFill: "Exporte o relatório executivo consolidado do projeto LSS e use o gerador automático de slides de apresentação para reuniões com sócios.",
    whereItImpacts: "Encerra o ciclo atual com chave de ouro, formaliza a governança corporativa e prepara o ambiente para o reinício da roda PDCA de melhoria contínua.",
    targetView: "REPORT"
  }
];
