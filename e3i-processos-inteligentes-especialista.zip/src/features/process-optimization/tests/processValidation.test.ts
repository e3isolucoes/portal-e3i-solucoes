import { describe, it, expect } from "vitest";
import { validateStrategy, validateAsIs, checkQuantitativeEligibility } from "../hooks/useProcessValidation";
import { StrategyContext, ProcessAsIs, ProcessActivity } from "../types/processOptimization.types";

describe("Process Optimization - Validation Engine Tests", () => {
  describe("validateStrategy", () => {
    it("should fail validation if strategic framework is missing", () => {
      const invalidStrategy: StrategyContext = {
        framework: "" as any,
        objective: "Reduzir tempo de faturamento em 40%",
        businessProblem: "Atendimento manual lento e propenso a erros",
        affectedArea: "Financeiro",
        affectedAudience: "Clientes",
        primaryStrategicIndicator: "Lead Time (minutos)",
        riskOfNoAction: "Perda de clientes importantes",
        expectedOutcome: "Tempo de atendimento menor",
        scope: "Sudeste",
        outOfScope: "Internacional"
      };

      const result = validateStrategy(invalidStrategy);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain("O framework estratégico é obrigatório.");
    });

    it("should fail validation if objective is shorter than 5 characters", () => {
      const invalidStrategy: StrategyContext = {
        framework: "BSC",
        objective: "Red.",
        businessProblem: "Atendimento manual lento e propenso a erros",
        affectedArea: "Financeiro",
        affectedAudience: "Clientes",
        primaryStrategicIndicator: "Lead Time (minutos)",
        riskOfNoAction: "Perda de clientes importantes",
        expectedOutcome: "Tempo de atendimento menor"
      };

      const result = validateStrategy(invalidStrategy);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain("O objetivo principal do projeto é obrigatório (mínimo 5 caracteres).");
    });

    it("should validate successfully with all mandatory fields populated", () => {
      const validStrategy: StrategyContext = {
        framework: "BSC",
        objective: "Reduzir o tempo de triagem fiscal em 40% nas faturas emitidas.",
        businessProblem: "A lentidão na digitação manual gera 15% de retrabalho na controladoria.",
        affectedArea: "Controladoria",
        affectedAudience: "Clientes e Transportadoras",
        primaryStrategicIndicator: "Tempo de triagem (minutos)",
        riskOfNoAction: "Atraso no faturamento e penalidades de SEFAZ.",
        expectedOutcome: "Redução de retrabalhos para patamares abaixo de 2%."
      };

      const result = validateStrategy(validStrategy);
      expect(result.isValid).toBe(true);
      expect(result.errors.length).toBe(0);
    });
  });

  describe("validateAsIs", () => {
    it("should fail validation if process name is missing", () => {
      const invalidAsIs: ProcessAsIs = {
        processName: "",
        processObjective: "Atendimento ágil",
        processInput: "E-mail com fatura",
        expectedOutput: "Fatura validada",
        activities: []
      };

      const result = validateAsIs(invalidAsIs);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain("O nome do processo é obrigatório (mínimo 3 caracteres).");
    });

    it("should fail validation if there are no activities in the process", () => {
      const invalidAsIs: ProcessAsIs = {
        processName: "Faturamento Fiscal",
        processObjective: "Validar e emitir notas",
        processInput: "Pedido aprovado",
        expectedOutput: "Nota emitida",
        activities: []
      };

      const result = validateAsIs(invalidAsIs);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain("O mapeamento precisa conter pelo menos uma atividade principal.");
    });

    it("should validate successfully if all process and activity parameters are correct", () => {
      const validAsIs: ProcessAsIs = {
        processName: "Faturamento Fiscal",
        processObjective: "Validar e emitir notas fiscais",
        processInput: "Pedido de venda aprovado",
        expectedOutput: "Nota fiscal faturada com sucesso",
        activities: [
          {
            id: "act-1",
            name: "Triagem de Documentos",
            description: "Análise inicial dos campos da nota",
            responsible: "Analista Fiscal",
            department: "Controladoria",
            systemUsed: "ERP SAP",
            avgTime: 10,
            timeUnit: "minutos",
            avgVolume: 100,
            frequency: "diaria",
            valueType: "AGREGA_VALOR",
            hasRework: false,
            hasWaiting: false,
            hasApproval: false,
            hasRisk: false
          }
        ]
      };

      const result = validateAsIs(validAsIs);
      expect(result.isValid).toBe(true);
      expect(result.errors.length).toBe(0);
    });
  });

  describe("checkQuantitativeEligibility", () => {
    it("should return eligible: false if any activity has avgTime or avgVolume <= 0", () => {
      const mockActivities: ProcessActivity[] = [
        {
          id: "act-1",
          name: "Triagem",
          description: "Descr",
          responsible: "Analista",
          department: "Controladoria",
          systemUsed: "ERP SAP",
          avgTime: 0, // Invalid time for quantitative analysis
          timeUnit: "minutos",
          avgVolume: 100,
          frequency: "diaria",
          valueType: "AGREGA_VALOR",
          hasRework: false,
          hasWaiting: false,
          hasApproval: false,
          hasRisk: false
        }
      ];

      const eligibility = checkQuantitativeEligibility(mockActivities);
      expect(eligibility.eligible).toBe(false);
      expect(eligibility.missingFields).toContain("Tempo médio (deve ser maior que zero) em todas as atividades");
    });

    it("should return eligible: true if all activities have avgTime and avgVolume > 0", () => {
      const mockActivities: ProcessActivity[] = [
        {
          id: "act-1",
          name: "Triagem",
          description: "Descr",
          responsible: "Analista",
          department: "Controladoria",
          systemUsed: "ERP SAP",
          avgTime: 5,
          timeUnit: "minutos",
          avgVolume: 100,
          frequency: "diaria",
          valueType: "AGREGA_VALOR",
          hasRework: false,
          hasWaiting: false,
          hasApproval: false,
          hasRisk: false
        }
      ];

      const eligibility = checkQuantitativeEligibility(mockActivities);
      expect(eligibility.eligible).toBe(true);
      expect(eligibility.missingFields.length).toBe(0);
    });
  });
});
