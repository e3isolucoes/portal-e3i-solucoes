import React, { useState } from "react";
import { ActionPlanItem, ProcessToBe } from "../types/processOptimization.types";
import { ListTodo, Check, Play, AlertCircle, Plus, Trash2, Calendar, User } from "lucide-react";
import { generateActionPlan } from "../services/processAnalysisService";

interface ActionPlanStepProps {
  toBe: ProcessToBe;
  actionPlan: ActionPlanItem[];
  onChange: (actionPlan: ActionPlanItem[]) => void;
}

export default function ActionPlanStep({
  toBe,
  actionPlan,
  onChange
}: ActionPlanStepProps) {
  const [newTask, setNewTask] = useState<Partial<ActionPlanItem>>({
    task: "",
    what: "",
    why: "",
    who: "",
    where: "",
    when: "",
    how: "",
    howMuch: 0,
    status: "NAO_INICIADO"
  });

  const handleStatusChange = (id: string, status: ActionPlanItem["status"]) => {
    onChange(
      actionPlan.map((item) => (item.id === id ? { ...item, status } : item))
    );
  };

  const handleAddTask = () => {
    if (!newTask.task || !newTask.who) {
      alert("Por favor, informe a Tarefa e o Responsável.");
      return;
    }

    const item: ActionPlanItem = {
      id: `task-${Date.now()}`,
      task: newTask.task,
      what: newTask.what || "",
      why: newTask.why || "",
      who: newTask.who,
      where: newTask.where || "Setor Operacional",
      when: newTask.when || "Imediato",
      how: newTask.how || "",
      howMuch: Number(newTask.howMuch) || 0,
      status: "NAO_INICIADO"
    };

    onChange([...actionPlan, item]);
    setNewTask({
      task: "",
      what: "",
      why: "",
      who: "",
      where: "",
      when: "",
      how: "",
      howMuch: 0,
      status: "NAO_INICIADO"
    });
  };

  const handleRemoveTask = (id: string) => {
    onChange(actionPlan.filter((item) => item.id !== id));
  };

  return (
    <div id="action-plan-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#10B981]/10 p-2 rounded-md shrink-0 self-start text-[#10B981]">
          <ListTodo className="w-5 h-5 text-[#10B981]" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 7: Plano de Ação 5W2H (Execução & Escalonamento)
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Aqui estruturamos as tarefas para viabilizar as mudanças do TO-BE na prática. O modelo 5W2H assegura clareza absoluta sobre Quem, O que, Como e Quanto custará cada projeto de melhoria, evitando omissão de responsabilidade.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Esquerda e Centro: Grid de Controle 5W2H */}
        <div className="lg:col-span-2 space-y-4">
          <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
            📋 Painel Geral de Tarefas Cadastradas ({actionPlan.length})
          </h4>

          {actionPlan.length === 0 ? (
            <div className="p-10 border border-dashed border-slate-800 rounded-lg text-center text-slate-500 font-sans text-xs">
              Nenhuma ação operacional registrada ainda. Cadastre novas ações ao lado.
            </div>
          ) : (
            <div className="space-y-3.5">
              {actionPlan.map((item) => (
                <div key={item.id} className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h5 className="text-xs font-sans font-bold text-slate-100">{item.task}</h5>
                      <p className="text-[10px] text-slate-400 font-sans mt-0.5">
                        <span className="font-bold">O que:</span> {item.what} | <span className="font-bold">Por que:</span> {item.why}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveTask(item.id)}
                      className="p-1 text-slate-500 hover:text-red-500 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Detalhes 5W2H */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-sans text-slate-400 pt-2 border-t border-slate-850/60">
                    <div className="flex gap-1.5 items-center">
                      <User className="w-3.5 h-3.5 text-[#C49746] shrink-0" />
                      <div>
                        <div className="text-[8px] font-mono uppercase text-slate-500">Quem (Who)</div>
                        <div className="font-bold text-slate-350">{item.who}</div>
                      </div>
                    </div>
                    <div className="flex gap-1.5 items-center">
                      <Calendar className="w-3.5 h-3.5 text-[#C49746] shrink-0" />
                      <div>
                        <div className="text-[8px] font-mono uppercase text-slate-500">Quando (When)</div>
                        <div className="font-bold text-slate-350">{item.when}</div>
                      </div>
                    </div>
                    <div>
                      <div className="text-[8px] font-mono uppercase text-slate-500">Como (How)</div>
                      <div className="font-bold text-slate-350 truncate max-w-[100px]" title={item.how}>{item.how || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[8px] font-mono uppercase text-slate-500">Quanto (How Much)</div>
                      <div className="font-bold text-slate-350">R$ {item.howMuch.toLocaleString()}</div>
                    </div>
                  </div>

                  {/* Seletor de Status */}
                  <div className="flex justify-between items-center pt-2 border-t border-slate-850/40">
                    <span className="text-[8px] font-mono uppercase text-slate-500">Status Operacional</span>
                    <div className="flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleStatusChange(item.id, "NAO_INICIADO")}
                        className={`px-2 py-1 rounded text-[9px] font-mono font-bold uppercase transition-all cursor-pointer ${
                          item.status === "NAO_INICIADO"
                            ? "bg-slate-800 text-slate-200 border border-slate-700"
                            : "bg-transparent text-slate-550 hover:text-slate-300"
                        }`}
                      >
                        Pendente
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange(item.id, "EM_ANDAMENTO")}
                        className={`px-2 py-1 rounded text-[9px] font-mono font-bold uppercase transition-all cursor-pointer ${
                          item.status === "EM_ANDAMENTO"
                            ? "bg-amber-950 text-amber-400 border border-amber-800"
                            : "bg-transparent text-slate-550 hover:text-slate-300"
                        }`}
                      >
                        Em Andamento
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange(item.id, "CONCLUIDO")}
                        className={`px-2 py-1 rounded text-[9px] font-mono font-bold uppercase transition-all cursor-pointer ${
                          item.status === "CONCLUIDO"
                            ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                            : "bg-transparent text-slate-550 hover:text-slate-300"
                        }`}
                      >
                        Concluído
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Direita: Formulário de Nova Ação */}
        <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
          <h4 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider">
            ➕ Cadastrar Nova Ação 5W2H
          </h4>

          <div className="space-y-3">
            <div>
              <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                Tarefa / O que fazer *
              </label>
              <input
                type="text"
                value={newTask.task || ""}
                onChange={(e) => setNewTask({ ...newTask, task: e.target.value })}
                placeholder="Ex: Instalar plugin de automação ERP"
                className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
              />
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                O que (What)
              </label>
              <input
                type="text"
                value={newTask.what || ""}
                onChange={(e) => setNewTask({ ...newTask, what: e.target.value })}
                placeholder="Ex: Plugin de automação de faturas"
                className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
              />
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                Por que (Why)
              </label>
              <input
                type="text"
                value={newTask.why || ""}
                onChange={(e) => setNewTask({ ...newTask, why: e.target.value })}
                placeholder="Ex: Eliminar digitação manual redundante"
                className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                  Quem (Who) *
                </label>
                <input
                  type="text"
                  value={newTask.who || ""}
                  onChange={(e) => setNewTask({ ...newTask, who: e.target.value })}
                  placeholder="Ex: Analista de TI"
                  className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                />
              </div>
              <div>
                <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                  Onde (Where)
                </label>
                <input
                  type="text"
                  value={newTask.where || ""}
                  onChange={(e) => setNewTask({ ...newTask, where: e.target.value })}
                  placeholder="Ex: Servidores em Nuvem"
                  className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                  Quando (When)
                </label>
                <input
                  type="text"
                  value={newTask.when || ""}
                  onChange={(e) => setNewTask({ ...newTask, when: e.target.value })}
                  placeholder="Ex: Próxima Segunda"
                  className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                />
              </div>
              <div>
                <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                  Custo (How Much)
                </label>
                <input
                  type="number"
                  min="0"
                  value={newTask.howMuch || ""}
                  onChange={(e) => setNewTask({ ...newTask, howMuch: Number(e.target.value) })}
                  placeholder="Ex: R$ 1500"
                  className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase text-slate-400 mb-1">
                Como (How)
              </label>
              <textarea
                rows={2}
                value={newTask.how || ""}
                onChange={(e) => setNewTask({ ...newTask, how: e.target.value })}
                placeholder="Ex: Instalação via script de deploy no contêiner..."
                className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746] resize-none"
              />
            </div>

            <button
              type="button"
              onClick={handleAddTask}
              className="w-full bg-[#C49746] hover:bg-[#D9A752] text-black p-2 rounded font-sans text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4 text-black stroke-[3]" /> Adicionar Ação
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
