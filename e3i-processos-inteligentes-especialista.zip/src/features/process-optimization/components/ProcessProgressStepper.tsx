import React from "react";
import { Check } from "lucide-react";

interface StepConfig {
  label: string;
  shortLabel: string;
}

interface ProcessProgressStepperProps {
  currentStep: number;
  highestCompletedStep: number;
  onStepClick: (stepIndex: number) => void;
  steps: StepConfig[];
}

export default function ProcessProgressStepper({
  currentStep,
  highestCompletedStep,
  onStepClick,
  steps
}: ProcessProgressStepperProps) {
  // Calcula porcentagem de progresso
  const progressPct = Math.round((highestCompletedStep / (steps.length - 1)) * 100);

  return (
    <div id="process-progress-stepper" className="w-full mb-8">
      {/* Progresso Numérico e Título */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <span className="text-[10px] font-mono font-black uppercase text-slate-400 tracking-widest">
            Fluxo de Consultoria Guiada
          </span>
          <h2 className="text-xl font-serif font-black uppercase tracking-tight text-slate-100">
            Otimização de Processos DMAIC
          </h2>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase">
            Progresso Geral
          </span>
          <p className="text-lg font-mono font-black text-slate-100">
            {progressPct}% <span className="text-xs text-slate-500 font-medium">concluído</span>
          </p>
        </div>
      </div>

      {/* Linha de Progresso Visual */}
      <div className="relative w-full h-1 bg-slate-800 rounded-full mb-6">
        <div 
          className="absolute top-0 left-0 h-full bg-[#C49746] transition-all duration-505 rounded-full"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      {/* Grid de Passos */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {steps.map((step, idx) => {
          const isActive = currentStep === idx;
          const isCompleted = highestCompletedStep >= idx;
          const isClickable = idx === 0 || highestCompletedStep >= idx - 1;

          return (
            <button
              key={idx}
              id={`step-indicator-${idx}`}
              disabled={!isClickable}
              onClick={() => onStepClick(idx)}
              className={`p-2.5 rounded-lg border text-left transition-all relative overflow-hidden flex flex-col justify-between h-[68px] ${
                isActive
                  ? "bg-[#C49746] border-[#D9A752] text-black shadow-lg shadow-amber-600/10"
                  : isCompleted
                  ? "bg-slate-900/60 border-slate-700/80 text-slate-100 hover:bg-slate-800/80 cursor-pointer"
                  : "bg-slate-950/20 border-slate-900 text-slate-500 cursor-not-allowed opacity-60"
              }`}
            >
              <div className="flex justify-between items-start w-full">
                <span className={`text-[9px] font-mono font-black ${isActive ? "text-slate-900" : "text-[#C49746]"}`}>
                  ETAPA 0{idx + 1}
                </span>
                {isCompleted && !isActive && (
                  <Check className="w-3 h-3 text-[#C49746]" />
                )}
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-sans font-black uppercase tracking-tight leading-none mb-0.5">
                  {step.label}
                </span>
                <span className={`text-[8px] font-mono uppercase ${isActive ? "text-slate-800" : "text-slate-400"}`}>
                  {isActive ? "Em Foco" : isCompleted ? "Concluído" : "Bloqueado"}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
