import React, { useState } from "react";
import { ProcessAsIs, ProcessActivity, ActivityValueType } from "../types/processOptimization.types";
import { 
  Plus, 
  Trash2, 
  BookOpen, 
  Info, 
  HelpCircle, 
  AlertTriangle,
  Play,
  Grid,
  Code,
  LayoutList
} from "lucide-react";
import MissingDataAlert from "./MissingDataAlert";
import { validateAsIs, checkQuantitativeEligibility } from "../hooks/useProcessValidation";

interface AsIsStepProps {
  asIs: ProcessAsIs;
  onChange: (asIs: ProcessAsIs) => void;
  showValidationErrors: boolean;
}

export default function AsIsStep({
  asIs,
  onChange,
  showValidationErrors
}: AsIsStepProps) {
  const [activeTab, setActiveTab] = useState<"FORMULARIO" | "TABELA" | "FLUXOGRAMA">("FORMULARIO");
  const [formError, setFormError] = useState<string | null>(null);

  // Estado local para adicionar uma nova atividade
  const [newActivity, setNewActivity] = useState<Partial<ProcessActivity>>({
    name: "",
    description: "",
    responsible: "",
    department: "",
    systemUsed: "",
    avgTime: 10,
    timeUnit: "minutos",
    avgVolume: 100,
    frequency: "diaria",
    valueType: "AGREGA_VALOR",
    hasRework: false,
    reworkRate: 0,
    hasWaiting: false,
    waitingTime: 0,
    hasApproval: false,
    hasRisk: false,
    riskDescription: ""
  });

  const handleGeneralChange = (field: keyof Omit<ProcessAsIs, "activities">, value: string) => {
    onChange({
      ...asIs,
      [field]: value
    });
  };

  const handleAddActivity = () => {
    if (!newActivity.name || !newActivity.responsible) {
      setFormError("Por favor, preencha os campos obrigatórios (Nome da Atividade e Responsável).");
      return;
    }

    setFormError(null);

    const activity: ProcessActivity = {
      id: `act-${Date.now()}`,
      name: newActivity.name,
      description: newActivity.description || "",
      responsible: newActivity.responsible,
      department: newActivity.department || "",
      systemUsed: newActivity.systemUsed || "",
      avgTime: Number(newActivity.avgTime) || 0,
      timeUnit: newActivity.timeUnit || "minutos",
      avgVolume: Number(newActivity.avgVolume) || 0,
      frequency: newActivity.frequency || "diaria",
      valueType: newActivity.valueType || "AGREGA_VALOR",
      hasRework: !!newActivity.hasRework,
      reworkRate: newActivity.hasRework ? Number(newActivity.reworkRate) || 0 : undefined,
      hasWaiting: !!newActivity.hasWaiting,
      waitingTime: newActivity.hasWaiting ? Number(newActivity.waitingTime) || 0 : undefined,
      hasApproval: !!newActivity.hasApproval,
      hasRisk: !!newActivity.hasRisk,
      riskDescription: newActivity.hasRisk ? newActivity.riskDescription || "" : undefined
    };

    onChange({
      ...asIs,
      activities: [...asIs.activities, activity]
    });

    // Reset form local
    setNewActivity({
      name: "",
      description: "",
      responsible: "",
      department: "",
      systemUsed: "",
      avgTime: 10,
      timeUnit: "minutos",
      avgVolume: 100,
      frequency: "diaria",
      valueType: "AGREGA_VALOR",
      hasRework: false,
      reworkRate: 0,
      hasWaiting: false,
      waitingTime: 0,
      hasApproval: false,
      hasRisk: false,
      riskDescription: ""
    });
  };

  const handleRemoveActivity = (id: string) => {
    onChange({
      ...asIs,
      activities: asIs.activities.filter((act) => act.id !== id)
    });
  };

  const validation = validateAsIs(asIs);
  const quantCheck = checkQuantitativeEligibility(asIs.activities);

  // Gera a sintaxe Mermaid para desenhar o fluxograma
  const generateMermaidString = () => {
    if (asIs.activities.length === 0) return "graph TD\n  Start([Mapeamento Vazio])";
    
    let str = "graph TD\n";
    str += "  Start([Início: " + (asIs.processInput || "Entrada") + "]) --> Act0\n";
    
    asIs.activities.forEach((act, idx) => {
      const typeStr = act.valueType === "AGREGA_VALOR" ? " (VA)" : act.valueType === "NVA_NECESSARIA" ? " (NVA-N)" : " (Desperdício)";
      const label = `"${idx + 1}. ${act.name}\n[${act.responsible}]${typeStr}"`;
      
      // Estilo de acordo com agregação de valor
      if (act.valueType === "AGREGA_VALOR") {
        str += `  Act${idx}{${label}}\n`;
      } else if (act.valueType === "NVA_NECESSARIA") {
        str += `  Act${idx}[${label}]\n`;
      } else {
        str += `  Act${idx}(${label})\n`;
      }
      
      // Conexões
      if (idx < asIs.activities.length - 1) {
        str += `  Act${idx} --> Act${idx + 1}\n`;
      } else {
        str += `  Act${idx} --> End([Fim: ${asIs.expectedOutput || "Saída"}])\n`;
      }
    });

    return str;
  };

  return (
    <div id="asis-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#2563EB]/10 p-2 rounded-md shrink-0 self-start text-[#2563EB]">
          <BookOpen className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 2: Mapeamento do Processo Atual — AS-IS
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Aqui mapeamos o processo exatamente como ocorre hoje ("Como É"). Registre as entradas, saídas e a sequência real de atividades. Identifique quais etapas de fato agregam valor sob a perspectiva do cliente (Value Stream Mapping).
          </p>
        </div>
      </div>

      {showValidationErrors && !validation.isValid && (
        <MissingDataAlert errors={validation.errors} />
      )}

      {/* Grid de Informações do Processo */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/20 border border-slate-900 p-4 rounded-lg">
        <div>
          <label className="block text-[10px] font-mono font-black uppercase text-slate-300 mb-1.5">
            Nome do Processo Atual *
          </label>
          <input
            type="text"
            value={asIs.processName}
            onChange={(e) => handleGeneralChange("processName", e.target.value)}
            placeholder="Ex: Faturamento de Pedidos de Venda"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
          />
        </div>
        <div>
          <label className="block text-[10px] font-mono font-black uppercase text-slate-300 mb-1.5">
            Objetivo do Processo *
          </label>
          <input
            type="text"
            value={asIs.processObjective}
            onChange={(e) => handleGeneralChange("processObjective", e.target.value)}
            placeholder="Ex: Emitir notas fiscais e despachar mercadoria em conformidade"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
          />
        </div>
        <div>
          <label className="block text-[10px] font-mono font-black uppercase text-slate-300 mb-1.5">
            Entrada do Processo (Gatilho) *
          </label>
          <input
            type="text"
            value={asIs.processInput}
            onChange={(e) => handleGeneralChange("processInput", e.target.value)}
            placeholder="Ex: Pedido aprovado pelo comercial no ERP"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
          />
        </div>
        <div>
          <label className="block text-[10px] font-mono font-black uppercase text-slate-300 mb-1.5">
            Saída Esperada (Entregável) *
          </label>
          <input
            type="text"
            value={asIs.expectedOutput}
            onChange={(e) => handleGeneralChange("expectedOutput", e.target.value)}
            placeholder="Ex: XML/DANFE faturado e enviado para transportadora"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
          />
        </div>
      </div>

      {/* Seção das Atividades */}
      <div className="border border-slate-850 rounded-lg overflow-hidden">
        
        {/* Barra de Navegação de Atividades */}
        <div className="bg-slate-900/40 border-b border-slate-850 p-3 flex justify-between items-center flex-wrap gap-2">
          <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
            Sequenciador de Atividades ({asIs.activities.length})
          </h4>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab("FORMULARIO")}
              className={`px-3 py-1.5 rounded text-[10px] font-mono font-black uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-all ${
                activeTab === "FORMULARIO" ? "bg-[#C49746] text-black" : "bg-slate-950 text-slate-400 hover:text-white"
              }`}
            >
              <LayoutList className="w-3 h-3" /> Add Atividades
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("TABELA")}
              className={`px-3 py-1.5 rounded text-[10px] font-mono font-black uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-all ${
                activeTab === "TABELA" ? "bg-[#C49746] text-black" : "bg-slate-950 text-slate-400 hover:text-white"
              }`}
            >
              <Grid className="w-3 h-3" /> Tabela Sequencial
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("FLUXOGRAMA")}
              className={`px-3 py-1.5 rounded text-[10px] font-mono font-black uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-all ${
                activeTab === "FLUXOGRAMA" ? "bg-[#C49746] text-black" : "bg-slate-950 text-slate-400 hover:text-white"
              }`}
            >
              <Code className="w-3 h-3" /> Estrutura do Fluxo
            </button>
          </div>
        </div>

        {/* Conteúdo Aba 1: Formulário de Adicionar Atividades */}
        {activeTab === "FORMULARIO" && (
          <div className="p-5 space-y-6">
            {formError && (
              <div id="asis-form-error-banner" className="bg-red-950/40 border border-red-900/50 p-3.5 rounded-lg flex items-center gap-2.5 text-xs text-red-400 font-sans animate-fade-in">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{formError}</span>
              </div>
            )}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Coluna 1 Form: Informações de Identificação */}
              <div className="space-y-4">
                <h5 className="text-[11px] font-mono font-bold uppercase text-[#C49746] border-b border-slate-850 pb-1">
                  Identificação & Papéis
                </h5>
                <div>
                  <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                    Nome da Atividade *
                  </label>
                  <input
                    type="text"
                    value={newActivity.name || ""}
                    onChange={(e) => setNewActivity({ ...newActivity, name: e.target.value })}
                    placeholder="Ex: Conferir itens do pedido"
                    className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                    Responsável (Cargo/Papel) *
                  </label>
                  <input
                    type="text"
                    value={newActivity.responsible || ""}
                    onChange={(e) => setNewActivity({ ...newActivity, responsible: e.target.value })}
                    placeholder="Ex: Conferente de Estoque"
                    className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Departamento
                    </label>
                    <input
                      type="text"
                      value={newActivity.department || ""}
                      onChange={(e) => setNewActivity({ ...newActivity, department: e.target.value })}
                      placeholder="Ex: Logística"
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Sistema Utilizado
                    </label>
                    <input
                      type="text"
                      value={newActivity.systemUsed || ""}
                      onChange={(e) => setNewActivity({ ...newActivity, systemUsed: e.target.value })}
                      placeholder="Ex: SAP ERP"
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    />
                  </div>
                </div>
              </div>

              {/* Coluna 2 Form: Dados Quantitativos (Métricas de Tempo e Volume) */}
              <div className="space-y-4">
                <h5 className="text-[11px] font-mono font-bold uppercase text-[#C49746] border-b border-slate-850 pb-1 flex justify-between">
                  <span>Métricas Táticas</span>
                  <span className="text-[9px] font-medium text-slate-450 uppercase">(Obrigatório para Quantitativa)</span>
                </h5>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Tempo Médio
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={newActivity.avgTime || ""}
                      onChange={(e) => setNewActivity({ ...newActivity, avgTime: Math.max(0, Number(e.target.value)) })}
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Unidade de Tempo
                    </label>
                    <select
                      value={newActivity.timeUnit}
                      onChange={(e) => setNewActivity({ ...newActivity, timeUnit: e.target.value as any })}
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    >
                      <option value="minutos">Minutos</option>
                      <option value="horas">Horas</option>
                      <option value="dias">Dias</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Volume Mensal
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={newActivity.avgVolume || ""}
                      onChange={(e) => setNewActivity({ ...newActivity, avgVolume: Math.max(0, Number(e.target.value)) })}
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                      Frequência
                    </label>
                    <select
                      value={newActivity.frequency}
                      onChange={(e) => setNewActivity({ ...newActivity, frequency: e.target.value as any })}
                      className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                    >
                      <option value="diaria">Diária</option>
                      <option value="semanal">Semanal</option>
                      <option value="mensal">Mensal</option>
                      <option value="sob_demanda">Sob Demanda</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                    Classificação de Valor (VSM)
                  </label>
                  <select
                    value={newActivity.valueType}
                    onChange={(e) => setNewActivity({ ...newActivity, valueType: e.target.value as ActivityValueType })}
                    className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                  >
                    <option value="AGREGA_VALOR">Agrega Valor (VA)</option>
                    <option value="NVA_NECESSARIA">Não Agrega Valor, mas é Necessária (NVA-N)</option>
                    <option value="NVA_DESPERDICIO">Não Agrega Valor (Desperdício Puro)</option>
                  </select>
                </div>
              </div>

              {/* Coluna 3 Form: Desperdícios e Gargalos */}
              <div className="space-y-4">
                <h5 className="text-[11px] font-mono font-bold uppercase text-[#C49746] border-b border-slate-850 pb-1">
                  Desperdícios & Aprovações
                </h5>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newActivity.hasRework}
                      onChange={(e) => setNewActivity({ ...newActivity, hasRework: e.target.checked })}
                      className="rounded text-[#C49746]"
                    />
                    <span>Existe retrabalho nesta etapa?</span>
                  </label>
                  {newActivity.hasRework && (
                    <div className="pl-6 animate-slide-down">
                      <label className="block text-[9px] font-mono text-slate-400 mb-1">
                        Taxa de Retrabalho (%)
                      </label>
                      <input
                        type="number"
                        placeholder="Ex: 15%"
                        value={newActivity.reworkRate || ""}
                        onChange={(e) => setNewActivity({ ...newActivity, reworkRate: Number(e.target.value) })}
                        className="w-full bg-slate-950 border border-slate-850 rounded p-1.5 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                      />
                    </div>
                  )}

                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newActivity.hasWaiting}
                      onChange={(e) => setNewActivity({ ...newActivity, hasWaiting: e.target.checked })}
                      className="rounded text-[#C49746]"
                    />
                    <span>Existe tempo de espera/fila?</span>
                  </label>
                  {newActivity.hasWaiting && (
                    <div className="pl-6 animate-slide-down">
                      <label className="block text-[9px] font-mono text-slate-400 mb-1">
                        Tempo de Fila Estimado (minutos)
                      </label>
                      <input
                        type="number"
                        placeholder="Ex: 30"
                        value={newActivity.waitingTime || ""}
                        onChange={(e) => setNewActivity({ ...newActivity, waitingTime: Number(e.target.value) })}
                        className="w-full bg-slate-950 border border-slate-850 rounded p-1.5 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                      />
                    </div>
                  )}

                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newActivity.hasApproval}
                      onChange={(e) => setNewActivity({ ...newActivity, hasApproval: e.target.checked })}
                      className="rounded text-[#C49746]"
                    />
                    <span>Atividade de Alçada/Aprovação?</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newActivity.hasRisk}
                      onChange={(e) => setNewActivity({ ...newActivity, hasRisk: e.target.checked })}
                      className="rounded text-[#C49746]"
                    />
                    <span>Existe risco de erro ou fraude?</span>
                  </label>
                  {newActivity.hasRisk && (
                    <div className="pl-6 animate-slide-down">
                      <label className="block text-[9px] font-mono text-slate-400 mb-1">
                        Descreva o risco operacional
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Aprovação manual sem controle de alçada"
                        value={newActivity.riskDescription || ""}
                        onChange={(e) => setNewActivity({ ...newActivity, riskDescription: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-850 rounded p-1.5 text-xs text-slate-200 outline-none focus:border-[#C49746]"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Descrição Longa da Atividade */}
            <div>
              <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                Descrição Detalhada do Trabalho Operacional
              </label>
              <textarea
                rows={2}
                value={newActivity.description || ""}
                onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })}
                placeholder="Descreva o que de fato o responsável executa nesta atividade. Ex: Abre o ERP SAP, digita a ordem de venda recebida via e-mail e confere se as informações fiscais estão corretas."
                className="w-full bg-slate-950 border border-slate-850 rounded p-2 text-xs text-slate-200 outline-none focus:border-[#C49746] resize-none"
              />
            </div>

            {/* Botão de Gravação de Atividade */}
            <div className="flex justify-end pt-2 border-t border-slate-850">
              <button
                type="button"
                onClick={handleAddActivity}
                className="bg-[#C49746] hover:bg-[#D9A752] text-black px-4 py-2 rounded-lg font-sans text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md shadow-amber-600/10 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-black stroke-[3]" /> Adicionar Atividade ao Fluxo
              </button>
            </div>
          </div>
        )}

        {/* Conteúdo Aba 2: Tabela de Atividades já cadastradas */}
        {activeTab === "TABELA" && (
          <div className="p-0 animate-fade-in overflow-x-auto">
            {asIs.activities.length === 0 ? (
              <div className="p-10 text-center text-slate-500 font-sans text-xs">
                Nenhuma atividade sequencial cadastrada. Volte para a aba de formulário e cadastre as etapas do processo.
              </div>
            ) : (
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900/60 border-b border-slate-850 text-[10px] font-mono font-black text-slate-400 uppercase tracking-wider">
                    <th className="p-3">Etapa</th>
                    <th className="p-3">Atividade</th>
                    <th className="p-3">Responsável / Área</th>
                    <th className="p-3">Tempo Médio</th>
                    <th className="p-3">Volume</th>
                    <th className="p-3">Tipo VSM</th>
                    <th className="p-3">Atributos</th>
                    <th className="p-3 text-center">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850 bg-slate-950/20">
                  {asIs.activities.map((act, idx) => (
                    <tr key={act.id} className="hover:bg-slate-900/40 text-slate-350">
                      <td className="p-3 font-mono font-bold text-[#C49746]">{idx + 1}</td>
                      <td className="p-3">
                        <div className="font-bold text-slate-100">{act.name}</div>
                        {act.description && <div className="text-[10px] text-slate-500 mt-0.5">{act.description}</div>}
                      </td>
                      <td className="p-3">
                        <div>{act.responsible}</div>
                        <div className="text-[10px] text-slate-500">{act.department} {act.systemUsed ? `| ERP: ${act.systemUsed}` : ""}</div>
                      </td>
                      <td className="p-3 font-mono">
                        {act.avgTime} {act.timeUnit}
                      </td>
                      <td className="p-3 font-mono">
                        {act.avgVolume} {act.frequency}
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-black uppercase ${
                          act.valueType === "AGREGA_VALOR"
                            ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                            : act.valueType === "NVA_NECESSARIA"
                            ? "bg-amber-950 text-amber-400 border border-amber-800"
                            : "bg-rose-950 text-rose-400 border border-rose-800"
                        }`}>
                          {act.valueType === "AGREGA_VALOR" ? "VA" : act.valueType === "NVA_NECESSARIA" ? "NVA-N" : "NVA"}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex flex-wrap gap-1">
                          {act.hasRework && (
                            <span className="text-[9px] bg-red-900/30 text-red-400 px-1 rounded border border-red-950" title="Retrabalho cadastrado">Retrabalho</span>
                          )}
                          {act.hasWaiting && (
                            <span className="text-[9px] bg-yellow-900/30 text-yellow-400 px-1 rounded border border-yellow-950" title="Fila cadastrada">Espera</span>
                          )}
                          {act.hasApproval && (
                            <span className="text-[9px] bg-purple-900/30 text-purple-400 px-1 rounded border border-purple-950" title="Exige alçada de aprovação">Aprovação</span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveActivity(act.id)}
                          className="p-1 text-slate-500 hover:text-red-500 rounded transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* Conteúdo Aba 3: Mermaid string render */}
        {activeTab === "FLUXOGRAMA" && (
          <div className="p-5 animate-fade-in space-y-4">
            <div className="flex justify-between items-center bg-slate-900/20 p-2.5 border border-slate-850 rounded">
              <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-[#C49746]" /> Sintaxe Mermaid auto-gerada
              </span>
              <span className="text-[9px] text-slate-500 font-mono">BPMN Simplificado integrável</span>
            </div>
            <pre className="p-4 bg-slate-950 border border-slate-850 rounded text-[11px] text-slate-350 font-mono overflow-x-auto select-all">
              {generateMermaidString()}
            </pre>
            <p className="text-[10px] text-slate-500 font-sans leading-relaxed">
              * A renderização visual acima segue o padrão AS-IS → Análise → TO-BE. O código é imutável para assegurar a rastreabilidade nas auditorias de governança (fase 9).
            </p>
          </div>
        )}
      </div>

      {/* Indicador de Qualidade de Dados */}
      <div className={`p-4 rounded-lg border flex gap-3 ${
        quantCheck.eligible 
          ? "bg-emerald-950/20 border-emerald-800 text-emerald-400" 
          : "bg-slate-950 border-slate-850 text-slate-400"
      }`}>
        <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${quantCheck.eligible ? "text-emerald-500" : "text-slate-500"}`} />
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider font-sans mb-1">
            Status dos Dados de Entrada para Simulação Quantitativa
          </h4>
          <p className="text-[11px] font-sans leading-normal">
            {quantCheck.eligible 
              ? "Parabéns! Todas as atividades possuem tempos e volumes válidos. O sistema está elegível para cálculo automático de Gargalo, Lead Time, PCE e Otimização com Pesquisa Operacional." 
              : "Apenas Análise Qualitativa está habilitada. Para liberar a simulação quantitativa fina e estimativa de ROI real na Fase 3 e 4, preencha o Tempo Médio e o Volume Mensal maior que zero em cada atividade cadastrada."}
          </p>
        </div>
      </div>
    </div>
  );
}
