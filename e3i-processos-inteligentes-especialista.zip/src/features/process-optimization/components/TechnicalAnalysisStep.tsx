import React, { useState } from "react";
import { TechnicalAnalysis, ProcessAsIs } from "../types/processOptimization.types";
import { 
  Activity, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Info,
  Sliders,
  Sparkles,
  Zap,
  Gauge
} from "lucide-react";
import { analyzeProcess } from "../services/processAnalysisService";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";

interface TechnicalAnalysisStepProps {
  asIs: ProcessAsIs;
  analysis: TechnicalAnalysis;
  onChange: (analysis: TechnicalAnalysis) => void;
}

export default function TechnicalAnalysisStep({
  asIs,
  analysis,
  onChange
}: TechnicalAnalysisStepProps) {
  // Estado para os modificadores de simulação granular por atividade
  const [activityModifiers, setActivityModifiers] = useState<Record<string, { timeReduction: number; reworkReduction: number }>>({});
  const [showAdvancedSimulation, setShowAdvancedSimulation] = useState<boolean>(true);

  const calculatedAnalysis = analyzeProcess(asIs);
  const hasMetrics = calculatedAnalysis.metrics !== undefined;

  const handleModifierChange = (activityId: string, field: "timeReduction" | "reworkReduction", value: number) => {
    setActivityModifiers(prev => ({
      ...prev,
      [activityId]: {
        ...(prev[activityId] || { timeReduction: 0, reworkReduction: 0 }),
        [field]: value
      }
    }));
  };

  // Cálculos do cenário simulado interativo granular
  let simulatedLeadTime = 0;
  let simulatedCycleTime = 0;
  let simulatedPce = 0;
  let simulatedReworkRate = 0;
  let totalReworkCount = 0;
  let sumReworkRate = 0;

  const chartData: any[] = [];

  if (hasMetrics && asIs.activities && asIs.activities.length > 0) {
    asIs.activities.forEach(act => {
      const modifier = activityModifiers[act.id] || { timeReduction: 0, reworkReduction: 0 };
      
      // Original
      const origExecTime = act.avgTime || 0;
      const origWaitTime = act.hasWaiting ? (act.waitingTime || 0) : 0;
      const origRework = act.hasRework ? (act.reworkRate || 0) : 0;
      const origTotal = (origExecTime + origWaitTime) * (1 + origRework / 100);

      // Simulado
      const simExecTime = origExecTime * (1 - modifier.timeReduction / 100);
      const simWaitTime = origWaitTime * (1 - modifier.timeReduction / 100);
      const simRework = origRework * (1 - modifier.reworkReduction / 100);
      const simTotal = (simExecTime + simWaitTime) * (1 + simRework / 100);

      simulatedLeadTime += simTotal;
      if (act.valueType === "AGREGA_VALOR") {
        simulatedCycleTime += simExecTime;
      } else {
        // NVAs também contam parcialmente em cycle time simulado se agregarem algum valor sob redesenho, 
        // mas em teoria clássica, Cycle Time é o tempo de atividades de Valor Agregado (VA)
        simulatedCycleTime += 0;
      }

      if (act.hasRework) {
        sumReworkRate += simRework;
        totalReworkCount++;
      }

      chartData.push({
        name: act.name.length > 14 ? act.name.substring(0, 11) + "..." : act.name,
        "Tempo Original": parseFloat(origTotal.toFixed(1)),
        "Tempo Simulado": parseFloat(simTotal.toFixed(1))
      });
    });

    simulatedPce = simulatedLeadTime > 0 ? (simulatedCycleTime / simulatedLeadTime) * 100 : 0;
    simulatedPce = Math.min(95, parseFloat(simulatedPce.toFixed(1)));
    simulatedReworkRate = totalReworkCount > 0 ? parseFloat((sumReworkRate / totalReworkCount).toFixed(1)) : 0;
  }

  return (
    <div id="technical-analysis-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#C49746]/10 p-2 rounded-md shrink-0 self-start text-[#C49746]">
          <Activity className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 3: Diagnóstico de Gargalos & Ciência de Dados (Six Sigma)
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Nossa engine de Ciência de Dados analisou de forma transparente as atividades de {asIs.processName || "seu processo"} mapeado na etapa anterior. Abaixo apresentamos o diagnóstico de gargalos operacionais e oportunidades Lean DMAIC detectadas.
          </p>
        </div>
      </div>

      {/* Seção Principal de Métricas e Diagnósticos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lado Esquerdo e Centro: Diagnóstico de Gargalos, Desperdícios e Riscos */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Box 1: Sumário e Gargalos */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider flex items-center gap-2">
              ⚠️ Gargalos Operacionais Identificados ({calculatedAnalysis.bottlenecks.length})
            </h4>
            <p className="text-xs text-slate-400 font-sans italic">
              "{calculatedAnalysis.summary}"
            </p>

            <div className="space-y-2.5">
              {calculatedAnalysis.bottlenecks.map((b, idx) => (
                <div key={idx} className="p-3 bg-red-950/20 border border-red-900/40 rounded-lg flex gap-3">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex gap-2 items-center">
                      <span className="text-xs font-sans font-bold text-slate-100">{b.activityName}</span>
                      <span className={`text-[8px] font-mono font-black uppercase px-1.5 py-0.5 rounded ${
                        b.severity === "ALTA" ? "bg-red-900/40 text-red-400" : "bg-amber-900/40 text-amber-400"
                      }`}>
                        SEVERIDADE {b.severity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans mt-0.5">{b.reason}</p>
                    <p className="text-[9px] font-mono text-slate-500 mt-1 uppercase">IMPACTA EM: {b.metricImpact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Box 2: Desperdícios Lean e Riscos */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Desperdícios */}
            <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
              <h5 className="text-[10px] font-mono font-black uppercase text-slate-400 tracking-wider">
                🗑️ Desperdícios Lean Detectados
              </h5>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {calculatedAnalysis.wastes.map((w, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-900/30 border border-slate-850 rounded text-[11px] font-sans">
                    <div className="flex justify-between font-bold text-slate-200">
                      <span>{w.type}</span>
                      <span className="text-[#C49746] font-mono text-[9px]">{w.impactScore}/10 Impacto</span>
                    </div>
                    <p className="text-slate-400 mt-0.5 text-[10px] leading-relaxed">{w.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Riscos */}
            <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
              <h5 className="text-[10px] font-mono font-black uppercase text-slate-400 tracking-wider">
                🛡️ Riscos & Fragilidades de Controle
              </h5>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {calculatedAnalysis.risks.length === 0 ? (
                  <div className="p-5 text-center text-slate-600 text-[10px] italic">
                    Nenhum ponto de risco ou fraude crítico cadastrado.
                  </div>
                ) : (
                  calculatedAnalysis.risks.map((r, idx) => (
                    <div key={idx} className="p-2.5 bg-slate-900/30 border border-slate-850 rounded text-[11px] font-sans">
                      <div className="flex justify-between font-bold text-slate-200">
                        <span className="truncate max-w-[120px]">{r.activityName}</span>
                        <span className="text-red-400 font-mono text-[9px] uppercase">GRAU: {r.criticality}</span>
                      </div>
                      <p className="text-slate-400 mt-0.5 text-[10px] leading-relaxed">{r.description}</p>
                      <p className="text-[9px] text-[#C49746] mt-1 font-mono">Mitigação: {r.mitigation}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>

          {/* Gráfico Comparativo de Fricção e Tempos em Tempo Real */}
          {hasMetrics && chartData.length > 0 && (
            <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
                  📊 Gráfico Comparativo: Tempos de Ciclo por Atividade (Minutos)
                </h4>
                <span className="text-[9px] font-mono text-[#C49746] uppercase">Atualização Matemática Ativa</span>
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                    <XAxis dataKey="name" stroke="#64748B" fontSize={10} tickLine={false} />
                    <YAxis stroke="#64748B" fontSize={10} tickLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0F172A", borderColor: "#334155", color: "#F8FAFC" }}
                      itemStyle={{ color: "#F8FAFC" }}
                      labelStyle={{ color: "#94A3B8" }}
                    />
                    <Legend wrapperStyle={{ fontSize: "10px", color: "#F8FAFC" }} />
                    <Bar dataKey="Tempo Original" fill="#EF4444" radius={[4, 4, 0, 0]} opacity={0.6} />
                    <Bar dataKey="Tempo Simulado" fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

        </div>

        {/* Lado Direito: Métricas Reais e Simulador de Melhorias (Ciência de Dados) */}
        <div className="space-y-6">
          
          {/* Seção de Métricas Reais (Quantitativa) */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
              📊 Métricas Atuais do Processo
            </h4>

            {hasMetrics && calculatedAnalysis.metrics ? (
              <div className="space-y-3">
                <div className="p-3 bg-slate-900/50 border border-slate-850 rounded-lg">
                  <span className="text-[9px] font-mono text-slate-500 uppercase">Lead Time Acumulado</span>
                  <div className="text-2xl font-serif font-black text-slate-100 mt-1">
                    {calculatedAnalysis.metrics.leadTime.toFixed(0)} <span className="text-xs font-mono text-[#C49746] font-bold">minutos</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-900/50 border border-slate-850 rounded-lg">
                  <span className="text-[9px] font-mono text-slate-500 uppercase">Eficiência do Ciclo (PCE)</span>
                  <div className="text-2xl font-serif font-black text-slate-100 mt-1">
                    {calculatedAnalysis.metrics.pce.toFixed(1)}%
                  </div>
                  <div className="w-full h-1 bg-slate-850 rounded-full mt-2 relative">
                    <div 
                      className={`absolute top-0 left-0 h-full rounded-full ${calculatedAnalysis.metrics.pce > 25 ? "bg-emerald-500" : "bg-amber-500"}`}
                      style={{ width: `${Math.min(100, calculatedAnalysis.metrics.pce * 2.5)}%` }}
                    />
                  </div>
                  <span className="text-[8px] font-mono text-slate-500 mt-1 block">Sua eficiência é {calculatedAnalysis.metrics.pce > 25 ? "excelente (>25%)" : "baixa (<25% indica filas)"}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 bg-slate-900/50 border border-slate-850 rounded">
                    <span className="text-[8px] font-mono text-slate-500 uppercase">Volume Mensal</span>
                    <div className="text-lg font-mono font-bold text-slate-200 mt-0.5">
                      {calculatedAnalysis.metrics.totalVolume}
                    </div>
                  </div>
                  <div className="p-2.5 bg-slate-900/50 border border-slate-850 rounded">
                    <span className="text-[8px] font-mono text-slate-500 uppercase">Média Retrabalho</span>
                    <div className="text-lg font-mono font-bold text-slate-200 mt-0.5">
                      {calculatedAnalysis.metrics.avgReworkRate.toFixed(1)}%
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-900/20 border border-slate-850 rounded text-slate-550 text-xs italic leading-relaxed text-center">
                “Os dados atuais permitem uma análise qualitativa. Para simulação quantitativa, informe tempo médio, volume, frequência, capacidade e taxa de erro ou retrabalho.”
              </div>
            )}
          </div>

          {/* Simulador Interativo Avançado de Melhorias Lean Six Sigma (Fricção e Redução) */}
          {hasMetrics && (
            <div className="bg-slate-950/20 border border-[#C49746]/30 p-5 rounded-lg space-y-4 shadow-sm shadow-amber-600/5">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#C49746]" /> Simulador de Impacto DMAIC
                </h4>
                <button 
                  onClick={() => setShowAdvancedSimulation(!showAdvancedSimulation)}
                  className="text-[9px] font-mono text-slate-400 hover:text-[#C49746] underline cursor-pointer"
                >
                  {showAdvancedSimulation ? "Minimizar" : "Expandir Sliders"}
                </button>
              </div>
              <p className="text-[10px] text-slate-400 font-sans leading-normal">
                Simule a aplicação de melhorias e poka-yokes de forma cirúrgica em cada atividade do processo e veja os resultados recalculados matematicamente em tempo real.
              </p>

              {showAdvancedSimulation && (
                <div className="space-y-4 pt-1 max-h-[300px] overflow-y-auto pr-1">
                  {asIs.activities.map((act) => {
                    const modifier = activityModifiers[act.id] || { timeReduction: 0, reworkReduction: 0 };
                    return (
                      <div key={act.id} className="p-3 bg-slate-900/40 border border-slate-850 rounded-lg space-y-2.5">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-sans font-bold text-slate-200 truncate max-w-[150px]">{act.name}</span>
                          <span className={`text-[8px] font-mono px-1 py-0.5 rounded ${
                            act.valueType === "AGREGA_VALOR" ? "bg-emerald-900/20 text-emerald-400" : "bg-red-900/20 text-red-400"
                          }`}>
                            {act.valueType === "AGREGA_VALOR" ? "AGREGA VALOR" : "NVA"}
                          </span>
                        </div>

                        {/* Slider de Redução de Desperdício/Fila */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[8px] font-mono text-slate-400">
                            <span>Reduzir Fila e Tempo</span>
                            <span className="text-[#C49746] font-bold">-{modifier.timeReduction}%</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="90"
                            step="5"
                            value={modifier.timeReduction}
                            onChange={(e) => handleModifierChange(act.id, "timeReduction", Number(e.target.value))}
                            className="w-full accent-[#C49746] bg-slate-850 rounded h-1 cursor-pointer"
                          />
                        </div>

                        {/* Slider de Erro/Retrabalho se aplicável */}
                        {act.hasRework && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-[8px] font-mono text-slate-400">
                              <span>Reduzir Retrabalho (Poka-Yoke)</span>
                              <span className="text-emerald-400 font-bold">-{modifier.reworkReduction}%</span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max="100"
                              step="5"
                              value={modifier.reworkReduction}
                              onChange={(e) => handleModifierChange(act.id, "reworkReduction", Number(e.target.value))}
                              className="w-full accent-emerald-500 bg-slate-850 rounded h-1 cursor-pointer"
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Quadro comparativo final da simulação */}
              <div className="pt-3 border-t border-slate-850 space-y-2">
                <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest block">Resultado Projetado DMAIC</span>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-slate-900/60 rounded border border-slate-850">
                    <span className="text-[8px] font-mono text-slate-500">LEAD TIME PROJETADO</span>
                    <div className="text-base font-mono font-bold text-emerald-400 mt-0.5">
                      {simulatedLeadTime.toFixed(0)} min
                    </div>
                    <span className="text-[7px] text-slate-400 font-mono">
                      Redução de {(((calculatedAnalysis.metrics?.leadTime || 120) - simulatedLeadTime) / (calculatedAnalysis.metrics?.leadTime || 120) * 100).toFixed(0)}%
                    </span>
                  </div>

                  <div className="p-2 bg-slate-900/60 rounded border border-slate-850">
                    <span className="text-[8px] font-mono text-slate-500">PCE PROJETADO</span>
                    <div className="text-base font-mono font-bold text-emerald-400 mt-0.5">
                      {simulatedPce.toFixed(1)}%
                    </div>
                    <span className="text-[7px] text-slate-400 font-mono">
                      Eficiência do Processo
                    </span>
                  </div>
                </div>

                {totalReworkCount > 0 && (
                  <div className="flex justify-between items-center text-[10px] font-sans text-slate-300 px-1">
                    <span>Taxa Média de Retrabalho Simulada:</span>
                    <span className="font-mono font-bold text-emerald-400">{simulatedReworkRate.toFixed(1)}%</span>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}

