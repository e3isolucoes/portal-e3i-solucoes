import React from "react";
import { ExecutiveStorytelling, ProcessAsIs, TechnicalAnalysis, OperationalResearchModel } from "../types/processOptimization.types";
import { BookOpen, TrendingUp, DollarSign, ChevronRight, HelpCircle, ShieldAlert, FileText } from "lucide-react";
import { generateExecutiveStorytelling, generatePOModel } from "../services/processAnalysisService";

interface StorytellingStepProps {
  asIs: ProcessAsIs;
  analysis: TechnicalAnalysis;
  storytelling: ExecutiveStorytelling;
  onChange: (storytelling: ExecutiveStorytelling) => void;
}

export default function StorytellingStep({
  asIs,
  analysis,
  storytelling,
  onChange
}: StorytellingStepProps) {
  // Gera modelo de PO provisório para extrair os cálculos de custos
  const poModel = generatePOModel(asIs, analysis);
  // Gera a narrativa executiva baseada em dados
  const narrative = generateExecutiveStorytelling(asIs, analysis, poModel);

  return (
    <div id="storytelling-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#C49746]/10 p-2 rounded-md shrink-0 self-start text-[#C49746]">
          <FileText className="w-5 h-5 text-[#C49746]" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 6: Storytelling de Dados & Impacto Executivo
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Nesta etapa, traduzimos toda a engenharia de processos, simulações de Pesquisa Operacional e Six Sigma em uma narrativa executiva simples, clara e persuasiva. Esse é o "Business Case" necessário para obter o sinal verde da presidência.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lado Esquerdo e Centro: Relatório Narrativo Executivo */}
        <div className="lg:col-span-2 space-y-6 bg-slate-950/20 border border-slate-900 p-6 rounded-lg">
          
          <div className="border-b border-slate-850 pb-4">
            <span className="text-[9px] font-mono font-black text-[#C49746] uppercase tracking-widest">
              BUSINESS CASE OPERACIONAL
            </span>
            <h4 className="text-lg font-serif font-black text-slate-100 uppercase mt-0.5">
              Sumário para Tomada de Decisão
            </h4>
          </div>

          <div className="space-y-4 text-xs font-sans text-slate-300 leading-relaxed">
            <div>
              <h5 className="font-bold text-slate-100 uppercase text-[10px] tracking-wider mb-1">
                1. Situação Atual & O Gargalo Crítico
              </h5>
              <p>{narrative.currentSituation}</p>
              <p className="mt-2 text-slate-400">
                <span className="text-[#C49746] font-bold">Diagnóstico:</span> {narrative.mainBottleneck} {narrative.probableCause}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-850/60">
              <h5 className="font-bold text-slate-100 uppercase text-[10px] tracking-wider mb-1">
                2. Cenário Operacional de Futuro Recomendado
              </h5>
              <p>{narrative.proposedScenario}</p>
            </div>

            {/* Tabela Comparativa de Indicadores de Sucesso */}
            <div className="pt-2 border-t border-slate-850/60 space-y-3">
              <h5 className="font-bold text-slate-100 uppercase text-[10px] tracking-wider mb-1">
                3. Ganhos Projetados Comparativos
              </h5>
              <table className="w-full text-left border-collapse text-xs mt-2">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-850 text-[9px] font-mono text-slate-400 uppercase">
                    <th className="p-2">Indicador de Sucesso</th>
                    <th className="p-2">Situação Atual (AS-IS)</th>
                    <th className="p-2">Situação Futura (TO-BE)</th>
                    <th className="p-2">Evolução (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {narrative.expectedGains.map((g, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40 text-slate-350">
                      <td className="p-2 font-bold text-slate-250">{g.metric}</td>
                      <td className="p-2 font-mono">{g.before}</td>
                      <td className="p-2 font-mono text-emerald-400">{g.after}</td>
                      <td className="p-2 font-mono font-bold text-[#C49746]">{g.improvementPct}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Lado Direito: ROI, Riscos e Próximos Passos */}
        <div className="space-y-6">
          
          {/* ROI e Retorno Financeiro */}
          <div className="bg-slate-950/20 border border-emerald-900/40 p-5 rounded-lg space-y-3 shadow-md shadow-emerald-950/10">
            <h4 className="text-xs font-mono font-black uppercase text-emerald-400 tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-400 shrink-0" /> Viabilidade Financeira & ROI
            </h4>
            <p className="text-xs font-sans text-slate-205 leading-relaxed">
              {narrative.estimatedRoi}
            </p>
            <div className="p-2.5 bg-emerald-950/10 border border-emerald-900/30 rounded text-[10px] text-emerald-300 font-sans">
              * O cálculo considera Capex padrão de implantação de formulários inteligentes e custos de licenciamento.
            </div>
          </div>

          {/* Riscos & Premissas */}
          <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
            <span className="text-[10px] font-mono text-slate-400 uppercase block border-b border-slate-850 pb-1 flex items-center gap-1 text-amber-500">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-500" /> Premissas Declaradas
            </span>
            <ul className="space-y-1.5 pl-3 list-disc text-[11px] text-slate-450 font-sans leading-relaxed">
              {narrative.risksAndAssumptions.map((risk, idx) => (
                <li key={idx}>{risk}</li>
              ))}
            </ul>
          </div>

          {/* Próximas Decisões */}
          <div className="bg-slate-950/20 border border-[#C49746]/20 p-5 rounded-lg space-y-3">
            <h4 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider flex items-center gap-1.5">
              🎯 Próximas Ações Decisórias
            </h4>
            <div className="space-y-2">
              {narrative.nextSteps.map((step, idx) => (
                <div key={idx} className="flex gap-2 items-start text-xs font-sans text-slate-300 leading-normal">
                  <ChevronRight className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
                  <p>{step}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
