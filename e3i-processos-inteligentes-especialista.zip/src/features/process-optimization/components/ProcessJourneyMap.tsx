import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Target, 
  Search, 
  TrendingUp, 
  Zap, 
  Network, 
  Volume2, 
  CalendarDays, 
  CheckCircle2, 
  HelpCircle, 
  Play, 
  Sparkles, 
  MapPin, 
  ArrowRight,
  Info,
  Layers,
  ChevronDown,
  Activity,
  Users
} from "lucide-react";

interface JourneyStep {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
  borderColor: string;
  textColor: string;
  role: string;
  purpose: string;
  tools: string[];
  output: string;
  tips: string;
}

const JOURNEY_STEPS: JourneyStep[] = [
  {
    id: "strategy",
    number: "01",
    title: "Alinhamento Estratégico",
    subtitle: "Strategy",
    icon: Target,
    color: "#C49746",
    bgColor: "rgba(196, 151, 70, 0.08)",
    borderColor: "border-[#C49746]/30",
    textColor: "text-[#C49746]",
    role: "Liderança & Consultor",
    purpose: "Conectar as metas estratégicas da empresa (ex: faturamento, retenção de faturas) aos indicadores de performance direta do processo.",
    tools: ["BSC (Balanced Scorecard)", "OKRs", "Indicadores de Lead Time", "Strategic Alignment Map"],
    output: "Diretriz de Sucesso, Definição do KPI Principal e Metas de Negócio.",
    tips: "Alinhe com o patrocinador (Sponsor) quais são as dores financeiras de alto nível para garantir que o projeto de otimização gere ROI mensurável."
  },
  {
    id: "asis",
    number: "02",
    title: "Mapeamento AS-IS",
    subtitle: "As-Is Process",
    icon: Search,
    color: "#38BDF8",
    bgColor: "rgba(56, 189, 248, 0.08)",
    borderColor: "border-sky-500/30",
    textColor: "text-sky-400",
    role: "Analista de Processos (BPM)",
    purpose: "Mapear o fluxo de atividades atual exatamente como ele é executado, documentando papéis, sistemas de TI e tempos de ciclo.",
    tools: ["Entrevistas com Executores", "Mapeamento de Raias", "Identificação de Desperdícios Lean", "Análise de Tempo de Fila (Queue Time)"],
    output: "Desenho estruturado em Mermaid, Lista de Gargalos Reais e Pontos de Decisão Críticos.",
    tips: "Evite descrever o processo ideal. O foco aqui é coletar a realidade nua e crua com as dores e sistemas reais utilizados pelos operadores."
  },
  {
    id: "analysis",
    number: "03",
    title: "Análise Técnica (Six Sigma)",
    subtitle: "DMAIC Analyze",
    icon: TrendingUp,
    color: "#F43F5E",
    bgColor: "rgba(244, 63, 94, 0.08)",
    borderColor: "border-rose-500/30",
    textColor: "text-rose-400",
    role: "Black Belt / Green Belt Six Sigma",
    purpose: "Investigar as causas-raiz mais profundas que geram retrabalho, lentidão ou desvios de qualidade no processo mapeado.",
    tools: ["Diagrama de Ishikawa (Causa-Efeito)", "Análise dos 5 Porquês", "Gravidade dos Desperdiçadores", "Matriz RPN (Risk Priority Number)"],
    output: "Mapeamento de Causas-Raiz Prioritárias e Gravidade Geral do Processo.",
    tips: "Use a dinâmica dos 5 Porquês para ultrapassar as causas superficiais (ex: 'falta de atenção') e encontrar problemas sistêmicos ou falta de ferramentas adequadas."
  },
  {
    id: "optimization",
    number: "04",
    title: "Otimização Avançada (PO)",
    subtitle: "Operations Research",
    icon: Zap,
    color: "#A855F7",
    bgColor: "rgba(168, 85, 247, 0.08)",
    borderColor: "border-purple-500/30",
    textColor: "text-purple-400",
    role: "Cientista de Dados / Especialista em PO",
    purpose: "Submeter o processo à modelagem matemática para simular o balanceamento ideal sob restrições físicas, financeiras e de equipe.",
    tools: ["Teoria das Filas", "Programação Linear (Max/Min)", "Simulador de Alocação de Recursos", "Análise de Sensibilidade e Gargalos de Capacidade"],
    output: "Estudo quantitativo de trade-offs, Dimensionamento de Equipe e Simulação de Cenários (Conservador, Moderado, Agressivo).",
    tips: "Se não houver dados históricos perfeitos, faça estimativas baseadas em premissas realistas informadas pelos responsáveis operacionais."
  },
  {
    id: "tobe",
    number: "05",
    title: "Processo Redesenhado (TO-BE)",
    subtitle: "To-Be Optimization",
    icon: Network,
    color: "#10B981",
    bgColor: "rgba(16, 185, 129, 0.08)",
    borderColor: "border-emerald-500/30",
    textColor: "text-emerald-400",
    role: "Consultor BPM & Arquiteto de Soluções",
    purpose: "Desenhar o novo fluxo de trabalho ideal eliminando etapas redundantes, inserindo automações, e definindo pontos de controle pós-melhoria.",
    tools: ["Eliminação de Desperdícios", "Automação com IA & RPA", "Novo Fluxograma Mermaid TO-BE", "Plano de Monitoramento e Controle"],
    output: "Fluxo Otimizado Redesenhado, Controles Recomendados e Matriz de Riscos da Transição.",
    tips: "Não automatize um processo ruim. O redesenho TO-BE vem primeiro para limpar o fluxo, garantindo que a tecnologia sirva a um fluxo limpo e eficiente."
  },
  {
    id: "storytelling",
    number: "06",
    title: "Storytelling Executivo",
    subtitle: "Data Storytelling",
    icon: Volume2,
    color: "#F59E0B",
    bgColor: "rgba(245, 158, 11, 0.08)",
    borderColor: "border-amber-500/30",
    textColor: "text-amber-400",
    role: "Consultor Sênior / Gerente do Projeto",
    purpose: "Simplificar e traduzir toda a engenharia técnica e matemática em um discurso persuasivo, focado em retorno sobre o investimento (ROI) e valor ao board.",
    tools: ["Pitch Executivo", "Narrativa 'Situação-Gargalo-Solução'", "Comunicação para C-Level", "Destacamento de Ganhos Operacionais e Financeiros"],
    output: "Slide/Relatório de Storytelling de Alto Impacto para aprovação do patrocinador.",
    tips: "Executivos buscam ver o impacto no cliente e no faturamento. Evite gastar tempo excessivo com detalhes matemáticos; foque na solução e nos benefícios."
  },
  {
    id: "actionplan",
    number: "07",
    title: "Plano de Ação 5W2H",
    subtitle: "Execution Plan",
    icon: CalendarDays,
    color: "#EC4899",
    bgColor: "rgba(236, 72, 153, 0.08)",
    borderColor: "border-pink-500/30",
    textColor: "text-pink-400",
    role: "Gerente do Projeto / Scrum Master",
    purpose: "Garantir a execução da melhoria transformando o diagnóstico e simulação em tarefas tangíveis, bem coordenadas, com prazos e responsáveis claros.",
    tools: ["Estruturação 5W2H (O que, Quem, Quando, Onde, Por que, Como, Quanto)", "Matriz de Priorização Impacto x Esforço", "Backlog Executável", "Gestão de Riscos de Implantação"],
    output: "Matriz 5W2H de Alta Definição e Cronograma Macro de Execução.",
    tips: "Defina um piloto (quick win) simples de testar nas primeiras semanas. Resultados rápidos engajam a equipe de transição e validam as premissas em campo real."
  }
];

export default function ProcessJourneyMap() {
  const [selectedStepId, setSelectedStepId] = useState<string>("strategy");
  const [activePlayId, setActivePlayId] = useState<string | null>(null);
  const [isJourneyExpanded, setIsJourneyExpanded] = useState<boolean>(true);

  const currentStepData = JOURNEY_STEPS.find(s => s.id === selectedStepId) || JOURNEY_STEPS[0];

  const handlePlaySimulation = (stepId: string) => {
    setActivePlayId(stepId);
    setSelectedStepId(stepId);
    // Remove o efeito de play depois de 3 segundos
    setTimeout(() => {
      setActivePlayId(null);
    }, 3000);
  };

  return (
    <div id="process-journey-map-container" className="bg-slate-900/40 border border-slate-850 rounded-xl overflow-hidden transition-all duration-300">
      
      {/* Cabeçalho Interativo do Mapa de Jornada */}
      <div 
        className="p-4 bg-slate-900/60 border-b border-slate-850 flex justify-between items-center cursor-pointer hover:bg-slate-900/80 transition-colors select-none"
        onClick={() => setIsJourneyExpanded(!isJourneyExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/10 p-2 rounded-lg text-amber-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs font-mono font-bold uppercase text-slate-300 tracking-wider">
              Orientação do Fluxo de Otimização E3I
            </h3>
            <p className="text-[11px] text-slate-400">
              Guia interativo para especialistas e clientes do início ao fim do projeto
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono bg-amber-950/40 text-amber-400 px-2.5 py-1 rounded-md border border-amber-900/30">
            {JOURNEY_STEPS.length} Etapas Estruturadas
          </span>
          <motion.div
            animate={{ rotate: isJourneyExpanded ? 180 : 0 }}
            transition={{ duration: 0.2 }}
            className="text-slate-400"
          >
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </div>
      </div>

      <AnimatePresence>
        {isJourneyExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-5 space-y-6">
              
              {/* Trilha do Processo Horizontal com Conexões Dinâmicas */}
              <div className="relative pt-2 pb-6 px-1 overflow-x-auto scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                {/* Linha conectora de fundo */}
                <div className="absolute top-10 left-8 right-8 h-0.5 bg-slate-800 pointer-events-none" />
                
                <div className="flex justify-between min-w-[850px] gap-4 relative z-10">
                  {JOURNEY_STEPS.map((step, idx) => {
                    const isSelected = selectedStepId === step.id;
                    const StepIcon = step.icon;
                    const isPlaying = activePlayId === step.id;

                    return (
                      <div 
                        key={step.id} 
                        className="flex flex-col items-center flex-1 group"
                      >
                        {/* Círculo da Etapa */}
                        <motion.button
                          type="button"
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setSelectedStepId(step.id)}
                          className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all relative ${
                            isSelected 
                              ? "bg-slate-900 border-amber-500 shadow-[0_0_15px_rgba(196,151,70,0.3)] scale-105" 
                              : "bg-slate-950 border-slate-800 hover:border-slate-700 hover:bg-slate-900"
                          }`}
                          style={{ borderColor: isSelected ? step.color : undefined }}
                        >
                          {/* Animação de pulso se estiver rodando simulação */}
                          {isPlaying && (
                            <span className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping" />
                          )}

                          <StepIcon 
                            className="w-5 h-5 transition-colors duration-200"
                            style={{ color: isSelected ? step.color : "#94A3B8" }}
                          />

                          {/* Badge do Número */}
                          <span className="absolute -bottom-1 -right-1 text-[8px] font-mono font-black px-1.5 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                            {step.number}
                          </span>
                        </motion.button>

                        {/* Rótulo da Etapa */}
                        <span 
                          onClick={() => setSelectedStepId(step.id)}
                          className={`mt-3 text-[11px] font-sans font-bold text-center leading-tight max-w-[110px] cursor-pointer transition-colors duration-200 ${
                            isSelected ? step.textColor : "text-slate-400 group-hover:text-slate-200"
                          }`}
                        >
                          {step.title}
                        </span>

                        {/* Subtítulo Técnico */}
                        <span className="text-[9px] font-mono text-slate-500 uppercase mt-0.5 tracking-wider">
                          {step.subtitle}
                        </span>

                        {/* Botão de Play da Simulação */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePlaySimulation(step.id);
                          }}
                          className="mt-2 text-[9px] font-mono text-slate-500 hover:text-amber-400 flex items-center gap-0.5 px-1.5 py-0.5 bg-slate-950/60 rounded border border-slate-850 hover:border-amber-500/30 transition-all cursor-pointer"
                          title={`Simular Fluxo da Etapa ${step.number}`}
                        >
                          <Play className="w-2.5 h-2.5 fill-current" /> Simular
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Detalhamento Dinâmico da Etapa Selecionada */}
              <div className="bg-slate-950/60 border border-slate-850/60 rounded-xl p-5 relative overflow-hidden">
                <div 
                  className="absolute top-0 right-0 w-2 h-full opacity-70"
                  style={{ backgroundColor: currentStepData.color }}
                />

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  
                  {/* Bloco Esquerdo: Título e Responsabilidade */}
                  <div className="md:col-span-4 space-y-4">
                    <div className="flex items-center gap-3">
                      <div 
                        className="p-3 rounded-xl shrink-0"
                        style={{ backgroundColor: currentStepData.bgColor }}
                      >
                        {React.createElement(currentStepData.icon, {
                          className: "w-6 h-6",
                          style: { color: currentStepData.color }
                        })}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-black bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-400">
                            Passo {currentStepData.number}
                          </span>
                          <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold">
                            {currentStepData.subtitle}
                          </span>
                        </div>
                        <h4 className="text-sm font-sans font-black text-white uppercase tracking-tight mt-1">
                          {currentStepData.title}
                        </h4>
                      </div>
                    </div>

                    <div className="bg-slate-900/50 border border-slate-850 p-3 rounded-lg space-y-1">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block">
                        Papel Responsável:
                      </span>
                      <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                        <Users className="w-3.5 h-3.5 text-amber-500" />
                        {currentStepData.role}
                      </div>
                    </div>

                    <div className="bg-slate-900/50 border border-slate-850 p-3 rounded-lg space-y-1">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block">
                        Entregável Final:
                      </span>
                      <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {currentStepData.output}
                      </div>
                    </div>
                  </div>

                  {/* Bloco Central: Propósito e Ferramentas */}
                  <div className="md:col-span-5 space-y-4">
                    <div>
                      <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
                        Objetivo do Passo:
                      </span>
                      <p className="text-xs text-slate-300 leading-relaxed font-sans">
                        {currentStepData.purpose}
                      </p>
                    </div>

                    <div>
                      <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block mb-2">
                        Ferramentas & Metodologias:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {currentStepData.tools.map((tool, index) => (
                          <span 
                            key={index} 
                            className="text-[10px] font-mono bg-slate-900 text-slate-300 px-2.5 py-1 rounded-md border border-slate-800"
                          >
                            {tool}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Bloco Direito: Dicas do Especialista */}
                  <div className="md:col-span-3 bg-slate-900/30 border border-slate-850 p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-1.5 text-[#C49746]">
                      <Sparkles className="w-4 h-4" />
                      <span className="text-[10px] font-mono uppercase tracking-widest font-black">
                        Dica do Especialista
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                      {currentStepData.tips}
                    </p>
                  </div>

                </div>

                {/* Linha de Progresso Visual de Conexão na base do card */}
                {selectedStepId !== "actionplan" && (
                  <div className="mt-5 pt-3 border-t border-slate-850 flex justify-end items-center gap-1.5 text-[10px] font-mono text-slate-400">
                    Ir para próximo passo: 
                    <span className="text-amber-400 font-black">
                      {JOURNEY_STEPS[JOURNEY_STEPS.findIndex(s => s.id === selectedStepId) + 1].title}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                )}
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
