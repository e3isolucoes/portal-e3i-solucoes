import React from "react";
import { StrategyContext, StrategicFramework } from "../types/processOptimization.types";
import { Target, HelpCircle, AlertCircle } from "lucide-react";
import MissingDataAlert from "./MissingDataAlert";
import { validateStrategy } from "../hooks/useProcessValidation";

interface StrategyStepProps {
  strategy: StrategyContext;
  onChange: (strategy: StrategyContext) => void;
  showValidationErrors: boolean;
}

const FRAMEWORKS: { value: StrategicFramework; label: string; description: string }[] = [
  { value: "SWOT", label: "Matriz SWOT / FOFA", description: "Foca em Forças, Oportunidades, Fraquezas e Ameaças operacionais." },
  { value: "PORTER_5_FORCES", label: "Cinco Forças de Porter", description: "Analisa competitividade de mercado e poder de barganha de fornecedores." },
  { value: "BCG", label: "Matriz BCG", description: "Classifica portfólio de produtos/processos em Estrelas, Vacas Leiteiras, etc." },
  { value: "BSC", label: "Balanced Scorecard (BSC)", description: "Desdobra metas sob as perspectivas Financeira, Clientes, Processos e Pessoas." },
  { value: "OKRS", label: "OKRs (Objectives and Key Results)", description: "Metodologia ágil de foco em objetivos de negócio e resultados chave quantificáveis." },
  { value: "OTHER", label: "Outro Framework", description: "Utilize uma estrutura customizada informada pela gerência." }
];

export default function StrategyStep({
  strategy,
  onChange,
  showValidationErrors
}: StrategyStepProps) {
  const handleChange = (field: keyof StrategyContext, value: any) => {
    onChange({
      ...strategy,
      [field]: value
    });
  };

  const validation = validateStrategy(strategy);

  return (
    <div id="strategy-step-panel" className="space-y-6 animate-fade-in">
      {/* Banner explicativo */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#C49746]/10 p-2 rounded-md shrink-0 self-start text-[#C49746]">
          <Target className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 1: Alinhamento Estratégico do Processo
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Antes de mergulhar na modelagem ou simulação tática, precisamos justificar por que este processo precisa de otimização. Vincular a operação aos objetivos macro da diretoria assegura prioridade e orçamento.
          </p>
        </div>
      </div>

      {showValidationErrors && !validation.isValid && (
        <MissingDataAlert errors={validation.errors} />
      )}

      {/* Grid de Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Esquerda: Frameworks */}
        <div className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-2">
              1. Framework Estratégico Orientador *
            </label>
            <p className="text-[10px] text-slate-500 mb-3 font-sans">
              Selecione o modelo estratégico de governança corporativa adotado para este projeto.
            </p>
            <div className="grid grid-cols-1 gap-2.5">
              {FRAMEWORKS.map((fw) => {
                const isSelected = strategy.framework === fw.value;
                return (
                  <button
                    key={fw.value}
                    type="button"
                    onClick={() => handleChange("framework", fw.value)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      isSelected
                        ? "bg-[#C49746]/10 border-[#C49746] text-[#C49746]"
                        : "bg-slate-950/40 border-slate-850 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="font-sans text-xs font-bold uppercase mb-0.5">{fw.label}</div>
                    <div className="text-[10px] font-sans text-slate-400 leading-normal">{fw.description}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {strategy.framework === "OTHER" && (
            <div className="animate-slide-down">
              <label className="block text-[10px] font-mono font-black uppercase text-slate-400 mb-1.5">
                Nome do Framework Customizado *
              </label>
              <input
                type="text"
                value={strategy.customFrameworkName || ""}
                onChange={(e) => handleChange("customFrameworkName", e.target.value)}
                placeholder="Ex: Análise de Processos Críticos E3I"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
              />
            </div>
          )}
        </div>

        {/* Direita: Campos de Formulário */}
        <div className="space-y-4 bg-slate-950/20 border border-slate-900 p-5 rounded-lg">
          <div>
            <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
              2. Objetivo Principal do Projeto *
            </label>
            <input
              type="text"
              value={strategy.objective}
              onChange={(e) => handleChange("objective", e.target.value)}
              placeholder="Ex: Reduzir em 40% o tempo total de triagem de contas a pagar"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
              3. Problema de Negócio (Gargalo Sentido) *
            </label>
            <textarea
              rows={3}
              value={strategy.businessProblem}
              onChange={(e) => handleChange("businessProblem", e.target.value)}
              placeholder="Ex: Clientes reclamam da lentidão na aprovação. Atualmente o processo manual gera 15% de retrabalho por digitação incorreta."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
                4. Área Impactada *
              </label>
              <input
                type="text"
                value={strategy.affectedArea}
                onChange={(e) => handleChange("affectedArea", e.target.value)}
                placeholder="Ex: Controladoria / Financeiro"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
                Público Afetado (Clientes/Usuários)
              </label>
              <input
                type="text"
                value={strategy.affectedAudience}
                onChange={(e) => handleChange("affectedAudience", e.target.value)}
                placeholder="Ex: Fornecedores de Insumos"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
              5. Indicador Estratégico Principal (KPI) *
            </label>
            <input
              type="text"
              value={strategy.primaryStrategicIndicator}
              onChange={(e) => handleChange("primaryStrategicIndicator", e.target.value)}
              placeholder="Ex: Lead Time Médio (dias) ou First Pass Yield (%)"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
              6. Risco de Não Melhorar o Processo (Custo da Inércia)
            </label>
            <input
              type="text"
              value={strategy.riskOfNoAction}
              onChange={(e) => handleChange("riskOfNoAction", e.target.value)}
              placeholder="Ex: Perda de contratos de grandes fornecedores e aumento de passivos fiscais"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
                7. Escopo do Projeto
              </label>
              <textarea
                rows={2}
                value={strategy.scope || ""}
                onChange={(e) => handleChange("scope", e.target.value)}
                placeholder="O que está incluído (ex: todas as filiais do Sudeste)"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none resize-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono font-black uppercase text-slate-300 tracking-wider mb-1.5">
                8. Fora de Escopo
              </label>
              <textarea
                rows={2}
                value={strategy.outOfScope || ""}
                onChange={(e) => handleChange("outOfScope", e.target.value)}
                placeholder="O que NÃO está incluído (ex: faturamento de exportação)"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-650 focus:border-[#C49746] outline-none resize-none"
              />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
