import React from "react";
import { ProcessToBe, ProcessAsIs, TechnicalAnalysis } from "../types/processOptimization.types";
import { CheckCircle2, ChevronRight, HelpCircle, Laptop, ShieldCheck, Zap } from "lucide-react";
import { generateToBeProcess } from "../services/processAnalysisService";

interface ToBeStepProps {
  asIs: ProcessAsIs;
  analysis: TechnicalAnalysis;
  toBe: ProcessToBe;
  onChange: (toBe: ProcessToBe) => void;
}

export default function ToBeStep({
  asIs,
  analysis,
  toBe,
  onChange
}: ToBeStepProps) {
  // Gera a proposta futura customizada baseada no diagnóstico anterior
  const toBeProcess = generateToBeProcess(asIs, analysis);

  return (
    <div id="tobe-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#2563EB]/10 p-2 rounded-md shrink-0 self-start text-[#2563EB]">
          <CheckCircle2 className="w-5 h-5 text-[#2563EB]" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 5: Desenho do Processo Futuro — TO-BE
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Apresentamos o desenho otimizado do seu fluxo operacional ("Como Deve Ser"). O TO-BE foi programado sob medida para conter os desperdícios de retrabalho e eliminar tarefas burocráticas identificadas na fase de análise técnica.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lado Esquerdo e Centro: Recomendações de Redesenho */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Tabela Comparativa de Atividades AS-IS vs TO-BE */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-3">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
              🔄 Ações Estruturais de Melhoria
            </h4>

            <div className="space-y-2">
              {/* Eliminadas */}
              <div className="p-3 bg-red-950/10 border border-red-900/20 rounded-lg">
                <span className="text-[9px] font-mono font-black text-red-400 uppercase">🚫 Atividades Eliminadas</span>
                <ul className="list-disc pl-4 mt-1 space-y-1">
                  {toBeProcess.activitiesEliminated.map((act, idx) => (
                    <li key={idx} className="text-xs text-slate-350 font-sans">{act}</li>
                  ))}
                </ul>
              </div>

              {/* Automatizadas */}
              <div className="p-3 bg-indigo-950/15 border border-indigo-900/25 rounded-lg">
                <span className="text-[9px] font-mono font-black text-indigo-400 uppercase">⚡ Atividades Automatizadas</span>
                <ul className="list-disc pl-4 mt-1 space-y-1">
                  {toBeProcess.activitiesAutomated.map((act, idx) => (
                    <li key={idx} className="text-xs text-slate-350 font-sans">{act}</li>
                  ))}
                </ul>
              </div>

              {/* Redesenhadas */}
              <div className="p-3 bg-emerald-950/10 border border-emerald-900/20 rounded-lg">
                <span className="text-[9px] font-mono font-black text-emerald-400 uppercase">🛠️ Atividades Redesenhadas (Qualidade)</span>
                <ul className="list-disc pl-4 mt-1 space-y-1">
                  {toBeProcess.activitiesRedesigned.map((act, idx) => (
                    <li key={idx} className="text-xs text-slate-350 font-sans">{act}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Automações Recomendadas com Esforço e Impacto */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-3">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
              💻 Tecnologias & Automações Críticas sugeridas
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {toBeProcess.recommendedAutomations.map((a, idx) => (
                <div key={idx} className="p-3 bg-slate-900/40 border border-slate-850 rounded-lg space-y-2 text-xs font-sans">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-200">{a.name}</span>
                    <Laptop className="w-4 h-4 text-slate-500 shrink-0 ml-1" />
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Ferramenta ideal: <span className="font-mono text-[#C49746]">{a.tool}</span>
                  </div>
                  <div className="flex gap-2 text-[9px] font-mono uppercase mt-1">
                    <span className={`px-1.5 py-0.5 rounded ${
                      a.effort === "BAIXO" ? "bg-emerald-950 text-emerald-400" : "bg-amber-950 text-amber-400"
                    }`}>
                      Esforço: {a.effort}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded ${
                      a.impact === "ALTO" ? "bg-emerald-950 text-emerald-400" : "bg-indigo-950 text-indigo-400"
                    }`}>
                      Impacto: {a.impact}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Lado Direito: Novos Controles, Riscos e Plano de Transição */}
        <div className="space-y-6">
          
          {/* Plano de Transição */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider flex items-center gap-1.5">
              🚀 Plano de Transição do AS-IS ao TO-BE
            </h4>
            <div className="space-y-3">
              {toBeProcess.transitionSteps.map((step, idx) => (
                <div key={idx} className="flex gap-2.5 items-start text-xs font-sans">
                  <div className="w-5 h-5 bg-[#C49746] text-black font-mono font-black rounded-full flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <p className="text-slate-305 leading-normal">{step.replace(/^\d+\.\s*/, '')}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Novos Controles Operacionais */}
          <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
            <span className="text-[10px] font-mono text-slate-400 uppercase block border-b border-slate-850 pb-1">
              🛡️ Novos Controles de Governança
            </span>
            <ul className="space-y-1.5 pl-3 list-disc text-[11px] text-slate-400 font-sans leading-relaxed">
              {toBeProcess.newControls.map((c, idx) => (
                <li key={idx}>{c}</li>
              ))}
            </ul>
          </div>

          {/* Riscos da Mudança */}
          <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-3">
            <span className="text-[10px] font-mono text-slate-400 uppercase block border-b border-slate-850 pb-1 text-red-400">
              ⚠️ Riscos da Mudança Operacional
            </span>
            <ul className="space-y-1.5 pl-3 list-disc text-[11px] text-slate-400 font-sans leading-relaxed">
              {toBeProcess.riskOfChange.map((r, idx) => (
                <li key={idx} className="text-slate-450">{r}</li>
              ))}
            </ul>
          </div>

          {/* Plano de Gestão da Mudança & Implantação */}
          <div className="bg-slate-950/30 border border-[#C49746]/20 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider flex items-center gap-1.5">
              🛡️ Plano de Gestão de Mudança (LSS Control)
            </h4>

            {/* Piloto Recomendado */}
            {toBeProcess.pilotPlan && (
              <div className="p-3 bg-[#C49746]/5 border border-[#C49746]/20 rounded-md space-y-1">
                <span className="text-[8px] font-mono font-black text-[#C49746] uppercase">🧪 Piloto Recomendado</span>
                <p className="text-[11px] text-slate-300 font-sans leading-relaxed">{toBeProcess.pilotPlan}</p>
              </div>
            )}

            {/* Abas Rápidas de Planejamento */}
            <div className="space-y-3.5 pt-2 border-t border-slate-850">
              {toBeProcess.communicationPlan && toBeProcess.communicationPlan.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[8px] font-mono font-black text-slate-450 uppercase">📢 Plano de Comunicação</span>
                  <ul className="list-disc pl-3 text-[10px] text-slate-400 font-sans space-y-1">
                    {toBeProcess.communicationPlan.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </div>
              )}

              {toBeProcess.trainingPlan && toBeProcess.trainingPlan.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[8px] font-mono font-black text-slate-450 uppercase">🎓 Plano de Treinamento</span>
                  <ul className="list-disc pl-3 text-[10px] text-slate-400 font-sans space-y-1">
                    {toBeProcess.trainingPlan.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                </div>
              )}

              {toBeProcess.acceptanceCriteria && toBeProcess.acceptanceCriteria.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[8px] font-mono font-black text-slate-450 uppercase">✅ Critérios de Aceite</span>
                  <ul className="list-disc pl-3 text-[10px] text-slate-400 font-sans space-y-1">
                    {toBeProcess.acceptanceCriteria.map((a, i) => (
                      <li key={i}>{a}</li>
                    ))}
                  </ul>
                </div>
              )}

              {toBeProcess.controlPlan && toBeProcess.controlPlan.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[8px] font-mono font-black text-[#10B981] uppercase">📈 Plano de Controle DMAIC</span>
                  <ul className="list-disc pl-3 text-[10px] text-slate-450 font-sans space-y-1">
                    {toBeProcess.controlPlan.map((ctrl, i) => (
                      <li key={i}>{ctrl}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
