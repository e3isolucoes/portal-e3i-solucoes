import React from "react";
import { AlertCircle } from "lucide-react";

interface MissingDataAlertProps {
  title?: string;
  errors: string[];
}

export default function MissingDataAlert({ title = "Dados mínimos necessários pendentes", errors }: MissingDataAlertProps) {
  if (errors.length === 0) return null;

  return (
    <div id="missing-data-alert-box" className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-lg text-amber-900 shadow-3xs flex gap-3 animate-fade-in my-4">
      <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider font-sans text-amber-950 mb-1">
          {title}
        </h4>
        <ul className="list-disc pl-4 space-y-1">
          {errors.map((err, idx) => (
            <li key={idx} className="text-xs font-sans text-amber-850">
              {err}
            </li>
          ))}
        </ul>
        <p className="text-[10px] font-sans text-amber-700/90 mt-2 font-medium">
          * Preencha todos os campos obrigatórios em destaque acima para liberar a navegação para a próxima fase.
        </p>
      </div>
    </div>
  );
}
