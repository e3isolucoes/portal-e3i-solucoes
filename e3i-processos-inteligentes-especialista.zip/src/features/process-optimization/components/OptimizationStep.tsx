import React, { useState } from "react";
import { OperationalResearchModel, ProcessAsIs, TechnicalAnalysis } from "../types/processOptimization.types";
import { 
  Sliders, 
  HelpCircle, 
  Check, 
  Info, 
  TrendingUp, 
  Zap, 
  Users, 
  Settings, 
  Activity, 
  DollarSign, 
  Sparkles,
  Gauge
} from "lucide-react";
import { generatePOModel } from "../services/processAnalysisService";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";

interface OptimizationStepProps {
  asIs: ProcessAsIs;
  analysis: TechnicalAnalysis;
  optimization: OperationalResearchModel;
  onChange: (optimization: OperationalResearchModel) => void;
}

export default function OptimizationStep({
  asIs,
  analysis,
  optimization,
  onChange
}: OptimizationStepProps) {
  // Gera o modelo estático de PO para base de dados
  const poModel = generatePOModel(asIs, analysis);

  // Parâmetros originais para calibrar o simulador matemático de PO em tempo real
  const baseLeadTime = analysis.metrics?.leadTime || 120;
  const originalVolume = asIs.activities.length > 0 ? (analysis.metrics?.totalVolume || 100) : 100;
  
  // Identifica o número sugerido de FTEs baseado na volumetria original
  const defaultFtes = Math.max(2, Math.ceil(originalVolume / 35));

  // Estados locais interativos para as variáveis de decisão de Pesquisa Operacional
  const [ftes, setFtes] = useState<number>(defaultFtes); // X_1: Mão de obra (FTEs)
  const [automationRate, setAutomationRate] = useState<number>(40); // X_2: Grau de automação (%)
  const [demandVolume, setDemandVolume] = useState<number>(originalVolume); // Demanda Mensal

  // --- MODELAGEM MATEMÁTICA DE PESQUISA OPERACIONAL & TEORIA DE FILAS EM TEMPO REAL ---
  
  // Produtividade Base: Quantos itens 1 FTE consegue processar por mês trabalhando 176h (10.560 min)
  // considerando o tempo total de processamento original.
  const prodBasePerFte = Math.max(1, 10560 / baseLeadTime);

  // Com automação, o tempo das tarefas cai (simulando que até 50% do processo original seja automatizável)
  const simulatedProcessTime = baseLeadTime * (1 - 0.5 * (automationRate / 100));
  
  // Nova produtividade por FTE após automação
  const prodSimPerFte = Math.max(1, 10560 / simulatedProcessTime);

  // Capacidade Máxima Operacional Mensal do Sistema (Colaboradores * Produtividade Simulada)
  const systemCapacity = Math.round(ftes * prodSimPerFte);

  // Taxa de Utilização do Sistema (rho = Demanda / Capacidade)
  const rho = demandVolume / Math.max(1, systemCapacity);

  // Throughput Real (Vazão Efetiva): O menor valor entre a demanda e a capacidade de processamento
  const throughput = Math.min(demandVolume, systemCapacity);

  // Backlog / Estouro de SLA: Demanda que não conseguiu ser atendida no mês
  const SLA_Limit = baseLeadTime * 1.5; // SLA aceitável é 1.5 vezes o tempo de ciclo original
  const pendingBacklog = Math.max(0, demandVolume - systemCapacity);

  // Efeito da Fila (Teoria de Filas simplificada): Conforme rho aproxima-se de 1.0 (100% de saturação),
  // o tempo de espera na fila explode exponencialmente.
  let queueMultiplier = 1;
  if (rho < 0.98) {
    queueMultiplier = 1 + (rho * rho) / (2 * Math.max(0.02, 1 - rho));
  } else {
    queueMultiplier = 25; // Saturação extrema do gargalo
  }
  const simulatedLeadTimeWithQueue = simulatedProcessTime * queueMultiplier;

  // Custo Mensal Projetado (R$):
  // 1. Custo de Pessoal: R$ 4.500 por FTE
  // 2. Custo de Licença de Automação: R$ 1.500 fixos por nível quadrático de escala
  // 3. Multas/Perda por estouro de SLA: R$ 150 por item represado em backlog, mais R$ 50 se o tempo de fila estourar o SLA Aceitável.
  const costStaff = ftes * 4500;
  const costAutomation = Math.round(2000 * Math.pow(automationRate / 100, 2));
  
  const leadTimeEstourouSla = simulatedLeadTimeWithQueue > SLA_Limit;
  const penaltyBacklog = pendingBacklog * 150;
  const penaltySlaDelay = leadTimeEstourouSla ? (throughput * 50) : 0;
  const totalCost = costStaff + costAutomation + penaltyBacklog + penaltySlaDelay;

  // Percentual de SLA atingido
  const slaCompliancePct = demandVolume > 0 ? Math.max(0, Math.min(100, (throughput / demandVolume) * 100)) : 100;

  // Dados para o Gráfico de Barras: Capacidade vs Demanda vs Atendimento
  const chartData = [
    {
      name: "Sua Configuração",
      "Demanda de Entrada": demandVolume,
      "Capacidade Máxima": systemCapacity,
      "Vazão Real (Throughput)": throughput
    },
    {
      name: "Original (AS-IS)",
      "Demanda de Entrada": originalVolume,
      "Capacidade Máxima": Math.round(defaultFtes * prodBasePerFte),
      "Vazão Real (Throughput)": Math.min(originalVolume, Math.round(defaultFtes * prodBasePerFte))
    }
  ];

  return (
    <div id="optimization-step-panel" className="space-y-6 animate-fade-in">
      {/* Cabeçalho */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex gap-3">
        <div className="bg-[#7C3AED]/10 p-2 rounded-md shrink-0 self-start text-[#7C3AED]">
          <Zap className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase text-slate-100 font-sans tracking-tight mb-1">
            Fase 4: Alocação Ótima & Pesquisa Operacional (PO)
          </h3>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            Aplicamos modelagem de Pesquisa Operacional para encontrar a alocação de equipe perfeita sob restrições severas de custo e conformidade de SLA. O modelo maximiza a produtividade geral resolvendo a Teoria de Filas nas restrições de gargalo.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Esquerda: Formulação e Controles Interativos */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Formulação do problema */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
              ⚙️ Formulação do Problema de Otimização
            </h4>

            {/* Função Objetivo */}
            <div className="p-3 bg-purple-950/15 border border-purple-900/40 rounded-lg">
              <span className="text-[9px] font-mono text-purple-400 font-bold uppercase">Função Objetivo (Min/Max)</span>
              <p className="text-xs font-sans font-bold text-slate-100 mt-0.5">
                {poModel.objectiveFunction}
              </p>
            </div>

            {/* Restrições */}
            <div className="space-y-2">
              <span className="text-[9px] font-mono text-slate-500 uppercase">Restrições Reais Modeladas</span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {poModel.constraints.map((c, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-900/20 border border-slate-850 rounded flex justify-between items-center text-[10px] font-sans">
                    <span className="text-slate-400">{c.description}</span>
                    <span className="font-mono text-[#C49746] font-bold">{c.mathNotation}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Simulador Interativo de Variáveis de Decisão */}
          <div className="bg-slate-950/20 border border-[#7C3AED]/30 p-5 rounded-lg space-y-5">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-mono font-black uppercase text-[#7C3AED] tracking-wider flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-[#7C3AED]" /> Variáveis de Decisão do Modelo de PO
              </h4>
              <span className="text-[8px] font-mono bg-[#7C3AED]/10 text-purple-300 px-2 py-0.5 rounded">MODO INTERATIVO ATIVO</span>
            </div>
            
            <p className="text-xs text-slate-400 font-sans leading-normal">
              Ajuste as variáveis de decisão (<span className="font-mono text-[#C49746]">X_1</span> e <span className="font-mono text-[#C49746]">X_2</span>) e a volumetria de entrada para simular o comportamento matemático do gargalo, tempos de fila e custos consolidados em tempo real.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              
              {/* Variable X_1: FTEs */}
              <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-lg space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[9px] font-mono text-purple-400 font-bold uppercase">Variável X_1</span>
                    <h5 className="text-[11px] font-sans font-bold text-slate-200 mt-0.5">Tamanho da Equipe</h5>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#C49746]">{ftes} FTEs</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="15"
                  step="1"
                  value={ftes}
                  onChange={(e) => setFtes(Number(e.target.value))}
                  className="w-full accent-purple-500 bg-slate-800 rounded h-1 cursor-pointer"
                />
                <p className="text-[9px] text-slate-400 leading-tight">
                  Alocação de colaboradores dedicados às atividades de processamento e triagem.
                </p>
              </div>

              {/* Variable X_2: Automation */}
              <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-lg space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[9px] font-mono text-purple-400 font-bold uppercase">Variável X_2</span>
                    <h5 className="text-[11px] font-sans font-bold text-slate-200 mt-0.5">Nível de Automação</h5>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#C49746]">{automationRate}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={automationRate}
                  onChange={(e) => setAutomationRate(Number(e.target.value))}
                  className="w-full accent-purple-500 bg-slate-800 rounded h-1 cursor-pointer"
                />
                <p className="text-[9px] text-slate-400 leading-tight">
                  Automação de preenchimento redundante e validações inteligentes na entrada.
                </p>
              </div>

              {/* Variable 3: Demand Volume */}
              <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-lg space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[9px] font-mono text-purple-400 font-bold uppercase">Volumetria</span>
                    <h5 className="text-[11px] font-sans font-bold text-slate-200 mt-0.5">Demanda Mensal</h5>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#C49746]">{demandVolume} itens</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="500"
                  step="10"
                  value={demandVolume}
                  onChange={(e) => setDemandVolume(Number(e.target.value))}
                  className="w-full accent-purple-500 bg-slate-800 rounded h-1 cursor-pointer"
                />
                <p className="text-[9px] text-slate-400 leading-tight">
                  Quantidade mensal de faturas ou processos que entram para a fila de atendimento.
                </p>
              </div>

            </div>
          </div>

          {/* Gráfico Recharts de Produtividade em Tempo Real */}
          <div className="bg-slate-950/20 border border-slate-900 p-5 rounded-lg space-y-4">
            <h4 className="text-xs font-mono font-black uppercase text-slate-300 tracking-wider">
              📊 Desempenho e Capacidade do Sistema em Tempo Real
            </h4>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                  <XAxis dataKey="name" stroke="#64748B" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748B" fontSize={10} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0F172A", borderColor: "#334155", color: "#F8FAFC" }}
                    itemStyle={{ color: "#F8FAFC" }}
                    labelStyle={{ color: "#94A3B8" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "10px", color: "#F8FAFC" }} />
                  <Bar dataKey="Demanda de Entrada" fill="#38BDF8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Capacidade Máxima" fill="#C49746" radius={[4, 4, 0, 0]} opacity={0.8} />
                  <Bar dataKey="Vazão Real (Throughput)" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* Direita: Resultados da Pesquisa Operacional em Tempo Real */}
        <div className="space-y-6">
          
          {/* Resultados Comparativos de Capacidade */}
          <div className="bg-slate-950/20 border border-[#7C3AED]/30 p-5 rounded-lg space-y-4 shadow-md shadow-purple-900/5">
            <h4 className="text-xs font-mono font-black uppercase text-slate-200 tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-400" /> Resultados Matemáticos
            </h4>

            {/* Painel de Saúde do Gargalo / Utilização */}
            <div className="p-3 bg-slate-900/50 border border-slate-850 rounded-lg space-y-1.5">
              <div className="flex justify-between items-center text-[10px] font-mono">
                <span className="text-slate-400 uppercase">Utilização da Equipe (ρ)</span>
                <span className={`font-bold ${
                  rho > 1.0 ? "text-red-400" : rho > 0.85 ? "text-amber-400" : "text-emerald-400"
                }`}>{(rho * 100).toFixed(0)}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${
                    rho > 1.0 ? "bg-red-500" : rho > 0.85 ? "bg-amber-500" : "bg-emerald-500"
                  }`}
                  style={{ width: `${Math.min(100, rho * 100)}%` }}
                />
              </div>
              <div className="text-[8px] font-sans text-slate-400 leading-normal">
                {rho > 1.0 
                  ? "⚠️ Sobrecarga Crítica: Fila explodindo e acumulando atrasos severos." 
                  : rho > 0.85 
                    ? "⚡ Utilização Elevada: Risco de formação de gargalos e oscilações no SLA." 
                    : "✅ Fluxo Estável: Equipe confortável e tempo de espera controlado."
                }
              </div>
            </div>

            {/* Grid de Principais Outputs */}
            <div className="grid grid-cols-2 gap-3.5">
              
              {/* SLA de Atendimento */}
              <div className="p-3 bg-slate-900/50 border border-slate-850 rounded-lg">
                <span className="text-[8px] font-mono text-slate-400 uppercase block">SLA Atingido</span>
                <span className={`text-lg font-mono font-black block mt-1 ${
                  slaCompliancePct > 95 ? "text-emerald-400" : "text-amber-400"
                }`}>{slaCompliancePct.toFixed(1)}%</span>
                <span className="text-[7px] font-mono text-slate-500 uppercase">{throughput} de {demandVolume} faturados</span>
              </div>

              {/* Lead Time com Fila */}
              <div className="p-3 bg-slate-900/50 border border-slate-850 rounded-lg">
                <span className="text-[8px] font-mono text-slate-400 uppercase block">Tempo com Fila</span>
                <span className={`text-lg font-mono font-black block mt-1 ${
                  leadTimeEstourouSla ? "text-red-400" : "text-emerald-400"
                }`}>{simulatedLeadTimeWithQueue.toFixed(0)} min</span>
                <span className="text-[7px] font-mono text-slate-500 uppercase">SLA Limite: {SLA_Limit.toFixed(0)} min</span>
              </div>

            </div>

            {/* Custo Operacional Mensal */}
            <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-lg space-y-2">
              <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest block">Custo Operacional Mensal Consolidado</span>
              <div className="text-2xl font-serif font-black text-slate-100 flex items-baseline gap-1">
                <span className="text-xs text-slate-400 font-sans font-normal">R$</span>
                {totalCost.toLocaleString("pt-BR")}
              </div>
              
              {/* Detalhamento dos Custos */}
              <div className="space-y-1 pt-2 border-t border-slate-800 text-[10px] text-slate-400 font-sans">
                <div className="flex justify-between">
                  <span>Mão de Obra (X_1):</span>
                  <span className="font-mono text-slate-300">R$ {costStaff.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Licenças de Automação (X_2):</span>
                  <span className="font-mono text-slate-300">R$ {costAutomation.toLocaleString()}</span>
                </div>
                {(penaltyBacklog + penaltySlaDelay) > 0 && (
                  <div className="flex justify-between text-red-400">
                    <span>Penalidades e Quebra de SLA:</span>
                    <span className="font-mono">R$ {(penaltyBacklog + penaltySlaDelay).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Indicação de Ponto de Equilíbrio / Recomendação de PO */}
            <div className="p-3 bg-purple-950/15 border border-[#7C3AED]/20 rounded-md flex gap-2 items-start">
              <Info className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
              <p className="text-[9px] text-purple-300 font-sans leading-relaxed">
                <span className="font-bold">Análise do Solver:</span> Para balancear custo total e conformidade regulatória (98%+ SLA), o ponto de equilíbrio ótimo calculado por programação linear sugere <span className="font-bold text-[#C49746]">{Math.max(2, Math.ceil(demandVolume / 45))} FTEs</span> associado a <span className="font-bold text-[#C49746]">60%+ de automação</span>.
              </p>
            </div>

          </div>

          {/* Tradeoffs de Decisão originais */}
          <div className="bg-slate-950/20 border border-slate-900 p-4 rounded-lg space-y-2">
            <span className="text-[9px] font-mono text-slate-500 uppercase">Análise de Trade-Off da PO</span>
            <ul className="space-y-1.5 pl-3 list-disc text-[10px] text-slate-400 font-sans leading-relaxed">
              {poModel.tradeOffs.map((t, idx) => (
                <li key={idx}>{t}</li>
              ))}
            </ul>
          </div>
        </div>

      </div>
    </div>
  );
}

