export type StrategicFramework = "SWOT" | "PORTER_5_FORCES" | "BCG" | "BSC" | "OKRS" | "OTHER";

export interface StrategyContext {
  framework: StrategicFramework;
  customFrameworkName?: string;
  objective: string;
  businessProblem: string;
  affectedArea: string;
  affectedAudience: string;
  primaryStrategicIndicator: string;
  riskOfNoAction: string;
  expectedOutcome: string;
  scope?: string;
  outOfScope?: string;
}

export type ActivityValueType = "AGREGA_VALOR" | "NVA_NECESSARIA" | "NVA_DESPERDICIO";

export interface ProcessActivity {
  id: string;
  name: string;
  description: string;
  responsible: string;
  department: string;
  systemUsed: string;
  avgTime: number; // Tempo numérico
  timeUnit: "minutos" | "horas" | "dias";
  avgVolume: number; // Volume numérico
  frequency: "diaria" | "semanal" | "mensal" | "sob_demanda";
  valueType: ActivityValueType;
  hasRework: boolean;
  reworkRate?: number; // Ex: 15%
  hasWaiting: boolean;
  waitingTime?: number; // em minutos
  hasApproval: boolean;
  hasRisk: boolean;
  riskDescription?: string;
}

export interface ProcessAsIs {
  processName: string;
  processObjective: string;
  processInput: string;
  expectedOutput: string;
  activities: ProcessActivity[];
}

export interface Bottleneck {
  activityId: string;
  activityName: string;
  reason: string;
  severity: "ALTA" | "MEDIA" | "BAIXA";
  metricImpact: string;
}

export interface Waste {
  activityId?: string;
  activityName?: string;
  type: "RETRABALHO" | "ESPERA" | "MOVIMENTACAO" | "SUPERPRODUCAO" | "PROCESSAMENTO_EXCESSIVO" | "ESTOQUE" | "DEFEITO" | "TALENTO_SUBUTILIZADO";
  description: string;
  impactScore: number; // 1-10
}

export interface Risk {
  id: string;
  activityName: string;
  description: string;
  criticality: "CRITICO" | "ALTO" | "MEDIO" | "BAIXO";
  mitigation: string;
}

export interface TechnicalAnalysis {
  isQuantitative: boolean;
  bottlenecks: Bottleneck[];
  wastes: Waste[];
  risks: Risk[];
  summary: string;
  metrics?: {
    leadTime: number; // tempo total (minutos equivalentes)
    cycleTime: number; // tempo de valor agregado (minutos equivalentes)
    pce: number; // Process Cycle Efficiency %
    totalVolume: number;
    avgReworkRate: number;
  };
}

export interface OperationalResearchModel {
  objectiveFunction: string; // Ex: "Minimizar tempo total do processo e custo operacional"
  decisionVariables: { name: string; description: string; value: string }[];
  constraints: { description: string; mathNotation: string }[];
  scenarios: { name: string; value: number; cost: number; throughput: number }[];
  recommendedDecision: string;
  tradeOffs: string[];
}

export interface ProcessToBe {
  activitiesEliminated: string[];
  activitiesAutomated: string[];
  activitiesRedesigned: string[];
  newResponsibleRoles: { activityName: string; oldResponsible: string; newResponsible: string }[];
  recommendedAutomations: { name: string; tool: string; effort: "BAIXO" | "MEDIO" | "ALTO"; impact: "BAIXO" | "MEDIO" | "ALTO" }[];
  newControls: string[];
  transitionSteps: string[];
  riskOfChange: string[];
  communicationPlan?: string[];
  trainingPlan?: string[];
  pilotPlan?: string;
  acceptanceCriteria?: string[];
  controlPlan?: string[];
}

export interface ExecutiveStorytelling {
  currentSituation: string;
  mainBottleneck: string;
  probableCause: string;
  proposedScenario: string;
  expectedGains: { metric: string; before: string; after: string; improvementPct: string }[];
  estimatedRoi: string;
  risksAndAssumptions: string[];
  nextSteps: string[];
}

export interface ActionPlanItem {
  id: string;
  task: string;
  what: string;
  why: string;
  who: string;
  where: string;
  when: string;
  how: string;
  howMuch: number;
  status: "NAO_INICIADO" | "EM_ANDAMENTO" | "CONCLUIDO";
}

export interface ProcessOptimizationState {
  strategy: StrategyContext;
  asIs: ProcessAsIs;
  analysis: TechnicalAnalysis;
  optimization: OperationalResearchModel;
  toBe: ProcessToBe;
  storytelling: ExecutiveStorytelling;
  actionPlan: ActionPlanItem[];
  currentStep: number;
  highestCompletedStep: number;
}
