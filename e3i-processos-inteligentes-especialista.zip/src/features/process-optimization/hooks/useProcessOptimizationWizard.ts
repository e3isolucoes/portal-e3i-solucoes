import { useState, useEffect } from "react";
import { 
  ProcessOptimizationState, 
  StrategyContext, 
  ProcessAsIs, 
  TechnicalAnalysis, 
  OperationalResearchModel, 
  ProcessToBe, 
  ExecutiveStorytelling, 
  ActionPlanItem 
} from "../types/processOptimization.types";
import { validateStrategy, validateAsIs } from "./useProcessValidation";
import { analyzeProcess, generatePOModel, generateToBeProcess, generateActionPlan } from "../services/processAnalysisService";

const DEFAULT_STRATEGY: StrategyContext = {
  framework: "BSC",
  objective: "Reduzir o tempo total de triagem e faturamento de pedidos em 40% e mitigar o retrabalho na controladoria.",
  businessProblem: "Atualmente, o processo manual de triagem e digitação de pedidos gera 15% de retrabalho por digitação incorreta, gerando atraso na entrega final e reclamações de fornecedores.",
  affectedArea: "Controladoria & Expedição",
  affectedAudience: "Clientes e Transportadoras",
  primaryStrategicIndicator: "Lead Time de Faturamento (minutos)",
  riskOfNoAction: "Perda de contratos de grandes fornecedores por falhas de SLA e aumento de passivos de faturamento.",
  expectedOutcome: "Processamento de pedidos faturados com erro próximo a zero e redução dramática das filas de espera."
};

const DEFAULT_ACTIVITIES = [
  {
    id: "act-default-1",
    name: "Triagem de Pedidos e Entrada de Dados",
    description: "Analista abre o ERP SAP, digita a ordem de venda recebida via e-mail e confere se as informações fiscais estão corretas.",
    responsible: "Assistente Financeiro",
    department: "Controladoria",
    systemUsed: "ERP SAP",
    avgTime: 15,
    timeUnit: "minutos" as const,
    avgVolume: 120,
    frequency: "diaria" as const,
    valueType: "NVA_NECESSARIA" as const,
    hasRework: false,
    hasWaiting: true,
    waitingTime: 45,
    hasApproval: false,
    hasRisk: false
  },
  {
    id: "act-default-2",
    name: "Faturamento e Emissão de Notas Fiscais",
    description: "Executa a validação fiscal, calcula os impostos aplicados e autoriza a nota na SEFAZ.",
    responsible: "Analista de Faturamento",
    department: "Controladoria",
    systemUsed: "ERP SAP / SEFAZ",
    avgTime: 12,
    timeUnit: "minutos" as const,
    avgVolume: 120,
    frequency: "diaria" as const,
    valueType: "AGREGA_VALOR" as const,
    hasRework: true,
    reworkRate: 15,
    hasWaiting: false,
    hasApproval: false,
    hasRisk: true,
    riskDescription: "Erro em códigos de tributação e alíquotas gerando guias fiscais incorretas."
  },
  {
    id: "act-default-3",
    name: "Conferência Física e Despacho",
    description: "Conferência física dos itens separados versus nota fiscal impressa e entrega na doca da transportadora.",
    responsible: "Conferente de Estoque",
    department: "Expedição",
    systemUsed: "WMS Coletor",
    avgTime: 45,
    timeUnit: "minutos" as const,
    avgVolume: 120,
    frequency: "diaria" as const,
    valueType: "AGREGA_VALOR" as const,
    hasRework: false,
    hasWaiting: true,
    waitingTime: 30,
    hasApproval: true,
    hasRisk: true,
    riskDescription: "Despacho de mercadoria divergente da nota fiscal por falha visual."
  }
];

const DEFAULT_AS_IS: ProcessAsIs = {
  processName: "Faturamento de Pedidos de Venda",
  processObjective: "Emitir notas fiscais e despachar mercadoria em total conformidade fiscal e operacional.",
  processInput: "Pedido aprovado pelo comercial no CRM",
  expectedOutput: "Mercadoria despachada e XML enviado à transportadora",
  activities: DEFAULT_ACTIVITIES
};

export function useProcessOptimizationWizard() {
  const [state, setState] = useState<ProcessOptimizationState>(() => {
    // Carrega dados se já salvos, senão utiliza os de alta fidelidade como demonstração padrão
    try {
      const stored = localStorage.getItem("e3i_process_optimization_state");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Erro carregando estado do localStorage", e);
    }

    // Calcula os estados iniciais baseando-se nos dados mockados premium
    const initialAnalysis = analyzeProcess(DEFAULT_AS_IS);
    const initialPO = generatePOModel(DEFAULT_AS_IS, initialAnalysis);
    const initialToBe = generateToBeProcess(DEFAULT_AS_IS, initialAnalysis);
    const initialActionPlan = generateActionPlan(initialToBe);

    return {
      strategy: DEFAULT_STRATEGY,
      asIs: DEFAULT_AS_IS,
      analysis: initialAnalysis,
      optimization: initialPO,
      toBe: initialToBe,
      storytelling: {} as any, // Calculado na tela
      actionPlan: initialActionPlan,
      currentStep: 0,
      highestCompletedStep: 0
    };
  });

  const [showValidationErrors, setShowValidationErrors] = useState(false);

  // Auto-salva alterações no localStorage para resiliência de cache/reloads
  useEffect(() => {
    localStorage.setItem("e3i_process_optimization_state", JSON.stringify(state));
  }, [state]);

  const updateStrategy = (strategy: StrategyContext) => {
    setState((prev) => ({ ...prev, strategy }));
  };

  const updateAsIs = (asIs: ProcessAsIs) => {
    // Ao atualizar o AS-IS, automaticamente re-calculamos as etapas dependentes
    const analysis = analyzeProcess(asIs);
    const optimization = generatePOModel(asIs, analysis);
    const toBe = generateToBeProcess(asIs, analysis);
    const actionPlan = generateActionPlan(toBe);

    setState((prev) => ({
      ...prev,
      asIs,
      analysis,
      optimization,
      toBe,
      actionPlan
    }));
  };

  const updateAnalysis = (analysis: TechnicalAnalysis) => {
    setState((prev) => ({ ...prev, analysis }));
  };

  const updateOptimization = (optimization: OperationalResearchModel) => {
    setState((prev) => ({ ...prev, optimization }));
  };

  const updateToBe = (toBe: ProcessToBe) => {
    setState((prev) => ({ ...prev, toBe }));
  };

  const updateStorytelling = (storytelling: ExecutiveStorytelling) => {
    setState((prev) => ({ ...prev, storytelling }));
  };

  const updateActionPlan = (actionPlan: ActionPlanItem[]) => {
    setState((prev) => ({ ...prev, actionPlan }));
  };

  const setStep = (stepIndex: number) => {
    // Garante que o usuário só consiga navegar se o passo anterior estiver válido
    if (stepIndex > state.highestCompletedStep + 1) {
      return; // Navegação bloqueada
    }

    setState((prev) => ({
      ...prev,
      currentStep: stepIndex
    }));
    setShowValidationErrors(false);
  };

  const handleNext = () => {
    const { currentStep, strategy, asIs } = state;
    
    // Validações por etapa
    if (currentStep === 0) {
      const val = validateStrategy(strategy);
      if (!val.isValid) {
        setShowValidationErrors(true);
        return;
      }
    } else if (currentStep === 1) {
      const val = validateAsIs(asIs);
      if (!val.isValid) {
        setShowValidationErrors(true);
        return;
      }
    }

    // Avança de etapa
    setState((prev) => {
      const nextStep = prev.currentStep + 1;
      const highestCompleted = Math.max(prev.highestCompletedStep, prev.currentStep);
      return {
        ...prev,
        currentStep: nextStep,
        highestCompletedStep: highestCompleted
      };
    });
    setShowValidationErrors(false);
  };

  const handlePrev = () => {
    setState((prev) => ({
      ...prev,
      currentStep: Math.max(0, prev.currentStep - 1)
    }));
    setShowValidationErrors(false);
  };

  return {
    state,
    updateStrategy,
    updateAsIs,
    updateAnalysis,
    updateOptimization,
    updateToBe,
    updateStorytelling,
    updateActionPlan,
    setStep,
    handleNext,
    handlePrev,
    showValidationErrors
  };
}
