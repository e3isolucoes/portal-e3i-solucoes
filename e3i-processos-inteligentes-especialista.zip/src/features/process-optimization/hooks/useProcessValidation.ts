import { StrategyContext, ProcessAsIs, ProcessActivity } from "../types/processOptimization.types";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validateStrategy(strategy: StrategyContext): ValidationResult {
  const errors: string[] = [];
  
  if (!strategy.framework) {
    errors.push("O framework estratégico é obrigatório.");
  }
  if (!strategy.objective || strategy.objective.trim().length < 5) {
    errors.push("O objetivo principal do projeto é obrigatório (mínimo 5 caracteres).");
  }
  if (!strategy.businessProblem || strategy.businessProblem.trim().length < 5) {
    errors.push("O problema de negócio a ser resolvido é obrigatório.");
  }
  if (!strategy.affectedArea || strategy.affectedArea.trim().length < 2) {
    errors.push("A área impactada é obrigatória.");
  }
  if (!strategy.primaryStrategicIndicator || strategy.primaryStrategicIndicator.trim().length < 2) {
    errors.push("O indicador estratégico principal é obrigatório.");
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

export function validateAsIs(asIs: ProcessAsIs): ValidationResult {
  const errors: string[] = [];

  if (!asIs.processName || asIs.processName.trim().length < 3) {
    errors.push("O nome do processo é obrigatório (mínimo 3 caracteres).");
  }
  if (!asIs.processObjective || asIs.processObjective.trim().length < 5) {
    errors.push("O objetivo do processo é obrigatório.");
  }
  if (!asIs.processInput || asIs.processInput.trim().length < 2) {
    errors.push("A entrada do processo é obrigatória.");
  }
  if (!asIs.expectedOutput || asIs.expectedOutput.trim().length < 2) {
    errors.push("A saída esperada do processo é obrigatória.");
  }
  if (!asIs.activities || asIs.activities.length === 0) {
    errors.push("O mapeamento precisa conter pelo menos uma atividade principal.");
  } else {
    asIs.activities.forEach((act, idx) => {
      if (!act.name || act.name.trim().length < 3) {
        errors.push(`Atividade #${idx + 1}: O nome da atividade é obrigatório.`);
      }
      if (!act.responsible || act.responsible.trim().length < 2) {
        errors.push(`Atividade "${act.name || idx + 1}": O responsável é obrigatório.`);
      }
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

/**
 * Determina se os dados informados no AS-IS são suficientes para uma análise quantitativa
 * (tempo médio e volume médio por atividade preenchidos, maiores que zero).
 */
export function checkQuantitativeEligibility(activities: ProcessActivity[]): {
  eligible: boolean;
  missingFields: string[];
} {
  const missingFields: string[] = [];
  if (!activities || activities.length === 0) {
    return { eligible: false, missingFields: ["Nenhuma atividade mapeada."] };
  }

  let hasZeroTime = false;
  let hasZeroVolume = false;

  activities.forEach((act) => {
    if (act.avgTime <= 0) {
      hasZeroTime = true;
    }
    if (act.avgVolume <= 0) {
      hasZeroVolume = true;
    }
  });

  if (hasZeroTime) {
    missingFields.push("Tempo médio (deve ser maior que zero) em todas as atividades");
  }
  if (hasZeroVolume) {
    missingFields.push("Volume médio processado (deve ser maior que zero) em todas as atividades");
  }

  return {
    eligible: missingFields.length === 0,
    missingFields,
  };
}
