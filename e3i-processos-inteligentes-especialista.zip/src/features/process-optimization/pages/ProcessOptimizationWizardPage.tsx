import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ChevronLeft, 
  ChevronRight, 
  Check, 
  Sparkles, 
  Compass, 
  ArrowRight,
  RefreshCw,
  AlertTriangle,
  Award,
  X
} from "lucide-react";
import { useProcessOptimizationWizard } from "../hooks/useProcessOptimizationWizard";
import ProcessProgressStepper from "../components/ProcessProgressStepper";
import ProcessJourneyMap from "../components/ProcessJourneyMap";

// Importações dos Steps
import StrategyStep from "../components/StrategyStep";
import AsIsStep from "../components/AsIsStep";
import TechnicalAnalysisStep from "../components/TechnicalAnalysisStep";
import OptimizationStep from "../components/OptimizationStep";
import ToBeStep from "../components/ToBeStep";
import StorytellingStep from "../components/StorytellingStep";
import ActionPlanStep from "../components/ActionPlanStep";

const STEP_CONFIG = [
  { label: "Estratégia", shortLabel: "01" },
  { label: "Mapeamento AS-IS", shortLabel: "02" },
  { label: "Análise Técnica", shortLabel: "03" },
  { label: "Otimização PO", shortLabel: "04" },
  { label: "Processo TO-BE", shortLabel: "05" },
  { label: "Storytelling", shortLabel: "06" },
  { label: "Plano de Ação", shortLabel: "07" }
];

export default function ProcessOptimizationWizardPage() {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showCompletionModal, setShowCompletionModal] = useState(false);

  const {
    state,
    updateStrategy,
    updateAsIs,
    updateAnalysis,
    updateOptimization,
    updateToBe,
    updateStorytelling,
    updateActionPlan,
    setStep,
    handleNext,
    handlePrev,
    showValidationErrors
  } = useProcessOptimizationWizard();

  const { currentStep, highestCompletedStep } = state;

  // Renderização condicional do passo atual
  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <StrategyStep
            strategy={state.strategy}
            onChange={updateStrategy}
            showValidationErrors={showValidationErrors}
          />
        );
      case 1:
        return (
          <AsIsStep
            asIs={state.asIs}
            onChange={updateAsIs}
            showValidationErrors={showValidationErrors}
          />
        );
      case 2:
        return (
          <TechnicalAnalysisStep
            asIs={state.asIs}
            analysis={state.analysis}
            onChange={updateAnalysis}
          />
        );
      case 3:
        return (
          <OptimizationStep
            asIs={state.asIs}
            analysis={state.analysis}
            optimization={state.optimization}
            onChange={updateOptimization}
          />
        );
      case 4:
        return (
          <ToBeStep
            asIs={state.asIs}
            analysis={state.analysis}
            toBe={state.toBe}
            onChange={updateToBe}
          />
        );
      case 5:
        return (
          <StorytellingStep
            asIs={state.asIs}
            analysis={state.analysis}
            storytelling={state.storytelling}
            onChange={updateStorytelling}
          />
        );
      case 6:
        return (
          <ActionPlanStep
            toBe={state.toBe}
            actionPlan={state.actionPlan}
            onChange={updateActionPlan}
          />
        );
      default:
        return null;
    }
  };

  const isLastStep = currentStep === STEP_CONFIG.length - 1;

  const handleResetClick = () => {
    setShowResetConfirm(true);
  };

  const executeReset = () => {
    localStorage.removeItem("e3i_process_optimization_state");
    window.location.reload();
  };

  return (
    <div id="process-optimization-wizard-page" className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Barra superior de Governança */}
        <div className="flex justify-between items-center bg-slate-900/45 border border-slate-850 p-4 rounded-xl">
          <div className="flex items-center gap-2.5">
            <div className="bg-[#C49746]/10 p-2 rounded-lg text-[#C49746] shrink-0">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[9px] font-mono font-black text-slate-500 uppercase tracking-widest leading-none block mb-0.5">
                Plataforma Corporativa E3I
              </span>
              <h1 className="text-sm font-sans font-black uppercase text-slate-100 tracking-tight leading-none">
                Assistente de Engenharia Consultiva
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetClick}
              className="text-[10px] font-mono font-bold text-slate-400 hover:text-red-400 flex items-center gap-1 bg-slate-950/40 hover:bg-red-950/20 px-2.5 py-1.5 rounded-lg border border-slate-850 hover:border-red-900/40 transition-all cursor-pointer"
              title="Reiniciar Wizard"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reiniciar Dados
            </button>
            <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-2 py-1 rounded-full font-black uppercase border border-emerald-900/40">
              ● Ativo
            </span>
          </div>
        </div>

        {/* Orientação Visual e Dinâmica da Jornada do Processo E3I */}
        <ProcessJourneyMap />

        {/* Stepper de Progresso Geral */}
        <ProcessProgressStepper
          currentStep={currentStep}
          highestCompletedStep={highestCompletedStep}
          onStepClick={setStep}
          steps={STEP_CONFIG}
        />

        {/* Card do Conteúdo do Passo Ativo */}
        <div className="bg-slate-900/30 border border-slate-850 rounded-xl p-6 shadow-xl relative overflow-hidden">
          
          {/* Efeito decorativo sutil no fundo */}
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-[#C49746]/10 to-transparent blur-3xl rounded-full pointer-events-none" />

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.22, ease: "easeInOut" }}
              className="min-h-[420px]"
            >
              {renderStepContent()}
            </motion.div>
          </AnimatePresence>

          {/* Rodapé de Navegação */}
          <div className="flex justify-between items-center pt-6 border-t border-slate-850/60 mt-8">
            <button
              type="button"
              onClick={handlePrev}
              disabled={currentStep === 0}
              className={`px-4 py-2.5 rounded-lg text-xs font-sans font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all ${
                currentStep === 0
                  ? "bg-slate-950 text-slate-600 border border-slate-900 cursor-not-allowed opacity-50"
                  : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer"
              }`}
            >
              <ChevronLeft className="w-4 h-4 shrink-0" /> Anterior
            </button>

            {isLastStep ? (
              <button
                type="button"
                onClick={() => {
                  setShowCompletionModal(true);
                }}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-lg text-xs font-sans font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md shadow-emerald-950/20 cursor-pointer"
              >
                <Check className="w-4 h-4 text-white stroke-[3]" /> Concluir Consultoria
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="bg-[#C49746] hover:bg-[#D9A752] text-black px-5 py-2.5 rounded-lg text-xs font-sans font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md shadow-amber-600/10 cursor-pointer"
              >
                Próximo <ChevronRight className="w-4 h-4 shrink-0 text-black stroke-[3]" />
              </button>
            )}
          </div>

        </div>

        {/* Rodapé institucional com a governança corporativa da Fase 9 */}
        <div className="flex justify-between items-center text-[10px] text-slate-500 px-2 flex-wrap gap-2">
          <span>E3I Processos Inteligentes © 2026</span>
          <div className="flex gap-4">
            <span>Mapeamento VSM</span>
            <span>Estudos de Capacidade PO</span>
            <span>Governança do Modelo ISO 9001:2015</span>
          </div>
        </div>

      </div>

      {/* MODAL DE CONFIRMAÇÃO DE RESET */}
      <AnimatePresence>
        {showResetConfirm && (
          <div id="reset-confirm-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-xl max-w-md w-full space-y-4 shadow-2xl relative"
            >
              <div className="flex items-center gap-3 text-red-400">
                <AlertTriangle className="w-6 h-6 shrink-0 text-red-500" />
                <h3 className="text-sm font-mono font-black uppercase tracking-wider">Reiniciar Todo o Progresso?</h3>
              </div>
              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                Esta ação apagará de forma irreversível todas as suas configurações de Estratégia, Mapeamento AS-IS, Simulações de Pesquisa Operacional, Redesenho TO-BE e Planos de Ação salvos no navegador. Deseja prosseguir com o reset total?
              </p>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  id="cancel-reset-btn"
                  onClick={() => setShowResetConfirm(false)}
                  className="px-4 py-2 rounded bg-slate-950 border border-slate-850 hover:bg-slate-850 text-xs text-slate-300 font-mono transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  id="confirm-reset-btn"
                  onClick={executeReset}
                  className="px-4 py-2 rounded bg-red-600 hover:bg-red-500 text-xs text-white font-mono font-bold transition-all cursor-pointer"
                >
                  Confirmar Reset
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL DE CONCLUSÃO DE CONSULTORIA */}
      <AnimatePresence>
        {showCompletionModal && (
          <div id="completion-celebration-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 p-7 rounded-xl max-w-lg w-full relative overflow-hidden shadow-2xl"
            >
              <button
                type="button"
                id="close-completion-modal-btn"
                onClick={() => setShowCompletionModal(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="bg-emerald-500/10 p-3.5 rounded-full text-emerald-400 border border-emerald-500/20">
                  <Award className="w-10 h-10 stroke-[1.5] text-emerald-400" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">
                    ENTREGÁVEL E3I CONCLUÍDO
                  </span>
                  <h3 className="text-base font-sans font-black uppercase text-slate-100 tracking-tight">
                    Consultoria de Otimização Homologada!
                  </h3>
                </div>
                <p className="text-xs text-slate-300 font-sans leading-relaxed max-w-md">
                  Parabéns! O fluxo corporativo completo de Engenharia Consultiva, Modelagem Matemática por Pesquisa Operacional e Estruturação Lean Six Sigma foi validado com sucesso.
                </p>
                <div className="bg-slate-950/50 border border-slate-850 p-4 rounded-lg text-left text-[11px] font-sans text-slate-450 space-y-2 w-full leading-normal">
                  <div className="flex gap-2 items-start">
                    <span className="text-emerald-400 font-black">✔</span>
                    <span className="text-slate-300"><strong className="text-slate-100">Mapeamento AS-IS e TO-BE:</strong> Cadastrados sob as diretrizes do Value Stream Mapping (VSM).</span>
                  </div>
                  <div className="flex gap-2 items-start">
                    <span className="text-emerald-400 font-black">✔</span>
                    <span className="text-slate-300"><strong className="text-slate-100">Pesquisa Operacional (PO):</strong> Simulações de Teoria das Filas calibradas e trade-offs ótimos de equipe identificados.</span>
                  </div>
                  <div className="flex gap-2 items-start">
                    <span className="text-emerald-400 font-black">✔</span>
                    <span className="text-slate-300"><strong className="text-slate-100">Storytelling e Plano de Ação:</strong> Pitch de valor estruturado para C-Level e Matriz 5W2H homologada para execução imediata.</span>
                  </div>
                </div>
                <button
                  type="button"
                  id="acknowledge-completion-btn"
                  onClick={() => setShowCompletionModal(false)}
                  className="w-full py-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-xs text-white font-sans font-bold uppercase tracking-wider transition-all shadow-md shadow-emerald-950/20 cursor-pointer"
                >
                  Prosseguir na Plataforma
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
