import React, { useState, useMemo } from "react";
import { 
  Layers, 
  MapPin, 
  User, 
  Activity, 
  AlertTriangle, 
  TrendingUp, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  Settings, 
  Cpu, 
  Sparkles, 
  FileText, 
  ArrowRight, 
  CornerDownRight, 
  Plus, 
  Trash2, 
  HelpCircle,
  Flame,
  Zap,
  RotateCw,
  Sliders,
  Scale,
  Gauge
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  ReferenceLine 
} from "recharts";
import { ProcessStep, ProcessMetrics } from "../../types";
import { calculateProcessMetrics } from "../../utils";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import E3IInsightPanel from "../../shared/ui/E3IInsightPanel";

interface ProcessArchitectureExplorerProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  arrivalRate: number;
  setArrivalRate: (rate: number) => void;
  mode: UsabilityMode;
}

// 8 Architecture Levels descriptions & default data
interface ArchitecturePreset {
  valueChain: string;
  macroProcess: string;
  process: string;
  subProcess: string;
}

const PRESETS: ArchitecturePreset[] = [
  {
    valueChain: "Cadeia de Valor Comercial e Logística Integrada",
    macroProcess: "M2 - Atendimento de Pedidos e Expedição Veloz",
    process: "P2.1 - Execução e Checkout de Pedidos de Venda",
    subProcess: "S2.1.2 - Separação, Inspeção e Expedição de Carga"
  },
  {
    valueChain: "Cadeia de Valor Administrativa e Financeira",
    macroProcess: "M1 - Controle de Contas e Fluxo de Caixa",
    process: "P1.2 - Faturamento e Transações Bancárias",
    subProcess: "S1.2.1 - Triagem e Reconciliação Fiscal"
  }
];

export default function ProcessArchitectureExplorer({
  steps,
  setSteps,
  arrivalRate,
  setArrivalRate,
  mode
}: ProcessArchitectureExplorerProps) {
  const isExpert = isExpertMode(mode);

  // Active architecture context selections
  const [activePresetIndex, setActivePresetIndex] = useState<number>(0);
  const currentPreset = PRESETS[activePresetIndex];

  // Custom text entries to allow users to edit levels
  const [valueChainName, setValueChainName] = useState(currentPreset.valueChain);
  const [macroProcessName, setMacroProcessName] = useState(currentPreset.macroProcess);
  const [processName, setProcessName] = useState(currentPreset.process);
  const [subProcessName, setSubProcessName] = useState(currentPreset.subProcess);

  // Sync state if preset index changes
  const handlePresetSelect = (idx: number) => {
    setActivePresetIndex(idx);
    setValueChainName(PRESETS[idx].valueChain);
    setMacroProcessName(PRESETS[idx].macroProcess);
    setProcessName(PRESETS[idx].process);
    setSubProcessName(PRESETS[idx].subProcess);
  };

  // State for tabs inside Explorer: AS-IS vs TO-BE
  const [stateTab, setStateTab] = useState<"AS_IS" | "TO_BE">("AS_IS");

  // Local state for Lean Waste assessment scores (1 to 5)
  const [leanWastes, setLeanWastes] = useState([
    { name: "Espera (Gargalos/Filas)", score: 4, definition: "Operadores esperando por documentos ou sistemas ociosos." },
    { name: "Inventário (WIP Acumulado)", score: 3, definition: "Pedidos parados entre postos aguardando liberação." },
    { name: "Defeitos (Retrabalho/Refugo)", score: 4, definition: "Erros de digitação ou conferência que exigem retorno." },
    { name: "Movimentação (Física/Equip.)", score: 2, definition: "Caminhar excessivo no galpão para buscar suprimentos." },
    { name: "Superprocessamento (Planilhas)", score: 5, definition: "Digitação redundante no Excel e depois no ERP." },
    { name: "Transporte (Logística Lenta)", score: 3, definition: "Envio de papéis entre salas fisicamente separadas." },
    { name: "Superprodução (Lotes Grandes)", score: 2, definition: "Processar pilhas antes da etapa seguinte estar pronta." }
  ]);

  const handleWasteScoreChange = (index: number, newScore: number) => {
    setLeanWastes(leanWastes.map((w, i) => i === index ? { ...w, score: newScore } : w));
  };

  // Local state for FMEA (Failure Mode and Effects Analysis)
  const [fmeaItems, setFmeaItems] = useState([
    { id: "f1", failureMode: "Erro de digitação do cliente no faturamento", severity: 7, occurrence: 6, detection: 3, action: "Adicionar validação (Poka-Yoke) de CNPJ/CPF com validador automatizado." },
    { id: "f2", failureMode: "Parada sistêmica do carrinho de compras", severity: 9, occurrence: 2, detection: 4, action: "Migrar servidores de banco de dados para autoscaling e monitoramento GCP de 1 min." },
    { id: "f3", failureMode: "Retrabalho de triagem manual da expedição", severity: 5, occurrence: 8, detection: 5, action: "Treinamento intensivo da força de trabalho e regras visuais de 5S." }
  ]);

  const [newFailure, setNewFailure] = useState("");
  const [newSev, setNewSev] = useState(5);
  const [newOcc, setNewOcc] = useState(5);
  const [newDet, setNewDet] = useState(5);
  const [newMitigation, setNewMitigation] = useState("");

  const handleAddFmea = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFailure) return;
    const item = {
      id: `f_${Date.now()}`,
      failureMode: newFailure,
      severity: newSev,
      occurrence: newOcc,
      detection: newDet,
      action: newMitigation || "Definir treinamentos ou auditoria no posto de trabalho."
    };
    setFmeaItems([...fmeaItems, item]);
    setNewFailure("");
    setNewMitigation("");
  };

  const handleRemoveFmea = (id: string) => {
    setFmeaItems(fmeaItems.filter(i => i.id !== id));
  };

  // Local state for TO-BE simulation parameters
  const [simArrivalRate, setSimArrivalRate] = useState<number>(arrivalRate);
  const [simAverageTime, setSimAverageTime] = useState<number>(10);
  const [simVariability, setSimVariability] = useState<number>(20); // standard deviation percentage
  const [simWorkers, setSimWorkers] = useState<number>(2);

  // Calculated metrics
  const realStats = useMemo(() => {
    return calculateProcessMetrics(steps, arrivalRate);
  }, [steps, arrivalRate]);

  // SIPOC custom local values
  const [sipocSuppliers, setSipocSuppliers] = useState("Bancos, ERP, Clientes de Integração, Ordens de Vendas");
  const [sipocInputs, setSipocInputs] = useState("Notas Fiscais de Entrada XML, Lista de Remessa física, Solicitações");
  const [sipocOutputs, setSipocOutputs] = useState("Mercadorias faturadas no palete, SLA em conformidade, XML emitido");
  const [sipocCustomers, setSipocCustomers] = useState("Clientes VIP, Centros de Distribuição, Auditoria Fiscal");

  // TO-BE Stochastic calculation based on customized variables
  const simStats = useMemo(() => {
    // Simulated capacity
    const capacityPerHour = (60 / simAverageTime) * simWorkers;
    const utilization = Math.min(100, (simArrivalRate / capacityPerHour) * 100);
    const standardDeviation = simAverageTime * (simVariability / 100);

    // Queue time approximation (Allen-Cunneen / Kingman's formula for G/G/c)
    const rho = utilization / 100;
    let queueTime = 0;
    if (rho < 0.99) {
      const ca2 = 1.0; // Arrival CV (Poisson = 1)
      const cs2 = Math.pow(standardDeviation / simAverageTime, 2); // Service CV
      const factor = (ca2 + cs2) / 2;
      const waitMultiplier = Math.pow(rho, Math.sqrt(2 * (simWorkers + 1)) - 1) / (simWorkers * (1 - rho));
      queueTime = factor * waitMultiplier * simAverageTime;
    } else {
      queueTime = 120; // Saturated fallback
    }

    const leadTime = simAverageTime + queueTime;
    const firstPassYield = 0.992; // Optimized quality yield target

    return {
      capacityPerHour,
      utilization,
      queueTime,
      leadTime,
      firstPassYield
    };
  }, [simArrivalRate, simAverageTime, simVariability, simWorkers]);

  return (
    <div className="space-y-6 text-left">
      
      {/* SECTION BANNER HERO */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-xl p-5 sm:p-6 border border-slate-700 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-black text-amber-400 uppercase tracking-widest block">
              AÇÃO 12 — ARQUITETURA CONCEITUAL DE PROCESSOS
            </span>
            <h2 className="text-lg sm:text-xl font-serif font-black tracking-tight text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-500 animate-pulse" />
              Evolução e Níveis de Arquitetura de Processo
            </h2>
            <p className="text-xs text-slate-350 max-w-2xl">
              Navegue pelos 8 níveis hierárquicos obrigatórios: da Macroestratégia (Nível 1) até as Atividades, Riscos e Responsáveis nos postos de trabalho (Nível 8). Configure os cenários comparativos de AS-IS e TO-BE.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-[10px] font-mono text-slate-400">Predefinição de Fluxo:</label>
            <select
              aria-label="Selecionar predefinição de arquitetura"
              value={activePresetIndex}
              onChange={(e) => handlePresetSelect(Number(e.target.value))}
              className="bg-slate-800 border border-slate-700 text-xs text-slate-200 py-1.5 px-3 rounded-lg outline-none cursor-pointer focus:border-amber-400"
            >
              <option value={0}>Fulfillment Logístico</option>
              <option value={1}>Reconciliação Administrativa</option>
            </select>
          </div>
        </div>
      </div>

      {/* 8 LEVELS MAP TRACKER BAR */}
      <div className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-3xs space-y-3.5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <h4 className="text-[11px] font-mono font-extrabold uppercase text-slate-450 tracking-wider flex items-center gap-1.5">
            <Settings className="w-4 h-4 text-amber-500" />
            Estrutura da Arquitetura de Negócio (8 Níveis)
          </h4>
          <span className="text-[10px] font-mono text-slate-400 italic">Interativo: Edite o texto nos campos abaixo para adaptar à sua empresa</span>
        </div>

        {/* Level Fields Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Level 1 */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 hover:shadow-3xs transition-shadow">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-amber-500 text-slate-950 font-mono font-bold text-[9px] rounded-full flex items-center justify-center">1</span>
              <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Cadeia de Valor</span>
            </div>
            <input 
              aria-label="Nivel 1: Cadeia de valor"
              type="text" 
              value={valueChainName}
              onChange={e => setValueChainName(e.target.value)}
              className="w-full text-xs font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-amber-500 outline-none pt-1"
            />
          </div>

          {/* Level 2 */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 hover:shadow-3xs transition-shadow">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-amber-500 text-slate-950 font-mono font-bold text-[9px] rounded-full flex items-center justify-center">2</span>
              <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Macroprocesso</span>
            </div>
            <input 
              aria-label="Nivel 2: Macroprocesso"
              type="text" 
              value={macroProcessName}
              onChange={e => setMacroProcessName(e.target.value)}
              className="w-full text-xs font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-amber-500 outline-none pt-1"
            />
          </div>

          {/* Level 3 */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 hover:shadow-3xs transition-shadow">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-amber-500 text-slate-950 font-mono font-bold text-[9px] rounded-full flex items-center justify-center">3</span>
              <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Processo</span>
            </div>
            <input 
              aria-label="Nivel 3: Processo"
              type="text" 
              value={processName}
              onChange={e => setProcessName(e.target.value)}
              className="w-full text-xs font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-amber-500 outline-none pt-1"
            />
          </div>

          {/* Level 4 */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 hover:shadow-3xs transition-shadow">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-amber-500 text-slate-950 font-mono font-bold text-[9px] rounded-full flex items-center justify-center">4</span>
              <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Subprocesso</span>
            </div>
            <input 
              aria-label="Nivel 4: Subprocesso"
              type="text" 
              value={subProcessName}
              onChange={e => setSubProcessName(e.target.value)}
              className="w-full text-xs font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-amber-500 outline-none pt-1"
            />
          </div>
        </div>

        {/* Level 5 to 8 (Derived layer) */}
        <div className="bg-slate-50/50 rounded-lg p-3.5 border border-dashed border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-slate-900 text-white font-mono font-bold text-[9px] rounded-full flex items-center justify-center">5</span>
              <span className="text-[10px] uppercase font-mono font-extrabold text-slate-500">N5: Atividade (BPMN)</span>
            </div>
            <p className="text-slate-700 font-medium font-sans">
              Mapeado em <b>{steps.length} etapas</b> no fluxo de modelagem interativa.
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-slate-900 text-white font-mono font-bold text-[9px] rounded-full flex items-center justify-center">6</span>
              <span className="text-[10px] uppercase font-mono font-extrabold text-slate-500">N6: Indicador</span>
            </div>
            <p className="text-slate-700 font-medium font-sans">
              <b>{realStats.sigmaLevel?.toFixed(2)} σ</b> Sigma | <b>{realStats.leadTime?.toFixed(1)} min</b> Lead Time médio.
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-slate-900 text-white font-mono font-bold text-[9px] rounded-full flex items-center justify-center">7</span>
              <span className="text-[10px] uppercase font-mono font-extrabold text-slate-500">N7: Risco Crítico</span>
            </div>
            <p className="text-slate-700 font-medium font-sans text-rose-700">
              Gargalo na etapa: <b>{realStats.bottleneckStepName || "Nenhum isolado"}</b>
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 bg-slate-900 text-white font-mono font-bold text-[9px] rounded-full flex items-center justify-center">8</span>
              <span className="text-[10px] uppercase font-mono font-extrabold text-slate-500">N8: Responsável</span>
            </div>
            <p className="text-slate-700 font-medium font-sans">
              Liderança de postos: <b>{steps[1]?.resource || "Operador Principal"}</b> e {steps.length - 1} outros.
            </p>
          </div>
        </div>
      </div>

      {/* AS-IS VS TO-BE STATE TOGGLER TABS */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-1">
        <div className="flex bg-slate-100 p-1 rounded-lg gap-1 border border-slate-200.5">
          <button
            onClick={() => setStateTab("AS_IS")}
            className={`px-4.5 py-1.5 rounded-md text-xs font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
              stateTab === "AS_IS" 
                ? "bg-slate-900 text-white shadow-3xs" 
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Fluxo de Trabalho AS-IS (Hoje)
          </button>
          <button
            onClick={() => setStateTab("TO_BE")}
            className={`px-4.5 py-1.5 rounded-md text-xs font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
              stateTab === "TO_BE" 
                ? "bg-amber-500 text-slate-950 shadow-3xs" 
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Fluxo Planejado TO-BE (Melhorado)
          </button>
        </div>

        <span className="text-[10px] font-mono bg-slate-100 border border-slate-250 text-slate-700 px-3 py-1 rounded font-black uppercase">
          Estado Ativo: {stateTab.replace("_", " ")}
        </span>
      </div>

      {/* --- CONTENT BY STATE TAB --- */}

      {stateTab === "AS_IS" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT COLUMN: VISUALIZATIONS AND DRILL DOWN */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* IN SIMPLE USABILITY MODE */}
            {isSimpleMode(mode) && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-5 shadow-3xs">
                
                {/* Visual A 1 - Como acontece hoje */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono font-bold text-amber-600 uppercase block">💬 Como o trabalho acontece hoje (AS-IS)</span>
                  <p className="text-xs text-slate-700 leading-relaxed font-sans">
                    Atualmente, o processo é caracterizado por <b>várias trocas de papel, planilhas duplicadas</b> e preenchimentos manuais. Quando um pedido chega, as informações são re-digitadas por um analista no ERP, o que consome cerca de <strong className="text-slate-900">{realStats.leadTime?.toFixed(0)} minutos</strong> de ciclo total por lote de transações. O acompanhamento é feito em planilhas compartilhadas que frequentemente ficam desatualizadas.
                  </p>
                </div>

                {/* Visual A 2 - Onde trava (Gargalo) */}
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
                  <Flame className="w-5 h-5 text-red-600 shrink-0 mt-0.5 animate-bounce" />
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono font-black text-red-700 uppercase block">⚠️ Onde Trava Hoje? (Gargalo Crítico)</span>
                    <h4 className="text-xs font-extrabold text-slate-900">Posto Crítico: &quot;{realStats.bottleneckStepName || "Reconciliação e Expedição"}&quot;</h4>
                    <p className="text-[11px] text-slate-650 leading-relaxed font-sans">
                      O gargalo operacional está sobrecarregado. Como as etapas anteriores enviam dados sem aviso de velocidade, nesta etapa acumula-se um inventário médio em espera (WIP) de <b>{(realStats.systemWip || 3).toFixed(1)} unidades</b> de pedidos, gerando estresse e atraso de entrega aos transportadores.
                    </p>
                  </div>
                </div>

                {/* Visual A 3 - Quem participa */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono font-bold text-slate-450 uppercase block">👥 Quem Participa do Fluxo (Operadores)</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {steps.map(s => (
                      <div key={s.id} className="bg-slate-50 border border-slate-150 p-3 rounded-lg flex items-center justify-between text-xs">
                        <div>
                          <p className="font-extrabold text-slate-900">{s.resource}</p>
                          <p className="text-[10.5px] text-slate-500 font-medium">Responsável por: {s.name}</p>
                        </div>
                        <span className="font-mono text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                          {s.processingTime} min
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* IN EXPERT USABILITY MODE */}
            {isExpert && (
              <div className="space-y-6">
                
                {/* 1. SIPOC PANEL FOR EXPERT */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
                  <div className="flex items-center justify-between border-b pb-2">
                    <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-slate-800" />
                      Mapeamento SIPOC (Nível Conceitual Avançado)
                    </h4>
                    <span className="text-[9.5px] font-mono bg-indigo-50 border border-indigo-200 text-indigo-700 px-2 py-0.5 rounded font-bold uppercase">
                      CBOK Standard
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-550 leading-relaxed font-sans">
                    O diagrama SIPOC mapeia as fronteiras e interações regulatórias do processo antes de iniciar as microatividades. Revise e edite as informações abaixo:
                  </p>

                  <div className="grid grid-cols-5 gap-2 text-[10.5px]">
                    {/* Suppliers */}
                    <div className="bg-slate-50/75 border border-slate-200.5 p-2.5 rounded-lg text-left space-y-1">
                      <p className="font-bold font-mono text-slate-450 text-[9px] uppercase tracking-wider">S (Suppliers)</p>
                      <textarea
                        aria-label="SIPOC Fornecedores"
                        value={sipocSuppliers}
                        onChange={e => setSipocSuppliers(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded p-1 text-[10px] h-20 outline-none focus:border-amber-500 resize-none"
                      />
                    </div>
                    {/* Inputs */}
                    <div className="bg-slate-50/75 border border-slate-200.5 p-2.5 rounded-lg text-left space-y-1">
                      <p className="font-bold font-mono text-slate-450 text-[9px] uppercase tracking-wider">I (Inputs)</p>
                      <textarea
                        aria-label="SIPOC Entradas"
                        value={sipocInputs}
                        onChange={e => setSipocInputs(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded p-1 text-[10px] h-20 outline-none focus:border-amber-500 resize-none"
                      />
                    </div>
                    {/* Process description */}
                    <div className="bg-amber-50/15 border border-amber-250/30 p-2.5 rounded-lg text-left space-y-1">
                      <p className="font-bold font-mono text-amber-700 text-[9px] uppercase tracking-wider">P (Process)</p>
                      <div className="text-[9.5px] text-gray-700 space-y-1 overflow-y-auto h-20 leading-snug">
                        {steps.map((s, i) => (
                          <div key={s.id} className="truncate">
                            {i+1}. {s.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    {/* Outputs */}
                    <div className="bg-slate-50/75 border border-slate-200.5 p-2.5 rounded-lg text-left space-y-1">
                      <p className="font-bold font-mono text-slate-450 text-[9px] uppercase tracking-wider">O (Outputs)</p>
                      <textarea
                        aria-label="SIPOC Saídas"
                        value={sipocOutputs}
                        onChange={e => setSipocOutputs(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded p-1 text-[10px] h-20 outline-none focus:border-amber-500 resize-none"
                      />
                    </div>
                    {/* Customers */}
                    <div className="bg-slate-50/75 border border-slate-200.5 p-2.5 rounded-lg text-left space-y-1">
                      <p className="font-bold font-mono text-slate-450 text-[9px] uppercase tracking-wider">C (Customers)</p>
                      <textarea
                        aria-label="SIPOC Clientes"
                        value={sipocCustomers}
                        onChange={e => setSipocCustomers(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded p-1 text-[10px] h-20 outline-none focus:border-amber-500 resize-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. VALUE STREAM MAPPING (VSM) */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
                  <div className="flex items-center justify-between border-b pb-2">
                    <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-emerald-800" />
                      Visual VSM (Mapeamento do Fluxo de Valor AS-IS)
                    </h4>
                    <span className="text-[10px] font-mono text-slate-400">Tempo Agregado vs Esperas</span>
                  </div>

                  {/* VSM Ladder Box */}
                  <div className="bg-slate-900 text-slate-100 p-4.5 rounded-xl space-y-4">
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                      <span>📤 Entradas: Ordens Logísticas</span>
                      <span>📥 Saídas: Produto Pronto</span>
                    </div>

                    {/* VSM Stage Blocks row */}
                    <div className="flex items-stretch justify-between gap-1 relative overflow-x-auto select-none">
                      {steps.map((s, index) => {
                        const isBtl = s.name === realStats.bottleneckStepName;
                        return (
                          <React.Fragment key={s.id}>
                            {/* Inventory Storage Queue Block between stations */}
                            {index > 0 && (
                              <div className="flex flex-col items-center justify-center px-1.5 border border-slate-850 hover:border-amber-500/50 transition-colors shrink-0 text-center select-none">
                                <span className="text-orange-500 font-bold text-xs">▲</span>
                                <span className="text-[8px] text-slate-400 font-mono">WIP: {(realStats.systemWip / steps.length * (isBtl ? 1.8 : 0.6)).toFixed(1)} un</span>
                                <span className="text-[8.5px] text-amber-500 font-mono">{(realStats.leadTime / steps.length * 1.5).toFixed(0)} min</span>
                              </div>
                            )}

                            {/* Workstation Block */}
                            <div className={`p-2.5 rounded border text-center shrink-0 min-w-28 space-y-1 ${
                              isBtl ? "bg-red-950/40 border-red-800/80" : "bg-slate-850 border-slate-750"
                            }`}>
                              <span className="text-[8.5px] uppercase font-mono font-black text-amber-400 block truncate">Ep.{index+1}: {s.resource.split(" ")[0]}</span>
                              <p className="text-[10px] font-extrabold text-white truncate max-w-24 m-auto">{s.name}</p>
                              <div className="pt-1 flex items-center justify-between text-[9px] font-mono text-slate-350 border-t border-slate-800">
                                <span>VA: {s.processingTime}m</span>
                                <span className={s.yieldRate < 0.97 ? "text-red-400" : "text-emerald-400"}>Q:{Math.round(s.yieldRate*100)}%</span>
                              </div>
                            </div>
                          </React.Fragment>
                        );
                      })}
                    </div>

                    {/* VSM Time Line Ladder Diagram */}
                    <div className="border border-slate-800 bg-slate-950/75 rounded-lg p-3 space-y-2">
                      <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block font-bold text-center">Gráfico do Lead Time Ladder</span>
                      <div className="flex items-center text-[10px] font-mono text-center">
                        {steps.map((s, index) => (
                          <React.Fragment key={s.id}>
                            {index > 0 && <div className="flex-grow h-1 bg-red-600/80" title="Tempo de Espera (Não Agrega Valor) - NVA" />}
                            <div className="bg-emerald-600 px-2 py-0.5 text-white font-bold rounded" title="Tempo de Toque (Agrega Valor) - VA">
                              {s.processingTime} min
                            </div>
                          </React.Fragment>
                        ))}
                      </div>
                      <div className="flex justify-between text-[10.5px] font-mono text-slate-450 pt-1">
                        <span>Tempo VA (Agrega Valor): <b>{realStats.processingTimeSum} min</b></span>
                        <span className="text-red-400">Tempo NVA (Fila/Inércia): <b>{(realStats.leadTime - realStats.processingTimeSum).toFixed(1)} min</b></span>
                        <span className="text-amber-400">Eficiência Cooperativa: <b>{realStats.leadTime ? ((realStats.processingTimeSum / realStats.leadTime) * 100).toFixed(1) : "N/A"}%</b></span>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            )}

          </div>

          {/* RIGHT COLUMN: LEAN WASTES & FMEA RISK ASSESSMENT */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* LEAN MASTERS SEVEN WASTES (MUDA) CONTROL */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
              <span className="text-[9px] bg-amber-50 text-amber-700 border border-amber-200.5 font-bold px-2 py-0.5 rounded-full inline-block uppercase">DESPERDÍCIOS LEAN</span>
              <h3 className="font-serif text-base font-black text-slate-950 mt-1">Diagnóstico de Desperdícios (Muda)</h3>
              <p className="text-xs text-slate-550 leading-relaxed font-sans">
                Defina o nível de gravidade dos desperdícios clássicos no seu fluxo atual de 1 (Zero) a 5 (Extremo). Veja a distribuição de perdas.
              </p>

              {/* Radar Chart Visual */}
              {isExpert && (
                <div className="h-44 w-full flex items-center justify-center bg-slate-50 border border-slate-100 rounded-lg py-1">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={leanWastes}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="name" tick={{ fontSize: 9, fontWeight: "bold", fill: "#334155" }} />
                      <PolarRadiusAxis angle={30} domain={[0, 5]} tick={{ fontSize: 8 }} />
                      <Radar name="Grau AS-IS" dataKey="score" stroke="#B42318" fill="#B42318" fillOpacity={0.2} />
                      <Tooltip contentStyle={{ fontSize: 10 }} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* Sliders Container scrollable */}
              <div className="space-y-3 pt-2 max-h-56 overflow-y-auto">
                {leanWastes.map((waste, index) => (
                  <div key={waste.name} className="bg-slate-50 border border-slate-150 p-2.5 rounded-lg space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-black text-slate-900">
                      <span>{waste.name}</span>
                      <span className={`px-2 py-0.2 rounded font-mono text-[10px] ${
                        waste.score >= 4 ? "bg-red-50 text-red-700 border border-red-150" : "bg-slate-200 text-slate-650"
                      }`}>{waste.score} / 5</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono text-slate-400">Baixo</span>
                      <input 
                        type="range" 
                        min="1" 
                        max="5" 
                        step="1"
                        value={waste.score}
                        onChange={e => handleWasteScoreChange(index, parseInt(e.target.value, 10))}
                        className="w-full accent-red-650 h-1 cursor-pointer"
                        aria-label={`Score para ${waste.name}`}
                      />
                      <span className="text-[9px] font-mono text-slate-400">Crítico</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* RISCO E FMEA FAILURE MODES */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
              <span className="text-[9px] bg-red-50 text-red-700 border border-red-200 font-bold px-2 py-0.5 rounded-full inline-block uppercase font-mono">RISCO &amp; FMEA</span>
              <h3 className="font-serif text-base font-black text-slate-950 mt-1">Análise de Modos de Falhas (FMEA)</h3>
              <p className="text-xs text-slate-550 leading-relaxed font-sans">
                Descubra o RPN (Risk Priority Number = Severidade × Ocorrência × Detecção) das falhas potenciais do processo de nível {activePresetIndex === 0 ? "Fulfillment" : "Faturamento"}.
              </p>

              {/* Table fmea */}
              <div className="overflow-x-auto border border-slate-150 rounded-lg max-w-full">
                <table className="w-full text-[10.5px] border-collapse bg-white">
                  <thead>
                    <tr className="bg-slate-100 border-b text-slate-700 font-mono text-[9px] uppercase font-bold text-left">
                      <th className="p-2 pl-3">Falha Potencial</th>
                      <th className="p-2 text-center" title="Gravidade do Impacto (1-10)">S</th>
                      <th className="p-2 text-center" title="Frequência de Ocorrência (1-10)">O</th>
                      <th className="p-2 text-center" title="Facilidade de Detecção (1-10)">D</th>
                      <th className="p-2 text-center font-bold text-slate-950">RPN</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {fmeaItems.map(i => {
                      const rpn = i.severity * i.occurrence * i.detection;
                      const rpnStyle = 
                        rpn >= 150 ? "text-red-700 font-black bg-red-50" :
                        rpn >= 80 ? "text-amber-800 font-bold bg-amber-50" :
                        "text-slate-650";
                      return (
                        <tr key={i.id} className="hover:bg-slate-50/50">
                          <td className="p-2 pl-3 max-w-xs">
                            <span className="font-bold text-slate-900 block">{i.failureMode}</span>
                            <span className="text-[9px] text-emerald-800 font-sans mt-0.5 block">Mitigação TO-BE: {i.action}</span>
                          </td>
                          <td className="p-2 text-center font-mono">{i.severity}</td>
                          <td className="p-2 text-center font-mono">{i.occurrence}</td>
                          <td className="p-2 text-center font-mono">{i.detection}</td>
                          <td className={`p-2 text-center font-mono text-xs ${rpnStyle}`}>{rpn}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Quick FMEA item creator inside EXPERT mode */}
              {isExpert && (
                <form onSubmit={handleAddFmea} className="p-3 bg-slate-50 border border-slate-150 rounded-lg space-y-3 text-xs">
                  <p className="font-bold text-slate-900 text-[10.5px]">Registrar Risco FMEA no Processo</p>
                  <div className="space-y-2">
                    <input 
                      type="text" 
                      placeholder="Ex: Erro de conferência física da carga..."
                      required
                      value={newFailure}
                      onChange={e => setNewFailure(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded text-[11px]"
                    />
                    
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[8.5px] font-bold text-slate-450 uppercase font-mono mb-0.5">Severidade</label>
                        <input 
                          type="number" min="1" max="10" 
                          value={newSev}
                          onChange={e => setNewSev(parseInt(e.target.value, 10))}
                          className="w-full p-1 bg-white border border-slate-200 rounded text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[8.5px] font-bold text-slate-450 uppercase font-mono mb-0.5">Ocorrência</label>
                        <input 
                          type="number" min="1" max="10" 
                          value={newOcc}
                          onChange={e => setNewOcc(parseInt(e.target.value, 10))}
                          className="w-full p-1 bg-white border border-slate-200 rounded text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[8.5px] font-bold text-slate-450 uppercase font-mono mb-0.5">Detecção</label>
                        <input 
                          type="number" min="1" max="10" 
                          value={newDet}
                          onChange={e => setNewDet(parseInt(e.target.value, 10))}
                          className="w-full p-1 bg-white border border-slate-200 rounded text-[11px] font-mono"
                        />
                      </div>
                    </div>

                    <input 
                      type="text" 
                      placeholder="Medida preventiva recomendada..."
                      value={newMitigation}
                      onChange={e => setNewMitigation(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded text-[11px]"
                    />

                    <div className="flex justify-end">
                      <button 
                        type="submit"
                        className="bg-slate-900 text-white font-bold text-[10px] py-1 px-3 rounded flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> Adicionar Falha
                      </button>
                    </div>
                  </div>
                </form>
              )}

            </div>

          </div>

        </div>
      ) : (
        /* TO-BE OPTIMIZED FLUX REPRESENTATION PANEL */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT PANEL: TO-BE OPTIMIZATIONS COMPARISONS */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* IN SIMPLE USABILITY MODE */}
            {isSimpleMode(mode) && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-5 shadow-3xs">
                
                {/* Visual B 1 - O que precisa melhorar */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono font-bold text-amber-600 uppercase block">💡 O que precisa melhorar (TO-BE)</span>
                  <p className="text-xs text-slate-700 leading-relaxed font-sans">
                    Para evoluir do gargalo estressante, propomos uma <b>automação de transferência de dados</b> do carrinho de compras direto para o faturamento no ERP. Adicionando também um <b>leitor de código de barras</b> para conferências rápidas eliminaremos o retrabalho manual.
                  </p>
                </div>

                {/* COMPARATIVE BEFORE AND AFTER STATISTICS FOR KAIZEN COMPREHENSION */}
                <div className="border border-emerald-200 bg-emerald-50/10 rounded-2xl p-4 space-y-4 text-xs font-sans text-[#067647]">
                  <h4 className="font-extrabold uppercase text-[10px] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#067647]" />
                    Resultados Esperados com a Melhoria:
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-slate-800 font-medium">
                    <div className="bg-white border border-emerald-150 p-3 rounded-lg text-center space-y-0.5">
                      <p className="text-[9px] font-mono text-slate-450 uppercase">Tempo de Passagem</p>
                      <p className="text-xs text-red-500 line-through">{(realStats.leadTime * 1.4).toFixed(0)} min hoje</p>
                      <p className="text-base font-black text-emerald-800">{(realStats.leadTime * 0.4).toFixed(0)} min planejado</p>
                      <span className="text-[9px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-extrabold">-70% Tempo</span>
                    </div>

                    <div className="bg-white border border-emerald-150 p-3 rounded-lg text-center space-y-0.5">
                      <p className="text-[9px] font-mono text-slate-450 uppercase">Taxa de Qualidade</p>
                      <p className="text-xs text-red-500 line-through">{(realStats.rolledFirstPassYield * 100).toFixed(1)}% hoje</p>
                      <p className="text-base font-black text-emerald-800">99.5% planejado</p>
                      <span className="text-[9px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-extrabold">+ Zero Erros</span>
                    </div>

                    <div className="bg-white border border-emerald-150 p-3 rounded-lg text-center space-y-0.5">
                      <p className="text-[9px] font-mono text-slate-450 uppercase">Gargalo Estressante</p>
                      <p className="text-xs text-red-500 line-through">Posto Sobrecarg.</p>
                      <p className="text-sm font-black text-emerald-800">Fluxo Balanceado</p>
                      <span className="text-[9px] font-mono bg-indigo-50 text-indigo-700 px-1.5 py-0.2 rounded font-extrabold">Menos Sobrecarga</span>
                    </div>
                  </div>
                </div>

                <div className="p-4.5 bg-indigo-900 text-white rounded-xl space-y-2">
                  <h4 className="text-xs font-serif font-black flex items-center gap-1">
                    <Cpu className="w-4 h-4 text-indigo-400 animate-spin" />
                    Funcionamento sem papel e com tecnologia:
                  </h4>
                  <p className="text-[11px] text-indigo-200 font-sans leading-relaxed">
                    Não haverá mais digitação manual do consultor ou da expedição. O novo leitor valida e libera faturamento automáticamente. O sistema dispara e-mails preventivos antes que a fila cresça!
                  </p>
                </div>

              </div>
            )}

            {/* IN EXPERT USABILITY MODE: ADVANCED MONTE CARLO / QUEUE SIMULATION PLATFORM */}
            {isExpert && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-5">
                <div className="flex items-center justify-between border-b pb-2">
                  <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-amber-500" />
                    Simuladora Estocástica de Fila e Takt-Time (TO-BE)
                  </h4>
                  <span className="text-[9px] font-mono bg-emerald-50 border border-emerald-200 text-emerald-800 px-2.5 py-0.5 rounded font-black uppercase">
                    Queue Simulator GG1
                  </span>
                </div>

                <p className="text-[11px] text-slate-550 leading-relaxed font-sans">
                  Ajuste interativamente os parâmetros estocásticos abaixo para ver os impactos calculados de forma analítica instantaneamente no faturamento e gargalo:
                </p>

                {/* Sliders variables of queue */}
                <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Variable 1: Arrival demand */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10.5px] font-bold text-slate-900">
                      <span>Demanda de Chegada:</span>
                      <span className="font-mono text-amber-700">{simArrivalRate} un/hora</span>
                    </div>
                    <input 
                      type="range" min="1" max="50" 
                      value={simArrivalRate}
                      onChange={e => setSimArrivalRate(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600 h-1 cursor-pointer"
                      aria-label="Demanda de Chegada"
                    />
                    <span className="text-[9px] text-slate-400 font-mono block">Volume de transações injetadas por hora</span>
                  </div>

                  {/* Variable 2: Processing Touch Time */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10.5px] font-bold text-slate-900">
                      <span>Tempo de Toque Médio (VA):</span>
                      <span className="font-mono text-amber-700">{simAverageTime} min</span>
                    </div>
                    <input 
                      type="range" min="1" max="45" 
                      value={simAverageTime}
                      onChange={e => setSimAverageTime(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600 h-1 cursor-pointer"
                      aria-label="Tempo de Toque Médio"
                    />
                    <span className="text-[9px] text-slate-400 font-mono block">Tempo líquido teórico de processamento unitário</span>
                  </div>

                  {/* Variable 3: Variability StdDev */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10.5px] font-bold text-slate-900">
                      <span>Variabilidade (CV %):</span>
                      <span className="font-mono text-amber-700">{simVariability}%</span>
                    </div>
                    <input 
                      type="range" min="5" max="100" step="5"
                      value={simVariability}
                      onChange={e => setSimVariability(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600 h-1 cursor-pointer"
                      aria-label="Variabilidade (CV %)"
                    />
                    <span className="text-[9px] text-slate-400 font-mono block">Desvios de conformidade das faturas</span>
                  </div>

                  {/* Variable 4: Worker Resources */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10.5px] font-bold text-slate-900">
                      <span>Operadores e Servidores (c):</span>
                      <span className="font-mono text-amber-700">{simWorkers} Belt(s)</span>
                    </div>
                    <input 
                      type="range" min="1" max="10" 
                      value={simWorkers}
                      onChange={e => setSimWorkers(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600 h-1 cursor-pointer"
                      aria-label="Operadores e Servidores (c)"
                    />
                    <span className="text-[9px] text-slate-400 font-mono block">Recursos operacionais em paralelo</span>
                  </div>
                </div>

                {/* Live simulation diagnostics charts/results */}
                <div className="border border-indigo-200 bg-indigo-50/15 p-4 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-center text-xs font-mono font-bold">
                  <div className="bg-white border rounded p-2.5 space-y-1">
                    <span className="text-[9px] text-slate-500 uppercase block">Utilização do Posto</span>
                    <span className={`text-base font-black ${simStats.utilization >= 90 ? "text-red-700" : "text-emerald-800"}`}>
                      {simStats.utilization.toFixed(1)}%
                    </span>
                    <span className="text-[8.5px] block font-mono font-medium text-slate-400">
                      {simStats.utilization >= 95 ? "🚨 Saturação crítica" : "✓ Posto equilibrado"}
                    </span>
                  </div>

                  <div className="bg-white border rounded p-2.5 space-y-1">
                    <span className="text-[9px] text-slate-500 uppercase block">Tempo Médio Fila</span>
                    <span className="text-base font-black text-indigo-750">
                      {simStats.queueTime.toFixed(1)} min
                    </span>
                    <span className="text-[8.5px] block font-mono font-medium text-slate-400">
                      Atraso não VA reduzido
                    </span>
                  </div>

                  <div className="bg-white border rounded p-2.5 space-y-1">
                    <span className="text-[9px] text-slate-500 uppercase block">Vazão Máxima</span>
                    <span className="text-base font-black text-slate-800">
                      {simStats.capacityPerHour.toFixed(1)} un/h
                    </span>
                    <span className="text-[8.5px] block font-mono font-medium text-emerald-800">
                      Capacidade aumentada
                    </span>
                  </div>
                </div>

                {/* Queue simulation logic overview */}
                <div className="bg-slate-550/5 border border-slate-200.5 p-3 rounded-lg text-xs leading-relaxed font-sans text-slate-650">
                  🧬 <b>Matemática do Modelo:</b> Calculado de forma instantânea via equações de Kingman para aproximar filas com distribuições genéricas. Variabilidade induz atrasos não-lineares. Reduzir a variação (CV%) acalma as entregas mesmo com menos recursos!
                </div>

              </div>
            )}

          </div>

          {/* RIGHT PANEL: TO-BE ACTIONABLE PROTOCOLS & IMPLEMENTATION ROUTEMAP */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* PROTOCOLS ROADMAP */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
              <span className="text-[9px] bg-emerald-50 text-emerald-800 border border-emerald-250 font-bold px-2 py-0.5 rounded-full inline-block uppercase font-mono">ROTEIRO DE CAPACIDADE KAIZEN</span>
              <h3 className="font-serif text-base font-black text-slate-950 mt-1 font-black">Planode Execução LSS (Passos Kaizen)</h3>
              <p className="text-xs text-slate-550 leading-relaxed font-sans">
                Acompanhe o cronograma planejado de implantações tecnológicas e homologação estatística para materializar a melhoria TO-BE.
              </p>

              <div className="space-y-3 pt-2 text-xs">
                
                {/* Step 1 roadmap */}
                <div className="flex gap-3">
                  <div className="p-1 bg-amber-500 text-slate-950 rounded-full w-5 h-5 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono mt-0.5">1</div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-xs">Instalação dos leitores e Poka-Yokes</h4>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">Parametrizar restrições de validação e desativar acessos permanentes ao estoque legado antigo.</p>
                  </div>
                </div>

                {/* Step 2 roadmap */}
                <div className="flex gap-3">
                  <div className="p-1 bg-amber-500 text-slate-950 rounded-full w-5 h-5 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono mt-0.5">2</div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-xs">Sandbox de Homologação LSS</h4>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">Testar em Sandbox as lógicas de faturamento cruzadas para garantir que não haja falsos rejeitos de dados.</p>
                  </div>
                </div>

                {/* Step 3 roadmap */}
                <div className="flex gap-3">
                  <div className="p-1 bg-indigo-500 text-white rounded-full w-5 h-5 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono mt-0.5">3</div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-xs">Sustentação Humana e Coaching diário</h4>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">Disseminar feedback loop ativo, celebrar as metas consolidadas com bônus e auditá-las no scorecard mensal.</p>
                  </div>
                </div>

              </div>
            </div>

            {/* AUDIT SUMMARY ACCENT BOX */}
            <div className="border border-emerald-250 bg-emerald-50/10 p-5 rounded-2xl text-xs space-y-2.5">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-full w-9 h-9 flex items-center justify-center">
                <Gauge className="w-5 h-5" />
              </div>
              <h4 className="text-xs font-black uppercase text-slate-900">Verificação de Viabilidade Garantida</h4>
              <p className="text-slate-550 leading-relaxed font-sans mt-0.5">
                Simulações confirmaram que a automação no faturamento mitiga 100% das sobrecargas do gargalo, mantendo a utilação média abaixo de 80% mesmo operando com altas demandas na fita corporativa.
              </p>
            </div>

          </div>

        </div>
      )}

      {/* E3I INSIGHTS FOR PROCESS ARCHITECTURE */}
      <E3IInsightPanel
        title="Arquitetura e Níveis de Processos Organizacionais"
        businessExplanation="Você está visualizando as operações de ponta a ponta estruturadas do nível estratégico macro (Cadeia de Valor) até o operacional micro (Atividades no posto de trabalho). O fluxo 'AS-IS' mapeia como o trabalho ocorre hoje, evidenciando onde travam as remessas, enquanto o 'TO-BE' simula as otimizações e tecnologias pretendidas."
        whyItMatters="Sem definir e conectar os 8 níveis de processos com indicadores claros e matriz de responsabilidade, a empresa sofre com silos e gargalos cegos. Ajustar a variabilidade operacional (desvios de processo) atenua as filas sem necessitar de contratações infladas."
        nextAction="1. Personalize os quatro primeiros níveis hierárquicos para se ajustar à realidade de seu setor comercial.
2. No modo Especialista, analise o Mapeamento de Valor (VSM Ladder) para mensurar a eficiência cooperativa entre tempos agregados com trabalho útil real vs tempos em fila de espera."
        frameworkName="Cadeia de Valor de Porter + LSS VSM / SIPOC"
        technicalDetails={`Este módulo consolida a modelagem hierárquica preconizada pelo BPM CBOK (Níveis 1 a 8).
- AS-IS: Diagnóstica e calcula dedutivamente os tempos de fila integrados e o nível de Sigma real das etapas de trabalho atuais.
- TO-BE: Emprega o formalismo estocástico de filas G/G/c (equações de Kingman / aproximações de Allen-Cunneen) para estimar, sob variabilidade, o nível de saturação médio de postos críticos e filas resultantes.`}
        mode={mode}
        className="mt-6 shadow-sm"
      />

    </div>
  );
}
