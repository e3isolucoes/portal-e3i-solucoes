import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Briefcase, 
  CheckCircle, 
  Loader2, 
  Target, 
  Plus, 
  Users, 
  TrendingUp, 
  AlertCircle,
  Play,
  ClipboardList
} from "lucide-react";

export interface InitiativeItem {
  id: string;
  name: string;
  descriptionSimple: string;
  descriptionTechnical: string;
  owner: string;
  status: "PLANEJADO" | "EM_EXECUCAO" | "CHURRASCO" | "CONCLUIDO";
  priority: "ALTA" | "MÉDIA" | "BAIXA";
  checklist: { text: string; done: boolean }[];
}

export interface StrategicInitiativesProps {
  initiatives: InitiativeItem[];
  mode: UsabilityMode;
  onAddInitiative: (ini: InitiativeItem) => void;
  onToggleCheckItem: (iniId: string, checkIndex: number) => void;
  onChangeStatus: (iniId: string, status: InitiativeItem["status"]) => void;
}

export default function StrategicInitiatives({
  initiatives,
  mode,
  onAddInitiative,
  onToggleCheckItem,
  onChangeStatus
}: StrategicInitiativesProps) {
  
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newOwner, setNewOwner] = useState("");
  const [newPriority, setNewPriority] = useState<"ALTA" | "MÉDIA" | "BAIXA">("MÉDIA");
  const [newChecklistRaw, setNewChecklistRaw] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;

    // Split raw text lines into checklist items
    const checkItems = newChecklistRaw
      .split("\n")
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .map(line => ({ text: line, done: false }));

    const created: InitiativeItem = {
      id: "ini_" + Date.now(),
      name: newName,
      descriptionSimple: newDesc,
      descriptionTechnical: newDesc,
      owner: newOwner || "Diretoria",
      status: "PLANEJADO",
      priority: newPriority,
      checklist: checkItems.length > 0 ? checkItems : [
        { text: "Primeira etapa do plano", done: false },
        { text: "Avaliar resultados iniciais", done: false }
      ]
    };

    onAddInitiative(created);
    setNewName("");
    setNewDesc("");
    setNewOwner("");
    setNewPriority("MÉDIA");
    setNewChecklistRaw("");
    setShowAdd(false);
  };

  const getStatusLabelAndStyles = (status: string) => {
    switch (status) {
      case "CONCLUIDO":
        return { label: "✔ Concluído", css: "bg-emerald-50 text-emerald-800 border-emerald-200" };
      case "EM_EXECUCAO":
        return { label: "⚡ Em Execução", css: "bg-blue-50 text-blue-800 border-blue-200" };
      default:
        return { label: "⏳ Planejado", css: "bg-slate-50 text-slate-600 border-slate-200" };
    }
  };

  return (
    <div id="initiatives-root" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* Title section */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            🚀 {isSimpleMode(mode) ? "Projetos de Execução (Planos de Ação)" : "Iniciativas Estratégicas & Projetos"}
          </h3>
          <p className="text-xs text-slate-500">
            {isSimpleMode(mode) 
              ? "Confira os planos práticos e quem está liderando cada projeto para as metas acontecerem." 
              : "Defina os projetos táticos e os roadmaps necessários para suportar os KRs estratégicos."}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAdd(!showAdd)}
          className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#C49746] hover:bg-[#A97E34] text-white font-mono text-[11px] font-bold uppercase rounded cursor-pointer transition-all active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" /> {showAdd ? "Fechar Formulário" : "Iniciar Novo Projeto"}
        </button>
      </div>

      {/* INITIATIVE CARD CREATOR FORM */}
      {showAdd && (
        <form onSubmit={handleSubmit} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-4 text-left">
          <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider">
            📂 {isSimpleMode(mode) ? "Cadastrar Novo Projeto Prático" : "Criar Nova Iniciativa de Execução"}
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Initiative Name */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                Nome do Projeto / Título
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Ex: Treinar Atendentes no Script de Excelência"
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white text-slate-800"
                required
              />
            </div>

            {/* Owner */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                Líder do Projeto
              </label>
              <input
                type="text"
                value={newOwner}
                onChange={(e) => setNewOwner(e.target.value)}
                placeholder="Ex: Amanda Silva (Supervisora)"
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white text-slate-800"
              />
            </div>

            {/* Description */}
            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                O que faremos nesse projeto? (Explicação)
              </label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Explique o escopo ou use perguntas: o que é, por que importa e qual benefício esperamos?"
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white resize-y text-slate-800"
                rows={2}
              />
            </div>

            {/* Checklist generator */}
            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                Etapas Práticas (Dica: digite uma por linha)
              </label>
              <textarea
                value={newChecklistRaw}
                onChange={(e) => setNewChecklistRaw(e.target.value)}
                placeholder="Exemplo:&#10;Reunir o time comercial&#10;Gravar simulação de vendas&#10;Criar planilha de checagem"
                className="w-full text-xs font-mono p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white resize-y text-slate-800"
                rows={3}
              />
            </div>

          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 border-2 border-slate-950 text-white font-mono text-[11px] font-bold uppercase transition-all rounded hover:bg-slate-800 cursor-pointer"
            >
              Criar Projeto
            </button>
          </div>
        </form>
      )}

      {/* CARDS LIST DESCRIPTION */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {(initiatives || []).map((ini) => {
          const statusDetails = getStatusLabelAndStyles(ini.status);
          const checklist = Array.isArray(ini.checklist) ? ini.checklist : [];
          const doneSteps = checklist.filter(c => c.done).length;
          const totalSteps = checklist.length;
          const pctDone = totalSteps > 0 ? Math.round((doneSteps / totalSteps) * 100) : 0;

          return (
            <div 
              key={ini.id} 
              id={`ini-card-${ini.id}`}
              className="border border-slate-200 hover:border-slate-350 bg-[#FAF9F5]/40 rounded-xl p-5 hover:shadow-xs transition-all relative text-left flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Ribbon Tag Priority & Owner */}
                <div className="flex items-center justify-between gap-2">
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${statusDetails.css}`}>
                    {statusDetails.label}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                    <Users className="w-3.5 h-3.5" />
                    <span>Líder: <b className="text-slate-800">{ini.owner}</b></span>
                  </div>
                </div>

                {/* Title */}
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-slate-950 font-sans tracking-tight">
                    {ini.name}
                  </h4>
                  <p className="text-[11.5px] text-slate-600 leading-relaxed text-justify">
                    {isSimpleMode(mode) ? ini.descriptionSimple : ini.descriptionTechnical}
                  </p>
                </div>

                {/* Status Toggle buttons */}
                <div className="flex items-center gap-1.5 pt-1">
                  <span className="text-[9px] font-mono text-slate-400 uppercase font-bold">Mudar Status:</span>
                  {(["PLANEJADO", "EM_EXECUCAO", "CONCLUIDO"] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => onChangeStatus(ini.id, st)}
                      className={`text-[8.5px] font-mono px-1.5 py-0.5 rounded uppercase font-bold transition-all border cursor-pointer ${
                        ini.status === st 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                      }`}
                    >
                      {st.replace("_", " ")}
                    </button>
                  ))}
                </div>

                {/* Checklist steps list */}
                <div className="space-y-2 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[10px] font-mono font-bold text-slate-400">
                    <span className="flex items-center gap-1">
                      <ClipboardList className="w-3.5 h-3.5 text-slate-330" /> 
                      {isSimpleMode(mode) ? "LISTA DE ETAPAS" : "CHECKLIST DA INICIATIVA"}
                    </span>
                    <span className="text-slate-700">{doneSteps}/{totalSteps} CONCLUÍDOS ({pctDone}%)</span>
                  </div>

                  <div className="space-y-1.5 bg-white p-3 rounded-lg border border-slate-100 max-h-[160px] overflow-y-auto">
                    {checklist.map((item, index) => (
                      <label 
                        key={index} 
                        className="flex items-start gap-2.5 text-xs text-slate-700 cursor-pointer select-none py-0.5 hover:text-slate-900 group"
                      >
                        <input
                          type="checkbox"
                          checked={item.done}
                          onChange={() => onToggleCheckItem(ini.id, index)}
                          className="mt-0.5 rounded border-slate-300 text-[#C49746] focus:ring-[#C49746] w-3.5 h-3.5 cursor-pointer"
                        />
                        <span className={item.done ? "line-through text-slate-450" : "font-medium"}>
                          {item.text}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

              </div>
              
              {/* Progress visual bar */}
              <div className="space-y-1 pt-1.5">
                <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-600 transition-all"
                    style={{ width: `${pctDone}%` }}
                  />
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
