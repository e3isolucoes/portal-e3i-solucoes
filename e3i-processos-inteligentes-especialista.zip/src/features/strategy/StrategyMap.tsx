import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  TrendingUp, 
  Users, 
  Settings, 
  BookOpen, 
  ArrowDown, 
  ArrowUp,
  Sparkles,
  Layers,
  HelpCircle
} from "lucide-react";

export interface StrategyMapProps {
  mode: UsabilityMode;
  onSelectObjective?: (id: string) => void;
}

export interface StrategicObjective {
  id: string;
  perspective: "FINANCEIRA" | "CLIENTES" | "PROCESSOS" | "APRENDIZADO";
  titleSimple: string;
  titleTechnical: string;
  targetSimple: string;
  targetTechnical: string;
  progress: number;
}

export default function StrategyMap({
  mode,
  onSelectObjective
}: StrategyMapProps) {
  
  const objectives: StrategicObjective[] = [
    // Financeira
    {
      id: "obj_fin_1",
      perspective: "FINANCEIRA",
      titleSimple: "Garantir a sobrevivência financeira e lucro saudável",
      titleTechnical: "Aumentar Margem EBITDA & Sustentabilidade de Caixa",
      targetSimple: "Aumentar as sobras de caixa mensais em +15%",
      targetTechnical: "Reduzir OPEX em 10% e otimizar capital de giro",
      progress: 75
    },
    {
      id: "obj_fin_2",
      perspective: "FINANCEIRA",
      titleSimple: "Aumentar o faturamento através de novas vendas",
      titleTechnical: "Diversificar Receita e Expandir Market Share",
      targetSimple: "Trazer 20 novos clientes de alto valor este ano",
      targetTechnical: "Elevar o LTV (Lifetime Value) médio em 25%",
      progress: 45
    },
    // Clientes
    {
      id: "obj_cli_1",
      perspective: "CLIENTES",
      titleSimple: "Fazer o cliente amar o nosso atendimento e nos indicar",
      titleTechnical: "Fidelização de Clientes & Elevação do NPS Score",
      targetSimple: "Alcançar nota de aprovação de atendimento acima de 9.0",
      targetTechnical: "Bater NPS (Net Promoter Score) na Zona de Excelência (>85)",
      progress: 60
    },
    {
      id: "obj_cli_2",
      perspective: "CLIENTES",
      titleSimple: "Entregar produtos e serviços sem nenhum erro",
      titleTechnical: "Garantia de Qualidade Percebida & Lead Time",
      targetSimple: "Reduzir atrasos de entregas de mercadorias para zero",
      targetTechnical: "SLA de entrega dentro de 24 horas em 98% dos pedidos",
      progress: 82
    },
    // Processos Internos
    {
      id: "obj_proc_1",
      perspective: "PROCESSOS",
      titleSimple: "Padronizar o passo a passo de todas as tarefas chave",
      titleTechnical: "Otimização de Processos Clínicos & Matriz RACI",
      targetSimple: "Mapear o manual de processos dos 3 setores mais importantes",
      targetTechnical: "Formalização de 100% de SOPs cruciais e matriz de decisões",
      progress: 30
    },
    {
      id: "obj_proc_2",
      perspective: "PROCESSOS",
      titleSimple: "Usar softwares eficientes para evitar controle em papel",
      titleTechnical: "Transformação Digital & Automação de Fluxo de Caixa",
      targetSimple: "Instalar sistema integrado para dar baixa automática de estoque",
      targetTechnical: "Sincronização 100% via API com tempo real de inventário",
      progress: 50
    },
    // Aprendizado e Crescimento
    {
      id: "obj_apr_1",
      perspective: "APRENDIZADO",
      titleSimple: "Treinar nossa equipe nas ferramentas certas",
      titleTechnical: "Capacitação Contínua (L&D) & Matriz de Polivalência",
      targetSimple: "Fazer 1 treinamento prático de vendas por mês no time",
      targetTechnical: "Elevar índice de polivalência técnica em +20% global",
      progress: 90
    },
    {
      id: "obj_apr_2",
      perspective: "APRENDIZADO",
      titleSimple: "Ter um ambiente de confiança onde as pessoas dão ideias",
      titleTechnical: "Cultura de Accountability & Segurança Psicológica",
      targetSimple: "Realizar reuniões curtas toda segunda para ouvir feedbacks",
      targetTechnical: "Rituais semanais de alinhamento com 100% de adesão atestada",
      progress: 68
    }
  ];

  const perspectivesData = [
    {
      key: "FINANCEIRA",
      titleSimple: "💰 Lucro & Sobrevivência (Financeira)",
      titleTechnical: "💰 Financeira (Financial Perspective)",
      questionSimple: "Qual resultado financeiro queremos ver no caixa?",
      questionTechnical: "Como geramos valor econômico sustentável aos acionistas?",
      icon: <TrendingUp className="w-5 h-5 text-amber-600" />,
      color: "bg-amber-50 border-amber-200"
    },
    {
      key: "CLIENTES",
      titleSimple: "🤝 Satisfação do Cliente (Clientes)",
      titleTechnical: "🤝 Clientes (Customer Perspective)",
      questionSimple: "Como os clientes devem avaliar nosso serviço?",
      questionTechnical: "Qual a nossa proposta de valor diferencial no mercado?",
      icon: <Users className="w-5 h-5 text-blue-600" />,
      color: "bg-blue-50 border-blue-200"
    },
    {
      key: "PROCESSOS",
      titleSimple: "⚙️ Eficiência Interna (Processos)",
      titleTechnical: "⚙️ Processos Internos (Internal Business Processes)",
      questionSimple: "Em quais rotinas e tarefas precisamos ser impecáveis?",
      questionTechnical: "Quais processos críticos criam excelência e barreira logística?",
      icon: <Settings className="w-5 h-5 text-purple-600" />,
      color: "bg-purple-50 border-purple-200"
    },
    {
      key: "APRENDIZADO",
      titleSimple: "🌱 Treinamento & Equipe (Aprendizado)",
      titleTechnical: "🌱 Aprendizado e Crescimento (Learning & Growth)",
      questionSimple: "Como treinamos as mentes do time para sustentar o crescimento?",
      questionTechnical: "Como mantemos inovação, ativos intangíveis e clima seguro?",
      icon: <BookOpen className="w-5 h-5 text-emerald-600" />,
      color: "bg-emerald-50 border-emerald-200"
    }
  ];

  return (
    <div id="strategy-map-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* Title block */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            🗺️ {isSimpleMode(mode) ? "Mapa de Objetivos Interligados" : "Balanced Scorecard Strategic Map (Norten-Kaplan)"}
          </h3>
          <p className="text-xs text-slate-500">
            {isSimpleMode(mode) 
              ? "Objetivos conectados de baixo para cima: Treinar a equipe melhora os processos, que atrai clientes, gerando lucros." 
              : "Causal linkages showing how Learning & Growth drives Process Optimization, which enhances Customer Value, yielding Financial Return."}
          </p>
        </div>
        
        {isExpertMode(mode) && (
          <span className="text-[9px] font-mono bg-slate-950 text-slate-200 px-2 py-0.5 rounded uppercase font-black">
            Causal Link Map (Bottom-Up)
          </span>
        )}
      </div>

      {/* BSC PERSPECTIVES STACK IN DESKTOP (BOTTOM-UP REPRESENTATION) */}
      <div className="flex flex-col space-y-4 relative">
        
        {/* Draw bottom-up arrow columns on the right for expert mode to guide causal links */}
        {isExpertMode(mode) && (
          <div className="absolute right-4 top-10 bottom-10 w-8 flex flex-col items-center justify-between pointer-events-none z-10 hidden md:flex">
            <div className="flex flex-col items-center">
              <span className="text-[8px] font-mono font-bold text-[#C49746]">IMPACTO</span>
              <ArrowUp className="w-4 h-4 text-[#C49746] animate-pulse" />
            </div>
            <div className="w-[1px] h-full bg-slate-200" />
            <div className="flex flex-col items-center">
              <ArrowUp className="w-4 h-4 text-slate-400" />
              <span className="text-[8px] font-mono font-bold text-slate-400">CAUSALIDADE</span>
            </div>
          </div>
        )}

        {perspectivesData.map((p, idx) => {
          const perspectiveObjectives = objectives.filter(o => o.perspective === p.key);

          return (
            <div 
              key={p.key} 
              id={`bsc-perspective-${p.key}`}
              className={`p-4 rounded-xl border-2 ${p.color} transition-all relative flex flex-col md:flex-row gap-4 items-start md:items-center`}
            >
              
              {/* Left identifier (Perspective metadata) */}
              <div className="md:w-[220px] shrink-0 space-y-1.5 border-b md:border-b-0 md:border-r border-slate-200 pb-3 md:pb-0 pr-4">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-white rounded border">
                    {p.icon}
                  </div>
                  <span className="text-xs uppercase font-sans font-black text-slate-900 tracking-tight">
                    {isSimpleMode(mode) ? p.titleSimple : p.titleTechnical}
                  </span>
                </div>
                
                {/* Simple guideline question */}
                <span className="text-[11px] text-slate-500 leading-normal italic block">
                  {isSimpleMode(mode) ? p.questionSimple : p.questionTechnical}
                </span>

                {isExpertMode(mode) && (
                  <span className="text-[8.5px] font-mono text-slate-400 uppercase font-bold bg-white/60 px-1 py-0.5 rounded border inline-block">
                    Eixo {idx + 1}: {p.key}
                  </span>
                )}
              </div>

              {/* Objectives lists in this perspective */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
                {perspectiveObjectives.map((obj) => (
                  <div
                    key={obj.id}
                    id={`obj-card-${obj.id}`}
                    onClick={() => onSelectObjective && onSelectObjective(obj.id)}
                    className="p-3 bg-white border border-slate-200 rounded-lg hover:border-[#C49746]/60 cursor-pointer transition-all hover:shadow-xs group space-y-2 text-left"
                  >
                    <div className="space-y-1">
                      <span className="text-xs font-black text-slate-900 group-hover:text-[#C49746] transition-colors leading-snug block">
                        {isSimpleMode(mode) ? obj.titleSimple : obj.titleTechnical}
                      </span>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                        <span className="font-extrabold text-slate-700">Meta:</span>
                        <span>{isSimpleMode(mode) ? obj.targetSimple : obj.targetTechnical}</span>
                      </div>
                    </div>

                    {/* Progress tracking */}
                    <div className="space-y-1 pt-1 border-t border-slate-100">
                      <div className="flex justify-between items-center text-[9px] font-mono font-bold text-slate-400">
                        <span>PROGRESSO</span>
                        <span className="text-slate-800">{obj.progress}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[#C49746] transition-all"
                          style={{ width: `${obj.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          );
        })}

      </div>

    </div>
  );
}
