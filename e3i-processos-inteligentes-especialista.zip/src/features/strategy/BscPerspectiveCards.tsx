import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Building,
  DollarSign, 
  Users, 
  Cpu, 
  GraduationCap, 
  TrendingUp, 
  BadgeCheck, 
  ArrowUpRight,
  Plus,
  HelpCircle,
  LayoutGrid
} from "lucide-react";

export interface BscPerspectiveCardsProps {
  mode: UsabilityMode;
  onAddIndicator?: (perspectiveKey: string) => void;
}

export interface BscPerspective {
  key: string;
  title: string;
  labelSimple: string;
  icon: React.ReactNode;
  question: string;
  explanation: string;
  colorTheme: {
    bg: string;
    border: string;
    accent: string;
    text: string;
  };
  metrics: {
    nameSimple: string;
    nameTechnical: string;
    currentValue: string;
    targetValue: string;
    status: "ESTÁVEL" | "CRÍTICO" | "EXCELENTE";
  }[];
}

export default function BscPerspectiveCards({
  mode,
  onAddIndicator
}: BscPerspectiveCardsProps) {
  
  const perspectives: BscPerspective[] = [
    {
      key: "FINANCEIRA",
      title: "Perspectiva Financeira",
      labelSimple: "Faturamento e Poupança",
      icon: <DollarSign className="w-5 h-5 text-amber-600" />,
      question: "Qual resultado financeiro precisamos entregar?",
      explanation: "Como definimos nossa saúde financeira frente aos sócios e investidores.",
      colorTheme: {
        bg: "bg-amber-50/40",
        border: "border-amber-100",
        accent: "bg-amber-550",
        text: "text-amber-800"
      },
      metrics: [
        {
          nameSimple: "Faturamento Bruto Mensal",
          nameTechnical: "Mensuração de Overhead & MRR",
          currentValue: "R$ 125.000,00",
          targetValue: "R$ 150.000,00",
          status: "ESTÁVEL"
        },
        {
          nameSimple: "Lucro Limpo Restante (Sobras)",
          nameTechnical: "EBITDA Margin / Net Profit",
          currentValue: "18.5%",
          targetValue: "25.0%",
          status: "ESTÁVEL"
        }
      ]
    },
    {
      key: "CLIENTES",
      title: "Perspectiva de Clientes",
      labelSimple: "Fidelização e Opinião do Cliente",
      icon: <Users className="w-5 h-5 text-blue-600" />,
      question: "Como nossos clientes nos avaliam diariamente?",
      explanation: "A proposta de valor oferecida aos clientes e nossa sobrevivência no mercado.",
      colorTheme: {
        bg: "bg-blue-50/40",
        border: "border-blue-100",
        accent: "bg-blue-550",
        text: "text-blue-800"
      },
      metrics: [
        {
          nameSimple: "Satisfação dos Clientes (Nota)",
          nameTechnical: "NPS (Net Promoter Score)",
          currentValue: "78 pontos",
          targetValue: "85 pontos",
          status: "ESTÁVEL"
        },
        {
          nameSimple: "Tempo médio de entrega / Resposta",
          nameTechnical: "SLA Operacional (Service Level Agreement)",
          currentValue: "4.8 horas",
          targetValue: "4.0 horas",
          status: "EXCELENTE"
        }
      ]
    },
    {
      key: "PROCESSOS",
      title: "Perspectiva de Processos Internos",
      labelSimple: "Rotinas e Padronização",
      icon: <Cpu className="w-5 h-5 text-purple-600" />,
      question: "Em quais processos operacionais precisamos ser excelentes?",
      explanation: "As tarefas e regras do dia a dia necessárias para fazer o cliente feliz.",
      colorTheme: {
        bg: "bg-purple-50/40",
        border: "border-purple-100",
        accent: "bg-purple-550",
        text: "text-purple-800"
      },
      metrics: [
        {
          nameSimple: "Setores com tarefas desenhadas e explicadas",
          nameTechnical: "Taxa de Padronização SOP / BPMN",
          currentValue: "40%",
          targetValue: "100%",
          status: "CRÍTICO"
        },
        {
          nameSimple: "Atrasos e perdas de material ou retrabalho",
          nameTechnical: "OEE Operacional & Desperdício",
          currentValue: "12%",
          targetValue: "manter < 5%",
          status: "CRÍTICO"
        }
      ]
    },
    {
      key: "APRENDIZADO",
      title: "Perspectiva de Aprendizado e Crescimento",
      labelSimple: "Treinamentos e Clima Organizacional",
      icon: <GraduationCap className="w-5 h-5 text-emerald-600" />,
      question: "Como ensinamos e motivamos nosso pessoal?",
      explanation: "As habilidades internas, tecnologias e cultura corporativa necessárias para crescer.",
      colorTheme: {
        bg: "bg-emerald-50/40",
        border: "border-emerald-100",
        accent: "bg-[#C49746]",
        text: "text-emerald-800"
      },
      metrics: [
        {
          nameSimple: "Colaboradores treinados e multifuncionais",
          nameTechnical: "Polivalência Crítica / Skill Mapping",
          currentValue: "65%",
          targetValue: "80%",
          status: "ESTÁVEL"
        },
        {
          nameSimple: "Rotatividade de funcionários (Fugas)",
          nameTechnical: "Índice Churn Corporativo / Turnover Rate",
          currentValue: "2% a.m.",
          targetValue: "abaixo de 1.5%",
          status: "EXCELENTE"
        }
      ]
    }
  ];

  const getStatusBadge = (status: "ESTÁVEL" | "CRÍTICO" | "EXCELENTE") => {
    switch (status) {
      case "CRÍTICO":
        return "bg-rose-100 text-rose-800 border-rose-200";
      case "EXCELENTE":
        return "bg-emerald-100 text-emerald-800 border-emerald-250";
      default:
        return "bg-slate-150 text-slate-700 border-slate-200";
    }
  };

  return (
    <div id="bsc-perspective-cards" className="space-y-6">
      
      {/* Small intro block if EXPERT */}
      {isExpertMode(mode) && (
        <div className="bg-slate-900 text-slate-100 p-4 rounded-xl border border-slate-800 flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-amber-500 font-bold uppercase tracking-widest block">Metodologia Norton & Kaplan</span>
            <h4 className="text-sm font-bold text-white">4 Vetores de Capacidade Estratégica</h4>
            <p className="text-xs text-slate-350">
              O BSC equilibra indicadores financeiros históricos com os direcionadores (leads) das perspectivas operacionais, de clientes e de aprendizado.
            </p>
          </div>
          <LayoutGrid className="w-8 h-8 text-slate-600 shrink-0 hidden sm:block" />
        </div>
      )}

      {/* Grid container */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {perspectives.map((pers) => (
          <div 
            key={pers.key}
            id={`bsc-card-${pers.key}`}
            className={`border border-slate-200 rounded-xl overflow-hidden transition-all duration-200 hover:shadow-md bg-white flex flex-col justify-between`}
          >
            {/* Perspective card header */}
            <div className={`p-4 ${pers.colorTheme.bg} border-b border-slate-150 flex items-center justify-between`}>
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-3xs">
                  {pers.icon}
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 font-sans">
                    {isSimpleMode(mode) ? pers.labelSimple : pers.title}
                  </h4>
                  <p className="text-[11px] font-mono text-slate-400">BSC Key: {pers.key}</p>
                </div>
              </div>

              {isExpertMode(mode) && onAddIndicator && (
                <button
                  type="button"
                  onClick={() => onAddIndicator(pers.key)}
                  className="p-1 px-2 text-[10px] bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold rounded flex items-center gap-1 cursor-pointer transition-all active:scale-95"
                >
                  <Plus className="w-3 h-3" /> Novo KPI
                </button>
              )}
            </div>

            {/* Core Body */}
            <div className="p-4 flex-1 space-y-4">
              
              {/* Perspective Question */}
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-slate-400" /> Pergunta de Direcionamento
                </span>
                <p className="text-xs text-slate-800 leading-normal font-semibold font-sans">
                  "{pers.question}"
                </p>
              </div>

              {/* Description */}
              {isExpertMode(mode) && (
                <p className="text-[11.5px] text-slate-500 text-justify leading-relaxed">
                  {pers.explanation}
                </p>
              )}

              {/* KPIs indicators list */}
              <div className="space-y-2.5 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                  📈 Indicadores de Desempenho
                </span>
                
                <div className="space-y-2">
                  {pers.metrics.map((m, mIdx) => (
                    <div 
                      key={mIdx} 
                      className="p-2.5 bg-slate-50 hover:bg-slate-100/55 rounded-lg border border-slate-150 flex items-center justify-between gap-3 text-left transition-all"
                    >
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold text-slate-900 block leading-tight">
                          {isSimpleMode(mode) ? m.nameSimple : m.nameTechnical}
                        </span>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                          <span>Atual: <b className="text-slate-850">{m.currentValue}</b></span>
                          <span className="text-slate-350">|</span>
                          <span>Meta: <b className="text-[#C49746]">{m.targetValue}</b></span>
                        </div>
                      </div>

                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${getStatusBadge(m.status)}`}>
                        {m.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
