import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Zap, 
  Plus, 
  User, 
  Calendar, 
  TrendingUp, 
  Sparkles, 
  CheckCircle,
  HelpCircle,
  Trash2,
  AlertCircle
} from "lucide-react";

export interface OkrItem {
  id: string;
  objectiveSimple: string;
  objectiveTechnical: string;
  keyResultSimple: string;
  keyResultTechnical: string;
  owner: string;
  deadline: string;
  progress: number; // 0 to 100
  status: "EM_ANDAMENTO" | "CONCLUIDO" | "ATRASADO";
  derivedFromGap?: string; // e.g. "estrutura", "processos", "sistemas"
}

export interface OkrBoardProps {
  okrs: OkrItem[];
  mode: UsabilityMode;
  onAddOkr: (newOkr: OkrItem) => void;
  onUpdateOkrProgress: (id: string, progress: number) => void;
  onDeleteOkr?: (id: string) => void;
  diagnosisGaps?: string[]; // list of poor scoring areas to generate recommendations
}

export default function OkrBoard({
  okrs,
  mode,
  onAddOkr,
  onUpdateOkrProgress,
  onDeleteOkr,
  diagnosisGaps = []
}: OkrBoardProps) {
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [newObj, setNewObj] = useState("");
  const [newKr, setNewKr] = useState("");
  const [newOwner, setNewOwner] = useState("");
  const [newDeadline, setNewDeadline] = useState("");

  // Presets of OKR templates based on diagnosis gaps to auto-inject
  const okrSuggestionsByGap: Record<string, { oSimple: string; oTech: string; krSimple: string; krTech: string; owner: string }[]> = {
    estrutura: [
      {
        oSimple: "Arrumar a casa e definir exatamente quem faz o que",
        oTech: "Estabelecer Alinhamento e Governabilidade de Estrutura Organizacional",
        krSimple: "Mapear a Matriz RACI de responsabilidades das 5 maiores áreas da empresa",
        krTech: "Modelagem estruturada de organograma corporativo e aprovação de matriz de tomada de decisão",
        owner: "Diretor Executivo / RH"
      }
    ],
    processos: [
      {
        oSimple: "Padronizar o passo a passo para que os serviços não dependam de poucas pessoas",
        oTech: "Otimizar a Eficiência Operacional através da Modelagem BPMN",
        krSimple: "Escrever e postar o manual de processos dos 4 setores principais",
        krTech: "Criação de Standard Operating Procedures (SOPs) em 100% dos fluxos críticos de valor",
        owner: "Gestor de Operações"
      }
    ],
    sistemas: [
      {
        oSimple: "Substituir planilhas lentas de papel por um software moderno e integrado",
        oTech: "Migrar para Plataformas Digitais Cloud-Native e Automatizadas",
        krSimple: "Instalar sistema ERP novo e unificar o cadastro de 100% das vendas",
        krTech: "Alcançar taxa de integração sistêmica de 95% na captação automática de transações",
        owner: "Responsável TI / Tecnologia"
      }
    ],
    indicadores: [
      {
        oSimple: "Ter dados na tela para parar de guiar a empresa com suposições",
        oTech: "Soberania de Dados e Business Intelligence Ativo",
        krSimple: "Criar um painel simples mostrando faturamento e custos em tempo real",
        krTech: "Desenvolvedor 3 Dashboards de KPI dinâmicos com atualização de latência mínima",
        owner: "Controller Financeiro"
      }
    ]
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "CONCLUIDO":
        return "bg-emerald-100 text-emerald-800 border bg-emerald-100 border-emerald-200";
      case "ATRASADO":
        return "bg-rose-100 text-rose-800 border border-rose-200";
      default:
        return "bg-amber-100 text-[#7C5A14] border border-amber-200";
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newObj || !newKr) return;

    const added: OkrItem = {
      id: "okr_" + Date.now(),
      objectiveSimple: newObj,
      objectiveTechnical: newObj, // copy to tech
      keyResultSimple: newKr,
      keyResultTechnical: newKr, // copy to tech
      owner: newOwner || "Sem responsável",
      deadline: newDeadline || "Não definido",
      progress: 0,
      status: "EM_ANDAMENTO"
    };

    onAddOkr(added);
    setNewObj("");
    setNewKr("");
    setNewOwner("");
    setNewDeadline("");
    setShowAddForm(false);
  };

  const handleApplySuggestion = (sug: typeof okrSuggestionsByGap[string][number]) => {
    const added: OkrItem = {
      id: "okr_" + Date.now(),
      objectiveSimple: sug.oSimple,
      objectiveTechnical: sug.oTech,
      keyResultSimple: sug.krSimple,
      keyResultTechnical: sug.krTech,
      owner: sug.owner,
      deadline: "30 dias",
      progress: 0,
      status: "EM_ANDAMENTO"
    };
    onAddOkr(added);
  };

  return (
    <div id="okr-board-root" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* Title block */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            🎯 {isSimpleMode(mode) ? "Metas de Curto Prazo (OKRs)" : "Objectives & Key Results (OKR Board)"}
          </h3>
          <p className="text-xs text-slate-500">
            {isSimpleMode(mode) 
              ? "Confira nossos focos imediatos e como medimos de forma simples se deu certo." 
              : "Desdobre os objetivos de longo prazo (BSC) em ciclos táticos trimestrais mensuráveis."}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#C49746] hover:bg-[#A97E34] text-white font-mono text-[11px] font-bold uppercase rounded cursor-pointer transition-all active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" /> {showAddForm ? "Cancelar" : "Definir Nova Meta"}
        </button>
      </div>

      {/* SUGGESTIONS BOX BASED ON GAPS */}
      {diagnosisGaps.length > 0 && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#C49746] animate-pulse" />
            <span className="text-[11px] font-mono font-bold text-amber-850 uppercase tracking-wider">
              🚀 Oportunidades Recomendadas por sua Maturidade
            </span>
          </div>
          <p className="text-xs text-slate-600">
            Com base em falhas mapeadas em seu diagnóstico de gestão, recomendamos adicionar estas metas de curto prazo:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
            {diagnosisGaps.map((gap) => {
              const suggestions = okrSuggestionsByGap[gap] || [];
              return suggestions.map((sug, sIdx) => (
                <div 
                  key={`${gap}-${sIdx}`} 
                  className="bg-white p-3 rounded border border-slate-150 flex flex-col justify-between items-start gap-2 text-left"
                >
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono font-black uppercase tracking-wider text-rose-700 bg-rose-50 border border-rose-100 px-1.5 rounded-sm">
                      Correção de lacuna de {gap.toUpperCase()}
                    </span>
                    <h5 className="text-xs font-bold text-slate-900">
                      {isSimpleMode(mode) ? sug.oSimple : sug.oTech}
                    </h5>
                    <p className="text-[11px] text-slate-500 italic">
                      KR: {isSimpleMode(mode) ? sug.krSimple : sug.krTech}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleApplySuggestion(sug)}
                    className="inline-flex items-center gap-1 text-[10px] font-bold text-[#C49746] hover:text-[#AC8134] cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Adicionar esta meta ao meu quadro
                  </button>
                </div>
              ));
            })}
          </div>
        </div>
      )}

      {/* OKR ADDITION FORM */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-4 text-left">
          <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider">
            📝 {isSimpleMode(mode) ? "Criar Novo Foco Inteligente" : "Cadastrar Nova Meta OKR"}
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Objective */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                {isSimpleMode(mode) ? "1. Qual grande resultado a empresa quer alcançar?" : "Objetivo Técnico (O)"}
              </label>
              <textarea
                value={newObj}
                onChange={(e) => setNewObj(e.target.value)}
                placeholder={isSimpleMode(mode) ? "Ex: Guardar mais lucros e reduzir desperdício" : "Ex: Otimizar o Retorno de Capital Empregado (ROIC)"}
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white resize-y"
                rows={2}
                required
              />
            </div>

            {/* Key Result */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                {isSimpleMode(mode) ? "2. Como saberemos que deu certo? (Métrica em números)" : "Resultado-Chave (KR)"}
              </label>
              <textarea
                value={newKr}
                onChange={(e) => setNewKr(e.target.value)}
                placeholder={isSimpleMode(mode) ? "Ex: Sofrer menos de 3 reclamações e alcançar R$ 15 mil guardado" : "Ex: Reduzir a variabilidade de margem EBITDA de 8% para menos de 3%"}
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white resize-y"
                rows={2}
                required
              />
            </div>

            {/* Owner */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                {isSimpleMode(mode) ? "3. Quem será responsável?" : "Responsável (Owner)"}
              </label>
              <input
                type="text"
                value={newOwner}
                onChange={(e) => setNewOwner(e.target.value)}
                placeholder="Ex: Carlos - Operações"
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white"
              />
            </div>

            {/* Deadline */}
            <div className="space-y-1">
              <label className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
                {isSimpleMode(mode) ? "4. Até quando quer alcançar?" : "Data Alvo / Target Cycle"}
              </label>
              <input
                type="text"
                value={newDeadline}
                onChange={(e) => setNewDeadline(e.target.value)}
                placeholder="Ex: Próximos 45 dias / Final T2"
                className="w-full text-xs font-sans p-2 border border-slate-200 rounded focus:ring-1 focus:ring-[#C49746] bg-white"
              />
            </div>

          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 border-2 border-slate-950 text-white font-mono text-[11px] font-bold uppercase transition-all rounded hover:bg-slate-800 cursor-pointer"
            >
              Confirmar e Salvar Meta
            </button>
          </div>
        </form>
      )}

      {/* OKRS LIST / GRID */}
      {okrs.length === 0 ? (
        <div className="p-8 border border-dashed border-slate-250 text-center rounded-lg max-w-md mx-auto">
          <AlertCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h4 className="text-xs font-bold text-slate-700">Nenhum OKR Ativo</h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Recomendamos escolher uma sugestão de gap acima ou clicar em "Definir Nova Meta" para começar.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {okrs.map((item) => (
            <div 
              key={item.id} 
              id={`okr-node-${item.id}`}
              className="border border-slate-200 rounded-xl p-4 sm:p-5 hover:shadow-xs transition-all bg-white relative text-left"
            >
              
              <div className="flex items-start justify-between gap-4 flex-wrap">
                {/* Objective + KR block */}
                <div className="space-y-2.5 flex-1 min-w-[240px]">
                  
                  {/* Objective (O) */}
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-mono font-black text-[#C49746] bg-amber-50 px-1 py-0.5 rounded border border-amber-150">
                      {isSimpleMode(mode) ? "META PRINCIPAL OU RESULTADO" : "OBJETIVO DO NEGÓCIO"}
                    </span>
                    <h4 className="text-sm font-black text-slate-950 leading-snug">
                      {isSimpleMode(mode) ? item.objectiveSimple : item.objectiveTechnical}
                    </h4>
                  </div>

                  {/* Key Result (KR) */}
                  <div className="p-3 bg-slate-50 border border-slate-150 rounded-lg space-y-1">
                    <span className="text-[9px] font-mono font-bold text-slate-450 block uppercase tracking-wide">
                      {isSimpleMode(mode) ? "Como saberemos se deu certo?" : "Resultado-Chave Associado (Key Result)"}
                    </span>
                    <p className="text-xs text-slate-800 leading-normal font-medium text-justify">
                      {isSimpleMode(mode) ? item.keyResultSimple : item.keyResultTechnical}
                    </p>
                  </div>

                </div>

                {/* Right hand details */}
                <div className="space-y-3 shrink-0 text-left min-w-[150px] sm:text-right">
                  
                  {/* Status Badge */}
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border inline-block ${getStatusBadge(item.status)}`}>
                    {item.status.replace("_", " ")}
                  </span>

                  {/* Owner & Deadline */}
                  <div className="space-y-1.5 text-[11px] text-slate-500">
                    <div className="flex sm:justify-end items-center gap-1.5 font-sans">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>Responsável: <b>{item.owner}</b></span>
                    </div>
                    <div className="flex sm:justify-end items-center gap-1.5 font-sans">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Até: <b>{item.deadline}</b></span>
                    </div>
                  </div>

                  {/* Actions (Delete if callback exists) */}
                  {onDeleteOkr && (
                    <button
                      type="button"
                      onClick={() => onDeleteOkr(item.id)}
                      className="text-[10px] font-mono text-slate-400 hover:text-rose-600 transition-colors cursor-pointer flex sm:ml-auto items-center gap-1 pt-1"
                    >
                      <Trash2 className="w-3 h-3" /> Excluir
                    </button>
                  )}

                </div>
              </div>

              {/* Progress slider / bar */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-mono font-bold">
                    <span className="text-slate-400 uppercase tracking-wider">
                      {isSimpleMode(mode) ? "Progresso alcançado" : "Métrica de Progresso de KR"}
                    </span>
                    <span className="text-slate-800 font-extrabold">{item.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden relative">
                    <div 
                      className="h-full bg-[#C49746] transition-all"
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                </div>

                {/* Micro-inputs to increase progress */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-[10px] font-mono text-slate-400">Ajustar:</span>
                  {[0, 25, 50, 75, 100].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => onUpdateOkrProgress(item.id, pct)}
                      className={`text-[9px] font-mono font-extrabold p-1 px-1.5 rounded border transition-all cursor-pointer ${
                        item.progress === pct 
                          ? "bg-slate-900 text-white border-slate-900" 
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
}
