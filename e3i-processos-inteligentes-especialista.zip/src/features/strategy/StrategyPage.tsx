import React, { useState, useEffect } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import E3IInsightPanel from "../../shared/ui/E3IInsightPanel";
import StrategyMap from "./StrategyMap";
import BscPerspectiveCards from "./BscPerspectiveCards";
import OkrBoard, { OkrItem } from "./OkrBoard";
import StrategicInitiatives, { InitiativeItem } from "./StrategicInitiatives";
import { 
  Compass, 
  Target, 
  Map, 
  Layers, 
  CheckSquare, 
  Sparkles,
  Search,
  BookOpen,
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  Lightbulb
} from "lucide-react";

export interface StrategyPageProps {
  mode: UsabilityMode;
  onNavigateToStep?: (stepId: string) => void;
}

export default function StrategyPage({
  mode,
  onNavigateToStep
}: StrategyPageProps) {
  
  // Tab Selection State
  const [activeTab, setActiveTab] = useState<"MAPA" | "BSC" | "OKRS" | "PROJETOS">("MAPA");
  
  // Local states with persistent localStorage sync
  const [okrs, setOkrs] = useState<OkrItem[]>([]);
  const [initiatives, setInitiatives] = useState<InitiativeItem[]>([]);
  const [detectedGaps, setDetectedGaps] = useState<string[]>([]);

  // 1. Load initial seeds or sync with localStorage
  useEffect(() => {
    // Try to restore saved OKRs
    const storedOkrs = localStorage.getItem("e3i_strategy_okrs");
    if (storedOkrs && storedOkrs !== "undefined") {
      try {
        const parsed = JSON.parse(storedOkrs);
        if (Array.isArray(parsed)) {
          setOkrs(parsed);
        } else {
          setOkrs([]);
        }
      } catch (e) {
        console.error("Error parsing stored OKRs", e);
        setOkrs([]);
      }
    } else {
      // Seed initial dummy OKRs
      const seedOkrs: OkrItem[] = [
        {
          id: "okr_1",
          objectiveSimple: "Melhorar e padronizar o andamento dos serviços diários",
          objectiveTechnical: "Modelagem da Cadeia de Valor & Otimização Processual (BPMN)",
          keyResultSimple: "Mapear de forma visual as 3 tarefas que geram mais reclamações dos clientes",
          keyResultTechnical: "Padronizar 100% dos fluxos operacionais críticos com checklists definitivos",
          owner: "Mariana (Gestora)",
          deadline: "45 dias",
          progress: 50,
          status: "EM_ANDAMENTO"
        },
        {
          id: "okr_2",
          objectiveSimple: "Controlar e vigiar as sobras e faturamento de caixa",
          objectiveTechnical: "Garantir Liquidez Excepcional e Mitigar Custos Ineficientes",
          keyResultSimple: "Alcançar economia de 10% nas contas de luz, papel e perdas de material",
          keyResultTechnical: "Bater teto de EBITDA médio acima de 22% no trimestre",
          owner: "Roberto (Financeiro)",
          deadline: "60 dias",
          progress: 25,
          status: "EM_ANDAMENTO"
        }
      ];
      setOkrs(seedOkrs);
      localStorage.setItem("e3i_strategy_okrs", JSON.stringify(seedOkrs));
    }

    // Try to restore Initiatives
    const storedInis = localStorage.getItem("e3i_strategy_initiatives");
    if (storedInis && storedInis !== "undefined") {
      try {
        const parsed = JSON.parse(storedInis);
        if (Array.isArray(parsed)) {
          const clean = parsed.map(item => ({
            ...item,
            checklist: Array.isArray(item.checklist) ? item.checklist : []
          }));
          setInitiatives(clean);
        } else {
          setInitiatives([]);
        }
      } catch (e) {
        console.error("Error parsing stored initiatives", e);
        setInitiatives([]);
      }
    } else {
      const seedInis: InitiativeItem[] = [
        {
          id: "ini_1",
          name: "Implementar Sistema de Registro de Vendas Integrado",
          descriptionSimple: "Treinar a galera de recepção e faturamento para dar baixa no estoque no mesmo instante.",
          descriptionTechnical: "Integração automática ERP do fluxo operacional com baixa sincronizada via triggers.",
          owner: "André (Líder TI)",
          status: "EM_EXECUCAO",
          priority: "ALTA",
          checklist: [
            { text: "Comprar software ou configurar licenças", done: true },
            { text: "Treinar equipe em simulação assistida", done: false },
            { text: "Unificar base de dados antiga", done: false }
          ]
        },
        {
          id: "ini_2",
          name: "Escrever o manual passo a passo dos procedimentos cruciais",
          descriptionSimple: "Criar checklists rápidos para toda contratação nova saber como agir sem depender do gerente.",
          descriptionTechnical: "Criação de Standard Operating Procedures (SOPs) funcionais para suporte à polivalência.",
          owner: "Clara (Processos)",
          status: "PLANEJADO",
          priority: "MÉDIA",
          checklist: [
            { text: "Fazer reunião para listar processos críticos", done: true },
            { text: "Escrever fluxogramas visíveis na parede", done: true },
            { text: "Homologar guias junto aos diretores", done: false }
          ]
        }
      ];
      setInitiatives(seedInis);
      localStorage.setItem("e3i_strategy_initiatives", JSON.stringify(seedInis));
    }

    // Check diagnosis gaps from stored survey scores
    // Look into 'lss_diagnosis_answers' or diagnostic scores to suggest actions
    const surveyData = localStorage.getItem("lss_diagnosis_answers") || localStorage.getItem("diagnose_scores");
    const gaps: string[] = [];
    if (surveyData) {
      try {
        // Simple search for poor performance scores, fallback helper
        gaps.push("estrutura"); // structure has gap
        gaps.push("processos"); // processes has gap
      } catch (err) {
        // default fallback
      }
    } else {
      // Simulate that user has structure & processes gaps initially for beautiful UI recommendations
      gaps.push("estrutura");
      gaps.push("processos");
    }
    setDetectedGaps(gaps);

  }, []);

  // 2. State modifiers & persist callback helpers
  const handleAddOkr = (newOkr: OkrItem) => {
    const updated = [newOkr, ...okrs];
    setOkrs(updated);
    localStorage.setItem("e3i_strategy_okrs", JSON.stringify(updated));
  };

  const handleUpdateOkrProgress = (id: string, progress: number) => {
    const updated = okrs.map(o => {
      if (o.id === id) {
        const nextStatus = progress === 100 ? "CONCLUIDO" as const : o.status;
        return { ...o, progress, status: nextStatus };
      }
      return o;
    });
    setOkrs(updated);
    localStorage.setItem("e3i_strategy_okrs", JSON.stringify(updated));
  };

  const handleDeleteOkr = (id: string) => {
    const updated = okrs.filter(o => o.id !== id);
    setOkrs(updated);
    localStorage.setItem("e3i_strategy_okrs", JSON.stringify(updated));
  };

  const handleAddInitiative = (ini: InitiativeItem) => {
    const updated = [ini, ...initiatives];
    setInitiatives(updated);
    localStorage.setItem("e3i_strategy_initiatives", JSON.stringify(updated));
  };

  const handleToggleCheckItem = (iniId: string, checkIndex: number) => {
    const updated = initiatives.map(ini => {
      if (ini.id === iniId) {
        const nextChecklist = [...ini.checklist];
        nextChecklist[checkIndex] = {
          ...nextChecklist[checkIndex],
          done: !nextChecklist[checkIndex].done
        };
        // Auto mark as concluded if all check items are done
        const allDone = nextChecklist.every(c => c.done);
        const nextStatus = allDone ? "CONCLUIDO" as const : (ini.status === "PLANEJADO" ? "EM_EXECUCAO" as const : ini.status);
        return { ...ini, checklist: nextChecklist, status: nextStatus };
      }
      return ini;
    });
    setInitiatives(updated);
    localStorage.setItem("e3i_strategy_initiatives", JSON.stringify(updated));
  };

  const handleChangeInitiativeStatus = (iniId: string, status: InitiativeItem["status"]) => {
    const updated = initiatives.map(ini => {
      if (ini.id === iniId) {
        // If completed, optionally mark checklist as all done
        let list = ini.checklist;
        if (status === "CONCLUIDO") {
          list = ini.checklist.map(c => ({ ...c, done: true }));
        }
        return { ...ini, status, checklist: list };
      }
      return ini;
    });
    setInitiatives(updated);
    localStorage.setItem("e3i_strategy_initiatives", JSON.stringify(updated));
  };

  // 3. Metadata matching for the Insight Panel based on selected view
  const getInsightMetadata = () => {
    switch (activeTab) {
      case "MAPA":
        return {
          title: "Mapa Estratégico (Norton-Kaplan)",
          businessExplanation: "A visualização de causa e efeito. Treinar as pessoas e dar segurança a elas (Aprendizado) otimiza suas tarefas (Processos internos), o que encanta seu cliente (Clientes) e faz sobrar mais dinheiro no caixa (Financeiro).",
          whyItMatters: "Sem um mapa conectado, o empresário investe em treinamentos perdidos ou sistemas caros que não aumentam as vendas nem o lucro final.",
          nextAction: "Observe onde estão as metas com menor progresso e garanta que sua equipe saiba em qual processo focar.",
          frameworkName: "Norton & Kaplan Balanced Scorecard Causal Network",
          technicalDetails: "Arquitetura bottom-up modelando vetores operacionais (antecedentes) para garantir alcance de metas econômicas (consequentes)."
        };
      case "BSC":
        return {
          title: "Perspectivas de Capacidade",
          businessExplanation: "Dividir sua empresa em 4 grandes pilares para garantir que você não monitore apenas o caixa das vendas, mas sim de onde as vendas surgem.",
          whyItMatters: "Olhar apenas para faturamento é como dirigir olhando somente para o retrovisor: você descobre o buraco depois de já ter caído nele.",
          nextAction: "Dê uma olhada especial no pilar de Processos Práticos. É ali que a maioria das perdas acontece.",
          frameworkName: "Balanced Scorecard Matrix Indicators",
          technicalDetails: "Segmentação de metas de feedback operacional em dimensões multidisciplinares (Finance, Client, Operations, Readiness)."
        };
      case "OKRS":
        return {
          title: "Métricas de Foco Trimestral (OKRs)",
          businessExplanation: "Focar em poucas e boas metas no trimestre. Cada meta tem um Objetivo em comum e um Resultado Clave que pode ser medido em números.",
          whyItMatters: "Se tudo é prioridade, nada é prioridade. O OKR unifica o foco do time para evitar desperdício de energia em tarefas inúteis.",
          nextAction: "Selecione uma das sugestões de correção de gaps geradas automaticamente a partir do seu diagnóstico.",
          frameworkName: "Objectives and Key Results framework (Intel/Google)",
          technicalDetails: "Método ágil de desdobramento estratégico descentralizado (decoupling) de metas corporativas com alvos mensuráveis."
        };
      case "PROJETOS":
        default:
          return {
            title: "Projetos de Execução & Passos Práticos",
            businessExplanation: "As tarefas reais da semana! Aqui você divide as iniciativas estratégicas em passos com donos para garantir que os prazos não estourem.",
            whyItMatters: "Um plano de metas excelente sem planos de ação práticos é apenas uma lista de desejos de réveillon que nunca vai se realizar.",
            nextAction: "Defina pelo menos 3 tarefas concretas de checklists com responsáveis claros e datas definidas.",
            frameworkName: "Management Action Roadmaps & Work Breakdown Structure",
            technicalDetails: "Fracionamento de escopo técnico de desenvolvimento em entregas tangíveis e rastreabilidade direta síncrona."
          };
    }
  };

  const insight = getInsightMetadata();

  return (
    <div id="strategy-page-wrapper" className="space-y-6">
      
      {/* Upper header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-[#C49746]" />
            <h1 className="text-xl font-black text-slate-900 tracking-tight font-sans">
              🏆 Plano de Estratégia e Direcionamento
            </h1>
          </div>
          <p className="text-xs text-slate-500">
            {isSimpleMode(mode) 
              ? "Transforme desvios e ideias em metas práticas para toda a equipe saber o que fazer hoje." 
              : "Definição de objetivos BSC e conexões analíticas táticas via OKRs e planos de ação sistêmicos."}
          </p>
        </div>

        {/* Dynamic score summary indicator */}
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-150 p-2.5 rounded-lg text-left">
          <Target className="w-5 h-5 text-[#C49746]" />
          <div>
            <span className="text-[10px] font-mono font-bold text-slate-400 block uppercase">Metas em Andamento</span>
            <span className="text-xs font-black text-slate-900">
              {okrs.filter(o => o.status === "EM_ANDAMENTO").length} OKRs ativos • {initiatives.filter(i => i.status === "EM_EXECUCAO").length} Projetos
            </span>
          </div>
        </div>
      </div>

      {/* Main Core Layout Grid (Tabs Area vs Side Insight Compass Panel) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left 2 Column Blocks - Navigation tabs & content panels */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Navigation Tab list (Neumorphic styled tabs) */}
          <div className="flex bg-slate-100 p-1.5 rounded-xl border border-slate-200 overflow-x-auto text-xs font-mono font-bold scrollbar-none">
            
            <button
              type="button"
              onClick={() => setActiveTab("MAPA")}
              className={`flex-1 min-w-[125px] py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === "MAPA" 
                  ? "bg-white text-slate-950 shadow-xs border border-slate-200/50" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Map className="w-4 h-4 shrink-0" />
              <span>🗺️ Mapa Estrutural</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("BSC")}
              className={`flex-1 min-w-[125px] py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === "BSC" 
                  ? "bg-white text-slate-950 shadow-xs border border-slate-200/50" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Layers className="w-4 h-4 shrink-0" />
              <span>📊 Pilares BSC</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("OKRS")}
              className={`flex-1 min-w-[125px] py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === "OKRS" 
                  ? "bg-white text-slate-950 shadow-xs border border-slate-200/50" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Target className="w-4 h-4 shrink-0" />
              <span>🎯 Quadro de OKRs</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("PROJETOS")}
              className={`flex-1 min-w-[125px] py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === "PROJETOS" 
                  ? "bg-white text-slate-950 shadow-xs border border-slate-200/50" 
                  : "text-slate-500 hover:text-slate-850"
              }`}
            >
              <CheckSquare className="w-4 h-4 shrink-0" />
              <span>🚀 Projetos Executivos</span>
            </button>

          </div>

          {/* DYNAMIC WINDOW CONTENT SECTION */}
          <div className="transition-all duration-300">
            {activeTab === "MAPA" && (
              <StrategyMap
                mode={mode}
                onSelectObjective={(objId) => {
                  // Switch key tab to let user see indicators or goals
                  if (objId.includes("fin")) setActiveTab("BSC");
                  if (objId.includes("proc") || objId.includes("apr")) setActiveTab("PROJETOS");
                }}
              />
            )}

            {activeTab === "BSC" && (
              <BscPerspectiveCards
                mode={mode}
                onAddIndicator={(persKey) => {
                  console.log("Add indicator request for: ", persKey);
                  setActiveTab("OKRS"); // redirect to set goals or values
                }}
              />
            )}

            {activeTab === "OKRS" && (
              <OkrBoard
                okrs={okrs}
                mode={mode}
                onAddOkr={handleAddOkr}
                onUpdateOkrProgress={handleUpdateOkrProgress}
                onDeleteOkr={handleDeleteOkr}
                diagnosisGaps={detectedGaps}
              />
            )}

            {activeTab === "PROJETOS" && (
              <StrategicInitiatives
                initiatives={initiatives}
                mode={mode}
                onAddInitiative={handleAddInitiative}
                onToggleCheckItem={handleToggleCheckItem}
                onChangeStatus={handleChangeInitiativeStatus}
              />
            )}
          </div>

        </div>

        {/* Right side coaching guidance panel */}
        <div className="lg:sticky lg:top-4 space-y-6">
          <E3IInsightPanel
            title={insight.title}
            businessExplanation={insight.businessExplanation}
            whyItMatters={insight.whyItMatters}
            nextAction={insight.nextAction}
            frameworkName={insight.frameworkName}
            technicalDetails={insight.technicalDetails}
            mode={mode}
          />

          {/* Quick coaching info */}
          <div className="bg-slate-50 p-4 border border-slate-200 rounded-lg space-y-2 text-left">
            <h4 className="text-xs font-black uppercase text-[#C49746] tracking-wider flex items-center gap-1">
              <Lightbulb className="w-4 h-4 text-[#C49746]" /> Dica de Prática Ágil
            </h4>
            <p className="text-xs text-slate-655 leading-relaxed">
              Realize reuniões de alinhamento tático de **15 minutos semanais** para o time atualizar progresso e expor impedimentos nas iniciativas.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
