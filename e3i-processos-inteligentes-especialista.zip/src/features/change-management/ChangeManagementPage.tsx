import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Compass, 
  HelpCircle, 
  Anchor, 
  Activity, 
  Megaphone, 
  ShieldAlert, 
  Sparkles,
  Info
} from "lucide-react";
import KotterChecklist from "./KotterChecklist";
import AdkarAssessment from "./AdkarAssessment";
import CommunicationPlan from "./CommunicationPlan";
import ResistanceMap from "./ResistanceMap";

export interface ChangeManagementPageProps {
  mode: UsabilityMode;
  onNavigateToStep?: (stepId: string) => void;
}

type SubTab = "kotter" | "adkar" | "communication" | "resistance";

export default function ChangeManagementPage({
  mode,
  onNavigateToStep
}: ChangeManagementPageProps) {
  const isExpert = isExpertMode(mode);
  const [activeTab, setActiveTab] = useState<SubTab>("kotter");

  return (
    <div className="space-y-6 w-full text-slate-800 text-left">
      
      {/* 1. MODULE BANNER */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 md:p-8 relative overflow-hidden border border-slate-800 shadow-lg text-left">
        {/* Decorative background gradients */}
        <div className="absolute -left-16 -top-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute right-12 bottom-0 w-48 h-48 bg-[#C49746]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl space-y-4 relative z-10">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-gradient-to-br from-[#C49746] to-amber-700 rounded-xl shadow-md text-slate-950">
              <Compass className="w-5 h-5 text-white" />
            </span>
            <div>
              <span className="text-[10px] font-mono font-black text-amber-400 uppercase tracking-widest block">AÇÃO 11 — ENGAJAMENTO HUMANO</span>
              <h2 className="text-xl md:text-2xl font-serif font-black tracking-tight text-white leading-tight">
                {isExpert ? "Cultura Organizacional & Gestão da Mudança" : "Cultura e Facilitação da Mudança"}
              </h2>
            </div>
          </div>

          <p className="text-xs md:text-sm text-slate-350 leading-relaxed max-w-3xl">
            {isExpert
              ? "Sincronize as transformações com os frameworks internacionais Kotter e ADKAR. Planeje de modo preditivo os riscos de desengajamento, as resistências culturais nos canais de comunicação interna e garanta a sustentação duradoura."
              : "Ajude sua equipe a aceitar o novo ritmo de trabalho com tranquilidade. Use os questionários interativos para descobrir dificuldades, planejar as conversas coletivas e celebrar as metas atingidas."}
          </p>

          {/* Quick Stats Grid / Status badges */}
          <div className="flex flex-wrap items-center gap-2.5 pt-1 text-[11px] font-mono">
            <span className="bg-slate-800 border border-slate-700 px-2.5 py-0.5 rounded text-indigo-400 font-bold">
              Kotter 8 Passos
            </span>
            <span className="bg-slate-800 border border-slate-700 px-2.5 py-0.5 rounded text-amber-400 font-bold">
              ADKAR Engine
            </span>
            <span className="bg-[#C49746]/10 border border-[#C49746]/30 text-[#C49746] px-2.5 py-0.5 rounded font-black">
              ✓ Atividades Vinculadas
            </span>
          </div>
        </div>
      </div>

      {/* 2. SUBTAB CONTROLLER BUTTONS */}
      <div className="flex overflow-x-auto select-none border-b border-slate-200 bg-white p-1 rounded-xl shadow-xs gap-1">
        
        {/* Tab: Kotter Checklist */}
        <button
          onClick={() => setActiveTab("kotter")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "kotter" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Anchor className="w-4 h-4" />
          {isExpert ? "Kotter 8 Passos" : "Roteiro da Mudança (Kotter)"}
        </button>

        {/* Tab: ADKAR Assessment */}
        <button
          onClick={() => setActiveTab("adkar")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "adkar" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Activity className="w-4 h-4" />
          {isExpert ? "Avaliação ADKAR" : "Engajamento (ADKAR)"}
        </button>

        {/* Tab: Communication Plan */}
        <button
          onClick={() => setActiveTab("communication")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "communication" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Megaphone className="w-4 h-4" />
          {isExpert ? "Plano de Comunicação" : "Cronograma de Avisos"}
        </button>

        {/* Tab: Resistance Map */}
        <button
          onClick={() => setActiveTab("resistance")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "resistance" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          {isExpert ? "Mapa de Resistências" : "Medo & Resistência Cultural"}
        </button>

      </div>

      {/* 3. DYNAMIC CONTENT RENDERING */}
      <div className="space-y-6">
        {activeTab === "kotter" && (
          <div className="animate-fade-in">
            <KotterChecklist mode={mode} />
          </div>
        )}

        {activeTab === "adkar" && (
          <div className="animate-fade-in">
            <AdkarAssessment mode={mode} />
          </div>
        )}

        {activeTab === "communication" && (
          <div className="animate-fade-in">
            <CommunicationPlan mode={mode} />
          </div>
        )}

        {activeTab === "resistance" && (
          <div className="animate-fade-in">
            <ResistanceMap mode={mode} />
          </div>
        )}
      </div>

    </div>
  );
}
