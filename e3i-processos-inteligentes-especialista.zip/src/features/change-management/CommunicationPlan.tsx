import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  Megaphone, 
  Plus, 
  Trash2, 
  Check, 
  Calendar, 
  Users, 
  Mail, 
  HelpCircle,
  FileText,
  Clock,
  Sparkles
} from "lucide-react";

export interface CommPlanItem {
  id: string;
  actionName: string;
  audienceSimple: string;
  audienceTechnical: string;
  channelSimple: string;
  channelTechnical: string;
  frequency: string;
  responsible: string;
  status: "planejado" | "concluido" | "em_andamento";
}

export interface CommunicationPlanProps {
  mode: UsabilityMode;
}

const INITIAL_PLAN: CommPlanItem[] = [
  {
    id: "comm_1",
    actionName: "Reunião de Alinhamento da Nova Rotina Comercial",
    audienceSimple: "Todos os Vendedores",
    audienceTechnical: "Front-Line Sales Representatives & Commercial Crew",
    channelSimple: "Reunião Presencial (10 min diários)",
    channelTechnical: "Daily Stand-up Synchronous Session",
    frequency: "Diário",
    responsible: "Gerente Comercial",
    status: "concluido"
  },
  {
    id: "comm_2",
    actionName: "Vídeo Tutorial - Como Usar a Nova Planilha de Estoque",
    audienceSimple: "Pessoal do Galpão e Compras",
    audienceTechnical: "Warehouse Clerks & Procurement Specialists",
    channelSimple: "Link do YouTube compartilhado no Whatsapp",
    channelTechnical: "Asynchronous Screen-cast & Tutorial SOP Asset",
    frequency: "Única vez",
    responsible: "Líder de Operações",
    status: "em_andamento"
  },
  {
    id: "comm_3",
    actionName: "Relatório Mensal de Metas Batidas com o Processo LSS",
    audienceSimple: "Toda a equipe da empresa",
    audienceTechnical: "All Hands stakeholders & Sponsors",
    channelSimple: "Mural da Copa e E-mail Geral",
    channelTechnical: "E-mail broadcast & Physical Office Dashboard",
    frequency: "Mensal",
    responsible: "Dono da Empresa",
    status: "planejado"
  }
];

export default function CommunicationPlan({
  mode
}: CommunicationPlanProps) {
  const isExpert = isExpertMode(mode);
  const [plan, setPlan] = useState<CommPlanItem[]>(INITIAL_PLAN);

  // New action form state
  const [actionName, setActionName] = useState("");
  const [audience, setAudience] = useState("");
  const [channel, setChannel] = useState("");
  const [freq, setFreq] = useState("Única vez");
  const [resp, setResp] = useState("");

  const handleAddPlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionName.trim()) return;

    const newItem: CommPlanItem = {
      id: `comm_${Date.now()}`,
      actionName,
      audienceSimple: audience || "Toda a empresa",
      audienceTechnical: audience || "Full Internal Stakeholders",
      channelSimple: channel || "E-mail / Whatsapp",
      channelTechnical: channel || "Omnichannel standard Slack",
      frequency: freq,
      responsible: resp || "Líder do Projeto",
      status: "planejado"
    };

    setPlan([...plan, newItem]);
    setActionName("");
    setAudience("");
    setChannel("");
    setResp("");
  };

  const handleToggleStatus = (id: string) => {
    setPlan(plan.map(item => {
      if (item.id === id) {
        const nextStatus: CommPlanItem["status"] = 
          item.status === "planejado" ? "em_andamento" :
          item.status === "em_andamento" ? "concluido" : "planejado";

        return { ...item, status: nextStatus };
      }
      return item;
    }));
  };

  const handleDelete = (id: string) => {
    setPlan(plan.filter(i => i.id !== id));
  };

  return (
    <div id="comm-plan-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Plano Estratégico de Comunicação Organizacional" : "Tabela do Plano de Comunicação"}
          </h3>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Assegure que os canais de informação permaneçam integrados e que nenhum setor chave sofra com escassez de dados durante os marcos de sprint." 
              : "Defina de forma organizada quem vai receber informações sobre a mudança, qual dia e qual canal."}
          </p>
        </div>

        <span className="text-[10px] font-mono bg-amber-50 border border-amber-200 text-amber-800 px-2.5 py-1 rounded font-black uppercase">
          COMMUNICATION FLOWMAP
        </span>
      </div>

      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4" /> Dica de Prato de Comunicação:
          </span>
          <p className="text-xs text-slate-650 leading-relaxed">
            Se as pessoas não souberem o que está mudando e qual o progresso da empresa, elas assumem que o projeto deu errado e voltam para o jeito antigo. Escreva pelo menos 2 comunicados simples por semana.
          </p>
        </div>
      )}

      {/* QUICK INLINE PLAN MAKER FORM */}
      <form onSubmit={handleAddPlan} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3.5">
        <span className="text-[10px] font-mono font-black text-slate-500 uppercase tracking-wider block">
          Agendar Comunicado ou Ação de Engajamento
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="md:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Nome da Ação</label>
            <input 
              type="text" 
              required
              placeholder="Ex: Treinamento prático do ERP com simulação..."
              value={actionName}
              onChange={e => setActionName(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Para Quem? (Público-alvo)</label>
            <input 
              type="text" 
              placeholder="Ex: Todos os vendedores"
              value={audience}
              onChange={e => setAudience(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Como enviar? (Canal)</label>
            <input 
              type="text" 
              placeholder="Ex: Encontro diário 10min"
              value={channel}
              onChange={e => setChannel(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Frequência</label>
            <select 
              value={freq}
              onChange={e => setFreq(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            >
              <option value="Única vez">Única vez</option>
              <option value="Diário">Diário</option>
              <option value="Semanal">Semanal</option>
              <option value="Quinzenal">Quinzenal</option>
              <option value="Mensal">Mensal</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Quem envia? (Responsável)</label>
            <input 
              type="text" 
              placeholder="Ex: Gerente Geral"
              value={resp}
              onChange={e => setResp(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div className="flex items-end justify-end md:col-span-2">
            <button
              type="submit"
              className="w-full md:w-auto px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-lg h-[38px] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Adicionar Ação
            </button>
          </div>
        </div>
      </form>

      {/* PLAN GRID RENDER */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plan.map((item) => (
          <div 
            key={item.id}
            className="border border-slate-200.5 bg-slate-50/40 rounded-xl p-4.5 space-y-4 hover:border-amber-200/80 transition-colors flex flex-col justify-between"
          >
            <div className="space-y-2.5">
              
              {/* Header inside item */}
              <div className="flex items-start justify-between gap-1">
                <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded cursor-pointer ${
                  item.status === "concluido" ? "bg-emerald-100 text-emerald-800 border border-emerald-200" :
                  item.status === "em_andamento" ? "bg-blue-100 text-blue-800 border border-blue-200" :
                  "bg-slate-200 text-slate-650 border border-slate-300"
                }`}
                onClick={() => handleToggleStatus(item.id)}
                title="Clique para mudar status"
                >
                  ● {item.status.replace("_", " ")}
                </span>

                <button 
                  onClick={() => handleDelete(item.id)}
                  className="text-slate-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Title Action */}
              <h4 className="text-xs font-black text-slate-950 leading-snug">
                {item.actionName}
              </h4>

              {/* Specs block */}
              <div className="space-y-1.5 pt-2 text-[11px] text-slate-650">
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span><b>Público:</b> {isExpert ? item.audienceTechnical : item.audienceSimple}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span><b>Canal:</b> {isExpert ? item.channelTechnical : item.channelSimple}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span><b>Frequência:</b> {item.frequency}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span><b>Remetente:</b> {item.responsible}</span>
                </div>
              </div>

            </div>

            {/* Change progress quick triggers */}
            <div className="pt-3 border-t border-dashed border-slate-200 mt-2 flex items-center justify-between">
              <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Ações do Gestor</span>
              <button
                onClick={() => handleToggleStatus(item.id)}
                className="text-[9.5px] font-sans font-extrabold text-[#C49746] hover:underline flex items-center gap-1 cursor-pointer"
              >
                Mudar Status <Check className="w-3 h-3" />
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
