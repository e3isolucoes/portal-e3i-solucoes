import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  ShieldAlert, 
  HelpCircle, 
  Users, 
  Trash2, 
  Plus, 
  Sparkles, 
  TrendingDown, 
  ThumbsUp, 
  Lightbulb, 
  MessageSquare,
  ShieldAlert as AlertIcon
} from "lucide-react";

export interface StakeholderItem {
  id: string;
  name: string;
  roleSimple: string;
  roleTechnical: string;
  disposition: "promotor" | "neutro" | "passivo_resistente" | "detrator_ativo";
  influence: "alta" | "media" | "baixa";
  cultureRiskSimple: string;
  cultureRiskTechnical: string;
  sustainingActionSimple: string;
  sustainingActionTechnical: string;
}

export interface ResistanceMapProps {
  mode: UsabilityMode;
}

const INITIAL_STAKEHOLDERS: StakeholderItem[] = [
  {
    id: "stk_1",
    name: "Líder Financeiro",
    roleSimple: "Auxiliar que paga as contas",
    roleTechnical: "Senior Accounts Payable Clerk",
    disposition: "passivo_resistente",
    influence: "media",
    cultureRiskSimple: "Medo de o novo processo expor erros de digitação antigos que ele cometia sozinho.",
    cultureRiskTechnical: "Receio de perda de controle operacional exclusivo sobre os lançamentos manuais no ERP.",
    sustainingActionSimple: "Fazer uma reunião amigável para esclarecer que o foco não é punir erros do passado, mas sim evitar retrabalho no futuro.",
    sustainingActionTechnical: "Oferecer feedback confidencial construtivo, alocar suporte preventivo temporário e pactuar metas individuais motivadoras."
  },
  {
    id: "stk_2",
    name: "Gerente Geral de Vendas",
    roleSimple: "Chefe dos vendedores",
    roleTechnical: "Chief of Commercial Operations",
    disposition: "promotor",
    influence: "alta",
    cultureRiskSimple: "Nenhum risco relevante. Ele quer agilidade no cadastro para receber comissões mais rápido.",
    cultureRiskTechnical: "Inexistente. Altamente incentivado por performance de lead conversion rate e velocidade transacional.",
    sustainingActionSimple: "Dar a ele o papel de líder motivador nas apresentações gerais da Black Friday.",
    sustainingActionTechnical: "Empoderá-lo como 'Change Champion' na comissão executiva institucional do projeto."
  },
  {
    id: "stk_3",
    name: "Vendedor Sênior (Antigo de Casa)",
    roleSimple: "Vendedor com mais clientes",
    roleTechnical: "Key Account Manager & Legacy Seller",
    disposition: "detrator_ativo",
    influence: "alta",
    cultureRiskSimple: "Acha que 'sempre foi feito assim' e que novos controles só servem para tirar a liberdade dele trabalhar.",
    cultureRiskTechnical: "Entrincheiramento metodológico. Percepção de microgerenciamento e redução de flexibilidade discricionária de margens.",
    sustainingActionSimple: "Pedir sugestões para ele sobre o novo modelo de vendas e dar um bônus especial caso ele ajude a treinar os novatos.",
    sustainingActionTechnical: "Alocá-lo formalmente na concepção dos novos SLAs de desconto e oferecer bônus de co-liderança de projeto."
  },
  {
    id: "stk_4",
    name: "Estoquista Geral",
    roleSimple: "Quem arruma as caixas",
    roleTechnical: "Inventory Logistical Operator",
    disposition: "neutro",
    influence: "baixa",
    cultureRiskSimple: "Acha que a planilha nova só vai dar mais trabalho para digitar produtos todo fim do expediente.",
    cultureRiskTechnical: "Fadiga de processo. Percepção de burocratização redundante sem ganho de produtividade visível.",
    sustainingActionSimple: "Demonstrar na prática que o novo celular de inventário economiza 2 horas de suor por dia.",
    sustainingActionTechnical: "Fornecer hardware de digitação rápida e estipular horas de trabalho protegidas para registros."
  }
];

export default function ResistanceMap({
  mode
}: ResistanceMapProps) {
  const isExpert = isExpertMode(mode);
  const [stakeholders, setStakeholders] = useState<StakeholderItem[]>(INITIAL_STAKEHOLDERS);

  // Form states
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [disposition, setDisposition] = useState<StakeholderItem["disposition"]>("neutro");
  const [influence, setInfluence] = useState<StakeholderItem["influence"]>("media");
  const [risk, setRisk] = useState("");
  const [act, setAct] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newItem: StakeholderItem = {
      id: `stk_${Date.now()}`,
      name,
      roleSimple: role || "Funcionário",
      roleTechnical: role || "Functional Specialist",
      disposition,
      influence,
      cultureRiskSimple: risk || "Preocupado com aumento de digitação.",
      cultureRiskTechnical: risk || "Inadequação cultural primária.",
      sustainingActionSimple: act || "Dar treinamento extra focado nas maiores preocupações dele.",
      sustainingActionTechnical: act || "Customized training & coaching sprint session."
    };

    setStakeholders([...stakeholders, newItem]);
    setName("");
    setRole("");
    setRisk("");
    setAct("");
  };

  const handleDelete = (id: string) => {
    setStakeholders(stakeholders.filter(s => s.id !== id));
  };

  return (
    <div id="resistance-map-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-600" /> 
            {isExpert ? "Mapa de Resistência Cultural & Stakeholders" : "Quem Pode Resistir ou Apoiar a Mudança?"}
          </h3>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Identifique os pontos focais de inércia organizativa. Elabore de modo dirigido planos preventivos de engajamento e sustentação." 
              : "Veja quem da sua equipe está inseguro, neutro ou feliz com as novidades da empresa para tratar as dores deles com paciência."}
          </p>
        </div>

        <span className="text-[10px] font-mono bg-red-50 border border-red-200 text-red-700 px-2.5 py-1 rounded font-black uppercase">
          STAKEHOLDERS MAP
        </span>
      </div>

      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4" /> Dica de Liderança Humana:
          </span>
          <p className="text-xs text-slate-650 leading-relaxed">
            As pessoas não resistem à mudança por maldade, e sim por <b>medo</b> de perder o emprego, de parecerem incompetentes aprendendo coisas novas, ou por cansaço da rotina. Identifique quem está assustado e ajude!
          </p>
        </div>
      )}

      {/* NEW STAKEHOLDER FORM */}
      <form onSubmit={handleAdd} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3.5">
        <span className="text-[10px] font-mono font-black text-slate-500 uppercase tracking-widest block">
          Adicionar Stakeholder ao Mapa de Resistência
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Nome</label>
            <input 
              type="text" 
              required
              placeholder="Ex: Carlos Oliveira..."
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Cargo</label>
            <input 
              type="text" 
              placeholder="Ex: Auxiliar de Expedição"
              value={role}
              onChange={e => setRole(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Comportamento Principal</label>
            <select 
              value={disposition}
              onChange={e => setDisposition(e.target.value as StakeholderItem["disposition"])}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            >
              <option value="promotor">Promotor (Apoiador entusiasta)</option>
              <option value="neutro">Neutro (Observando com paciência)</option>
              <option value="passivo_resistente">Passivo Resistente (Em silêncio, mas não faz)</option>
              <option value="detrator_ativo">Detrator Ativo (Critica e boicota o plano)</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Influência Interna</label>
            <select 
              value={influence}
              onChange={e => setInfluence(e.target.value as StakeholderItem["influence"])}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            >
              <option value="alta">Alta (Líder informal que o time escuta)</option>
              <option value="media">Média (Opinião razoável)</option>
              <option value="baixa">Baixa (Não dita os comportamentos)</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Qual o medo dele? (Risco Cultural)</label>
            <input 
              type="text" 
              placeholder="Ex: Medo de não conseguir usar o celular do estoque"
              value={risk}
              onChange={e => setRisk(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono mb-1">Plano de Apoio (Ação de Sustentação)</label>
            <input 
              type="text" 
              placeholder="Ex: Colocar um padrinho experiente do lado dele"
              value={act}
              onChange={e => setAct(e.target.value)}
              className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
            />
          </div>
        </div>
        
        <div className="flex items-center justify-end">
          <button
            type="submit"
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-lg h-[38px] transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Cadastrar Stakeholder
          </button>
        </div>
      </form>

      {/* RENDER TABLE OF RESISTANCE AND ENGAGEMENT OUTCOMES */}
      <div className="overflow-x-auto border border-slate-150 rounded-xl shadow-3xs max-w-full">
        <table className="w-full text-xs border-collapse bg-white">
          <thead>
            <tr className="bg-slate-900 text-slate-100 font-mono tracking-wider font-extrabold uppercase border-b border-slate-800 text-left">
              <th className="p-3 pl-4">Nome / Papel</th>
              <th className="p-3">Comportamento</th>
              <th className="p-3">Influência</th>
              <th className="p-3">Risco Cultural de Resistência</th>
              <th className="p-3">Ação de Sustentação / Engajamento</th>
              <th className="p-3 text-center">Remover</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-medium">
            {stakeholders.map((stk) => {
              
              // Custom style variables depending on behavior type
              const behaviorColors = 
                stk.disposition === "promotor" ? "bg-emerald-100 text-emerald-800 border-emerald-250" :
                stk.disposition === "neutro" ? "bg-blue-50 border-blue-200 text-blue-800" :
                stk.disposition === "passivo_resistente" ? "bg-amber-100 text-[#7C5A14] border-amber-200/80" :
                "bg-red-100 text-red-800 border-red-200";

              return (
                <tr key={stk.id} className="hover:bg-slate-50/50">
                  {/* Name and role */}
                  <td className="p-3.5 pl-4 font-black text-[#1a1b1F]">
                    <div>{stk.name}</div>
                    <div className="text-[10px] text-slate-450 font-mono mt-0.5 uppercase">
                      {isExpert ? stk.roleTechnical : stk.roleSimple}
                    </div>
                  </td>

                  {/* Disposition badge */}
                  <td className="p-3">
                    <span className={`text-[10.5px] px-2 py-0.5 rounded border ${behaviorColors} font-bold`}>
                      {stk.disposition.replace("_", " ")}
                    </span>
                  </td>

                  {/* Influence level */}
                  <td className="p-3">
                    <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      stk.influence === "alta" ? "bg-red-50 text-red-700 font-black border border-red-150" :
                      stk.influence === "media" ? "bg-amber-50 text-amber-800 border border-amber-150" :
                      "bg-slate-100 text-slate-500"
                    }`}>
                      {stk.influence}
                    </span>
                  </td>

                  {/* Culture Risk */}
                  <td className="p-3 text-slate-700 max-w-xs leading-relaxed font-sans">
                    {isExpert ? stk.cultureRiskTechnical : stk.cultureRiskSimple}
                  </td>

                  {/* Sustaining Actions */}
                  <td className="p-3 max-w-sm">
                    <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-2.5 text-xs text-[#7C5A14] font-medium leading-relaxed">
                      <span className="text-[9px] font-mono font-bold uppercase tracking-wider block text-slate-450">Como contornar:</span>
                      <p className="mt-0.5 text-slate-800">
                        {isExpert ? stk.sustainingActionTechnical : stk.sustainingActionSimple}
                      </p>
                    </div>
                  </td>

                  {/* Action delete */}
                  <td className="p-3 text-center">
                    <button 
                      onClick={() => handleDelete(stk.id)}
                      className="p-1 text-slate-400 hover:text-red-500 transition-colors"
                      title="Excluir"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>

                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

    </div>
  );
}
