import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  CheckSquare, 
  HelpCircle, 
  TrendingUp, 
  Award, 
  Flame, 
  Users, 
  Megaphone, 
  Zap, 
  Anchor
} from "lucide-react";

export interface KotterStep {
  stepNumber: number;
  titleSimple: string;
  titleTechnical: string;
  questionSimple: string;
  questionTechnical: string;
  tipsSimple: string;
  tipsTechnical: string;
  icon: React.ReactNode;
}

export interface KotterChecklistProps {
  mode: UsabilityMode;
}

export default function KotterChecklist({
  mode
}: KotterChecklistProps) {
  const isExpert = isExpertMode(mode);

  // Kotter Steps definitions
  const steps: KotterStep[] = [
    {
      stepNumber: 1,
      titleSimple: "Criar senso de urgência",
      titleTechnical: "Establishing a Sense of Urgency",
      questionSimple: "Existe urgência real? As pessoas entendem por que precisamos mudar hoje e não amanhã?",
      questionTechnical: "Existe uma queima de plataforma (burning platform) com fatos econômicos que valide a necessidade imediata da mudança?",
      tipsSimple: "Apresente números concretos de reclamações de clientes ou perdas financeiras para mobilizar o time.",
      tipsTechnical: "Apresentar análise competitiva exógena, gargalos de margem EBITDA e indicadores de descontinuidade tática.",
      icon: <Flame className="w-5 h-5 text-red-500" />
    },
    {
      stepNumber: 2,
      titleSimple: "Montar grupo de liderança",
      titleTechnical: "Creating the Guiding Coalition",
      questionSimple: "A alta liderança apoia o projeto? Temos influenciadores internos engajados?",
      questionTechnical: "Temos um comitê de patrocinadores executivos (change agents) com capital político para neutralizar resistências?",
      tipsSimple: "Traga pessoas-chave de diferentes setores da empresa para apoiar a iniciativa.",
      tipsTechnical: "Estruturar coalizão multidisciplinar de C-level, Black Belts operacionais e influenciadores formadores de opinião.",
      icon: <Users className="w-5 h-5 text-blue-500" />
    },
    {
      stepNumber: 3,
      titleSimple: "Criar uma visão de futuro",
      titleTechnical: "Developing a Vision and Strategy",
      questionSimple: "O time sabe exatamente onde queremos chegar com essa alteração?",
      questionTechnical: "A visão de estado futuro (to-be) possui formulação clara, aspiracional e mensurável por OKRs?",
      tipsSimple: "Explique como o trabalho de todos facilitará quando o novo processo estiver operando.",
      tipsTechnical: "Definir metas tangíveis de redução de Lead Time, aumento de qualidade e melhora da experiência do cliente.",
      icon: <TrendingUp className="w-5 h-5 text-emerald-500" />
    },
    {
      stepNumber: 4,
      titleSimple: "Comunicar a visão para todos",
      titleTechnical: "Communicating the Change Vision",
      questionSimple: "Existe um plano de comunicação contínuo? Falamos sobre isso em todas as reuniões?",
      questionTechnical: "Os rumos estratégicos estão sendo propagados em múltiplos canais de comunicação interna (ombroadcasting)?",
      tipsSimple: "Use cartazes, canais de chat, e-mails e reuniões rápidas de balcão para relembrar as mudanças.",
      tipsTechnical: "Criar ritmo de comunicação integrado (alignment pulse) de 15 em 15 dias minimizando ruídos informacionais.",
      icon: <Megaphone className="w-5 h-5 text-purple-500" />
    },
    {
      stepNumber: 5,
      titleSimple: "Remover barreiras e dar autonomia",
      titleTechnical: "Empowering Employees for Broad-Based Action",
      questionSimple: "Demos ferramentas e treinamento para as pessoas trabalharem sem medo de errar?",
      questionTechnical: "Os sistemas, incentivos funcionais e restrições burocráticas foram reconfigurados para impulsionar a adoção?",
      tipsSimple: "Treine quem tem dificuldade no novo sistema e facilite o acesso às telas relevantes do ERP.",
      tipsTechnical: "Desativar gatilhos antigos de retrabalho, atualizar descrições de cargo na matriz RACI e reciclar a equipe.",
      icon: <Zap className="w-5 h-5 text-amber-500" />
    },
    {
      stepNumber: 6,
      titleSimple: "Garantir vitórias de curto prazo",
      titleTechnical: "Generating Short-Term Wins",
      questionSimple: "Comemoramos pequenas metas batidas na primeira semana para motivar as pessoas?",
      questionTechnical: "Temos marcos de execução definidos (quick-wins) para legitimar a transformação na primeira fase?",
      tipsSimple: "Elogie publicamente quem bateu a meta de cadastros com o novo formulário mais rápido.",
      tipsTechnical: "Mapear retornos rápidos e ganhos financeiros perceptíveis nos primeiros 30 dias para calar detratores.",
      icon: <Award className="w-5 h-5 text-[#C49746]" />
    },
    {
      stepNumber: 7,
      titleSimple: "Não relaxar antes do final",
      titleTechnical: "Consolidating Gains and Producing More Change",
      questionSimple: "Continuamos medindo os dados de erro para garantir que velhos hábitos não voltem?",
      questionTechnical: "As melhorias do processo estão retroalimentando novos projetos de melhoria contínua (DMAIC)?",
      tipsSimple: "Não ache que o problema sumiu só porque deu certo uma vez. Acompanhe as metas por 3 meses.",
      tipsTechnical: "Evitar a fadiga de mudança declarando vitória prematuramente; usar as melhorias como alavanca de expansão.",
      icon: <CheckSquare className="w-5 h-5 text-teal-500" />
    },
    {
      stepNumber: 8,
      titleSimple: "Tornar a mudança parte da rotina",
      titleTechnical: "Anchoring New Approaches in the Culture",
      questionSimple: "A mudança virou padrão e foi documentada? As pessoas já fazem sem precisar de cobrança?",
      questionTechnical: "A nova prática operacional foi institucionalizada, auditada em rotinas diárias (SDA/SDCA)?",
      tipsSimple: "Grave tutoriais em vídeo, imprima cartilhas visuais e faça parte do treinamento de novatos.",
      tipsTechnical: "Criação de novos padrões formais de trabalho (SOP), relatórios de auditoria e vinculação ao plano de metas diário.",
      icon: <Anchor className="w-5 h-5 text-indigo-500" />
    }
  ];

  const [completedSteps, setCompletedSteps] = useState<number[]>([1, 2]);

  const toggleStep = (stepNumber: number) => {
    if (completedSteps.includes(stepNumber)) {
      setCompletedSteps(completedSteps.filter(s => s !== stepNumber));
    } else {
      setCompletedSteps([...completedSteps, stepNumber]);
    }
  };

  const calculateProgress = () => {
    return Math.round((completedSteps.length / steps.length) * 100);
  };

  return (
    <div id="kotter-checklist-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Anchor className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Análise Diagnóstica: Kotter 8 Passos para Mudança" : "Checklist dos 8 Passos da Mudança Saudável"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Metodologia clássica de John Kotter para gerenciar o processo adaptativo e mitigar o declínio de desempenho associado à transição." 
              : "Siga este roteiro certificado para garantir que seus novos métodos de trabalho sejam aceitos sem estresse na equipe."}
          </p>
        </div>

        {/* Progress percent circle */}
        <div className="flex items-center gap-2.5 bg-slate-50 border border-slate-150 px-3.5 py-1.5 rounded-xl">
          <div className="text-right shrink-0">
            <span className="text-[10px] font-mono font-bold text-slate-450 uppercase block">Adoção Kotter</span>
            <span className="text-sm font-mono font-black text-slate-900">{calculateProgress()}% Concluído</span>
          </div>
          <div className="w-2.5 h-10 bg-slate-200 rounded-full overflow-hidden relative">
            <div 
              className="bg-[#C49746] absolute bottom-0 left-0 right-0 transition-all duration-500" 
              style={{ height: `${calculateProgress()}%` }}
            />
          </div>
        </div>
      </div>

      {/* SIMPLE MODE QUESTIONS GRID UNDER TITLE */}
      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4" /> Principais Perguntas de Cultura Mapeadas:
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-xs text-slate-650">
            <div>• <b>Existe urgência clara?</b> (Passo 1)</div>
            <div>• <b>A liderança apoia o projeto?</b> (Passo 2)</div>
            <div>• <b>O time entendeu o motivo?</b> (Passo 3 e 4)</div>
            <div>• <b>As pessoas foram treinadas?</b> (Passo 5)</div>
            <div>• <b>A mudança entrou na rotina?</b> (Passo 8)</div>
          </div>
        </div>
      )}

      {/* RENDER CHRONOLOGICAL STEPS GROUP */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {steps.map((step) => {
          const isDone = completedSteps.includes(step.stepNumber);
          return (
            <div 
              key={step.stepNumber}
              onClick={() => toggleStep(step.stepNumber)}
              className={`border rounded-xl p-4 cursor-pointer select-none transition-all flex items-start gap-4 hover:border-[#C49746]/60 hover:shadow-2xs ${
                isDone ? "bg-slate-50/70 border-slate-200 opacity-90" : "bg-white border-slate-250"
              }`}
            >
              {/* Checkbox circle & step index */}
              <div className="shrink-0 flex flex-col items-center gap-1.5 mt-0.5">
                <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors ${
                  isDone ? "bg-[#C49746] text-white border-[#C49746]" : "bg-white border-slate-300 text-transparent"
                }`}>
                  <span className="text-[11px] font-mono font-bold">✓</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400 font-extrabold">ETAPA {step.stepNumber}</span>
              </div>

              {/* Step info details */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="p-1 bg-slate-100 border border-slate-200 rounded">
                    {step.icon}
                  </div>
                  <h4 className={`text-xs font-black uppercase tracking-wide ${isDone ? "text-slate-500 line-through" : "text-slate-900"}`}>
                    {isExpert ? step.titleTechnical : step.titleSimple}
                  </h4>
                </div>

                <p className="text-xs text-slate-700 font-medium leading-relaxed">
                  <b>Foco Atual:</b> {isExpert ? step.questionTechnical : step.questionSimple}
                </p>

                {/* Practical recommendation visual pill */}
                <div className="bg-slate-100/60 border border-slate-200 p-2.5 rounded-lg text-[11px] leading-normal text-slate-550">
                  <span className="font-bold text-[#C49746] text-[10px] font-mono uppercase block">⚡ Dica para ação:</span>
                  {isExpert ? step.tipsTechnical : step.tipsSimple}
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
