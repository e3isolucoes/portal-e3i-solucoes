import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  Building, 
  HelpCircle, 
  Settings, 
  Sparkles, 
  Activity, 
  Heart, 
  Flame, 
  Lightbulb, 
  MessageSquare, 
  GraduationCap, 
  CheckSquare, 
  TrendingUp, 
  Zap 
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface AdkarDimension {
  id: "awareness" | "desire" | "knowledge" | "ability" | "reinforcement";
  titleSimple: string;
  titleTechnical: string;
  definitionSimple: string;
  definitionTechnical: string;
  questionSimple: string;
  questionTechnical: string;
  score: number;
}

export interface AdkarAssessmentProps {
  mode: UsabilityMode;
}

export default function AdkarAssessment({
  mode
}: AdkarAssessmentProps) {
  const isExpert = isExpertMode(mode);

  const [dimensions, setDimensions] = useState<AdkarDimension[]>([
    {
      id: "awareness",
      titleSimple: "A — Consciência da Mudança",
      titleTechnical: "Awareness of the Need for Change",
      definitionSimple: "Saber o motivo real por trás desse novo procedimento.",
      definitionTechnical: "Nível de compreensão acerca dos gatilhos competitivos ou dores de margem que exigem a transformação.",
      questionSimple: "O colaborador sabe por que a empresa precisa mudar?",
      questionTechnical: "A força de trabalho entende os impactos sistêmicos caso este processo não seja otimizado de imediato?",
      score: 4
    },
    {
      id: "desire",
      titleSimple: "D — Desejo de Participar",
      titleTechnical: "Desire to Support the Change",
      definitionSimple: "Querer fazer parte e apoiar a novidade sem boicotar.",
      definitionTechnical: "Disposição individual e tática para apoiar, contribuir e participar das atividades do novo formato.",
      questionSimple: "As pessoas querem mudar e estão animadas ou neutras?",
      questionTechnical: "Há predisposição interna à adoção ou temos focos velados de inércia e boicote?",
      score: 2 // Barrier point example
    },
    {
      id: "knowledge",
      titleSimple: "K — Conhecimento de Como Mudar",
      titleTechnical: "Knowledge on How to Change",
      definitionSimple: "Saber os passos técnicos e as regras dos novos sistemas.",
      definitionTechnical: "Absorção de procedimentos operacionais padrão (SOP), políticas e capacitações de ferramenta.",
      questionSimple: "Eles receberam instruções claras detalhadas ou manuais?",
      questionTechnical: "A curva de aprendizado técnico está embasada por treinamentos formais e rotinas piloto?",
      score: 3
    },
    {
      id: "ability",
      titleSimple: "A — Habilidade Prática",
      titleTechnical: "Ability to Implement New Skills",
      definitionSimple: "Conseguir fazer a tarefa no dia a dia sem travar ou errar.",
      definitionTechnical: "Capacidade prática de converter conhecimentos teóricos em entregas diárias com agilidade e qualidade.",
      questionSimple: "Os funcionários têm tempo e capacidade de executar o processo hoje?",
      questionTechnical: "Há suporte operacional diário (coaching, ajuda local) para assegurar a execução sem gargalos?",
      score: 3
    },
    {
      id: "reinforcement",
      titleSimple: "R — Reforço Sustentável",
      titleTechnical: "Reinforcement to Sustain the Change",
      definitionSimple: "Reconhecimento e cobrança para que o hábito não se perca.",
      definitionTechnical: "Mecanismos formais de governança e premiação que coíbam o retorno às práticas ineficientes anteriores.",
      questionSimple: "Existe fiscalização e prêmio para quem faz tudo certo?",
      questionTechnical: "Temos feedback loop ativo, auditoria de desvios e celebração de marcos estruturais consolidados?",
      score: 3
    }
  ]);

  const handleScoreChange = (id: string, newScore: number) => {
    setDimensions(dimensions.map(dim => {
      if (dim.id === id) {
        return { ...dim, score: newScore };
      }
      return dim;
    }));
  };

  // ADKAR Theory: The first dimension with a score of 3 or less is the "Barrier Point"
  const getBarrierPoint = () => {
    return dimensions.find(dim => dim.score <= 3);
  };

  const barrier = getBarrierPoint();

  // Create chart data compatibility
  const chartData = dimensions.map(dim => ({
    name: dim.id.toUpperCase(),
    Score: dim.score,
    title: isExpert ? dim.titleTechnical : dim.titleSimple
  }));

  // Advisory generator based on barrier point
  const getBarrierAdvisory = (barrierId: string) => {
    switch (barrierId) {
      case "awareness":
        return {
          simple: "Foque em explicar a crise atual ou a oportunidade perdida. Sem saber o porquê, as pessoas sentem que a mudança é apenas capricho da diretoria.",
          technical: "Recomenda-se realizar reuniões gerais (All Hands) com fatos econômicos brutos. Divulgue as reclamações de clientes de forma transparente e as perdas de faturamento."
        };
      case "desire":
        return {
          simple: "Abra espaço para ouvir as queixas sem punição. Entenda o medo de perder poder, status ou sofrer com sobrecarga por conta do novo modelo.",
          technical: "Ative a coalizão de lideranças para alinhamento 1v1. Ajuste os incentivos anuais, bônus operacionais e trate as objeções explícitas de chefes de área."
        };
      case "knowledge":
        return {
          simple: "Hora de Treinamento! Não adianta apenas pedir para fazer se eles não sabem os botões do sistema de cor. Faça simulações sem valor real.",
          technical: "Gerar plano de capacitação sob demanda, cartilhas interativas rápidas por canal do Slack/Teams e criar sandbox de homologação de dados."
        };
      case "ability":
        return {
          simple: "Eles já sabem a teoria mas estão sem tempo ou errando por pressão. Reduza as metas normais por 10 dias para que peguem ritmo.",
          technical: "Identifique gargalos de banda de staff. Coloque um facilitador (Sponsor ou Lean Black Belt) próximo às mesas na primeira semana como suporte hands-on."
        };
      case "reinforcement":
        return {
          simple: "Crie campanhas de metas e prêmios imediatos. Corrija na hora quem tentar voltar aos métodos antigos e desative de vez a planilha velha.",
          technical: "Desativar acessos permanentes a banco de dados antigos, incluir KPIs de conformidade do processo no scorecard mensal corporativo."
        };
      default:
        return {
          simple: "Continue acompanhando os indicadores diários de faturamento e engajamento da equipe.",
          technical: "Mapear o desbravamento sustentável e retroalimentar novos ciclos de auditoria (DMAIC)."
        };
    }
  };

  return (
    <div id="adkar-assessment-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Diagnóstico de Resistência - Modelo ADKAR da Prosci" : "Régua ADKAR de Engajamento Humano"}
          </h3>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Identifique numericamente em qual estágio cognitivo da mudança o seu time parou. O menor nível acumulado é chamado de 'Ponto de Barreiras'." 
              : "Veja as notas de engajamento do seu time para descobrir quem está apoiando e quem está com medo ou sem saber o que fazer."}
          </p>
        </div>

        <span className="text-[10px] font-mono bg-indigo-50 border border-indigo-200 text-indigo-750 px-2.5 py-1 rounded font-black uppercase">
          PROSCI ADKAR ENGINE
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* INTERACTIVE SCORING SLIDERS COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <span className="text-[10px] font-mono font-black text-slate-450 uppercase tracking-widest block">
            Dê uma nota técnica de 1 a 5 para a situação do seu time hoje:
          </span>

          <div className="space-y-3.5">
            {dimensions.map((dim) => (
              <div 
                key={dim.id}
                id={`adkar-item-${dim.id}`}
                className="bg-slate-50 hover:bg-slate-100/70 border border-slate-200 rounded-xl p-4 transition-colors space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-extrabold text-slate-900">
                      {isExpert ? dim.titleTechnical : dim.titleSimple}
                    </h4>
                    <p className="text-[11px] text-slate-500 leading-normal">
                      {isExpert ? dim.definitionTechnical : dim.definitionSimple}
                    </p>
                  </div>

                  {/* Circular Score Badge */}
                  <span className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center font-mono font-black text-xs border ${
                    dim.score <= 3 
                      ? "bg-red-50 text-red-650 border-red-200" 
                      : "bg-emerald-50 text-emerald-800 border-emerald-200"
                  }`}>
                    {dim.score}
                  </span>
                </div>

                {/* Range Input slider */}
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-[10px] font-mono text-slate-400">Péssimo (1)</span>
                  <input 
                    type="range" 
                    min="1" 
                    max="5"
                    step="1"
                    value={dim.score}
                    onChange={(e) => handleScoreChange(dim.id, parseInt(e.target.value, 10))}
                    className="w-full accent-[#C49746] cursor-pointer"
                  />
                  <span className="text-[10px] font-mono text-slate-400">Total (5)</span>
                </div>

                <div className="text-[11px] text-slate-700 italic bg-white/75 p-2 rounded border border-slate-150/60 mt-2">
                  <b>Pergunta de Auditoria:</b> {isExpert ? dim.questionTechnical : dim.questionSimple}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ANALYSIS CHART & BARRIER ADVISORY COLUMN */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* BAR CHARTS VISUALIZATION */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-[10px] font-mono font-bold text-slate-450 uppercase tracking-widest block text-center">
              Adesão por Dimensão (ADKAR)
            </span>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: "bold" }} />
                  <YAxis domain={[0, 5]} tickCount={6} tick={{ fontSize: 9 }} />
                  <Tooltip 
                    contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid #e2e8f0" }}
                    labelStyle={{ fontWeight: "bold" }}
                  />
                  <Bar dataKey="Score" fill="#C49746" radius={[4, 4, 0, 0]} maxBarSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* BARRIER POINT INTERPRETATION PANEL */}
          {barrier ? (
            <div className="border border-red-200 bg-red-50/15 p-5 rounded-2xl space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-red-100 text-red-650 rounded-full shrink-0">
                  <Flame className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <span className="text-[9px] font-mono text-red-700 font-extrabold uppercase tracking-wide">
                    ⚠️ Ponto de Barreiras Identificado!
                  </span>
                  <h4 className="text-sm font-serif font-black text-slate-900 mt-1">
                    {isExpert ? barrier.titleTechnical : barrier.titleSimple}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    De acordo com a metodologia ADKAR, tentar treinar ou cobrar a equipe se eles ainda têm notas baixas aqui é perda de tempo e dinheiro. Primeiro resolva esse gargalo psicológico.
                  </p>
                </div>
              </div>

              {/* Specific advisory box */}
              <div className="bg-white border border-red-200/50 p-4 rounded-xl space-y-1.5 text-xs">
                <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase block">
                  Ação Recomendada pelo Consultor:
                </span>
                <p className="text-slate-850 font-medium leading-relaxed">
                  {isExpert ? getBarrierAdvisory(barrier.id).technical : getBarrierAdvisory(barrier.id).simple}
                </p>
              </div>
            </div>
          ) : (
            <div className="border border-emerald-250 bg-emerald-50/10 p-5 rounded-2xl text-xs space-y-2">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-full w-9 h-9 flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="text-xs font-black uppercase text-slate-900">Perfeita Prontidão Psicológica</h4>
              <p className="text-slate-550 leading-relaxed">
                Toda a sua equipe obteve notas superiores a 3 em todas as frentes ADKAR. Estão saudáveis e prontos para decolar a nova rotina LSS!
              </p>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
