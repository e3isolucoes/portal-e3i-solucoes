import React, { useState, useMemo } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import E3IInsightPanel from "../../shared/ui/E3IInsightPanel";
import { 
  Building2, 
  TrendingUp, 
  ShieldAlert, 
  Award, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Clock, 
  Users, 
  ArrowRight, 
  Target, 
  DollarSign, 
  FileText, 
  ShieldCheck, 
  CheckSquare, 
  AlertCircle,
  Activity,
  Maximize2,
  Calendar,
  Zap,
  Info,
  Sliders,
  ArrowDown
} from "lucide-react";
import { 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  LineChart,
  Line
} from "recharts";

interface EnterpriseExecutiveDashboardProps {
  mode: UsabilityMode;
}

// 5 Dimensions of Reorganization Maturity
interface MaturityDimension {
  dimension: string;
  score: number;
  maxScore: number;
  criteria: string;
  evidence: string;
  calculation: string;
  gap: string;
  history: { date: string; score: number }[];
}

const MATURITY_DATA: MaturityDimension[] = [
  {
    dimension: "Diagnóstico Integrado",
    score: 8.2,
    maxScore: 10,
    criteria: "Profundidade de triagem dos gargalos estruturais e quantificação de perdas ocultas em postos de trabalho N8.",
    evidence: "Ação 11 concluída com mapeamento completo de gargalos e perdas.",
    calculation: "Score = (Perdas Identificadas / Perdas Tratadas) * 10",
    gap: "Falta auditar re-digitação secundária no ERP por analistas locais.",
    history: [
      { date: "Mês 1", score: 4.5 },
      { date: "Mês 2", score: 6.8 },
      { date: "Mês 3", score: 8.2 }
    ]
  },
  {
    dimension: "Estratégia & OKRs",
    score: 7.5,
    maxScore: 10,
    criteria: "Desdobramento das diretrizes estratégicas táticas do BSC e integrabilidade de metas de alta gerência.",
    evidence: "Conexão de OKRs aos postos de trabalho e telas ativas no galpão.",
    calculation: "Score = (% OKRs Ativos * 0.4) + (% Metas Alinhadas * 0.6) * 10",
    gap: "Inconsistência temporária na conversão de taxas cambiais para faturamento de filiais.",
    history: [
      { date: "Mês 1", score: 3.0 },
      { date: "Mês 2", score: 5.5 },
      { date: "Mês 3", score: 7.5 }
    ]
  },
  {
    dimension: "Modelagem de Processos",
    score: 8.8,
    maxScore: 10,
    criteria: "Aderência ao padrão BPMN, nível Sigma medido em gárgalos críticos e remoção de desperdícios Lean.",
    evidence: "Eliminação estrutural do papel em postos de expedição e triagem.",
    calculation: "Score = (Nível Sigma Alcançado / 6) * 10",
    gap: "Falta balancear os postos ociosos na etapa inicial do carrinho de compras.",
    history: [
      { date: "Mês 1", score: 5.0 },
      { date: "Mês 2", score: 7.2 },
      { date: "Mês 3", score: 8.8 }
    ]
  },
  {
    dimension: "Governança & RACI",
    score: 6.2,
    maxScore: 10,
    criteria: "Isolamento de autoridade operacional, matriz RACI ativa e tempos máximos de ciclo acordados formalmente.",
    evidence: "Assinatura e aprovação mútua de SLAs sob regulação jurídica do ERP.",
    calculation: "Score = (Ações RACI Sem Conflitos / Total Atividades) * 10",
    gap: "Atitudes de microgerenciamento pontuadas no posto de conferência.",
    history: [
      { date: "Mês 1", score: 2.8 },
      { date: "Mês 2", score: 4.2 },
      { date: "Mês 3", score: 6.2 }
    ]
  },
  {
    dimension: "Cultura & Mudança",
    score: 6.9,
    maxScore: 10,
    criteria: "Mitigação ativa de focos de resistência operacionais e engajamento orgânico das lideranças de trabalho.",
    evidence: "Fóruns operacionais quinzenais de gamificação e metas de prontidão cultural.",
    calculation: "Score = (% Prontidão Cultural Média * 10)",
    gap: "Necessidade de intensificar rituais motivacionais devido às novas rotinas dos sábados.",
    history: [
      { date: "Mês 1", score: 3.5 },
      { date: "Mês 2", score: 5.0 },
      { date: "Mês 3", score: 6.9 }
    ]
  }
];

export default function EnterpriseExecutiveDashboard({ mode }: EnterpriseExecutiveDashboardProps) {
  const isExpert = isExpertMode(mode);

  // Dynamic ROI Calculator state (As-Is vs To-Be Balanced Line)
  const [volumeMensal, setVolumeMensal] = useState(2500);
  const [tempoAsIs, setTempoAsIs] = useState(45); // in minutes
  const [tempoToBe, setTempoToBe] = useState(15); // in minutes
  const [custoHora, setCustoHora] = useState(35); // R$/hora per resource
  const [taxaRetrabalhoAsIs, setTaxaRetrabalhoAsIs] = useState(20); // %
  const [taxaRetrabalhoToBe, setTaxaRetrabalhoToBe] = useState(3); // %
  const [custoRetrabalho, setCustoRetrabalho] = useState(120); // average cost per rework event

  // Handlers with validation to maintain logical consistency (To-Be is better/faster than As-Is)
  const handleTempoAsIsChange = (val: number) => {
    setTempoAsIs(val);
    if (tempoToBe > val) {
      setTempoToBe(val);
    }
  };

  const handleTempoToBeChange = (val: number) => {
    if (val <= tempoAsIs) {
      setTempoToBe(val);
    }
  };

  const handleTaxaRetrabalhoAsIsChange = (val: number) => {
    setTaxaRetrabalhoAsIs(val);
    if (taxaRetrabalhoToBe > val) {
      setTaxaRetrabalhoToBe(val);
    }
  };

  const handleTaxaRetrabalhoToBeChange = (val: number) => {
    if (val <= taxaRetrabalhoAsIs) {
      setTaxaRetrabalhoToBe(val);
    }
  };

  // Calculations
  const custoOpAsIs = useMemo(() => (volumeMensal * tempoAsIs / 60) * custoHora, [volumeMensal, tempoAsIs, custoHora]);
  const custoOpToBe = useMemo(() => (volumeMensal * tempoToBe / 60) * custoHora, [volumeMensal, tempoToBe, custoHora]);

  const custoRetAsIs = useMemo(() => volumeMensal * (taxaRetrabalhoAsIs / 100) * custoRetrabalho, [volumeMensal, taxaRetrabalhoAsIs, custoRetrabalho]);
  const custoRetToBe = useMemo(() => volumeMensal * (taxaRetrabalhoToBe / 100) * custoRetrabalho, [volumeMensal, taxaRetrabalhoToBe, custoRetrabalho]);

  const economiaPapel = 6500; // Fixed value for paper reduction
  const economiaInfra = 4800; // Fixed value for legacy IT reduction

  const totalAsIs = useMemo(() => custoOpAsIs + custoRetAsIs + economiaPapel + economiaInfra, [custoOpAsIs, custoRetAsIs]);
  const totalToBe = useMemo(() => custoOpToBe + custoRetToBe, [custoOpToBe, custoRetToBe]);

  const economiaTempo = useMemo(() => custoOpAsIs - custoOpToBe, [custoOpAsIs, custoOpToBe]);
  const economiaRetrabalho = useMemo(() => custoRetAsIs - custoRetToBe, [custoRetAsIs, custoRetToBe]);
  const economiaTotalMensal = useMemo(() => totalAsIs - totalToBe, [totalAsIs, totalToBe]);
  const economiaTotalAnual = useMemo(() => economiaTotalMensal * 12, [economiaTotalMensal]);

  // Waterfall dataset preparation for Recharts stacked bar approach
  const waterfallData = useMemo(() => {
    const data = [];
    
    // 1. Custo As-Is (Total)
    data.push({
      name: "Custo As-Is",
      invisible: 0,
      saving: 0,
      expense: 0,
      total: Math.round(totalAsIs),
      displayVal: `R$ ${Math.round(totalAsIs).toLocaleString('pt-BR')}`
    });

    // 2. Redução Tempo (Saving)
    const base1 = totalAsIs - economiaTempo;
    data.push({
      name: "Ganho Operação",
      invisible: Math.round(base1),
      saving: Math.round(economiaTempo),
      expense: 0,
      total: 0,
      displayVal: `-R$ ${Math.round(economiaTempo).toLocaleString('pt-BR')}`
    });

    // 3. Redução Retrabalho (Saving)
    const base2 = base1 - economiaRetrabalho;
    data.push({
      name: "Menos Retrabalho",
      invisible: Math.round(base2),
      saving: Math.round(economiaRetrabalho),
      expense: 0,
      total: 0,
      displayVal: `-R$ ${Math.round(economiaRetrabalho).toLocaleString('pt-BR')}`
    });

    // 4. Digitalização Papel (Saving)
    const base3 = base2 - economiaPapel;
    data.push({
      name: "Corte Papel/Físico",
      invisible: Math.round(base3),
      saving: Math.round(economiaPapel),
      expense: 0,
      total: 0,
      displayVal: `-R$ ${Math.round(economiaPapel).toLocaleString('pt-BR')}`
    });

    // 5. Infraestrutura Cloud (Saving)
    const base4 = base3 - economiaInfra;
    data.push({
      name: "Infra & TI",
      invisible: Math.round(base4),
      saving: Math.round(economiaInfra),
      expense: 0,
      total: 0,
      displayVal: `-R$ ${Math.round(economiaInfra).toLocaleString('pt-BR')}`
    });

    // 6. Custo To-Be (Total)
    data.push({
      name: "Custo To-Be",
      invisible: 0,
      saving: 0,
      expense: 0,
      total: Math.round(totalToBe),
      displayVal: `R$ ${Math.round(totalToBe).toLocaleString('pt-BR')}`
    });

    return data;
  }, [totalAsIs, totalToBe, economiaTempo, economiaRetrabalho, economiaPapel, economiaInfra]);

  // Selected dimension details block
  const [selectedDimIndex, setSelectedDimIndex] = useState<number>(3); // Defaults to Governança
  const selectedDimension = MATURITY_DATA[selectedDimIndex];

  // Calculated high level enterprise stats
  const averageMaturity = useMemo(() => {
    const sum = MATURITY_DATA.reduce((acc, dim) => acc + dim.score, 0);
    return Number((sum / MATURITY_DATA.length).toFixed(1));
  }, []);

  const overallMaturityStatus = 
    averageMaturity >= 8.5 ? "Líder de Mercado" :
    averageMaturity >= 7.0 ? "Estável & Integrado" :
    averageMaturity >= 5.0 ? "Operação em Evolução" : "Nível Manual Crítico";

  // Actions Evolution Over Time simulated data for comparison
  const comparisonData = [
    { dimension: "Diagnóstico", antes: 4.5, depois: 8.2, gap: 3.7 },
    { dimension: "Estratégia", antes: 3.0, depois: 7.5, gap: 4.5 },
    { dimension: "Processos", antes: 5.0, depois: 8.8, gap: 3.8 },
    { dimension: "Governança", antes: 2.8, depois: 6.2, gap: 3.4 },
    { dimension: "Mudança", antes: 3.5, depois: 6.9, gap: 3.4 }
  ];

  const CustomWaterfallTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3 border border-slate-700 rounded-lg text-xs font-sans shadow-lg">
          <p className="font-mono font-bold uppercase tracking-wider text-[#C49746]">{data.name}</p>
          <p className="text-[11px] font-medium mt-1 text-slate-300">
            {data.name.includes("Custo") ? "Custo Mensal Total:" : "Impacto de Melhoria Mensal:"}
          </p>
          <p className={`text-sm font-mono font-black mt-0.5 ${
            data.name.includes("Custo") ? "text-white" : "text-emerald-400"
          }`}>
            {data.displayVal}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 text-left">
      
      {/* HEADER HERO EXECUTIVE BANNER */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-5 sm:p-6 rounded-2xl border border-slate-700 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">
              DIRETRIZ DE INTEGRABILIDADE — AÇÃO 14
            </span>
            <h2 className="text-xl sm:text-2xl font-serif font-black text-white flex items-center gap-2">
              <Building2 className="w-6 h-6 text-[#C49746] animate-pulse" />
              Dashboard Corporativo de Performance Executiva
            </h2>
            <p className="text-xs text-slate-350 max-w-3xl leading-relaxed">
              Consolide em uma visão de nível C-Suite a saúde de maturidade da empresa em 5 frentes estratégicas de mudança organizativa.
            </p>
          </div>

          <span className="text-[10px] font-mono bg-[#C49746]/10 border border-[#C49746]/30 text-[#C49746] px-3 py-1.5 rounded-lg font-black uppercase">
            ENTERPRISE HEALTH CENTER
          </span>
        </div>
      </div>

      {/* DYNAMICS INTEPRETATION BLOCK IN SIMPLE MODE */}
      {isSimpleMode(mode) && (
        <div className="bg-[#C49746]/5 border border-[#C49746]/20 p-4.5 rounded-xl text-xs space-y-1.5">
          <span className="text-[10.5px] font-mono font-black text-[#A17528] uppercase flex items-center gap-1.5">
            <Info className="w-4 h-4 text-[#C49746]" />
            Leitura Inteligente dos Resultados (Diagnóstico Simples)
          </span>
          <p className="text-slate-705 leading-relaxed">
            <strong className="text-slate-900">“O maior gargalo e risco atual para a empresa reside em Governança &amp; RACI e Gestão de Mudança.”</strong> Atualmente, a modelagem de processos BPMN e o mapeamento do fluxo operacional tiveram avanços céleres, mas as tensões e overlapping de autoridade continuam exigindo alinhamento executivo formal para que as novas regras de sábado ganhem harmonia nas equipes.
          </p>
        </div>
      )}

      {/* 8 CRITICAL EXECUTIVE INDEX CARDS GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Maturidade Geral */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Maturidade Geral</span>
            <Award className="w-4 h-4 text-[#C49746]" />
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-slate-900">{averageMaturity} / 10</p>
            <span className="text-[10px] font-mono font-bold bg-[#C49746]/10 text-[#C49746] px-1.5 py-0.2 rounded">
              {overallMaturityStatus}
            </span>
          </div>
        </div>

        {/* Card 2: Dimensão mais crítica */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Dimensão Crítica</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="space-y-0.5">
            <p className="text-lg sm:text-xl font-black text-rose-700">Governança &amp; RACI</p>
            <span className="text-[10px] font-mono font-bold text-red-500">
              Score atual: 6.2 / 10
            </span>
          </div>
        </div>

        {/* Card 3: Processos Críticos */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Etapas Estressantes</span>
            <Clock className="w-4 h-4 text-amber-500 animate-spin" />
          </div>
          <div className="space-y-0.5">
            <p className="text-lg sm:text-xl font-black text-slate-900">Expedição N8</p>
            <span className="text-[10px] text-slate-500">
              Gargalo médio de 24 min ao faturar
            </span>
          </div>
        </div>

        {/* Card 4: Responsabilidades Pendentes */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Vetos / RACI Pendentes</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-indigo-800">2 Co-autorias</p>
            <span className="text-[10px] text-slate-500">
              SLA logística comercial indefinido
            </span>
          </div>
        </div>

        {/* Card 5: Ações Atrasadas */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Ações em Atraso</span>
            <ShieldAlert className="w-4 h-4 text-red-500 animate-bounce" />
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-red-700">0 Críticas</p>
            <span className="text-[10px] text-slate-500 font-bold bg-emerald-50 text-emerald-800 px-1.5 py-0.2 rounded inline-block">
              100% Cronograma em Linha
            </span>
          </div>
        </div>

        {/* Card 6: Ganho Estimado */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>ROI Reorg Estimado</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-emerald-800">R$ 158.000 / ano</p>
            <span className="text-[10px] text-slate-500">
              Eliminação de retrabalhos manuais
            </span>
          </div>
        </div>

        {/* Card 7: Risco Organizacional */}
        <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-slate-450 text-[10px] font-mono font-black uppercase">
            <span>Risco Geral</span>
            <Activity className="w-4 h-4 text-red-500" />
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-orange-600">Baixo - Médio</p>
            <span className="text-[10px] text-slate-450 font-sans">
              Prontidão cultural de 69%
            </span>
          </div>
        </div>

        {/* Card 8: Próxima melhor ação */}
        <div className="bg-[#C49746]/10 border border-[#C49746]/30 p-4 rounded-xl space-y-2 hover:shadow-3xs transition-all">
          <div className="flex items-center justify-between text-[#A17528] text-[10px] font-mono font-black uppercase">
            <span>Próxima Ação</span>
            <Zap className="w-4 h-4 text-[#C49746]" />
          </div>
          <div className="space-y-0.5">
            <p className="text-[11.5px] font-black text-[#A17528]">Assinar Termo de SLAs operacionais</p>
            <span className="text-[10px] text-slate-655 font-mono">
              Impacto: 8/10 | Esforço: Baixo
            </span>
          </div>
        </div>

      </div>

      {/* CHART DOCK ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Radar of Maturity Chart */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-[#C49746]" />
              Radar de Maturidade C-Suite
            </h4>
            <span className="text-[10.2px] font-mono text-slate-450">5 Dimensões Críticas</span>
          </div>

          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={MATURITY_DATA}>
                <PolarGrid />
                <PolarAngleAxis dataKey="dimension" tick={{ fontSize: 9, fontWeight: "bold", fill: "#334155" }} />
                <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fontSize: 8 }} />
                <Radar name="Status Atual" dataKey="score" stroke="#C49746" fill="#C49746" fillOpacity={0.15} />
                <Tooltip contentStyle={{ fontSize: 10 }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Before and After Comparison Chart */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Impacto &amp; Evolução Histórica (Antes × Depois)
            </h4>
            <span className="text-[10px] font-mono text-slate-450">Evolução por Dimensão de Reorg</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="dimension" tick={{ fontSize: 10, fontWeight: "bold" }} />
                <YAxis domain={[0, 10]} tick={{ fontSize: 9 }} />
                <Tooltip contentStyle={{ fontSize: 10 }} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: 10, fontWeight: "bold" }} />
                <Bar name="Antes da Reorganização" dataKey="antes" fill="#94a3b8" />
                <Bar name="Após Reorganização (Estável)" dataKey="depois" fill="#C49746" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* NEW ROI WATERFALL VISUAL PANEL: AS-IS VS TO-BE BALANCE LINE */}
      <div className="bg-white border-2 border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm space-y-5 text-left">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-black text-emerald-600 uppercase tracking-widest block flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 animate-pulse text-emerald-500" /> ANÁLISE DE RETORNO SOBRE INVESTIMENTO (ROI)
            </span>
            <h3 className="text-lg font-serif font-black text-slate-900 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              Modelador Financeiro &amp; Cascata de ROI (As-Is × To-Be)
            </h3>
            <p className="text-xs text-slate-500 max-w-3xl leading-relaxed">
              Descubra os ganhos mensais agregados calculando a diferença entre as perdas do <strong>Processo As-Is</strong> e a eficiência obtida com a <strong>Linha Balanceada (To-Be)</strong>. Altere as variáveis reais do seu negócio abaixo para calibrar a projeção:
            </p>
          </div>
          
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 flex items-center gap-3 self-start sm:self-center">
            <TrendingUp className="w-8 h-8 text-emerald-600 shrink-0" />
            <div className="space-y-0.5">
              <span className="text-[9px] font-mono font-black uppercase text-emerald-600 block leading-none">ECONOMIA ANUAL ESTIMADA</span>
              <p className="text-lg font-mono font-black leading-none text-emerald-900">R$ {Math.round(economiaTotalAnual).toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Controls column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
              <span className="text-[10px] font-mono font-black text-slate-500 uppercase tracking-wider block flex items-center gap-1.5 border-b pb-1.5 mb-2">
                <Sliders className="w-3.5 h-3.5 text-slate-500" /> Painel de Controle Operacional
              </span>
              
              {/* Sliders Grid */}
              <div className="space-y-3">
                {/* Volume slider */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-700">Volume Mensal:</span>
                    <span className="text-indigo-900 font-mono font-bold">{volumeMensal.toLocaleString('pt-BR')} transações</span>
                  </div>
                  <input 
                    type="range" 
                    min="500" 
                    max="10000" 
                    step="250"
                    value={volumeMensal}
                    onChange={(e) => setVolumeMensal(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                </div>

                {/* Operator cost slider */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-700">Custo Hora Operador:</span>
                    <span className="text-indigo-900 font-mono font-bold">R$ {custoHora}/h</span>
                  </div>
                  <input 
                    type="range" 
                    min="15" 
                    max="150" 
                    step="5"
                    value={custoHora}
                    onChange={(e) => setCustoHora(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                </div>

                {/* Tempo As-Is & To-Be */}
                <div className="border-t pt-2 mt-2 space-y-3">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-700">Tempo Médio As-Is:</span>
                      <span className="text-red-700 font-mono font-bold">{tempoAsIs} minutos</span>
                    </div>
                    <input 
                      type="range" 
                      min="15" 
                      max="120" 
                      step="5"
                      value={tempoAsIs}
                      onChange={(e) => handleTempoAsIsChange(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-700">Tempo Médio To-Be:</span>
                      <span className="text-emerald-700 font-mono font-bold">{tempoToBe} minutos</span>
                    </div>
                    <input 
                      type="range" 
                      min="5" 
                      max="60" 
                      step="5"
                      value={tempoToBe}
                      onChange={(e) => handleTempoToBeChange(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>
                </div>

                {/* Rework Parameters */}
                <div className="border-t pt-2 mt-2 space-y-3">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-700">Retrabalho As-Is:</span>
                      <span className="text-red-700 font-mono font-bold">{taxaRetrabalhoAsIs}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="2" 
                      max="40" 
                      step="1"
                      value={taxaRetrabalhoAsIs}
                      onChange={(e) => handleTaxaRetrabalhoAsIsChange(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-700">Retrabalho To-Be:</span>
                      <span className="text-emerald-700 font-mono font-bold">{taxaRetrabalhoToBe}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="1" 
                      max="15" 
                      step="1"
                      value={taxaRetrabalhoToBe}
                      onChange={(e) => handleTaxaRetrabalhoToBeChange(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-700">Custo Unitário de Retrabalho:</span>
                      <span className="text-indigo-900 font-mono font-bold">R$ {custoRetrabalho}</span>
                    </div>
                    <input 
                      type="range" 
                      min="50" 
                      max="500" 
                      step="10"
                      value={custoRetrabalho}
                      onChange={(e) => setCustoRetrabalho(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Metrics Comparison Table */}
            <div className="bg-slate-900 text-white rounded-xl p-4 space-y-3 font-sans border border-slate-800 shadow-sm">
              <span className="text-[9.5px] font-mono font-black text-[#C49746] uppercase block tracking-wider">REPARTIÇÃO DOS CUSTOS MENSAIS</span>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-slate-800/60 p-2 rounded border border-slate-700/50">
                  <p className="text-[9px] font-mono font-bold text-slate-400 uppercase leading-none">AS-IS TOTAL</p>
                  <p className="text-xs font-mono font-black text-rose-400 mt-1">R$ {Math.round(totalAsIs).toLocaleString('pt-BR')}</p>
                </div>
                <div className="bg-slate-800/60 p-2 rounded border border-slate-700/50">
                  <p className="text-[9px] font-mono font-bold text-slate-400 uppercase leading-none">TO-BE TOTAL</p>
                  <p className="text-xs font-mono font-black text-emerald-400 mt-1">R$ {Math.round(totalToBe).toLocaleString('pt-BR')}</p>
                </div>
                <div className="bg-emerald-950/40 p-2 rounded border border-emerald-800/30">
                  <p className="text-[9px] font-mono font-bold text-emerald-400 uppercase leading-none">GAIN/MÊS</p>
                  <p className="text-xs font-mono font-black text-[#C49746] mt-1">+R$ {Math.round(economiaTotalMensal).toLocaleString('pt-BR')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Waterfall Chart Column */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-3xs flex flex-col justify-between">
            <div className="space-y-1 mb-4">
              <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-[#C49746]" />
                Visualização de Cascata (Ganhos de Transição Operacional)
              </h4>
              <span className="text-[10px] font-medium text-slate-450 block">Pontes flutuantes ligando o custo de entrada (As-Is) ao custo de saída ideal (To-Be)</span>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={waterfallData} margin={{ top: 20, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: "bold" }} />
                  <YAxis tick={{ fontSize: 9 }} tickFormatter={(val) => `R$ ${Math.round(val/1000)}k`} />
                  <Tooltip content={<CustomWaterfallTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                  {/* Floating support bar (invisible) */}
                  <Bar dataKey="invisible" stackId="a" fill="transparent" />
                  {/* Positive cost savings */}
                  <Bar dataKey="saving" stackId="a" fill="#10b981" radius={[2, 2, 0, 0]} />
                  {/* Expense increases (if any) */}
                  <Bar dataKey="expense" stackId="a" fill="#ef4444" radius={[2, 2, 0, 0]} />
                  {/* Totals (As-Is and To-Be) */}
                  <Bar dataKey="total" stackId="a" fill="#1e293b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="border-t border-slate-200 pt-3 mt-4 flex flex-wrap justify-between items-center gap-3">
              <div className="flex gap-4 text-[10px] font-mono font-bold">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-[#1e293b] rounded inline-block"></span>
                  <span className="text-slate-600 font-sans">Total Base</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-[#10b981] rounded inline-block"></span>
                  <span className="text-emerald-700 font-sans font-bold">Ganhos Operacionais</span>
                </div>
              </div>

              <div className="text-[10px] bg-indigo-50 text-indigo-950 px-2.5 py-1 rounded font-medium max-w-md">
                ℹ️ <strong>Payback estimado:</strong> Com base na melhoria balanceada, o payback do investimento operacional é de <strong>menos de 1 mês</strong>.
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* EXPERT VIEW UNDERMATURING SECTIONS AND MATH DEPICTION */}
      {isExpert && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left: Gaps and Gaps Table */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="text-xs font-bold uppercase text-slate-900 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-indigo-700" />
                Mapeamento de Gaps de Auditoria e Critérios de Concessão
              </h4>
              <span className="text-[10px] font-mono bg-indigo-50 border border-indigo-200 text-indigo-700 px-2 py-0.5 rounded font-black uppercase">
                AUDIT ENGINE
              </span>
            </div>

            <p className="text-[11px] text-slate-550 leading-relaxed">
              Consulte a fundamentação dos scores operacionais e as restrições identificadas na auditoria clínica integrada. Selecione no radar ou clique em uma das linhas para visualizar a evolução:
            </p>

            <div className="overflow-x-auto border border-slate-150 rounded-lg">
              <table className="w-full text-[10.5px] border-collapse bg-white">
                <thead>
                  <tr className="bg-slate-100 border-b text-slate-700 font-mono text-[9px] uppercase font-bold text-left">
                    <th className="p-2.5 pl-3">Eixo de Mudança</th>
                    <th className="p-2.5 text-center">Score Atual</th>
                    <th className="p-2.5">Ocorrência de Restrição (Gap Operativo)</th>
                    <th className="p-2.5">Evidência Identificada</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {MATURITY_DATA.map((dim, idx) => {
                    const isSelected = selectedDimIndex === idx;
                    return (
                      <tr 
                        key={dim.dimension}
                        onClick={() => setSelectedDimIndex(idx)}
                        className={`hover:bg-slate-50/50 cursor-pointer transition-colors ${
                          isSelected ? "bg-[#C49746]/5 text-[#A17528]" : ""
                        }`}
                      >
                        <td className="p-2.5 pl-3 font-bold text-slate-900">{dim.dimension}</td>
                        <td className="p-2.5 text-center font-mono font-extrabold text-slate-950">{dim.score} / 10</td>
                        <td className="p-2.5 text-slate-550 max-w-xs truncate">{dim.gap}</td>
                        <td className="p-2.5 text-slate-650 max-w-xs truncate font-sans">{dim.evidence}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right: Formulas and selected score detail panel */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-3xs space-y-4">
            <span className="text-[9px] bg-indigo-50 text-indigo-750 border border-indigo-200 font-bold px-2 py-0.5 rounded-full inline-block uppercase font-mono">
              Fórmula de Cálculo &amp; Historial
            </span>
            
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
              <h5 className="text-[11.5px] font-black text-slate-900">
                Eixo Ativo: {selectedDimension.dimension}
              </h5>
              
              <div className="space-y-1">
                <span className="text-[8.5px] font-mono font-bold text-slate-400 uppercase">FÓRMULA ANALÍTICA DE ESCALONAMENTO:</span>
                <p className="bg-white border text-center border-slate-200 font-mono text-[10px] p-2 rounded text-slate-800 font-black">
                  {selectedDimension.calculation}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[8.5px] font-mono font-bold text-slate-400 uppercase">CRITÉRIO EXIGIDO:</span>
                <p className="text-[10.5px] text-slate-600 leading-snug">{selectedDimension.criteria}</p>
              </div>
            </div>

            {/* LineChart on history of this parameter */}
            <div className="space-y-1.5 border border-slate-200 rounded-xl p-3.5 bg-slate-50/20">
              <span className="text-[9px] font-mono font-black text-slate-450 uppercase block">CURVA DE MATURAÇÃO DOS ÚLTIMOS 90 DIAS:</span>
              <div className="h-28 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={selectedDimension.history} margin={{ top: 5, right: 10, left: -30, bottom: 0 }}>
                    <XAxis dataKey="date" tick={{ fontSize: 9 }} />
                    <YAxis domain={[0, 10]} tick={{ fontSize: 8 }} />
                    <Tooltip contentStyle={{ fontSize: 10 }} />
                    <Line type="monotone" dataKey="score" stroke="#C49746" strokeWidth={2.2} activeDot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                <span>Início: {selectedDimension.history[0].score}/10</span>
                <span>Alvo: {selectedDimension.maxScore}/10</span>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* E3I INSIGHTS FOR EXECUTIVE DASHBOARD */}
      <E3IInsightPanel
        title="Painel de Maturidade e Reorganização Executiva"
        businessExplanation="Este painel consolida o status da reorganização da empresa em cinco frentes críticas (Diagnóstico, Estratégia, Processos, Governança e Transição de Cultura). Ele serve para dar à diretoria executiva uma leitura imediata das forças e fraquezas operacionais da empresa de forma simples."
        whyItMatters="Permite que a tomada de decisão seja sempre pautada por dados de aderência operacional e desvios eliminados, em vez de percepções vagas, alinhando eficiência na ponta com retorno financeiro estratégico."
        nextAction="1. Priorize ações na dimensão de Governança & RACI, identificada como a principal frente de risco restante.
2. No modo Especialista, consulte a fórmula analítica de escalonamento para compreender as métricas pesadas de conformidade por área."
        frameworkName="McKinsey 7S Integrado + C-Suite Maturity Matrix"
        technicalDetails={`Os scores de maturidade são apurados por meio de ponderações estatísticas normalizadas (escala de 0 a 10):
- Diagnóstico: Relaciona perdas tratadas no ERP a perdas remanescentes.
- OKRs: Combina percentuais de desdobramento de metas com alinhamento vertical.
- Governança: Mede em tempo real a fração de etapas de fluxo livres de overlapping ou indefinição na matriz RACI.`}
        mode={mode}
        className="mt-6 font-sans"
      />

    </div>
  );
}
