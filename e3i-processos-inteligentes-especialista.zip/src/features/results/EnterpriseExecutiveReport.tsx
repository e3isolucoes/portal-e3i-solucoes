import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import E3IInsightPanel from "../../shared/ui/E3IInsightPanel";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import {
  FileText,
  Building2,
  HelpCircle,
  Compass,
  Network,
  BookOpen,
  ShieldCheck,
  Megaphone,
  Layers,
  TrendingUp,
  ArrowRight,
  Printer,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Info,
  Calendar,
  DollarSign,
  User,
  Users,
  Target
} from "lucide-react";

export interface EnterpriseExecutiveReportProps {
  mode: UsabilityMode;
}

export default function EnterpriseExecutiveReport({ mode }: EnterpriseExecutiveReportProps) {
  const isExpert = isExpertMode(mode);
  const [activeSection, setActiveSection] = useState<string>("contexto");
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handlePrint = () => {
    setIsExporting(true);
    
    // Allow a small timeout to ensure the element is rendered and styled in DOM
    setTimeout(() => {
      const element = document.getElementById("enterprise-report-pdf-content");
      if (!element) {
        console.error("Elemento de exportação do PDF não encontrado.");
        setIsExporting(false);
        return;
      }

      html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: "#FAF9F6"
      }).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const imgWidth = 210;
        const pageHeight = 297;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;

        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }

        pdf.save(`Relatorio-Executivo-AlfaSA-${Date.now()}.pdf`);
        setIsExporting(false);
      }).catch((err) => {
        console.error("Erro ao gerar PDF:", err);
        setIsExporting(false);
      });
    }, 100);
  };

  const sections = [
    { id: "contexto", label: "1. Contexto", icon: <Building2 className="w-4 h-4" /> },
    { id: "diagnostico", label: "2. Diagnóstico 7S", icon: <HelpCircle className="w-4 h-4" /> },
    { id: "gaps", label: "3. Principais Desalinhamentos", icon: <AlertTriangle className="w-4 h-4" /> },
    { id: "prioridades", label: "4. Prioridades Recomendadas", icon: <Target className="w-4 h-4" /> },
    { id: "estrategia", label: "5. Estratégia & OKRs", icon: <Compass className="w-4 h-4" /> },
    { id: "estrutura", label: "6. Estrutura & Papéis", icon: <Network className="w-4 h-4" /> },
    { id: "processos", label: "7. Processos Críticos", icon: <BookOpen className="w-4 h-4" /> },
    { id: "reorganizacao", label: "8. Plano de Ação 5W2H", icon: <Layers className="w-4 h-4" /> },
    { id: "resultados", label: "9. Resultados & ROI", icon: <TrendingUp className="w-4 h-4" /> },
    { id: "proximos-passos", label: "10. Próximos Passos", icon: <ArrowRight className="w-4 h-4" /> }
  ];

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* HEADER HERO BANNER */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-5 sm:p-6 rounded-2xl border border-slate-700 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">
            DIRETRIZ DE INTEGRABILIDADE — RELATÓRIO EXECUTIVO (AÇÃO 15)
          </span>
          <h2 className="text-xl sm:text-2xl font-serif font-black text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-[#C49746]" />
            Relatório de Reestruturação &amp; Alinhamento Empresarial
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Relatório estratégico unificado ligando a maturidade operacional, governança de responsabilidades RACI, processos críticos e gestão da mudança ao planejamento tático de médio prazo.
          </p>
        </div>
        <button
          onClick={handlePrint}
          disabled={isExporting}
          className="flex items-center gap-2 bg-[#C49746] hover:bg-[#b0853a] text-slate-950 px-4 py-2 rounded-lg text-xs font-black uppercase transition-all shadow-sm shrink-0 self-start md:self-center cursor-pointer"
        >
          <Printer className="w-4 h-4 animate-bounce" />
          {isExporting ? "Gerando Impressão..." : "Exportar Relatório (PDF)"}
        </button>
      </div>

      {/* QUICK TABLE OF CONTENTS BAR FOR EASIER NAVIGATION */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-3xs overflow-x-auto whitespace-nowrap scrollbar-thin">
        <div className="flex items-center gap-1.5 md:gap-3 text-xs">
          <span className="text-[10px] font-mono font-black text-slate-400 uppercase mr-2 shrink-0">Sumário Executivo:</span>
          {sections.map((sect) => (
            <button
              key={sect.id}
              onClick={() => setActiveSection(sect.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                activeSection === sect.id
                  ? "bg-slate-900 text-[#C49746] border-slate-900 shadow-3xs"
                  : "bg-slate-50 text-slate-600 border-slate-200.5 hover:bg-slate-100"
              }`}
            >
              {sect.icon}
              <span className="text-[10.5px] uppercase tracking-tight">{sect.label.split(". ")[1]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* DETAILED CONTENT SECTIONS WRAPPER */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* SIDEBAR SUBSECTION EXPLAINER - HIDDEN ON MOBILE FOR COMPACTNESS */}
        <div className="lg:col-span-1 space-y-4 hidden lg:block">
          <div className="bg-slate-900 text-slate-100 p-5 rounded-2xl space-y-4 border border-slate-800 shadow-sm">
            <h3 className="text-sm font-serif font-black text-[#C49746] uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Empresa Alvo
            </h3>
            <div className="space-y-3 text-xs leading-relaxed">
              <div>
                <p className="text-[10px] uppercase font-mono text-slate-400">Cliente Corporativo</p>
                <p className="font-bold text-slate-200">Indústrias Metalúrgicas Alfa S.A.</p>
              </div>
              <div>
                <p className="text-[10px] uppercase font-mono text-slate-400">Consultoria Responsável</p>
                <p className="font-bold text-[#C49746] flex items-center gap-1">
                  E3I Intelligence Group
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase font-mono text-slate-400">Escopo da Intervenção</p>
                <p className="font-medium text-slate-300">Diagnóstico 360°, Redesenho do Modelo Operacional, Arquitetura de Processos Complexos &amp; Acordo de Níveis de Serviço (SLA) para Turnos do Sábado.</p>
              </div>
              <div className="pt-2 border-t border-slate-800/60 font-mono text-[9px] text-slate-400">
                Data do Relatório: 22 de Junho de 2026<br />
                Status: Prontidão Operacional
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 p-4.5 rounded-2xl text-xs space-y-2.5 shadow-sm">
            <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest block">Metodologia Unificada</span>
            <p className="text-slate-600 leading-relaxed">
              Este relatório consolida de forma linear a história de diagnóstico e mitigação de desvios, aplicando as melhores práticas de governança técnica.
            </p>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 font-mono text-[10px] text-slate-700">
              {isExpert ? (
                <div>
                  <strong className="text-slate-900">Frameworks Aplicados:</strong>
                  <ul className="list-disc pl-4 mt-1 space-y-0.5">
                    <li>McKinsey 7S Model</li>
                    <li>Balanced Scorecard (BSC)</li>
                    <li>OKRs Operacionais</li>
                    <li>SIPOC / VSM Lean</li>
                    <li>Matriz RACI / ARWI</li>
                    <li>Kotter 8 Passos / ADKAR</li>
                  </ul>
                </div>
              ) : (
                <div>
                  <strong className="text-slate-900">Trilha Percorrida:</strong>
                  <ul className="list-disc pl-4 mt-1 space-y-0.5">
                    <li>Descobrir problemas</li>
                    <li>Traçar metas de ganho</li>
                    <li>Dividir os papéis do time</li>
                    <li>Simplificar tarefas</li>
                    <li>Apoiar colaboradores</li>
                    <li>Planejar ações 5W2H</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* MAIN BODY AREA FOR ACTIVE REPORT PART */}
        <div className="lg:col-span-3 bg-white border border-slate-200.5 rounded-2xl p-5 sm:p-7 shadow-sm min-h-[500px]">
          
          {/* 1. CONTEXTO */}
          {activeSection === "contexto" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">1. Contexto Estratégico</h3>
                  <p className="text-[10px] text-slate-400 font-mono">AS-IS contextualization and trigger details</p>
                </div>
              </div>

              <div className="space-y-3 leading-relaxed text-xs sm:text-sm">
                <p>
                  A Alfa S.A. enfrenta um momento decisivo em seu crescimento de mercado. Com a necessidade emergente de rodar as fábricas e expedir lotes também aos <strong>sábados</strong>, surgiram desencontros organizacionais reativos: conflitos de autoridade, sobrecarga de engenheiros veteranos e intercorrências devido à falta de clareza nas responsabilidades operacionais mais simples.
                </p>
                <p>
                  Para resolver esse gargalo de expansão sem incorrer no inchaço dos custos fixos, a empresa idealizou esta reestruturação integrada. O objetivo principal é profissionalizar a governança da operação, conectando a liderança estratégica ao chão de fábrica, otimizando os arranjos e eliminando redundâncias.
                </p>

                {isExpert ? (
                  <div className="bg-slate-900 text-slate-100 p-4 rounded-xl border border-slate-800 space-y-2 mt-4 text-xs font-serif leading-relaxed">
                    <span className="text-[10px] font-mono font-black text-[#C49746] uppercase flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5" />
                      ANÁLISE DE PRONTIDÃO DO MODELO OPERACIONAL (TOM)
                    </span>
                    <p className="text-slate-300">
                      O Target Operating Model (TOM) atual carece de flexibilidade funcional estrita para acomodar o regime de compensações e as janelas reguladoras adicionais aos sábados. A ausência de regras organizativas claras impõe um custo de fricção diária de cerca de <strong>12% de retrabalho útil</strong> na transmissão de heranças de tarefas entre o turno da sexta-feira e os plantões de fim de semana.
                    </p>
                    <p className="text-slate-450 font-mono text-[9px] mt-2">
                      Fórmula de Atrito de Interface: ΔF = N_Interfaces * (1 - CoerênciaRACI_Aprovação) * Tempo de Reuniões diárias.
                    </p>
                  </div>
                ) : (
                  <div className="bg-[#C49746]/5 border border-[#C49746]/20 p-4.5 rounded-xl space-y-2 mt-4 text-xs leading-relaxed">
                    <span className="text-[11px] font-mono font-black text-[#A17528] uppercase flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-[#C49746]" />
                      Como isso afeta o seu negócio?
                    </span>
                    <p className="text-slate-700 font-medium">
                      O nosso trabalho não está rendendo como deveria aos sábados porque a equipe se sente perdida sobre "quem decide o que" e as orientações não descem organizadamente de forma escrita. Isso gera estresse nas lideranças e atrasos que prejudicam as entregas de segunda-feira de manhã.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. DIAGNOSTICO INICIAL (7S / MATURIDADE) */}
          {activeSection === "diagnostico" && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3 text-slate-750">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">2. Diagnóstico da Maturidade</h3>
                  <p className="text-[10px] text-slate-400 font-mono">McKinsey 7S dimensions mapping and overall baseline</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  O diagnóstico mapeou a aderência de sete dimensões fundamentais que compõem o desempenho corporativo. O resultado apontou para uma disparidade clássica: a empresa tem boa clareza sobre o rumo que deseja tomar (Estratégia), mas carece das ferramentas metodológicas estáveis para garantir a execução previsível diária (Processos, Governança e Indicadores).
                </p>

                {/* 7S Grid Score presentation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-2">
                  {[
                    { dim: "Estratégia (Strategy)", simpleTitle: "Para onde rumamos?", nota: 8.5, bsc: "Direcionamento Estratégico", descExpert: "Metas de portfólio claras, mas descoladas da governança de atividades rotineiras.", descSimple: "Temos o objetivo de crescimento claro na mente da diretoria." },
                    { dim: "Estrutura (Structure)", simpleTitle: "Divisão de departamentos", nota: 7.0, bsc: "Organograma Funcional", descExpert: "Silos organizacionais acentuados e duplicidade de responsabilidade em compras de engenharia.", descSimple: "As divisões entre áreas funcionam, mas geram ruído nas transições de plantão." },
                    { dim: "Sistemas (Systems)", simpleTitle: "Sistemas e Softwares", nota: 5.5, bsc: "Aderência Tecnológica ERP/BI", descExpert: "Subutilização de módulos de consolidação do ERP para tomada de decisão ágil.", descSimple: "Temos sistemas computacionais mas as informações continuam soltas no WhatsApp." },
                    { dim: "Valores Compartilhados (Shared Values)", simpleTitle: "Cultura e Cooperação", nota: 7.2, bsc: "Princípios Operacionais", descExpert: "Cultura resiliente e focada na qualidade, mas reativa a novos acordos de plantões corporativos.", descSimple: "O colaborador veste a camisa, mas fica amedrontado ao propor mudanças estruturais." },
                    { dim: "Liderança (Staff/Style)", simpleTitle: "Atitudes e Pessoas", nota: 6.8, bsc: "Liderança e Clima", descExpert: "Liderança com perfil altamente paternalista e centralizadora no presidente da corporação.", descSimple: "Os gestores ajudam muito o time, mas acabam sobrecarregados por não delegarem." },
                    { dim: "Família de Tarefas (Skills)", simpleTitle: "Competências Internas", nota: 6.0, bsc: "Nível Técnico Operacional", descExpert: "Concentração extrema de know-how técnico em 3 engenheiros veteranos.", descSimple: "As pessoas sabem o que fazer, mas as dúvidas difíceis sempre dependem de poucos heróis." }
                  ].map((item, idx) => (
                    <div key={idx} className="bg-slate-50 border border-slate-200.5 p-3 rounded-xl flex flex-col justify-between">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-serif font-bold text-xs text-slate-800">
                          {isExpert ? item.dim : item.simpleTitle}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-[#C49746] font-mono">
                          Nota: {item.nota} / 10
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 italic leading-relaxed">
                        “{isExpert ? item.descExpert : item.descSimple}”
                      </p>
                    </div>
                  ))}
                </div>

                {isExpert ? (
                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-slate-650 mt-4 leading-relaxed text-xs">
                    <span className="text-[9px] font-mono font-black text-slate-500 uppercase block mb-1">Análise de Correlação Baseada no McKinsey 7S:</span>
                    O desalinhamento crítico entre <strong className="text-slate-800">Shared Values (Valores)</strong> e <strong className="text-slate-800">Systems/Structure (Processos e Sistemas)</strong> expõe a empresa a um desperdício oculto que dilapida cerca de <strong>1.2% da margem líquida industrial</strong> por meio de re-expedições e penalidades de atraso contratado.
                  </div>
                ) : (
                  <div className="bg-[#C49746]/5 border border-[#C49746]/10 p-3 rounded-lg text-slate-700 mt-4 text-xs">
                    <strong className="text-slate-900">Resumo Prático:</strong> A empresa é muito boa em planejar e sabe o que quer alcançar, mas falha na hora de documentar e deixar claro qual é o papel de cada colaborador nas tarefas diárias.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. PRINCIPAIS GAPS / DESALINHAMENTOS */}
          {activeSection === "gaps" && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">3. Principais Desalinhamentos</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Structural voids, authority overlapping and friction points</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm text-slate-700">
                <p className="leading-relaxed">
                  Ao cruzarmos os silos operacionais mapeados com a necessidade de entrega das encomendas, identificamos 3 fontes nítidas de ineficiência de governança:
                </p>

                <div className="space-y-3">
                  <div className="flex gap-2.5 bg-red-50/40 p-3.5 rounded-xl border border-red-100/70">
                    <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {isExpert ? "Duplicidade de Aprovação (Overlapping RACI)" : "Confusão e Donos Duplos"}
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed mt-1">
                        {isExpert 
                          ? "Há atividades onde existem dois Aprovadores (A) definidos simultaneamente na recepção industrial: Planejador de Produção e Supervisor de Turno. Isso causa morosidade tática por desencontro de alçadas."
                          : "Nas contratações adicionais de insumos para o sábado, duas pessoas tentam aprovar a mesma compra, gerando atraso e discussões sobre quem de fato tem a palavra final."}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2.5 bg-amber-50/45 p-3.5 rounded-xl border border-amber-100/60">
                    <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {isExpert ? "Gargalo por Centralização Crítica de Informações" : "Dependência Excessiva de Poucos Engenheiros"}
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed mt-1">
                        {isExpert
                          ? "Déficit de maturidade no nível 4 (Subprocessos) e ausência de base de conhecimento compartilhada geram intercorrências na passagem de informações. 80% das tomadas de decisão complexas param na mesa do presidente."
                          : "Se o engenheiro mais antigo pegar um resfriado ou não puder atender o telefone no sábado de manhã, a produção inteira do setor corre risco de paralisação técnica por falta de um roteiro operacional escrito."}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2.5 bg-blue-50/20 p-3.5 rounded-xl border border-blue-105/40">
                    <AlertTriangle className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {isExpert ? "Ausência de SLAs Acordados e Metas Diárias" : "Falta de Cobrança Clara"}
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed mt-1">
                        {isExpert
                          ? "O Mapeamento da Cadeia de Valor identificou que o plantão de sábado carece de metas individuais de produtividade desdobradas, gerando variabilidade de entrega de até 40% no volume produzido."
                          : "Como ninguém anotava o rendimento diário específico do time do sábado, os plantonistas apenas cumpriam hora sem foco em bater metas e sem saber se o dia foi produtivo ou não."}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. PRIORIDADES RECOMENDADAS */}
          {activeSection === "prioridades" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">4. Prioridades Recomendadas</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Systemic interventions and corrective roadmaps</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Para restaurar a integridade corporativa, definimos 4 pilares de ação sequenciais. Essas prioridades visam destravar os gargalos de fim de semana de forma rápida e sustentada:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                  <div className="bg-white border border-slate-205 p-4 rounded-xl space-y-2 hover:shadow-xs transition-shadow">
                    <div className="flex items-center gap-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="bg-[#C49746] text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-mono font-black text-[10px]">1</span>
                      {isExpert ? "Firmar SLAs na Matriz RACI" : "Definir Donos no Papel"}
                    </div>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {isExpert
                        ? "Mapear linearmente todos os envolvidos e registrar formalmente que haverá um único aprovador (A) por atividade, eliminando sobreposições jurídicas de autoridade."
                        : "Colocar de forma clara no papel exatamente quem faz, quem manda, quem apoia e quem apenas precisa ser informado de cada atividade do sábado."}
                    </p>
                  </div>

                  <div className="bg-white border border-slate-205 p-4 rounded-xl space-y-2 hover:shadow-xs transition-shadow">
                    <div className="flex items-center gap-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="bg-[#C49746] text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-mono font-black text-[10px]">2</span>
                      {isExpert ? "Sustentar Rituais de Prontidão Cultural" : "Treinar e Alinhar a Liderança"}
                    </div>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {isExpert
                        ? "Implementar comitês quinzenais de Gestão de Mudança baseados no ADKAR para colher feedbacks, mensurar focos de resistência ativa e pacificar o time."
                        : "Fazer reuniões curtas toda quinzena para escutar os problemas do time e alinhar os supervisores sobre os objetivos de ganho financeiro."}
                    </p>
                  </div>

                  <div className="bg-white border border-slate-205 p-4 rounded-xl space-y-2 hover:shadow-xs transition-shadow">
                    <div className="flex items-center gap-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="bg-[#C49746] text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-mono font-black text-[10px]">3</span>
                      {isExpert ? "Desdobrar OKRs de Capacidade" : "Desdobrar Metas de Produção"}
                    </div>
                    <p className="text-slate-650 text-xs leading-relaxed">
                      {isExpert
                        ? "Conectar a meta do Balanced Scorecard (Scorecard Financeiro) aos quadros táticos de OKR semanais nas áreas de usinagem e expedição de peças."
                        : "Mostrar para as equipes operacionais do sábado qual o volume mínimo esperado em cada etapa para garantir o bônus de expedição."}
                    </p>
                  </div>

                  <div className="bg-white border border-slate-205 p-4 rounded-xl space-y-2 hover:shadow-xs transition-shadow">
                    <div className="flex items-center gap-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="bg-[#C49746] text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-mono font-black text-[10px]">4</span>
                      {isExpert ? "Auditar Interfaces de Processo" : "Mapear Passagem de Bastão"}
                    </div>
                    <p className="text-slate-650 text-xs leading-relaxed">
                      {isExpert
                        ? "Definir padrões de passagem de turno baseados no SIPOC corporativo para mitigar quebras de histórico e assegurar integridade tática de dados."
                        : "Deixar uma ficha de passagem anotando quais máquinas estão prontas ou precisando de óleo para que o plantonista do sábado de manhã saiba exatamente como começar."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. ESTRATÉGIA E OBJETIVOS (BSC / OKR) */}
          {activeSection === "estrategia" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">5. Estratégia &amp; OKRs</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Connecting long term BSC perspectives with short term OKRs</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Para conectar o plano em longo prazo com a rotina diária operatória, o modelo de desdobramento estratégico unifica as métricas do negócio.
                </p>

                {isExpert ? (
                  <div className="space-y-4">
                    <h4 className="font-serif font-bold text-slate-900 text-xs tracking-wider uppercase border-l-2 border-[#C49746] pl-2">Perspectivas BSC Redesenhadas</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200.5">
                        <strong className="text-slate-900 text-xs">Financeira</strong>
                        <p className="text-[11px] text-slate-600 mt-1">Aumentar a margem líquida de expedição em 4.5% através do faturamento incremental aos sábados.</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200.5">
                        <strong className="text-slate-900 text-xs">Clientes</strong>
                        <p className="text-[11px] text-slate-600 mt-1">Garantir nível de SLA de entrega superior a 95.5% para os clientes automotivos prioritários na segunda-feira.</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200.5">
                        <strong className="text-slate-900 text-xs">Processos Internos</strong>
                        <p className="text-[11px] text-slate-600 mt-1">Padronizar o Mapeamento AS-IS/TO-BE e eliminar em 90% as quebras na passagem de turnos de engenharia.</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200.5">
                        <strong className="text-slate-900 text-xs">Aprendizado e Crescimento</strong>
                        <p className="text-[11px] text-slate-600 mt-1">Certificar 100% da equipe de plantão nos novos rituais de governança e matriz de autoridade tática.</p>
                      </div>
                    </div>

                    <h4 className="font-serif font-bold text-slate-900 text-xs tracking-wider uppercase border-l-2 border-slate-900 pl-2 mt-4">Painel de OKRs Táticos Relacionados</h4>
                    <div className="border border-slate-200 rounded-lg overflow-hidden font-mono text-[11px]">
                      <table className="w-full text-left">
                        <thead className="bg-slate-900 text-white uppercase text-[10px]">
                          <tr>
                            <th className="p-2.5">Objetivo / KR</th>
                            <th className="p-2.5">Responsável</th>
                            <th className="p-2.5">Prazo</th>
                            <th className="p-2.5">Progresso</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-250 text-slate-700">
                          <tr>
                            <td className="p-2.5"><strong className="text-slate-900">[OBJ] Maximizar Produtividade de Fim de Semana</strong></td>
                            <td className="p-2.5">Ger. Industrial</td>
                            <td className="p-2.5">T3 - 2026</td>
                            <td className="p-2.5 font-bold text-emerald-600">65%</td>
                          </tr>
                          <tr>
                            <td className="p-2.5 pl-6">KR 1. Realizar 100% das passagens de plantão com ficha técnica descrita</td>
                            <td className="p-2.5 text-slate-500">Superv. Produção</td>
                            <td className="p-2.5">Agosto</td>
                            <td className="p-2.5">80%</td>
                          </tr>
                          <tr>
                            <td className="p-2.5 pl-6">KR 2. Eliminar em 100% conflitos de aprovação duplicada de compras de insumos</td>
                            <td className="p-2.5 text-slate-500">Coord. Suprimentos</td>
                            <td className="p-2.5">Julho</td>
                            <td className="p-2.5">90%</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-slate-700 leading-relaxed">
                      Nosso rumo está estruturado em responder quatro perguntas simples com metas claras de crescimento:
                    </p>
                    <div className="space-y-3">
                      <div className="bg-slate-50 border border-slate-200.5 p-3.5 rounded-xl">
                        <p className="font-bold text-slate-900 text-xs sm:text-sm">O que queremos alcançar financeiramente?</p>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">Metas: Garantir faturamento adicional fabricando aos sábados e reduzindo despesas com frete expresso corretivo.</p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200.5 p-3.5 rounded-xl">
                        <p className="font-bold text-slate-900 text-xs sm:text-sm">Como sabermos que está dando certo de verdade?</p>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">Metas: Quando o volume de peças produzidas atingir 120 lotes semanais e as reclamações de atraso de grandes clientes zerarem.</p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200.5 p-3.5 rounded-xl">
                        <p className="font-bold text-slate-900 text-xs sm:text-sm">Quem é responsável real por cada meta estratégica?</p>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">Metas: O Gerente de Fábrica lidera a qualidade dos produtos, o Supervisor Administrativo foca na escala do time e o Diretor Geral cuida da margem financeira.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 6. ESTRUTURA E RESPONSABILIDADES (RACI) */}
          {activeSection === "estrutura" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <Network className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">6. Estrutura &amp; Responsabilidades</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Operations hierarchy alignment and RACI Matrix validation rules</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Sem a harmonia da estrutura operacional corporativa, a equipe sofre com cansaço excessivo e duplicações. Redefinimos o organograma para deixar claro quem lidera, quem executa taticamente e como mitigamos conflitos organizacionais.
                </p>

                {isExpert ? (
                  <div className="space-y-4">
                    <span className="text-[10px] font-mono font-black text-[#C49746] uppercase block">EXEMPLO DE MATRIZ RACI REFINADA DA OPERAÇÃO DE SÁBADO</span>
                    <div className="border border-slate-200 rounded-lg overflow-hidden font-mono text-[10.5px]">
                      <table className="w-full text-left">
                        <thead className="bg-[#C49746] text-slate-950 uppercase text-[9.5px]">
                          <tr>
                            <th className="p-2">Atividade Crítica</th>
                            <th className="p-2 text-center">Dir. Geral</th>
                            <th className="p-2 text-center">Ger. Prod</th>
                            <th className="p-2 text-center">Superv. Turno</th>
                            <th className="p-2 text-center">Eng. Plantonista</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 text-slate-700 bg-white">
                          <tr>
                            <td className="p-2 font-bold text-slate-900">Aprovar plano de produção semanal</td>
                            <td className="p-2 text-center font-bold text-amber-800">A</td>
                            <td className="p-2 text-center font-bold text-blue-700">R</td>
                            <td className="p-2 text-center">C</td>
                            <td className="p-2 text-center">I</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-bold text-slate-900">Autorizar compras urgentes de peças de reposição</td>
                            <td className="p-2 text-center">I</td>
                            <td className="p-2 text-center font-bold text-amber-800">A</td>
                            <td className="p-2 text-center">R</td>
                            <td className="p-2 text-center">C</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-bold text-slate-900">Liberar expedição física do sábado para estrada</td>
                            <td className="p-2 text-center">I</td>
                            <td className="p-2 text-center">C</td>
                            <td className="p-2 text-center font-bold text-amber-800 font-serif">A</td>
                            <td className="p-2 text-center font-bold text-blue-700">R</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <div className="bg-red-50/50 border-l-2 border-red-500 p-3 text-[11px] text-red-900 leading-relaxed font-mono">
                      <strong>Validação de Governança Estrita:</strong> A regra algorítmica de integridade impede que a atividade "Autorizar compras urgentes de peças de reposição" tenha mais de um avalista de nível A (Aprovador). Anteriormente, a empresa tolerava a co-aprovação do Diretor Geral e do Gerente de Produção, travando a aquisição de retentores sob parada de máquina por 5 horas adicionais de fila.
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-slate-700 leading-relaxed font-medium">As responsabilidades de fim de semana agora estão organizadas por três papéis claros:</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-lg">
                        <strong className="text-slate-900 block text-xs uppercase mb-1">Quem decide (Aprovador)</strong>
                        <p className="text-xs text-slate-650 leading-relaxed">O Supervisor do Turno de Sábado tem os direitos finais de carimbar saídas, autorizar remessas e lidar com urgências de funcionários.</p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-lg">
                        <strong className="text-slate-900 block text-xs uppercase mb-1">Quem faz (Responsável)</strong>
                        <p className="text-xs text-slate-650 leading-relaxed">Os Operadores de máquinas produzem de fato as peças e os Plantonistas de manutenção corrigem vazamentos físicos na hora.</p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-lg">
                        <strong className="text-slate-900 block text-xs uppercase mb-1">Quem deve ser informado</strong>
                        <p className="text-xs text-slate-650 leading-relaxed">O Diretor da Alfa S.A. é avisado automaticamente por relatório por e-mail no final da tarde, sem precisar parar seu descanso do fim de semana.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 7. PROCESSOS CRÍTICOS (VALOR, BOOTLENECK) */}
          {activeSection === "processos" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">7. Processos Críticos</h3>
                  <p className="text-[10px] text-slate-400 font-mono">BPMN process architecture, bottlenecks and value flow efficiency</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Para que a execução diária atinja alto nível, mapeamos a <strong>Cadeia de Valor</strong> de ponta a ponta e calculamos onde acontecem os congestionados desperdícios.
                </p>

                {isExpert ? (
                  <div className="space-y-4">
                    <h4 className="font-serif font-bold text-slate-900 text-xs tracking-wider uppercase border-l-2 border-[#C49746] pl-2">Análise Lean &amp; SIPOC / Tempos</h4>
                    
                    <div className="bg-slate-50 border border-slate-205 p-3 rounded-lg space-y-2">
                      <span className="text-[10px] font-mono font-black text-[#A17528] uppercase flex items-center gap-1">
                        Estágio Operacional Crítico: Tratamento Térmico &amp; Retífica
                      </span>
                      <p className="text-xs text-slate-650 leading-relaxed">
                        - <strong>Lead Time Atual (AS-IS):</strong> 48 horas totais integradas.<br />
                        - <strong>Tempo de Processamento Útil (NVA vs VA):</strong> 3.2 horas.<br />
                        - <strong>Eficiência de Ciclo (Process Cycle Efficiency):</strong> 6.6% (Crítico - indica excesso severo de estoques intermediários e filas reativas).
                      </p>
                    </div>

                    <div className="bg-white border border-slate-200.5 p-4 rounded-xl space-y-2 text-xs font-mono">
                      <span className="text-slate-900 font-bold block">[Simulação Estocástica de Teoria de Filas G/G/1]</span>
                      <p className="text-slate-600 leading-relaxed text-[11px]">
                        Sob regime de plantões de sábado, a variabilidade dos insumos gera picos de demanda estocástica na retífica. O fator de utilização média (ρ) sobe para <strong>92%</strong> por volta das 10h da manhã. O atraso de fila típico cresce exponencialmente devido ao acoplamento estocástico de setups não padronizados.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-slate-700 leading-relaxed">
                      O mapeamento dos fluxos revelou o exato local onde nossa operação atrasa:
                    </p>
                    <div className="bg-[#C49746]/5 p-4 rounded-xl border border-[#C49746]/10 space-y-2">
                      <p className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-[#C49746]" />
                        O Grande Gargalo: Passagem de Bastão do Turno da Manhã para o Turno da Tarde
                      </p>
                      <p className="text-xs text-slate-660 leading-relaxed">
                        Das 48 horas totais que levamos para expedir as peças, apenas <strong className="text-slate-900">3 horas</strong> são de trabalho útil de fato. As outras 45 horas consistem em esperas, máquinas paradas por falta de lubrificação correta ou material aguardando liberação de notas fiscais de forma manual.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 8. PLANO DE REORGANIZAÇÃO (KANBAN / 5W2H) */}
          {activeSection === "reorganizacao" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">8. Plano de Ação Estruturado</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Execution roadmap, 5W2H parameters and Kanban task board</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Para acionar essas intervenções, todas as recomendações de diagnóstico e governança foram consolidadas em ações estruturadoras sob o modelo unificado <strong>5W2H</strong>.
                </p>

                <div className="space-y-3 mt-2">
                  {[
                    { what: "Firmar termos de alçada únicos", why: "Eliminar duplicidade de aprovação tática", who: "Coord. Suprimentos", when: "Julho", how: "Assinatura mútua de SLAs sob regulação jurídica do ERP" },
                    { what: "Implementar rituais do comitê de mudança", why: "Dirimir resistência tática aos sábados", who: "Superv. Treinamento", when: "Agosto", how: "Pesquisas ADKAR e dinâmicas motivacionais de suporte" },
                    { what: "Publicar ficha oficial de passagem de turnos", why: "Acabar com falhas de histórico na troca", who: "Ger. Produção", when: "Julho", how: "Documentação escrita via rotina visual automatizada" }
                  ].map((act, idx) => (
                    <div key={idx} className="bg-slate-50 border border-slate-200.5 p-3.5 rounded-xl space-y-1.5 text-xs text-slate-700">
                      <div className="flex justify-between items-center border-b border-slate-205 pb-1">
                        <strong className="text-slate-900 text-xs sm:text-sm">{act.what}</strong>
                        <span className="font-mono text-[10px] font-bold text-slate-400">STATUS: EM ANDAMENTO</span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-slate-600 font-sans">
                        <div>
                          <p className="text-[9px] uppercase font-mono text-slate-400">Por Que?</p>
                          <p className="font-medium text-slate-800">{act.why}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase font-mono text-slate-400">Responsável</p>
                          <p className="font-bold text-[#C49746]">{act.who}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase font-mono text-slate-400">Prazo</p>
                          <p className="font-bold text-slate-850 flex items-center gap-1"><Calendar className="w-3.5 h-3.5 shrink-0" /> {act.when}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase font-mono text-slate-400">Como Fazer?</p>
                          <p className="text-slate-800 leading-tight">{act.how}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 9. RESULTADOS ESPERADOS & ROI */}
          {activeSection === "resultados" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">9. Resultados &amp; Retorno de Investimento</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Measurable gains, efficiency targets and ROI estimations</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm text-slate-700">
                <p className="leading-relaxed">
                  Os ganhos mapeados para Alfa S.A. são calculados matematicamente com base em desvios mensuráveis eliminados e na melhor satisfação do quadro de colaboradores plantonistas.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-2">
                  <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-850 space-y-1 text-center">
                    <span className="text-[10px] font-mono font-black uppercase tracking-tight text-[#C49746]">Investimento tático</span>
                    <p className="text-xl font-bold font-serif">R$ 15.000</p>
                    <p className="text-[11px] text-slate-400">Gastos com modelador BPMN, consultoria E3I e treinamentos específicos.</p>
                  </div>
                  <div className="bg-slate-50 border border-slate-200.5 p-4 rounded-xl space-y-1 text-center">
                    <span className="text-[10px] font-mono font-black uppercase text-[#C49746] tracking-tight">Retorno Mensal Estimado</span>
                    <p className="text-xl font-extrabold text-slate-900">R$ 48.000</p>
                    <p className="text-[11px] text-slate-550">Eliminação de fretes expressos, atrasos burocráticos e perda operacional.</p>
                  </div>
                  <div className="bg-slate-50 border border-slate-200.5 p-4 rounded-xl space-y-1 text-center">
                    <span className="text-[10px] font-mono font-black uppercase text-slate-400 tracking-tight">Tempo de Retorno (Payback)</span>
                    <p className="text-xl font-extrabold text-emerald-600">Sub 1 Mês</p>
                    <p className="text-[11px] text-slate-550">Compensação financeira imediata na primeira entrega automotiva pontual.</p>
                  </div>
                </div>

                {isExpert ? (
                  <div className="bg-white border border-slate-205 p-3.5 rounded-xl space-y-2 text-xs leading-relaxed font-mono">
                    <span className="text-slate-900 font-bold block">[ANÁLISE DE ROI MATEMÁTICO INTEGRADA E3I FOR COGNITIVE SYSTEM]</span>
                    <p className="text-[11px] text-slate-600">
                      Cálculo Dedutivo: ROI = ((Redução_Atraso * V_Faturamento_Sábado + Redução_Retrabalho * C_EngenheiroHour) - I_Consultoria) / I_Consultoria<br />
                      Ao mitigarmos os prazos excedidos, asseguramos um faturamento líquido estável de <strong>R$ 380 mil mensais por Turno Adicional de Sábado</strong> com zero elevação reativa de horas extras corretivas ou perdas por setup tardio.
                    </p>
                  </div>
                ) : (
                  <div className="bg-[#C49746]/5 p-3.5 rounded-xl border border-[#C49746]/15 text-xs text-slate-700 leading-relaxed font-sans">
                    <strong className="text-slate-900 block mb-1">Impacto nos Seus Resultados:</strong>
                    Toda reestruturação de processos do sábado se paga sozinha logo no primeiro mês. O investimento é irrisório se comparado ao alívio nas cobranças de atrasos por parte de nossos clientes prioritários automotivos de segunda-feira.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 10. PRÓXIMOS PASSOS RECOMMENDED */}
          {activeSection === "proximos-passos" && (
            <div className="space-y-4 animate-fade-in text-slate-750">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="bg-slate-900 text-[#C49746] p-2 rounded-lg">
                  <ArrowRight className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg text-slate-900 uppercase">10. Próximos Passos &amp; Recomendações</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Immediate actionable takeaways for both profiles</p>
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <p className="text-slate-650 leading-relaxed">
                  Para efetivar essa reorganização com êxito absoluto, a liderança executiva da Alfa S.A. deve seguir os seguintes passos práticos recomendados:
                </p>

                <div className="space-y-2">
                  <div className="flex items-start gap-2.5 bg-slate-50 border border-slate-200.5 p-3 rounded-lg leading-relaxed text-xs">
                    <CheckCircle2 className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 text-xs uppercase block">Passo 1: Assinatura dos Acordos de Alçada</strong>
                      Marcar uma reunião de 30 minutos na segunda-feira para colher e assinar formalmente os novos termos da Matriz RACI.
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 bg-slate-50 border border-slate-200.5 p-3 rounded-lg leading-relaxed text-xs">
                    <CheckCircle2 className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 text-xs uppercase block">Passo 2: Treinar as Equipes Operacionais</strong>
                      Apresentar aos operadores e mecânicos que farão plantão no sábado os novos fluxos visuais e passagens de bastão no papel.
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 bg-slate-50 border border-slate-200.5 p-3 rounded-lg leading-relaxed text-xs">
                    <CheckCircle2 className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 text-xs uppercase block">Passo 3: Acompanhamento de Campo (Gemba Walk)</strong>
                      Realizar visitas de supervisão nos dois primeiros sábados para monitorar a aderência aos indicadores desdobrados de capacidade.
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 text-[#C49746] p-4.5 rounded-xl border border-slate-800 space-y-2 mt-4 text-xs">
                  <div className="flex items-center gap-1.5 font-bold uppercase tracking-tight">
                    <Info className="w-4 h-4" />
                    Aprovação da Consultoria Técnica E3I
                  </div>
                  <p className="text-slate-300 leading-normal font-medium">
                    Declaramos que a Alfa S.A. encontra-se plenamente madura e tecnicamente balizada para operar em alta integrabilidade sob as novas recomendações e diretrizes de sábado apresentadas.
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* E3I INSIGHTS PANEL - ALWAYS REQUIRED TO HARMONIZE ACCORDING TO SYSTEM */}
      <E3IInsightPanel
        title="Relatório Executivo Integrado de Alinhamento C-Suite"
        businessExplanation="Este relatório conta a história da reorganização unindo cinco eixos cruciais (Suas metas táticas, o organograma, as tarefas diárias e a ajuda às pessoas). Ele garante uma leitura sequencial lógica para a aprovação dos acionistas de forma descomplicada."
        whyItMatters="Garante que novas regras difíceis (como plantões operacionais de sábado) entrem na rotina das pessoas sem causar greves, atrasos ou sobrecarga de poucos funcionários veteranos."
        nextAction="1. Use o sumário executivo acima para apresentar individualmente as frentes aos respectivos gerentes de departamento da Alfa S.A.
2. Ative o modo Especialista para debater as hipóteses de variabilidade logística com a equipe técnica de suprimentos e processos."
        frameworkName="Target Operating Model (TOM) + RACI Alignment Blueprint"
        technicalDetails={`Este painel de prestação de contas renderiza o desdobramento corporativo ligando as frentes simuladas em toda a aplicação. Especialistas em Reorganização Societária/Operacional (BPM/LSS) podem auditar o relatório para fins regulatórios ou de fusões e aquisições (M&A).`}
        mode={mode}
        className="mt-6 border border-slate-210 shadow-xs"
      />

      {/* OFF-SCREEN HIGH-FIDELITY PDF LAYOUT CONTAINER */}
      <div style={{ position: "absolute", left: "-9999px", top: "-9999px" }}>
        <div 
          id="enterprise-report-pdf-content" 
          className="w-[840px] bg-[#FAF9F6] text-slate-800 p-10 space-y-8 font-sans leading-relaxed"
        >
          {/* Cover Page / Header */}
          <div className="border-4 border-slate-900 bg-slate-900 text-white p-8 rounded-2xl space-y-6 shadow-sm">
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-mono font-black text-[#C49746] tracking-widest uppercase bg-slate-800 px-3 py-1.5 rounded border border-slate-700">
                E3I INTELLIGENCE GROUP
              </span>
              <span className="text-[10px] font-mono text-slate-400 font-bold">
                CONFIDENCIAL — REGISTRO DE AUDITORIA LSS
              </span>
            </div>
            
            <div className="space-y-2 pt-4">
              <h1 className="text-3xl font-serif font-black text-white leading-tight">
                Relatório de Reestruturação &amp;<br />Alinhamento Empresarial
              </h1>
              <p className="text-xs text-[#C49746] font-mono uppercase tracking-wider font-black">
                DIRETRIZ DE INTEGRABILIDADE — RELATÓRIO EXECUTIVO (AÇÃO 15)
              </p>
            </div>

            <div className="border-t border-dashed border-slate-700 my-4"></div>

            <div className="grid grid-cols-2 gap-4 text-xs pt-2 text-slate-300">
              <div>
                <p className="text-[9px] uppercase font-mono text-slate-500">Cliente Corporativo</p>
                <p className="font-bold text-white">Indústrias Metalúrgicas Alfa S.A.</p>
                <p className="text-[10px] text-slate-400">Planta de Fundição &amp; Usinagem Contínua</p>
              </div>
              <div>
                <p className="text-[9px] uppercase font-mono text-slate-500">Escopo da Intervenção</p>
                <p className="font-bold text-[#C49746]">Modelo Operacional Alvo (TOM) &amp; Acordo de Nível de Serviço (SLA) de Sábado</p>
                <p className="text-[10px] text-slate-400 font-mono">Data: 22 de Junho de 2026</p>
              </div>
            </div>
          </div>

          {/* Sumário & Metodologia */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
            <h3 className="font-serif font-bold text-slate-900 text-sm uppercase border-b border-slate-200 pb-2">
              Sumário Executivo &amp; Metodologia Unificada
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Este relatório executivo unifica as frentes de maturidade industrial, governança RACI, gestão de mudanças operacionais e o planejamento tático de médio prazo. A abordagem assegura a aderência das novas regras de plantão tático aos sábados de forma linear e transparente para o Comitê Executivo e acionistas (C-Suite).
            </p>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs text-slate-700 font-medium">
              <div className="flex items-center gap-1.5"><span className="text-[#C49746] font-bold">✔</span> McKinsey 7S Model para Diagnóstico</div>
              <div className="flex items-center gap-1.5"><span className="text-[#C49746] font-bold">✔</span> Balanced Scorecard (BSC) &amp; OKRs</div>
              <div className="flex items-center gap-1.5"><span className="text-[#C49746] font-bold">✔</span> Matriz RACI de Interfaces Críticas</div>
              <div className="flex items-center gap-1.5"><span className="text-[#C49746] font-bold">✔</span> Planejamento de Ação Estruturado 5W2H</div>
            </div>
          </div>

          {/* 1. Contexto */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>1. Contexto Estratégico</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">AS-IS</span>
            </h3>
            <p className="text-xs text-slate-700">
              A Alfa S.A. enfrenta um momento decisivo em seu crescimento de mercado. Com a necessidade emergente de rodar as fábricas e expedir lotes também aos <strong>sábados</strong>, surgiram desencontros organizacionais reativos: conflitos de autoridade, sobrecarga de engenheiros veteranos e intercorrências devido à falta de clareza nas responsabilidades operacionais mais simples. O objetivo principal é profissionalizar a governança da operação, eliminando redundâncias de comando.
            </p>
            {isExpert ? (
              <div className="bg-slate-900 text-slate-100 p-4 rounded-xl space-y-1.5 text-xs">
                <span className="text-[9px] font-mono font-black text-[#C49746] uppercase block">ANÁLISE DE PRONTIDÃO DO MODELO OPERACIONAL (TOM)</span>
                <p className="text-slate-300">
                  O Target Operating Model (TOM) atual carece de flexibilidade funcional estrita para acomodar o regime de compensações e as janelas reguladoras adicionais aos sábados. A ausência de regras organizativas claras impõe um custo de fricção diária de cerca de <strong>12% de retrabalho útil</strong> na herança de tarefas.
                </p>
              </div>
            ) : (
              <div className="bg-[#C49746]/5 border border-[#C49746]/20 p-4 rounded-xl text-xs">
                <span className="text-[10px] font-mono font-black text-[#A17528] uppercase block">PERSPECTIVA DO NEGÓCIO</span>
                <p className="text-slate-700 font-medium">
                  O nosso trabalho não está rendendo como deveria aos sábados porque a equipe se sente perdida sobre "quem decide o que". Isso gera estresse nas lideranças e atrasos que prejudicam as entregas de segunda-feira.
                </p>
              </div>
            )}
          </div>

          {/* 2. Diagnóstico McKinsey 7S */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>2. Diagnóstico da Maturidade</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">McKinsey 7S</span>
            </h3>
            <p className="text-xs text-slate-700">
              O diagnóstico mapeou a aderência de sete dimensões fundamentais que compõem o desempenho corporativo. O resultado apontou que a empresa possui clareza de rumo (Estratégia), mas carece de estabilidade metodológica diária (Processos, Governança e Indicadores).
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { dim: "Estratégia (Strategy)", simpleTitle: "Para onde rumamos?", nota: 8.5, descExpert: "Metas de portfólio claras, mas descoladas da governança de atividades rotineiras.", descSimple: "Temos o objetivo de crescimento claro na mente da diretoria." },
                { dim: "Estrutura (Structure)", simpleTitle: "Divisão de departamentos", nota: 7.0, descExpert: "Silos organizacionais acentuados e duplicidade de responsabilidade em compras de engenharia.", descSimple: "As divisões entre áreas funcionam, mas geram ruído nas transições de plantão." },
                { dim: "Sistemas (Systems)", simpleTitle: "Sistemas e Softwares", nota: 5.5, descExpert: "Subutilização de módulos de consolidação do ERP para tomada de decisão ágil.", descSimple: "Temos sistemas computacionais mas as informações continuam soltas no WhatsApp." },
                { dim: "Valores Compartilhados (Shared Values)", simpleTitle: "Cultura e Cooperação", nota: 7.2, descExpert: "Cultura resiliente e focada na qualidade, mas reativa a novos acordos de plantões corporativos.", descSimple: "O colaborador veste a camisa, mas fica amedrontado ao propor mudanças estruturais." },
                { dim: "Liderança (Staff/Style)", simpleTitle: "Atitudes e Pessoas", nota: 6.8, descExpert: "Liderança com perfil altamente paternalista e centralizadora no presidente da corporação.", descSimple: "Os gestores ajudam muito o time, mas acabam sobrecarregados por não delegarem." },
                { dim: "Família de Tarefas (Skills)", simpleTitle: "Competências Internas", nota: 6.0, descExpert: "Concentração extrema de know-how técnico em 3 engenheiros veteranos.", descSimple: "As pessoas sabem o que fazer, mas as dúvidas difíceis sempre dependem de poucos heróis." }
              ].map((item, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-200 p-3 rounded-lg flex flex-col justify-between text-xs">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-slate-800">{isExpert ? item.dim : item.simpleTitle}</span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-slate-900 text-[#C49746] font-mono">
                      {item.nota}/10
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 italic">“{isExpert ? item.descExpert : item.descSimple}”</p>
                </div>
              ))}
            </div>
          </div>

          {/* 3. Principais Desalinhamentos & Gaps Mapeados */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>3. Principais Desalinhamentos</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Gaps Mapeados</span>
            </h3>
            <div className="space-y-2 text-xs">
              <div className="p-3 bg-red-50/50 rounded-lg border border-red-100 flex gap-2">
                <span className="font-bold text-red-700 shrink-0">GAP A:</span>
                <div>
                  <strong className="text-slate-900 block">{isExpert ? "Duplicidade de Aprovação (Overlapping RACI)" : "Confusão e Donos Duplos"}</strong>
                  <span className="text-slate-650 text-[11px]">
                    {isExpert 
                      ? "Há atividades onde existem dois Aprovadores (A) definidos simultaneamente na recepção industrial, gerando sobreposições jurídicas e morosidade tática de alçadas."
                      : "Nas contratações adicionais de insumos para o sábado, duas pessoas tentam aprovar a mesma compra, gerando atraso e discussões."}
                  </span>
                </div>
              </div>
              <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-100 flex gap-2">
                <span className="font-bold text-amber-700 shrink-0">GAP B:</span>
                <div>
                  <strong className="text-slate-900 block">{isExpert ? "Gargalo por Centralização de Informações" : "Dependência Excessiva de Poucos Engenheiros"}</strong>
                  <span className="text-slate-650 text-[11px]">
                    {isExpert
                      ? "Falta de base de conhecimento compartilhada faz com que 80% das tomadas de decisão complexas dependam unicamente do comitê diretivo central."
                      : "Se o engenheiro mais experiente não puder atender o telefone no sábado, a produção corre risco de paralisação por falta de roteiro escrito."}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 4. Prioridades Recomendadas */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>4. Prioridades Recomendadas</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Pilha de Prioridades</span>
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 border border-slate-200 rounded-lg">
                <strong className="text-slate-900 block mb-1">1. {isExpert ? "Firmar SLAs na Matriz RACI" : "Definir Donos no Papel"}</strong>
                <p className="text-slate-600 text-[11px]">Mapear e registrar formalmente que haverá um único aprovador de nível (A) por atividade crítica da operação.</p>
              </div>
              <div className="p-3 border border-slate-200 rounded-lg">
                <strong className="text-slate-900 block mb-1">2. {isExpert ? "Sustentar Rituais de Prontidão" : "Treinar e Alinhar a Liderança"}</strong>
                <p className="text-slate-600 text-[11px]">Implementar rituais quinzenais para mensurar focos de resistência e dar suporte técnico-motivacional.</p>
              </div>
              <div className="p-3 border border-slate-200 rounded-lg">
                <strong className="text-slate-900 block mb-1">3. {isExpert ? "Desdobrar OKRs de Capacidade" : "Desdobrar Metas de Produção"}</strong>
                <p className="text-slate-600 text-[11px]">Conectar a meta do Scorecard Financeiro do sábado aos quadros de metas operacionais semanais.</p>
              </div>
              <div className="p-3 border border-slate-200 rounded-lg">
                <strong className="text-slate-900 block mb-1">4. {isExpert ? "Auditar Interfaces de Processo" : "Mapear Passagem de Bastão"}</strong>
                <p className="text-slate-600 text-[11px]">Instituir roteiros visuais formais e detalhados de passagem de plantão para manter a continuidade histórica.</p>
              </div>
            </div>
          </div>

          {/* 5. Estratégia e OKRs */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>5. Estratégia &amp; OKRs Táticos</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Desdobramento BSC</span>
            </h3>
            <p className="text-xs text-slate-700 mb-2">
              Desdobramento estratégico de longo prazo do Balanced Scorecard para indicadores práticos de OKR semanais:
            </p>
            <div className="border border-slate-200 rounded-lg overflow-hidden font-mono text-[10.5px]">
              <table className="w-full text-left">
                <thead className="bg-slate-900 text-white uppercase text-[9px]">
                  <tr>
                    <th className="p-2">Objetivo / KR</th>
                    <th className="p-2">Responsável</th>
                    <th className="p-2">Prazo</th>
                    <th className="p-2 text-right">Progresso</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700 bg-white">
                  <tr>
                    <td className="p-2"><strong>[OBJ] Maximizar Produtividade de Sábado</strong></td>
                    <td className="p-2 text-slate-950 font-bold">Gerente Industrial</td>
                    <td className="p-2">T3 - 2026</td>
                    <td className="p-2 text-right font-bold text-emerald-600">65%</td>
                  </tr>
                  <tr>
                    <td className="p-2 pl-4">KR 1. Realizar 100% das passagens de plantão escritas</td>
                    <td className="p-2">Supervisor Produção</td>
                    <td className="p-2">Agosto</td>
                    <td className="p-2 text-right">80%</td>
                  </tr>
                  <tr>
                    <td className="p-2 pl-4">KR 2. Eliminar em 100% conflitos de aprovação de compras</td>
                    <td className="p-2">Coord. Suprimentos</td>
                    <td className="p-2">Julho</td>
                    <td className="p-2 text-right">90%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 6. Estrutura & Responsabilidades (RACI) */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>6. Estrutura &amp; Responsabilidades</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Matriz RACI</span>
            </h3>
            <p className="text-xs text-slate-700 mb-2">
              O alinhamento estrito das responsabilidades operacionais assegura a pacificação do comitê de liderança técnica:
            </p>
            <div className="border border-slate-200 rounded-lg overflow-hidden font-mono text-[10.5px]">
              <table className="w-full text-left">
                <thead className="bg-[#C49746] text-slate-950 uppercase text-[9px]">
                  <tr>
                    <th className="p-2">Atividade Crítica</th>
                    <th className="p-2 text-center">Dir. Geral</th>
                    <th className="p-2 text-center">Ger. Prod</th>
                    <th className="p-2 text-center">Superv. Turno</th>
                    <th className="p-2 text-center">Eng. Plantonista</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700 bg-white">
                  <tr>
                    <td className="p-2 font-bold text-slate-900">Aprovar plano de produção semanal</td>
                    <td className="p-2 text-center font-bold text-amber-800">A</td>
                    <td className="p-2 text-center font-bold text-blue-700">R</td>
                    <td className="p-2 text-center font-mono">C</td>
                    <td className="p-2 text-center font-mono">I</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-bold text-slate-900">Autorizar compras urgentes de peças</td>
                    <td className="p-2 text-center font-mono">I</td>
                    <td className="p-2 text-center font-bold text-amber-800">A</td>
                    <td className="p-2 text-center font-mono">R</td>
                    <td className="p-2 text-center font-mono">C</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-bold text-slate-900">Liberar expedição física do sábado</td>
                    <td className="p-2 text-center font-mono">I</td>
                    <td className="p-2 text-center font-mono">C</td>
                    <td className="p-2 text-center font-bold text-amber-800">A</td>
                    <td className="p-2 text-center font-bold text-blue-700">R</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 7. Processos Críticos */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>7. Processos Críticos &amp; Gargalos</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Análise Lean</span>
            </h3>
            <p className="text-xs text-slate-700">
              Análise dos fluxos de valor de ponta a ponta e mapeamento do gargalo físico de passagem de turno:
            </p>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <span className="text-[10px] font-mono font-black text-slate-500 uppercase block">INDICADORES DE FLUXO LEAN</span>
                <p className="text-slate-700 font-medium leading-tight">
                  - Lead Time de Expedição: 48 horas totais.<br />
                  - Tempo Útil Real (Value Add): 3.2 horas.<br />
                  - Eficiência de Ciclo (PCE): 6.6% (Crítico - indica altos tempos de espera intermediários).
                </p>
              </div>
              <div className="p-4 bg-amber-50/30 border border-amber-200 rounded-lg space-y-1">
                <span className="text-[10px] font-mono font-black text-amber-800 uppercase block">TEORIA DE FILAS OPERACIONAL</span>
                <p className="text-slate-700 text-[11px] leading-tight">
                  Sob regime de sábado, a variabilidade na passagem de turnos gera picos estocásticos de fila na retífica. O fator de utilização de retífica sobe para 92%, disparando atrasos de setup.
                </p>
              </div>
            </div>
          </div>

          {/* 8. Plano de Ação (5W2H) */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>8. Plano de Ação Estruturado</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Matriz 5W2H</span>
            </h3>
            <div className="space-y-2">
              {[
                { what: "Firmar termos de alçada únicos", why: "Eliminar duplicidade de aprovação tática", who: "Coord. Suprimentos", when: "Julho", how: "Assinatura mútua de SLAs sob regulação jurídica do ERP" },
                { what: "Implementar rituais do comitê de mudança", why: "Dirimir resistência tática aos sábados", who: "Superv. Treinamento", when: "Agosto", how: "Pesquisas ADKAR e dinâmicas motivacionais de suporte" },
                { what: "Publicar ficha oficial de passagem de turnos", why: "Acabar com falhas de histórico na troca", who: "Ger. Produção", when: "Julho", how: "Documentação escrita via rotina visual automatizada" }
              ].map((act, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl text-xs space-y-1">
                  <div className="flex justify-between items-center border-b border-slate-200 pb-1">
                    <strong className="text-slate-900">{act.what}</strong>
                    <span className="text-[9px] font-mono font-bold text-slate-400">EM ANDAMENTO</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-[10px] text-slate-600">
                    <div>
                      <span className="text-[8px] font-mono uppercase text-slate-400 block">POR QUÊ?</span>
                      {act.why}
                    </div>
                    <div>
                      <span className="text-[8px] font-mono uppercase text-slate-400 block">QUEM?</span>
                      <strong className="text-[#C49746]">{act.who}</strong>
                    </div>
                    <div>
                      <span className="text-[8px] font-mono uppercase text-slate-400 block">QUANDO?</span>
                      {act.when}
                    </div>
                    <div>
                      <span className="text-[8px] font-mono uppercase text-slate-400 block">COMO?</span>
                      {act.how}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 9. Resultados & ROI */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-3">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>9. Resultados &amp; Retorno de Investimento (ROI)</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Viabilidade</span>
            </h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-slate-900 text-white p-3 rounded-lg border border-slate-800">
                <span className="text-[9px] font-mono uppercase text-[#C49746] block">INVESTIMENTO TÁTICO</span>
                <span className="text-base font-bold font-serif">R$ 15.000</span>
                <p className="text-[10px] text-slate-400 mt-1">Modeladores BPMN e treinamento.</p>
              </div>
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                <span className="text-[9px] font-mono uppercase text-slate-500 block">RETORNO MENSAL</span>
                <span className="text-base font-bold text-slate-900">R$ 48.000</span>
                <p className="text-[10px] text-slate-500 mt-1">Gargalos eliminados.</p>
              </div>
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                <span className="text-[9px] font-mono uppercase text-slate-500 block">PAYBACK ESTIMADO</span>
                <span className="text-base font-bold text-emerald-600">Sub 1 Mês</span>
                <p className="text-[10px] text-slate-500 mt-1">Retorno imediato.</p>
              </div>
            </div>
            {isExpert && (
              <div className="bg-white border border-slate-200 p-3 rounded-lg font-mono text-[10px] text-slate-650 leading-relaxed">
                <strong>FÓRMULA DO ROI OPERACIONAL UNIFICADO:</strong><br />
                ROI = ((Redução_Atraso * V_Faturamento_Sábado + Redução_Retrabalho * C_EngenheiroHour) - I_Consultoria) / I_Consultoria.
                Ao mitigar os desvios, asseguramos um faturamento líquido estável de <strong>R$ 380 mil mensais por Turno de Sábado</strong> com zero elevação de custos extras corretivos.
              </div>
            )}
          </div>

          {/* 10. Próximos Passos */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-4">
            <h3 className="font-serif font-black text-sm text-slate-900 uppercase border-b border-slate-200 pb-2 flex justify-between">
              <span>10. Próximos Passos &amp; Recomendações</span>
              <span className="text-[10px] text-slate-400 font-mono normal-case">Roadmap</span>
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2 bg-slate-50 p-3 rounded-lg">
                <span className="text-[#C49746] font-bold">✔</span>
                <div>
                  <strong className="text-slate-900">Passo 1: Assinatura dos Acordos de Alçada</strong>
                  <p className="text-slate-600 text-[11px] mt-0.5">Marcar uma reunião de 30 minutos na segunda-feira para oficializar e pactuar os termos da Matriz RACI.</p>
                </div>
              </div>
              <div className="flex items-start gap-2 bg-slate-50 p-3 rounded-lg">
                <span className="text-[#C49746] font-bold">✔</span>
                <div>
                  <strong className="text-slate-900">Passo 2: Treinar as Equipes Operacionais</strong>
                  <p className="text-slate-600 text-[11px] mt-0.5">Apresentar aos operadores os novos fluxos visuais de passagem de bastão de turno.</p>
                </div>
              </div>
              <div className="flex items-start gap-2 bg-slate-50 p-3 rounded-lg">
                <span className="text-[#C49746] font-bold">✔</span>
                <div>
                  <strong className="text-slate-900">Passo 3: Acompanhamento de Campo (Gemba Walk)</strong>
                  <p className="text-slate-600 text-[11px] mt-0.5">Realizar visitas de campo nos dois primeiros sábados para auditar os tempos de ciclo e o PCE.</p>
                </div>
              </div>
            </div>

            {/* Approval Footer */}
            <div className="mt-8 border-t border-dashed border-slate-300 pt-6 flex justify-between items-center text-xs">
              <div>
                <p className="font-bold text-slate-900">E3I Intelligence Group</p>
                <p className="text-slate-450 font-mono text-[10px]">Consultoria em Reorganização Societária &amp; Processos</p>
              </div>
              <div className="border border-emerald-500 bg-emerald-50 text-emerald-800 rounded px-4 py-2 font-mono text-[10px] text-center font-bold tracking-tight shadow-3xs">
                Aprovado para Certificação LSS<br />
                <span className="text-emerald-600 font-mono text-[9px]">C-SUITE ALIGNMENT STAMP</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
