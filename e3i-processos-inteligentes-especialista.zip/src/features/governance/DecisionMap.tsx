import React from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  GitBranch, 
  Wallet, 
  HelpCircle, 
  ShieldCheck, 
  Compass, 
  CheckSquare, 
  CheckCircle,
  Users,
  Building
} from "lucide-react";

export interface DecisionLevel {
  id: string;
  levelSimple: string;
  levelTechnical: string;
  ownerSimple: string;
  ownerTechnical: string;
  financialLimit: string;
  examplesSimple: string[];
  examplesTechnical: string[];
}

export interface DecisionMapProps {
  mode: UsabilityMode;
}

export default function DecisionMap({
  mode
}: DecisionMapProps) {
  const isExpert = isExpertMode(mode);

  const decisionLevels: DecisionLevel[] = [
    {
      id: "level_1",
      levelSimple: "Nível 1: Decisões de Rotina Geral (In loco)",
      levelTechnical: "Nível Operacional (Decentralized Local Autonomy)",
      ownerSimple: "Ajudantes, Caixa e Vendedores",
      ownerTechnical: "Front-line Executors & Field Sales Operators",
      financialLimit: "Até R$ 200 por evento",
      examplesSimple: [
        "Estornar um erro pequeno de produto para o cliente",
        "Trocar mercadoria com pequeno defeito físico de fábrica",
        "Pagar a entrega do toner de impressão urgente"
      ],
      examplesTechnical: [
        "Aprovação de RMA padrão em garantia primária",
        "Contratação pontual de fretes spot de emergência de baixo valor",
        "Substituição imediata de insumo de escritório em falta imediata"
      ]
    },
    {
      id: "level_2",
      levelSimple: "Nível 2: Decisões Gerais de Área (Tático)",
      levelTechnical: "Nível Tático (Functional Coordination Level)",
      ownerSimple: "Gerentes e Supervisores",
      ownerTechnical: "Business Unit Heads & Department Leads",
      financialLimit: "Até R$ 2.500 por mês",
      examplesSimple: [
        "Contratar folguista ou freelancer para cobrir final de semana",
        "Dar descontos comerciais maiores no atacado",
        "Comprar consertos ou reparos de ar condicionado"
      ],
      examplesTechnical: [
        "Aprovação de desconto comercial fora da tabela padrão (SLA 5%)",
        "Aprovação de horas extras pontuais para cumprimento de metas táticas",
        "Autorização de manutenção preventiva de ativos operacionais"
      ]
    },
    {
      id: "level_3",
      levelSimple: "Nível 3: Rumo da Empresa e Grandes Gastos (Estratégico)",
      levelTechnical: "Nível Diretivo e de Capital (Strategic Board Investment)",
      ownerSimple: "Dono / Sócios Fundadores",
      ownerTechnical: "Chief Executives & Board of Directors (CEO/CFO)",
      financialLimit: "Sem limite financeiro",
      examplesSimple: [
        "Mudar o local físico do galpão ou escritório",
        "Contratar ou demitir cargos de alta chefia",
        "Comprar maquinários novos de alto custo"
      ],
      examplesTechnical: [
        "Aprovação de investimentos CAPEX não contemplados no budget anual",
        "Formulação e alteração da estrutura hierárquica organizacional",
        "Validação final de acordos comerciais de fusão ou contratos de exclusividade"
      ]
    }
  ];

  return (
    <div id="decision-map-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Matriz de Alçadas & Matriz de Delegação" : "Quem Pode Decidir O Quê?"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Evite que gargalos burocráticos sobrecarreguem os fundadores definindo tetos claros de gastos e autonomia financeira." 
              : "Defina limites de dinheiro e de responsabilidade para os funcionários resolverem problemas sozinhos sem ligar para o dono toda hora."}
          </p>
        </div>

        <span className="text-[10px] font-mono bg-slate-900 text-slate-200 px-2.5 py-1 rounded font-black tracking-wider uppercase">
          DELEGATION MATRIX
        </span>
      </div>

      {/* COMPACT METHODOLOGY INFOPANEL */}
      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4" /> Por que dividir as Decisões em Alçadas?
          </span>
          <p className="text-xs text-slate-650 leading-relaxed">
            Se tudo depender do dono da empresa (inclusive resolver um problema de R$ 30 de um cliente), a empresa fica lenta e os sócios não têm tempo para pensar em estratégias de crescimento e vendas.
          </p>
        </div>
      )}

      {/* DECISIONS TIMELINE */}
      <div className="space-y-6 relative before:absolute before:top-4 before:bottom-4 before:left-5 before:w-0.5 before:bg-slate-200">
        {decisionLevels.map((level, index) => (
          <div 
            key={level.id}
            id={`decision-level-${level.id}`}
            className="flex items-start gap-4 relative"
          >
            {/* Index badge */}
            <div className="w-10 h-10 rounded-full bg-slate-100 border-2 border-[#C49746] flex items-center justify-center text-xs font-black font-mono shrink-0 z-10 text-slate-900 group">
              0{index + 1}
            </div>

            {/* Content card */}
            <div className="bg-slate-50 border border-slate-200 hover:border-amber-200 rounded-xl p-4 md:p-5 w-full space-y-4">
              
              {/* Card Title & Salary Threshold */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                <h4 className="text-xs font-black uppercase text-slate-900 font-sans tracking-wide">
                  {isExpert ? level.levelTechnical : level.levelSimple}
                </h4>
                
                <div className="flex items-center gap-1 text-xs shrink-0 bg-amber-500/10 border border-amber-500/20 text-[#A37B34] px-2.5 py-0.5 rounded-full font-bold">
                  <Wallet className="w-3.5 h-3.5" />
                  <span>Limite Financeiro: {level.financialLimit}</span>
                </div>
              </div>

              {/* Roles responsible */}
              <div className="text-xs space-y-0.5">
                <span className="text-[9px] font-mono text-slate-400 font-black uppercase tracking-widest block">Quem é dono desse nível?</span>
                <p className="text-slate-800 font-extrabold">
                  {isExpert ? level.ownerTechnical : level.ownerSimple}
                </p>
              </div>

              {/* Examples */}
              <div className="space-y-2 pt-2 border-t border-dashed border-slate-200">
                <span className="text-[10px] font-mono text-slate-450 uppercase tracking-widest block font-extrabold">Exemplos Práticos</span>
                
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11.5px] leading-relaxed text-slate-650">
                  {(isExpert ? level.examplesTechnical : level.examplesSimple).map((ex, i) => (
                    <li key={i} className="flex items-start gap-1.5 pl-1">
                      <span className="text-[#C49746] font-bold mt-0.5">•</span>
                      <span>{ex}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
