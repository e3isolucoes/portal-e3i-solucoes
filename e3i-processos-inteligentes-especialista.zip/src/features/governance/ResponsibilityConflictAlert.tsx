import React from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { GovernanceAlert } from "../../domain/enterprise-architecture/raciEngine";
import { 
  AlertTriangle, 
  HelpCircle, 
  ShieldAlert, 
  Info, 
  CheckCircle,
  Lightbulb,
  ArrowRight
} from "lucide-react";

export interface ResponsibilityConflictAlertProps {
  mode: UsabilityMode;
  alerts: GovernanceAlert[];
  onFixAlert?: (alert: GovernanceAlert) => void;
}

export default function ResponsibilityConflictAlert({
  mode,
  alerts,
  onFixAlert
}: ResponsibilityConflictAlertProps) {
  const isExpert = isExpertMode(mode);

  const criticalAlerts = alerts.filter(a => a.severity === "critical");
  const warningAlerts = alerts.filter(a => a.severity === "warning");

  return (
    <div id="responsibility-conflict-alert-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="space-y-0.5">
          <h4 className="text-sm font-black uppercase text-slate-900 tracking-wide flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-600 animate-pulse" />
            {isExpert ? "Auditoria Automática de Conformidade de Governança" : "Alertas de Confusão ou Tarefas Sem Dono"}
          </h4>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Algoritmo tático avalia conflitos de dupla chefia, vácuo de tomadores de decisão e silos consultivos de baixa eficiência." 
              : "Nosso sistema analisou suas atividades e encontrou algumas falhas que causam brigas ou atrasos."}
          </p>
        </div>
        
        <span className="text-[10px] font-mono bg-red-50 text-red-700 border border-red-200 px-2 py-0.5 rounded font-black">
          {alerts.length} ALERTA(S)
        </span>
      </div>

      {alerts.length === 0 ? (
        <div className="bg-emerald-50 border border-emerald-200/60 p-5 rounded-xl flex items-center gap-3.5">
          <div className="p-2 bg-emerald-100 text-emerald-700 rounded-full">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <h5 className="text-xs font-black text-emerald-900 uppercase">Sua Governança está Perfeita!</h5>
            <p className="text-[11.5px] text-emerald-700 mt-0.5">
              Nenhum conflito de alçada, comando duplo ou tarefa abandonada foi detectado nos processos ativos.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          
          {/* CRITICAL ALERTS GROUP */}
          {criticalAlerts.length > 0 && (
            <div className="space-y-3">
              <span className="text-[10px] font-mono font-black text-red-600 uppercase tracking-widest block">
                🚨 Erros Críticos de Estrutura (Corrigir Urgente)
              </span>

              <div className="space-y-2.5">
                {criticalAlerts.map((alert) => (
                  <div 
                    key={alert.id}
                    className="border border-red-200/90 bg-red-50/20 p-4 rounded-xl space-y-3 relative overflow-hidden"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono font-bold bg-red-100 text-red-800 px-1.5 py-0.5 rounded">
                          Atividade: {alert.activityName}
                        </span>
                        <h5 className="text-xs font-extrabold text-slate-900 mt-1">
                          {isExpert ? alert.messageTechnical : alert.messageSimple}
                        </h5>
                      </div>

                      {onFixAlert && (
                        <button
                          type="button"
                          onClick={() => onFixAlert(alert)}
                          className="text-[10px] font-sans font-bold bg-red-600 hover:bg-red-700 text-white px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 uppercase tracking-wide"
                        >
                          Resolver Agora
                        </button>
                      )}
                    </div>

                    {/* Technical Advisory Panel */}
                    <div className="bg-white/80 border border-red-200/40 p-2.5 rounded-lg text-xs flex items-start gap-1.5">
                      <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[9px] font-mono font-bold text-slate-450 uppercase block">Recomendação do Consultor:</span>
                        <p className="text-slate-700 font-medium mt-0.5 leading-snug">
                          {isExpert ? alert.recommendationTechnical : alert.recommendationSimple}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* WARNING ALERTS GROUP */}
          {warningAlerts.length > 0 && (
            <div className="space-y-3 pt-2">
              <span className="text-[10px] font-mono font-black text-amber-600 uppercase tracking-widest block">
                ⚡ Avisos de Lentidão e Risco Tático
              </span>

              <div className="space-y-2.5">
                {warningAlerts.map((alert) => (
                  <div 
                    key={alert.id}
                    className="border border-amber-200/90 bg-amber-50/10 p-4 rounded-xl space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                          Atividade: {alert.activityName}
                        </span>
                        <h5 className="text-xs font-extrabold text-slate-900 mt-1">
                          {isExpert ? alert.messageTechnical : alert.messageSimple}
                        </h5>
                      </div>

                      {onFixAlert && (
                        <button
                          type="button"
                          onClick={() => onFixAlert(alert)}
                          className="text-[10px] font-sans font-bold bg-[#S49746] hover:bg-amber-600 bg-[#C49746] text-white px-2.5 py-1 rounded transition-colors cursor-pointer shrink-0 uppercase tracking-wide"
                        >
                          Ajustar Papel
                        </button>
                      )}
                    </div>

                    {/* Advisory */}
                    <div className="bg-white/80 border border-amber-200/40 p-2.5 rounded-lg text-xs flex items-start gap-1.5">
                      <Lightbulb className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[9px] font-mono font-bold text-slate-450 uppercase block">Recomendação do Consultor:</span>
                        <p className="text-slate-700 font-medium mt-0.5 leading-snug">
                          {isExpert ? alert.recommendationTechnical : alert.recommendationSimple}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* QUICK METHODOLOGICAL NOTE */}
      {isSimpleMode(mode) && (
        <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl text-xs space-y-2.5 text-slate-650">
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wide font-black flex items-center gap-1">
            <HelpCircle className="w-4 h-4 text-slate-400" /> Como evitar brigas em sua equipe de uma vez por todas?
          </span>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] leading-relaxed">
            <div>
              <p className="font-extrabold text-slate-800">Apenas um Aprovador:</p>
              <p>Múltiplas pessoas mandando na mesma tarefa gera paralisia ou ordens cruzadas. Designe apenas um líder definitivo.</p>
            </div>
            <div>
              <p className="font-extrabold text-slate-800">Corte Reuniões Desnecessárias:</p>
              <p>Ouvir pessoas demais (Consultados) para decidir coisas cotidianas gera lentidão burocrática absurda no dia a dia.</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
