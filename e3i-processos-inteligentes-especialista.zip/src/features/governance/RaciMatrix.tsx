import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { RaciItem, analyzeRaciItem, GovernanceAlert } from "../../domain/enterprise-architecture/raciEngine";
import EmptyState from "../../components/EmptyState";
import { 
  Users, 
  HelpCircle, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  CheckCircle, 
  ChevronRight,
  Info,
  Edit2,
  Check,
  Briefcase
} from "lucide-react";

export interface RaciMatrixProps {
  mode: UsabilityMode;
  onAlertsChange?: (alerts: GovernanceAlert[]) => void;
  openTemplatesHub?: () => void;
}

const INITIAL_RACI: RaciItem[] = [
  {
    id: "raci_1",
    activityName: "Fechamento de Caixa Diário",
    responsible: ["Auxiliar Financeiro"],
    accountable: ["Dono da Empresa"],
    consulted: ["Líder de Vendas"],
    informed: ["Contabilidade Externa"],
    criticality: "alta"
  },
  {
    id: "raci_2",
    activityName: "Dar Desconto Maior que 10% para fechar Venda",
    responsible: ["Vendedor Comercial"],
    accountable: ["Dono da Empresa", "Gerente Financeiro"], // Conflict: Two accountables!
    consulted: [],
    informed: ["Auxiliar Financeiro"],
    criticality: "alta"
  },
  {
    id: "raci_3",
    activityName: "Limpeza Geral das Prateleiras e Balcão",
    responsible: [], // Lacuna: No responsible!
    accountable: ["Supervisor de Operações"],
    consulted: [],
    informed: [],
    criticality: "baixa"
  },
  {
    id: "raci_4",
    activityName: "Definir Promoção de Black Friday",
    responsible: ["Líder de Vendas"],
    accountable: ["Dono da Empresa"],
    consulted: ["Líder de Vendas", "Supervisor de Operações", "Estoquista", "Auxiliar Financeiro"], // Overload C
    informed: ["Todos os Colaboradores"],
    criticality: "media"
  },
  {
    id: "raci_5",
    activityName: "Pagar Contas de Clientes no Banco",
    responsible: ["Auxiliar Financeiro"],
    accountable: ["Auxiliar Financeiro"], // Risk: Junior is Accountable for high importance
    consulted: [],
    informed: ["Dono da Empresa"],
    criticality: "alta"
  }
];

export default function RaciMatrix({
  mode,
  onAlertsChange,
  openTemplatesHub
}: RaciMatrixProps) {
  const isExpert = isExpertMode(mode);
  const [raciList, setRaciList] = useState<RaciItem[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("lss_raci_list");
      if (saved) {
        try { return JSON.parse(saved); } catch (e) { console.error(e); }
      }
    }
    return INITIAL_RACI;
  });

  React.useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_raci_list", JSON.stringify(raciList));
    }
  }, [raciList]);
  const [newActivityName, setNewActivityName] = useState("");
  const [newCriticality, setNewCriticality] = useState<RaciItem["criticality"]>("media");

  // Inline inputs for editing/modifying allocations quickly
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editR, setEditR] = useState("");
  const [editA, setEditA] = useState("");
  const [editC, setEditC] = useState("");
  const [editI, setEditI] = useState("");

  // Recalculate alerts
  const allAlerts = raciList.flatMap(analyzeRaciItem);

  // Expose updates to parent page so alerts are synchronized automatically 
  React.useEffect(() => {
    if (onAlertsChange) {
      onAlertsChange(allAlerts);
    }
  }, [raciList]);

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActivityName.trim()) return;

    const newItem: RaciItem = {
      id: `raci_custom_${Date.now()}`,
      activityName: newActivityName,
      responsible: [],
      accountable: [],
      consulted: [],
      informed: [],
      criticality: newCriticality
    };

    setRaciList([...raciList, newItem]);
    setNewActivityName("");
  };

  const handleDeleteActivity = (id: string) => {
    if (confirm("Gostaria de remover esta atividade da Matriz RACI?")) {
      setRaciList(raciList.filter(item => item.id !== id));
    }
  };

  const handleStartEdit = (item: RaciItem) => {
    setEditingItemId(item.id);
    setEditR(item.responsible.join(", "));
    setEditA(item.accountable.join(", "));
    setEditC(item.consulted.join(", "));
    setEditI(item.informed.join(", "));
  };

  const handleSaveEdit = (id: string) => {
    setRaciList(raciList.map(item => {
      if (item.id === id) {
        return {
          ...item,
          responsible: editR ? editR.split(",").map(s => s.trim()) : [],
          accountable: editA ? editA.split(",").map(s => s.trim()) : [],
          consulted: editC ? editC.split(",").map(s => s.trim()) : [],
          informed: editI ? editI.split(",").map(s => s.trim()) : []
        };
      }
      return item;
    }));
    setEditingItemId(null);
  };

  return (
    <div id="raci-matrix-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Users className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Matriz RACI - Repartição de Responsabilidade Linha por Linha" : "Quem faz o que nas Atividades?"}
          </h3>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Regule de forma categórica as obrigações operacionais: Quem executa (R), quem possui legitimidade final (A), quem assessora (C) e quem recebe relatórios (I)." 
              : "Defina de modo rápido os papéis para cada tarefa diária da sua empresa."}
          </p>
        </div>

        {isSimpleMode(mode) && (
          <div className="text-[11px] text-amber-800 font-bold bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg max-w-sm shrink-0">
            💡 <b>R</b>esponsável (faz) • <b>A</b>provador (aprova) • <b>C</b>onsultado • <b>I</b>nformado
          </div>
        )}
      </div>

      {/* QUICK METHODOLOGICAL DESCRIPTION */}
      {isSimpleMode(mode) && (
        <p className="text-xs text-slate-650 leading-relaxed bg-[#FAF9F5]/40 p-3 rounded-lg border border-amber-100 italic">
          "Esta matriz mostra quem faz, quem aprova, quem precisa ser ouvido e quem precisa ser informado de modo visual, eliminando o estigma do 'pensei que fulano ia fazer'."
        </p>
      )}

      {/* ADD ACTIVITY INLINE FORM */}
      <form onSubmit={handleAddActivity} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row gap-3 items-end">
        <div className="w-full">
          <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">Cadastrar Atividade na Matriz</label>
          <input 
            type="text" 
            required
            placeholder="Ex: Confecção e envio de boleto ao cliente..."
            value={newActivityName}
            onChange={e => setNewActivityName(e.target.value)}
            className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
          />
        </div>
        <div className="shrink-0 w-full sm:w-40">
          <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">Importância</label>
          <select 
            value={newCriticality}
            onChange={e => setNewCriticality(e.target.value as RaciItem["criticality"])}
            className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
          >
            <option value="alta">Alta</option>
            <option value="media">Média</option>
            <option value="baixa">Baixa</option>
          </select>
        </div>
        <div className="flex gap-2 shrink-0 w-full sm:w-auto">
          <button 
            type="submit"
            className="bg-slate-900 text-white font-sans text-xs font-bold py-2 px-4 rounded-lg shrink-0 w-full sm:w-auto h-[38px] hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Adicionar
          </button>
          {raciList.length > 0 && (
            <button 
              type="button"
              onClick={() => setRaciList([])}
              className="border border-red-200 text-red-650 bg-white font-sans text-xs font-bold py-2 px-4 rounded-lg shrink-0 w-full sm:w-auto h-[38px] hover:bg-red-50 transition-colors cursor-pointer"
            >
              Limpar Tudo
            </button>
          )}
        </div>
      </form>

      {raciList.length === 0 ? (
        <EmptyState 
          type="no_raci"
          primaryAction={{
            label: "Criar matriz RACI",
            onClick: () => {
              const defaultItem: RaciItem = {
                id: "raci_1",
                activityName: "Fechamento de Caixa Diário",
                responsible: ["Auxiliar Financeiro"],
                accountable: ["Dono da Empresa"],
                consulted: ["Gerente Comercial"],
                informed: ["Contabilidade"],
                criticality: "alta"
              };
              setRaciList([defaultItem]);
            }
          }}
          secondaryAction={{
            label: "Gerar a partir de processos",
            onClick: () => {
              setRaciList(INITIAL_RACI);
            }
          }}
          tertiaryAction={openTemplatesHub ? {
            label: "Templates por Segmento",
            onClick: openTemplatesHub
          } : undefined}
        />
      ) : (
        /* SPREADSHEET TABLE GRID CONTAINER */
        <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-3xs max-w-full">
        <table className="w-full text-xs border-collapse bg-white">
          <thead>
            <tr className="bg-slate-900 text-slate-100 font-mono tracking-wider font-extrabold uppercase border-b border-slate-800 text-left">
              <th className="p-3.5 pl-4 w-1/4">Atividade / Processo</th>
              <th className="p-3.5 text-center bg-blue-900/10 text-slate-900 border-x border-slate-200">
                Responsável (R) <br />
                <span className="text-[10px] lowercase text-slate-500 font-normal">Executa o trabalho</span>
              </th>
              <th className="p-3.5 text-center bg-purple-900/10 text-slate-900 border-x border-slate-200">
                Aprovador (A) <br />
                <span className="text-[10px] lowercase text-slate-500 font-normal">Aprova a entrega</span>
              </th>
              <th className="p-3.5 text-center bg-amber-900/10 text-slate-900 border-x border-slate-200">
                Consultado (C) <br />
                <span className="text-[10px] lowercase text-slate-500 font-normal">Ouve opiniões</span>
              </th>
              <th className="p-3.5 text-center bg-emerald-950/10 text-slate-900 border-x border-slate-200">
                Informado (I) <br />
                <span className="text-[10px] lowercase text-slate-500 font-normal">Fica sabendo</span>
              </th>
              <th className="p-3.5 text-center w-[110px]">Ações</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-150">
            {raciList.map((item) => {
              const isEditing = editingItemId === item.id;
              const hasAlerts = analyzeRaciItem(item).length > 0;

              return (
                <tr 
                  key={item.id}
                  id={`raci-row-${item.id}`}
                  className={`${hasAlerts ? "bg-amber-500/[0.02]" : "hover:bg-slate-50/50"}`}
                >
                  {/* Activity and diagnostic alerts */}
                  <td className="p-3.5 pl-4 font-black text-slate-900 font-sans space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span>{item.activityName}</span>
                      <span className={`text-[8px] font-mono font-bold uppercase px-1.5 rounded ${
                        item.criticality === "alta" ? "bg-red-100 text-red-700" :
                        item.criticality === "media" ? "bg-amber-100 text-amber-700" :
                        "bg-slate-100 text-slate-650"
                      }`}>
                        {item.criticality}
                      </span>
                    </div>

                    {/* Inline small alerts notification for expert audits */}
                    {hasAlerts && (
                      <div className="text-[10px] text-red-600 font-bold bg-ref-50 border border-red-200 p-1.5 rounded flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                        <span>Falta preencher dono ou há conflito ativo. Ver guia "Alertas"</span>
                      </div>
                    )}
                  </td>

                  {/* R: Responsible */}
                  <td className="p-3 bg-blue-900/[0.01] border-x border-slate-200 text-center">
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editR}
                        onChange={e => setEditR(e.target.value)}
                        placeholder="Cargos separados por vírgula..."
                        className="w-full text-xs p-1 border rounded bg-white text-slate-900"
                      />
                    ) : (
                      <div className="flex flex-col gap-1 items-center">
                        {item.responsible.length > 0 ? item.responsible.map((r, idx) => (
                          <span key={idx} className="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded text-[10.5px]">
                            {r}
                          </span>
                        )) : (
                          <span className="text-[10px] text-red-500 font-extrabold bg-red-50 border border-red-100 px-2 py-0.5 rounded">
                            Sem executor!
                          </span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* A: Accountable */}
                  <td className="p-3 bg-purple-900/[0.01] border-x border-slate-200 text-center">
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editA}
                        onChange={e => setEditA(e.target.value)}
                        placeholder="Cargo do Aprovador..."
                        className="w-full text-xs p-1 border rounded bg-white text-slate-900"
                      />
                    ) : (
                      <div className="flex flex-col gap-1 items-center">
                        {item.accountable.length > 0 ? item.accountable.map((a, idx) => (
                          <span key={idx} className="bg-purple-100 text-purple-800 font-semibold px-2 py-0.5 rounded text-[10.5px]">
                            {a}
                          </span>
                        )) : (
                          <span className="text-[10px] text-red-500 font-extrabold bg-red-50 border border-red-100 px-2 py-0.5 rounded">
                            Sem aprovador!
                          </span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* C: Consulted */}
                  <td className="p-3 bg-amber-900/[0.01] border-x border-slate-200 text-center">
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editC}
                        onChange={e => setEditC(e.target.value)}
                        placeholder="Consultados..."
                        className="w-full text-xs p-1 border rounded bg-white text-slate-900"
                      />
                    ) : (
                      <div className="flex flex-col gap-1 items-center">
                        {item.consulted.length > 0 ? item.consulted.map((c, idx) => (
                          <span key={idx} className="bg-amber-100 text-amber-800 font-semibold px-2 py-0.5 rounded text-[10.5px]">
                            {c}
                          </span>
                        )) : (
                          <span className="text-[10px] text-slate-400 italic">-</span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* I: Informed */}
                  <td className="p-3 bg-emerald-950/[0.01] border-x border-slate-200 text-center">
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editI}
                        onChange={e => setEditI(e.target.value)}
                        placeholder="Informados..."
                        className="w-full text-xs p-1 border rounded bg-white text-slate-900"
                      />
                    ) : (
                      <div className="flex flex-col gap-1 items-center">
                        {item.informed.length > 0 ? item.informed.map((i, idx) => (
                          <span key={idx} className="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded text-[10.5px]">
                            {i}
                          </span>
                        )) : (
                          <span className="text-[10px] text-slate-400 italic">-</span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* Actions Column */}
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {isEditing ? (
                        <button
                          onClick={() => handleSaveEdit(item.id)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white p-1.5 rounded cursor-pointer"
                          title="Gravar"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <button
                          onClick={() => handleStartEdit(item)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 p-1.5 rounded cursor-pointer border border-slate-300"
                          title="Editar atribuições RACI"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteActivity(item.id)}
                        className="bg-red-50 hover:bg-red-100 text-red-650 p-1.5 rounded border border-red-100 cursor-pointer"
                        title="Remover linha"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      )}

    </div>
  );
}
