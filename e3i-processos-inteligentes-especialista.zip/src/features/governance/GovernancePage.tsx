import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { GovernanceAlert } from "../../domain/enterprise-architecture/raciEngine";
import { 
  ShieldCheck, 
  Users, 
  GitBranch, 
  ShieldAlert, 
  Sparkles,
  HelpCircle,
  Lightbulb
} from "lucide-react";
import RaciMatrix from "./RaciMatrix";
import DecisionMap from "./DecisionMap";
import ResponsibilityConflictAlert from "./ResponsibilityConflictAlert";

export interface GovernancePageProps {
  mode: UsabilityMode;
  openTemplatesHub?: () => void;
}

type ActiveTabType = "raci" | "limits" | "alerts";

export default function GovernancePage({
  mode,
  openTemplatesHub
}: GovernancePageProps) {
  const isExpert = isExpertMode(mode);
  const [activeTab, setActiveTab] = useState<ActiveTabType>("raci");
  const [alerts, setAlerts] = useState<GovernanceAlert[]>([]);

  const criticalCount = alerts.filter(a => a.severity === "critical").length;
  const warningCount = alerts.filter(a => a.severity === "warning").length;

  return (
    <div className="space-y-6 w-full text-slate-800">
      
      {/* 1. TOP BANNER / MODULE HEADER */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 md:p-8 relative overflow-hidden border border-slate-800 shadow-lg text-left">
        {/* Decorative ambient background accent */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="absolute right-12 bottom-0 w-48 h-48 bg-[#C49746]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl space-y-4 relative z-10">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl shadow-md text-slate-950">
              <ShieldCheck className="w-6 h-6 text-white" />
            </span>
            <div>
              <span className="text-[10px] font-mono font-black text-emerald-400 uppercase tracking-widest block">AÇÃO 10 — MÓDULO AUXILIAR</span>
              <h2 className="text-xl md:text-2xl font-serif font-black tracking-tight text-white leading-tight">
                {isExpert ? "Governança Corporativa & Matriz RACI" : "Divisão de Responsabilidades e Aprovações"}
              </h2>
            </div>
          </div>

          <p className="text-xs md:text-sm text-slate-350 leading-relaxed max-w-3xl">
            {isExpert
              ? "Regulamente fluxos de autorização tática linha por linha. Defina quem Executa (R), quem Aprova (A) e realize auditorias automáticas para eliminar redundâncias e comitês morosos."
              : "Defina quem aprova e quem faz as tarefas principais. Evite atrasos e garanta que cada líder cuide da sua respectiva zona de trabalho."}
          </p>

          {/* Quick counts */}
          <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] font-mono">
            <span className="bg-slate-800 border border-slate-700 px-2.5 py-0.5 rounded text-slate-200">
              ✓ Auditoria Ativa
            </span>
            {criticalCount > 0 ? (
              <span className="text-red-400 font-bold">● {criticalCount} erro(s) crítico(s) detectado(s)!</span>
            ) : (
              <span className="text-emerald-400 font-bold">● Nenhum erro crítico de alçada</span>
            )}
          </div>
        </div>
      </div>

      {/* 2. TABBED CONTROLS */}
      <div className="flex overflow-x-auto select-none border-b border-slate-200 bg-white p-1 rounded-xl shadow-xs gap-1">
        
        {/* Tab: RACI Matrix */}
        <button
          onClick={() => setActiveTab("raci")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "raci" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Users className="w-4 h-4" />
          {isExpert ? "Matriz RACI" : "Quem Faz / Quem Aprova"}
        </button>

        {/* Tab: Limits of Authority */}
        <button
          onClick={() => setActiveTab("limits")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "limits" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <GitBranch className="w-4 h-4" />
          {isExpert ? "Alçadas Decisórias" : "Quem Pode Decidir?"}
        </button>

        {/* Tab: Governance Alerts */}
        <button
          onClick={() => setActiveTab("alerts")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer relative ${
            activeTab === "alerts" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          {isExpert ? "Auditoria de Riscos" : "Alertas de Conflito"}

          {alerts.length > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-650 text-white text-[10px] font-bold rounded-full flex items-center justify-center border border-white">
              {alerts.length}
            </span>
          )}
        </button>

      </div>

      {/* 3. DYNAMIC TAB CONTENT VIEW */}
      <div>
        {activeTab === "raci" && (
          <div className="animate-fade-in">
            <RaciMatrix 
              mode={mode}
              onAlertsChange={setAlerts}
              openTemplatesHub={openTemplatesHub}
            />
          </div>
        )}

        {activeTab === "limits" && (
          <div className="animate-fade-in">
            <DecisionMap 
              mode={mode}
            />
          </div>
        )}

        {activeTab === "alerts" && (
          <div className="animate-fade-in">
            <ResponsibilityConflictAlert 
              mode={mode}
              alerts={alerts}
              onFixAlert={(alert) => {
                setActiveTab("raci"); // Redirect back to RACI so they can fix immediately
              }}
            />
          </div>
        )}
      </div>

    </div>
  );
}
