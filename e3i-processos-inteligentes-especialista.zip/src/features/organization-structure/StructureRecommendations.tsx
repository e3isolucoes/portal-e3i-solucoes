import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  Compass, 
  Settings, 
  HelpCircle, 
  Cpu, 
  Lightbulb, 
  AlertTriangle,
  Grid,
  CheckCircle,
  TrendingUp,
  Workflow,
  Sparkles,
  RefreshCw
} from "lucide-react";

export interface StructureRecommendationsProps {
  mode: UsabilityMode;
}

export default function StructureRecommendations({
  mode
}: StructureRecommendationsProps) {
  const isExpert = isExpertMode(mode);
  
  // Quick self-audit simulator state
  const [hasDoubleBoss, setHasDoubleBoss] = useState(false);
  const [hasNoOwner, setHasNoOwner] = useState(false);
  const [hasHighCentralization, setHasHighCentralization] = useState(true);

  // Calculate simulated structural health
  const getStructuralScore = () => {
    let score = 95;
    if (hasDoubleBoss) score -= 30;
    if (hasNoOwner) score -= 25;
    if (hasHighCentralization) score -= 15;
    return Math.max(score, 10);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (score >= 50) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-red-600 bg-red-50 border-red-100";
  };

  return (
    <div id="structure-recommendations-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Header segment */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Recomendações e Governança LSS" : "Dicas para Organizar a minha Empresa"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Diretrizes recomendadas de governança corporativa e integridade de estrutura para evitar duplicidade e centralizações excessivas." 
              : "Recomendações práticas e fáceis para acabar com a confusão de tarefas no dia a dia do seu negócio."}
          </p>
        </div>
        <span className="text-[10px] bg-[#C49746]/10 text-[#C49746] font-mono font-bold px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1">
          <Sparkles className="w-3 h-3" /> IA Advisor Ativo
        </span>
      </div>

      {/* QUICK INTERACTIVE SELF-AUDIT SIMULATOR */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 md:p-5 space-y-4">
        <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide font-sans">
          🚦 Simulador Rápido de Saúde da Estrutura
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="flex items-center gap-2.5 bg-white p-3 rounded-lg border border-slate-200 cursor-pointer select-none">
            <input 
              type="checkbox" 
              checked={hasDoubleBoss} 
              onChange={e => setHasDoubleBoss(e.target.checked)}
              className="accent-[#C49746] rounded focus:ring-0"
            />
            <div className="text-[11.5px]">
              <p className="font-bold text-slate-800">Dupla Chefia Ativa?</p>
              <p className="text-[10px] text-slate-450">Falta clareza de comando único.</p>
            </div>
          </label>

          <label className="flex items-center gap-2.5 bg-white p-3 rounded-lg border border-slate-200 cursor-pointer select-none">
            <input 
              type="checkbox" 
              checked={hasNoOwner} 
              onChange={e => setHasNoOwner(e.target.checked)}
              className="accent-[#C49746] rounded focus:ring-0"
            />
            <div className="text-[11.5px]">
              <p className="font-bold text-slate-800">Tarefas Sem Dono?</p>
              <p className="text-[10px] text-slate-450">Ninguém cobra e ninguém faz.</p>
            </div>
          </label>

          <label className="flex items-center gap-2.5 bg-white p-3 rounded-lg border border-slate-200 cursor-pointer select-none">
            <input 
              type="checkbox" 
              checked={hasHighCentralization} 
              onChange={e => setHasHighCentralization(e.target.checked)}
              className="accent-[#C49746] rounded focus:ring-0"
            />
            <div className="text-[11.5px]">
              <p className="font-bold text-slate-800">Decisão só no Dono?</p>
              <p className="text-[10px] text-slate-450">Tudo trava se o dono viajar.</p>
            </div>
          </label>
        </div>

        {/* Scoring result box */}
        <div className={`p-4 border rounded-lg flex items-center justify-between gap-4 transition-colors ${getScoreColor(getStructuralScore())}`}>
          <div>
            <span className="text-[10px] font-mono font-black uppercase tracking-wider block">Índice Estimado de Saúde Estrutural:</span>
            <p className="text-xs font-medium mt-0.5 max-w-lg leading-relaxed text-slate-650">
              {getStructuralScore() >= 80 ? "Sua empresa possui governança madura e canais de comando alinhados. Os gargalos táticos são mínimos." :
               getStructuralScore() >= 50 ? "Atenção: há centralização ou tarefas críticas que dependem estritamente da presença física da liderança. Delegue!" :
               "Alerta Crítico: Altas chances de conflito pessoal diário, retrabalhos constantes e desperdício de tempo dos sócios decidindo rotinas."}
            </p>
          </div>
          <div className="text-right shrink-0">
            <span className="text-3xl font-mono font-black">{getStructuralScore()}%</span>
          </div>
        </div>
      </div>

      {/* ADVISORY LIST BASED ON USABILITY MODE */}
      <div className="space-y-4">
        <h4 className="text-xs font-mono tracking-wider font-extrabold text-slate-400 uppercase">
          📋 Próximos Passos de Otimização Organizacional
        </h4>

        {isExpert ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Exper Advice 1 */}
            <div className="border border-slate-200 bg-slate-50/50 p-4 rounded-xl space-y-2">
              <span className="text-[10px] font-mono font-black text-rose-600 bg-rose-50 border border-rose-100 px-2.5 py-0.5 rounded uppercase">
                Passo 1: Matriz de Alçada Decisória
              </span>
              <h5 className="text-xs font-black text-slate-900">Implementar Tabela de Limites de Autoridade (Limits of Authority)</h5>
              <p className="text-[11.5px] text-slate-600 leading-normal">
                Determine tetos de gastos e alçadas de decisão por cargos. Vendedores seniores podem autorizar reduções de até 5%, supervisores até 10%, e acima disso somente aprovação tática automatizada por e-mail/sistema.
              </p>
            </div>

            {/* Expert Advice 2 */}
            <div className="border border-slate-200 bg-slate-50/50 p-4 rounded-xl space-y-2">
              <span className="text-[10px] font-mono font-black text-indigo-600 bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded uppercase">
                Passo 2: Design de Interface
              </span>
              <h5 className="text-xs font-black text-slate-900">Estabelecer SLAs de Trabalho Entre Departamentos (Front to Back Link)</h5>
              <p className="text-[11.5px] text-slate-600 leading-normal">
                Evite brigas de prioridade regulamentando pontos de contato. O comercial possui o papel de trazer contratos qualificados contendo todas as assinaturas técnicas, enquanto a operação se compromete a expedir em até 4h úteis.
              </p>
            </div>

            {/* Expert Advice 3 */}
            <div className="border border-slate-200 bg-slate-50/50 p-4 rounded-xl space-y-2 col-span-1 md:col-span-2">
              <span className="text-[10px] font-mono font-black text-emerald-600 bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded uppercase">
                Passo 3: Conexão RACI Futurista
              </span>
              <h5 className="text-xs font-black text-slate-900">Atrelar Atribuições de Processos Automáticos aos Cargos Cadastrados</h5>
              <p className="text-[11.5px] text-slate-600 leading-normal">
                Esta estrutura organizacional será vinculada aos seus diagramas de raias (BPMN) e planos de ação. O sistema alertará automaticamente se um processo for designado a um cargo que não pertence àquela área, prevenindo anomalias de compliance.
              </p>
            </div>

          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Simple Advice 1 */}
            <div className="border border-amber-100 bg-[#FAF9F5]/40 p-4 rounded-xl space-y-2">
              <span className="text-[10px] tracking-wide font-mono font-bold text-[#A37B34] flex items-center gap-1 uppercase">
                <CheckCircle className="w-3.5 h-3.5 text-[#C49746]" /> 1. Regra do Único Chefe
              </span>
              <h5 className="text-xs font-black text-slate-900">Cada funcionário deve prestar contas a apenas uma pessoa</h5>
              <p className="text-[11.5px] text-slate-600 leading-normal">
                Se o ajudante recebe ordens conflitantes do Dono, do Gerente Comercial e do Caixa ao mesmo tempo, ele ficará sobrecarregado, confuso e fará as tarefas com erros recorrentes de atenção.
              </p>
            </div>

            {/* Simple Advice 2 */}
            <div className="border border-amber-100 bg-[#FAF9F5]/40 p-4 rounded-xl space-y-2">
              <span className="text-[10px] tracking-wide font-mono font-bold text-[#A37B34] flex items-center gap-1 uppercase">
                <CheckCircle className="w-3.5 h-3.5 text-[#C49746]" /> 2. Manual de "Pega-Boba"
              </span>
              <h5 className="text-xs font-black text-slate-900">Defina o responsável por tarefas chatas e chatíssimas</h5>
              <p className="text-[11.5px] text-slate-600 leading-normal">
                Quem limpa a sujeira do balcão? Quem fecha a porta no fim do dia? Quem atende o entregador de água? Deixe anotado de forma clara de quem é o dever desse recolhimento diário.
              </p>
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
