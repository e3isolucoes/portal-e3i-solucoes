import React, { useState } from "react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Briefcase, 
  User, 
  Flame, 
  Layers, 
  MapPin, 
  CreditCard, 
  CheckSquare, 
  Plus, 
  Trash2, 
  Search, 
  Filter, 
  ChevronRight,
  TrendingDown,
  Clock
} from "lucide-react";

export interface Role {
  id: string;
  departmentId: string;
  titleSimple: string;
  titleTechnical: string;
  responsibleName: string;
  responsibilitiesSimple: string[];
  responsibilitiesTechnical: string[];
  seniorityLevel: "Junior" | "Pleno" | "Senior" | "Diretor/Sócio";
  estimatedSalarySimple: string;
  estimatedSalaryExpert: string;
  outcomesSimple: string;
  outcomesTechnical: string;
}

export interface RoleCardsProps {
  mode: UsabilityMode;
  selectedDepartmentId?: string;
}

const INITIAL_ROLES: Role[] = [
  {
    id: "role_1",
    departmentId: "dept_dir",
    titleSimple: "Dono Geral da Empresa",
    titleTechnical: "Chief Executive Officer & Visionary Founder",
    responsibleName: "Marcos Miranda",
    responsibilitiesSimple: [
      "Decidir os rumos financeiros da empresa",
      "Contratar coordenadores e gerentes",
      "Definir metas de faturamento anual"
    ],
    responsibilitiesTechnical: [
      "Formulação de estratégia corporativa global",
      "Supervisão de riscos e captação de Capex/Investimento externo",
      "Liderança fiduciária e aprovação final de budget departamental"
    ],
    seniorityLevel: "Diretor/Sócio",
    estimatedSalarySimple: "R$ 15.000 / Pró-labore",
    estimatedSalaryExpert: "R$ 18.000 + Participação societária em dividendos",
    outcomesSimple: "Garantir que a empresa continue dando lucro e crescendo",
    outcomesTechnical: "Alinhamento das metas gerais através do desdobramento de OKRs do Board"
  },
  {
    id: "role_2",
    departmentId: "dept_ops",
    titleSimple: "Supervisor de Operações",
    titleTechnical: "Head of Operations & Delivery",
    responsibleName: "Carla Souza",
    responsibilitiesSimple: [
      "Organizar a escala de folga dos ajudantes",
      "Checar se há gargalos na expedição dos produtos",
      "Evitar reclamações de atrasos no Google"
    ],
    responsibilitiesTechnical: [
      "Análise de capacidade de produção física e gargalos de fila",
      "Manutenção Preventiva de Equipamentos de Chão de Fábrica",
      "Supervisão das métricas operacionais OEE, Cycle Time e lead time da logística"
    ],
    seniorityLevel: "Senior",
    estimatedSalarySimple: "R$ 4.500",
    estimatedSalaryExpert: "R$ 5.800 CLT + Bônus de Produtividade de Entrega",
    outcomesSimple: "Entregar tudo dentro do prazo sem erros",
    outcomesTechnical: "Estabilização das entregas no tempo planejado mantendo custo com pessoal sob controle"
  },
  {
    id: "role_3",
    departmentId: "dept_ops",
    titleSimple: "Atendente Operacional",
    titleTechnical: "Operador de Atendimento Júnior",
    responsibleName: "Felipe Almeida",
    responsibilitiesSimple: [
      "Colocar produtos nas prateleiras",
      "Ajudar o cliente a encontrar o que precisa",
      "Manter o ambiente limpo e organizado"
    ],
    responsibilitiesTechnical: [
      "Triagem primária de solicitações de assistência técnica",
      "Controle de inventário transitório utilizando metodologia Kanban física",
      "Preenchimento diário das planilhas de desperdício tático"
    ],
    seniorityLevel: "Junior",
    estimatedSalarySimple: "R$ 1.800",
    estimatedSalaryExpert: "R$ 1.950 CLT + Seguro Saúde",
    outcomesSimple: "Fazer o atendimento com bom humor e rapidez",
    outcomesTechnical: "Maximização de conversão em balcão mantendo satisfação acima de 85% de aprovação"
  },
  {
    id: "role_4",
    departmentId: "dept_fin",
    titleSimple: "Responsável pelo Contas a Pagar e Caixa",
    titleTechnical: "Analista Financeiro Sênior",
    responsibleName: "Mariana Santos",
    responsibilitiesSimple: [
      "Fazer os pagamentos diários no aplicativo do banco",
      "Cobrar clientes que estão devendo",
      "Checar se sobrou dinheiro no fim do mês"
    ],
    responsibilitiesTechnical: [
      "Conciliação bancária diária via extrato OFX e ERP",
      "Elaboração de relatórios trimestrais de DRE (Regime de competência e caixa)",
      "Projeção e acompanhamento de fluxo de caixa operacional futuro de 90 dias"
    ],
    seniorityLevel: "Pleno",
    estimatedSalarySimple: "R$ 3.200",
    estimatedSalaryExpert: "R$ 4.000 CLT",
    outcomesSimple: "Garantir que nenhuma conta passe do dia do vencimento",
    outcomesTechnical: "Redução de despesas com juros e atrasos para o nível zero absoluto"
  },
  {
    id: "role_5",
    departmentId: "dept_vendas",
    titleSimple: "Vendedor Comercial",
    titleTechnical: "Sales Executive & Hunter",
    responsibleName: "Rodrigo Costa",
    responsibilitiesSimple: [
      "Atender telefone e responder WhatsApp de clientes",
      "Montar o orçamento preliminar e tentar fechar a venda",
      "Ir visitar novos clientes potenciais"
    ],
    responsibilitiesTechnical: [
      "Prospecção outbound direcionada por ICP (Profile ideal de cliente)",
      "Gestão de ciclo de vendas dentro da ferramenta de CRM (Sales Hub)",
      "Dimensionamento técnico de propostas customizadas de alto impacto comercial"
    ],
    seniorityLevel: "Pleno",
    estimatedSalarySimple: "R$ 2.400 + Comissão",
    estimatedSalaryExpert: "R$ 2.800 CLT + 2% de Comissão sobre Faturamento Líquido",
    outcomesSimple: "Bater a meta mensal estabelecida pelo chefe",
    outcomesTechnical: "Aumento sistemático da taxa de conversão comercial entre contatos e contratos fechados"
  }
];

export default function RoleCards({
  mode,
  selectedDepartmentId
}: RoleCardsProps) {
  const isExpert = isExpertMode(mode);
  const [roles, setRoles] = useState<Role[]>(INITIAL_ROLES);
  
  // Interaction and Filtering state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDeptFilter, setSelectedDeptFilter] = useState(selectedDepartmentId || "all");
  const [selectedLevelFilter, setSelectedLevelFilter] = useState("all");

  // Add new role modal/form inline state
  const [isAdding, setIsAdding] = useState(false);
  const [newTitleSimple, setNewTitleSimple] = useState("");
  const [newTitleExpert, setNewTitleExpert] = useState("");
  const [newResponsible, setNewResponsible] = useState("");
  const [newDept, setNewDept] = useState("dept_ops");
  const [newLevel, setNewLevel] = useState<Role["seniorityLevel"]>("Junior");
  const [newSalary, setNewSalary] = useState("R$ 2.500");
  const [newResponsibility, setNewResponsibility] = useState("");
  const [newOutcome, setNewOutcome] = useState("");

  const handleCreateRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleSimple.trim()) return;

    const newRoleObj: Role = {
      id: `role_custom_${Date.now()}`,
      departmentId: newDept,
      titleSimple: newTitleSimple,
      titleTechnical: newTitleExpert || `${newTitleSimple} Expert`,
      responsibleName: newResponsible || "A contratar / Vago",
      responsibilitiesSimple: [newResponsibility || "Adotar processos descritos e zelar pelos prazos"],
      responsibilitiesTechnical: [newResponsibility || "Conduzir operações táticas garantindo os SLAs mapeados"],
      seniorityLevel: newLevel,
      estimatedSalarySimple: newSalary,
      estimatedSalaryExpert: newSalary,
      outcomesSimple: newOutcome || "Garantir conformidade e satisfação do cliente",
      outcomesTechnical: newOutcome || "Estabilização das entregas no respectivo centro de custo"
    };

    setRoles([...roles, newRoleObj]);
    
    // Clear state & collapse
    setNewTitleSimple("");
    setNewTitleExpert("");
    setNewResponsible("");
    setNewResponsibility("");
    setNewOutcome("");
    setIsAdding(false);
  };

  const handleDeleteRole = (id: string) => {
    if (confirm("Deseja realmente remover este cargo/papel da estrutura?")) {
      setRoles(roles.filter(r => r.id !== id));
    }
  };

  // Filter roles list
  const filteredRoles = roles.filter(role => {
    const matchesSearch = 
      role.titleSimple.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.titleTechnical.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.responsibleName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDept = 
      selectedDeptFilter === "all" || 
      role.departmentId === selectedDeptFilter;

    const matchesLevel = 
      selectedLevelFilter === "all" || 
      role.seniorityLevel === selectedLevelFilter;

    return matchesSearch && matchesDept && matchesLevel;
  });

  return (
    <div id="role-cards-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Dicionário de Competências & Matriz de Papéis" : "Cargos e Papéis na Prática"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Defina atribuições precisas de responsabilidades (atribuição direta ou subsidiária) para dar clareza a cada cargo." 
              : "Veja as tarefas de cada pessoa, quanto ganham e qual o principal resultado que elas precisam entregar."}
          </p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="text-xs font-bold font-sans bg-[#C49746] hover:bg-[#A37B34] text-white px-3 py-2 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-center uppercase tracking-wide"
        >
          <Plus className="w-4 h-4" /> {isAdding ? "Cancelar Cadastro" : "Adicionar Cargo"}
        </button>
      </div>

      {/* COLLAPSIBLE ADDING CARD */}
      {isAdding && (
        <form onSubmit={handleCreateRole} className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Nome do Cargo (Comum)</label>
              <input 
                type="text" 
                required
                placeholder="Ex: Ajudante Geral de Balcão"
                value={newTitleSimple}
                onChange={e => setNewTitleSimple(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              />
            </div>
            {isExpert && (
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Nome do Cargo (Técnico)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Auxiliar de Fulfillment"
                  value={newTitleExpert}
                  onChange={e => setNewTitleExpert(e.target.value)}
                  className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
                />
              </div>
            )}
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Nome do Responsável Atual</label>
              <input 
                type="text" 
                placeholder="Ex: João da Silva"
                value={newResponsible}
                onChange={e => setNewResponsible(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Área Vincular</label>
              <select 
                value={newDept}
                onChange={e => setNewDept(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              >
                <option value="dept_dir">Diretoria</option>
                <option value="dept_ops">Operações</option>
                <option value="dept_fin">Financeiro</option>
                <option value="dept_vendas">Vendas</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Nível de Senioridade</label>
              <select 
                value={newLevel}
                onChange={e => setNewLevel(e.target.value as Role["seniorityLevel"])}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              >
                <option value="Junior">Junior</option>
                <option value="Pleno">Pleno</option>
                <option value="Senior">Senior</option>
                <option value="Diretor/Sócio">Diretor / Sócio</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Custo do Cargo / Salário</label>
              <input 
                type="text" 
                placeholder="Ex: R$ 2.400"
                value={newSalary}
                onChange={e => setNewSalary(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-2">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Principal Atribuição do Dia</label>
              <textarea 
                placeholder="Ex: Atender o WhatsApp rapidamente salvando todos os contatos no funil."
                value={newResponsibility}
                onChange={e => setNewResponsibility(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900 h-16 resize-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Entregável Esperado / Meta Básica</label>
              <textarea 
                placeholder="Ex: Bater a meta mínima de 12 novos cadastros diários."
                value={newOutcome}
                onChange={e => setNewOutcome(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900 h-16 resize-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button 
              type="button" 
              onClick={() => setIsAdding(false)}
              className="text-xs px-3 py-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold"
            >
              Cancelar
            </button>
            <button 
              type="submit" 
              className="text-xs px-4 py-1.5 rounded bg-[#C49746] hover:bg-[#A37B34] text-white font-bold"
            >
              Salvar Papel
            </button>
          </div>
        </form>
      )}

      {/* FILTER & SEARCH ROW */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between pb-2">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input 
            type="text" 
            placeholder="Buscar por cargo ou responsável..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:border-[#C49746] bg-white text-slate-900"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto overflow-x-auto select-none py-1">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          
          <select 
            value={selectedDeptFilter}
            onChange={e => setSelectedDeptFilter(e.target.value)}
            className="text-[11px] font-bold font-sans bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 px-2 py-1 rounded-md shrink-0 cursor-pointer"
          >
            <option value="all">Todas as Áreas</option>
            <option value="dept_dir">Diretoria</option>
            <option value="dept_ops">Operações</option>
            <option value="dept_fin">Financeiro</option>
            <option value="dept_vendas">Vendas</option>
          </select>

          <select 
            value={selectedLevelFilter}
            onChange={e => setSelectedLevelFilter(e.target.value)}
            className="text-[11px] font-bold font-sans bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 px-2 py-1 rounded-md shrink-0 cursor-pointer"
          >
            <option value="all">Sênioridades</option>
            <option value="Junior">Junior</option>
            <option value="Pleno">Pleno</option>
            <option value="Senior">Senior</option>
            <option value="Diretor/Sócio">Diretor/Sócio</option>
          </select>
        </div>
      </div>

      {/* CARDS RENDER GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRoles.map((role) => (
          <div 
            key={role.id}
            id={`role-card-${role.id}`}
            className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between hover:border-amber-200 hover:shadow-xs transition-all relative overflow-hidden"
          >
            {/* Top department identity badge */}
            <div className="flex justify-between items-start gap-1">
              <span className={`text-[8.5px] font-mono tracking-widest font-black uppercase px-2 py-0.5 rounded-full ${
                role.departmentId === "dept_dir" ? "bg-purple-100 text-purple-700" :
                role.departmentId === "dept_ops" ? "bg-blue-100 text-blue-700" :
                role.departmentId === "dept_fin" ? "bg-emerald-100 text-emerald-700" :
                "bg-amber-100 text-[#A37B34]"
              }`}>
                {role.departmentId === "dept_dir" ? "Diretoria" :
                 role.departmentId === "dept_ops" ? "Operação" :
                 role.departmentId === "dept_fin" ? "Financeiro" :
                 "Comercial"}
              </span>

              <button 
                onClick={() => handleDeleteRole(role.id)}
                className="text-slate-400 hover:text-red-500 p-0.5"
                title="Remover cargo"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Title & Responsible Name */}
            <div className="space-y-1.5 mt-2">
              <h4 className="text-sm font-extrabold text-slate-950 font-sans tracking-tight">
                {isExpert ? role.titleTechnical : role.titleSimple}
              </h4>
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-bold">{role.responsibleName}</span>
                <span className="text-[10px] font-mono bg-slate-200 font-black px-1.5 rounded">
                  {role.seniorityLevel}
                </span>
              </div>
            </div>

            {/* Responsibilities list snippet */}
            <div className="space-y-1 mt-4 pt-4 border-t border-slate-200/60">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest block">
                Atribuições Principais
              </span>
              <ul className="text-[11.5px] text-slate-650 space-y-1 pl-3.5 list-disc font-medium">
                {(isExpert ? role.responsibilitiesTechnical : role.responsibilitiesSimple).slice(0, 3).map((resp, i) => (
                  <li key={i}>{resp}</li>
                ))}
              </ul>
            </div>

            {/* Principal objective target outcome */}
            <div className="bg-amber-500/5 p-2.5 rounded-lg border border-amber-500/10 text-xs mt-3.5">
              <span className="text-[9px] font-mono font-bold text-[#A37B34] uppercase tracking-widest block">🎯 Principal Entregável</span>
              <p className="text-slate-750 font-bold font-sans mt-0.5 leading-snug">
                {isExpert ? role.outcomesTechnical : role.outcomesSimple}
              </p>
            </div>

            {/* Salary footer */}
            <div className="pt-3 mt-3 border-t border-slate-200/60 flex items-center justify-between text-[10.5px]">
              <span className="text-slate-450 font-mono tracking-wide">Custo Estimado Cargo:</span>
              <span className="font-mono font-black text-slate-900">
                {isExpert ? role.estimatedSalaryExpert : role.estimatedSalarySimple}
              </span>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
