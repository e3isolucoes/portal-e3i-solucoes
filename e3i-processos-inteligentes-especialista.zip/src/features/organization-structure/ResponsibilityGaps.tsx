import React, { useState } from "react";
import { UsabilityMode, isExpertMode, isSimpleMode } from "../../domain/usabilityMode";
import { 
  AlertTriangle, 
  HelpCircle, 
  CheckSquare, 
  Plus, 
  Trash2, 
  TrendingUp, 
  Zap, 
  Users, 
  ShieldAlert,
  Search,
  UserCheck
} from "lucide-react";

export interface StructuralProblem {
  id: string;
  type: "gap" | "conflict";
  titleSimple: string;
  titleTechnical: string;
  descriptionSimple: string;
  descriptionTechnical: string;
  implicationSimple: string;
  implicationTechnical: string;
  detectedInDepartment: string;
  status: "Pendente" | "Mitigado" | "Em Análise";
}

const INITIAL_PROBLEMS: StructuralProblem[] = [
  {
    id: "prob_1",
    type: "gap",
    titleSimple: "Ninguém responde pelo pós-venda nem pesquisa de satisfação",
    titleTechnical: "Lacuna de Atribuição Crítica: Customer Success & Retenção de Clientes",
    descriptionSimple: "O cliente faz a compra tática, mas depois que o pedido sai, ninguém entra em contato para saber se deu tudo certo ou para oferecer novos produtos de recorrência.",
    descriptionTechnical: "Ausência de papel responsável por ciclo de pós-entrega (LTV/Churn). Vendedores alegam falta de tempo e a operação foca estritamente em fulfillment rápido.",
    implicationSimple: "Clientes perdem a confiança e compram da concorrência na próxima vez sem sabermos o motivo.",
    implicationTechnical: "Instabilidade na receita recorrente e fragilidade na reputação digital (avaliações negativas não monitoradas).",
    detectedInDepartment: "dept_vendas",
    status: "Pendente"
  },
  {
    id: "prob_2",
    type: "conflict",
    titleSimple: "Financeiro e Vendas discordam sobre dar desconto para clientes",
    titleTechnical: "Conflito de Alçada Decisória: Políticas de Desconto vs. Fluxo de Caixa",
    descriptionSimple: "Vendedores dão descontos de até 15% para conseguir vender rápido, mas o Financeiro trava as propostas no banco por risco de o lucro cair para zero.",
    descriptionTechnical: "Sobreposição de autoridade entre a área comercial (meta de faturamento bruto) e a área financeira (meta de margem Ebitda operacional).",
    implicationSimple: "Vendas perdidas no meio do processo e discussões constantes entre equipes comerciais e de caixa.",
    implicationTechnical: "Estresse organizacional crônico devido à falta de uma matriz de limites (limits of authority) clara para a equipe de vendas.",
    detectedInDepartment: "dept_fin",
    status: "Pendente"
  },
  {
    id: "prob_3",
    type: "gap",
    titleSimple: "Falta de gerente fixo aos sábados na operação",
    titleTechnical: "Vácuo Tático Temporário: Liderança Operacional de Plantão",
    descriptionSimple: "Aos sábados, os donos não estão e os ajudantes trabalham sozinhos. Se o sistema cai ou um cliente reclama, ninguém tem autonomia para dar reembolso.",
    descriptionTechnical: "Ausência de delegação formal de alçada de exceção no nível de supervisão de turno nos finais de semana.",
    implicationSimple: "Funcionários ficam estressados e o cliente vai embora insatisfeito por falta de resolução rápida.",
    implicationTechnical: "Gargalos de atendimento e degradação do SLA de resposta devido à centralização estrita no fundador da empresa.",
    detectedInDepartment: "dept_ops",
    status: "Em Análise"
  }
];

export interface ResponsibilityGapsProps {
  mode: UsabilityMode;
}

export default function ResponsibilityGaps({
  mode
}: ResponsibilityGapsProps) {
  const isExpert = isExpertMode(mode);
  const [problems, setProblems] = useState<StructuralProblem[]>(INITIAL_PROBLEMS);
  
  // State for creating a new issue
  const [isAdding, setIsAdding] = useState(false);
  const [newType, setNewType] = useState<"gap" | "conflict">("gap");
  const [newTitle, setNewTitle] = useState("");
  const [newTitleExp, setNewTitleExp] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newImplication, setNewImplication] = useState("");
  const [newDept, setNewDept] = useState("dept_ops");

  const handleRegisterProblem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const customProb: StructuralProblem = {
      id: `prob_custom_${Date.now()}`,
      type: newType,
      titleSimple: newTitle,
      titleTechnical: newTitleExp || `${newTitle} (Análise Técnica)`,
      descriptionSimple: newDesc || "Dúvidas estruturais sem processo e responsável claro.",
      descriptionTechnical: newDesc || "Vácuo ou conflito de governança operacional identificado na ponta.",
      implicationSimple: newImplication || "Risco de retrabalho ou insatisfação interna.",
      implicationTechnical: newImplication || "Degradação da eficiência dos centros de custo correlatados.",
      detectedInDepartment: newDept,
      status: "Pendente"
    };

    setProblems([customProb, ...problems]);
    
    // reset form
    setNewTitle("");
    setNewTitleExp("");
    setNewDesc("");
    setNewImplication("");
    setIsAdding(false);
  };

  const handleDeleteProblem = (id: string) => {
    setProblems(problems.filter(p => p.id !== id));
  };

  const handleToggleStatus = (id: string) => {
    setProblems(problems.map(p => {
      if (p.id === id) {
        const nextStatus: StructuralProblem["status"] = 
          p.status === "Pendente" ? "Em Análise" :
          p.status === "Em Análise" ? "Mitigado" : "Pendente";
        return { ...p, status: nextStatus };
      }
      return p;
    }));
  };

  return (
    <div id="responsibility-gaps-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title block */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Lacunas de Responsabilidade & Riscos Estruturais" : "Conflitos de Decisão e Tarefas Sem Dono"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Mapeie gargalos de autoridade dupla (overlapping authority) ou vácuos operacionais ativos para calibrar o modelo organizacional." 
              : "Verifique onde existem dúvidas de 'quem decide o quê' e quais tarefas importantes estão sem responsável definido."}
          </p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="text-xs font-bold font-sans bg-slate-900 hover:bg-slate-800 text-white px-3 py-2 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-center uppercase tracking-wide"
        >
          <Plus className="w-4 h-4 text-[#C49746]" /> {isAdding ? "Cancelar Registro" : "Registrar Conflito/Lacuna"}
        </button>
      </div>

      {/* MODAL / COLLAPSIBLE REGISTRATION FORM */}
      {isAdding && (
        <form onSubmit={handleRegisterProblem} className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Tipo de Anomalia</label>
              <select 
                value={newType}
                onChange={e => setNewType(e.target.value as "gap" | "conflict")}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              >
                <option value="gap">🔧 Lacuna (Tarefa sem responsável claro)</option>
                <option value="conflict">⚡ Conflito (Duas pessoas tentando decidir)</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Título do Problema</label>
              <input 
                type="text" 
                required
                placeholder="Ex: Ninguém confere as devoluções de mercadoria"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Área Onde Ocorre</label>
              <select 
                value={newDept}
                onChange={e => setNewDept(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              >
                <option value="dept_dir">Diretoria</option>
                <option value="dept_ops">Operações</option>
                <option value="dept_fin">Financeiro</option>
                <option value="dept_vendas">Vendas</option>
              </select>
            </div>
          </div>

          {isExpert && (
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Terminologia Técnica do Risco</label>
              <input 
                type="text" 
                placeholder="Ex: Instabilidade de Governança nos Logísticos de Devolução RMA"
                value={newTitleExp}
                onChange={e => setNewTitleExp(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900"
              />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Descrição do que acontece</label>
              <textarea 
                placeholder="Quem é que faz isso hoje? Quais as desculpas comuns dos integrantes?"
                value={newDesc}
                onChange={e => setNewDesc(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900 h-16"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase font-mono">Impacto / Prejuízo prático na empresa</label>
              <textarea 
                placeholder="Ex: Clientes não recebem o estorno e reclamam no ReclameAqui, sujando a imagem."
                value={newImplication}
                onChange={e => setNewImplication(e.target.value)}
                className="w-full text-xs mt-1 px-3 py-1.5 border border-slate-300 rounded focus:border-[#C49746] bg-white text-slate-900 h-16"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button 
              type="button" 
              onClick={() => setIsAdding(false)}
              className="text-xs px-3 py-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold"
            >
              Cancelar
            </button>
            <button 
              type="submit" 
              className="text-xs px-4 py-1.5 rounded bg-slate-900 hover:bg-slate-850 text-white font-bold"
            >
              Gravar Alerta Estrutural
            </button>
          </div>
        </form>
      )}

      {/* SIMPLE QUESTIONS BLOCK IF IN SIMPLE MODE */}
      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2 text-left">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4 text-[#C49746]" /> Compreendendo Conflitos de Decisão:
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs text-slate-650">
            <div>⚡ <b>Conflito de Autoridade:</b> Quando duas posições se atropelam (ex: vendedor dando desconto maior do que o financeiro permitiu).</div>
            <div>🔧 <b>Lacuna de Execução:</b> Quando uma tarefa essencial fica esquecida pois cada funcionário acha que o outro deveria fazê-la.</div>
          </div>
        </div>
      )}

      {/* PROBLEMS ITERATOR LIST */}
      <div className="space-y-4">
        {problems.map((prob) => {
          const isGap = prob.type === "gap";
          return (
            <div 
              key={prob.id}
              className={`border rounded-xl p-4 md:p-5 transition-all relative ${
                prob.status === "Mitigado" ? "border-slate-150 bg-slate-50 opacity-75" :
                isGap ? "border-amber-200/90 bg-amber-50/20" : "border-red-200/90 bg-red-50/10"
              }`}
            >
              {/* Top metadata row */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-dashed border-slate-200 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded ${
                    isGap ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"
                  }`}>
                    {isGap ? "🔧 Lacuna Estrutural" : "⚡ Conflito Ativo"}
                  </span>
                  
                  <span className="text-[10px] font-mono text-slate-500 font-bold">
                    Dep: {prob.detectedInDepartment === "dept_vendas" ? "Vendas" :
                          prob.detectedInDepartment === "dept_fin" ? "Financeiro" :
                          prob.detectedInDepartment === "dept_ops" ? "Operações" : "Diretoria"}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Interactive Status Badge to toggle mitigation status */}
                  <button
                    onClick={() => handleToggleStatus(prob.id)}
                    className={`text-[9.5px] font-mono font-bold px-2 py-0.5 rounded cursor-pointer transition-colors ${
                      prob.status === "Mitigado" ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-200" :
                      prob.status === "Em Análise" ? "bg-blue-100 text-blue-800 hover:bg-blue-200" :
                      "bg-slate-100 text-slate-800 hover:bg-slate-200"
                    }`}
                    title="Clique para alternar o status de mitigação"
                  >
                    Status: {prob.status}
                  </button>

                  <button 
                    onClick={() => handleDeleteProblem(prob.id)}
                    className="text-slate-400 hover:text-red-600 p-0.5"
                    title="Excluir risco"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Title & Body description */}
              <div className="space-y-2">
                <h4 className="text-sm font-black text-slate-900">
                  {isExpert ? prob.titleTechnical : prob.titleSimple}
                </h4>
                
                <p className="text-xs text-slate-650 leading-relaxed">
                  <b>O que ocorre:</b> {isExpert ? prob.descriptionTechnical : prob.descriptionSimple}
                </p>

                {/* Implication / Real damage */}
                <div className="bg-white/70 border border-slate-150 p-3 rounded-lg text-xs space-y-1">
                  <span className="text-[9px] font-mono font-bold text-slate-450 uppercase flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#C49746]" /> 
                    Consequência Tática para a Empresa:
                  </span>
                  <p className="text-slate-750 font-bold italic leading-snug">
                    "{isExpert ? prob.implicationTechnical : prob.implicationSimple}"
                  </p>
                </div>

                {/* Future Hook guidance note */}
                <div className="pt-2 mt-1 flex items-center gap-2 text-[10px] font-mono text-slate-450">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C49746] animate-pulse" />
                  <span>Ação futura: conectar com a Matriz RACI para forçar um único papel decisor "A".</span>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
