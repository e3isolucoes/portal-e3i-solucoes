import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Network, 
  Users, 
  ShieldCheck, 
  ArrowRight, 
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  GitBranch,
  Building2,
  Workflow
} from "lucide-react";

export interface Department {
  id: string;
  nameSimple: string;
  nameTechnical: string;
  leaderSimple: string;
  leaderTechnical: string;
  decider: string;
  executor: string;
  interfacesSimple: string;
  interfacesTechnical: string;
  roleCount: number;
}

export interface OrganizationMapProps {
  mode: UsabilityMode;
  onSelectDepartment?: (id: string) => void;
}

export default function OrganizationMap({
  mode,
  onSelectDepartment
}: OrganizationMapProps) {
  const isExpert = isExpertMode(mode);

  const departments: Department[] = [
    {
      id: "dept_dir",
      nameSimple: "Diretoria e Planejamento",
      nameTechnical: "Conselho Executivo (C-Level & Strategic Governance)",
      leaderSimple: "Dono / Fundador",
      leaderTechnical: "Chief Executive Officer (CEO)",
      decider: "Dono e Conselheiros",
      executor: "Dono e Secretária Executiva",
      interfacesSimple: "Com todas as áreas para passar metas e cobrar resultados",
      interfacesTechnical: "Overlord estratégico, canais diretos de relatórios de OPEX/CAPEX e alinhamento tático",
      roleCount: 2
    },
    {
      id: "dept_ops",
      nameSimple: "Operações e Serviços",
      nameTechnical: "Unidade de Operações & Entrega (Core Flow & Fulfillment)",
      leaderSimple: "Gerente de Operações",
      leaderTechnical: "Chief Operations Officer (COO) / Head de Delivery",
      decider: "Gerente Operacional",
      executor: "Atendentes, Operadores de Caixa e Estoquistas",
      interfacesSimple: "Com o Financeiro para liberar pedidos e Administração para contratação",
      interfacesTechnical: "Integração entre core produtivo, balanceamento de capacidade (SOP) e contas comerciais",
      roleCount: 6
    },
    {
      id: "dept_fin",
      nameSimple: "Controle de Finanças e Caixa",
      nameTechnical: "Controladoria & Gestão Fiduciária (Finance & Treasury)",
      leaderSimple: "Responsável pelo Caixa",
      leaderTechnical: "Chief Financial Officer (CFO) / Controller Sênior",
      decider: "Dono da empresa",
      executor: "Auxiliar Administrativo Financeiro",
      interfacesSimple: "Com Vendas para checar faturamento e Diretoria para pagar contas",
      interfacesTechnical: "Fluxos de consolidação contábil, auditoria de margens, conciliação e compliance fiscal",
      roleCount: 2
    },
    {
      id: "dept_vendas",
      nameSimple: "Vendas e Atendimento comercial",
      nameTechnical: "Expansão Comercial & Sucesso do Cliente (Growth & Front-Office)",
      leaderSimple: "Líder de Vendas",
      leaderTechnical: "Chief Revenue Officer (CRO) / Head de Marketing",
      decider: "Dono e Coordenador Comercial",
      executor: "Vendedores externos e Atendentes de Chat",
      interfacesSimple: "Com Operações para avisar sobre pedidos novos que foram vendidos",
      interfacesTechnical: "Canal de conversão (MQL/SQL), funil tático de aquisição e SLA de passagem de propostas",
      roleCount: 4
    }
  ];

  return (
    <div id="organization-map-container" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* Header section with explanatory lines based on mode */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div className="space-y-1">
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Desenho Organizacional & Modelo Operacional" : "Áreas e Departamentos Cadastrados"}
          </h3>
          <p className="text-xs text-slate-500">
            {isExpert 
              ? "Visualize a taxonomia de departamentos, papéis de tomada de decisão, pontos de contato de interfaces e fronteiras de autoridade." 
              : "Veja quais as grandes áreas que dividem a empresa e entenda exatamente quem responde por cada uma delas."}
          </p>
        </div>

        {isExpert && (
          <span className="text-[9px] font-mono bg-slate-900 text-slate-200 border border-slate-800 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
            ORGANIZATIONAL STRUCTURE
          </span>
        )}
      </div>

      {/* SIMPLE QUESTIONS GUIDELINE BLOCK IF IN SIMPLE MODE */}
      {isSimpleMode(mode) && (
        <div className="bg-[#FAF9F5] border border-amber-100 rounded-lg p-4 space-y-2 text-left">
          <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wide flex items-center gap-1">
            <HelpCircle className="w-4 h-4 text-[#C49746]" /> Perguntas Importantes da Estrutura:
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-650">
            <div>• <b>Quais áreas existem?</b> Listamos as 4 divisões vitais acima.</div>
            <div>• <b>Quem responde por cada área?</b> É o Líder responsável por bater a meta.</div>
            <div>• <b>Quem decide?</b> Quem tem a palavra final para evitar brigas de opinião.</div>
            <div>• <b>Quem executa no dia a dia?</b> Quem coloca a mão na massa nas tarefas diárias.</div>
          </div>
        </div>
      )}

      {/* RENDER STRUCTURAL TREE / DEPTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {departments.map((dept) => (
          <div
            key={dept.id}
            id={`dept-node-${dept.id}`}
            onClick={() => onSelectDepartment && onSelectDepartment(dept.id)}
            className="border border-slate-200 hover:border-[#C49746]/60 rounded-xl p-4 md:p-5 hover:shadow-xs cursor-pointer transition-all bg-white text-left space-y-4 group relative flex flex-col justify-between"
          >
            {/* Visual Accent Box */}
            <div className="absolute top-0 bottom-0 left-0 w-1 bg-slate-200 group-hover:bg-[#C49746] transition-colors rounded-l-lg" />

            <div className="space-y-3 pl-2.5">
              
              {/* Dept title & Count badge */}
              <div className="flex items-start justify-between gap-2.5">
                <div>
                  <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide font-sans group-hover:text-[#C49746] transition-colors leading-snug">
                    {isExpert ? dept.nameTechnical : dept.nameSimple}
                  </h4>
                  <p className="text-[11px] text-slate-400 font-mono">ID: {dept.id.toUpperCase()}</p>
                </div>
                <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-150">
                  {dept.roleCount} Cargos
                </span>
              </div>

              {/* Leader segment */}
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-150 text-xs">
                <span className="text-[10px] font-mono tracking-wider font-bold text-slate-450 uppercase block">Líder Responsável</span>
                <p className="text-slate-850 font-black font-sans mt-0.5">
                  {isExpert ? dept.leaderTechnical : dept.leaderSimple}
                </p>
              </div>

              {/* Decider/Executor flow */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <span className="text-[9px] font-mono text-slate-400 uppercase font-black tracking-wider block">✔ Quem Decide?</span>
                  <p className="text-xs text-slate-700 font-bold leading-tight mt-0.5">{dept.decider}</p>
                </div>
                <div>
                  <span className="text-[9px] font-mono text-slate-400 uppercase font-black tracking-wider block">⚙ Quem Executa?</span>
                  <p className="text-xs text-slate-700 font-bold leading-tight mt-0.5">{dept.executor}</p>
                </div>
              </div>

              {/* Interface connections (Who they interact with) */}
              <div className="pt-2 border-t border-slate-105">
                <span className="text-[9px] font-mono text-slate-405 uppercase font-bold tracking-wider flex items-center gap-1">
                  <Workflow className="w-3 h-3 text-[#C49746]" /> Interface / Pontos de Contato
                </span>
                <p className="text-[11.5px] text-slate-600 leading-normal mt-1 italic">
                  "{isExpert ? dept.interfacesTechnical : dept.interfacesSimple}"
                </p>
              </div>

            </div>

            {/* Micro interactivity details */}
            <div className="pt-3 border-t border-slate-100 pl-2.5 flex items-center justify-between text-[10px] font-mono text-slate-400 font-bold uppercase">
              <span>Relação de subordinação direta</span>
              <span className="text-[#C49746] group-hover:underline flex items-center gap-0.5 cursor-pointer">
                Ver organograma detalhado <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
              </span>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
