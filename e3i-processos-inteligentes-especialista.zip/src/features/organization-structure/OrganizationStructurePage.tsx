import React, { useState } from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  Building2, 
  Users, 
  ShieldAlert, 
  Lightbulb, 
  Layers, 
  ArrowRight,
  Sparkles,
  HelpCircle,
  GitBranch,
  Network
} from "lucide-react";
import OrganizationMap from "./OrganizationMap";
import RoleCards from "./RoleCards";
import ResponsibilityGaps from "./ResponsibilityGaps";
import StructureRecommendations from "./StructureRecommendations";

export interface OrganizationStructurePageProps {
  mode: UsabilityMode;
  onNavigateToStep?: (stepId: string) => void;
}

type ActiveTabType = "map" | "roles" | "gaps" | "advise";

export default function OrganizationStructurePage({
  mode,
  onNavigateToStep
}: OrganizationStructurePageProps) {
  const isExpert = isExpertMode(mode);
  const [activeTab, setActiveTab] = useState<ActiveTabType>("map");
  const [selectedDeptId, setSelectedDeptId] = useState<string>("all");

  const handleSelectDepartment = (deptId: string) => {
    setSelectedDeptId(deptId);
    setActiveTab("roles"); // Automatically switch to roles card to show the filtered result
  };

  return (
    <div className="space-y-6 w-full text-slate-800">
      
      {/* 1. TOP BANNER / MODULE HEADER */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 md:p-8 relative overflow-hidden border border-slate-800 shadow-lg text-left">
        {/* Decorative ambient background accent */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />
        <div className="absolute right-12 bottom-0 w-48 h-48 bg-[#C49746]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl space-y-4 relative z-10">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-gradient-to-br from-[#C49746] to-amber-600 rounded-xl shadow-md text-slate-900">
              <Network className="w-6 h-6 text-white" />
            </span>
            <div>
              <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">AÇÃO 9 — MÓDULO AUXILIAR</span>
              <h2 className="text-xl md:text-2xl font-serif font-black tracking-tight text-white leading-tight">
                {isExpert ? "Estrutura Organizacional & Arquitetura de Cargos" : "Organização e Divisão de Tarefas da Empresa"}
              </h2>
            </div>
          </div>

          <p className="text-xs md:text-sm text-slate-350 leading-relaxed max-w-3xl">
            {isExpert
              ? "Defina o modelo operacional, taxonomia de departamentos, fronteiras de decisão (alçadas) e mitigue riscos de sobreposição hierárquica ou vácuos táticos."
              : "Acabe com a bagunça de processos! Saiba exatamente quem manda em cada área, quem executa o serviço diário e quais tarefas cruciais estão sem dono."}
          </p>

          {/* Quick connection notice */}
          <div className="flex flex-wrap items-center gap-3 pt-2 text-[11px] text-slate-400 font-mono">
            <span className="bg-slate-800 border border-slate-700 px-2 py-0.5 rounded text-slate-200">
              ✓ Integração Tática
            </span>
            <span>Estes cargos poderão ser futuramente vinculados às raias do Kanban, RACI e processos BPM.</span>
          </div>
        </div>
      </div>

      {/* 2. TABBED CONTROLS */}
      <div className="flex overflow-x-auto select-none border-b border-slate-200 bg-white p-1 rounded-xl shadow-xs gap-1">
        
        {/* Tab: Department Map */}
        <button
          onClick={() => setActiveTab("map")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "map" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Building2 className="w-4 h-4" />
          {isExpert ? "Desenho Organizacional" : "Áreas e Donos"}
        </button>

        {/* Tab: Role Cards */}
        <button
          onClick={() => {
            setActiveTab("roles");
            setSelectedDeptId("all");
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "roles" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Users className="w-4 h-4" />
          {isExpert ? "Dicionário de Cargos & Salários" : "Quem Faz o Quê? (Atribuições)"}
        </button>

        {/* Tab: Responsibility Gaps */}
        <button
          onClick={() => setActiveTab("gaps")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "gaps" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          {isExpert ? "Riscos Estruturais" : "Conflitos & Tarefas Sem Dono"}
        </button>

        {/* Tab: Structure Recommendations */}
        <button
          onClick={() => setActiveTab("advise")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
            activeTab === "advise" 
              ? "bg-[#C49746] text-white shadow-3xs" 
              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
          }`}
        >
          <Lightbulb className="w-4 h-4" />
          {isExpert ? "Diretrizes de Governança" : "Dicas Rápidas"}
        </button>

      </div>

      {/* 3. DYNAMIC TAB CONTENT VIEW */}
      <div>
        {activeTab === "map" && (
          <div className="animate-fade-in">
            <OrganizationMap 
              mode={mode} 
              onSelectDepartment={handleSelectDepartment} 
            />
          </div>
        )}

        {activeTab === "roles" && (
          <div className="animate-fade-in">
            <RoleCards 
              mode={mode} 
              selectedDepartmentId={selectedDeptId} 
            />
          </div>
        )}

        {activeTab === "gaps" && (
          <div className="animate-fade-in">
            <ResponsibilityGaps 
              mode={mode} 
            />
          </div>
        )}

        {activeTab === "advise" && (
          <div className="animate-fade-in">
            <StructureRecommendations 
              mode={mode} 
            />
          </div>
        )}
      </div>

    </div>
  );
}
