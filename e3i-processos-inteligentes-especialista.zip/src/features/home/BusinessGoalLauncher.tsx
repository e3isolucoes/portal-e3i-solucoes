import React, { useState } from "react";
import { 
  Compass, 
  ArrowRight, 
  CheckCircle2, 
  Target, 
  Sparkles, 
  Layers, 
  Users, 
  BarChart3, 
  Clock, 
  RefreshCw, 
  TrendingUp, 
  ShieldAlert, 
  Activity, 
  ChevronRight,
  Info
} from "lucide-react";
import { enterpriseJourney, JourneyStep } from "../../domain/enterprise-architecture/enterpriseJourney";
import { frameworks } from "../../domain/enterprise-architecture/frameworks";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";

export interface BusinessGoalLauncherProps {
  usabilityMode?: UsabilityMode;
  onSelectJourneyStep?: (stepId: string) => void;
  onLaunchJourney?: (selectedGoal: string, recommendedStepIds: string[]) => void;
}

export interface BusinessGoalOption {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  stepIds: ("diagnostico" | "estrategia" | "estrutura" | "processos" | "governanca" | "mudanca" | "execucao" | "resultados")[];
}

export default function BusinessGoalLauncher({
  usabilityMode: propUsabilityMode,
  onSelectJourneyStep,
  onLaunchJourney
}: BusinessGoalLauncherProps) {
  // Let's allow local toggle of usability mode if not provided, or stay in sync with prop
  const [localUsabilityMode, setLocalUsabilityMode] = useState<UsabilityMode>("SIMPLE");
  const activeMode = propUsabilityMode || localUsabilityMode;

  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);

  // Define the 10 business goal options with their corresponding journey steps
  const goalOptions: BusinessGoalOption[] = [
    {
      id: "organizar_empresa",
      title: "Organizar minha empresa",
      description: "Colocar ordem geral, alinhar o rumo e entender as funções e responsabilidades de cada setor.",
      icon: <Layers className="w-5 h-5 text-amber-600" />,
      stepIds: ["diagnostico", "estrategia", "estrutura", "processos"]
    },
    {
      id: "melhorar_processos",
      title: "Melhorar processos",
      description: "Padronizar tarefas do dia a dia, eliminar burocracia e entregar produtos ou serviços melhores.",
      icon: <RefreshCw className="w-5 h-5 text-amber-600" />,
      stepIds: ["diagnostico", "processos", "execucao", "resultados"]
    },
    {
      id: "definir_responsabilidades",
      title: "Definir responsabilidades",
      description: "Esclarecer quem faz e quem aprova cada entrega, eliminando redundâncias dadas por falta de foco.",
      icon: <Users className="w-5 h-5 text-amber-600" />,
      stepIds: ["estrategia", "estrutura", "mudanca"]
    },
    {
      id: "criar_indicadores",
      title: "Criar indicadores",
      description: "Construir metas numéricas precisas e tabuleiros de acompanhamento para parar de agir no achismo.",
      icon: <BarChart3 className="w-5 h-5 text-amber-600" />,
      stepIds: ["estrategia", "governanca", "resultados"]
    },
    {
      id: "reduzir_atrasos",
      title: "Reduzir atrasos",
      description: "Acelerar tempos de entrega para o cliente final removendo filas e esperas inúteis.",
      icon: <Clock className="w-5 h-5 text-amber-600" />,
      stepIds: ["diagnostico", "processos", "execucao"]
    },
    {
      id: "reduzir_retrabalho",
      title: "Reduzir retrabalho",
      description: "Evitar erros repetidos dos funcionários identificando pontos de falha e criando proteção preventiva.",
      icon: <ShieldAlert className="w-5 h-5 text-amber-600" />,
      stepIds: ["estrutura", "processos", "governanca"]
    },
    {
      id: "preparar_crescimento",
      title: "Preparar crescimento",
      description: "Criar uma base operacional robusta e escalável para suportar o aumento do número de vendas.",
      icon: <TrendingUp className="w-5 h-5 text-amber-600" />,
      stepIds: ["estrategia", "estrutura", "processos", "resultados"]
    },
    {
      id: "profissionalizar_gestao",
      title: "Profissionalizar a gestão",
      description: "Evoluir a administração familiar ou empírica para uma estrutura clara de papéis e roteiros formais.",
      icon: <Compass className="w-5 h-5 text-amber-600" />,
      stepIds: ["diagnostico", "estrategia", "estrutura", "processos", "governanca", "execucao", "resultados"]
    },
    {
      id: "reestruturar_areas",
      title: "Reestruturar áreas",
      description: "Adaptar organogramas, capacitar equipes e organizar silos de departamentos para cooperação ágil.",
      icon: <Activity className="w-5 h-5 text-amber-600" />,
      stepIds: ["diagnostico", "estrutura", "mudanca"]
    },
    {
      id: "acompanhar_execucao",
      title: "Acompanhar execução",
      description: "Garantir que as diretrizes estratégicas e planos de ação saiam do papel por meio de rotinas diárias.",
      icon: <Target className="w-5 h-5 text-amber-600" />,
      stepIds: ["estrategia", "execucao", "resultados"]
    }
  ];

  const selectedGoal = goalOptions.find(g => g.id === selectedGoalId);

  // Generate recommended step sequence matching enterpriseJourney
  const recommendedSteps: JourneyStep[] = selectedGoal
    ? enterpriseJourney
        .filter(step => selectedGoal.stepIds.includes(step.id))
        .sort((a, b) => a.sequence - b.sequence)
    : [];

  const handleLaunch = () => {
    if (selectedGoal && onLaunchJourney) {
      onLaunchJourney(selectedGoal.title, selectedGoal.stepIds);
    }
  };

  return (
    <div id="business-goal-launcher-root" className="w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-slate-800">
      
      {/* HEADER CARD */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-850 text-white rounded-lg p-6 sm:p-8 shadow-md mb-8 relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" /> E3I Enterprise Architect
            </div>
            <h1 className="text-2.5xl sm:text-3.5xl font-black tracking-tight text-white mb-2 font-sans">
              O que você quer organizar ou melhorar na empresa?
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Selecione o seu objetivo corporativo mais urgente. Nossa inteligência de arquitetura estrutural construirá o roteiro ideal de etapas acadêmicas para o seu desafio.
            </p>
          </div>

          {/* Local mode option switcher (shows up if prop usablityMode is omitted) */}
          {!propUsabilityMode && (
            <div className="flex bg-slate-850 border border-slate-750 rounded-md p-1.5 shrink-0 self-start md:self-center">
              <button
                type="button"
                onClick={() => setLocalUsabilityMode("SIMPLE")}
                className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  activeMode === "SIMPLE" 
                    ? "bg-amber-500 text-slate-950 font-black shadow-sm" 
                    : "text-slate-400 hover:text-white"
                }`}
              >
                🌱 Simples
              </button>
              <button
                type="button"
                onClick={() => setLocalUsabilityMode("EXPERT")}
                className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  activeMode === "EXPERT" 
                    ? "bg-slate-750 text-white shadow-sm" 
                    : "text-slate-400 hover:text-white"
                }`}
              >
                🎓 Especialista
              </button>
            </div>
          )}
        </div>
      </div>

      {/* TWO COLUMN GRID FOR SELECTION AND LIVE RECOMMENDATIONS PREVIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: 10 SELECTION CARDS (8 COLS ON DESKTOP) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <h2 className="text-lg font-bold text-slate-950 flex items-center gap-2">
              🧭 Objetivos Corporativos Disponíveis
            </h2>
            <span className="text-xs text-slate-500 font-mono font-bold tracking-tight bg-slate-100 border px-1.5 py-0.5 rounded">
              {goalOptions.length} OPÇÕES
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {goalOptions.map((goal) => {
              const isSelected = selectedGoalId === goal.id;
              return (
                <div
                  key={goal.id}
                  id={`goal-option-${goal.id}`}
                  onClick={() => setSelectedGoalId(goal.id)}
                  className={`group p-4 rounded-lg border text-left cursor-pointer transition-all ${
                    isSelected 
                      ? "bg-slate-50 border-amber-500 shadow-sm ring-1 ring-amber-500/30" 
                      : "bg-white border-slate-200 hover:border-slate-350 hover:bg-slate-50/50"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-md transition-colors ${
                      isSelected ? "bg-amber-500/10" : "bg-slate-100 group-hover:bg-slate-200/70"
                    }`}>
                      {goal.icon}
                    </div>
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-slate-900 leading-snug group-hover:text-amber-700 transition-colors">
                          {goal.title}
                        </span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />}
                      </div>
                      <p className="text-xs text-slate-500 leading-normal line-clamp-2">
                        {goal.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: PATHWAY ANALYSIS DRAWER / PANEL (5 COLS ON DESKTOP) */}
        <div className="lg:col-span-5">
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden sticky top-6">
            
            {/* PANEL HEADER */}
            <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                🌟 Recomendação Sistêmica
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                activeMode === "EXPERT" 
                  ? "bg-slate-900 border-slate-800 text-slate-200" 
                  : "bg-emerald-50 border-emerald-200 text-emerald-800 font-bold"
              }`}>
                {activeMode === "EXPERT" ? "Modo Especialista (ADM)" : "Modo Simplificado"}
              </span>
            </div>

            {/* PANEL CONTENT */}
            {!selectedGoalId ? (
              <div className="p-8 text-center text-slate-400 space-y-4">
                <div className="flex justify-center">
                  <div className="w-16 h-16 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-300">
                    <Compass className="w-8 h-8 animate-spin-slow" />
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold text-slate-700">Selecione um Objetivo Estratégico</p>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Escolha uma das 10 opções ao lado para gerarmos uma trilha sequencial personalizada de implementação.
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-5 sm:p-6 space-y-5">
                {/* Selected Headline */}
                <div className="border-b border-slate-100 pb-4">
                  <div className="text-xs text-amber-600 font-bold tracking-wide uppercase mb-1">Trilha recomendada para:</div>
                  <h3 className="text-xl font-extrabold text-slate-900 leading-snug">{selectedGoal?.title}</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-normal">{selectedGoal?.description}</p>
                </div>

                {/* Vertical Timeline of Recommended Steps */}
                <div className="relative pl-6 space-y-6 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-100">
                  {recommendedSteps.map((step, idx) => {
                    return (
                      <div key={step.id} className="relative group/step">
                        {/* Bullet circle point */}
                        <div className="absolute -left-[21px] top-1 w-[12px] h-[12px] rounded-full bg-white border-2 border-amber-500 z-10 flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        </div>

                        {/* Step Details */}
                        <div id={`pathway-step-${step.id}`} className="space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-xs font-mono font-bold text-slate-400">Etapa {idx + 1}:</span>
                            <span 
                              onClick={() => {
                                if (onSelectJourneyStep) onSelectJourneyStep(step.id);
                              }}
                              className="text-sm font-extrabold text-slate-900 hover:text-amber-700 cursor-pointer transition-colors underline decoration-dotted underline-offset-2"
                            >
                              {step.label}
                            </span>
                            
                            {/* Framework Tags if in EXPERT mode */}
                            {isExpertMode(activeMode) && step.associatedFrameworks.map(fId => {
                              const fw = frameworks.find(f => f.id === fId);
                              return (
                                <span key={fId} className="text-[9px] font-mono font-bold bg-slate-100 text-slate-600 border border-slate-200 rounded px-1 uppercase shrink-0">
                                  {fw ? fw.name : fId}
                                </span>
                              );
                            })}
                          </div>

                          {/* Dynamic content depending on level */}
                          <p className="text-xs text-slate-600 leading-normal">
                            {isSimpleMode(activeMode) ? step.objectiveSimple : step.objectiveTechnical}
                          </p>

                          {/* Golden question trigger link */}
                          <div className="bg-slate-50 rounded p-2 border border-slate-150/60 mt-1.5">
                            <div className="text-[9px] font-mono uppercase font-bold text-slate-400">Pergunta Chave (Golden Question):</div>
                            <p className="text-[11px] text-slate-700 italic font-medium mt-0.5">"{step.goldenQuestion}"</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Launch Button Trigger */}
                <div className="pt-4 border-t border-slate-100 flex flex-col gap-3">
                  <button
                    type="button"
                    onClick={handleLaunch}
                    className="w-full bg-[#C49746] hover:bg-[#B38339] text-white font-bold text-xs uppercase tracking-wider py-3 px-4 rounded shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    🚀 Aplicar Trilha e Iniciar Jornada <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="flex justify-between text-[11px] text-slate-500 px-1">
                    <span className="flex items-center gap-1">
                      <Info className="w-3.5 h-3.5 text-slate-400" /> Ativará o roteiro guiado
                    </span>
                    <span>{recommendedSteps.length} etapas selecionadas</span>
                  </div>
                </div>

              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
}
