/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DiagnosticAnswers {
  pain?: string;
  measurement?: string;
  teamSize?: string;
  methodology?: string;
  stability?: string;
  engineeringMeta?: string;
  serviceTime?: number;
  serviceVariance?: number;
  serversCount?: number;
  utilizationPercent?: number;
}

export interface DiagnosticData {
  audienceType: "LEIGO" | "ESPECIALISTA";
  volume: number;
  defectRatePercent: number;
  estimatedAnnualWaste: number;
  estimatedSavingsAfterE3I: number;
  score: number;
  advice: string;
  answers?: DiagnosticAnswers;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company: string;
  role: string;
  segment: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "FINANCE" | "HUMAN_RESOURCES" | string;
  interest: string;
  status: string; // "Pendente" | "Em Atendimento" | "Proposta Enviada" | "Ganho" | "Recusado"
  date?: string;
  diagnosticData?: DiagnosticData;
}

export interface SMTPLog {
  id: string;
  timestamp: string;
  recipient: string;
  status: "SUCCESS" | "ERROR" | "INFO" | string;
  subject: string;
  serverUsed: string;
  details: string;
}

export interface SMTPSettings {
  enabled: boolean;
  host: string;
  port: number;
  user: string;
  pass: string;
  fromName: string;
  fromEmail: string;
  ssl: boolean;
}

export interface CorpUser {
  id: string;
  fullName: string;
  email: string;
  cargo: "Analista Júnior" | "Black Belt" | "Admin" | "Dono do Processo";
  status: "Ativo" | "Pendente" | "Suspenso";
}

export interface LocalEvent {
  id: string;
  summary: string;
  description: string;
  start: string;
  end: string;
  status: 'synced_google' | 'local_only';
}
