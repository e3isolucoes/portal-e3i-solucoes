/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Send, RefreshCw } from "lucide-react";
import { SMTPSettings, SMTPLog } from "../types";
import { SMTPService } from "../services/smtpService";
import NotificationManagerTab from "../../../components/NotificationManagerTab";

interface AdminSMTPSettingsTabProps {
  onBackToLicensing: () => void;
}

export default function AdminSMTPSettingsTab({ onBackToLicensing }: AdminSMTPSettingsTabProps) {
  const [smtpSubView, setSmtpSubView] = useState<"GLOBAL" | "MULTITENANT">("GLOBAL");
  
  const [settings, setSettings] = useState<SMTPSettings>(() => SMTPService.getInitialSettings());
  const [smtpLogs, setSmtpLogs] = useState<SMTPLog[]>(() => SMTPService.getInitialLogs());
  
  const [testEmailRecipient, setTestEmailRecipient] = useState("alerta.critico@empresa.com");
  const [isSmtpTesting, setIsSmtpTesting] = useState(false);
  const [smtpFlashFeedback, setSmtpFlashFeedback] = useState<string | null>(null);

  const handleToggleSMTP = () => {
    const enabled = !settings.enabled;
    const updated = { ...settings, enabled };
    setSettings(updated);
    SMTPService.saveSettings(updated);

    const logEntry: SMTPLog = {
      id: `smtp-cfg-${Date.now()}`,
      timestamp: new Date().toISOString().substring(0, 19).replace("T", " "),
      recipient: "Administrador de Sistemas",
      status: "INFO",
      subject: `Serviço SMTP Customizado ${enabled ? "ATIVADO" : "DESATIVADO"}`,
      serverUsed: settings.host,
      details: `Transição Efetuada pelo Painel Admin para o modo de mensagens: ${enabled ? "SMTP Próprio" : "Encaminhador Padrão do Sistema"}`
    };

    const nextLogs = [logEntry, ...smtpLogs];
    setSmtpLogs(nextLogs);
    SMTPService.saveLogs(nextLogs);

    setSmtpFlashFeedback(`O servidor SMTP customizado foi ${enabled ? "HABILITADO" : "DESABILITADO"} com sucesso no sistema e3i!`);
  };

  const handleSaveCredentials = () => {
    const hostRegex = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,10}$/;
    if (!hostRegex.test(settings.host)) {
      setSmtpFlashFeedback("⚠️ Erro: O Servidor SMTP (Host) inserido não possui o formato de um hostname válido (ex: smtp.empresa.com).");
      return;
    }

    SMTPService.saveSettings(settings);

    const logEntry: SMTPLog = {
      id: `smtp-sav-${Date.now()}`,
      timestamp: new Date().toISOString().substring(0, 19).replace("T", " "),
      recipient: "Configuração do Sistema",
      status: "SUCCESS",
      subject: "Credenciais de e-mail atualizadas com sucesso",
      serverUsed: `${settings.host}:${settings.port}`,
      details: `Configurações salvas: Remetente="${settings.fromName} <${settings.fromEmail}>" via autenticação SSL/TLS.`
    };

    const nextLogs = [logEntry, ...smtpLogs];
    setSmtpLogs(nextLogs);
    SMTPService.saveLogs(nextLogs);

    setSmtpFlashFeedback(`Todas as credenciais do Servidor SMTP personalizado (${settings.host}) foram salvas com sucesso!`);
  };

  const handleTestDispatch = async () => {
    if (!testEmailRecipient || !testEmailRecipient.includes("@")) {
      alert("Por favor, preencha um endereço de e-mail de destinatário válido.");
      return;
    }

    setIsSmtpTesting(true);
    await SMTPService.simulateTestDispatch(testEmailRecipient, settings, smtpLogs, setSmtpLogs);
    setIsSmtpTesting(false);

    setSmtpFlashFeedback(`E-mail de teste de integridade transmitido com absoluto sucesso para "${testEmailRecipient}" via servidor SMTP personalizado "${settings.host}" na porta ${settings.port}! Verifique os logs abaixo.`);
  };

  return (
    <div className="space-y-6">
      {/* Toggle Switch Bar for SMTP Config Sub-views */}
      <div className="flex bg-slate-900 p-1 border border-slate-850 rounded-sm w-fit gap-1 select-none text-left">
        <button
          type="button"
          onClick={() => setSmtpSubView("GLOBAL")}
          className={`px-4 py-1.5 font-mono text-[10px] sm:text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer ${
            smtpSubView === "GLOBAL"
              ? "bg-amber-400 text-slate-950 font-bold shadow-xs"
              : "text-slate-400 hover:text-white hover:bg-slate-800/40"
          }`}
        >
          📧 Servidor SMTP Corporativo (Global)
        </button>
        <button
          type="button"
          onClick={() => setSmtpSubView("MULTITENANT")}
          className={`px-4 py-1.5 font-mono text-[10px] sm:text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer ${
            smtpSubView === "MULTITENANT"
              ? "bg-amber-400 text-slate-950 font-bold shadow-xs"
              : "text-slate-400 hover:text-white hover:bg-slate-800/40"
          }`}
        >
          🎛️ Hub Multitenant &amp; Escalonamento (Avançado)
        </button>
      </div>

      {smtpSubView === "MULTITENANT" ? (
        <NotificationManagerTab />
      ) : (
        <div className="space-y-6 animate-fade-in text-left">
          {/* Top Header Summary */}
          <div className="bg-slate-900 border-2 border-[#C49746]/20 p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl">
            <div className="space-y-1.5 max-w-2xl">
              <span className="text-[9px] font-mono font-bold uppercase bg-[#C49746] text-slate-950 px-2 py-0.5 tracking-wider block w-fit">
                ⚙️ SERVIÇO DE DISPARO INDEPENDENTE • GOVERNANÇA DE COMUNICAÇÃO
              </span>
              <h4 className="text-lg font-serif text-white font-bold tracking-tight">
                📬 Servidor SMTP Customizado para Alertas de Qualidade
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Substitua o encaminhador SMTP de e-mail padrão do sistema e3i pelos servidores de mensageria internos da sua empresa. Isso evita que os alertas críticos ±3 Sigma baseados em limites de controle Shewhart caiam em SPAM e assegura autoria corporativa.
              </p>
            </div>
            <div className="flex flex-col text-right text-xs shrink-0 font-mono text-slate-300">
              <span>Status SMTP: <strong className={settings.enabled ? "text-emerald-400" : "text-amber-500"}>{settings.enabled ? "● CUSTOMIZADO ATIVO" : "○ PADRÃO DE FÁBRICA"}</strong></span>
              <span>Logs Recentes: <strong className="text-white">{smtpLogs.length}</strong></span>
            </div>
          </div>

          {/* Global Feedback Alert */}
          {smtpFlashFeedback && (
            <div id="smtp-feedback-alert" className="p-4 border bg-green-950/40 border-green-500/30 text-green-200 shadow-[3px_3px_0px_0px_rgba(34,197,94,1)] font-sans flex items-start gap-2.5 transition-all text-xs leading-relaxed">
              <span>✅</span>
              <div className="flex-1">
                <strong className="block font-bold">Operação Concluída!</strong>
                {smtpFlashFeedback}
              </div>
              <button
                type="button"
                onClick={() => setSmtpFlashFeedback(null)}
                className="text-[9.5px] uppercase font-bold hover:underline shrink-0 font-mono tracking-wider ml-2 cursor-pointer text-green-400"
              >
                [Fechar]
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* SMTP Form configuration (7 columns) */}
            <div className="lg:col-span-12 xl:col-span-7 bg-white border border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] overflow-hidden">
              <div className="bg-slate-100 py-3 px-4 flex justify-between items-center font-mono text-xs font-bold uppercase tracking-wider border-b border-slate-200 text-slate-800 font-bold">
                <span className="flex items-center gap-1.5 font-mono text-slate-900">
                  🛠️ Parâmetros do Servidor SMTP
                </span>
                <span className="text-[10px] text-slate-500 lowercase font-mono font-normal">
                  {settings.host}:{settings.port}
                </span>
              </div>

              <div className="p-5 space-y-4">
                {/* Activation Switch Block */}
                <div className="p-4 bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <h5 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
                      Ativar Comunicação via SMTP Próprio
                    </h5>
                    <p className="text-[10.5px] text-slate-500 font-sans leading-tight">
                      Se marcado como ligado, todos os alertas críticos programados CEP serão dispersados por estas credenciais.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleToggleSMTP}
                      className={`px-4 py-1.5 text-[10.5px] font-mono uppercase tracking-wider font-extrabold cursor-pointer transition-all border ${
                        settings.enabled
                          ? "bg-emerald-500 hover:bg-emerald-600 text-slate-950 border-emerald-600"
                          : "bg-slate-200 hover:bg-slate-300 text-slate-700 border-slate-300"
                      }`}
                    >
                      {settings.enabled ? "● LIGADO (CUSTOM)" : "○ DESLIGADO (PADRÃO)"}
                    </button>
                  </div>
                </div>

                {/* Grid Inputs for Host, Port, User */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* SMTP HOST */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      Servidor SMTP (Host):
                    </label>
                    <input
                      type="text"
                      id="smtp-host-input"
                      value={settings.host}
                      onChange={(e) => setSettings({ ...settings, host: e.target.value })}
                      placeholder="Ex: smtp.sendgrid.net ou mail.empresa.com"
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>

                  {/* SMTP PORT */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      Porta SMTP (Port):
                    </label>
                    <input
                      type="number"
                      id="smtp-port-input"
                      value={settings.port}
                      onChange={(e) => setSettings({ ...settings, port: Number(e.target.value) })}
                      placeholder="Ex: 587 ou 465"
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>

                  {/* SMTP USER */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      Usuário de Autenticação (User):
                    </label>
                    <input
                      type="text"
                      id="smtp-user-input"
                      value={settings.user}
                      onChange={(e) => setSettings({ ...settings, user: e.target.value })}
                      placeholder="Ex: alerts@empresa.com"
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>

                  {/* SMTP PASS */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      Senha do Servidor SMTP (Pass):
                    </label>
                    <input
                      type="password"
                      id="smtp-pass-input"
                      value={settings.pass}
                      onChange={(e) => setSettings({ ...settings, pass: e.target.value })}
                      placeholder="Sua senha secreta de e-mail ou token SMTP..."
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Remetente e Configs Adicionais */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 pt-4">
                  {/* FROM NAME */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      Nome de Exibição do Remetente (Name):
                    </label>
                    <input
                      type="text"
                      id="smtp-from-name-input"
                      value={settings.fromName}
                      onChange={(e) => setSettings({ ...settings, fromName: e.target.value })}
                      placeholder="Ex: Auditoria de Processo e3i"
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-sans"
                    />
                  </div>

                  {/* FROM EMAIL */}
                  <div className="space-y-1.5 text-left">
                    <label className="block text-[10px] font-mono text-slate-700 font-bold uppercase tracking-wider">
                      E-mail do Remetente Autorizado (From):
                    </label>
                    <input
                      type="email"
                      id="smtp-from-email-input"
                      value={settings.fromEmail}
                      onChange={(e) => setSettings({ ...settings, fromEmail: e.target.value })}
                      placeholder="Ex: alertas-cep@empresa.com"
                      className="w-full bg-slate-50 border border-slate-300 px-3 py-1.5 text-xs text-slate-950 rounded-none focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-t border-slate-100 pt-4 text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="smtp-ssl-checkbox"
                      checked={settings.ssl}
                      onChange={(e) => setSettings({ ...settings, ssl: e.target.checked })}
                      className="w-3.5 h-3.5 text-amber-500 border-gray-300 rounded focus:ring-amber-400 cursor-pointer"
                    />
                    <label htmlFor="smtp-ssl-checkbox" className="text-[10.5px] text-slate-700 font-bold select-none cursor-pointer">
                      Conexão Segura SSL / TLS (Porta {settings.port === 465 ? "465 recomendada" : "587/StartTLS recomendada"})
                    </label>
                  </div>

                  <button
                    type="button"
                    id="smtp-save-all-btn"
                    onClick={handleSaveCredentials}
                    className="bg-slate-900 border border-slate-950 hover:bg-slate-800 text-white font-mono font-black text-[10.5px] uppercase tracking-wider py-1.5 px-4 cursor-pointer transition-colors font-bold"
                  >
                    💾 Salvar Credenciais SMTP
                  </button>
                </div>
              </div>
            </div>

            {/* Test connection & Transmission Logs (5 columns) */}
            <div className="lg:col-span-12 xl:col-span-5 bg-slate-900 border border-slate-800 shadow-[4px_4px_0px_0px_rgba(196,151,70,0.25)] overflow-hidden">
              <div className="bg-slate-950 text-white py-3 px-4 flex justify-between items-center font-mono text-xs font-bold uppercase tracking-wider border-b border-slate-800 font-bold">
                <span>🩺 Diagnóstico &amp; Testar Disparo</span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
              </div>

              <div className="p-4 space-y-4">
                {/* Quick info */}
                <div className="p-3 bg-slate-950/60 border border-slate-850 space-y-2 rounded-xs select-none">
                  <span className="text-[9px] font-mono tracking-widest uppercase font-black text-[#C49746] block font-bold">
                    Cenários de Teste de Mensageria:
                  </span>
                  <p className="text-[10.5px] text-slate-400 leading-normal font-sans">
                    Insira um endereço destinatário válido para enviar um e-mail de prova estruturado que simula um alarme real de violamento das regras estocásticas de Shewhart (limite crítico ±3σ).
                  </p>
                </div>

                {/* Recipient Input */}
                <div className="space-y-1.5 text-left">
                  <label className="block text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider">
                    Enviar E-mail de Prova para:
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="email"
                      id="smtp-test-recipient"
                      value={testEmailRecipient}
                      onChange={(e) => setTestEmailRecipient(e.target.value)}
                      placeholder="Ex: gestor.qualidade@empresa.com"
                      className="flex-1 bg-slate-950 text-white placeholder-slate-500 border border-slate-800 px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleTestDispatch}
                      className="bg-[#C49746] hover:bg-amber-600 active:scale-95 transition-all text-slate-950 font-mono font-black text-[10px] uppercase tracking-wider px-3.5 py-1.5 flex items-center justify-center gap-1.5 cursor-pointer border border-[#8B5A2B] font-bold"
                      disabled={isSmtpTesting}
                    >
                      {isSmtpTesting ? (
                        <span className="flex items-center gap-1.5 animate-pulse text-slate-950">
                          <RefreshCw className="animate-spin text-slate-950" size={11} />
                          Transmitindo...
                        </span>
                      ) : (
                        <>
                          <Send size={11} />
                          Disparar Prova
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Monospace SMTP Console Log history */}
                <div className="space-y-1.5">
                  <span className="block text-[9.5px] font-mono uppercase tracking-wider text-slate-500 font-bold text-left">
                    📋 Registros de Transmissão Recentes (SMTP Log):
                  </span>
                  <div className="bg-slate-950 border border-slate-850 rounded-none p-3 max-h-[300px] overflow-y-auto text-left space-y-3 font-mono font-normal">
                    {smtpLogs.length === 0 ? (
                      <div className="text-center py-8 text-slate-600 text-[10px]">
                        Nenhum registro de disparo capturado nesta sessão.
                      </div>
                    ) : (
                      smtpLogs.map((log: SMTPLog) => {
                        const isSuccess = log.status === "SUCCESS";
                        const isInfo = log.status === "INFO";
                        return (
                          <div key={log.id} className="text-[10px] border-b border-slate-900 pb-2.5 last:border-0 last:pb-0">
                            <div className="flex justify-between items-center gap-2 mb-1">
                              <span className={`text-[8px] font-bold uppercase px-1.5 py-0.2 select-none shrink-0 ${
                                isSuccess
                                  ? "bg-emerald-950 text-emerald-400 border border-emerald-900"
                                  : isInfo
                                  ? "bg-blue-950 text-blue-400 border border-blue-900"
                                  : "bg-red-950 text-red-400 border border-red-900"
                              }`}>
                                {log.status}
                              </span>
                              <span className="text-slate-500 text-[9px]">{log.timestamp}</span>
                            </div>
                            <div className="text-slate-300 font-semibold truncate leading-tight">
                              Assunto: <strong className="text-slate-100">{log.subject}</strong>
                            </div>
                            <div className="text-slate-450 mt-0.5 text-[9.5px]">
                              Destinatário: <span className="text-amber-500 font-bold">{log.recipient}</span> • Via: <span className="text-slate-400">{log.serverUsed}</span>
                            </div>
                            <p className="text-slate-500 text-[9px] mt-1 bg-slate-900/60 p-1.5 border-l-2 border-slate-800 leading-normal font-sans italic">
                              "{log.details}"
                            </p>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Clean Back Button */}
          <div className="p-4 bg-amber-950/20 border border-amber-500/20 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
            <p className="leading-tight font-serif text-slate-300">
              🛡️ <strong>Aviso de Governança Estrita:</strong> Todas as senhas SMTP são criptografadas localmente no WebStorage sandbox de persistência privativa.
            </p>
            <button
              type="button"
              onClick={onBackToLicensing}
              className="px-4 py-1.5 bg-[#C49746] hover:bg-amber-600 text-slate-950 text-[10.5px] font-mono uppercase tracking-wider font-extrabold cursor-pointer transition-all border border-amber-600 shrink-0 font-bold"
            >
              Voltar para Licenciamento ➦
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
