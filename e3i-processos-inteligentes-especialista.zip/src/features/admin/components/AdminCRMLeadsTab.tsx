/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Send, AlertCircle } from "lucide-react";
import { Lead } from "../types";
import { Company } from "../../../types";
import { CRMService } from "../services/crmService";

interface AdminCRMLeadsTabProps {
  companies: Company[];
  setCompanies?: (companies: Company[]) => void;
  currentUserUid?: string;
  activeEmail?: string;
}

export default function AdminCRMLeadsTab({
  companies,
  setCompanies,
  currentUserUid,
  activeEmail = "admin@sixsigma.com"
}: AdminCRMLeadsTabProps) {
  const [leads, setLeads] = useState<Lead[]>(() => CRMService.getInitialLeads());
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [leadSearchQuery, setLeadSearchQuery] = useState("");

  // Proposal parameters
  const [customProposalPrice, setCustomProposalPrice] = useState<number>(3800);
  const [customLicencesCount, setCustomLicencesCount] = useState<number>(5);
  const [customConsultingHours, setCustomConsultingHours] = useState<number>(16);
  const [customSupportSla, setCustomSupportSla] = useState<string>("SLA 12h Master");
  const [customProposalScope, setCustomProposalScope] = useState<string>("");
  const [proposalFlashFeedback, setProposalFlashFeedback] = useState<string | null>(null);

  // Sync leads back to localStorage
  useEffect(() => {
    CRMService.saveLeads(leads);
  }, [leads]);

  // Sync proposal draft when selected lead or parameters change
  useEffect(() => {
    if (selectedLead) {
      const scopeDraft = CRMService.generateProposalDraft(
        selectedLead,
        customLicencesCount,
        customConsultingHours,
        customSupportSla,
        customProposalPrice
      );
      setCustomProposalScope(scopeDraft);
    }
  }, [selectedLead, customProposalPrice, customLicencesCount, customConsultingHours, customSupportSla]);

  const handleOptimiseScope = () => {
    setCustomProposalScope((prev) => `✓ REVISADO CO-PILOTO IA e3i\n` + prev);
    alert("Tuning de proposta com a Inteligência IA E3I executado com sucesso! Módulo de dores de gargalo otimizados no texto.");
  };

  const handleSendProposal = () => {
    if (!selectedLead) return;
    const updated = leads.map((l) =>
      l.id === selectedLead.id ? { ...l, status: "Proposta Enviada" } : l
    );
    setLeads(updated);
    setSelectedLead({ ...selectedLead, status: "Proposta Enviada" });

    CRMService.logAction(
      "Envio de Proposta",
      `Proposta de R$ ${customProposalPrice.toLocaleString("pt-BR")}/mês PJ encaminhada com sucesso para o lead: ${selectedLead.email}`
    );

    setProposalFlashFeedback(
      `Proposta Comercial de Licenciamento PJ para a empresa "${selectedLead.company}" gerada por R$ ${customProposalPrice.toLocaleString("pt-BR")},00/mês, com suporte de ${customSupportSla}, enviada com sucesso no e-mail: ${selectedLead.email}! Status do CRM atualizado.`
    );
  };

  const handleSimulateAcceptance = () => {
    if (!selectedLead) return;

    const exists = companies.some(
      (c) => c.name.toLowerCase() === selectedLead.company.toLowerCase()
    );
    if (exists) {
      alert(`A empresa "${selectedLead.company}" já foi cadastrada no sistema!`);
      return;
    }

    const mockCnpj = CRMService.registerWinningCompany(
      selectedLead.company,
      selectedLead.segment,
      selectedLead.diagnosticData,
      companies,
      setCompanies,
      activeEmail,
      currentUserUid
    );

    const updated = leads.map((l) =>
      l.id === selectedLead.id ? { ...l, status: "Ganho" } : l
    );
    setLeads(updated);
    setSelectedLead({ ...selectedLead, status: "Ganho" });

    CRMService.logAction(
      "Aceite de Proposta",
      `Proposta aceita! ID: ${selectedLead.id}, empresa ${selectedLead.company} migrada para produção.`
    );

    alert(
      `🤝 Simulação de Aceite bem-sucedida!\nCliente "${selectedLead.name}" (${selectedLead.company}) deu o de acordo na proposta.\nA organização foi automaticamente cadastrada com CNPJ: ${mockCnpj}!`
    );
  };

  const handleRemoveLead = () => {
    if (!selectedLead) return;
    const updated = leads.filter((l) => l.id !== selectedLead.id);
    setLeads(updated);

    CRMService.logAction(
      "Remoção CRM",
      `Lead "${selectedLead.name}" removido por decisão do administrador.`
    );

    setSelectedLead(null);
  };

  const handleStatusChange = (newStatus: string) => {
    if (!selectedLead) return;
    const updated = leads.map((l) =>
      l.id === selectedLead.id ? { ...l, status: newStatus } : l
    );
    setLeads(updated);
    setSelectedLead({ ...selectedLead, status: newStatus });

    if (newStatus === "Ganho") {
      const exists = companies.some(
        (c) => c.name.toLowerCase() === selectedLead.company.toLowerCase()
      );
      if (!exists) {
        const mockCnpj = CRMService.registerWinningCompany(
          selectedLead.company,
          selectedLead.segment,
          selectedLead.diagnosticData,
          companies,
          setCompanies,
          activeEmail,
          currentUserUid
        );
        alert(
          `🎉 Parabéns! Proposta Aceita!\nA empresa "${selectedLead.company}" (CNPJ: ${mockCnpj}) foi automaticamente cadastrada no banco de dados e está pronta para uso imediato!`
        );
      }
    }

    CRMService.logAction(
      "Atualização CRM",
      `Lead "${selectedLead.name}" alterado para status: ${newStatus}${
        newStatus === "Ganho" ? " e empresa PJ registrada automaticamente" : ""
      }`
    );
  };

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* Top Header Summary */}
      <div className="bg-slate-900 border-2 border-amber-500/20 p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl">
        <div className="space-y-1.5 max-w-xl">
          <span className="text-[9px] font-mono font-bold uppercase bg-amber-500 text-slate-950 px-2 py-0.5 tracking-wider block w-fit">
            🔒 GESTÃO DE PROSPECÇÃO • CRM ADMINISTRATIVO S.A.
          </span>
          <h4 className="text-lg font-serif text-white font-bold tracking-tight">
            📈 Atendimento de Leads &amp; Propostas Comerciais
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed font-sans">
            Organize os leads capturados na página institucional externa, estude o nível de maturidade e interesse indicados, configure propostas de vendas customizadas e dispare orçamentos digitais diretamente.
          </p>
        </div>
        <div className="flex flex-col text-right text-xs shrink-0 font-mono text-slate-300">
          <span>Total Leads: <strong className="text-white">{leads.length}</strong></span>
          <span>Pendentes: <strong className="text-amber-400">{leads.filter((l) => l.status === "Pendente").length}</strong></span>
          <span>Ganhos: <strong className="text-emerald-400">{leads.filter((l) => l.status === "Ganho").length}</strong></span>
        </div>
      </div>

      {/* Action feedback alert/toast */}
      {proposalFlashFeedback && (
        <div className="p-4 border bg-green-950/40 border-green-500/30 text-green-200 shadow-[3px_3px_0px_0px_rgba(34,197,94,1)] font-sans flex items-start gap-2.5 transition-all text-xs leading-relaxed">
          <span>✅</span>
          <div className="flex-1">
            <strong className="block font-bold">Proposta Comercial Enviada!</strong>
            {proposalFlashFeedback}
          </div>
          <button
            type="button"
            onClick={() => setProposalFlashFeedback(null)}
            className="text-[9.5px] uppercase font-bold hover:underline shrink-0 font-mono tracking-wider ml-2 cursor-pointer text-green-400"
          >
            [Fechar]
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* List of Leads (5 columns) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 shadow-[4px_4px_0px_0px_rgba(245,158,11,0.25)] overflow-hidden">
          <div className="bg-slate-950 text-white py-3 px-4 flex justify-between items-center font-mono text-xs font-bold uppercase tracking-wider border-b border-slate-800">
            <span>Leads Cadastrados ({leads.length})</span>
            <div className="relative w-36">
              <input
                type="text"
                placeholder="Pesquisar..."
                value={leadSearchQuery}
                onChange={(e) => setLeadSearchQuery(e.target.value)}
                className="bg-white/10 text-white placeholder-slate-400 text-[10px] border border-white/20 px-2 py-0.5 focus:outline-none w-full"
              />
            </div>
          </div>

          <div className="p-3 space-y-3 max-h-[550px] overflow-y-auto bg-slate-950/50">
            {leads
              .filter(
                (l) =>
                  l.name.toLowerCase().includes(leadSearchQuery.toLowerCase()) ||
                  l.company.toLowerCase().includes(leadSearchQuery.toLowerCase()) ||
                  (l.email && l.email.toLowerCase().includes(leadSearchQuery.toLowerCase()))
              )
              .map((ld) => {
                const isSelected = selectedLead?.id === ld.id;
                const isPending = ld.status === "Pendente";
                const isProposta = ld.status === "Proposta Enviada";
                const isWon = ld.status === "Ganho";

                return (
                  <div
                    key={ld.id}
                    onClick={() => setSelectedLead(ld)}
                    className={`p-3 border transition-all cursor-pointer text-left relative ${
                      isSelected
                        ? "border-amber-500 bg-amber-500/10 shadow-[2px_2px_0px_0px_rgba(245,158,11,1)]"
                        : "border-slate-800 bg-slate-900/50 hover:bg-slate-800 text-slate-100"
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-start gap-1">
                        <span className="text-[9.5px] text-amber-500 font-mono font-bold block truncate max-w-[70%]">
                          🏢 {ld.company}
                        </span>
                        <span
                          className={`text-[8px] font-mono font-extrabold uppercase px-1.5 py-0.2 rounded shrink-0 ${
                            isPending
                              ? "bg-red-950/50 text-red-400 border border-red-900"
                              : isProposta
                              ? "bg-blue-950/50 text-blue-400 border border-blue-900"
                              : isWon
                              ? "bg-emerald-950/50 text-emerald-400 border border-emerald-900"
                              : "bg-slate-950/80 text-slate-300 border border-slate-800"
                          }`}
                        >
                          {ld.status}
                        </span>
                      </div>

                      <div>
                        <strong className="text-xs text-white font-bold block">{ld.name}</strong>
                        <span className="text-[10px] text-slate-400 font-mono block">{ld.email}</span>
                      </div>

                      <div className="flex justify-between items-center text-[9px] font-mono text-slate-500 pt-1.5 border-t border-slate-850">
                        <span>🎯 {ld.interest || "Diagnóstico Geral"}</span>
                        <span>
                          {ld.date ? new Date(ld.date).toLocaleDateString("pt-BR") : "Disparado"}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* Lead Servicing & Interactive Proposal Generator (7 columns) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 shadow-[4px_4px_0px_0px_rgba(245,158,11,0.25)] overflow-hidden min-h-[500px]">
          {selectedLead ? (
            <div className="divide-y divide-slate-800 animate-fade-in text-left">
              {/* Lead Header */}
              <div className="p-4 bg-slate-950 flex justify-between items-start">
                <div className="space-y-1">
                  <span className="text-[8.5px] font-mono font-bold uppercase bg-amber-500 text-slate-950 px-2 py-0.5 tracking-wider block w-fit">
                    ID Lead: {selectedLead.id.toUpperCase()}
                  </span>
                  <h4 className="text-[16px] font-serif text-white font-bold">{selectedLead.name}</h4>
                  <p className="text-[11px] text-slate-400">
                    Segmento:{" "}
                    <strong className="text-white">
                      {selectedLead.segment || "Industrial / PJ"}
                    </strong>{" "}
                    • Cargo: {selectedLead.role}
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleRemoveLead}
                    className="p-1 px-2.5 bg-red-950/40 hover:bg-red-900/50 border border-red-800 text-red-400 font-mono text-[9px] font-bold rounded uppercase cursor-pointer"
                  >
                    Remover Lead
                  </button>
                </div>
              </div>

              {/* Lead Contact Info Block */}
              <div className="p-4 bg-slate-950/50 grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs text-slate-300 font-sans border-b border-slate-800">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block pb-0.5 border-b border-slate-800/60 font-bold">
                    Inspecionar Contato
                  </span>
                  <p>
                    ✉️ E-mail: <strong className="text-white font-mono">{selectedLead.email}</strong>
                  </p>
                  <p>
                    📞 Telefone:{" "}
                    <strong className="text-white font-mono">
                      {selectedLead.phone || "(Não informado)"}
                    </strong>
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase tracking-wider text-slate-500 block pb-0.5 border-b border-slate-800/60 font-bold">
                    Foco de Interesse
                  </span>
                  <p>
                    Módulo: <strong className="text-amber-400 font-bold">{selectedLead.interest}</strong>
                  </p>
                  <p>
                    SLA de Atendimento:{" "}
                    <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 font-mono text-[9.5px] font-black border border-amber-500/20">
                      24H CORPORATIVA
                    </span>
                  </p>
                </div>
              </div>

              {/* Captured Diagnostic Data Block */}
              {selectedLead.diagnosticData && (
                <div className="p-4 bg-slate-950/40 text-slate-300 space-y-3.5 border-b border-slate-800">
                  <span className="text-[9.5px] font-mono font-black uppercase text-amber-500 tracking-wider block border-b border-slate-800 pb-1 font-bold">
                    📋 Diagnóstico Capturado de Entrada
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                    <div className="space-y-1.5">
                      <p>
                        👤 Domínio:{" "}
                        <strong className="text-white">
                          {selectedLead.diagnosticData.audienceType === "LEIGO"
                            ? "💡 Pessoa Leiga (Simples/Guiado)"
                            : "🛡️ Especialista LSS (Avançado)"}
                        </strong>
                      </p>
                      <p>
                        📊 Volume Mensal:{" "}
                        <strong className="text-white">
                          {(selectedLead.diagnosticData.volume || 0).toLocaleString("pt-BR")} itens
                        </strong>
                      </p>
                      <p>
                        🎯 Taxa de Defeito:{" "}
                        <strong className="text-amber-400">
                          {selectedLead.diagnosticData.defectRatePercent}%
                        </strong>
                      </p>
                    </div>
                    <div className="space-y-1.5">
                      <p>
                        💸 Desperdício COPQ Anual:{" "}
                        <strong className="text-red-400">
                          R${" "}
                          {Math.round(
                            selectedLead.diagnosticData.estimatedAnnualWaste || 0
                          ).toLocaleString("pt-BR")}
                        </strong>
                      </p>
                      <p>
                        💰 Economia Líquida:{" "}
                        <strong className="text-emerald-400 font-bold">
                          R${" "}
                          {Math.round(
                            selectedLead.diagnosticData.estimatedSavingsAfterE3I || 0
                          ).toLocaleString("pt-BR")}
                        </strong>
                      </p>
                      <p>
                        📈 Score da Operação:{" "}
                        <span className="text-white bg-slate-800 px-1.5 py-0.5 font-mono text-[11px] font-bold">
                          {selectedLead.diagnosticData.score}/100
                        </span>
                      </p>
                    </div>
                  </div>

                  {/* Advice Card */}
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-none text-xs">
                    <p className="font-mono font-bold text-amber-400 block mb-1">
                      Recomendação LSS Recomendada:
                    </p>
                    <p className="text-slate-400 leading-relaxed font-sans">
                      {selectedLead.diagnosticData.advice}
                    </p>
                  </div>

                  {/* Specific Answers */}
                  <div className="p-3 bg-slate-900/50 text-[11px] font-mono space-y-1.5 border border-dashed border-slate-800">
                    <span className="text-slate-400 font-bold block mb-1">
                      Respostas do Questionário de Entrada:
                    </span>
                    {selectedLead.diagnosticData.audienceType === "LEIGO" ? (
                      <>
                        <p>
                          • Dor Principal:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.pain === "gargalo"
                              ? "Demora para entregar tarefas (Gargalos)"
                              : selectedLead.diagnosticData.answers?.pain === "qualidade"
                              ? "Erros frequentes e retrabalhos"
                              : "Falta de processos padronizados"}
                          </strong>
                        </p>
                        <p>
                          • Métricas Atuais:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.measurement === "sentimento"
                              ? "No sentimento / Olhômetro"
                              : selectedLead.diagnosticData.answers?.measurement === "excel"
                              ? "Planilhas manuais de Excel"
                              : "Sem medição ativa"}
                          </strong>
                        </p>
                        <p>
                          • Tamanho do Time:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.teamSize === "1-5"
                              ? "1 a 5 colaboradores"
                              : selectedLead.diagnosticData.answers?.teamSize === "6-20"
                              ? "6 a 20 colaboradores"
                              : "Mais de 20 colaboradores"}
                          </strong>
                        </p>
                      </>
                    ) : (
                      <>
                        <p>
                          • Metodologia:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.methodology === "nenhuma"
                              ? "Sem metodologia padrão"
                              : selectedLead.diagnosticData.answers?.methodology === "kaizen"
                              ? "Práticas Kaizen esporádicas"
                              : "Projetos DMAIC consistentes"}
                          </strong>
                        </p>
                        <p>
                          • Estabilidade:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.stability === "alta_var"
                              ? "Alta instabilidade e atrasos de SLA"
                              : selectedLead.diagnosticData.answers?.stability === "moderada"
                              ? "Estabilidade moderada com gráficos manuais"
                              : "Estabilidade rígida CPK > 1.33"}
                          </strong>
                        </p>
                        <p>
                          • Meta Trimestre:{" "}
                          <strong className="text-white">
                            {selectedLead.diagnosticData.answers?.engineeringMeta === "lead_time"
                              ? "Redução de Lead Time / WIP"
                              : selectedLead.diagnosticData.answers?.engineeringMeta === "sigma_level"
                              ? "Redução de refugo / Elevar nível Sigma"
                              : "Alocação Linear de Capacidade Simplex"}
                          </strong>
                        </p>
                        <p className="text-indigo-400 font-bold mt-1.5">
                          Métricas Avançadas de Simulação:
                        </p>
                        <p className="text-slate-300">
                          • Tempo Médio de Atendimento (T):{" "}
                          {selectedLead.diagnosticData.answers?.serviceTime} min
                        </p>
                        <p className="text-slate-300">
                          • Desvio Padrão do Serviço (s):{" "}
                          {selectedLead.diagnosticData.answers?.serviceVariance} min
                        </p>
                        <p className="text-slate-300">
                          • Quantidade de Operadores (c):{" "}
                          {selectedLead.diagnosticData.answers?.serversCount}
                        </p>
                        <p className="text-slate-300">
                          • Ocupação Teórica do Sistema (ρ):{" "}
                          {selectedLead.diagnosticData.answers?.utilizationPercent}%
                        </p>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Lead Status Update Area */}
              <div className="p-4 bg-slate-950/80 border-t border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <p className="font-bold text-amber-500 font-mono uppercase tracking-wider text-[10px]">
                    Situação de Atendimento:
                  </p>
                  <p className="text-[10.5px] text-slate-400">
                    Mude a chave de funil comercial do lead abaixo.
                  </p>
                </div>
                <div className="shrink-0">
                  <select
                    value={selectedLead.status}
                    onChange={(e) => handleStatusChange(e.target.value)}
                    className="px-2.5 py-1.5 uppercase font-mono bg-slate-900 text-amber-400 border border-slate-800 font-bold focus:outline-none focus:border-amber-500"
                  >
                    <option value="Pendente">🔴 Pendente de Triagem</option>
                    <option value="Em Atendimento">🟡 Em Atendimento</option>
                    <option value="Proposta Enviada">🔵 Proposta Comercial Disparada</option>
                    <option value="Ganho">🟢 Ganho / Ativar Licença</option>
                    <option value="Recusado">⚫ Recusado / Arquivado</option>
                  </select>
                </div>
              </div>

              {/* Interactive Proposal Configurator */}
              <div className="p-4 space-y-4 bg-slate-900 border-t border-slate-800">
                <span className="text-[9.5px] font-mono font-black uppercase text-amber-500 tracking-wider block border-b border-slate-800 pb-1 flex items-center gap-1.5 animate-pulse font-bold">
                  ⚙️ Configurar Proposta Comercial (ROI &amp; Licenças)
                </span>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                  {/* Price Input */}
                  <div className="space-y-1">
                    <label className="text-[9px] text-slate-400 font-bold uppercase block">
                      Preço Recorrente (Mês):
                    </label>
                    <div className="relative">
                      <span className="absolute left-1.5 top-1.5 text-slate-500">R$</span>
                      <input
                        type="number"
                        value={customProposalPrice}
                        onChange={(e) => setCustomProposalPrice(Number(e.target.value))}
                        className="w-full bg-slate-950 text-white border border-slate-800 pl-6 pr-1.5 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
                      />
                    </div>
                  </div>

                  {/* Licenses Count */}
                  <div className="space-y-1">
                    <label className="text-[9px] text-slate-400 font-bold uppercase block">
                      Licenças Inclusas PJ:
                    </label>
                    <input
                      type="number"
                      value={customLicencesCount}
                      onChange={(e) => setCustomLicencesCount(Number(e.target.value))}
                      className="w-full bg-slate-950 text-white border border-slate-800 px-2 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
                    />
                  </div>

                  {/* Consulting Hours */}
                  <div className="space-y-1">
                    <label className="text-[9px] text-slate-400 font-bold uppercase block">
                      Prática / Coaching (H):
                    </label>
                    <input
                      type="number"
                      value={customConsultingHours}
                      onChange={(e) => setCustomConsultingHours(Number(e.target.value))}
                      className="w-full bg-slate-950 text-white border border-slate-800 px-2 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
                    />
                  </div>

                  {/* SLA Support Tier */}
                  <div className="space-y-1">
                    <label className="text-[9px] text-slate-400 font-bold uppercase block">
                      Acordo de SLA Técnico:
                    </label>
                    <select
                      value={customSupportSla}
                      onChange={(e) => setCustomSupportSla(e.target.value)}
                      className="w-full bg-slate-950 text-amber-400 border border-slate-800 py-1.5 px-1.5 focus:outline-none focus:border-amber-500 font-sans text-[11px] font-bold"
                    >
                      <option value="SLA Standard 24h">Standard 24h</option>
                      <option value="SLA 12h Master">12h Master</option>
                      <option value="SLA Black Belt Premium 4h">Premium Black Belt 4h</option>
                    </select>
                  </div>
                </div>

                {/* Draft Preview Textarea */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-[9px] font-mono tracking-wider text-slate-500 block pb-0.5">
                    <span>RASCUNHO DINÂMICO DA PROPOSTA DE CONTRATUALIZAÇÃO</span>
                    <button
                      type="button"
                      onClick={handleOptimiseScope}
                      className="text-amber-500 hover:underline hover:text-amber-400 font-extrabold cursor-pointer flex items-center gap-1 font-bold"
                    >
                      ⚡ Otimizar Redação via IA E3I
                    </button>
                  </div>
                  <textarea
                    rows={8}
                    value={customProposalScope}
                    onChange={(e) => setCustomProposalScope(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 p-3 font-mono text-[10.5px] leading-relaxed border border-slate-800 h-[240px] focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Submission triggers */}
                <div className="border-t border-slate-800 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <p className="text-[10.5px] text-slate-400 leading-tight">
                    Ao acionar o botão de envio, a proposta será compilada e enviada via canal seguro direto ao lead.
                  </p>
                  <div className="flex flex-wrap items-center gap-2">
                    {selectedLead.status === "Proposta Enviada" && (
                      <button
                        type="button"
                        onClick={handleSimulateAcceptance}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono font-black text-xs uppercase tracking-wider py-2 md:py-2.5 px-4 transition-transform active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer rounded-none border border-emerald-800 font-bold"
                      >
                        Simular Aceite Cliente 🤝
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={handleSendProposal}
                      className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-black text-xs uppercase tracking-wider py-2 md:py-2.5 px-6 shrink-0 transition-transform active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer rounded-none border border-amber-600 font-bold"
                    >
                      <Send size={12} className="animate-pulse" />
                      Enviar Proposta Oficial ✓
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center p-12 text-center text-slate-400 gap-3 min-h-[480px]">
              <div className="w-16 h-16 bg-slate-950 border border-slate-800 rounded-none flex items-center justify-center text-2xl text-slate-500">
                📈
              </div>
              <div className="space-y-1">
                <p className="font-serif text-[13px] text-amber-500 font-extrabold font-sans uppercase tracking-wider font-bold">
                  Triagem e Funil CRM Leads
                </p>
                <p className="text-xs max-w-xs leading-normal text-slate-400">
                  Selecione um lead na lista lateral para prosseguir no atendimento e formular o orçamento comercial adequado de implantação.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
