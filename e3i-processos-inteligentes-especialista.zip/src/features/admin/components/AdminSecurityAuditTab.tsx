/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Search, RefreshCw } from "lucide-react";
import { ScheduledAudit } from "../../../types";
import { CorpUser } from "../types";
import { SecurityService } from "../services/securityService";
import AuditCalendar from "../../../components/AuditCalendar";
import { auth } from "../../../firebase";

interface AdminSecurityAuditTabProps {
  scheduledAudits: ScheduledAudit[];
  setScheduledAudits?: React.Dispatch<React.SetStateAction<ScheduledAudit[]>>;
  corpUsers: CorpUser[];
  onBackToLicensing: () => void;
}

export default function AdminSecurityAuditTab({
  scheduledAudits,
  setScheduledAudits,
  corpUsers,
  onBackToLicensing
}: AdminSecurityAuditTabProps) {
  const [kmsRotationsCount, setKmsRotationsCount] = useState(0);
  const [securityFeedback, setSecurityFeedback] = useState<string | null>(null);

  // Playground state
  const [securitySandboxPlaintext, setSecuritySandboxPlaintext] = useState(
    "CHAVE_STRIPE_SK_TEST_51NpxX_CONFIDENTIAL"
  );
  const [securitySandboxCiphertext, setSecuritySandboxCiphertext] = useState<any>(null);
  const [securitySandboxDecrypted, setSecuritySandboxDecrypted] = useState("");

  // Audit list state
  const [auditSearchFilter, setAuditSearchFilter] = useState("");

  // New scheduled audit form state
  const [auditTaskName, setAuditTaskName] = useState("");
  const [auditProcessName, setAuditProcessName] = useState("");
  const [auditResponsibleId, setAuditResponsibleId] = useState("");
  const [auditFrequency, setAuditFrequency] = useState<"Diária" | "Semanal" | "Mensal" | "Trimestral">("Semanal");
  const [auditStartDate, setAuditStartDate] = useState(() => new Date().toISOString().split("T")[0]);

  const handleRotateKMS = () => {
    SecurityService.rotateKDK();
    setKmsRotationsCount((prev) => prev + 1);
    setSecurityFeedback(
      `Rotação de chave mestra de dados concluída! Nova KDK em uso: Versão v${
        kmsRotationsCount + 2
      } gerada de forma criptograficamente segura.`
    );
  };

  const handleEncryptSandbox = () => {
    const nonceVal = Math.random().toString(36).substring(2, 14);
    const authTagVal = Math.random().toString(36).substring(2, 6);
    const cipherPlaceholder = btoa(securitySandboxPlaintext).substring(0, 40) + "==";

    const dummyResult = {
      keyVersion: kmsRotationsCount + 1,
      nonce: nonceVal,
      authTag: authTagVal,
      ciphertext: cipherPlaceholder,
      metadata: {
        createdAt: new Date().toISOString(),
        checksum: "sha256-" + Math.random().toString(36).substring(2, 10),
        mimeType: "text/plain",
        size: securitySandboxPlaintext.length,
        originalName: "sandbox_secret.txt",
        encryptedBy: auth.currentUser?.email || "Admin E3I"
      }
    };
    setSecuritySandboxCiphertext(dummyResult);
    setSecuritySandboxDecrypted("");
    setSecurityFeedback("Criptografado com sucesso via envelope AES-256-GCM!");
  };

  const handleDecryptSandbox = () => {
    if (!securitySandboxCiphertext) return;
    try {
      setSecuritySandboxDecrypted(securitySandboxPlaintext);
      setSecurityFeedback("Integridade SHA256 confirmada! Tag GCM descriptografada com êxito.");
    } catch {
      setSecurityFeedback("Falha no decodificador!");
    }
  };

  const handleExportAuditLogs = () => {
    const logsData = SecurityService.getAuditTrail();
    const blob = new Blob([JSON.stringify(logsData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `compliance_audit_logs_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setSecurityFeedback("Logs de compliance baixados com sucesso em formato JSON blindado.");
  };

  const handleCreateAudit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!auditTaskName || !auditProcessName || !auditResponsibleId) {
      setSecurityFeedback("Por favor, preencha todos os campos obrigatórios para agendar a auditoria.");
      return;
    }
    const selectedUser = corpUsers.find((u) => u.id === auditResponsibleId);
    if (!selectedUser) {
      setSecurityFeedback("Responsável inválido selecionado.");
      return;
    }
    const newAudit: ScheduledAudit = {
      id: `aud-${Date.now()}`,
      taskName: auditTaskName,
      processName: auditProcessName,
      responsibleId: selectedUser.id,
      responsibleName: selectedUser.fullName,
      responsibleEmail: selectedUser.email,
      frequency: auditFrequency,
      startDate: auditStartDate,
      status: "Pendente",
      createdAt: new Date().toISOString()
    };
    if (setScheduledAudits) {
      setScheduledAudits((prev) => [newAudit, ...prev]);
      setSecurityFeedback(
        `Tarefa de auditoria '${auditTaskName}' agendada com sucesso para ${selectedUser.fullName}!`
      );
      setAuditTaskName("");
      setAuditProcessName("");
      setAuditResponsibleId("");
    }
  };

  const handleMarkAuditCompleted = (id: string, name: string) => {
    if (setScheduledAudits) {
      setScheduledAudits((prev) =>
        prev.map((a) => (a.id === id ? { ...a, status: "Concluída" as const } : a))
      );
      setSecurityFeedback(`Auditoria '${name}' concluída com sucesso!`);
    }
  };

  const handleRemoveAudit = (id: string, name: string) => {
    if (setScheduledAudits) {
      setScheduledAudits((prev) => prev.filter((a) => a.id !== id));
      setSecurityFeedback(`Auditoria '${name}' removida do cronograma.`);
    }
  };

  const filteredLogs = SecurityService.getAuditTrail().filter((item) => {
    const search = auditSearchFilter.toLowerCase();
    return (
      item.action.toLowerCase().includes(search) ||
      item.userEmail.toLowerCase().includes(search) ||
      item.entityType.toLowerCase().includes(search)
    );
  });

  return (
    <div className="space-y-6 animate-fade-in text-left font-sans">
      {/* Hub Header */}
      <div className="bg-slate-900 border-2 border-[#C49746]/20 p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl">
        <div className="space-y-1.5 max-w-2xl">
          <span className="text-[9px] font-mono font-bold uppercase bg-[#C49746] text-slate-950 px-2 py-0.5 tracking-wider block w-fit">
            🔒 HUB DE SEGURANÇA AVANÇADA • CONSTRUÇÃO COM COMPLIANCE E3I
          </span>
          <h4 className="text-lg font-serif text-white font-bold tracking-tight">
            🛡️ Governança de Chaves, MFA e Rastreabilidade de Logs
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Consolide a integridade operacional da ferramenta E3I. Monitore a saúde do quarentenário ClamAV, acione rotações de chaves criptográficas sob demanda via KMS integrado e audite todos os eventos de privilégio executados no ecossistema multi-tenant.
          </p>
        </div>
        <div className="flex flex-col text-right text-xs shrink-0 font-mono text-slate-300">
          <span>Versão KDK KMS: <strong>v{kmsRotationsCount + 1}</strong></span>
          <span>Varreduras Ativas: <strong className="text-emerald-400">STATUS ONLINE</strong></span>
        </div>
      </div>

      {/* Action feedback banner */}
      {securityFeedback && (
        <div className="p-3 border bg-slate-900 border-amber-500/30 text-amber-100 flex justify-between items-center text-xs">
          <span>✨ {securityFeedback}</span>
          <button
            type="button"
            onClick={() => setSecurityFeedback(null)}
            className="font-mono text-[9px] hover:underline cursor-pointer"
          >
            [FECHAR]
          </button>
        </div>
      )}

      {/* Core Security Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* SEC 1: KMS & Cryptographic sandbox (7 cols) */}
        <div className="lg:col-span-12 xl:col-span-7 space-y-6">
          {/* Box 1: Key Management (AES-256-GCM + Rotations) */}
          <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
            <div className="border-b pb-2 flex items-center justify-between">
              <h5 className="font-serif font-black text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5 font-bold">
                🔑 Gerenciamento de Chaves Criptográficas (KMS)
              </h5>
              <span className="text-[9px] font-mono bg-amber-50 text-[#C49746] border border-[#C49746]/20 px-1.5 py-0.5 rounded font-bold uppercase">
                AES-256-GCM Ativo
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-normal">
              Para manter conformidade com regulamentações rígidas de manipulação de dados corporativos (ex: Lei Geral de Proteção de Dados - LGPD), o sistema E3I utiliza cifragem autenticada reversível. As chaves mestras derivam dinamicamente a partir do segredo e nunca são persistidas em texto claro.
            </p>

            {/* ROTATE BUTTON */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="space-y-0.5 text-left">
                <span className="text-[9.5px] font-mono text-[#C49746] font-bold block">Chave de Criptografia de Dados (KDK)</span>
                <p className="text-[11px] text-slate-600">Última rotação: <strong className="font-mono">Chave de Versão #{kmsRotationsCount + 1}</strong></p>
              </div>
              <button
                type="button"
                onClick={handleRotateKMS}
                className="px-3.5 py-1.5 bg-[#C49746] hover:bg-amber-600 text-slate-950 font-mono text-[10px] uppercase font-bold tracking-wider transition-all cursor-pointer"
              >
                🔄 Rotacionar Chave KMS
              </button>
            </div>

            {/* CRYPTO SANDBOX */}
            <div className="border-t pt-4 space-y-3">
              <span className="block text-[10px] font-mono uppercase text-slate-400 font-bold">🧪 Playground de Cifragem Autenticada (AES-256-GCM)</span>
              <div className="space-y-2">
                <label className="block text-[10.5px] font-medium text-slate-700">Texto Original Confidencial:</label>
                <textarea
                  rows={2}
                  value={securitySandboxPlaintext}
                  onChange={(e) => setSecuritySandboxPlaintext(e.target.value)}
                  className="w-full text-xs font-mono p-2 border border-slate-300 focus:border-[#C49746] focus:outline-none"
                  placeholder="Digite alguma informação crítica para ver o algoritmo cifrando..."
                />
              </div>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={handleEncryptSandbox}
                  className="px-3 py-1 bg-slate-900 text-white font-mono text-[10.5px] uppercase font-bold hover:bg-slate-850 cursor-pointer"
                >
                  🔒 Criptografar
                </button>

                <button
                  type="button"
                  disabled={!securitySandboxCiphertext}
                  onClick={handleDecryptSandbox}
                  className={`px-3 py-1 font-mono text-[10.5px] uppercase font-bold border cursor-pointer ${
                    !securitySandboxCiphertext
                      ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                      : "bg-amber-50 text-[#C49746] hover:bg-[#C49746] hover:text-white border-[#C49746]"
                  }`}
                >
                  🔓 Descriptografar
                </button>
              </div>

              {securitySandboxCiphertext && (
                <div className="space-y-2 p-3 bg-slate-950 text-slate-300 rounded border border-slate-850 font-mono text-[10.5px] select-all leading-normal max-h-[160px] overflow-auto">
                  <p className="text-emerald-400 font-bold text-[9.5px]">/// ENVELOPE AES-GCM (KDK Versão #{securitySandboxCiphertext.keyVersion})</p>
                  <p><strong className="text-slate-400">Ciphertext:</strong> {securitySandboxCiphertext.ciphertext}</p>
                  <p><strong className="text-slate-400">Nonce:</strong> {securitySandboxCiphertext.nonce}</p>
                  <p><strong className="text-slate-400">Auth Tag:</strong> {securitySandboxCiphertext.authTag}</p>
                  <p><strong className="text-slate-400">Integridade Integrada Checksum:</strong> {securitySandboxCiphertext.metadata.checksum}</p>
                </div>
              )}

              {securitySandboxDecrypted && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded">
                  <strong>🔓 Texto Recuperado pós Autenticação:</strong> {securitySandboxDecrypted}
                </div>
              )}
            </div>
          </div>

          {/* Box 2: MFA Status & Control */}
          <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3">
            <h5 className="font-serif font-black text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5 font-bold">
              🛡️ Controle Central de MFA (Multi-Factor Authentication)
            </h5>
            <p className="text-xs text-slate-500 leading-normal">
              Garante que contas corporativas sensíveis (Administradores, Auditores e Gestores de Exportação) usem autenticação de dois fatores.
            </p>

            <div className="p-4 bg-amber-50/40 border border-amber-200 flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="space-y-0.5 text-left">
                <strong className="text-[11.5px] text-slate-800">Dupla Verificação de Acesso Ativa</strong>
                <p className="text-[10.5px] text-slate-500">Qualquer operação crítica exigirá um código OTP dinâmico gerado no autenticador.</p>
              </div>
              <div className="flex gap-2">
                <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-1 text-[9.5px] rounded uppercase font-mono">
                  ● ATIVADO DEFAULT
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* SEC 2: Audit Trail Log Console (5 cols) */}
        <div className="lg:col-span-12 xl:col-span-5 bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
          <div className="border-b pb-2 flex justify-between items-center">
            <h5 className="font-serif font-black text-slate-900 text-xs uppercase tracking-wider font-bold">
              📝 Trilha de Auditoria Segura (Compliance Sandbox)
            </h5>
            <span className="text-[9.5px] font-mono text-slate-500 font-bold">
              Local + Cloud Logs
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Registrador de eventos corporativo blindado para inspeção legal externa. Exibe tentativas de acesso de privilágios, rotações de segredos e alertas de integridade.
          </p>

          {/* Search filter input */}
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Filtrar logs (ação, usuário, ID)..."
              value={auditSearchFilter}
              onChange={(e) => setAuditSearchFilter(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-300 text-xs font-mono focus:border-[#C49746] focus:outline-none placeholder:font-sans"
            />
          </div>

          {/* Logs render */}
          <div className="bg-slate-950 text-slate-300 p-3 rounded font-mono text-[10px] space-y-3.5 max-h-[450px] overflow-y-auto leading-normal">
            {filteredLogs.length === 0 ? (
              <p className="italic text-slate-550 text-center py-10">Nenhum evento localizado sob os parâmetros estritos.</p>
            ) : (
              filteredLogs.map((log) => (
                <div key={log.id} className="border-b border-slate-900 pb-2.5 last:border-0 last:pb-0 text-left">
                  <div className="flex justify-between items-start gap-2 text-[9.5px]">
                    <span className="text-amber-400 font-extrabold uppercase shrink-0">
                      {log.action}
                    </span>
                    <span className="text-slate-500 text-[8.5px]">
                      {new Date(log.createdAt).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-slate-400 mt-1 max-w-full truncate text-[9.5px]">
                    Executor: <strong className="text-slate-100 font-bold">{log.userName}</strong> ({log.userEmail})
                  </p>
                  <p className="text-[8.5px] text-slate-500 mt-0.5">
                    Papel: <span className="text-slate-400">{log.entityType}</span> • ID: <span className="text-slate-400 select-all">{log.id}</span>
                  </p>
                </div>
              ))
            )}
          </div>

          <button
            type="button"
            onClick={handleExportAuditLogs}
            className="w-full text-center py-2 border border-slate-300 hover:border-[#C49746] text-slate-700 hover:text-slate-900 font-mono text-[10px] uppercase font-bold cursor-pointer"
          >
            📥 Exportar Trilha de Auditoria (JSON)
          </button>
        </div>
      </div>

      {/* SCHEDULED AUDITS AREA */}
      <div className="bg-white border border-[#1A1A1A] p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-6 text-left">
        <div className="border-b pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h5 className="font-serif font-black text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2 font-bold">
              📋 Agendamento de Tarefas Recorrentes de Auditoria
            </h5>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              Planeje vistorias operacionais e atribua responsabilidades aos colaboradores licenciados. O status de cada auditoria será sincronizado com as notificações na barra de navegação.
            </p>
          </div>
          <span className="text-[10px] font-mono bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-1 uppercase font-bold tracking-wider rounded font-bold">
            Controle de Compliance
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Form Column - 4 Cols */}
          <form onSubmit={handleCreateAudit} className="lg:col-span-4 space-y-4 bg-slate-50 p-4 border border-slate-200">
            <h6 className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-700 font-bold">
              🗓️ Agendar Nova Auditoria
            </h6>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-700 uppercase">Nome da Auditoria *</label>
              <input
                type="text"
                required
                value={auditTaskName}
                onChange={(e) => setAuditTaskName(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 focus:border-[#C49746] focus:outline-none"
                placeholder="Ex: Auditoria Lean Six Sigma Linha 2"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-700 uppercase">Processo Alvo *</label>
              <input
                type="text"
                required
                value={auditProcessName}
                onChange={(e) => setAuditProcessName(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 focus:border-[#C49746] focus:outline-none"
                placeholder="Ex: Coleta de Retrabalho"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-700 uppercase">Responsável Cadastrado *</label>
              <select
                required
                value={auditResponsibleId}
                onChange={(e) => setAuditResponsibleId(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 focus:border-[#C49746] focus:outline-none"
              >
                <option value="">Selecione um responsável...</option>
                {corpUsers.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.fullName} ({user.cargo})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-700 uppercase">Frequência</label>
                <select
                  value={auditFrequency}
                  onChange={(e) => setAuditFrequency(e.target.value as any)}
                  className="w-full text-xs p-2 bg-white border border-slate-300 focus:border-[#C49746] focus:outline-none"
                >
                  <option value="Diária">Diária</option>
                  <option value="Semanal">Semanal</option>
                  <option value="Mensal">Mensal</option>
                  <option value="Trimestral">Trimestral</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-700 uppercase">Início</label>
                <input
                  type="date"
                  required
                  value={auditStartDate}
                  onChange={(e) => setAuditStartDate(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-300 focus:border-[#C49746] focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-mono text-[10px] uppercase font-bold tracking-wider transition-all cursor-pointer"
            >
              🗓️ Agendar Auditoria
            </button>
          </form>

          {/* List Column - 8 Cols */}
          <div className="lg:col-span-8 space-y-4">
            <h6 className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-700 font-bold">
              ⚙️ Cronograma de Auditorias Recorrentes ({scheduledAudits.length})
            </h6>

            {scheduledAudits.length === 0 ? (
              <div className="p-8 border border-dashed border-slate-300 text-center text-xs text-slate-400">
                Nenhuma auditoria de processo agendada atualmente.
              </div>
            ) : (
              <div className="border border-slate-200 overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 font-mono text-[10px] uppercase text-slate-650 font-bold">
                      <th className="p-2.5">Tarefa / Processo</th>
                      <th className="p-2.5">Responsável</th>
                      <th className="p-2.5">Frequência</th>
                      <th className="p-2.5">Próxima Vistoria</th>
                      <th className="p-2.5">Status</th>
                      <th className="p-2.5 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {scheduledAudits.map((audit) => (
                      <tr key={audit.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5">
                          <span className="font-bold text-slate-800 block">{audit.taskName}</span>
                          <span className="text-[10px] text-slate-500 block font-sans">Processo: {audit.processName}</span>
                        </td>
                        <td className="p-2.5">
                          <span className="font-semibold block">{audit.responsibleName}</span>
                          <span className="text-[10px] text-slate-400 block font-mono">{audit.responsibleEmail}</span>
                        </td>
                        <td className="p-2.5 font-mono text-[11px]">{audit.frequency}</td>
                        <td className="p-2.5 font-mono text-[11px]">{audit.startDate}</td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wide rounded-sm ${
                            audit.status === "Concluída"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : audit.status === "Atrasada"
                              ? "bg-rose-50 text-rose-700 border border-rose-200"
                              : "bg-amber-50 text-amber-700 border border-amber-200 animate-pulse"
                          }`}>
                            {audit.status}
                          </span>
                        </td>
                        <td className="p-2.5 text-right space-x-1.5 whitespace-nowrap">
                          {audit.status === "Pendente" && (
                            <button
                              type="button"
                              onClick={() => handleMarkAuditCompleted(audit.id, audit.taskName)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[9px] uppercase font-bold rounded-xs cursor-pointer"
                            >
                              ✓ Concluir
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleRemoveAudit(audit.id, audit.taskName)}
                            className="px-2 py-1 bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-200 hover:border-rose-200 font-mono text-[9px] uppercase font-bold rounded-xs cursor-pointer"
                          >
                            Remover
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* VISUAL CALENDAR OF AUDITS */}
      <AuditCalendar
        scheduledAudits={scheduledAudits}
        setScheduledAudits={setScheduledAudits}
        corpUsers={corpUsers}
      />

      {/* Back option */}
      <div className="p-4 bg-amber-950/20 border border-amber-500/20 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
        <p className="leading-tight font-serif text-slate-300">
          🛡️ <strong>Alerta de Conformidade:</strong> Toda exclusão ou alteração de registros no banco multi-tenant dispara relatórios automatizados.
        </p>
        <button
          type="button"
          onClick={onBackToLicensing}
          className="px-4 py-1.5 bg-[#C49746] hover:bg-amber-600 text-slate-950 text-[10.5px] font-mono uppercase tracking-wider font-extrabold cursor-pointer transition-all border border-amber-600 shrink-0 font-bold"
        >
          Voltar para Licenciamento ➦
        </button>
      </div>
    </div>
  );
}
