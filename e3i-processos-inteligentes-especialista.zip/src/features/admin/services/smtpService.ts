/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SMTPSettings, SMTPLog } from "../types";

export const SMTPService = {
  getInitialSettings(): SMTPSettings {
    try {
      const enabled = localStorage.getItem("lss_smtp_enabled") === "true";
      const host = localStorage.getItem("lss_smtp_host") || "smtp.empresa.com";
      const port = Number(localStorage.getItem("lss_smtp_port")) || 587;
      const user = localStorage.getItem("lss_smtp_user") || "alerta@empresa.com";
      const fromName = localStorage.getItem("lss_smtp_from_name") || "Motor de Estabilidade e3i";
      const fromEmail = localStorage.getItem("lss_smtp_from_email") || "alerta@empresa.com";
      const ssl = localStorage.getItem("lss_smtp_ssl") !== "false";

      return {
        enabled,
        host,
        port,
        user,
        pass: "••••••••••••••••",
        fromName,
        fromEmail,
        ssl
      };
    } catch {
      return {
        enabled: false,
        host: "smtp.empresa.com",
        port: 587,
        user: "alerta@empresa.com",
        pass: "••••••••••••••••",
        fromName: "Motor de Estabilidade e3i",
        fromEmail: "alerta@empresa.com",
        ssl: true
      };
    }
  },

  getInitialLogs(): SMTPLog[] {
    try {
      const v = localStorage.getItem("lss_smtp_logs");
      return v ? JSON.parse(v) : [
        {
          id: "log-smtp-init",
          timestamp: new Date(Date.now() - 36000000).toISOString().substring(0, 19).replace("T", " "),
          recipient: "alerta.critico@empresa.com",
          status: "SUCCESS",
          subject: "Ficha cp-1: Estabilização de Forno Ativa (Shewhart)",
          serverUsed: "smtp.empresa.com:587",
          details: "Conexão estabelecida e aceita. Handshake seguro finalizado via StartTLS obtendo 250 OK."
        }
      ];
    } catch {
      return [];
    }
  },

  saveSettings(settings: SMTPSettings): void {
    try {
      localStorage.setItem("lss_smtp_enabled", String(settings.enabled));
      localStorage.setItem("lss_smtp_host", settings.host);
      localStorage.setItem("lss_smtp_port", String(settings.port));
      localStorage.setItem("lss_smtp_user", settings.user);
      localStorage.setItem("lss_smtp_from_name", settings.fromName);
      localStorage.setItem("lss_smtp_from_email", settings.fromEmail);
      localStorage.setItem("lss_smtp_ssl", String(settings.ssl));
    } catch (err) {
      console.error("Error saving SMTP settings:", err);
    }
  },

  saveLogs(logs: SMTPLog[]): void {
    try {
      localStorage.setItem("lss_smtp_logs", JSON.stringify(logs));
    } catch (err) {
      console.error("Error saving SMTP logs:", err);
    }
  },

  simulateTestDispatch(
    recipient: string,
    settings: SMTPSettings,
    logs: SMTPLog[],
    setLogs: (logs: SMTPLog[]) => void
  ): Promise<SMTPLog> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newLog: SMTPLog = {
          id: `log-smtp-test-${Date.now()}`,
          timestamp: new Date().toISOString().substring(0, 19).replace("T", " "),
          recipient,
          status: "SUCCESS",
          subject: "TESTE: Gateway de E-mail Próprio e3i Ativado",
          serverUsed: `${settings.host}:${settings.port}`,
          details: `Mensagem de depuração transmitida com sucesso por ${settings.fromName} <${settings.fromEmail}>. Protocolo SMTP respondeu: '250 2.0.0 OK Message accepted inside Queue ID e3i-test-1010'`
        };

        const updated = [newLog, ...logs];
        setLogs(updated);
        this.saveLogs(updated);

        // System logs persistence fallback
        try {
          const savedSystemLogs = localStorage.getItem("lss_system_logs");
          const sysLogsList = savedSystemLogs ? JSON.parse(savedSystemLogs) : [];
          const sysLog = {
            id: `log-sys-smtp-test-${Date.now()}`,
            timestamp: new Date().toISOString(),
            ip: "127.0.0.1",
            user: "Administrador e3i",
            action: "Teste SMTP",
            details: `E-mail de teste de disparo enviado com sucesso para ${recipient} usando o servidor customizado ${settings.host}:${settings.port}`
          };
          localStorage.setItem("lss_system_logs", JSON.stringify([sysLog, ...sysLogsList]));
        } catch {}

        resolve(newLog);
      }, 1200);
    });
  }
};
