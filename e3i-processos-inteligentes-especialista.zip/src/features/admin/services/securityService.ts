/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { KMS } from "../../../utils/fileSecurityPipeline";
import { getLocalAuditTrail } from "../../../utils/auditLogger";

export const SecurityService = {
  getAuditTrail(): any[] {
    return getLocalAuditTrail();
  },

  rotateKDK(): void {
    KMS.rotateKMSKey();
  }
};
