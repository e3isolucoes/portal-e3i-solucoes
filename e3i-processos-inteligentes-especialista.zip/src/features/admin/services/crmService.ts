/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Lead, DiagnosticData } from "../types";
import { Company } from "../../../types";
import { CompanyProjectRepository } from "../../../repositories/CompanyProjectRepository";

export const CRMService = {
  getInitialLeads(): Lead[] {
    try {
      const saved = localStorage.getItem("lss_leads");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (err) {
      console.error("Error reading leads from localStorage:", err);
    }
    return [
      { id: "lead-1", name: "Carlos Henrique Souza", email: "carlos.souza@ambev.com.br", phone: "(11) 98122-3044", company: "Ambev Logistics", role: "Coordenador de Excelência", segment: "LOGISTICS", interest: "Teoria de Filas (G/G/c)", status: "Em Atendimento", date: "2026-06-07T10:30:00Z" },
      { id: "lead-2", name: "Beatriz Nogueira Prado", email: "beatriz.nogueira@itau.com.br", phone: "(11) 97321-4491", company: "Itaú Unibanco", role: "Gerente Operacional", segment: "FINANCE", interest: "Simplex / Alocação Ótima", status: "Proposta Enviada", date: "2026-06-08T08:15:00Z" },
      { id: "lead-3", name: "Marcio Roberto Dias", email: "marcio.dias@petrobras.com.br", phone: "(21) 99872-1102", company: "Petrobras S.A.", role: "Lead Engineer", segment: "MANUFACTURING", interest: "Mapeamento VSM / CEP", status: "Pendente", date: "2026-06-08T11:40:00Z" }
    ];
  },

  saveLeads(leads: Lead[]): void {
    try {
      localStorage.setItem("lss_leads", JSON.stringify(leads));
    } catch (err) {
      console.error("Error saving leads to localStorage:", err);
    }
  },

  logAction(action: string, details: string): void {
    try {
      const savedLogs = localStorage.getItem("lss_system_logs");
      const logsList = savedLogs ? JSON.parse(savedLogs) : [];
      const newLog = {
        id: `log-crm-${Date.now()}`,
        timestamp: new Date().toISOString(),
        ip: "177.34.120.10",
        user: "E3I Admin S.A.",
        action,
        details
      };
      localStorage.setItem("lss_system_logs", JSON.stringify([newLog, ...logsList]));
    } catch (err) {
      console.error("Error creating audit log:", err);
    }
  },

  generateProposalDraft(
    lead: Lead,
    licencesCount: number,
    consultingHours: number,
    supportSla: string,
    proposalPrice: number
  ): string {
    const pId = lead.id.split("-")[1] || "01";
    const roiVal = lead.segment === "LOGISTICS" || lead.segment === "MANUFACTURING" ? "120.000,00" : "85.000,00";
    const pbVal = lead.segment === "LOGISTICS" || lead.segment === "MANUFACTURING" ? "3" : "2";

    return `PROPOSTA COMERCIAL DE IMPLANTAÇÃO LEAN SIX SIGMA • E3I SOLUÇÕES S.A.

Destinatário: ${lead.company}
A/C: ${lead.name} (${lead.role})
Ref: Implantação de Suíte Digital LSS e Analítica Preditiva

1. ESCOPO DO TRABALHO & LICENCIAMENTO PJ
- Ativação de ${licencesCount} licenças corporativas válidas para usuários chave da empresa.
- Liberação integral dos módulos de modelagem BPM, Teoria de Filas Estocásticas, Simulação de Monte Carlo e BI avançado.
- Suporte técnico prioritário e Acordo de Nível de Serviço (${supportSla}).

2. MENTORIA & CAPACITAÇÃO OPERACIONAL
- Treinamento dedicado de ${consultingHours} horas ministrado por Especialista Black Belt da E3I.
- Elaboração do SIPOC preliminar para foco em: ${lead.interest}.

3. RETORNO FINANCEIRO ESTIMADO (ROI PREVISTO)
- Redução estocástica de gargalos projetando economias líquidas de BRL R$ ${roiVal} ao ano.
- Payback de investimento de capital projetado para: ${pbVal} meses.

4. INVESTIMENTO E CONDIÇÕES COMERCIAIS
- Taxa de Licenciamento Anualizada: BRL R$ ${(proposalPrice * 12).toLocaleString("pt-BR")},00
- Ou Parcelamento Mensal Recorrente: BRL R$ ${proposalPrice.toLocaleString("pt-BR")},00 por mês.
- Condição de pagamento: Faturamento via Boleto PJ com validade de 20 dias.`;
  },

  registerWinningCompany(
    companyName: string,
    segment: string,
    diagnosticData: DiagnosticData | undefined,
    existingCompanies: Company[],
    setCompanies: ((companies: Company[]) => void) | undefined,
    activeEmail: string,
    currentUserUid: string | undefined
  ): string {
    const mockCnpj = `23.456.789/0001-${Math.floor(Math.random() * 90 + 10)}`;
    const newComp: Company = {
      id: "comp-" + Math.random().toString(36).substring(2, 8),
      name: companyName || "Sem Nome",
      cnpj: mockCnpj,
      industry: segment === "LOGISTICS" ? "Logística" : segment === "MANUFACTURING" ? "Manufatura" : "Serviço",
      createdAt: new Date().toISOString(),
      enabledModules: ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "OR_HUB", "REPORT", "ENTERPRISE_STUDIO"],
      ownerId: currentUserUid || "",
      diagnosticData: diagnosticData
    };
    const newList = [...existingCompanies, newComp];
    if (setCompanies) {
      setCompanies(newList);
    }
    CompanyProjectRepository.saveCompanies(newList, activeEmail);
    return mockCnpj;
  }
};
