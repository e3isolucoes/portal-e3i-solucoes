import React, { useState, useMemo } from "react";
import { ReorgAction } from "./PriorityMatrix";
import { Calendar, CircleDot, ArrowRight, CheckCircle2, Clock, User, Award, ShieldAlert, Sparkles } from "lucide-react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";

interface ReorganizationRoadmapProps {
  actions: ReorgAction[];
  mode: UsabilityMode;
  onSelectAction?: (action: ReorgAction) => void;
}

interface RoadmapPhase {
  id: string;
  title: string;
  duration: string;
  description: string;
  badgeColor: string;
  borderColors: string;
}

const PHASES: RoadmapPhase[] = [
  {
    id: "fase1",
    title: "Fase 1: Alinhamento & Fundações",
    duration: "Dias 1 - 30",
    description: "Medidas urgentes de correção, diagnóstico inicial integrado e estruturação do plano estratégico de mudança.",
    badgeColor: "bg-red-50 text-red-700 border border-red-200",
    borderColors: "border-red-300 bg-red-50/5"
  },
  {
    id: "fase2",
    title: "Fase 2: Estabilização de Processos",
    duration: "Dias 31 - 60",
    description: "Revisão dos fluxos de trabalho críticos (BPMN), implantação de poka-yokes e combate ativo a desperdícios nos gargalos.",
    badgeColor: "bg-amber-50 text-amber-700 border border-amber-200",
    borderColors: "border-amber-300 bg-amber-50/5"
  },
  {
    id: "fase3",
    title: "Fase 3: Governança & RACI",
    duration: "Dias 61 - 90",
    description: "Saturação de responsabilidades, definição formal de acordos de nível de serviço (SLA) e novos limites de autoridade.",
    badgeColor: "bg-indigo-50 text-indigo-700 border border-indigo-200",
    borderColors: "border-indigo-300 bg-indigo-50/5"
  },
  {
    id: "fase4",
    title: "Fase 4: Consolidação Cultural",
    duration: "Dias 91+",
    description: "Plano de comunicação intensivo para retenção de talentos, treinamento continuado e auditoria integrada de resultados.",
    badgeColor: "bg-emerald-50 text-emerald-700 border border-emerald-250",
    borderColors: "border-emerald-300 bg-emerald-50/5"
  }
];

export default function ReorganizationRoadmap({
  actions,
  mode,
  onSelectAction
}: ReorganizationRoadmapProps) {
  const isExpert = isExpertMode(mode);
  const [selectedPhaseId, setSelectedPhaseId] = useState<string>("all");

  // Filter actions based on target dates or simple mapping for roadmap simulation:
  // - Phase 1: actions with ID ending in e_1 / e_2 or randomly/statically allocated
  // We'll distribute actions logically across the 4 phases:
  // Diagnostico & Estrategia -> Phase 1
  // Processos -> Phase 2
  // RACI -> Phase 3
  // Mudanca -> Phase 4
  const distributedPhases = useMemo(() => {
    return PHASES.map(phase => {
      let filtered: ReorgAction[] = [];
      if (phase.id === "fase1") {
        filtered = actions.filter(a => a.source === "diagnostico" || a.source === "estrategia");
      } else if (phase.id === "fase2") {
        filtered = actions.filter(a => a.source === "processos");
      } else if (phase.id === "fase3") {
        filtered = actions.filter(a => a.source === "raci");
      } else {
        filtered = actions.filter(a => a.source === "mudanca");
      }

      return {
        ...phase,
        actions: filtered
      };
    });
  }, [actions]);

  return (
    <div id="reorg-roadmap-panel" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title box */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h4 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#C49746]" />
            Cronograma e Roadmap da Mudança Organizacional
          </h4>
          <p className="text-xs text-slate-550">
            Acompanhe o sequenciamento temporal crítico da reorganização. Cada iniciativa está associada ao seu respectivo ciclo de maturidade (90+ dias).
          </p>
        </div>

        {/* Phase Filter Button bar */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
          <button
            onClick={() => setSelectedPhaseId("all")}
            className={`px-3 py-1 rounded text-[10.5px] font-bold uppercase transition-all cursor-pointer ${
              selectedPhaseId === "all" ? "bg-slate-900 text-white shadow-3xs" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Ver Tudo
          </button>
          {PHASES.map(phase => (
            <button
              key={phase.id}
              onClick={() => setSelectedPhaseId(phase.id)}
              className={`px-3 py-1 rounded text-[10.5px] font-bold uppercase transition-all cursor-pointer ${
                selectedPhaseId === phase.id ? "bg-slate-900 text-white shadow-3xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              F{phase.id.replace("fase", "")}
            </button>
          ))}
        </div>
      </div>

      {/* ROADMAP TIMELINE TRAILER DESIGN */}
      <div className="space-y-6">
        {distributedPhases
          .filter(p => selectedPhaseId === "all" || p.id === selectedPhaseId)
          .map((phase, pIdx) => {
            return (
              <div 
                key={phase.id} 
                className={`border-l-2 pl-5 sm:pl-6 relative pb-5 space-y-3 ${phase.borderColors}`}
              >
                {/* Timeline node icon */}
                <div className="absolute -left-[11px] top-0.5 bg-white rounded-full p-0.5 border-2 border-slate-300">
                  <CircleDot className="w-4 h-4 text-[#C49746] animate-pulse" />
                </div>

                {/* Phase Header details */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-extrabold text-slate-950 font-serif">{phase.title}</h4>
                      <span className={`text-[9.5px] font-mono font-black uppercase px-2 py-0.5 rounded-full ${phase.badgeColor}`}>
                        {phase.duration}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">{phase.description}</p>
                  </div>

                  <span className="text-[10px] text-slate-400 font-mono italic">
                    {phase.actions.length} ações vinculadas
                  </span>
                </div>

                {/* Grid of Actions belonging to this Phase */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                  {phase.actions.length === 0 ? (
                    <div className="col-span-full border border-dashed border-slate-200 rounded-xl p-4 text-center bg-slate-50">
                      <p className="text-[11px] text-slate-450 italic font-medium">Nenhuma ação vinculada a este estágio.</p>
                    </div>
                  ) : (
                    phase.actions.map(action => {
                      const isComplete = action.status === "concluido";
                      const isInProgress = action.status === "em_andamento";
                      
                      const badgeLabel = 
                        action.status === "concluido" ? "Concluído" :
                        action.status === "em_andamento" ? "Em Andamento" :
                        action.status === "cancelado" ? "Cancelado" : "Planejado";

                      const borderStyle = 
                        isComplete ? "border-emerald-200 bg-emerald-50/10" :
                        isInProgress ? "border-amber-200 bg-amber-50/10" :
                        "border-slate-200 bg-white hover:shadow-3xs";

                      return (
                        <div 
                          key={action.id}
                          onClick={() => onSelectAction?.(action)}
                          className={`border rounded-xl p-4.5 text-left space-y-3 transition-all cursor-pointer ${borderStyle}`}
                        >
                          <div className="flex items-center justify-between gap-2.5">
                            <span className="text-[8.5px] font-mono font-black text-slate-450 uppercase block bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                              {action.source}
                            </span>
                            
                            <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-full ${
                              isComplete ? "bg-emerald-100 text-emerald-800" :
                              isInProgress ? "bg-amber-100 text-amber-800" :
                              "bg-slate-100 text-slate-600"
                            }`}>
                              {badgeLabel}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h5 className="text-xs font-bold text-slate-900 line-clamp-2 leading-relaxed">{action.what}</h5>
                            <p className="text-[10.5px] text-slate-500 line-clamp-2 font-medium">Porquê: {action.why}</p>
                          </div>

                          {/* Minimal 5W2H details footer inside card */}
                          <div className="pt-2.5 border-t border-slate-100 grid grid-cols-2 gap-2 text-[10px] text-slate-600 font-medium">
                            <div className="flex items-center gap-1.5 truncate">
                              <User className="w-3 h-3 text-slate-400 shrink-0" />
                              <span className="truncate">{action.who}</span>
                            </div>
                            <div className="flex items-center gap-1.5 truncate justify-end text-right">
                              <Clock className="w-3 h-3 text-[#C49746] shrink-0" />
                              <span className="truncate">{action.when}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
      </div>

    </div>
  );
}
