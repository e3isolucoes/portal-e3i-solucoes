import React from "react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";
import { ShieldCheck, HelpCircle, AlertCircle, ArrowUpRight, Award, Zap, Flame, Sparkles } from "lucide-react";
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Label, ReferenceLine } from "recharts";

export interface ReorgAction {
  id: string;
  what: string;
  why: string;
  who: string;
  when: string;
  where: string;
  how: string;
  howMuch: string;
  evidence: string;
  status: "planejado" | "em_andamento" | "concluido" | "cancelado";
  impact: number; // 1-10
  effort: number; // 1-10
  source: "diagnostico" | "estrategia" | "processos" | "raci" | "mudanca";
}

interface PriorityMatrixProps {
  actions: ReorgAction[];
  mode: UsabilityMode;
  onSelectAction?: (action: ReorgAction) => void;
}

export default function PriorityMatrix({
  actions,
  mode,
  onSelectAction
}: PriorityMatrixProps) {
  const isExpert = isExpertMode(mode);

  // Divide actions into quadrants based on impact vs effort (Threshold: 5)
  const quadrants = {
    quickWins: actions.filter(a => a.impact >= 5 && a.effort < 5), // High Impact, Low Effort
    strategic: actions.filter(a => a.impact >= 5 && a.effort >= 5), // High Impact, High Effort
    fillIns: actions.filter(a => a.impact < 5 && a.effort < 5), // Low Impact, Low Effort
    descartar: actions.filter(a => a.impact < 5 && a.effort >= 5) // Low Impact, High Effort
  };

  // Format data for ScatterChart
  const scatterData = actions.map(a => ({
    id: a.id,
    name: a.what,
    x: a.effort, // Effort on X axis
    y: a.impact, // Impact on Y axis
    sourceName: a.source.toUpperCase(),
    status: a.status
  }));

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div id={`tooltip-${data.id}`} className="bg-slate-900 text-white p-3 rounded-lg shadow-xl border border-slate-700 text-xs text-left max-w-xs space-y-1">
          <span className="text-[9px] font-mono bg-amber-500 text-slate-950 px-2.5 py-0.5 rounded font-black uppercase inline-block">
            {data.sourceName}
          </span>
          <p className="font-extrabold leading-snug">{data.name}</p>
          <div className="flex gap-4 pt-1 font-mono text-[10px] text-slate-300 border-t border-slate-700">
            <span>Esforço (X): <strong>{data.x}/10</strong></span>
            <span>Impacto (Y): <strong>{data.y}/10</strong></span>
          </div>
          <p className="text-[10px] text-slate-400 font-sans italic">Status: {data.status}</p>
        </div>
      );
    };
    return null;
  };

  return (
    <div id="reorg-priority-matrix" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* Title block */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h4 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#C49746]" /> 
            {isExpert ? "Matriz de Priorização Executiva (Impacto × Esforço)" : "Onde Começar? Matriz de Esforço e Impacto"}
          </h4>
          <p className="text-xs text-slate-550">
            {isExpert 
              ? "Posicione e selecione as iniciativas baseando-se no trade-off de eficiência de implantação. Priorize 'Quick Wins' para garantir tração ágil de caixa." 
              : "Veja as tarefas separadas por dificuldade. Comece pelas fáceis que dão muito resultado!"}
          </p>
        </div>

        <span className="text-[10px] font-mono bg-[#C49746]/10 border border-[#C49746]/30 text-[#C49746] px-2.5 py-1 rounded font-black uppercase">
          PRIORITIZATION ENGINE
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* CHART PORTION */}
        <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block text-center mb-2">
            Mapeamento Gráfico Bidimensional
          </span>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 30, bottom: 20, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  type="number" 
                  dataKey="x" 
                  name="Esforço" 
                  domain={[0, 10]} 
                  tickCount={11}
                  tick={{ fontSize: 10, fontWeight: "bold" }}
                >
                  <Label value="Dificuldade / Esforço →" offset={-10} position="insideBottom" style={{ fontSize: 10, fontWeight: "bold", fill: "#64748b" }} />
                </XAxis>
                <YAxis 
                  type="number" 
                  dataKey="y" 
                  name="Impacto" 
                  domain={[0, 10]} 
                  tickCount={11}
                  tick={{ fontSize: 10, fontWeight: "bold" }}
                >
                  <Label value="Impacto Operacional / Retorno ↑" angle={-90} position="insideLeft" style={{ fontSize: 10, fontWeight: "bold", fill: "#64748b" }} />
                </YAxis>
                <ReferenceLine x={5} stroke="#cbd5e1" strokeDasharray="4 4" />
                <ReferenceLine y={5} stroke="#cbd5e1" strokeDasharray="4 4" />
                <Tooltip content={<CustomTooltip />} />
                <Scatter name="Atividades 5W2H" data={scatterData} fill="#C49746" shape="circle" size={120} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          <div className="flex justify-between text-[10px] text-slate-450 font-mono pt-2 border-t border-slate-200">
            <span>Eixo X: 1 (Fácil) a 10 (Complexo)</span>
            <span>Eixo Y: 1 (Incremental) a 10 (Transformador)</span>
          </div>
        </div>

        {/* QUADRANTS PORTION */}
        <div className="lg:col-span-5 grid grid-cols-1 gap-3.5">
          
          {/* Quadrante 1 - Ganhos Rápidos */}
          <div className="border border-emerald-200 bg-emerald-50/10 p-3.5 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-black text-emerald-800 uppercase tracking-widest flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-emerald-600" />
                1. Ganhos Rápidos (Quick Wins)
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {quadrants.quickWins.length}
              </span>
            </div>
            
            <p className="text-[11px] text-slate-500">Alto impacto operacional com investimento brando. Implante imediato!</p>
            
            <div className="max-h-24 overflow-y-auto space-y-1">
              {quadrants.quickWins.length === 0 ? (
                <p className="text-[10.5px] italic text-slate-450 font-medium">Nenhuma ação neste quadrante.</p>
              ) : (
                quadrants.quickWins.map(a => (
                  <div 
                    key={a.id} 
                    onClick={() => onSelectAction?.(a)}
                    className="text-[11px] font-bold bg-white border border-emerald-150 p-2 rounded hover:border-emerald-400 cursor-pointer text-slate-900 truncate"
                  >
                    🚀 {a.what}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quadrante 2 - Projetos Estratégicos */}
          <div className="border border-indigo-200 bg-indigo-50/10 p-3.5 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-black text-indigo-800 uppercase tracking-widest flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-indigo-600" />
                2. Projetos Estratégicos
              </span>
              <span className="bg-indigo-100 text-indigo-800 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {quadrants.strategic.length}
              </span>
            </div>
            
            <p className="text-[11px] text-slate-500">Alto impacto, porém exige muito esforço e investimentos expressivos de equipe.</p>
            
            <div className="max-h-24 overflow-y-auto space-y-1">
              {quadrants.strategic.length === 0 ? (
                <p className="text-[10.5px] italic text-slate-450 font-medium">Nenhuma ação neste quadrante.</p>
              ) : (
                quadrants.strategic.map(a => (
                  <div 
                    key={a.id} 
                    onClick={() => onSelectAction?.(a)}
                    className="text-[11px] font-bold bg-white border border-indigo-150 p-2 rounded hover:border-indigo-400 cursor-pointer text-slate-900 truncate"
                  >
                    👑 {a.what}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quadrante 3 - Tarefas Menores */}
          <div className="border border-slate-200 bg-slate-50 p-3.5 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-black text-slate-650 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-slate-500" />
                3. Tarefas Menores (Fill-ins)
              </span>
              <span className="bg-slate-200 text-slate-700 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {quadrants.fillIns.length}
              </span>
            </div>
            
            <p className="text-[11px] text-slate-500">Baixo impacto de faturamento e baixo esforço. Resolva em momentos ociosos.</p>
            
            <div className="max-h-24 overflow-y-auto space-y-1">
              {quadrants.fillIns.length === 0 ? (
                <p className="text-[10.5px] italic text-slate-450 font-medium">Nenhuma ação neste quadrante.</p>
              ) : (
                quadrants.fillIns.map(a => (
                  <div 
                    key={a.id} 
                    onClick={() => onSelectAction?.(a)}
                    className="text-[11px] font-bold bg-white border border-slate-200 p-2 rounded hover:border-[#C49746] cursor-pointer text-slate-900 truncate"
                  >
                    📎 {a.what}
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}

// Sliders stub to avoid typescript compilation errors
import { Sliders } from "lucide-react";
