import React, { useState } from "react";
import { ReorgAction } from "./PriorityMatrix";
import { Plus, Trash2, Edit3, ClipboardList, AlertTriangle, CheckSquare, Sparkles, Sliders, DollarSign, Briefcase, RefreshCw, Layers } from "lucide-react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";

interface ActionPlan5W2HProps {
  actions: ReorgAction[];
  setActions: React.Dispatch<React.SetStateAction<ReorgAction[]>>;
  mode: UsabilityMode;
  selectedAction: ReorgAction | null;
  setSelectedAction: (action: ReorgAction | null) => void;
}

export default function ActionPlan5W2H({
  actions,
  setActions,
  mode,
  selectedAction,
  setSelectedAction
}: ActionPlan5W2HProps) {
  const isExpert = isExpertMode(mode);
  const [activeSubTab, setActiveSubTab] = useState<"table" | "kanban" | "create">("table");

  // Form State
  const [formData, setFormData] = useState({
    what: "",
    why: "",
    who: "",
    when: "",
    where: "",
    how: "",
    howMuch: "",
    evidence: "",
    status: "planejado" as const,
    impact: 5,
    effort: 5,
    source: "diagnostico" as const
  });

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: (name === "impact" || name === "effort") ? parseInt(value, 10) : value
    }));
  };

  const handleAddAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.what || !formData.why || !formData.who || !formData.when) return;

    const newAction: ReorgAction = {
      id: `act_${Date.now()}`,
      what: formData.what,
      why: formData.why,
      who: formData.who,
      when: formData.when,
      where: formData.where || "Setor Operativo Central",
      how: formData.how || "Implantação via times integrados e sprints ágeis.",
      howMuch: formData.howMuch || "Baixo impacto financeiro imediato",
      evidence: formData.evidence || "Certificação documental com check ins.",
      status: formData.status,
      impact: formData.impact,
      effort: formData.effort,
      source: formData.source
    };

    setActions(prev => [...prev, newAction]);
    
    // Reset Form
    setFormData({
      what: "",
      why: "",
      who: "",
      when: "",
      where: "",
      how: "",
      howMuch: "",
      evidence: "",
      status: "planejado",
      impact: 5,
      effort: 5,
      source: "diagnostico"
    });

    setActiveSubTab("table");
  };

  const handleDeleteAction = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setActions(prev => prev.filter(x => x.id !== id));
    if (selectedAction?.id === id) {
      setSelectedAction(null);
    }
  };

  const handleStatusChange = (id: string, newStatus: ReorgAction["status"]) => {
    setActions(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a));
    if (selectedAction?.id === id) {
      setSelectedAction(selectedAction ? { ...selectedAction, status: newStatus } : null);
    }
  };

  return (
    <div id="reorg-action-plan-5w2h" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-6 text-left">
      
      {/* HEADER SECTION WITH VIEWS INTEGRATIONS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h4 className="text-base font-bold text-slate-950 flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-[#C49746]" /> 
            Ferramenta Tática 5W2H Integrada
          </h4>
          <p className="text-xs text-slate-550">
            Mapeie e gerencie ações táticas com rigo executivo. Cada linha abrange o plano operacional completo: 5 perguntas básicas e 2 de estimativas financeiras.
          </p>
        </div>

        {/* View togglers */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-205">
          <button
            onClick={() => setActiveSubTab("table")}
            className={`px-4.5 py-1.5 rounded-md text-[10.5px] font-bold uppercase transition-all cursor-pointer ${
              activeSubTab === "table" ? "bg-slate-900 text-white shadow-3xs" : "text-slate-650 hover:text-slate-900"
            }`}
          >
            Grade 5W2H
          </button>
          <button
            onClick={() => setActiveSubTab("kanban")}
            className={`px-4.5 py-1.5 rounded-md text-[10.5px] font-bold uppercase transition-all cursor-pointer ${
              activeSubTab === "kanban" ? "bg-slate-900 text-white shadow-3xs" : "text-slate-650 hover:text-slate-900"
            }`}
          >
            Kanban da Reorg
          </button>
          <button
            onClick={() => setActiveSubTab("create")}
            className={`px-4.5 py-1.5 rounded-md text-[10.5px] font-bold uppercase transition-all cursor-pointer flex items-center gap-1 cursor-pointer ${
              activeSubTab === "create" ? "bg-slate-900 text-white shadow-3xs" : "text-slate-650 hover:text-slate-900"
            }`}
          >
            <Plus className="w-3.5 h-3.5" /> Criar Ação
          </button>
        </div>
      </div>

      {/* SUBTABS CONTENT */}
      
      {/* 1. TABLE VIEW */}
      {activeSubTab === "table" && (
        <div className="space-y-4">
          <div className="overflow-x-auto border border-slate-150 rounded-xl">
            <table className="w-full text-xs text-left border-collapse bg-white">
              <thead>
                <tr className="bg-slate-100 border-b text-slate-705 font-mono text-[9px] uppercase font-bold">
                  <th className="p-3 pl-4">Ação / O que (What)</th>
                  <th className="p-3">Por quê (Why)</th>
                  <th className="p-3">Quem / Onde</th>
                  <th className="p-3">Quando / Como</th>
                  <th className="p-3">Esforço / Quanto</th>
                  <th className="p-3">Origem</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right pr-4">Excluir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                {actions.map(action => {
                  const isSelected = selectedAction?.id === action.id;
                  return (
                    <tr 
                      key={action.id}
                      onClick={() => setSelectedAction(action)}
                      className={`hover:bg-slate-50/50 cursor-pointer transition-colors ${
                        isSelected ? "bg-amber-50/20 text-[#A17528]" : ""
                      }`}
                    >
                      <td className="p-3 pl-4 max-w-xs">
                        <span className="font-extrabold text-slate-955 block">{action.what}</span>
                        <span className="text-[10px] text-slate-450 mt-0.5 block italic truncate">Evidência: {action.evidence}</span>
                      </td>
                      <td className="p-3 max-w-xs truncate text-[11px] text-slate-650 font-medium">
                        {action.why}
                      </td>
                      <td className="p-3 text-[11px]">
                        <span className="font-bold text-slate-900 block">{action.who}</span>
                        <span className="text-[10px] text-slate-500 block truncate font-normal">{action.where}</span>
                      </td>
                      <td className="p-3 text-[11px]">
                        <span className="font-mono text-slate-800 font-bold block">{action.when}</span>
                        <span className="text-[10px] text-slate-500 block truncate font-normal">{action.how}</span>
                      </td>
                      <td className="p-3 font-mono text-[11px] font-bold text-slate-850">
                        <span>{action.howMuch}</span>
                        <span className="text-[10px] text-slate-450 block font-normal">Impacto: {action.impact}/10 | Esforço: {action.effort}/10</span>
                      </td>
                      <td className="p-3 font-mono text-[9.5px] font-black uppercase text-amber-700">
                        {action.source}
                      </td>
                      <td className="p-3">
                        <select
                          aria-label={`Mudar status da ação ${action.what}`}
                          value={action.status}
                          onClick={e => e.stopPropagation()}
                          onChange={e => handleStatusChange(action.id, e.target.value as ReorgAction["status"])}
                          className="bg-slate-50 border border-slate-200 rounded font-bold py-1 px-2 cursor-pointer text-[10px]"
                        >
                          <option value="planejado">Planejado</option>
                          <option value="em_andamento">Em Andamento</option>
                          <option value="concluido">Concluído</option>
                          <option value="cancelado">Cancelado</option>
                        </select>
                      </td>
                      <td className="p-3 text-right pr-4">
                        <button
                          onClick={e => handleDeleteAction(action.id, e)}
                          className="text-slate-400 hover:text-red-600 transition-colors p-1 rounded hover:bg-slate-100 cursor-pointer"
                          aria-label={`Excluir ação ${action.what}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* DETAIL DRAWER FOR SELECTED ACTION */}
          {selectedAction && (
            <div className="bg-[#C49746]/5 border border-[#C49746]/20 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-[#C49746]/10 pb-2">
                <span className="text-[10px] font-mono font-black text-[#A17528] uppercase tracking-wider">
                  Dossiê Completo 5W2H: {selectedAction.id}
                </span>
                <button 
                  onClick={() => setSelectedAction(null)}
                  className="text-slate-400 hover:text-slate-900 text-xs font-bold font-mono"
                >
                  X FECHAR
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs font-sans">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">1. O que (What)</span>
                  <p className="font-extrabold text-slate-950">{selectedAction.what}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">2. Por que (Why)</span>
                  <p className="text-slate-700 font-medium">{selectedAction.why}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">3. Quem (Who)</span>
                  <p className="font-extrabold text-[#A17528]">{selectedAction.who}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">4. Quando (When)</span>
                  <p className="font-mono text-slate-800 font-black">{selectedAction.when}</p>
                </div>

                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">5. Onde (Where)</span>
                  <p className="text-slate-650 font-medium">{selectedAction.where}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">6. Como (How)</span>
                  <p className="text-slate-650 font-medium">{selectedAction.how}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">7. Quanto (How Much)</span>
                  <p className="font-extrabold text-slate-900">{selectedAction.howMuch}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">8. Evidência (Evidence)</span>
                  <p className="text-slate-750 font-bold">{selectedAction.evidence}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. KANBAN VIEW */}
      {activeSubTab === "kanban" && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Column: Planned */}
          <div className="bg-slate-50 border border-slate-200.5 rounded-xl p-3.5 space-y-3.5">
            <div className="flex items-center justify-between border-b pb-1">
              <span className="text-[10px] font-mono font-black text-slate-650 uppercase">PLANEJADO</span>
              <span className="bg-slate-200 text-slate-700 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {actions.filter(a => a.status === "planejado").length}
              </span>
            </div>

            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {actions.filter(a => a.status === "planejado").length === 0 ? (
                <p className="text-[10.5px] text-slate-400 italic text-center py-2">Sem tarefas pendentes.</p>
              ) : (
                actions.filter(a => a.status === "planejado").map(action => (
                  <div 
                    key={action.id}
                    onClick={() => setSelectedAction(action)}
                    className="bg-white border border-slate-200 p-3 rounded-lg shadow-3xs space-y-2 text-left cursor-pointer hover:border-amber-400"
                  >
                    <span className="text-[8px] font-mono font-black uppercase text-amber-700 bg-amber-50 px-1 py-0.2 border border-amber-100 rounded">
                      {action.source}
                    </span>
                    <h5 className="text-[11.5px] font-bold text-slate-900 leading-snug">{action.what}</h5>
                    <p className="text-[10px] text-slate-500 font-serif font-semibold">{action.who} | {action.when}</p>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleStatusChange(action.id, "em_andamento"); }}
                      className="w-full text-center py-1 bg-slate-900 text-white font-bold text-[9px] uppercase rounded cursor-pointer"
                    >
                      Iniciar Trabalho
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Column: In Progress */}
          <div className="bg-amber-50/15 border border-amber-205 rounded-xl p-3.5 space-y-3.5">
            <div className="flex items-center justify-between border-b pb-1">
              <span className="text-[10px] font-mono font-black text-amber-700 uppercase">EM ANDAMENTO</span>
              <span className="bg-amber-100 text-amber-800 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {actions.filter(a => a.status === "em_andamento").length}
              </span>
            </div>

            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {actions.filter(a => a.status === "em_andamento").length === 0 ? (
                <p className="text-[10.5px] text-slate-400 italic text-center py-2">Sem tarefas em progresso.</p>
              ) : (
                actions.filter(a => a.status === "em_andamento").map(action => (
                  <div 
                    key={action.id}
                    onClick={() => setSelectedAction(action)}
                    className="bg-white border border-amber-200 p-3 rounded-lg shadow-3xs space-y-2 text-left cursor-pointer hover:border-emerald-400"
                  >
                    <span className="text-[8px] font-mono font-black uppercase text-amber-700 bg-amber-50 px-1 py-0.2 border border-amber-100 rounded">
                      {action.source}
                    </span>
                    <h5 className="text-[11.5px] font-bold text-slate-900 leading-snug">{action.what}</h5>
                    <p className="text-[10px] text-slate-500 font-serif font-semibold">{action.who} | {action.when}</p>
                    <div className="flex gap-1.5">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleStatusChange(action.id, "planejado"); }}
                        className="flex-1 text-center py-1 bg-slate-100 text-slate-700 font-bold text-[9px] uppercase rounded cursor-pointer"
                      >
                        Pausar
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleStatusChange(action.id, "concluido"); }}
                        className="flex-1 text-center py-1 bg-emerald-600 text-white font-bold text-[9px] uppercase rounded cursor-pointer"
                      >
                        Concluir
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Column: Done */}
          <div className="bg-emerald-50/10 border border-emerald-205 rounded-xl p-3.5 space-y-3.5">
            <div className="flex items-center justify-between border-b pb-1">
              <span className="text-[10px] font-mono font-black text-emerald-700 uppercase">CONCLUÍDO</span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {actions.filter(a => a.status === "concluido").length}
              </span>
            </div>

            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {actions.filter(a => a.status === "concluido").length === 0 ? (
                <p className="text-[10.5px] text-slate-400 italic text-center py-2">Sem tarefas concluídas ainda.</p>
              ) : (
                actions.filter(a => a.status === "concluido").map(action => (
                  <div 
                    key={action.id}
                    onClick={() => setSelectedAction(action)}
                    className="bg-white border border-emerald-200 p-3 rounded-lg shadow-3xs space-y-2 text-left cursor-pointer"
                  >
                    <span className="text-[8px] font-mono font-black uppercase text-[#067647] bg-emerald-50 px-1 py-0.2 border border-emerald-100 rounded">
                      {action.source}
                    </span>
                    <h5 className="text-[11.5px] font-bold text-slate-650 leading-snug line-through">{action.what}</h5>
                    <p className="text-[10px] text-slate-450 font-serif font-medium flex items-center gap-1">
                      ✅ {action.who}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Column: Cancelled */}
          <div className="bg-rose-50/10 border border-rose-205 rounded-xl p-3.5 space-y-3.5">
            <div className="flex items-center justify-between border-b pb-1">
              <span className="text-[10px] font-mono font-black text-red-700 uppercase">CANCELADO</span>
              <span className="bg-red-100 text-red-800 text-[10px] font-mono font-black px-1.5 py-0.2 rounded">
                {actions.filter(a => a.status === "cancelado").length}
              </span>
            </div>

            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {actions.filter(a => a.status === "cancelado").length === 0 ? (
                <p className="text-[10.5px] text-slate-400 italic text-center py-2"></p>
              ) : (
                actions.filter(a => a.status === "cancelado").map(action => (
                  <div 
                    key={action.id}
                    className="bg-white border border-rose-100 p-3 rounded-lg shadow-3xs space-y-1.5 text-left opacity-60"
                  >
                    <h5 className="text-[11px] font-bold text-slate-500 line-through">{action.what}</h5>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      )}

      {/* 3. CREATE OPERATION FORM */}
      {activeSubTab === "create" && (
        <form onSubmit={handleAddAction} className="bg-slate-50 border border-slate-200.5 p-5 rounded-xl space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <h5 className="text-xs font-bold text-slate-900 uppercase">Adicionar Iniciativa sob o Padrão 5W2H</h5>
            <span className="text-[10px] text-slate-400 italic">Preencha os campos obrigatórios</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
            
            {/* 1. What */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-what">O que será feito (What) *</label>
              <input 
                id="reorg-input-what"
                type="text" 
                name="what"
                value={formData.what}
                onChange={handleFormChange}
                required
                placeholder="Exemplo: Automatizar disparo de solicitações de faturamento..."
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 2. Why */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-why">Por que será feito (Why) *</label>
              <textarea 
                id="reorg-input-why"
                name="why"
                value={formData.why}
                onChange={handleFormChange}
                required
                placeholder="Exemplo: Para anular digitações duplicadas e diminuir a latência do faturamento..."
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500 h-16 resize-none"
              />
            </div>

            {/* 3. Who */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-who">Quem executará (Who) *</label>
              <input 
                id="reorg-input-who"
                type="text" 
                name="who"
                value={formData.who}
                onChange={handleFormChange}
                required
                placeholder="Exemplo: Tech Lead de Logística"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 4. When */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-when">Quando entregar (When) *</label>
              <input 
                id="reorg-input-when"
                type="text" 
                name="when"
                value={formData.when}
                onChange={handleFormChange}
                required
                placeholder="Exemplo: 30 dias após kick off"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 5. Where */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-where">Onde impacta (Where)</label>
              <input 
                id="reorg-input-where"
                type="text" 
                name="where"
                value={formData.where}
                onChange={handleFormChange}
                placeholder="Exemplo: Posto de Faturamento e TI"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 6. How */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-how">Como executar (How)</label>
              <input 
                id="reorg-input-how"
                type="text" 
                name="how"
                value={formData.how}
                onChange={handleFormChange}
                placeholder="Exemplo: Via canais de integração de API e testes automatizados"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 7. How Much */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-howMuch">Qual o Custo/Orçamento (How Much)</label>
              <input 
                id="reorg-input-howMuch"
                type="text" 
                name="howMuch"
                value={formData.howMuch}
                onChange={handleFormChange}
                placeholder="Exemplo: Sob consulta com equipe de TI interna ou R$ 5.000,00"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* 8. Evidence */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-700" htmlFor="reorg-input-evidence">Evidência Esperada de Conclusão</label>
              <input 
                id="reorg-input-evidence"
                type="text" 
                name="evidence"
                value={formData.evidence}
                onChange={handleFormChange}
                placeholder="Exemplo: Relatório de integrações bem-sucedidas no ERP"
                className="w-full bg-white border border-slate-201 p-2.5 rounded-lg outline-none focus:border-amber-500"
              />
            </div>

            {/* Matrix positioning */}
            <div className="grid grid-cols-3 gap-2.5 sm:col-span-2 bg-white border border-slate-200.5 p-3.5 rounded-xl">
              <div>
                <label className="block font-bold text-slate-700 mb-1" htmlFor="reorg-select-source">Origem Recomendada</label>
                <select
                  id="reorg-select-source"
                  name="source"
                  value={formData.source}
                  onChange={handleFormChange}
                  className="w-full bg-slate-50 border border-slate-200 py-1.5 px-2.5 rounded outline-none text-[11px]"
                >
                  <option value="diagnostico">Do Diagnóstico Corporativo</option>
                  <option value="estrategia">Da Estratégia de Negócios</option>
                  <option value="processos">Da Modelagem de Processos</option>
                  <option value="raci">Da Matriz de Governança (RACI)</option>
                  <option value="mudanca">Da Mudança de Equipe</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1" htmlFor="reorg-range-impact">Impacto Estimado (1-10)</label>
                <div className="flex items-center gap-2">
                  <input 
                    id="reorg-range-impact"
                    type="range" min="1" max="10" name="impact"
                    value={formData.impact}
                    onChange={handleFormChange}
                    className="w-full h-1 accent-amber-500 cursor-pointer"
                  />
                  <span className="font-mono font-bold text-[11px] min-w-[20px]">{formData.impact}</span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1" htmlFor="reorg-range-effort">Dificuldade/Esforço (1-10)</label>
                <div className="flex items-center gap-2">
                  <input 
                    id="reorg-range-effort"
                    type="range" min="1" max="10" name="effort"
                    value={formData.effort}
                    onChange={handleFormChange}
                    className="w-full h-1 accent-red-550 cursor-pointer"
                  />
                  <span className="font-mono font-bold text-[11px] min-w-[20px]">{formData.effort}</span>
                </div>
              </div>
            </div>

          </div>

          <div className="flex justify-end gap-2 pt-2 border-t text-xs">
            <button
              type="button"
              onClick={() => setActiveSubTab("table")}
              className="bg-slate-200 hover:bg-slate-250 text-slate-800 font-bold py-2 px-4.5 rounded-lg cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="bg-slate-900 hover:bg-slate-950 text-white font-bold py-2 px-4.5 rounded-lg cursor-pointer"
            >
              Confirmar &amp; Salvar Ação
            </button>
          </div>
        </form>
      )}

    </div>
  );
}
