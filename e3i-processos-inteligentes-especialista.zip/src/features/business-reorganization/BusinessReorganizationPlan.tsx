import React, { useState, useEffect } from "react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";
import PriorityMatrix, { ReorgAction } from "./PriorityMatrix";
import ReorganizationRoadmap from "./ReorganizationRoadmap";
import ActionPlan5W2H from "./ActionPlan5W2H";
import { 
  Award, 
  HelpCircle, 
  Sliders, 
  ClipboardCheck, 
  ChevronRight, 
  FileCheck, 
  Settings, 
  Building2, 
  Download, 
  CheckSquare, 
  ListTodo, 
  AlertCircle, 
  Activity, 
  Plus, 
  Info, 
  Target, 
  Sparkles,
  RefreshCw,
  Trophy,
  Users
} from "lucide-react";

interface BusinessReorganizationPlanProps {
  mode: UsabilityMode;
}

const DEFAULT_ACTIONS: ReorgAction[] = [
  {
    id: "act_1",
    what: "Digitalização das Notas de Carga e Remessa",
    why: "Eliminar a conferência manual estressante na expedição que induz a erros.",
    who: "Supervisor de Faturamento & TI",
    when: "Até Dia 15",
    where: "Expedição Logística e Postos N8",
    how: "Aquisição de coletores de dados e integração de XML via validador homologado.",
    howMuch: "R$ 3.500,00 (Coletores)",
    evidence: "Faturamento 100% digitalizado e ausência de notas de papel pendentes.",
    status: "concluido",
    impact: 8,
    effort: 3,
    source: "diagnostico"
  },
  {
    id: "act_2",
    what: "Desdobramento do BSC (Balanced Scorecard) Operacional",
    why: "Garantir que as metas de liderança (Nível 2) convirjam para o faturamento (Nível 3).",
    who: "Diretor Comercial & PMO",
    when: "Até Dia 30",
    where: "Diretoria e Controladoria Corporativa",
    how: "Reuniões integradas e fixação de painéis visuais no setor operacional.",
    howMuch: "Uso de recursos internos de consultoria / Horas de PMO",
    evidence: "Telas de acompanhamento de KPIs ativas em tempo real na fábrica.",
    status: "em_andamento",
    impact: 9,
    effort: 6,
    source: "estrategia"
  },
  {
    id: "act_3",
    what: "Substituição do Repositório de Planilhas Locais por Banco de Dados",
    why: "Eliminar o perigoso 'Superprocessamento' e a digitação cruzada de planilhas locais.",
    who: "Database Administrator & Analista de Negócios",
    when: "Até Dia 45",
    where: "Sistemas Corporativos / Integrares de Nuvem",
    how: "Migração das planilhas para estrutura unificada e desenvolvimento de painel de visualização.",
    howMuch: "Licenciamento Cloud SaaS complementar (R$ 800/mês)",
    evidence: "Tabelas gerenciais consolidadas sem intervenção humana manual.",
    status: "em_andamento",
    impact: 7,
    effort: 4,
    source: "processos"
  },
  {
    id: "act_4",
    what: "Assinatura Formal de SLAs de Posto entre Logística e Comercial",
    why: "Cessar sobreposições de autoridade (RACI) e delimitar tempos máximos de ciclo.",
    who: "Comitê de Governança & Gerente Jurídico",
    when: "Até Dia 60",
    where: "Setor Regulatório e Administrativo",
    how: "Elaboração de termo de compromisso interno e rotina rígida de conciliação aos sábados.",
    howMuch: "Incremental zero - Alinhamento executivo interno",
    evidence: "Cláusulas documentadas e aprovadas por ambos os gestores no ERP.",
    status: "planejado",
    impact: 8,
    effort: 5,
    source: "raci"
  },
  {
    id: "act_5",
    what: "Inauguração do Fórum Quinzenal de Premiação Meritocrática",
    why: "Treinar, sanar focos de resistência e engajar líderes de postos nas mudanças.",
    who: "Gerente de RH & Agente de Mudança",
    when: "Até Dia 75",
    where: "Sala de Reuniões Multiuso",
    how: "Dinâmicas de gamificação e acompanhamento de bônus por produtividade.",
    howMuch: "Bônus variável de eficiência (conforme metas atingidas)",
    evidence: "Aumento palpável na pontuação de prontidão cultural para mudança.",
    status: "planejado",
    impact: 9,
    effort: 7,
    source: "mudanca"
  }
];

export default function BusinessReorganizationPlan({ mode }: BusinessReorganizationPlanProps) {
  const isExpert = isExpertMode(mode);

  // Load from LocalStorage or Fallback to DEFAULT_ACTIONS
  const [actions, setActions] = useState<ReorgAction[]>(() => {
    const saved = localStorage.getItem("reorg_action_plan_actions");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Falha ao ler dados de reorganização:", e);
      }
    }
    return DEFAULT_ACTIONS;
  });

  // Save to LocalStorage whenever actions change
  useEffect(() => {
    localStorage.setItem("reorg_action_plan_actions", JSON.stringify(actions));
  }, [actions]);

  // Selected Action for details block
  const [selectedAction, setSelectedAction] = useState<ReorgAction | null>(null);

  // Restore defaults function
  const handleResetDefaults = () => {
    if (window.confirm("Deseja realmente restaurar as ações padrão consolidadas do plano executivo?")) {
      setActions(DEFAULT_ACTIONS);
      setSelectedAction(null);
    }
  };

  // Calculate high level KPIs
  const totalActions = actions.length;
  const completedActions = actions.filter(a => a.status === "concluido").length;
  const inProgressActions = actions.filter(a => a.status === "em_andamento").length;
  const pendingActions = actions.filter(a => a.status === "planejado").length;
  
  const completionPercentage = totalActions > 0 ? Math.round((completedActions / totalActions) * 100) : 0;
  
  const quickWinsCount = actions.filter(a => a.impact >= 5 && a.effort < 5).length;
  
  return (
    <div className="space-y-6 text-left">
      
      {/* EXECUTIVE SUMMARY BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-705 p-6 rounded-2xl text-white shadow-md space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">
              DIRETRIZ DE INTEGRABILIDADE — AÇÃO 13
            </span>
            <h2 className="text-xl sm:text-2xl font-serif font-black text-white flex items-center gap-2">
              <Building2 className="w-6 h-6 text-[#C49746]" />
              Painel de Reorganização Empresarial
            </h2>
            <p className="text-xs text-slate-350 max-w-3xl leading-relaxed">
              Consolide ações integradas de todas as etapas analisadas — Diagnóstico, Estratégia, Processos, RACI e Gestão de Mudança. Monitore a priorização bidimensional de esforço versus impacto com rigor executivo.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleResetDefaults}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold py-1.5 px-3 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Restaurar Padrões
            </button>
            <span className="text-[10px] bg-[#C49746]/10 text-[#C49746] border border-[#C49746]/30 px-3 py-1.5 rounded-lg font-black uppercase">
              Consolidated Executive Plan
            </span>
          </div>
        </div>

        {/* METRICS ROW */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3.5 border-t border-slate-800 text-xs">
          <div className="bg-slate-850/50 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
            <ListTodo className="w-5 h-5 text-[#C49746] shrink-0" />
            <div>
              <p className="text-[10px] font-mono text-slate-400 uppercase font-black">Plan Total Iniciativas</p>
              <p className="text-base font-black text-white">{totalActions} Ações</p>
            </div>
          </div>

          <div className="bg-slate-850/50 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
            <Activity className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="text-[10px] font-mono text-slate-400 uppercase font-black">Progresso Geral</p>
              <p className="text-base font-black text-emerald-400">{completionPercentage}% Concluído</p>
            </div>
          </div>

          <div className="bg-slate-850/50 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
            <Trophy className="w-5 h-5 text-amber-500 shrink-0" />
            <div>
              <p className="text-[10px] font-mono text-slate-400 uppercase font-black">Ganhos Rápidos</p>
              <p className="text-base font-black text-amber-500">{quickWinsCount} Quick-Wins</p>
            </div>
          </div>

          <div className="bg-slate-850/50 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
            <Users className="w-5 h-5 text-indigo-400 shrink-0" />
            <div>
              <p className="text-[10px] font-mono text-slate-400 uppercase font-black font-black">Ações em Curso</p>
              <p className="text-base font-black text-indigo-400">{inProgressActions} Ativas / {pendingActions} Planej.</p>
            </div>
          </div>
        </div>
      </div>

      {/* DETAILED DRILL DOWN & STRATEGIC RECOMMENDATIONS SUMMARY */}
      {isExpert && (
        <div className="bg-amber-50/10 border border-[#C49746]/15 rounded-xl p-4.5 text-xs text-slate-700 font-sans space-y-2.5">
          <h4 className="font-extrabold text-[#A17528] uppercase text-[10.5px] flex items-center gap-1.5">
            <Info className="w-4 h-4 text-[#C49746]" />
            Alinhamento Executivo & Desafios de Implantação
          </h4>
          <p className="leading-relaxed">
            Este plano de ação foi integrado a partir de inconsistências pontuadas em postos críticos N8 da expedição (Ação 12), falhas de prioridade de negócio no scorecard de alta gerência (Ação 10), e atritos de equipes mapeados no diagnóstico de prontidão estrutural (Ação 11). A liderança operacional deve interagir quinzenalmente sobre o andamento físico-financeiro para blindagem de resultados de caixa.
          </p>
        </div>
      )}

      {/* COMPONENT 1: MAP AND CHART OF PRIORITIES */}
      <PriorityMatrix 
        actions={actions}
        mode={mode}
        onSelectAction={(act) => setSelectedAction(act)}
      />

      {/* COMPONENT 2: ROADMAP TIMELINE (CHRONOLOGICAL SEQUENCING) */}
      <ReorganizationRoadmap 
        actions={actions}
        mode={mode}
        onSelectAction={(act) => setSelectedAction(act)}
      />

      {/* COMPONENT 3: ACTION PLAN 5W2H TOOL - WITH FORM/LIST & KANBAN VIEWS */}
      <ActionPlan5W2H 
        actions={actions}
        setActions={setActions}
        mode={mode}
        selectedAction={selectedAction}
        setSelectedAction={setSelectedAction}
      />

    </div>
  );
}
