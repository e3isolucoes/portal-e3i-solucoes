import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { Layers, ShieldAlert, Sparkles, BookOpen, Target, RefreshCw, Users, Handshake, Brain, Activity } from "lucide-react";

export interface DimensionScore {
  id: "estrategia" | "estrutura" | "sistemas" | "valores" | "lideranca" | "equipe" | "competencias";
  keyNameSimple: string;
  keyNameTechnical: string;
  category: "HARD_S" | "SOFT_S";
  score: number;
}

export interface DiagnosisHeatmapProps {
  usabilityMode: UsabilityMode;
  scores: DimensionScore[];
  selectedDimensionId: string | null;
  onSelectDimension: (dimensionId: string) => void;
}

export default function DiagnosisHeatmap({
  usabilityMode,
  scores,
  selectedDimensionId,
  onSelectDimension
}: DiagnosisHeatmapProps) {

  // Function to get color class based on score
  const getScoreColor = (score: number) => {
    if (score < 1.6) return { bg: "bg-red-50", border: "border-red-400", text: "text-red-700", fill: "#EF4444", progress: "bg-red-500" };
    if (score < 3.1) return { bg: "bg-amber-50", border: "border-amber-400", text: "text-amber-800", fill: "#F59E0B", progress: "bg-amber-500" };
    if (score < 4.5) return { bg: "bg-emerald-50", border: "border-emerald-400", text: "text-emerald-700", fill: "#10B981", progress: "bg-emerald-500" };
    return { bg: "bg-yellow-50", border: "border-yellow-500", text: "text-yellow-700", fill: "#EAB308", progress: "bg-yellow-500" };
  };

  // Define position mapping for the 7S elements in the diagram (SVG)
  // Shared Values (valores) is central.
  // strategy, structure, systems form the top triad (Hard S)
  // style, staff, skills form the bottom triad (Soft S)
  const positions = {
    estrategia: { x: 100, y: 50, label: "Estratégia", labelTech: "Strategy" },
    estrutura: { x: 300, y: 50, label: "Estrutura", labelTech: "Structure" },
    sistemas: { x: 400, y: 150, label: "Sistemas", labelTech: "Systems" },
    valores: { x: 200, y: 200, label: "Valores", labelTech: "Shared Values" },
    lideranca: { x: 100, y: 350, label: "Liderança", labelTech: "Style" },
    equipe: { x: 300, y: 350, label: "Equipe", labelTech: "Staff" },
    competencias: { x: 400, y: 270, label: "Habilidades", labelTech: "Skills" }
  };

  // Build SVG lines between all nodes to represent the fully connected McKinsey 7S mesh
  const dimensionsKeys = Object.keys(positions) as (keyof typeof positions)[];
  const links: { from: keyof typeof positions; to: keyof typeof positions }[] = [];
  
  for (let i = 0; i < dimensionsKeys.length; i++) {
    for (let j = i + 1; j < dimensionsKeys.length; j++) {
      links.push({ from: dimensionsKeys[i], to: dimensionsKeys[j] });
    }
  }

  return (
    <div id="diagnosis-heatmap-panel" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs">
      
      {/* Title block */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h3 className="text-base font-bold text-slate-950">
            📊 Mapa de Calor de Maturidade ({isSimpleMode(usabilityMode) ? "Alinhamento de Processos" : "McKinsey 7S Alignment Map"})
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Clique em qualquer dimensão abaixo ou no gráfico para analisar as forças e vulnerabilidades.
          </p>
        </div>

        {/* Legend Box */}
        <div className="flex items-center gap-3 text-[10px] font-mono font-bold">
          <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-red-500" /> &lt; 1.5 Caos</div>
          <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-amber-500" /> 1.6 - 3.0 Alerta</div>
          <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-emerald-500" /> 3.1 - 4.5 Sólido</div>
          <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-yellow-400" /> &gt; 4.5 Excelente</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* INTERACTIVE MESH CANVAS (7 COLS) */}
        <div className="lg:col-span-7 flex justify-center items-center bg-slate-50 p-4 rounded-lg border border-slate-100 relative min-h-[380px]">
          
          {/* McKinsey 7S Web SVG Diagram */}
          <svg className="w-full max-w-[450px] aspect-square" viewBox="0 0 500 400">
            {/* Draw Links/Lines (Fully grid-connected network) */}
            {links.map((link, idx) => {
              const pFrom = positions[link.from];
              const pTo = positions[link.to];
              const isSelectedFrom = selectedDimensionId === link.from;
              const isSelectedTo = selectedDimensionId === link.to;
              const isAccent = isSelectedFrom || isSelectedTo;
              
              return (
                <line
                  key={idx}
                  x1={pFrom.x}
                  y1={pFrom.y}
                  x2={pTo.x}
                  y2={pTo.y}
                  stroke={isAccent ? "#C49746" : "#E2E8F0"}
                  strokeWidth={isAccent ? 2.5 : 1.25}
                  strokeDasharray={isAccent ? "none" : link.from === "valores" || link.to === "valores" ? "none" : "2,2"}
                  className="transition-all duration-300"
                />
              );
            })}

            {/* Draw Dimension Node Circles */}
            {scores.map((scoreObj) => {
              const coords = positions[scoreObj.id];
              const isSelected = selectedDimensionId === scoreObj.id;
              const colorInfo = getScoreColor(scoreObj.score);

              return (
                <g 
                  key={scoreObj.id} 
                  className="cursor-pointer group/node"
                  onClick={() => onSelectDimension(scoreObj.id)}
                >
                  {/* Outer active shadow glow */}
                  <circle
                    cx={coords.x}
                    cy={coords.y}
                    r={isSelected ? 32 : 24}
                    fill={colorInfo.fill}
                    fillOpacity={isSelected ? 0.22 : 0.08}
                    stroke={isSelected ? "#C49746" : "transparent"}
                    strokeWidth={isSelected ? 2 : 0}
                    className="transition-all duration-300"
                  />
                  
                  {/* Inner Node Circle */}
                  <circle
                    cx={coords.x}
                    cy={coords.y}
                    r={isSelected ? 22 : 18}
                    fill={colorInfo.fill}
                    stroke={isSelected ? "#C49746" : "#FFFFFF"}
                    strokeWidth={isSelected ? 3 : 2}
                    className="transition-all duration-300 shadow-sm"
                  />

                  {/* Rating value text in circle */}
                  <text
                    x={coords.x}
                    y={coords.y + 4}
                    textAnchor="middle"
                    fill="#FFFFFF"
                    fontSize="11"
                    fontWeight="900"
                    className="font-mono tracking-tighter"
                  >
                    {scoreObj.score.toFixed(1)}
                  </text>

                  {/* Label Text above/below node */}
                  <text
                    x={coords.x}
                    y={coords.y + (coords.y > 220 ? 36 : -31)}
                    textAnchor="middle"
                    fill={isSelected ? "#000000" : "#475569"}
                    fontSize="11"
                    fontWeight={isSelected ? "900" : "700"}
                    className="transition-all duration-300 pointer-events-none select-none font-sans"
                  >
                    {isSimpleMode(usabilityMode) ? coords.label : coords.labelTech}
                  </text>
                  
                  {/* Subtle technical type tag for expert only with very small font */}
                  {isExpertMode(usabilityMode) && (
                    <text
                      x={coords.x}
                      y={coords.y + (coords.y > 220 ? 46 : -21)}
                      textAnchor="middle"
                      fill="#94A3B8"
                      fontSize="7.5"
                      fontFamily="monospace"
                      fontWeight="bold"
                      className="transition-all duration-300 pointer-events-none select-none uppercase tracking-widest"
                    >
                      {scoreObj.category === "HARD_S" ? "Hard S" : "Soft S"}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>

          {/* McKinsey 7S overlay concept hint */}
          <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-xs px-2 py-1 rounded text-[9px] font-mono text-slate-400 uppercase border border-slate-100">
            {isExpertMode(usabilityMode) ? "Estrutura Acadêmica McKinsey 7S" : "Teia Integrada de Processos"}
          </div>
        </div>

        {/* DETAILS PANEL FOR THE SELECTED NODE (5 COLS) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="border border-slate-150 rounded-lg p-4 bg-slate-50/50 space-y-4">
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">
              Análise de Elemento Selecionado
            </span>

            {(() => {
              const selectedScore = scores.find(s => s.id === selectedDimensionId) || scores[0];
              if (!selectedScore) return null;
              const colorInfo = getScoreColor(selectedScore.score);

              // Descriptions for values
              const descriptors: Record<string, { descSimple: string; descTechnical: string; titleSimple: string; titleTech: string }> = {
                estrategia: {
                  titleSimple: "Direção Geral & Rumo",
                  titleTech: "Corporate Strategy",
                  descSimple: "Mede o quanto a sua empresa sabe para onde vai e se existem rascunhos de planos operacionais compartilhados para evitar que cada funcionário puxe para um rumo diferente.",
                  descTechnical: "Auditoria de posicionamento estratégico clássico, desdobramento de metas por Balanced Scorecard ou OKRs, planejamento de market share e diferenciação estrutural."
                },
                estrutura: {
                  titleSimple: "Organização & Organograma",
                  titleTech: "Organizational Structure",
                  descSimple: "Define como os setores se comunicam e se dividem. Evita lentidões, trombadas de chefias e retrabalhos originados por falta de donos em cada departamento.",
                  descTechnical: "Avaliação do organograma formal, linhas de autoridade estáticas/dinâmicas, centralização vs. autonomia, e distribuição de autoridade funcional."
                },
                sistemas: {
                  titleSimple: "Processos & Softwares",
                  titleTech: "Operational Systems",
                  descSimple: "Mapeia as rotinas, listas de tarefas, POPs do dia a dia e os softwares e planilhas fundamentais para controlar faturamento, compras e atendimento sem perdas.",
                  descTechnical: "Análise da maturidade da engrenagem processual geral. Integração de sistemas integrados (ERP), segurança de base de dados e canais estruturados de repasse operacional."
                },
                valores: {
                  titleSimple: "Valores & Cultura Interna",
                  titleTech: "Shared Values (Superordinate Goals)",
                  descSimple: "O coração invisível da empresa. Avalia o quanto o time trabalha com ética, união e dedicação para proteger o cliente mesmo na ausência de controles físicos.",
                  descTechnical: "Análise do propósito de valor, fit cultural da marca corporativa, coesão ética e crença compartilhada nas diretrizes estratégicas centrais do negócio."
                },
                lideranca: {
                  titleSimple: "Liderança & Mentoria",
                  titleTech: "Management Style",
                  descSimple: "O estilo dos gerentes e donos. Analisa se eles atuam estimulando e cobrando os combinados de forma madura ou se usam gritos e desorganização.",
                  descTechnical: "Atuação pela liderança intelectual e comportamental. Análise do estilo de liderança consultiva, situacional e presença em rituais de governança formal."
                },
                equipe: {
                  titleSimple: "Equipe & Contratação",
                  titleTech: "Corporate Staff",
                  descSimple: "Se as mentes certas estão alocadas em cada vaga de trabalho. Mede também o fôlego humano do negócio e se as taxas de saída de pessoal estão perigosas.",
                  descTechnical: "Análise de Headcount (FTEs), balanceamento de turnos, taxas de turnover e maturidade do plano geral de captação e desenvolvimento de talentos corporativos."
                },
                competencias: {
                  titleSimple: "Habilidades Técnicas",
                  titleTech: "Installed Skills",
                  descSimple: "A capacitação prática da equipe. Avalia o nível de autonomia técnica das pessoas para as tarefas rotineiras, sem sobrecarregar a mesa do proprietário.",
                  descTechnical: "Matriz de polivalência funcional, capital intelectual estocado e eficácia de programas de upskilling/reskilling contínuo na cadeia de suprimentos interna."
                }
              };

              const elementDesc = descriptors[selectedScore.id] || { titleSimple: "", titleTech: "", descSimple: "", descTechnical: "" };

              return (
                <div key={selectedScore.id} className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-black text-slate-950 uppercase">
                        {isSimpleMode(usabilityMode) ? elementDesc.titleSimple : elementDesc.titleTech}
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${colorInfo.bg} ${colorInfo.border} ${colorInfo.text} font-black uppercase`}>
                        {selectedScore.score.toFixed(1)} / 5.0
                      </span>
                    </div>

                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-2">
                      <div 
                        className={`h-full ${colorInfo.progress} transition-all duration-500`}
                        style={{ width: `${(selectedScore.score / 5) * 100}%` }}
                      />
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed text-justify">
                    {isSimpleMode(usabilityMode) ? elementDesc.descSimple : elementDesc.descTechnical}
                  </p>

                  <div className="border-t border-slate-200 pt-3 flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                      Classificação Organizacional:
                    </span>
                    <div className="flex gap-2">
                      <span className={`text-[9px] font-mono font-bold border rounded px-1.5 py-0.5 ${
                        selectedScore.category === "HARD_S" 
                          ? "bg-slate-950 text-white border-slate-900" 
                          : "bg-amber-100 text-amber-900 border-amber-350"
                      }`}>
                        {selectedScore.category === "HARD_S" ? "HARD S (Estruturas Rígidas)" : "SOFT S (Cultura & Pessoas)"}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-xs text-amber-900 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Regra McKinsey: </span>
              Um desbalanceamento severo (ex: nota 4.5 em Estratégia, mas 1.0 em Processos) causa o desgaste da equipe e o fracasso dos planos comerciais. Forças isoladas não sustentam o crescimento.
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
