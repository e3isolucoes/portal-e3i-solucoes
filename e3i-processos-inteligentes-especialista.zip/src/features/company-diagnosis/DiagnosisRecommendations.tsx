import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { DimensionScore } from "./DiagnosisHeatmap";
import { 
  Compass, 
  ArrowRight, 
  Sparkles, 
  Zap, 
  CheckSquare, 
  Target, 
  Users, 
  Layers, 
  BarChart3, 
  Terminal, 
  BookOpen,
  Settings
} from "lucide-react";

export interface DiagnosisRecommendationsProps {
  usabilityMode: UsabilityMode;
  scores: DimensionScore[];
  onNavigateToJourney?: (stepId: string) => void;
}

export interface RecommendationAction {
  title: string;
  framework: string;
  simpleDescription: string;
  technicalDescription: string;
  priority: "IMEDIATA" | "MÉDIO_PRAZO" | "ESTRUTÚRICA";
  targetJourneyStepId: "diagnostico" | "estrategia" | "estrutura" | "processos" | "governanca" | "mudanca" | "execucao" | "resultados";
  icon: React.ReactNode;
}

export default function DiagnosisRecommendations({
  usabilityMode,
  scores,
  onNavigateToJourney
}: DiagnosisRecommendationsProps) {

  // Generate recommendations by sorting scores (lowest scores gets first priority recommendations)
  const sortedDimensions = [...scores].sort((a, b) => a.score - b.score);

  // Map of 7S pillars recommendations
  const recommendationCatalog: Record<string, RecommendationAction> = {
    estrategia: {
      title: "Definir Rumo & Missões da Liderança",
      framework: "Diretrizes Estratégicas & Plano de Negócios / Balanced Scorecard",
      simpleDescription: "Falta clareza de rumo. Agende reuniões semanais para definir as metas do trimestre e rascunhar o que cada setor precisa focar para bater os números da diretoria.",
      technicalDescription: "Formalização do planejamento estratégico tático-operacional (OKRs). Construção de mapa estratégico clássico de Porter ou Kaplan-Norton, comunicando drivers competitivos para os departamentos.",
      priority: "IMEDIATA",
      targetJourneyStepId: "estrategia",
      icon: <Target className="w-5 h-5 text-[#C49746]" />
    },
    estrutura: {
      title: "Desenhar Organograma & Mapear Responsáveis",
      framework: "Matriz RACI de Decisões & Estrutura Baseada em Processos",
      simpleDescription: "Mapeie quem manda, quem faz e quem apoia cada atividade. Crie um organograma visual simples de setores para evitar atropelos em tarefas chave do faturamento.",
      technicalDescription: "Reconfiguração da hierarquia organizacional técnica. Estabelecimento de limites funcionais rígidos através da matriz de responsabilidades RACI, dissolvendo silos de produtividade departamental.",
      priority: "MÉDIO_PRAZO",
      targetJourneyStepId: "estrutura",
      icon: <Layers className="w-5 h-5 text-[#C49746]" />
    },
    sistemas: {
      title: "Modelar Rotinas & Mapear Gargalos do Trabalho",
      framework: "Modelagem BPMN & Ferramentas Operacionais",
      simpleDescription: "Os funcionários executam procedimentos essenciais no achismo. Escreva o passo a passo dos 3 principais fluxos operacionais da sua empresa e exija o cumprimento rigoroso.",
      technicalDescription: "Modelagem e arquitetura de processos (BPMN / POPs) com auditoria em sistemas ERP integrados. Criação de planos de contingência técnica e monitoramento ativo de qualidade produtiva.",
      priority: "IMEDIATA",
      targetJourneyStepId: "processos",
      icon: <Settings className="w-5 h-5 text-[#C49746]" />
    },
    valores: {
      title: "Comunicar Valores de Atendimento & Jeito de Ser",
      framework: "Cultura Organizacional e Princípios Transcendentais",
      simpleDescription: "Realize reuniões de alinhamento com a equipe explicando por que atendemos bem e quais regras de respeito e zelo são inegociáveis no dia a dia da empresa.",
      technicalDescription: "Implementação de cultura orientada ao valor de marca (Customer Centricity) e dinâmicas de segurança psicológica grupal. Alinhamento de metas pessoais a propósitos corporativos coletivos.",
      priority: "ESTRUTÚRICA",
      targetJourneyStepId: "diagnostico",
      icon: <Sparkles className="w-5 h-5 text-[#C49746]" />
    },
    lideranca: {
      title: "Rotinas de Reunião para Lançar Desafios",
      framework: "Estilo de Liderança Situacional & Accountability Act",
      simpleDescription: "Inaugure reuniões curtas toda segunda-feira para levantar o andamento dos projetos e tire dúvidas da equipe sem julgamentos rudes.",
      technicalDescription: "Instalação de programas formais de mentoria de lideranças operacionais (Management Style). Instituição de rituais de feedback de performance individuais periódicos (One-on-Ones).",
      priority: "MÉDIO_PRAZO",
      targetJourneyStepId: "governanca",
      icon: <Users className="w-5 h-5 text-[#C49746]" />
    },
    equipe: {
      title: "Mapeamento Quantitativo de Vagas & RH Justo",
      framework: "Dimensionamento de Mão de Obra e Gestão de Headcount",
      simpleDescription: "Verifique o cansaço do time. Desenhe cargos atrativos com metas fáceis de entender e crie regras transparentes de remuneração extra por resultados reais.",
      technicalDescription: "Mapeamento de capacidade produtiva total (Full-Time Equivalent / FTE). Revisão do modelo de atração de elenco humano por fit sociocultural e criação de bônus atrelados a lucros do trimestre.",
      priority: "ESTRUTÚRICA",
      targetJourneyStepId: "mudanca",
      icon: <Users className="w-5 h-5 text-[#C49746]" />
    },
    competencias: {
      title: "Treinamento Prático dos Processos de Trabalho",
      framework: "Matriz de Polivalência L&D & Programas de Treinamento Técnico",
      simpleDescription: "Crie apostilas fáceis ou grave tutoriais em vídeo explicando o uso correto dos softwares e dos maquinários. Treine todos os novatos de forma idêntica.",
      technicalDescription: "Instalação da Matriz de Polivalência Operacional (Skill Matrix). Sistematização de planos individuais de upskilling/reskilling práticos gerando autonomia no uso de ferramentas empresariais.",
      priority: "IMEDIATA",
      targetJourneyStepId: "execucao",
      icon: <Zap className="w-5 h-5 text-[#C49746]" />
    }
  };

  // Get the 3 lowest scoring elements as recommendations
  const prioritizedRecs: RecommendationAction[] = sortedDimensions
    .slice(0, 3)
    .map(scoreObj => recommendationCatalog[scoreObj.id])
    .filter(Boolean);

  // Next Best Action (the single absolute lowest pillar)
  const nextBestAction = recommendationCatalog[sortedDimensions[0]?.id];

  return (
    <div id="diagnosis-recommendations-panel" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* GOLDEN CARD: NEXT BEST ACTION (PRÓXIMA MELHOR AÇÃO) */}
      {nextBestAction && (
        <div className="bg-gradient-to-r from-[#FAF9F5] to-[#F1EDE1] border-2 border-[#C49746]/40 rounded-lg p-5 relative overflow-hidden shadow-xs">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#C49746]/10 rounded-full blur-xl pointer-events-none"></div>
          
          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#C49746]/10 rounded-full border border-[#C49746]/30 text-[#C49746] shrink-0 mt-0.5">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            
            <div className="space-y-2 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-[#C49746] text-white px-2 py-0.5 rounded uppercase">
                  ⭐ Próxima Melhor Ação Recomendada
                </span>
                <span className="text-[10px] font-mono text-amber-800 font-bold uppercase">
                  Prioridade Máxima urgente
                </span>
              </div>

              <h4 className="text-lg font-black text-slate-900 leading-snug">
                {nextBestAction.title}
              </h4>

              <p className="text-xs text-slate-700 leading-relaxed">
                {isSimpleMode(usabilityMode) ? nextBestAction.simpleDescription : nextBestAction.technicalDescription}
              </p>

              {isExpertMode(usabilityMode) && (
                <div className="flex items-center gap-1 text-[9px] font-mono text-slate-500 bg-white/60 p-1.5 rounded border">
                  <Terminal className="w-3.5 h-3.5 text-slate-400 shrink-0" /> Framework Acadêmico: {nextBestAction.framework}
                </div>
              )}

              {onNavigateToJourney && (
                <button
                  type="button"
                  id="go-to-journey-step-btn"
                  onClick={() => onNavigateToJourney(nextBestAction.targetJourneyStepId)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#C49746] hover:text-[#B38339] pt-1 transition-all cursor-pointer group"
                >
                  Abrir Roteiro Prático de Implementação <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TOP 3 STRATEGIC PRIORITY WORKLIST */}
      <div className="space-y-4">
        <h4 className="text-xs uppercase font-mono font-black text-slate-400 tracking-wider flex items-center gap-1.5">
          <CheckSquare className="w-4 h-4 text-[#C49746] shrink-0" />
          Roteiro de Reestruturações Recomendado (Foco 90 Dias)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {prioritizedRecs.map((rec, index) => {
            return (
              <div 
                key={index} 
                className="bg-white border border-slate-200 hover:border-[#C49746]/45 p-4 rounded-lg flex flex-col justify-between hover:shadow-xs transition-all space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">
                      Passo {index + 1}
                    </span>
                    <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      rec.priority === "IMEDIATA" 
                        ? "bg-red-50 text-red-700 border border-red-200" 
                        : rec.priority === "MÉDIO_PRAZO" 
                          ? "bg-amber-50 text-amber-800 border border-amber-200" 
                          : "bg-slate-50 text-slate-600 border border-slate-200"
                    }`}>
                      {rec.priority.replace("_", " ")}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-slate-50 rounded border text-indigo-900 shrink-0">
                      {rec.icon}
                    </div>
                    <span className="text-xs font-black text-slate-900 leading-tight">
                      {rec.title}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 leading-relaxed text-justify">
                    {isSimpleMode(usabilityMode) ? rec.simpleDescription : rec.technicalDescription}
                  </p>
                </div>

                {isExpertMode(usabilityMode) && (
                  <div className="text-[8px] font-mono text-slate-400 border-t border-slate-100 pt-2 flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-slate-350 shrink-0" /> {rec.framework.split(" / ")[0]}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
