import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { DimensionScore } from "./DiagnosisHeatmap";
import { 
  Award, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  TrendingUp, 
  HelpCircle 
} from "lucide-react";

export interface DiagnosisSummaryProps {
  usabilityMode: UsabilityMode;
  scores: DimensionScore[];
  generalScore: number;
}

export default function DiagnosisSummary({
  usabilityMode,
  scores,
  generalScore
}: DiagnosisSummaryProps) {
  
  // Calculate maturity level description
  const getMaturityLevel = (score: number) => {
    if (score < 1.5) {
      return {
        level: "Nível 1 - Caótico / Empreendedor Iniciante",
        academic: "Maturidade Ad-Hoc / Sem Processos Definidos",
        badge: "bg-red-50 text-red-700 border-red-300",
        barColor: "bg-red-500",
        descSimple: "Sua empresa opera de modo reativo, 'apagando incêndios' no dia a dia. Não há processos escritos e a qualidade depende do esforço heróico das pessoas ou do proprietário.",
        descTechnical: "Ausência severa de alinhamento estrutural (McKinsey 7S). Os elementos rígidos (Hard S) e leves (Soft S) estão desconectados, operando de forma estritamente episódica/emergencial."
      };
    }
    if (score < 2.5) {
      return {
        level: "Nível 2 - Reativo Sobrevivente / Sobrecarga",
        academic: "Maturidade Repetível / Reativa",
        badge: "bg-orange-50 text-orange-700 border-orange-300",
        barColor: "bg-orange-500",
        descSimple: "Existem algumas tarefas repetidas de forma natural e certas divisões de setores, mas nada de forma oficial. O proprietário vive sobrecarregado cobrando e corrigindo problemas de retrabalho.",
        descTechnical: "Pequena coesão nos pilares rígidos (Strategy, Structure). Contudo, sistemas internos e ativos organizacionais de desenvolvimento de pessoas (Staff, Skills) são rudimentares."
      };
    }
    if (score < 3.5) {
      return {
        level: "Nível 3 - Organização Definida & Consistente",
        academic: "Maturidade Definida & Padronizada",
        badge: "bg-amber-50 text-amber-800 border-amber-300",
        barColor: "bg-amber-500",
        descSimple: "Sua empresa já possui regras, rotinas e setores que funcionam sozinhos na maior parte do tempo. O desafio agora é tornar isso constante, criar indicadores objetivos e automatizar processos.",
        descTechnical: "Os pilares rígidos (Hard S) e operacionais (Systems) estão minimamente consolidados. O desafio agora reside no alinhamento cultural (Shared Values) e governanças de liderança (Style)."
      };
    }
    if (score < 4.5) {
      return {
        level: "Nível 4 - Gestão Profissional & Monitorada",
        academic: "Maturidade Gerenciada / Alta Coesão 7S",
        badge: "bg-emerald-50 text-emerald-800 border-emerald-300",
        barColor: "bg-emerald-500",
        descSimple: "Sua empresa é profissionalizada. Decisões são tomadas com bases em metas numéricas, as responsabilidades estão desenhadas e a equipe tem forte autonomia no dia a dia operacional.",
        descTechnical: "Configuração madura do McKinsey 7S. Hard e Soft S estão correlacionados estrategicamente, operando com processos de feedback ativos e governança periódica."
      };
    }
    return {
      level: "Nível 5 - Excelência Comercial & Resiliente",
      academic: "Maturidade Automatizada / Otimização Contínua",
      badge: "bg-yellow-50 text-yellow-800 border-yellow-300",
      barColor: "bg-yellow-500",
      descSimple: "Excepcional! A empresa opera por melhoria contínua autogerenciada, com processos que se adaptam rapidamente a mudanças de mercado e forte cultura de inovação interna.",
      descTechnical: "Acme do alinhamento sistêmico. Todos os 7 vetores se reforçam mutualmente em tempo real, atingindo sinergia máxima de expansão corporativa e excelência científica."
    };
  };

  const maturity = getMaturityLevel(generalScore);

  // Identify misalignments (gaps between hard S elements and soft S elements, or max element and min element)
  const sortedScores = [...scores].sort((a, b) => b.score - a.score);
  const highestElement = sortedScores[0];
  const lowestElement = sortedScores[sortedScores.length - 1];
  const hasSevereGap = (highestElement?.score - lowestElement?.score) > 2.0;

  // Formulate specific misalignments based on lowest scores
  const getMisalignments = () => {
    const list: string[] = [];
    if (hasSevereGap) {
      list.push(
        isSimpleMode(usabilityMode)
          ? `Desequilíbrio Severo: Sua empresa se destaca em [${highestElement?.keyNameSimple}] (nota ${highestElement?.score.toFixed(1)}), mas está travada por sérios problemas de [${lowestElement?.keyNameSimple}] (nota ${lowestElement?.score.toFixed(1)}). De nada adianta planejar se a engrenagem falha na base.`
          : `Gargalo Estrutural McKinsey 7S: Severe misalignment detected between [${highestElement?.keyNameTechnical}] (${highestElement?.score.toFixed(1)}) and [${lowestElement?.keyNameTechnical}] (${lowestElement?.score.toFixed(1)}). A robust corporate strategy cannot deploy successfully through fragile operational systems or weak skills.`
      );
    }

    // Specific structural checks
    const s_strategy = scores.find(s => s.id === "estrategia")?.score || 0;
    const s_systems = scores.find(s => s.id === "sistemas")?.score || 0;
    const s_competencias = scores.find(s => s.id === "competencias")?.score || 0;
    const s_valores = scores.find(s => s.id === "valores")?.score || 0;

    if (s_strategy >= 3 && s_systems < 2) {
      list.push(
        isSimpleMode(usabilityMode)
          ? "Rumo no papel, caos na prática: Há boas ideias estratégicas, mas a falta de fluxos desenhados e softwares corretos gera atrasos constantes nas entregas."
          : "Strategy-to-Systems Gap: Strategic intent is formulated, but backend execution mechanisms (Systems) are not configured to translate plans into standard procedures."
      );
    }
    if (s_systems >= 3 && s_competencias < 2) {
      list.push(
        isSimpleMode(usabilityMode)
          ? "Sistemas complexos, equipe perdida: A empresa possui softwares ou regras formais, mas os colaboradores não têm capacitação e autonomia técnica para utilizá-los sozinhos."
          : "Systems-to-Skills Paradox: High process mapping or tech complexity meets low-skilled manual execution (Staff/Skills), leading to system bypasses and human errors."
      );
    }
    if (s_strategy >= 3 && s_valores < 22) {
      list.push(
        isSimpleMode(usabilityMode)
          ? "Diretoria dita as ordens, equipe descomprometida: A empresa planeja expandir faturamento, mas falta engajamento dos funcionários com a cultura e o propósito real."
          : "Strategy-to-Shared-Values Friction: Corporate leadership directs financial/growth targets, but lacks organizational trust, culture or collective buy-in."
      );
    }

    // Default safety
    if (list.length === 0) {
      list.push(
        isSimpleMode(usabilityMode)
          ? "Alinhamento operacional geral homogêneo. Continue mantendo o equilíbrio de metas entre os setores e as equipes."
          : "Systemic alignment indicators are within optimal standard deviations. Maintain periodic performance health checks to verify execution rhythm."
      );
    }

    return list;
  };

  const misalignments = getMisalignments();

  return (
    <div id="diagnosis-summary-panel" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs space-y-6">
      
      {/* MATURITY SUMMARY SCORE CARD */}
      <div className="bg-slate-900 text-white rounded-lg p-6 relative overflow-hidden border border-slate-800 shadow-sm">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#C49746]/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-widest block">
              INDICE DE MATURIDADE EMPRESARIAL
            </span>
            <div className={`inline-flex px-2.5 py-1 rounded-sm border text-xs font-black uppercase ${maturity.badge}`}>
              {isSimpleMode(usabilityMode) ? maturity.level : maturity.academic}
            </div>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              {isSimpleMode(usabilityMode) ? maturity.descSimple : maturity.descTechnical}
            </p>
          </div>

          {/* Large Circle Numeric Score Display */}
          <div className="flex flex-col items-center shrink-0 md:border-l md:border-slate-800 md:pl-8">
            <div className="relative w-24 h-24 rounded-full bg-slate-800 flex items-center justify-center border-2 border-[#C49746]/50">
              <span className="text-3.5xl font-black text-white">{generalScore.toFixed(1)}</span>
              <span className="text-xs text-slate-400 font-bold absolute bottom-2 font-mono">/ 5.0</span>
            </div>
            <span className="text-[9px] font-mono text-slate-400 font-bold uppercase mt-2 tracking-wide">
              Média Integrada 7S
            </span>
          </div>
        </div>
      </div>

      {/* DISALIGNMENT AND GAP FINDER LIST */}
      <div className="space-y-4">
        <h4 className="text-xs uppercase font-mono font-black text-slate-400 tracking-wider flex items-center gap-1.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
          Pontos Críticos e Desalinhamentos Sistêmicos Detectados
        </h4>

        <div className="space-y-3">
          {misalignments.map((mis, index) => {
            return (
              <div 
                key={index} 
                className="bg-amber-50/50 border border-amber-500/25 p-4 rounded-md text-xs text-slate-800 flex items-start gap-3"
              >
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-extrabold text-slate-900 block font-sans">
                    Alerta de Impacto {index + 1}
                  </span>
                  <p className="leading-relaxed text-slate-700">{mis}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
