import React, { useState, useEffect } from "react";
import { 
  Compass, 
  HelpCircle, 
  Sparkles, 
  Play, 
  AlertTriangle, 
  Award, 
  RotateCcw,
  BookOpen,
  Info,
  CheckCircle2,
  ChevronRight,
  ClipboardList
} from "lucide-react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import DiagnosisQuestionnaire, { diagnosisQuestions } from "./DiagnosisQuestionnaire";
import DiagnosisHeatmap, { DimensionScore } from "./DiagnosisHeatmap";
import DiagnosisSummary from "./DiagnosisSummary";
import DiagnosisRecommendations from "./DiagnosisRecommendations";
import { useToast } from "../../shared/ui/Toast";
import ConfirmModal from "../../shared/ui/ConfirmModal";

export interface CompanyDiagnosisPageProps {
  usabilityMode: UsabilityMode;
  setUsabilityMode?: (mode: UsabilityMode) => void;
  onNavigateToJourneyStep?: (stepId: string) => void;
}

export default function CompanyDiagnosisPage({
  usabilityMode,
  setUsabilityMode,
  onNavigateToJourneyStep
}: CompanyDiagnosisPageProps) {
  
  // State for survey answers (persisted in localStorage or empty)
  const [answers, setAnswers] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem("lss_diagnosis_answers");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [isCompleted, setIsCompleted] = useState<boolean>(() => {
    try {
      const savedStatus = localStorage.getItem("lss_diagnosis_completed");
      return savedStatus === "true";
    } catch {
      return false;
    }
  });

  const [activeTab, setActiveTab] = useState<"QUESTIONNAIRE" | "RESULTS">(() => {
    try {
      const savedStatus = localStorage.getItem("lss_diagnosis_completed");
      return savedStatus === "true" ? "RESULTS" : "QUESTIONNAIRE";
    } catch {
      return "QUESTIONNAIRE";
    }
  });

  const [selectedDimensionId, setSelectedDimensionId] = useState<string | null>("estrategia");
  const { warning, success } = useToast();
  const [isConfirmRestartOpen, setIsConfirmRestartOpen] = useState(false);

  // Save answers whenever they change
  useEffect(() => {
    localStorage.setItem("lss_diagnosis_answers", JSON.stringify(answers));
  }, [answers]);

  // Handle answers update
  const handleAnswerChange = (questionId: string, value: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  // Complete diagnostic
  const handleComplete = () => {
    // Verify everything is answered
    const unanswered = diagnosisQuestions.filter(q => answers[q.id] === undefined);
    if (unanswered.length > 0) {
      warning(`Por favor, responda todas as perguntas. Faltam responder ${unanswered.length} perguntas.`);
      return;
    }
    
    setIsCompleted(true);
    localStorage.setItem("lss_diagnosis_completed", "true");
    setActiveTab("RESULTS");
    setSelectedDimensionId("estrategia");
    success("Diagnóstico empresarial 360° concluído com sucesso!");
  };

  // Restart diagnostic
  const handleRestart = () => {
    setIsConfirmRestartOpen(true);
  };

  const handleRestartConfirm = () => {
    setAnswers({});
    setIsCompleted(false);
    localStorage.removeItem("lss_diagnosis_completed");
    localStorage.removeItem("lss_diagnosis_answers");
    setActiveTab("QUESTIONNAIRE");
    success("Diagnóstico reiniciado com sucesso! Comece a responder novamente.");
  };

  // Skip questionnaire with standard average scores (for quick preview/demonstration)
  const handleSkipToPreview = () => {
    const mockAnswers: Record<string, number> = {
      strategy_goal: 4,
      strategy_deployment: 3,
      structure_roles: 2,
      structure_efficiency: 2,
      systems_process: 1,
      systems_it: 2,
      values_culture: 4,
      values_purpose: 3,
      lideranca_coaching: 3,
      lideranca_accountability: 3,
      equipe_talent: 3,
      equipe_retention: 2,
      competencias_skill: 3,
      competencias_training: 1
    };
    setAnswers(mockAnswers);
    setIsCompleted(true);
    localStorage.setItem("lss_diagnosis_completed", "true");
    setActiveTab("RESULTS");
    setSelectedDimensionId("estrategia");
  };

  // Calculate scores per 7S category (0-5 scale)
  const calculateDimensionScores = (): DimensionScore[] => {
    const dimensions: Record<string, { total: number; count: number; category: "HARD_S" | "SOFT_S"; keyNameSimple: string; keyNameTechnical: string }> = {
      estrategia: { total: 0, count: 0, category: "HARD_S", keyNameSimple: "Estratégia (Rumo)", keyNameTechnical: "Strategy" },
      estrutura: { total: 0, count: 0, category: "HARD_S", keyNameSimple: "Estrutura (Organização)", keyNameTechnical: "Structure" },
      sistemas: { total: 0, count: 0, category: "HARD_S", keyNameSimple: "Sistemas (Processos)", keyNameTechnical: "Systems" },
      valores: { total: 0, count: 0, category: "SOFT_S", keyNameSimple: "Cultura (Valores)", keyNameTechnical: "Shared Values" },
      lideranca: { total: 0, count: 0, category: "SOFT_S", keyNameSimple: "Liderança (Estilo)", keyNameTechnical: "Style" },
      equipe: { total: 0, count: 0, category: "SOFT_S", keyNameSimple: "Pessoas (Equipe)", keyNameTechnical: "Staff" },
      competencias: { total: 0, count: 0, category: "SOFT_S", keyNameSimple: "Habilidades (Competências)", keyNameTechnical: "Skills" }
    };

    diagnosisQuestions.forEach(q => {
      const val = answers[q.id];
      if (val !== undefined) {
        dimensions[q.dimension].total += val;
        dimensions[q.dimension].count += 1;
      }
    });

    return Object.entries(dimensions).map(([key, data]) => {
      const score = data.count > 0 ? data.total / data.count : 0;
      return {
        id: key as any,
        keyNameSimple: data.keyNameSimple,
        keyNameTechnical: data.keyNameTechnical,
        category: data.category,
        score: parseFloat(score.toFixed(2))
      };
    });
  };

  const dimensionScores = calculateDimensionScores();

  // General index score
  const answeredCount = Object.keys(answers).length;
  const generalScore = answeredCount > 0 
    ? (Object.values(answers) as number[]).reduce((sum: number, v: number) => sum + v, 0) / answeredCount 
    : 0;

  return (
    <div id="company-diagnosis-page-root" className="w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-slate-800 space-y-6">
      
      {/* HEADER CONTROLS AND INFO */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <ClipboardList className="w-6 h-6 text-[#C49746]" />
            <h1 className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight">
              {isSimpleMode(usabilityMode) ? "Diagnóstico de Processos 360°" : "Empirical McKinsey 7S Diagnosis Suite"}
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {isSimpleMode(usabilityMode) 
              ? "Analise de forma simples o alinhamento da sua empresa dividida em 7 pilares organizacionais essenciais." 
              : "Diagnostic algorithm using the McKinsey 7S Framework to expose bottlenecks and systemic gaps."}
          </p>
        </div>

        {/* Global Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Diagnostic status selector */}
          <div className="flex bg-slate-100 p-1 rounded-md border border-slate-200">
            <button
              type="button"
              id="tab-diagnosis-questionnaire"
              onClick={() => setActiveTab("QUESTIONNAIRE")}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === "QUESTIONNAIRE" 
                  ? "bg-white text-slate-900 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              📋 Questionário {isCompleted && <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1 py-0.5 rounded font-black">OK</span>}
            </button>
            <button
              type="button"
              id="tab-diagnosis-results"
              onClick={() => {
                if (!isCompleted) {
                  warning("Por favor, conclua o preenchimento de todas as perguntas para visualizar o diagnóstico 360°.");
                  return;
                }
                setActiveTab("RESULTS");
              }}
              disabled={!isCompleted}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                !isCompleted ? "opacity-45 cursor-not-allowed" : ""
              } ${
                activeTab === "RESULTS" 
                  ? "bg-white text-slate-900 shadow-xs" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              📊 Resultados e Recomendações
            </button>
          </div>

          {/* Quick Demo button on developer context */}
          {!isCompleted && (
            <button
              type="button"
              onClick={handleSkipToPreview}
              className="px-3 py-1.5 bg-slate-100 border border-slate-300 hover:bg-slate-200 text-[10px] font-mono font-bold text-slate-600 rounded cursor-pointer transition-colors"
            >
              ⚡ Preencher Simulação
            </button>
          )}

          {/* Restart button if completed */}
          {isCompleted && (
            <button
              type="button"
              onClick={handleRestart}
              className="p-2 bg-slate-100 hover:bg-red-50 hover:text-red-700 text-slate-600 border rounded cursor-pointer transition-colors flex items-center gap-1.5 text-xs font-bold"
              title="Apagar respostas e refazer diagnóstico"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Refazer Teste
            </button>
          )}
        </div>
      </div>

      {/* DETAILED DIAGNOSTIC TUTORIAL BOX */}
      {isExpertMode(usabilityMode) && (
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col md:flex-row gap-4 items-start">
          <div className="p-2 bg-[#C49746]/10 border border-[#C49746]/30 text-[#C49746] rounded-md shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div className="space-y-1.5 flex-1">
            <h4 className="text-sm font-extrabold text-slate-950 uppercase tracking-tight">O que é a metodologia McKinsey 7S?</h4>
            <p className="text-xs text-slate-600 leading-relaxed text-justify">
              Desenvolvido nos anos 80 por Robert Waterman Jr e Tom Peters, este framework postula que uma organização não cresce apenas por meio de uma boa <strong>Estratégia</strong> (Strategy), mas da harmonia mútua de sete elementos. Dividido em <strong>Hard S Elements</strong> (Strategy, Structure, Systems - fáceis de definir e planejar) e <strong>Soft S Elements</strong> (Shared Values, Staff, Style, Skills - difíceis de calibrar pois envolvem cultura e pessoas), qualquer assimetria severa entre eles provoca gargalos na entrega de sua cadeia de valor.
            </p>
          </div>
        </div>
      )}

      {/* BODY INTERACTION */}
      <div>
        {activeTab === "QUESTIONNAIRE" ? (
          <div className="space-y-6">
            
            {/* Show welcome block first if empty */}
            {answeredCount === 0 && (
              <div className="bg-[#FAF9F5]/40 border border-slate-200 rounded-lg p-8 text-center max-w-2xl mx-auto space-y-5">
                <div className="flex justify-center">
                  <div className="w-12 h-12 bg-[#C49746]/10 text-[#C49746] rounded-full flex items-center justify-center">
                    <Compass className="w-6 h-6" />
                  </div>
                </div>
                <div className="space-y-2">
                  <h2 className="text-xl font-extrabold text-slate-900 leading-snug">Como está o alinhamento de processos em seu negócio?</h2>
                  <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto leading-normal">
                    Este mapeamento estruturado ajuda você a medir o amadurecimento operacional correspondente a todas as áreas chaves do ecossistema corporativo. Leva em torno de 5 minutos.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-left">
                  <div className="bg-white border rounded p-3 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-[#C49746] font-mono">Pilar 1: Hard S</div>
                    <p className="text-xs text-slate-700 font-bold">Estratégia, Setores e Sistemas</p>
                    <p className="text-[10px] text-slate-400">Como você planeja, divide obrigações e automatiza no papel.</p>
                  </div>
                  <div className="bg-white border rounded p-3 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-[#C49746] font-mono">Pilar 2: Soft S</div>
                    <p className="text-xs text-slate-700 font-bold">Liderança, Pessoas e Habilidades</p>
                    <p className="text-[10px] text-slate-400">Como as pessoas executam e se apoiam de forma integrada.</p>
                  </div>
                  <div className="bg-white border rounded p-3 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-emerald-700 font-mono">Pilar Central</div>
                    <p className="text-xs text-slate-700 font-bold">Valores & Cultura</p>
                    <p className="text-[10px] text-slate-400">O propósito coletivo que une todos sem demandar polícias.</p>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={() => handleAnswerChange(diagnosisQuestions[0].id, 3)} // starts with default neutral selection
                    className="bg-[#C49746] hover:bg-[#B38339] text-white font-bold text-xs uppercase tracking-wider py-3 px-8 rounded shadow-xs hover:shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-white" /> Iniciar Diagnóstico Agora
                  </button>
                </div>
              </div>
            )}

            {/* Render actual survey if started */}
            {answeredCount > 0 && (
              <DiagnosisQuestionnaire
                usabilityMode={usabilityMode}
                answers={answers}
                onAnswerChange={handleAnswerChange}
                onComplete={handleComplete}
              />
            )}

          </div>
        ) : (
          <div className="space-y-8 animate-fade-in">
            
            {/* Overview / general Summary dashboard */}
            <DiagnosisSummary 
              usabilityMode={usabilityMode}
              scores={dimensionScores}
              generalScore={generalScore}
            />

            {/* SVG fully-mesh Heatmap diagram */}
            <DiagnosisHeatmap
              usabilityMode={usabilityMode}
              scores={dimensionScores}
              selectedDimensionId={selectedDimensionId}
              onSelectDimension={setSelectedDimensionId}
            />

            {/* Recommendations workflow based on weaknesses */}
            <DiagnosisRecommendations
              usabilityMode={usabilityMode}
              scores={dimensionScores}
              onNavigateToJourney={onNavigateToJourneyStep}
            />

          </div>
        )}
      </div>

      <ConfirmModal
        isOpen={isConfirmRestartOpen}
        title="Reiniciar Diagnóstico"
        message="Deseja realmente reiniciar seu diagnóstico empresarial 360°? Todas as suas respostas atuais serão completamente removidas."
        confirmLabel="Sim, Reiniciar"
        cancelLabel="Cancelar"
        type="warning"
        onConfirm={handleRestartConfirm}
        onClose={() => setIsConfirmRestartOpen(false)}
      />

    </div>
  );
}
