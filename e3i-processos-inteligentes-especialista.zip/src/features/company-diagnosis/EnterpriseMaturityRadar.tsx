import React from "react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { 
  ShieldAlert, 
  Sparkles, 
  TrendingUp, 
  Award, 
  HelpCircle, 
  Info, 
  Target, 
  Layers, 
  RefreshCw, 
  Users, 
  Cpu, 
  BarChart3, 
  Bookmark, 
  ChevronRight,
  Workflow
} from "lucide-react";

export interface MaturityDimension {
  id: "estrategia" | "estrutura" | "processos" | "pessoas" | "sistemas" | "indicadores" | "cultura" | "governanca";
  labelSimple: string;
  labelTechnical: string;
  framework: string;
  riskSimple: string;
  riskTechnical: string;
  recSimple: string;
  recTechnical: string;
}

export const radarDimensions: MaturityDimension[] = [
  {
    id: "estrategia",
    labelSimple: "Estratégia (Rumo)",
    labelTechnical: "Strategic Formulation",
    framework: "Porter's General Positioning / BSC Map",
    riskSimple: "Sem direção definida, o negócio perde vendas por carência de foco mercadológico.",
    riskTechnical: "Falhas severas de posicionamento e ausência de barreira contra novos entrantes de mercado.",
    recSimple: "Defina as metas essenciais do próximo faturamento trimestral e comunique ao time.",
    recTechnical: "Formular proposta de valor sustentável e estabelecer táticas de segmentação competitiva."
  },
  {
    id: "estrutura",
    labelSimple: "Estrutura (Organização)",
    labelTechnical: "Organizational Design",
    framework: "RACI Matrix / Matrix Hierarchy",
    riskSimple: "Funcionários se atropelando em tarefas e gerando conflitos internos constantes.",
    riskTechnical: "Disperdício de FTEs e atrito interdepartamental por falta de limites de autoridade.",
    recSimple: "Desenhe um organograma de chefia direto e distribua as tarefas por escrito de cada setor.",
    recTechnical: "Instituir matriz de autoridade operacional formalizada anulando ambiguidades funcionais."
  },
  {
    id: "processos",
    labelSimple: "Processos (Rotinas)",
    labelTechnical: "Business Process Management (BPMN)",
    framework: "BPMN Standard / SOP Frameworks",
    riskSimple: "Qualidade de atendimento varia muito, cansando e afastando os melhores clientes.",
    riskTechnical: "Dependência excessiva de mão de obra individualista e alta incidência de gargalos críticos.",
    recSimple: "Escreva ou grave vídeos de instrução explicando o passo-a-passo do trabalho de vendas e compras.",
    recTechnical: "Mapear a cadeia de valor integrada e modelar os principais subprocessos em raias lógicas."
  },
  {
    id: "pessoas",
    labelSimple: "Pessoas (Equipe)",
    labelTechnical: "Staff & Talent Allocation",
    framework: "FTE Capacity Model / HR Retention Systems",
    riskSimple: "Colaboradores cansados e desmotivados pedindo demissão frequentemente.",
    riskTechnical: "Perda sistemática de capital intelectual devido a altos índices de turnover operacional.",
    recSimple: "Crie metas justas com bônus de comissão direta associados ao faturamento.",
    recTechnical: "Desenhar política consistente de valorização humana e balancear o dimensionamento técnico de pessoal."
  },
  {
    id: "sistemas",
    labelSimple: "Sistemas (Softwares)",
    labelTechnical: "Information Technology & Architecture",
    framework: "ERP Integrations / Relational Databases",
    riskSimple: "Perda de dados financeiros e lentidão no fechamento das contas por processos em papel.",
    riskTechnical: "Fragilidade de segurança de base de dados e dessincronização de relatórios gerenciais.",
    recSimple: "Implemente um único software comercial para unificar finanças, vendas e estoque.",
    recTechnical: "Padronizar o ecossistema tecnológico com APIs sólidas, evitando processos manuais redundantes."
  },
  {
    id: "indicadores",
    labelSimple: "Indicadores (Metas)",
    labelTechnical: "Performance Measurement Systems",
    framework: "Key Performance Indicators (KPIs)",
    riskSimple: "Os donos administram confiando no achismo, sem saber o faturamento preciso do dia.",
    riskTechnical: "Inabilidade de prever crises de caixa e tomada de decisões sob distorção cognitiva.",
    recSimple: "Defina os 3 principais números semanais de controle e acompanhe em um quadro visível.",
    recTechnical: "Configurar painéis com KPIs de volume, eficácia e produtividade com metas deduzidas."
  },
  {
    id: "cultura",
    labelSimple: "Cultura (Clima)",
    labelTechnical: "Shared Values & Culture Alignment",
    framework: "Denison Culture Model / Corporate Trust Index",
    riskSimple: "Profissionais agem de má fé ou desleixo por falta de valores éticos compartilhados.",
    riskTechnical: "Instalação silenciosa de desvios éticos por ausência de um código de conduta vivo na firma.",
    recSimple: "Esclareça o regulamento de honestidade e comprometimento exigido no atendimento.",
    recTechnical: "Desenvolver governança ética sólida e reforçar dinâmicas de segurança psicológica no ambiente."
  },
  {
    id: "governanca",
    labelSimple: "Governança (Reuniões)",
    labelTechnical: "Corporate Governance & Accountability",
    framework: "Operational Rituals / Board Control",
    riskSimple: "Problemas se arrastam por meses porque ninguém senta para definir soluções formais.",
    riskTechnical: "Quebra sistemática de diretrizes por debilidade de acompanhamento e conselho de gestão.",
    recSimple: "Institua reuniões rápidas e regulares toda segunda-feira para cobrar as entregas.",
    recTechnical: "Fundamentar rituais formais de cobrança operacional periódica (Daily, Weekly, Monthly Reviews)."
  }
];

export interface EnterpriseMaturityRadarProps {
  usabilityMode: UsabilityMode;
  scores?: Record<string, number>;
}

export default function EnterpriseMaturityRadar({
  usabilityMode,
  scores: propScores
}: EnterpriseMaturityRadarProps) {
  
  // Default fallback mock scores if not provided
  const defaultScores: Record<string, number> = {
    estrategia: 3.8,
    estrutura: 2.2,
    processos: 1.5,
    pessoas: 2.8,
    sistemas: 3.1,
    indicadores: 1.8,
    cultura: 4.2,
    governanca: 2.0
  };

  const activeScores = propScores || defaultScores;

  // Render score color context
  const getScoreColor = (score: number) => {
    if (score < 1.6) return { text: "text-red-700", bg: "bg-red-50", border: "border-red-300", fill: "#EF4444" };
    if (score < 3.1) return { text: "text-amber-800", bg: "bg-amber-50", border: "border-amber-300", fill: "#F59E0B" };
    if (score < 4.5) return { text: "text-emerald-800", bg: "bg-emerald-50", border: "border-emerald-300", fill: "#10B981" };
    return { text: "text-yellow-800", bg: "bg-yellow-50", border: "border-yellow-300", fill: "#EAB308" };
  };

  // Build the dynamic textual summary based on values
  const getNarrativeSummary = () => {
    const highDimensions = Object.entries(activeScores)
      .filter(([_, score]) => score >= 3.5)
      .map(([key]) => radarDimensions.find(t => t.id === key)?.labelSimple.split(" ")[0] || "");

    const lowDimensions = Object.entries(activeScores)
      .filter(([_, score]) => score < 2.5)
      .map(([key]) => radarDimensions.find(t => t.id === key)?.labelSimple.split(" ")[0] || "");

    if (highDimensions.length > 0 && lowDimensions.length > 0) {
      return `Sua empresa possui boa solidez estrutural ou operacional em ${highDimensions.join(", ")}, demonstrando controle nestas frentes. Contudo, a capacidade de colher resultados sustentáveis está ameaçada por gargalos em ${lowDimensions.join(", ")}, demandando atenção corretiva prioritária.`;
    } else if (lowDimensions.length > 0) {
      return `Alerta: Sua empresa enfrenta vulnerabilidades gerais generalizadas de performance, com carências críticas em ${lowDimensions.join(", ")}. É urgente reestruturar de forma sequencial o negócio para evitar falência operacional de atividades diárias.`;
    } else {
      return `Excelente alinhamento operacional geral! Todos os subsetores de faturamento, equipes e governança estão operando em sintonia equilibrada de amadurecimento corporativo.`;
    }
  };

  // SVG Coordinates calculations for a 8-axis Radar chart
  // Radar dimension points (Center is (175, 175) with radius 110)
  const cx = 175;
  const cy = 175;
  const maxRadius = 110;

  // Coordinates for the 8 axes spaced 45 degrees apart
  const numAxes = 8;
  const axisCoordinates = Array.from({ length: numAxes }).map((_, i) => {
    const angle = (i * Math.PI * 2) / numAxes - Math.PI / 2; // offset -90 deg to start top vertical
    return {
      x: Math.cos(angle),
      y: Math.sin(angle),
      angle
    };
  });

  // Calculate coordinates of current user score points for the polygon outline
  const scorePolygonPoints = radarDimensions.map((dim, i) => {
    const axis = axisCoordinates[i];
    const score = activeScores[dim.id] !== undefined ? activeScores[dim.id] : 0;
    const currentRadius = (score / 5) * maxRadius;
    const ptX = cx + axis.x * currentRadius;
    const ptY = cy + axis.y * currentRadius;
    return `${ptX},${ptY}`;
  }).join(" ");

  return (
    <div id="enterprise-maturity-radar" className="bg-white border border-slate-200 rounded-lg p-5 sm:p-6 shadow-xs">
      
      {/* SECTION HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
        <div>
          <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
            🕸️ Radar de Maturidade Sistêmica
          </h3>
          <p className="text-xs text-slate-500">
            Diagnóstico gráfico comparativo englobando as 8 direções críticas para o crescimento comercial sustentável.
          </p>
        </div>

        {/* Mode marker */}
        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border self-start ${
          isExpertMode(usabilityMode) 
            ? "bg-slate-900 border-slate-800 text-slate-200" 
            : "bg-amber-50 border-amber-200 text-amber-800 font-bold"
        }`}>
          {isExpertMode(usabilityMode) ? "Radar de Frameworks" : "Radar de Operações"}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* RADAR CANVAS SVG (5 COLS) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center bg-slate-50 border border-slate-100 rounded-lg p-4 relative min-h-[350px]">
          
          <svg className="w-full max-w-[340px] aspect-square" viewBox="0 0 350 350">
            {/* Draw grid concentric octagons (0.5 to 5.0 in steps of 1.0) */}
            {[1, 2, 3, 4, 5].map((level) => {
              const ringRadius = (level / 5) * maxRadius;
              const pointsStr = axisCoordinates.map(axis => {
                const px = cx + axis.x * ringRadius;
                const py = cy + axis.y * ringRadius;
                return `${px},${py}`;
              }).join(" ");

              return (
                <polygon
                  key={level}
                  points={pointsStr}
                  fill="none"
                  stroke="#E2E8F0"
                  strokeWidth="1"
                  strokeDasharray={level === 5 ? "none" : "2,2"}
                />
              );
            })}

            {/* Draw Grid Axis Lines */}
            {axisCoordinates.map((axis, i) => {
              const ax = cx + axis.x * maxRadius;
              const ay = cy + axis.y * maxRadius;
              return (
                <line
                  key={i}
                  x1={cx}
                  y1={cy}
                  x2={ax}
                  y2={ay}
                  stroke="#CBD5E1"
                  strokeWidth="1.25"
                />
              );
            })}

            {/* Draw current score polygon outline and translucent fill */}
            <polygon
              points={scorePolygonPoints}
              fill="rgba(196, 151, 70, 0.22)"
              stroke="#C49746"
              strokeWidth="2.5"
              className="transition-all duration-500"
            />

            {/* Axis Node Dots & Text Labels */}
            {radarDimensions.map((dim, i) => {
              const axis = axisCoordinates[i];
              
              // Push text label slightly outward to avoid overlapping SVG dots
              const textRadius = maxRadius + 18;
              const tx = cx + axis.x * textRadius;
              const ty = cy + axis.y * textRadius + 4;

              const score = activeScores[dim.id] || 0;
              const ptRadius = (score / 5) * maxRadius;
              const ptX = cx + axis.x * ptRadius;
              const ptY = cy + axis.y * ptRadius;

              // Anchor text alignment depending on which quadrant it resides
              let textAnchor = "middle";
              if (axis.x > 0.1) textAnchor = "start";
              if (axis.x < -0.1) textAnchor = "end";

              return (
                <g key={dim.id}>
                  {/* Actual Score dot on the polygon vertex */}
                  <circle
                    cx={ptX}
                    cy={ptY}
                    r="4.5"
                    fill="#C49746"
                    stroke="#FFFFFF"
                    strokeWidth="1.5"
                    className="shadow-xs hover:r-6 hover:fill-amber-600 transition-all cursor-pointer"
                  />

                  {/* Dimension Name Label */}
                  <text
                    x={tx}
                    y={ty}
                    textAnchor={textAnchor}
                    fill="#0F172A"
                    fontSize="9.5"
                    fontWeight="800"
                    className="font-sans select-none tracking-tight"
                  >
                    {isSimpleMode(usabilityMode) ? dim.labelSimple.split(" ")[0] : dim.id.toUpperCase()}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Quick info status badge inside chart area */}
          <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-white p-1.5 rounded-sm border text-[9px] font-mono font-bold text-slate-500">
            <Info className="w-3.5 h-3.5 text-[#C49746]" /> Clique nos eixos de 0.0 a 5.0
          </div>
        </div>

        {/* NARRATIVE ANALYSIS AND COMPREHENSIVE ROADMAP CARDS (7 COLS) */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Narrative simple translation */}
          <div className="bg-slate-55 border border-slate-200 rounded-lg p-4 space-y-2">
            <span className="text-[10.5px] uppercase font-mono font-bold text-[#C49746] tracking-wider flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5" /> Tradução em Linguagem Simples (Orientação)
            </span>
            <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed text-justify">
              "{getNarrativeSummary()}"
            </p>
          </div>

          {/* Detailed tabular list of scores & framework/risks depending on mode */}
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {radarDimensions.map((dim) => {
              const score = activeScores[dim.id] || 0;
              const colorInfo = getScoreColor(score);

              return (
                <div 
                  key={dim.id} 
                  id={`radar-row-${dim.id}`}
                  className="bg-white border hover:border-slate-350 p-3 rounded-lg flex items-start justify-between gap-4 transition-all"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-xs font-black text-slate-900">
                        {isSimpleMode(usabilityMode) ? dim.labelSimple : dim.labelTechnical}
                      </span>
                      
                      {isExpertMode(usabilityMode) && (
                        <span className="text-[8.5px] font-mono text-slate-400 border border-slate-150 px-1 py-0.5 rounded uppercase font-bold bg-slate-50">
                          {dim.framework.split(" / ")[0]}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-500 leading-normal text-justify">
                      <span className="font-extrabold text-slate-700">Ameaça: </span>
                      {isSimpleMode(usabilityMode) ? dim.riskSimple : dim.riskTechnical}
                    </p>

                    <p className="text-[11px] text-[#C49746] leading-normal text-justify">
                      <span className="font-extrabold">Ação Indicada: </span>
                      {isSimpleMode(usabilityMode) ? dim.recSimple : dim.recTechnical}
                    </p>
                  </div>

                  {/* Compact score layout */}
                  <div className="flex flex-col items-center shrink-0">
                    <span className={`text-base font-black px-2.5 py-1 rounded-md border font-mono ${colorInfo.bg} ${colorInfo.border} ${colorInfo.text}`}>
                      {score.toFixed(1)}
                    </span>
                    <span className="text-[8px] font-mono text-slate-400 font-bold uppercase mt-1 tracking-tight">
                      Maturidade
                    </span>
                  </div>

                </div>
              );
            })}
          </div>

        </div>

      </div>

    </div>
  );
}
