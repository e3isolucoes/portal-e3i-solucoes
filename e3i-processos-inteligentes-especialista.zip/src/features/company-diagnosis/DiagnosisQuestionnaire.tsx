import React, { useState } from "react";
import { 
  Award,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  BookOpen,
  Zap,
  Layers,
  Sparkles,
  Info
} from "lucide-react";
import { UsabilityMode, isSimpleMode, isExpertMode } from "../../domain/usabilityMode";
import { useToast } from "../../shared/ui/Toast";

export interface DiagnosisQuestion {
  id: string;
  dimension: "estrategia" | "estrutura" | "sistemas" | "valores" | "lideranca" | "equipe" | "competencias";
  dimensionLabelSimple: string;
  dimensionLabelTechnical: string;
  dimensionTechnicalDesc: string;
  questionSimple: string;
  questionTechnical: string;
  helpSimple: string;
  helpTechnical: string;
}

export const diagnosisQuestions: DiagnosisQuestion[] = [
  {
    id: "strategy_goal",
    dimension: "estrategia",
    dimensionLabelSimple: "Estratégia (Rumo)",
    dimensionLabelTechnical: "Strategy",
    dimensionTechnicalDesc: "O plano de longo prazo para construir vantagem competitiva sustentável e alcançar os objetivos estratégicos.",
    questionSimple: "A empresa sabe claramente para onde quer ir e onde focar suas forças nos próximos anos?",
    questionTechnical: "A estratégia corporativa de médio/longo prazo está claramente formulada e serve de guia para as decisões operacionais?",
    helpSimple: "Avalie se os donos e a equipe têm o mesmo destino em mente ou se cada um corre para um lado sem rumo único.",
    helpTechnical: "Verifique se há análise de mercado estruturada, posicionamento competitivo diferenciado e objetivos estratégicos compartilhados."
  },
  {
    id: "strategy_deployment",
    dimension: "estrategia",
    dimensionLabelSimple: "Estratégia (Rumo)",
    dimensionLabelTechnical: "Strategy",
    dimensionTechnicalDesc: "O plano de longo prazo para construir vantagem competitiva sustentável e alcançar os objetivos estratégicos.",
    questionSimple: "As grandes metas gerais da empresa são convertidas em planos específicos com responsáveis e prazos claros?",
    questionTechnical: "Existe o desdobramento da estratégia (ex: OKRs, Balanced Scorecard) em planos táticos e metas tangíveis para as áreas?",
    helpSimple: "Ideias e vontades saem da cabeça dos diretores e se tornam projetos desenhados com datas de entrega e cobrança?",
    helpTechnical: "Investigue se há governança formal para o monitoramento da execução e desdobramento sistemático do plano estratégico."
  },
  {
    id: "structure_roles",
    dimension: "estrutura",
    dimensionLabelSimple: "Estrutura (Organização)",
    dimensionLabelTechnical: "Structure",
    dimensionTechnicalDesc: "A forma como a empresa se divide (setores) e estabelece canais de reporte e delegação.",
    questionSimple: "Cada área/pessoa sabe exatamente quais são todas as suas obrigações diárias e quem aprova cada tarefa?",
    questionTechnical: "O desenho organizacional de responsabilidades (ex: Matriz Raci, organograma funcional) é claro e formalmente comunicado?",
    helpSimple: "Evite conflitos, buracos operacionais e o famoso 'joguei a bola e ninguém pegou'. Todo mundo sabe o que responder?",
    helpTechnical: "Avalie a eficiência das linhas de reporte, o grau de descentralização e a clareza das fronteiras de tomada de decisão."
  },
  {
    id: "structure_efficiency",
    dimension: "estrutura",
    dimensionLabelSimple: "Estrutura (Organização)",
    dimensionLabelTechnical: "Structure",
    dimensionTechnicalDesc: "A forma como a empresa se divide (setores) e estabelece canais de reporte e delegação.",
    questionSimple: "A divisão de setores e o fluxo de ordens reduzem a burocracia e ajudam a atender o cliente interno/externo com agilidade?",
    questionTechnical: "A arquitetura de unidades organizacionais minimiza silos departamentais e suporta a cadeia de valor integrada?",
    helpSimple: "A estrutura organizacional ajuda a fluir o trabalho ou cria paredes/gargalos de comunicação que atrasam as entregas?",
    helpTechnical: "A estrutura apoia a estratégia. Uma estrutura estática demais compromete a adaptabilidade corporativa."
  },
  {
    id: "systems_process",
    dimension: "sistemas",
    dimensionLabelSimple: "Sistemas (Processos)",
    dimensionLabelTechnical: "Systems",
    dimensionTechnicalDesc: "Os procedimentos formais e informais que sustentam as atividades de rotina.",
    questionSimple: "Os processos críticos de trabalho estão desenhados, explicados e realmente padronizados no dia a dia da equipe?",
    questionTechnical: "Os fluxos de processo (BPMN, POPs) estão documentados, operacionalizados e livres de desvios e gargalos recorrentes?",
    helpSimple: "Sem padrões, cada funcionário desempenha a mesma função de um jeito diferente, gerando retrabalhos constantes e oscilação de qualidade.",
    helpTechnical: "Análise da maturidade de processos críticos. Há padronização executável ou depende do heroísmo dos indivíduos?"
  },
  {
    id: "systems_it",
    dimension: "sistemas",
    dimensionLabelSimple: "Sistemas (Processos)",
    dimensionLabelTechnical: "Systems",
    dimensionTechnicalDesc: "Os procedimentos formais e informais que sustentam as atividades de rotina.",
    questionSimple: "Existem softwares comerciais estáveis ou controles compartilhados que entregam informações corretas em tempo real?",
    questionTechnical: "Os sistemas integrados de gestão (ERP, CRM) e a arquitetura de dados garantem confiabilidade e suporte de informações?",
    helpSimple: "As planilhas ou sistemas informáticos atuais ajudam a controlar os gargalos e evitar perdas financeiras ou geram retrabalho extra?",
    helpTechnical: "Mapeamento tecnológico. Os sistemas sustentam a cadeia de valor com segurança de informação e automação confiável."
  },
  {
    id: "values_culture",
    dimension: "valores",
    dimensionLabelSimple: "Valores Compartilhados (Cultura)",
    dimensionLabelTechnical: "Shared Values",
    dimensionTechnicalDesc: "As crenças centrais, propósitos e princípios que moldam o comportamento coletivo.",
    questionSimple: "As pessoas da equipe agem de acordo com as regras éticas da empresa mesmo quando os chefes não estão vigiando?",
    questionTechnical: "Os valores fundamentais declarados coincidem com a prática organizacional real e as condutas diárias evidentes?",
    helpSimple: "A cultura do negócio incentiva a honestidade, a dedicação e o zelo profissional de forma natural do próprio grupo?",
    helpTechnical: "Auditoria do alinhamento cultural. Há presença real do código de ética na resolução de conflitos e decisões difíceis?"
  },
  {
    id: "values_purpose",
    dimension: "valores",
    dimensionLabelSimple: "Valores Compartilhados (Cultura)",
    dimensionLabelTechnical: "Shared Values",
    dimensionTechnicalDesc: "As crenças centrais, propósitos e princípios que moldam o comportamento coletivo.",
    questionSimple: "A equipe se sente parte de algo maior e entende o impacto e a importância do próprio trabalho para o sucesso da empresa?",
    questionTechnical: "Existe clareza de propósito social corporativo, visão inspiradora compartilhada e orgulho em pertencer à marca?",
    helpSimple: "Os operários entendem que estão construindo uma catedral, e não apenas quebrando pedras para ganhar um salário no final do mês?",
    helpTechnical: "Avaliação do engajamento transcendental. O propósito unifica e motiva os colaboradores, gerando paixão pelo negócio."
  },
  {
    id: "lideranca_coaching",
    dimension: "lideranca",
    dimensionLabelSimple: "Liderança (Estilo)",
    dimensionLabelTechnical: "Style",
    dimensionTechnicalDesc: "O padrão comportamental, linguagem coletiva e liderança praticada pela diretoria da corporação.",
    questionSimple: "Os líderes são presentes, justos, dedicam tempo para tirar dúvidas e escutam o que a equipe tem a propor?",
    questionTechnical: "O estilo de liderança predominante (coaching, situacional) apoia a maturidade das equipes e promove a segurança psicológica?",
    helpSimple: "Uma liderança muito egoísta, distante ou ditatorial afasta os bons talentos e impede a inovação por medo de errar.",
    helpTechnical: "Verificar se as lideranças atuam como facilitadoras e mentoras ou se atuam de forma estritamente autocrática."
  },
  {
    id: "lideranca_accountability",
    dimension: "lideranca",
    dimensionLabelSimple: "Liderança (Estilo)",
    dimensionLabelTechnical: "Style",
    dimensionTechnicalDesc: "O padrão comportamental, linguagem coletiva e liderança praticada pela diretoria da corporação.",
    questionSimple: "Os gerentes e diretores assumem a responsabilidade por cumprir promessas e corrigem falhas rapidamente com a equipe?",
    questionTechnical: "Existe uma cultura forte de responsabilidade corporativa (accountability), rituais de feedback sincero e consistência ética?",
    helpSimple: "Os líderes dão o exemplo de engajamento do início ao fim ou apenas apontam o dedo buscando bodes expiatórios para as crises?",
    helpTechnical: "A liderança pelo exemplo é a base do McKinsey 7S. Líderes incoerentes decompõem a coesão de qualquer processo."
  },
  {
    id: "equipe_talent",
    dimension: "equipe",
    dimensionLabelSimple: "Equipe (Pessoas)",
    dimensionLabelTechnical: "Staff",
    dimensionTechnicalDesc: "A demografia, número, diversidade e gestão geral dos recursos humanos da empresa.",
    questionSimple: "A quantidade de pessoas operando atualmente é suficiente e estão nas funções onde suas maiores qualidades brilham?",
    questionTechnical: "O dimensionamento de pessoal (FTE) está balanceado e o processo seletivo assegura atração qualificada e boa adaptação cultural?",
    helpSimple: "Temos pessoas cansadas por excesso de carga ou subaproveitadas em departamentos que não condizem com suas características?",
    helpTechnical: "Análise quantitativa e qualitativa do quadro funcional. O perfil demográfico de contratação atende à expansão estratégica do negócio?"
  },
  {
    id: "equipe_retention",
    dimension: "equipe",
    dimensionLabelSimple: "Equipe (Pessoas)",
    dimensionLabelTechnical: "Staff",
    dimensionTechnicalDesc: "A demografia, número, diversidade e gestão geral dos recursos humanos da empresa.",
    questionSimple: "A empresa possui um ambiente agradável de trabalho e rituais transparentes de valorização e retenção da equipe?",
    questionTechnical: "Existem rotinas maduras de avaliação de desempenho, políticas salariais coerentes e planos claros de progressão interna?",
    helpSimple: "Funcionários antigos e eficientes vão embora frequentemente por melhores salários ou falta de chance de crescimento?",
    helpTechnical: "Nível de rotatividade (turnover) e metodologias de retenção de talentos críticos na cadeia de valor corporativa."
  },
  {
    id: "competencias_skill",
    dimension: "competencias",
    dimensionLabelSimple: "Competências (Habilidades)",
    dimensionLabelTechnical: "Skills",
    dimensionTechnicalDesc: "As capacidades reais, ativos de conhecimento e saberes práticos instalados na organização.",
    questionSimple: "A equipe domina as tarefas técnicas e resolve a maioria das pedreiras do dia a dia sem precisar do dono no pé toda hora?",
    questionTechnical: "O capital de conhecimento (know-how) operacional está bem distribuído, evitando gargalos de dependência de indivíduos-chave?",
    helpSimple: "Se as mentes mais experientes da empresa tirarem 15 dias de férias coletivas por motivos médicos, seu negócio continua operando normalmente?",
    helpTechnical: "Verificar se há dependência extrema de pessoas-chave para tarefas corriqueiras e se há matriz de polivalência técnica instalada."
  },
  {
    id: "competencias_training",
    dimension: "competencias",
    dimensionLabelSimple: "Competências (Habilidades)",
    dimensionLabelTechnical: "Skills",
    dimensionTechnicalDesc: "As capacidades reais, ativos de conhecimento e saberes práticos instalados na organização.",
    questionSimple: "Existem treinamentos recorrentes e práticos para ensinar novas ferramentas de trabalho e melhorar o rendimento técnico?",
    questionTechnical: "Existe uma estratégia sistemática de capacitação contínua (L&D), mapeamento de lacunas e atualização de competências?",
    helpSimple: "Há incentivos e agendas para o funcionário continuar buscando aprender, melhorando a produtividade do seu trabalho?",
    helpTechnical: "Avaliação do investimento em desenvolvimento humano de alto desempenho (Upskilling e Reskilling)."
  }
];

export interface DiagnosisQuestionnaireProps {
  usabilityMode: UsabilityMode;
  answers: Record<string, number>;
  onAnswerChange: (questionId: string, value: number) => void;
  onComplete: () => void;
}

export default function DiagnosisQuestionnaire({
  usabilityMode,
  answers,
  onAnswerChange,
  onComplete
}: DiagnosisQuestionnaireProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const { warning } = useToast();

  const totalQuestions = diagnosisQuestions.length;
  const currentQuestion = diagnosisQuestions[currentStep];
  const isLastStep = currentStep === totalQuestions - 1;

  // Answer labels for 0-5
  const scoreOptions = [
    { value: 0, label: "0 - Caótico / Inexistente", desc: "Não existe controle ou iniciativa sobre isso na rotina." },
    { value: 1, label: "1 - Reativo / Básico", desc: "Apenas tomamos providências em caso de incêndio ou crise." },
    { value: 2, label: "2 - Informal", desc: "Existe alguma ideia ou conversa, mas nada padronizado ou seguido." },
    { value: 3, label: "3 - Padronizado", desc: "Há combinados consistentes e a equipe executa de forma constante." },
    { value: 4, label: "4 - Monitorado", desc: "Acompanhamos com metas numéricas, medimos qualidade e cobramos desvios." },
    { value: 5, label: "5 - Excelente", desc: "Referência absoluta, otimizado sempre com processos automatizados." }
  ];

  const handleNext = () => {
    if (answers[currentQuestion.id] === undefined) {
      warning("Por favor, selecione uma nota antes de avançar.");
      return;
    }
    if (isLastStep) {
      onComplete();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const currentValue = answers[currentQuestion.id];
  const progressPercent = Math.round(((currentStep + 1) / totalQuestions) * 100);

  return (
    <div id="diagnosis-questionnaire-panel" className="bg-white border border-slate-200 rounded-lg p-6 sm:p-8 shadow-xs max-w-3xl mx-auto">
      
      {/* ProgressBar */}
      <div className="mb-6 space-y-2">
        <div className="flex justify-between items-center text-xs font-mono font-bold text-slate-500">
          <span className="uppercase tracking-wider">📋 Questionário Diagnóstico 360°</span>
          <span>{currentStep + 1} de {totalQuestions} perguntas ({progressPercent}%)</span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-[#C49746] transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* QUESTION BODY */}
      <div className="space-y-6 min-h-[220px]">
        {/* Category Badge */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#C49746]" />
            <span className="text-sm font-extrabold text-slate-900 uppercase font-sans tracking-wide">
              {isSimpleMode(usabilityMode) ? currentQuestion.dimensionLabelSimple : currentQuestion.dimensionLabelTechnical}
            </span>
          </div>

          {isExpertMode(usabilityMode) && (
            <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200/60 uppercase">
              7S Pillar: {currentQuestion.dimension === "valores" ? "Shared Values" : currentQuestion.dimension}
            </span>
          )}
        </div>

        {/* Academic detail box for experts only */}
        {isExpertMode(usabilityMode) && (
          <div className="bg-slate-50 border border-slate-150 rounded p-3 text-xs text-slate-600 flex items-start gap-2.5">
            <BookOpen className="w-4 h-4 text-[#C49746] shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-800">Conceito McKinsey 7S: </span>
              {currentQuestion.dimensionTechnicalDesc}
            </div>
          </div>
        )}

        {/* Actual Question */}
        <div className="space-y-1.5">
          <h3 className="text-lg sm:text-xl font-bold text-slate-950 leading-snug">
            {isSimpleMode(usabilityMode) ? currentQuestion.questionSimple : currentQuestion.questionTechnical}
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 leading-normal italic flex items-center gap-1.5">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            {isSimpleMode(usabilityMode) ? currentQuestion.helpSimple : currentQuestion.helpTechnical}
          </p>
        </div>

        {/* 0-5 Selection list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
          {scoreOptions.map((opt) => {
            const isSelected = currentValue === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                id={`score-option-${opt.value}`}
                onClick={() => onAnswerChange(currentQuestion.id, opt.value)}
                className={`flex flex-col p-3 rounded-lg border text-left transition-all cursor-pointer ${
                  isSelected 
                    ? "bg-slate-50 border-[#C49746] ring-1 ring-[#C49746]/20" 
                    : "bg-white border-slate-200 hover:border-slate-350 hover:bg-slate-50/30"
                }`}
              >
                <span className={`text-xs font-bold ${isSelected ? "text-[#C49746]" : "text-slate-800"}`}>
                  {opt.label}
                </span>
                <span className="text-[11px] text-slate-500 mt-1 leading-normal line-clamp-2">
                  {opt.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ACTIONS FOOTER */}
      <div className="flex items-center justify-between border-t border-slate-150 pt-5 mt-8">
        <button
          type="button"
          onClick={handlePrev}
          disabled={currentStep === 0}
          className={`flex items-center gap-1 py-2 px-4 rounded text-xs font-bold uppercase ${
            currentStep === 0 
              ? "text-slate-300 pointer-events-none" 
              : "text-slate-600 hover:text-slate-950 cursor-pointer"
          }`}
        >
          <ChevronLeft className="w-4 h-4" /> Voltar anterior
        </button>

        <button
          type="button"
          onClick={handleNext}
          className="bg-[#C49746] hover:bg-[#B38339] text-white font-bold text-xs uppercase tracking-wider py-2.5 px-6 rounded shadow-xs hover:shadow-md transition-all cursor-pointer flex items-center gap-1.5"
        >
          {isLastStep ? "Concluir Diagnóstico" : "Ir para próxima"} <ChevronRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
}
