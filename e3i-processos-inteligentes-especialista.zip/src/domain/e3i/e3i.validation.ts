import { z } from "zod";

/**
 * Strict Zod validation schema for Initial Process Mapping submissions.
 * Defines rules for selected sectors, macroprocess identifiers, and user descriptions.
 */
export const initialProcessMappingSchema = z.object({
  selectedSector: z.enum(["GENERAL", "INDUSTRIAL", "SERVICES", "RETAIL", "LOGISTICS"]),
  selectedMacroId: z.string().min(1, "Por favor, selecione um macroprocesso associado válido."),
  description: z.string()
    .min(15, "A descrição precisa ter pelo menos 15 caracteres para detalhar o processo adequadamente.")
    .max(5000, "A descrição excede o limite máximo permitido de 5000 caracteres.")
    .refine((val) => val.trim().length >= 15, {
      message: "A descrição do processo não pode consistir apenas de espaços vazios."
    })
});

export type InitialProcessMappingInput = z.infer<typeof initialProcessMappingSchema>;
