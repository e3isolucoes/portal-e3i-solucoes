export interface SegmentTemplate {
  id: string;
  name: string;
  icon: string; // lucide icon name
  description: string;
  pains: string[];
  suggestedProcesses: {
    name: string;
    description: string;
    steps: {
      name: string;
      resource: string;
      processingTime: number; // in mins
      yieldRate: number; // 0 to 1
    }[];
  }[];
  suggestedMetrics: {
    name: string;
    target: string;
    unit: string;
    frequency: string;
  }[];
  commonResponsibilities: {
    role: string;
    activities: { activityName: string; roleType: "R" | "A" | "C" | "I" }[];
  }[];
  commonRisks: {
    event: string;
    impact: "alto" | "medio" | "baixo";
    probability: "alto" | "medio" | "baixo";
    mitigation: string;
  }[];
  diagnosticQuestions: {
    text: string;
    options: { label: string; score: number }[];
  }[];
  initialPlan: {
    stepName: string;
    responsible: string;
    duration: string;
    deliverable: string;
  }[];
}

export const SEGMENT_TEMPLATES: Record<string, SegmentTemplate> = {
  accounting: {
    id: "accounting",
    name: "Escritório Contábil",
    icon: "FileSpreadsheet",
    description: "Especializado em fluxo de obrigações acessórias, fiscal, trabalhoso e societário com foco em pontualidade e conformidade Saneadora.",
    pains: [
      "Perda de prazos de guias fiscais e multas acumuladas por falha humana",
      "Retrabalho contínuo na digitação manual de extratos e notas",
      "Sobrecarga extrema da equipe na primeira semana útil do mês",
      "Falta de visibilidade sobre o status de processamento por cliente"
    ],
    suggestedProcesses: [
      {
        name: "Fechamento Fiscal Mensal",
        description: "Rotina de conferência de notas, cálculo de impostos federais/estaduais e emissão de guias acessórias.",
        steps: [
          { name: "Importação de XML e Extratos", resource: "Assistente Fiscal", processingTime: 15, yieldRate: 0.95 },
          { name: "Saneamento de Inconsistências", resource: "Analista Fiscal", processingTime: 45, yieldRate: 0.88 },
          { name: "Cálculo de Impostos (DAS/IPI)", resource: "Analista Fiscal", processingTime: 30, yieldRate: 0.97 },
          { name: "Validação Cruzada Sped", resource: "Supervisor Fiscal", processingTime: 20, yieldRate: 0.99 },
          { name: "Emissão e Entrega de Guias", resource: "Assistente Fiscal", processingTime: 10, yieldRate: 1.0 }
        ]
      },
      {
        name: "Admissão de Colaborador de Cliente",
        description: "Processamento legal da documentação trabalhista de admissão do colaborador até registro oficial do eSocial.",
        steps: [
          { name: "Recebimento de Documentos", resource: "Assistente de D.P.", processingTime: 20, yieldRate: 0.85 },
          { name: "Análise Cadastral e Qualificação", resource: "Analista de D.P.", processingTime: 15, yieldRate: 0.92 },
          { name: "Upload no Portal do eSocial", resource: "Analista de D.P.", processingTime: 10, yieldRate: 0.98 },
          { name: "Envio do Protocolo de Registro", resource: "Assistente de D.P.", processingTime: 5, yieldRate: 1.0 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Entregas dentro do prazo (SLA)", target: "> 99.5%", unit: "% das obrigações", frequency: "Mensal" },
      { name: "Tempo de digitação manual", target: "< 5 min", unit: "por lote de notas", frequency: "Semanal" },
      { name: "Taxa de retrabalho fiscal", target: "< 2.0%", unit: "% de guias retificadas", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "Analista Fiscal",
        activities: [
          { activityName: "Cálculo de Impostos do Cliente", roleType: "R" },
          { activityName: "Aprovação de Guias Calculadas", roleType: "A" }
        ]
      },
      {
        role: "Sócio do Escritório",
        activities: [
          { activityName: "Homologação de Contratos de Honorários", roleType: "A" },
          { activityName: "Acompanhamento Técnico Preventivo", roleType: "C" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Perda da data limite de obrigações do Sped Fiscal",
        impact: "alto",
        probability: "medio",
        mitigation: "Configurar alertas automáticos de cronograma no painel 3 dias antes do limite regular."
      },
      {
        event: "Instabilidade sistêmica do governo (eSocial/Receita)",
        impact: "medio",
        probability: "alto",
        mitigation: "Antecipar rotinas cadastrais básicas e manter contingência de backup de arquivos XML."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Como é feita a coleta de movimentações financeiras de clientes?",
        options: [
          { label: "Totalmente manual via PDF/Papel, exigindo digitação exaustiva", score: 1 },
          { label: "Misto, parte via arquivos Excel estruturados e parte por digitação", score: 3 },
          { label: "Integrada, com importação eletrônica direta de arquivos OFX ou API", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Mapeamento das Fontes de Dados", responsible: "Consultor Lean", duration: "1 semana", deliverable: "Mapa de gargalos de entrada de XMLs" },
      { stepName: "Implantação de Ferramenta de Captura", responsible: "Analista de TI", duration: "2 semanas", deliverable: "Integração automática com prefeitura" }
    ]
  },
  pme_services: {
    id: "pme_services",
    name: "PME de Serviços",
    icon: "Building2",
    description: "Foco em vendas, negociação, prestação ágil de serviços especializados e manutenção preventiva.",
    pains: [
      "Oscilação pesada no faturamento mensal por falta de funil qualificado",
      "Serviços executados no Escopo errado (sem briefing amarrado)",
      "Lentidão para faturar e enviar o boleto de cobrança contratual",
      "Falta de controle de horas de equipe especializada por projeto"
    ],
    suggestedProcesses: [
      {
        name: "Funil de Vendas e Proposta",
        description: "Etapa mercantil da atração, qualificação, proposta técnica comercial e fechamento de novos negócios.",
        steps: [
          { name: "Qualificação de Lead Receptivo", resource: "Pré-Vendedor (SDR)", processingTime: 15, yieldRate: 0.7 },
          { name: "Escopo de Solução & Briefing", resource: "Consultor Técnico", processingTime: 60, yieldRate: 0.85 },
          { name: "Cálculo de Precificação e Margem", resource: "Diretor Comercial", processingTime: 30, yieldRate: 0.95 },
          { name: "Apresentação de Proposta Técnico-Comercial", resource: "Vendedor Avançado", processingTime: 45, yieldRate: 0.4 },
          { name: "Assinatura do Contrato de Serviços", resource: "Vendedor Avançado", processingTime: 20, yieldRate: 0.95 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Taxa de conversão de leads", target: "> 15%", unit: "% Comercial", frequency: "Mensal" },
      { name: "Tempo de entrega de proposta", target: "< 48h", unit: "horas corridas", frequency: "Semanal" },
      { name: "Margem de contribuição média", target: "> 35%", unit: "% Financeiro", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "Vendedor",
        activities: [
          { activityName: "Bater metas de prospecção fria", roleType: "R" },
          { activityName: "Aprovação de descontos extras", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Cancelamentos de contratos no primeiro mês (Churn Precoce)",
        impact: "alto",
        probability: "baixo",
        mitigation: "Garantir rito de Onboarding nas 3 primeiras semanas de contrato com pontos de contato estruturados."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Com qual frequência o escopo dos serviços contratados é desrespeitado durante a execução?",
        options: [
          { label: "Sempre executamos extras sem faturar (scope creep total)", score: 1 },
          { label: "Eventualmente temos desvios negociados de forma informal com o responsável", score: 3 },
          { label: "Raramente, as ordens de alteração de escopo são formalizadas e faturadas", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Padronização do Contrato Padrão", responsible: "Assessor Jurídico", duration: "1 semana", deliverable: "Acordo de Nível de Serviço (SLA) polido" }
    ]
  },
  retail: {
    id: "retail",
    name: "Comércio",
    icon: "ShoppingCart",
    description: "Otimização de giro de mercadorias, gestão rigorosa do estoque físico comercial e despacho rápido multicanal.",
    pains: [
      "Falta de produtos críticos na gôndola (Ruptura extrema de catálogo)",
      "Capital de giro imobilizado em itens com giro zero no depósito",
      "Perda de controle financeiro sobre fluxo de recebíveis das maquininhas",
      "Demora na conferência de recebimentos de cargas físicas de distribuidores"
    ],
    suggestedProcesses: [
      {
        name: "Reposição de Estoque Inteligente",
        description: "Processamento de pedidos de abastecimento conforme curva de vendas ABC/Estoque Mínimo de Segurança.",
        steps: [
          { name: "Cálculo de Curva ABC e Ponto de Pedido", resource: "Comprador Especialista", processingTime: 40, yieldRate: 0.98 },
          { name: "Cotação de Melhores Condições fornecedor", resource: "Comprador Especialista", processingTime: 90, yieldRate: 0.9 },
          { name: "Aprovação de Verba de Orçamento", resource: "Gerente Financeiro", processingTime: 15, yieldRate: 0.95 },
          { name: "Emissão Oficial de Ordem de Compra", resource: "Comprador Especialista", processingTime: 10, yieldRate: 1.0 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Taxa de Ruptura de Estoque", target: "< 3.0%", unit: "% do catálogo geral", frequency: "Semanal" },
      { name: "Giro de Estoque Anualizado", target: "> 6.5x", unit: "vezes por ano", frequency: "Mensal" },
      { name: "Acurácia de Inventário Rotativo", target: "> 98.5%", unit: "% de batimento físico", frequency: "Diário" }
    ],
    commonResponsibilities: [
      {
        role: "Gerente de Loja",
        activities: [
          { activityName: "Inventário Geral Físico Semanal", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Diferenças ocultas no inventário de mercadorias fisicamente",
        impact: "alto",
        probability: "alto",
        mitigation: "Instituir inventários rotativos diários (blind por amostragem) nos 10 SKUs de maior giro financeiro."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Como você sabe que é a hora exata de comprar mais estoque de um produto de alto giro?",
        options: [
          { label: "Visualmente, quando o armário ou prateleira física esvazia", score: 1 },
          { label: "Por sentimento ou sugestão periódica de representantes comerciais parceiros", score: 2 },
          { label: "Através de cálculos automáticos de Ponto de Pedido baseados no ERP ativo", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Categorização Completa Curva ABC de Estoque", responsible: "Analista de PCP", duration: "1 semana", deliverable: "Lista de prioridade de compras prioritária" }
    ]
  },
  healthcare: {
    id: "healthcare",
    name: "Clínica ou Saúde",
    icon: "Heart",
    description: "Gestão orientada à jornada assistencial do paciente, segurança na manipulação e minimização máxima do absenteísmo de consultas.",
    pains: [
      "No-show elevado de pacientes que confirmação e não comparecem à seção",
      "Prontuários e fichas não preenchidos de forma adequada pelo corpo médico",
      "Glosa hospitalar alta de exames por guias rejeitadas por convênios",
      "Filas de espera desconfortáveis para check-in inicial recepção"
    ],
    suggestedProcesses: [
      {
        name: "Confirmação e Triagem Atendimento",
        description: "Processo para reduzir faltas programando confirmações em múltiplos canais e triando dados essenciais.",
        steps: [
          { name: "Automated Disparos Mensagem Confirmação", resource: "Recepcionista", processingTime: 5, yieldRate: 0.9 },
          { name: "Re-alocação Ativa de Horários Vagos", resource: "Recepcionista", processingTime: 15, yieldRate: 0.8 },
          { name: "Check-in Cadastral e Conferência Convênio", resource: "Recepcionista", processingTime: 10, yieldRate: 0.94 },
          { name: "Direcionamento Médico / Triagem Meds", resource: "Enfermeiro Supervisor", processingTime: 12, yieldRate: 0.99 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Taxa de No-Show (Absenteísmo)", target: "< 8.0%", unit: "% de agendamentos", frequency: "Diário" },
      { name: "Lead Time de Espera na recepção", target: "< 15 min", unit: "minutos corrido", frequency: "Semanal" },
      { name: "Glosa de faturamento de guias", target: "< 1.5%", unit: "% financeiro", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "Médico Diretor",
        activities: [
          { activityName: "Auditoria Científica Interna de Finais Clin", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Prontuário preenchido incorretamente / Falta de assinatura",
        impact: "alto",
        probability: "medio",
        mitigation: "Travar sistemas de faturamento para requerer assinatura médica sob autenticação forte imediata."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Qual mecanismo é usado atualmente para lembrar os pacientes de suas consultas agendadas?",
        options: [
          { label: "Não ligamos ou realizamos contatos sistemáticos preventivos", score: 1 },
          { label: "Ligamos manualmente na tarde do dia útil anterior", score: 3 },
          { label: "Régua Omnichannel integrada com WhatsApp automático de duplo fator", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Mapeamento do Tempo de Espera da Jornada", responsible: "Diretor Clínico", duration: "2 semanas", deliverable: "Diagnóstico visual de afunilamento de checkin" }
    ]
  },
  logistics: {
    id: "logistics",
    name: "Logística",
    icon: "Truck",
    description: "Processamento ultra ágil de expedição, cross-docking, roteirização otimizada e entrega de última milha (Last-Mile).",
    pains: [
      "Atrasos sistemáticos nas saídas de frotas de distribuição",
      "Erros crônicos de separação no picking de caixas (troca de pedidos)",
      "Alto custo com fretes de retorno ou devoluções não programadas",
      "Avaria física de mercadorias no manuseio de empilhadeiras em pátio"
    ],
    suggestedProcesses: [
      {
        name: "Picking e Expedição Integrada",
        description: "Processo de separação de mercadorias fisicamente baseada no romaneio, envelopamento e emissão CTE/NFE rápida.",
        steps: [
          { name: "Agrupamento de Pedidos no Sistema WMS", resource: "Analista de Tráfego", processingTime: 10, yieldRate: 0.99 },
          { name: "Separação Física e Código de Barras", resource: "Operador de Picking", processingTime: 25, yieldRate: 0.94 },
          { name: "Conferência por Peso Eletrônico", resource: "Conferente Técnico", processingTime: 8, yieldRate: 0.97 },
          { name: "Emissão Automática NFE e Etiquetagem", resource: "Assistente de Expedição", processingTime: 5, yieldRate: 1.0 },
          { name: "Carregamento das Doca de Saída", resource: "Operador de Pátio", processingTime: 15, yieldRate: 0.98 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "OTIF (On-Time In-Full Delivery)", target: "> 97.5%", unit: "% de eficiência logística", frequency: "Semanal" },
      { name: "Tempo médio de carregamento de doca", target: "< 45 min", unit: "por caminhão", frequency: "Diário" },
      { name: "Acurácia de Picking", target: "> 99.8%", unit: "% de itens separados sem erro", frequency: "Semanal" }
    ],
    commonResponsibilities: [
      {
        role: "Supervisor de Logística",
        activities: [
          { activityName: "Aprovação de Rotas de Carregamento", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Roteiro ineficiente gerando gasto excedente de combustível",
        impact: "alto",
        probability: "alto",
        mitigation: "Utilizar algoritmos modernos do Google Maps API ou roteirizadores profissionais para travar cubagem."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Como é feita a conferência final dos pacotes antes do embarque nos caminhões?",
        options: [
          { label: "No olho, confiando estritamente na memória e boa vontade do carregador", score: 1 },
          { label: "Misto, checando romaneios impressos com caneta marca texto lentamente", score: 3 },
          { label: "Totalmente automatizado por códigos de barra bidimensional ou RFID", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Implantação de Inventário Fino de Picking", responsible: "Consultor Lean Logistics", duration: "3 semanas", deliverable: "Novo layout de separação por calor ABC" }
    ]
  },
  technology: {
    id: "technology",
    name: "Tecnologia",
    icon: "Cpu",
    description: "Foco no ciclo de desenvolvimento seguro, entrega contínua (CI/CD), suporte a incidentes (ITIL) e escalabilidade ágil.",
    pains: [
      "Bugs recorrentes escapando para ambiente de produção (falha de QA)",
      "Retrabalho por definições de requisito incompletas / voláteis",
      "Prazo estourado para deploy de novos relatórios contratuais",
      "Incidentes de queda de cloud ou instabilidade de banco ocultas"
    ],
    suggestedProcesses: [
      {
        name: "Ciclo de Entrega de Feature / Bugfix",
        description: "Estágios ágeis desde a escrita do teste de aceitação até o deploy produtivo automatizado por pipelines.",
        steps: [
          { name: "Refinamento Técnico & Escrita de Critérios", resource: "Product Owner / PM", processingTime: 50, yieldRate: 0.9 },
          { name: "Desenvolvimento e Código Limpo", resource: "Engenheiro Sênior", processingTime: 120, yieldRate: 0.95 },
          { name: "Validação Automática CI (Linter/Tests)", resource: "Máquina de Pipeline", processingTime: 10, yieldRate: 0.98 },
          { name: "Revisão por Par (Code Review)", resource: "Engenheiro Principal", processingTime: 30, yieldRate: 0.88 },
          { name: "QA Funcional em Sandbox/Homolog", resource: "Analista de Testes QA", processingTime: 40, yieldRate: 0.92 },
          { name: "Deploy Automatizado em Prod", resource: "Engenheiro de DevOps", processingTime: 5, yieldRate: 0.99 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Fuga de defeitos para Prod (Escape Rate)", target: "< 1.5%", unit: "% de bugs escapados", frequency: "Qualquer release" },
      { name: "Lead Time de entrega (De ideia à Prod)", target: "< 10 dias", unit: "dias corridos", frequency: "Mensal" },
      { name: "Tempo de Recuperação de Bugs (MTTR)", target: "< 60 min", unit: "minutos de interrupção", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "CTO / Head de Tecnologia",
        activities: [
          { activityName: "Aprovação de Orçamento Cloud AWS/GCP", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Vazamento de dados ou credencial de API exposta publicamente",
        impact: "alto",
        probability: "baixo",
        mitigation: "Configurar secrets automatizados e habilitar Varreduras semestrais de integridade no repositório GitHub."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Quanto tempo depois de finalizada a feature ela de fato chega nas mãos do seu usuário final?",
        options: [
          { label: "Mais de 30 dias por conta de aprovações mecânicas em comitês morosos", score: 1 },
          { label: "Entre 7 e 15 dias, dependendo de rituais semanais de lançamento planejado", score: 3 },
          { label: "Menos de 24 horas graças a pipelines robustas de entrega contínua CI/CD", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Mapeamento de Desperdício de Desenvolvimento", responsible: "Agilista de TI", duration: "1 semana", deliverable: "Estudo de gargalos de Code Review" }
    ]
  },
  consulting: {
    id: "consulting",
    name: "Consultoria",
    icon: "Compass",
    description: "Entrega intelectual de alto valor baseado em diagnósticos apurados, pesquisas sob demanda e relatórios focados.",
    pains: [
      "Consultores gastam mais de 40% das horas úteis formatando slides",
      "Perda de histórico de evidências colhidas in-loco nas visitas",
      "Clientes reclamam que o andamento do projeto é invisível ou turvo",
      "Precipitação na recomendação de remédios de negócio sem dados"
    ],
    suggestedProcesses: [
      {
        name: "Ritual de Entrega e Diagnóstico Inicial",
        description: "Processamento estruturado que liga o kick-off até a entrega do relatório executivo validado no comitê.",
        steps: [
          { name: "Kickoff e Alinhamento de Expectativas", resource: "Diretor Associado", processingTime: 40, yieldRate: 1.0 },
          { name: "Entrevistas Profundas com a equipe chave", resource: "Consultor Pleno", processingTime: 90, yieldRate: 0.95 },
          { name: "Coleta Técnica de Dados Quantitativos", resource: "Consultor Júnior", processingTime: 120, yieldRate: 0.88 },
          { name: "Modelagem Científica e Análise de Valor", resource: "Consultor Pleno", processingTime: 180, yieldRate: 0.95 },
          { name: "Consolidação e Revisão da Apresentação", resource: "Diretor Associado", processingTime: 60, yieldRate: 0.92 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "NPS do cliente no fechamento do rito", target: "> 85 pontos", unit: "Score NPS", frequency: "Qualquer projeto" },
      { name: "Acurácia de Estimativa de Horas", target: "> 90%", unit: "% do orçado vs realizado", frequency: "Semanal" },
      { name: "Tempo de Elaboração de Artefatos", target: "< 15h", unit: "horas úteis acumuladas", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "Sócio Sênior",
        activities: [
          { activityName: "Aprovação de Propostas de Renovação Comercial", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Desalinhamento de expectativas do cliente no fechamento",
        impact: "alto",
        probability: "medio",
        mitigation: "Garantir ritos semanais rápidos de alinhamento com minutas formais e entregáveis visuais parciais."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Como você garante que toda a equipe de consultoria segue a mesma metodologia de análise rígida?",
        options: [
          { label: "Não há padrão, cada profissional aplica suas experiências passadas", score: 1 },
          { label: "Temos um manual PDF de 2018 salvo em alguma pasta compartilhada da Nuvem", score: 3 },
          { label: "Seguimos playbooks digitais amarrados com checklists estritos de validação", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Digitalização de Playbooks Operacionais", responsible: "Gerente de Negócios", duration: "2 semanas", deliverable: "Manual de análise consolidado no workspace" }
    ]
  },
  admin_operations: {
    id: "admin_operations",
    name: "Operação Administrativa",
    icon: "Sliders",
    description: "Padronização de fluxo de contas a pagar, emissão de reembolsos, compras de suprimentos internos e compliance corporativo.",
    pains: [
      "Atrasos nos reembolsos de despesas provocando descontentamento do time",
      "Erros no preenchimento de notas fiscais nas ordens de faturamento",
      "Excesso de burocracia e assinaturas físicas para compras de baixo custo",
      "Falta de controle centralizado de vencimento de licenças e certificados"
    ],
    suggestedProcesses: [
      {
        name: "Processamento de Reembolso de Despesas",
        description: "Processo que vai da digitalização de comprovantes fiscais pelo colaborador até a conciliação e pagamento definitivo.",
        steps: [
          { name: "Digitalização e Submissão do Recibo", resource: "Colaborador Solicitante", processingTime: 10, yieldRate: 0.9 },
          { name: "Auditoria Fiscal de Recibo & Compliance", resource: "Analista de Controller", processingTime: 15, yieldRate: 0.85 },
          { name: "Aprovação Hierárquica Baseada em Quotas", resource: "Gerente da Área", processingTime: 5, yieldRate: 0.98 },
          { name: "Lançamento no Contas a Pagar e Pix", resource: "Assistente de Tesouraria", processingTime: 8, yieldRate: 0.99 },
          { name: "Conciliação Bancária com Extratos", resource: "Gerente Financeiro", processingTime: 10, yieldRate: 1.0 }
        ]
      }
    ],
    suggestedMetrics: [
      { name: "Lead time de ressarcimento Pix", target: "< 72h", unit: "horas corridas", frequency: "Semanal" },
      { name: "Eficiência de auditoria (sem retrabalho)", target: "> 95.0%", unit: "% de recibos sem erro", frequency: "Mensal" },
      { name: "Margem de desvio orçamentário real", target: "< 1.0%", unit: "% de divergência financeira", frequency: "Mensal" }
    ],
    commonResponsibilities: [
      {
        role: "Gerente Administrativo",
        activities: [
          { activityName: "Auditoria de Fechamento Contábil Trimestral", roleType: "A" }
        ]
      }
    ],
    commonRisks: [
      {
        event: "Erro de digitação de Chave Pix em lançamento manual no banco",
        impact: "alto",
        probability: "medio",
        mitigation: "Gerar remessa bancária automatizada CNAB240 pelo sistema ERP para evitar inserções manuais do Pix."
      }
    ],
    diagnosticQuestions: [
      {
        text: "Como as requisições de compras de suprimentos de baixo valor (ex: papelaria) são autorizadas?",
        options: [
          { label: "Exigem papel impresso assinado fisicamente pelo CEO pessoalmente", score: 1 },
          { label: "Misto, por mensagens de WhatsApp ou e-mails formais esparsos", score: 3 },
          { label: "Através de matriz flexível de teto de responsabilidade autorizada no sistema", score: 5 }
        ]
      }
    ],
    initialPlan: [
      { stepName: "Padronização da Política de Reembolsos", responsible: "Diretor Administrativo", duration: "1 semana", deliverable: "Portaria normativa homologada" }
    ]
  }
};
