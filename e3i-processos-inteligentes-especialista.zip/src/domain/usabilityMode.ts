export type UsabilityMode = "SIMPLE" | "EXPERT" | "L0_ONBOARDING" | "L1_SIMPLE" | "L2_ASSISTED" | "L3_ADVANCED" | "L4_ADMIN";

export type UxLayerId = "L0" | "L1" | "L2" | "L3" | "L4";

export interface UxLayerInfo {
  id: UxLayerId;
  name: string;
  badge: string;
  targetUser: string;
  description: string;
  icon: string;
}

export const UX_LAYERS: Record<UxLayerId, UxLayerInfo> = {
  L0: {
    id: "L0",
    name: "Camada 0 — Onboarding & Guias",
    badge: "Início",
    targetUser: "Novos Usuários",
    description: "Apresentação guiada, cenários demonstrativos e primeiro fluxo passo a passo.",
    icon: "🚀"
  },
  L1: {
    id: "L1",
    name: "Camada 1 — Operação Simples",
    badge: "Iniciante",
    targetUser: "Dono de Negócio / Leigo",
    description: "Visão limpa com os indicadores principais, tarefas diretas e busca inteligente sem jargões.",
    icon: "🌱"
  },
  L2: {
    id: "L2",
    name: "Camada 2 — Operação Assistida",
    badge: "Intermediário",
    targetUser: "Gestor de Operações",
    description: "Dashboards personalizados, filtros, histórico e recomendações automáticas geradas por IA.",
    icon: "💡"
  },
  L3: {
    id: "L3",
    name: "Camada 3 — Operação Avançada",
    badge: "Especialista",
    targetUser: "Black Belt / Consultor LSS",
    description: "Estatística SPC avançada, Monte Carlo, fórmulas, parametrização e mapeamento técnico.",
    icon: "⚡"
  },
  L4: {
    id: "L4",
    name: "Camada 4 — Administração",
    badge: "Admin",
    targetUser: "Administrador do Sistema",
    description: "Gestão de acessos, logs de auditoria, integrações globais e segurança da plataforma.",
    icon: "🛡️"
  }
};

export const usabilityModeLabels: Record<string, { title: string; subtitle: string; icon: string }> = {
  SIMPLE: {
    title: "Modo Simples (Dono de Negócio / Leigo)",
    subtitle: "Orientação intuitiva por passos simples, sem jargões e focada em resultados práticos.",
    icon: "🌱"
  },
  EXPERT: {
    title: "Modo Especialista (Consultor / Black Belt)",
    subtitle: "Profundidade técnica total: fórmulas, diagramas formais, parametrizações e auditoria.",
    icon: "🎓"
  },
  L0_ONBOARDING: {
    title: UX_LAYERS.L0.name,
    subtitle: UX_LAYERS.L0.description,
    icon: UX_LAYERS.L0.icon
  },
  L1_SIMPLE: {
    title: UX_LAYERS.L1.name,
    subtitle: UX_LAYERS.L1.description,
    icon: UX_LAYERS.L1.icon
  },
  L2_ASSISTED: {
    title: UX_LAYERS.L2.name,
    subtitle: UX_LAYERS.L2.description,
    icon: UX_LAYERS.L2.icon
  },
  L3_ADVANCED: {
    title: UX_LAYERS.L3.name,
    subtitle: UX_LAYERS.L3.description,
    icon: UX_LAYERS.L3.icon
  },
  L4_ADMIN: {
    title: UX_LAYERS.L4.name,
    subtitle: UX_LAYERS.L4.description,
    icon: UX_LAYERS.L4.icon
  }
};

export function getLayerFromMode(mode: UsabilityMode | string): UxLayerId {
  const normalized = String(mode).toUpperCase();
  if (normalized.includes("L0") || normalized.includes("ONBOARDING")) return "L0";
  if (normalized.includes("L1") || normalized === "SIMPLE" || normalized === "LEIGO") return "L1";
  if (normalized.includes("L2") || normalized.includes("ASSISTED")) return "L2";
  if (normalized.includes("L3") || normalized === "EXPERT" || normalized === "ESPECIALISTA") return "L3";
  if (normalized.includes("L4") || normalized.includes("ADMIN")) return "L4";
  return "L1";
}

export function isSimpleMode(mode: UsabilityMode | string): boolean {
  const layer = getLayerFromMode(mode);
  return layer === "L0" || layer === "L1" || layer === "L2";
}

export function isExpertMode(mode: UsabilityMode | string): boolean {
  const layer = getLayerFromMode(mode);
  return layer === "L3" || layer === "L4";
}

export function normalizeUsabilityMode(mode: any): UsabilityMode {
  if (!mode) return "SIMPLE";
  
  const upper = String(mode).toUpperCase();
  if (upper === "L0_ONBOARDING" || upper === "L0") return "L0_ONBOARDING";
  if (upper === "L1_SIMPLE" || upper === "L1") return "L1_SIMPLE";
  if (upper === "L2_ASSISTED" || upper === "L2") return "L2_ASSISTED";
  if (upper === "L3_ADVANCED" || upper === "L3") return "L3_ADVANCED";
  if (upper === "L4_ADMIN" || upper === "L4") return "L4_ADMIN";
  if (upper === "LAYPERSON" || upper === "SIMPLE" || upper === "LEIGO") return "SIMPLE";
  if (upper === "PROFESSIONAL" || upper === "EXPERT" || upper === "ESPECIALISTA") return "EXPERT";
  
  return "SIMPLE";
}

