import { UsabilityMode, isSimpleMode, isExpertMode } from "../usabilityMode";

export interface NextBestAction {
  id: string;
  titleSimple: string;
  titleTechnical: string;
  reasonSimple: string;
  reasonTechnical: string;
  impactSimple: string;
  impactTechnical: string;
  effort: "BAIXO" | "MÉDIO" | "ALTO";
  priority: "CRÍTICA" | "ALTA" | "MÉDIA";
  suggestedModule: string;
  targetStepId: "diagnostico" | "estrategia" | "estrutura" | "processos" | "governanca" | "mudanca" | "execucao" | "resultados";
  actionLabel: string;
}

// Preset catalog of Next Best Actions based on weak links
export const nextBestActionCatalog: NextBestAction[] = [
  {
    id: "nba_raci",
    titleSimple: "Definir responsáveis (Donos) para os Processos",
    titleTechnical: "Estabelecer Matriz de Responsabilidades RACI",
    reasonSimple: "Há conflito de autoridade e tarefas caindo no esquecimento entre as áreas operacionais.",
    reasonTechnical: "Desalinhamento severo de governança (Organizational Structure) gerando duplicação de ordens ou lacunas de supervisão.",
    impactSimple: "Reduzir fofocas, discussões, retrabalho e o famoso 'jogo de empurra' nas entregas.",
    impactTechnical: "Garantir responsabilização individual formalizada (Accountability) e transparência em etapas críticas do fluxo de valor.",
    effort: "BAIXO",
    priority: "CRÍTICA",
    suggestedModule: "Estrutura Organizacional",
    targetStepId: "estrutura",
    actionLabel: "Desenhar Matriz RACI"
  },
  {
    id: "nba_process_mapping",
    titleSimple: "Mapear de forma visual os Processos Críticos",
    titleTechnical: "Modelagem e Cadeia de Processos AS-IS (BPMN)",
    reasonSimple: "Cada funcionário executa tarefas à sua própria maneira, causando perdas de tempo e erros frequentes.",
    reasonTechnical: "Dependência absoluta do heroísmo humano devido à falta de padronização estruturada de processos (Operational Systems).",
    impactSimple: "Garantir a mesma qualidade no produto ou serviço final sem depender de monitoramento do dono.",
    impactTechnical: "Redução do Lead Time produtivo e eliminação sistemática de retrabalhos por padronização técnica de procedimentos (BPMN).",
    effort: "MÉDIO",
    priority: "CRÍTICA",
    suggestedModule: "Modelagem de Processos",
    targetStepId: "processos",
    actionLabel: "Mapear Fluxo AS-IS"
  },
  {
    id: "nba_kpis",
    titleSimple: "Criar Indicadores Práticos para as Áreas",
    titleTechnical: "Painel de Performance Gerencial (KPIs)",
    reasonSimple: "A diretoria toma decisões baseadas em palpites e impressões, sem saber o faturamento correto em tempo real.",
    reasonTechnical: "Falta de sensores de feedback operacional (Performance Measurements), impossibilitando o acompanhamento tático de conversão.",
    impactSimple: "Parar de agir no achismo, conseguindo identificar desvios financeiros antes que o caixa fique no vermelho.",
    impactTechnical: "Habilitar governança corporativa orientada a dados (Data-Driven Decisions) e provisionamento confiável de metas estruturadas.",
    effort: "MÉDIO",
    priority: "ALTA",
    suggestedModule: "Resultados & Indicadores",
    targetStepId: "resultados",
    actionLabel: "Definir Métricas KPIs"
  },
  {
    id: "nba_daily_sync",
    titleSimple: "Instituir Reuniões Curtas de Alinhamento",
    titleTechnical: "Sincronização de Rotina & Governança (Daily Reviews)",
    reasonSimple: "Várias pendências demoram semanas para serem resolvidas porque os gerentes nunca conversam de forma ágil.",
    reasonTechnical: "Inexistência de rituais periódicos de governança diária (Management Style), gerando dessincronização operacional contínua.",
    impactSimple: "Resolver gargalos no mesmo dia em reuniões de apenas 15 minutos com o time focado no plano.",
    impactTechnical: "Aceleração do fluxo de decisões operacionais e estabelecimento de rotinas estruturadas de mitigação de anomalias.",
    effort: "BAIXO",
    priority: "MÉDIA",
    suggestedModule: "Processos & Governança",
    targetStepId: "governanca",
    actionLabel: "Iniciar Reuniões de Sincronia"
  },
  {
    id: "nba_strategy_okrs",
    titleSimple: "Desdobrar Objetivos Gerais em Metas Práticas",
    titleTechnical: "Desdobramento Estratégico Orientado a OKRs",
    reasonSimple: "A equipe faz as tarefas diárias sem entender como isso ajuda no crescimento da empresa no ano.",
    reasonTechnical: "Falta de conexão e alinhamento vertical entre a visão da diretoria (Strategy) e as tarefas rotineiras do chão de fábrica.",
    impactSimple: "Engajar o time em desafios claros que impulsionam o lucro do negócio de forma coordenada.",
    impactTechnical: "Aumentar a taxa de sucesso estratégico por meio da tradução ágil de objetivos centrais em alvos numéricos semanais.",
    effort: "ALTO",
    priority: "ALTA",
    suggestedModule: "Estratégia & OKRs",
    targetStepId: "estrategia",
    actionLabel: "Formular OKRs"
  }
];

/**
 * Next Best Action Recommendation Engine
 * Dynamically decides the single absolute best recommendation based on current survey maturity scores
 */
export function getRecommendedNextBestAction(
  scores?: Record<string, number>
): NextBestAction {
  if (!scores) {
    return nextBestActionCatalog[0]; // fallback default is responsibilities
  }

  // Find the lowest score categories
  const s_estrutura = scores["estrutura"] ?? 5;
  const s_processos = scores["sistemas"] ?? scores["processos"] ?? 5; // compatible with both surveys
  const s_indicadores = scores["indicadores"] ?? 5;
  const s_governanca = scores["governanca"] ?? scores["lideranca"] ?? 5;
  const s_estrategia = scores["estrategia"] ?? 5;

  // Decision logic hierarchy (first solve critical structural gaps)
  if (s_estrutura < 2.5) {
    return nextBestActionCatalog.find(n => n.id === "nba_raci") || nextBestActionCatalog[0];
  }
  if (s_processos < 2.5) {
    return nextBestActionCatalog.find(n => n.id === "nba_process_mapping") || nextBestActionCatalog[1];
  }
  if (s_indicadores < 2.5) {
    return nextBestActionCatalog.find(n => n.id === "nba_kpis") || nextBestActionCatalog[2];
  }
  if (s_governanca < 2.5) {
    return nextBestActionCatalog.find(n => n.id === "nba_daily_sync") || nextBestActionCatalog[3];
  }
  if (s_estrategia < 3.0) {
    return nextBestActionCatalog.find(n => n.id === "nba_strategy_okrs") || nextBestActionCatalog[4];
  }

  // General fallback if all scores are very solid
  return nextBestActionCatalog[1]; // mapping process for fine tuning
}
