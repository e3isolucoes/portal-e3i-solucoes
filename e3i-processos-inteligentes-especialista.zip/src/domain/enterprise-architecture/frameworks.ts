export interface Framework {
  id: string;
  name: string;
  objective: string;
  recommendedAudience: "Simple" | "Specialist" | "Both";
  journeyPhase: "Diagnóstico" | "Estratégia" | "Estrutura" | "Processos" | "Governança" | "Mudança" | "Execução" | "Resultados";
  descriptionSimple: string;
  descriptionTechnical: string;
}

export const frameworks: Framework[] = [
  {
    id: "mckinsey_7s",
    name: "McKinsey 7S",
    objective: "Avaliar o alinhamento interno da organização entre 7 fatores críticos.",
    recommendedAudience: "Specialist",
    journeyPhase: "Diagnóstico",
    descriptionSimple: "Um diagnóstico para ver se todos os pontos da empresa (estratégia, estrutura, equipe, habilidades, sistemas, estilo de liderança e valores) estão puxando o barco para o mesmo lado.",
    descriptionTechnical: "Modelo analítico que postula que a eficácia organizacional repousa na congruência de sete elementos: Strategy, Structure, Systems (duros) e Shared Values, Style, Staff, Skills (moles)."
  },
  {
    id: "bsc",
    name: "Balanced Scorecard (BSC)",
    objective: "Traduzir a estratégia de longo prazo em objetivos e metas balanceadas em 4 perspectivas.",
    recommendedAudience: "Specialist",
    journeyPhase: "Estratégia",
    descriptionSimple: "Um mapa visual que organiza seus objetivos em quatro áreas: como está o financeiro, como os clientes nos veem, se nossos processos internos são bons e como nossa equipe aprende e cresce.",
    descriptionTechnical: "Metodologia de gestão de desempenho estratégico que estabelece objetivos, indicadores, metas e iniciativas sob quatro perspectivas fundamentais: Financeira, Clientes, Processos Internos e Aprendizado & Crescimento."
  },
  {
    id: "okr",
    name: "Objectives and Key Results (OKR)",
    objective: "Alinhar e engajar toda a empresa em torno de metas trimestrais ambiciosas e mensuráveis.",
    recommendedAudience: "Both",
    journeyPhase: "Estratégia",
    descriptionSimple: "Um jeito simples de definir 'Aonde queremos chegar' (Objetivos) e 'Como mediremos que estamos no caminho certo de fato' (Resultados Chave) a cada três meses.",
    descriptionTechnical: "Framework de metas ágeis focado em cadências curtas (trimestrais), com transparência radical e alinhamento bidirecional. Objetivos qualitativos desdobrados em resultados-chave quantitativos e mensuráveis."
  },
  {
    id: "raci",
    name: "Matriz de Responsabilidade RACI",
    objective: "Atribuir com precisão os papéis de quem executa, quem aprova, quem é consultado e quem é informado em cada tarefa.",
    recommendedAudience: "Both",
    journeyPhase: "Estrutura",
    descriptionSimple: "Um quadro que deixa claro: quem faz o trabalho (Executa), quem dá o veredito final (Aprova), quem dá conselhos (Consultado) e quem só precisa ver o resultado final (Informado).",
    descriptionTechnical: "Matriz de atribuição linear de responsabilidades aplicada à governança de projetos ou processos operacionais, segmentada nas siglas: R (Responsible/Executor), A (Accountable/Aprovador), C (Consulted/Consultado) e I (Informed/Informado)."
  },
  {
    id: "sipoc",
    name: "Mapeamento SIPOC",
    objective: "Ter uma visão macro de alto nível do fluxo de valor de um processo antes do detalhamento.",
    recommendedAudience: "Both",
    journeyPhase: "Processos",
    descriptionSimple: "Um mapa rápido de 5 passos para entender: Quem fornece as coisas (Supplier), qual é a matéria-prima (Input), o que o processo faz (Process), o que sai feito (Output) e quem recebe a entrega final (Customer).",
    descriptionTechnical: "Ferramenta clássica da qualidade Six Sigma para visão panorâmica e controle fronteiriço de processos de negócio, mapeando Suppliers (Fornecedores), Inputs (Entradas), Process (Processo macro), Outputs (Saídas) e Customers (Clientes)."
  },
  {
    id: "vsm",
    name: "Value Stream Mapping (VSM)",
    objective: "Mapear o fluxo de valor identificando desperdícios, tempos de espera e tempos de agregação de valor.",
    recommendedAudience: "Specialist",
    journeyPhase: "Processos",
    descriptionSimple: "Uma linha do tempo detalhada que mostra todo o caminho que o produto ou serviço percorre, separando as etapas úteis das etapas onde o processo fica parado, gerando custos sem acrescentar valor para o cliente.",
    descriptionTechnical: "Mapeamento do Fluxo de Valor voltado à mentalidade Lean, servindo para quantificar de ponta a ponta o lead time produtivo, o tempo de processamento e a taxa de valor agregado, identificando estoques intermediários e gargalos operacionais."
  },
  {
    id: "bpmn",
    name: "Notation BPMN",
    objective: "Mapear processos rascunhados de maneira formal e padronizada internacionalmente para automação ou otimização.",
    recommendedAudience: "Specialist",
    journeyPhase: "Processos",
    descriptionSimple: "A linguagem profissional de desenho de processos do mundo B2B, usando ícones específicos de início, fim, decisões e caminhos paralelos que qualquer analista técnico entende globalmente.",
    descriptionTechnical: "Business Process Model and Notation. Padrão formal da OMG para representação lógica e fluxos de dados de processos corporativos corporificados em raias, piscinas, gate-ways lógicos (AND/OR/XOR), atividades e disparadores de eventos."
  },
  {
    id: "lean",
    name: "Filosofia Lean",
    objective: "Eliminar desperdícios sistemáticos e aumentar a produtividade operacional.",
    recommendedAudience: "Both",
    journeyPhase: "Processos",
    descriptionSimple: "O pensamento focado em 'fazer mais com menos', reduzindo burocracias, erros, excesso de estoques e movimentações inúteis, acelerando de forma enxuta a entrega real ao cliente.",
    descriptionTechnical: "Modelo sociotécnico de manufatura e serviços originário do Sistema Toyota de Produção, sustentado na eliminação contínua de desperdícios (muda), redução de variabilidade (mura) e sobrecarga (muri)."
  },
  {
    id: "fmea",
    name: "Matriz FMEA",
    objective: "Identificar falhas potenciais de processos antes que aconteçam, priorizando-as por risco real.",
    recommendedAudience: "Specialist",
    journeyPhase: "Governança",
    descriptionSimple: "Uma avaliação de segurança onde você anota o que pode dar errado no seu negócio, qual a gravidade disso acontecer, a chance de ocorrer e se você consegue detectar antes. Gera um índice de risco para você agir preventivamente.",
    descriptionTechnical: "Failure Mode and Effects Analysis (Análise de Modos de Falha e Seus Efeitos). Metodologia analítica estruturada que calcula o Índice de Prioridade de Risco (RPN) baseado no produto aritmético de três dimensões: Severidade (S), Ocorrência (O) e Detecção (D)."
  },
  {
    id: "kotter",
    name: "Modelo de Mudança de Kotter",
    objective: "Conduzir a organização por 8 passos essenciais para aprovar, implementar e sustentar uma mudança profunda de cultura.",
    recommendedAudience: "Specialist",
    journeyPhase: "Mudança",
    descriptionSimple: "Um guia de 8 passos para gerenciar o sentimento das pessoas durante reformas na empresa: como criar senso de urgência, juntar uma equipe aliada, planejar vitórias rápidas e enraizar o novo modo de trabalhar no cotidiano.",
    descriptionTechnical: "Framework de gestão de mudança organizacional baseado em 8 etapas fundamentais: estabelecer urgência, formar coalizão, criar visão de mudança, comunicar visão, empoderar ação, gerar ganhos de curto prazo, consolidar ganhos e institucionalizar abordagens."
  },
  {
    id: "adkar",
    name: "Modelo ADKAR",
    objective: "Facilitar a transição focando no processo de mudança individual de cada colaborador.",
    recommendedAudience: "Specialist",
    journeyPhase: "Mudança",
    descriptionSimple: "Um método que lembra que a empresa só muda se cada colaborador mudar individualmente. Ele avalia se a pessoa entende por que precisa mudar (Awareness), quer mudar (Desire), sabe como fazer (Knowledge), consegue colocar em prática (Ability) e se é incentivada a continuar (Reinforcement).",
    descriptionTechnical: "Modelo de mudança individualizado criado pela Prosci, estruturado no acrônimo: Awareness (Consciência da necessidade de mudar), Desire (Desejo de apoiar a mudança), Knowledge (Conhecimento operacional), Ability (Habilidade de demonstrar competência) e Reinforcement (Reforço para fixar)."
  },
  {
    id: "kanban",
    name: "Quadro Kanban",
    objective: "Visualizar o fluxo de trabalho diário de forma lúdica evitando congestionamento de tarefas pendentes.",
    recommendedAudience: "Both",
    journeyPhase: "Execução",
    descriptionSimple: "O famoso quadro de cartões divididos em 'A fazer', 'Em execução' e 'Concluído'. Ajuda a limitar o tanto de trabalho que você começa ao mesmo tempo sem terminar o anterior primeiro.",
    descriptionTechnical: "Sistema de controle de produção puxada e gestão ágil baseado em cartões visuais para controlar e sinalizar o fluxo produtivo de conhecimento. Orientado a otimizar o Lead Time e o Throughput limitando o Trabalho em Progresso (WIP)."
  },
  {
    id: "5w2h",
    name: "Plano de Ação 5W2H",
    objective: "Criar um plano de ação robusto, respondendo 7 perguntas elementares para evitar brechas.",
    recommendedAudience: "Both",
    journeyPhase: "Execução",
    descriptionSimple: "O checklist definitivo que tira qualquer ideia do papel de forma clara respondendo: O que será feito, por que, quem fará, onde, quando, como e quanto custará.",
    descriptionTechnical: "Diretriz metodológica para formulação de plano de ação tático-operacional estruturado em sete variáveis: What (O que), Why (Por que), Who (Quem), Where (Onde), When (Quando), How (Como) e How Much (Quanto custa)."
  },
  {
    id: "roi",
    name: "Análise de ROI",
    objective: "Avaliar o ganho financeiro líquido sobre os custos incorridos nos projetos de reorganização.",
    recommendedAudience: "Both",
    journeyPhase: "Resultados",
    descriptionSimple: "A conta matemática fundamental: quanto dinheiro o seu projeto de melhoria vai trazer de lucro líquido comparado ao investimento financeiro que você fez para colocá-lo de pé.",
    descriptionTechnical: "Return on Investment (Retorno sobre o Investimento). Métrica financeira de eficiência alocativa calculada como a razão entre o ganho financeiro líquido (Retorno do Investimento - Custo do Investimento) e o Custo do Investimento."
  }
];
