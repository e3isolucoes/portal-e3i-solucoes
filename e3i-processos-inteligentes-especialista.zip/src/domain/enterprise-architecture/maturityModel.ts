export interface MaturityLevel {
  level: number;
  label: string;
  descriptionSimple: string;
  descriptionTechnical: string;
  keyCharacteristics: string[];
}

export const maturityLevels: MaturityLevel[] = [
  {
    level: 0,
    label: "Inexistente",
    descriptionSimple: "A empresa faz as coisas sem qualquer ordem, dependendo apenas do heroísmo individual no dia a dia.",
    descriptionTechnical: "Ausência formal e informal de processos e controles sistematizados. Reatividade máxima e extrema dependência de iniciativas ad-hoc sem previsibilidade.",
    keyCharacteristics: [
      "Processos não mapeados e sem padronização.",
      "As decisões de negócio ocorrem integralmente fora de dados ou métodos planejados.",
      "As saídas e entregas são altamente instáveis e imprevisíveis."
    ]
  },
  {
    level: 1,
    label: "Informal (Ad-hoc)",
    descriptionSimple: "As tarefas são executadas com hábitos estabelecidos mas de cabeça, sem documentação oficial.",
    descriptionTechnical: "Práticas operacionais informais executadas de maneira pessoal. O conhecimento está centralizado nas mentes de indivíduos chaves, correndo sério risco de fuga de inteligência.",
    keyCharacteristics: [
      "Conhecimento operacional exclusivamente implícito e centralizado.",
      "Ausência de planos estruturados ou metas formais integradas.",
      "Qualidade das entregas depende de quem executa no momento."
    ]
  },
  {
    level: 2,
    label: "Básico (Consciente)",
    descriptionSimple: "Há consciência da importância de organizar e algumas listas ou passos simples já são desenhados de forma rudimentar.",
    descriptionTechnical: "Sistematização de processos em nível elementar. O início da documentação surge em formatos esparsos (listas de verificação, Word, planilhas simples) com esforço de alinhamento tático.",
    keyCharacteristics: [
      "Início da documentação de atividades e fluxos críticos.",
      "Raciocínio básico de métricas (controles financeiros mais bem observados).",
      "Definição primária de quem faz o que, ainda com redundâncias frequentes."
    ]
  },
  {
    level: 3,
    label: "Definido",
    descriptionSimple: "Os principais processos e metas estão mapeados de forma oficial, compreendidos pela equipe e centralizados em um portal.",
    descriptionTechnical: "Processos e políticas de governança estão totalmente padronizados, formalizados institucionalmente e disponibilizados de ponta a ponta na organização.",
    keyCharacteristics: [
      "Mapeamento oficial estabelecido sob arquitetura formal de processos.",
      "Rituais e responsabilidades claras de aprovação e execução divididos de fato.",
      "Integração clara entre a missão estratégica e as atividades de rotina."
    ]
  },
  {
    level: 4,
    label: "Gerenciado",
    descriptionSimple: "Medimos a velocidade, custos e erros de cada etapa importante do processo por meio de números e tomamos rumo rápido.",
    descriptionTechnical: "Controle quantitativo rigoroso dos processos por meio de indicadores estatísticos e KPIs de eficiência. Desvios operacionais são detectados em tempo real de forma proativa.",
    keyCharacteristics: [
      "Uso de dashboards analíticos com métricas operacionais interligadas à estratégia.",
      "Gestão de riscos ativos (FMEA, contingenciamento) em plena operação.",
      "Decisões gerenciais embasadas em dados, tempos de ciclo históricos e evidências."
    ]
  },
  {
    level: 5,
    label: "Otimizado",
    descriptionSimple: "Sua empresa funciona como um relógio inteligente que muda de velocidade sozinho diante de imprevistos do mercado de forma científica.",
    descriptionTechnical: "Foco contínuo na inovação estruturada e na melhoria contínua dos processos. Utilização ativa de inteligência artificial generativa, simulações avançadas e feedback dinâmico das operações na tomada de decisão.",
    keyCharacteristics: [
      "Melhorias são executadas sistematicamente via ciclos ágeis retroalimentados.",
      "Processos autogerenciáveis integrados com automação avançada de ponta a ponta.",
      "Capacidade adaptativa extrema baseada em simulação estocástica e IA integrada."
    ]
  }
];
