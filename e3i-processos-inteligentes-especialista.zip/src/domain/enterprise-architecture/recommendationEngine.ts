import { enterpriseDimensions } from "./enterpriseDimensions";

export interface RecommendationResult {
  dimensionId: string;
  dimensionName: string;
  currentScore: number;
  simpleAdvice: string;
  technicalAdvice: string;
  recommendedFrameworks: string[]; // Framework IDs
}

export function generateRecommendations(scores: Record<string, number>): RecommendationResult[] {
  const recommendations: RecommendationResult[] = [];

  for (const dim of enterpriseDimensions) {
    const score = scores[dim.id] !== undefined ? scores[dim.id] : 0;
    
    // Low score threshold: below 3 is considered weak/unstructured (Levels 0, 1, 2)
    let simpleAdvice = "";
    let technicalAdvice = "";
    let recommendedFrameworksList: string[] = [];

    if (dim.id === "strategy") {
      if (score < 3) {
        simpleAdvice = "Defina os 3 principais objetivos do seu negócio e de sua equipe para este início de ciclo de forma simples. Garanta que todos saibam qual rumo tomar.";
        technicalAdvice = "Implantar as premissas de alinhamento tático Balanced Scorecard (BSC). Transformar os objetivos corporativos em métricas de cadência ágil OKRs divididos por times operacionais.";
        recommendedFrameworksList = ["okr", "bsc"];
      } else {
        simpleAdvice = "Sua estratégia está clara. Mantenha as revisões periódicas de metas e incentive a equipe a atualizar o status semanalmente.";
        technicalAdvice = "Consolidar a governança dos ciclos de OKR e refinar as premissas de causa e efeito do seu mapa estratégico BSC.";
        recommendedFrameworksList = ["okr"];
      }
    } else if (dim.id === "structure") {
      if (score < 3) {
        simpleAdvice = "Crie uma lista das tarefas do dia a dia e anote explicitamente quem executa e quem aprova cada uma delas para evitar brigas ou tarefas esquecidas.";
        technicalAdvice = "Modelar as linhas de governança interna com uma matriz de responsabilidades RACI para todas as frentes de trabalho operacional chave.";
        recommendedFrameworksList = ["raci"];
      } else {
        simpleAdvice = "A responsabilidade está bem dividida. Continue revisando quando novos colaboradores entrarem para manter os papéis sempre transparentes.";
        technicalAdvice = "Otimizar o fluxo de delegação, implementando níveis claros de alçada de tomada de decisão, formalizando papéis organizacionais.";
        recommendedFrameworksList = ["raci"];
      }
    } else if (dim.id === "processes") {
      if (score < 3) {
        simpleAdvice = "Escreva o passo a passo de como o trabalho é feito, localizando os atrasos que mais geram desperdício de tempo e dinheiro.";
        technicalAdvice = "Aplicar mapeamento SIPOC macro e detalhar os fluxos recorrentes com a notação padrão BPMN. Identificar desperdícios operacionais utilizando o framework Lean.";
        recommendedFrameworksList = ["sipoc", "bpmn", "lean"];
      } else {
        simpleAdvice = "O fluxo do trabalho está mapeado e documentado. Busque agora monitorar o tempo de cada etapa para torná-lo ainda mais assertivo.";
        technicalAdvice = "Realizar mapeamento de fluxo de valor profundo (VSM) buscando gargalos ocultos de lead-time e dimensionamento estocástico de filas.";
        recommendedFrameworksList = ["vsm", "bpmn"];
      }
    } else if (dim.id === "people") {
      if (score < 3) {
        simpleAdvice = "Verifique os gargalos de habilidades na sua equipe e faça treinamentos rápidos das etapas mais complicadas do processo.";
        technicalAdvice = "Cruzar as capacidades críticas necessárias do plano estratégico com a matriz de competências da equipe, estruturando trilhas de desenvolvimento.";
        recommendedFrameworksList = ["adkar"];
      } else {
        simpleAdvice = "O time demonstra boa capacitação. Valorize e recompense o engajamento de alta performance.";
        technicalAdvice = "Manter avaliações frequentes baseadas em contribuições de valor e impulsionar planos de desenvolvimento individual sintonizados na excelência.";
        recommendedFrameworksList = ["adkar"];
      }
    } else if (dim.id === "systems") {
      if (score < 3) {
        simpleAdvice = "Mapeie os trabalhos manuais e redigitados do dia a dia e veja quais deles podem ser automatizados por planilhas integradas ou robôs simples.";
        technicalAdvice = "Auditar o ecossistema tecnológico (Arquitetura de Sistemas Integrada) para eliminar silos de processamento de informação de forma automatizada.";
        recommendedFrameworksList = ["bpmn"];
      } else {
        simpleAdvice = "As ferramentas operam integradamente. Avalie se as ferramentas continuam comportando o aumento do volume de dados atual.";
        technicalAdvice = "Análise periódica de escalabilidade tecnológica e conformidade securitária de dados sensíveis empresariais.";
        recommendedFrameworksList = ["bpmn"];
      }
    } else if (dim.id === "indicators") {
      if (score < 3) {
        simpleAdvice = "Comece monitorando poucas métricas chaves que mostram a saúde do faturamento e da entrega dos serviços, uma vez por semana.";
        technicalAdvice = "Fomentar um painel de indicadores (KPIs de Eficácia e Eficiência) indexados ao mapa de processos, estabelecendo limites aceitáveis de desvios.";
        recommendedFrameworksList = ["bsc", "okr"];
      } else {
        simpleAdvice = "As decisões ocorrem com base em dados de indicadores estruturados. Excelente! Acompanhe as variações para atuar preventivamente.";
        technicalAdvice = "Implementar cartas de controle estatístico Shewhart para monitorar anomalias e atuar nos desvios padrão volumétricos sistematicamente.";
        recommendedFrameworksList = ["bsc"];
      }
    } else if (dim.id === "culture") {
      if (score < 3) {
        simpleAdvice = "Incentive os colaboradores a trazer problemas reais e debata abertamente soluções em vez de buscar culpados.";
        technicalAdvice = "Diagnosticar e realinhar os valores compartilhados organizacionais com base nos sete elementos estruturantes do 7S McKinsey.";
        recommendedFrameworksList = ["mckinsey_7s", "kotter"];
      } else {
        simpleAdvice = "Seus valores guiam o time com solidez. Proteja essa cultura nas novas contratações do trimestre.";
        technicalAdvice = "Fixar as diretrizes de cultura organizacional conectando a avaliação de competências comportamentais ao plano estratégico de médio prazo.";
        recommendedFrameworksList = ["mckinsey_7s"];
      }
    } else if (dim.id === "governance") {
      if (score < 3) {
        simpleAdvice = "Documente as maiores regras e combine reuniões regulares para debater problemas repetitivos e os planos de ação abertos.";
        technicalAdvice = "Estruturar comitês formais de acompanhamento e aplicar relatórios preventivos contra riscos operacionais via matriz FMEA.";
        recommendedFrameworksList = ["fmea"];
      } else {
        simpleAdvice = "A governança e regras estão estruturadas. Mantenha os históricos salvos de maneira transparente.";
        technicalAdvice = "Realizar auditorias preventivas contínuas nos processos essenciais para garantir conformidade de nível ISO/Qualidade total.";
        recommendedFrameworksList = ["fmea"];
      }
    } else if (dim.id === "execution") {
      if (score < 3) {
        simpleAdvice = "Instale um quadro visual (como Kanban) onde todos do time consigam ver em tempo real o que está pendente, o que está correndo e o que está entregue.";
        technicalAdvice = "Implantar fluxo de trabalho Kanban estabelecendo limites estritos de WIP (Work in Progress). Desdobrar ações de melhoria sob o rigor tático do 5W2H.";
        recommendedFrameworksList = ["kanban", "5w2h"];
      } else {
        simpleAdvice = "O andamento diário está produtivo de forma ágil. Evite carregar novas tarefas de improviso sem planejamento prévio.";
        technicalAdvice = "Otimizar as reuniões ágeis diárias (Dailies) e controlar o lead-time real acumulado das melhorias.";
        recommendedFrameworksList = ["kanban", "5w2h"];
      }
    } else if (dim.id === "results") {
      if (score < 3) {
        simpleAdvice = "Calcule o custo financeiro total de cada melhoria implantada e compare com os ganhos reais obtidos no caixa no fim de cada ciclo.";
        technicalAdvice = "Construir estudos analíticos rigorosos de Retorno sobre Investimento (ROI) operacionais para as otimizações implementadas.";
        recommendedFrameworksList = ["roi"];
      } else {
        simpleAdvice = "O ganho financeiro e eficácia são consolidados com segurança de dados reais. Parabéns!";
        technicalAdvice = "Auditar as economias operacionais declaradas e criar planos de reinvestimento de capital excedente em novas frentes de melhorias estratégicas.";
        recommendedFrameworksList = ["roi"];
      }
    }

    recommendations.push({
      dimensionId: dim.id,
      dimensionName: dim.name,
      currentScore: score,
      simpleAdvice,
      technicalAdvice,
      recommendedFrameworks: recommendedFrameworksList
    });
  }

  return recommendations;
}
