export interface EnterpriseDimension {
  id: string;
  name: string;
  descriptionSimple: string;
  descriptionTechnical: string;
  keyQuestions: string[];
}

export const enterpriseDimensions: EnterpriseDimension[] = [
  {
    id: "strategy",
    name: "Estratégia",
    descriptionSimple: "A direção que sua empresa quer seguir e os objetivos que deseja alcançar.",
    descriptionTechnical: "Definição do posicionamento competitivo, modelo de negócios, metas de longo prazo e caminhos estratégicos com base em frameworks como BSC e OKRs.",
    keyQuestions: [
      "Quais são as três principais metas da sua empresa para este ano?",
      "Como você sabe se está caminhando na direção certa?",
      "Quem são seus principais concorrentes e qual é o seu diferencial para vencê-los?"
    ]
  },
  {
    id: "structure",
    name: "Estrutura",
    descriptionSimple: "Como sua equipe está organizada e quem é responsável pelo quê.",
    descriptionTechnical: "Desenho organizacional, hierarquias de reporte, definição de funções e atribuição de responsabilidades operacionais através de matrizes de responsabilidade como RACI.",
    keyQuestions: [
      "Existe um organograma atualizado e compreendido por todos?",
      "Os colaboradores sabem exatamente quem toma a decisão final em cada área?",
      "Há sobreposição de funções ou pessoas sem responsabilidades claras?"
    ]
  },
  {
    id: "processes",
    name: "Processos",
    descriptionSimple: "A forma como o trabalho é feito no dia a dia, passo a passo, para entregar valor.",
    descriptionTechnical: "Mapeamento, análise e otimização de fluxos de trabalho (BPMN, SIPOC, VSM) com foco em eficiência, eliminação de gargalos e redução de desperdícios no padrão Lean.",
    keyQuestions: [
      "Os principais processos da empresa estão descritos e padronizados?",
      "Quais atividades tomam mais tempo e causam mais dor de cabeça?",
      "Como você garante a mesma qualidade na entrega toda vez?"
    ]
  },
  {
    id: "people",
    name: "Pessoas",
    descriptionSimple: "A equipe que faz o negócio acontecer, suas habilidades e motivação.",
    descriptionTechnical: "Gestão do capital humano, capacidades críticas, programas de capacitação, avaliação de competências e alinhamento do time operacional aos desafios empresariais.",
    keyQuestions: [
      "Sua equipe atual tem as habilidades técnicas necessárias para as metas de crescimento?",
      "Como são tratadas a contratação, desenvolvimento e retenção de talentos?",
      "As pessoas se sentem capacitadas e valorizadas no trabalho?"
    ]
  },
  {
    id: "systems",
    name: "Sistemas",
    descriptionSimple: "As ferramentas e softwares que apoiam o trabalho diário.",
    descriptionTechnical: "Arquitetura de informações, sistemas legados, ERPs, CRMs, ferramentas de automação de fluxo de trabalho e integrabilidade tecnológica das operações de ponta a ponta.",
    keyQuestions: [
      "Quais softwares a empresa utiliza e eles se integram bem?",
      "Há tarefas manuais e repetitivas que poderiam ser automatizadas?",
      "A equipe perde muito tempo transferindo dados de um sistema para o outro?"
    ]
  },
  {
    id: "indicators",
    name: "Indicadores",
    descriptionSimple: "Os números que você acompanha para saber se a empresa está saudável.",
    descriptionTechnical: "Métricas de desempenho chaves (KPIs), alinhamento de metas locais à estratégia corporativa (Balanced Scorecard) e sistemas estáveis de visualização analítica.",
    keyQuestions: [
      "Quais números você acompanha toda semana para avaliar sua empresa?",
      "Cada setor ou colaborador tem metas claras que influenciam na meta da empresa?",
      "As decisões de negócio são tomadas com base em dados reais ou no sentimento?"
    ]
  },
  {
    id: "culture",
    name: "Cultura",
    descriptionSimple: "Os valores e comportamentos que de fato guiam a equipe, mesmo quando ninguém está olhando.",
    descriptionTechnical: "Valores compartilhados, clima organizacional, hábitos coletivos de liderança e alinhamento de comportamento às diretrizes institucionais.",
    keyQuestions: [
      "Quais atitudes são mais valorizadas e recompensadas na equipe?",
      "Como a equipe lida com erros e novidades no ambiente de trabalho?",
      "Os valores da empresa são vividos na prática ou estão apenas no papel?"
    ]
  },
  {
    id: "governance",
    name: "Governança",
    descriptionSimple: "As regras do jogo, como as decisões são tomadas e as reuniões são conduzidas.",
    descriptionTechnical: "Estrutura de comitês, rituais periódicos de alinhamento, auditoria de processos técnicos, regras de permissões corporativas e políticas de conformidade (Compliance).",
    keyQuestions: [
      "Com que frequência as lideranças se reúnem para avaliar o rumo do negócio?",
      "Quem tem autoridade para aprovar novos projetos ou despesas na empresa?",
      "As decisões importantes ficam devidamente registradas para auditoria futura?"
    ]
  },
  {
    id: "execution",
    name: "Execução",
    descriptionSimple: "A capacidade de transformar ideias e planos em ações reais e práticas.",
    descriptionTechnical: "Gestão ágil de portfólio de iniciativas, táticas de acompanhamento através de metodologias como Kanban, Scrum e acompanhamento detalhado de planos de ação (5W2H).",
    keyQuestions: [
      "As metas traçadas são realmente executadas ou acabam esquecidas?",
      "Como o time organiza e prioriza as tarefas diárias para evitar gargalos?",
      "Com que frequência vocês revisam o andamento dos planos de ação?"
    ]
  },
  {
    id: "results",
    name: "Resultados",
    descriptionSimple: "O impacto final de todo o esforço na saúde financeira e satisfação do cliente.",
    descriptionTechnical: "Margens de lucro operacionais, retorno sobre investimento (ROI), nível de retenção de clientes, índices de fidelidade e sustentabilidade financeira do negócio.",
    keyQuestions: [
      "Como está a rentabilidade financeira da empresa comparada ao planejado?",
      "Os clientes finais estão satisfeitos e recomendando a empresa?",
      "Sua empresa está gerando o retorno esperado com base no esforço e recursos investidos?"
    ]
  }
];
