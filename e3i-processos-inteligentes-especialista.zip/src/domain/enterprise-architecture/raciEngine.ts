export interface RaciItem {
  id: string;
  activityName: string;
  responsible: string[]; // R: Who executes the work
  accountable: string[]; // A: Who approves (must be exactly 1 ideally to avoid conflict)
  consulted: string[];  // C: Who should be heard
  informed: string[];   // I: Who should be kept updated
  processId?: string;
  criticality: "alta" | "media" | "baixa";
}

export interface GovernanceAlert {
  id: string;
  activityId: string;
  activityName: string;
  type: "no_responsible" | "multiple_accountables" | "no_accountable" | "no_authority" | "too_many_consulted" | "healthy";
  severity: "critical" | "warning" | "info";
  messageSimple: string;
  messageTechnical: string;
  recommendationSimple: string;
  recommendationTechnical: string;
}

export function analyzeRaciItem(item: RaciItem): GovernanceAlert[] {
  const alerts: GovernanceAlert[] = [];

  // Rule 1: No Responsible (R)
  if (item.responsible.length === 0) {
    alerts.push({
      id: `alert_no_r_${item.id}`,
      activityId: item.id,
      activityName: item.activityName,
      type: "no_responsible",
      severity: "critical",
      messageSimple: "Ninguém está escalado para colocar a mão na massa nesta tarefa.",
      messageTechnical: "Ausência de Atribuição Executora (R - Responsible) primária.",
      recommendationSimple: "Escolha uma pessoa ou cargo para ficar responsável por fazer essa tarefa todo dia.",
      recommendationTechnical: "Designar formalmente uma função operacional para o recebimento e execução das saídas deste processo."
    });
  }

  // Rule 2: Multiple Accountables (A)
  if (item.accountable.length > 1) {
    alerts.push({
      id: `alert_mult_a_${item.id}`,
      activityId: item.id,
      activityName: item.activityName,
      type: "multiple_accountables",
      severity: "critical",
      messageSimple: "Tem mais de um chefe querendo mandar ou aprovar essa tarefa, o que vai gerar brigas e lentidão.",
      messageTechnical: "Duplicidade de Alçada Deliberativa (A - Accountable). Riscos de paralisia de comitê.",
      recommendationSimple: "Deixe apenas uma pessoa como o aprovador final. Cachorro com dois donos morre de fome.",
      recommendationTechnical: "Garantir o princípio de comando único. Reduzir a alçada 'A' a um único role de liderança para assegurar a responsabilidade final (ownership)."
    });
  }

  // Rule 3: No Accountable (A)
  if (item.accountable.length === 0) {
    alerts.push({
      id: `alert_no_a_${item.id}`,
      activityId: item.id,
      activityName: item.activityName,
      type: "no_accountable",
      severity: "critical",
      messageSimple: "Não tem nenhum responsável ou dono claro que responde pelos erros e acertos dessa atividade.",
      messageTechnical: "Vácuo de Governança Executiva (A - Accountable) não configurado.",
      recommendationSimple: "Defina quem é o líder da área para ser o aprovador definitivo.",
      recommendationTechnical: "Associar o 'Accountable' ao Gerente de Divisão ou Sócio Diretor correlato para estabelecer governança."
    });
  }

  // Rule 4: Too many consulted (C)
  if (item.consulted.length >= 3) {
    alerts.push({
      id: `alert_many_c_${item.id}`,
      activityId: item.id,
      activityName: item.activityName,
      type: "too_many_consulted",
      severity: "warning",
      messageSimple: "Tem gente demais precisando ser ouvida antes da tarefa ser feita, o que deixa o processo muito lento.",
      messageTechnical: "Excesso de Interfaces de Consulta (C - Consulted). Gargalo potencial por excesso de reuniões.",
      recommendationSimple: "Reduza os consultados. Fale apenas com quem realmente agrega valor de decisão técnica.",
      recommendationTechnical: "Otimizar o fluxo transacional. Converter posições de 'Consultar (C)' para simplesmente 'Informar após a conclusão (I)'."
    });
  }

  // Rule 5: Responsible without Authority
  // If a junior role is Accountable (A) for highly critical items but doesn't have authority
  if (item.criticality === "alta" && item.accountable.some(acc => acc.includes("Auxiliar") || acc.includes("Ajudante") || acc.includes("Junior"))) {
    alerts.push({
      id: `alert_no_authority_${item.id}`,
      activityId: item.id,
      activityName: item.activityName,
      type: "no_authority",
      severity: "warning",
      messageSimple: "Pessoas de cargo muito inicial estão respondendo por decisões que envolvem muito dinheiro ou risco.",
      messageTechnical: "Desalinhamento de Alçada vs Cargo Júnior. Risco financeiro ou tático iminente por aprovação indevida.",
      recommendationSimple: "Transfira o papel de aprovação para o dono ou gerente para evitar prejuízos inesperados.",
      recommendationTechnical: "Elevar o nível hierárquico detentor da aprovação de conformidade nesta tarefa sensível."
    });
  }

  return alerts;
}
