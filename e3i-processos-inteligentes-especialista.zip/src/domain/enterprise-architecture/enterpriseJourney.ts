export interface JourneyStep {
  id: "diagnostico" | "estrategia" | "estrutura" | "processos" | "governanca" | "mudanca" | "execucao" | "resultados";
  sequence: number;
  label: string;
  objectiveSimple: string;
  objectiveTechnical: string;
  goldenQuestion: string;
  associatedFrameworks: string[];
  simpleGoal: string;
  technicalImpact: string;
}

export const enterpriseJourney: JourneyStep[] = [
  {
    id: "diagnostico",
    sequence: 1,
    label: "Diagnóstico",
    objectiveSimple: "Descobrir o estado atual da empresa e identificar onde estão as principais travas e problemas de ritmo.",
    objectiveTechnical: "Mapeamento sistemático de assimetrias, incompatibilidades de cultura ou arquitetura e vazamento de valor utilizando o Modelo 7S da McKinsey.",
    goldenQuestion: "Onde dói mais no seu negócio e o que está travando o crescimento hoje?",
    associatedFrameworks: ["mckinsey_7s"],
    simpleGoal: "Identificar as 3 maiores travas da operação de forma límpida.",
    technicalImpact: "Garantir blindagem metodológica para que as otimizações incidam na raiz motivadora do gargalo."
  },
  {
    id: "estrategia",
    sequence: 2,
    label: "Estratégia",
    objectiveSimple: "Definir clareza absoluta sobre para onde a empresa está indo e como vamos medir a chegada.",
    objectiveTechnical: "Alinhamento tático-estratégico sob Balanced Scorecard (BSC) desdobrando metas de longo prazo em indicadores acionáveis (OKRs) de cadência trimestral.",
    goldenQuestion: "Aonde você quer ver sua empresa nos próximos meses e quais números provarão isso?",
    associatedFrameworks: ["bsc", "okr"],
    simpleGoal: "Ter objetivos unificados compartilhados com a equipe.",
    technicalImpact: "Substituir suposições gerais por metas estatísticas consistentes e rastreáveis."
  },
  {
    id: "estrutura",
    sequence: 3,
    label: "Estrutura",
    objectiveSimple: "Organizar as cadeiras do seu time para saber exatamente quem executa e quem aprova cada etapa.",
    objectiveTechnical: "Mapeamento e formalização do organograma de processos atribuindo papéis de governança lineares através de uma matriz de responsabilidades RACI.",
    goldenQuestion: "As pessoas do seu time sabem exatamente quais tarefas dependem exclusivamente delas e quem dá a palavra final?",
    associatedFrameworks: ["raci"],
    simpleGoal: "Eliminar o 'cachorro com dois donos morrendo de fome' com papéis claros.",
    technicalImpact: "Redução radical de silos funcionais, retrabalhos operacionais e atrasos por ambiguidades de reporte."
  },
  {
    id: "processos",
    sequence: 4,
    label: "Processos",
    objectiveSimple: "Desenhar as etapas do trabalho físico ou administrativo para tirar desperdícios e tornar tudo mais rápido.",
    objectiveTechnical: "Modelagem e auditoria de valor de ponta a ponta com fluxos no padrão formal BPMN suportados por diagramas SIPOC e análise do fluxo de valor (VSM) e Lean.",
    goldenQuestion: "Como o seu produto ou serviço é fabricado e entregue, desde a chegada do pedido até o cliente final?",
    associatedFrameworks: ["sipoc", "vsm", "bpmn", "lean"],
    simpleGoal: "Ter o mapa de como sua empresa deve rodar padronizadamente todos os dias.",
    technicalImpact: "Redução significativa do Lead Time e variabilidade volumétrica (desvio padrão) por meio de eliminação de desperdício."
  },
  {
    id: "governanca",
    sequence: 5,
    label: "Governança & Risco",
    objectiveSimple: "Proteger seu negócio contra erros graves, vazamento de segredos, multas e imprevistos do cotidiano.",
    objectiveTechnical: "Estruturação preventiva de identificação de modos de falha por FMEA e execução de planos de contingenciamento e matrizes de risco integradas.",
    goldenQuestion: "O que de pior pode acontecer no seu negócio hoje e o que está estruturado para impedir que isso ocorra?",
    associatedFrameworks: ["fmea"],
    simpleGoal: "Montar escudos de proteção para evitar falhas surpresa na operação.",
    technicalImpact: "Prevenção sistemática de anomalias com diminuição expressiva do custo da não-qualidade na organização."
  },
  {
    id: "mudanca",
    sequence: 6,
    label: "Gestão da Mudança",
    objectiveSimple: "Preparar a equipe para as melhorias, guiando os sentimentos para ninguém sabotar o novo processo.",
    objectiveTechnical: "Engajamento e capacitação comportamental da organização aplicando os passos de Kotter e medindo o nível de prontidão pelo modelo ADKAR da Prosci.",
    goldenQuestion: "Como você vai engajar as pessoas da equipe para que fiquem animadas e adotem a nova forma de trabalhar?",
    associatedFrameworks: ["kotter", "adkar"],
    simpleGoal: "Fazer o time aderir ao projeto sem travar ou sabotar por medo da mudança.",
    technicalImpact: "Garantir aderência sustentável de novos fluxos minguando a resistência cultural das equipes de trabalho."
  },
  {
    id: "execucao",
    sequence: 7,
    label: "Execução Prática",
    objectiveSimple: "Tirar as ideias do papel organizando as tarefas da semana em quadros fáceis visíveis para todos.",
    objectiveTechnical: "Implantação de fluxo de trabalho contínuo puxado por quadros ágeis Kanban associados a premissas formais de ações documentadas em 5W2H.",
    goldenQuestion: "Quais ações específicas começaremos a fazer nesta segunda-feira e quem vai carregar o piano?",
    associatedFrameworks: ["kanban", "5w2h"],
    simpleGoal: "Dividir grandes planos em metas detalhadas e pequenas tarefas semanais controláveis.",
    technicalImpact: "Estabilização do trabalho diário com mitigação do estresse por acúmulo de WIP (trabalho em andamento)."
  },
  {
    id: "resultados",
    sequence: 8,
    label: "Resultados & ROI",
    objectiveSimple: "Contar o dinheiro extra que entrou, a satisfação gerada e o tempo ganho para comemorar.",
    objectiveTechnical: "Compilação de ganhos operacionais líquidos, mensuração do custo-benefício financeiro e cálculo exato de ROI baseado no custo de projeto.",
    goldenQuestion: "Quais resultados financeiros e operacionais palpáveis você obteve após essas mudanças nos processos?",
    associatedFrameworks: ["roi"],
    simpleGoal: "Enxergar com clareza o retorno financeiro real gerado pelas melhorias feitas.",
    technicalImpact: "Validação matemática rigorosa do valor gerado pelos programas de excelência operacional e financeira."
  }
];
