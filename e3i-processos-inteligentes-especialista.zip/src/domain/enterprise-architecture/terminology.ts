export interface TermTranslation {
  technicalTerm: string;
  simpleTranslation: string;
  explanation: string;
  category: "Estratégia" | "Processos" | "Mudança" | "Estrutura" | "Execução" | "Geral";
}

export const terminologyDictionary: TermTranslation[] = [
  {
    technicalTerm: "DMAIC",
    simpleTranslation: "Roteiro de 5 passos para resolver problemas",
    explanation: "É uma metodologia clássica para arrumar processos que estão dando prejuízo, dividida em: Definir, Medir, Analisar, Incrementar/Melhorar e Controlar.",
    category: "Processos"
  },
  {
    technicalTerm: "Balanced Scorecard (BSC)",
    simpleTranslation: "Placa de controle panorâmico do negócio",
    explanation: "Um quadro que ajuda o empresário a olhar para a empresa de 4 ângulos: dinheiro, clientes, processos internos inovadores e treinamento do seu time.",
    category: "Estratégia"
  },
  {
    technicalTerm: "Objectives and Key Results (OKR)",
    simpleTranslation: "Metas de foco focadas no trimestre",
    explanation: "Uma maneira de fazer a equipe inteira focar em poucas conquistas essenciais para os próximos 3 meses, medindo o progresso com números diretos.",
    category: "Estratégia"
  },
  {
    technicalTerm: "Matriz RACI",
    simpleTranslation: "Definição de quem faz o que e quem dá aprovação",
    explanation: "Uma tabela simples que deixa registrado quem põe a mão na massa, quem assina o cheque dando aval e quem só pode emitir palpites consultivos em cada tarefa.",
    category: "Estrutura"
  },
  {
    technicalTerm: "Mapeamento SIPOC",
    simpleTranslation: "Visão panorâmica de entrada, processo e clientes",
    explanation: "Um raio-x instantâneo para entender: fornecedores, matéria-prima de entrada, o roteiro principal, o resultado gerado e o cliente final que recebe.",
    category: "Processos"
  },
  {
    technicalTerm: "Value Stream Mapping (VSM)",
    simpleTranslation: "Linha do tempo de esperas e de trabalho real",
    explanation: "Arrumar em um mapa visual onde o seu trabalho ou produto fica parado gerando cansaço de equipe vs. onde de fato agregamos valor de compra para o cliente.",
    category: "Processos"
  },
  {
    technicalTerm: "Modelagem BPMN",
    simpleTranslation: "Desenho profissional universal do trabalho",
    explanation: "Desenhar fluxogramas do trabalho utilizando símbolos padronizados reconhecidos mundialmente por qualquer analista ou software de automação.",
    category: "Processos"
  },
  {
    technicalTerm: "FMEA (Modos de Falha)",
    simpleTranslation: "Estudo de 'Onde corremos o risco de falhar'",
    explanation: "Um inventário que pontua a gravidade dos piores erros imagináveis acontecerem na empresa para que a gerência faça proteções antes deles aparecerem.",
    category: "Geral"
  },
  {
    technicalTerm: "ADKAR",
    simpleTranslation: "Roteiro pessoal de adaptação de cada colaborador",
    explanation: "O segredo de fazer seus colaboradores mudarem hábitos sem briga, assegurando que eles tenham: Consciência, Desejo, Conhecimento, Habilidade e Estímulo.",
    category: "Mudança"
  },
  {
    technicalTerm: "Kotter (8 passos)",
    simpleTranslation: "Guia de união de equipe para mudanças sérias",
    explanation: "O segredo de iniciar mudanças na empresa diminuindo a fofoca ou rebeldia do time, unindo aliados e comemorando pequenas vitórias no caminho.",
    category: "Mudança"
  },
  {
    technicalTerm: "WIP (Work in Progress)",
    simpleTranslation: "Pilha de tarefas começadas acumuladas sem terminar",
    explanation: "Mostra o quanto de trabalho ou projeto sua empresa iniciou e acumulou de uma vez sem finalizar. Quanto mais WIP, mais o time fica exausto e improdutivo.",
    category: "Execução"
  },
  {
    technicalTerm: "5W2H",
    simpleTranslation: "Checklist de 7 perguntas sem frestas",
    explanation: "O checklist definitivo que tira qualquer ideia da conversa informal de reunião respondendo: o que será feito, por que, quem fará, onde, quando, como e quanto custará.",
    category: "Execução"
  },
  {
    technicalTerm: "ROI (Return on Investment)",
    simpleTranslation: "Dinheiro limpo que voltou para o bolso comparado ao gasto",
    explanation: "Mostra matematicamente se a grana investida em uma mudança ou novo sistema gerou faturamento suficiente para pagar as contas e deixar a empresa no lucro.",
    category: "Geral"
  },
  {
    technicalTerm: "Lead Time",
    simpleTranslation: "Tempo total de espera do cliente do início ao fim",
    explanation: "O relógio correndo desde o primeiro segundo que o cliente pede o produto/serviço até a entrega ou finalização completa. Idealmente deve ser o menor possível.",
    category: "Processos"
  },
  {
    technicalTerm: "UCL / LCL (Limites Estatísticos)",
    simpleTranslation: "Linhas vermelhas de teto e chão de segurança",
    explanation: "São os limites estatísticos calculados que alertam quando a produtividade está flutuando de forma perigosa e anormal, exigindo intervenção rápida.",
    category: "Processos"
  }
];

export function translateTechnicalToSimple(technicalText: string): string {
  let text = technicalText;
  for (const item of terminologyDictionary) {
    const regex = new RegExp(item.technicalTerm.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
    text = text.replace(regex, `${item.simpleTranslation} (${item.technicalTerm})`);
  }
  return text;
}
