import { ProcessStep, ProjectCharter, Sipoc, ControlPlan, Deliverable } from "../../types";
import { BusinessType } from "../../App";

export const BUSINESS_TERMS = {
  INDUSTRIAL: {
    title: "Indústria & Produção",
    badge: "Módulo Industrial",
    step: "Posto de Trabalho",
    stepPlural: "Postos de Trabalho",
    units: "Peças / Itens",
    unitSingular: "Peça",
    wip: "Estoque em Processo (WIP)",
    cycleTime: "Tempo de Ciclo (Usinagem/Montagem)",
    cycleTimeTitle: "Tempo de Ciclo (Usinagem/Montagem) Total",
    setup: "Tempo de Setup (Troca de Máquina)",
    throughput: "Capacidade de Produção (Peças/Hora)",
    queue: "Fila de Espera Fisiológica",
    bottleneckDesc: "Gargalo da Linha de Fabricação",
    qualityTitle: "Qualidade Compilada FPP",
    dpmoLabel: "desvios",
    sigmaSubtitle: "Nível Sigma combinado",
    littleLawSubtitle: "Pela Lei de Little estendida"
  },
  SERVICES: {
    title: "Serviços & Escritórios",
    badge: "Módulo de Serviços",
    step: "Estação de Serviço / Atendente",
    stepPlural: "Estações de Serviço / Atendentes",
    units: "Chamados / Clientes",
    unitSingular: "Chamado",
    wip: "Fila de Chamados Pendentes (Backlog)",
    cycleTime: "Tempo de Atendimento",
    cycleTimeTitle: "Tempo de Atendimento Total",
    setup: "Preparação de Atividades / Briefing",
    throughput: "Capacidade de Atendimento (Clientes/Hora)",
    queue: "Fila de Espera de Serviço",
    bottleneckDesc: "Ponto Crítico de Saturação de Serviço",
    qualityTitle: "Qualidade de Serviço (FTT)",
    dpmoLabel: "falhas/10⁶ chamados",
    sigmaSubtitle: "Nível Sigma de Prestação",
    littleLawSubtitle: "Backlog em trânsito (Lei de Little)"
  },
  RETAIL: {
    title: "Comércio & Varejo",
    badge: "Módulo Comercial Varejista",
    step: "Ponto de Atendimento / Caixa",
    stepPlural: "Pontos de Atendimento / Caixas",
    units: "Clientes em Fila",
    unitSingular: "Cliente",
    wip: "Clientes Aguardando Atendimento",
    cycleTime: "Tempo de Atendimento no PDV",
    cycleTimeTitle: "Tempo de Atendimento no PDV Total",
    setup: "Organização de Prateleira / Fechamento",
    throughput: "Vazão de Clientes (Clientes/Hora)",
    queue: "Fila do Caixa",
    bottleneckDesc: "Gargalo de Atendimento Comercial",
    qualityTitle: "Acurácia no Atendimento (FTT)",
    dpmoLabel: "erros/10⁶ transações",
    sigmaSubtitle: "Nível Sigma de Varejo / PDV",
    littleLawSubtitle: "Fila dinâmica calculada pela Lei de Little"
  },
  LOGISTICS: {
    title: "Logística & Distribuição",
    badge: "Módulo de Supply Chain",
    step: "Doca / Etapa Logística",
    stepPlural: "Docas / Etapas Logísticas",
    units: "Pedidos / Paletes",
    unitSingular: "Pedido",
    wip: "Pedidos Acumulados no Centro de Distribuição",
    cycleTime: "Tempo de Processamento Logístico",
    cycleTimeTitle: "Tempo de Processamento Logístico Total",
    setup: "Troca de Carga / Liberação de Doca",
    throughput: "Vazão Logística (Pedidos/Hora)",
    queue: "Acúmulo de Docas / Triagem",
    bottleneckDesc: "Restrição de Despacho (Gargalo)",
    qualityTitle: "Desempenho de Entrega OTIF / FFP",
    dpmoLabel: "falhas/10⁶ entregas",
    sigmaSubtitle: "Nível Sigma da Cadeia Logística",
    littleLawSubtitle: "Volume em trânsito no CD (Lei de Little)"
  },
  TECHNOLOGY: {
    title: "Tecnologia & DevOps (SaaS)",
    badge: "Módulo de Tecnologia",
    step: "Squad / Etapa Kanban Dev",
    stepPlural: "Squads / Etapas de Entrega",
    units: "Histórias / Tarefas de Backlog",
    unitSingular: "História",
    wip: "Cards e Demanda em Progresso (WIP)",
    cycleTime: "Lead Time de Código (Desenvolvimento)",
    cycleTimeTitle: "Lead Time de Desenvolvimento Total",
    setup: "Setup de Ambiente / Revisão Crítica",
    throughput: "Vazão de Deploys (Histórias/Hora)",
    queue: "Backlog Pronto para Puxar (Todo)",
    bottleneckDesc: "Gargalo do Fluxo de Código",
    qualityTitle: "Qualidade de Release (Zero Defects)",
    dpmoLabel: "bugs/10⁶ deploys",
    sigmaSubtitle: "Nível Sigma de Engenharia / Delivery",
    littleLawSubtitle: "WIP do Pipeline Agile (Lei de Little)"
  },
  HEALTHCARE: {
    title: "Saúde & Atendimento Clínico",
    badge: "Módulo de Saúde Pública/Privada",
    step: "Posto Clínico / Consultório",
    stepPlural: "Postos / Consultórios Médicos",
    units: "Pacientes",
    unitSingular: "Paciente",
    wip: "Pacientes no Pronto-Socorro",
    cycleTime: "Tempo de Triagem ou Consulta",
    cycleTimeTitle: "Tempo Assistencial Total",
    setup: "Higienização / Higiene de Leito",
    throughput: "Capacidade de Atendimento (Pacientes/Hora)",
    queue: "Fila de Espera / Triagem Manchester",
    bottleneckDesc: "Restrição de Prontidão Clínica",
    qualityTitle: "Segurança e Conformidade Clínica",
    dpmoLabel: "não-conformidades/10⁶ atendimentos",
    sigmaSubtitle: "Nível Sigma Assistencial",
    littleLawSubtitle: "Carga de espera no P.S. (Lei de Little)"
  },
  FINANCE: {
    title: "Finanças & Contabilidade",
    badge: "Módulo Governança Financeira",
    step: "Posto de Análise / Aprovação",
    stepPlural: "Analistas / Postos de Faturamento",
    units: "Faturas / Documentos",
    unitSingular: "Fatura",
    wip: "Documentos Acumulados no Processo",
    cycleTime: "Tempo de Conciliação / Fechamento",
    cycleTimeTitle: "Tempo de Fechamento Financeiro Total",
    setup: "Verificação de Lotes / Checklist",
    throughput: "Capacidade de Processamento (Faturas/Hora)",
    queue: "Fila de Entrada / Borderôs",
    bottleneckDesc: "Gargalo de Compliance de Fechamento",
    qualityTitle: "Acurácia de Lançamentos & Controles",
    dpmoLabel: "erros/10⁶ faturas",
    sigmaSubtitle: "Nível Sigma de Governança Financeira",
    littleLawSubtitle: "Documentos em lote na fila (Lei de Little)"
  },
  HUMAN_RESOURCES: {
    title: "Recursos Humanos & Contratação",
    badge: "Módulo Gente & Gestão (RH)",
    step: "Fase do Funil / Entrevistador",
    stepPlural: "Avaliadores / Fases de Seleção",
    units: "Candidatos / Currículos",
    unitSingular: "Candidato",
    wip: "Processos Seletivos em Andamento",
    cycleTime: "Tempo no Funil (Time-to-Hire)",
    cycleTimeTitle: "Time-to-Hire (Funil de Seleção) Total",
    setup: "Alinhamento de Perfil / Sincronia de Escopo",
    throughput: "Taxa de Contratação (Candidatos Admitidos/Hora)",
    queue: "Pipeline de Inscritos / Triagem de CVs",
    bottleneckDesc: "Gargalo Crítico de Contratação de Talentos",
    qualityTitle: "Taxa de Qualidade e Fit de Seleção",
    dpmoLabel: "desvios/10⁶ avaliações",
    sigmaSubtitle: "Nível Sigma de Recrutamento & Seleção",
    littleLawSubtitle: "Candidatos ativos no pipeline (Lei de Little)"
  }
};

export const getVisibleWorkspaceViews = (type: BusinessType) => {
  return ["CLIENT_PROJECTS", "E3I_INTELLIGENCE", "DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "OR_HUB", "REPORT", "ENTERPRISE_STUDIO", "BI_STUDIO", "SIGMA_TREND"];
};

export const INITIAL_STEPS: ProcessStep[] = [
  {
    id: "step-1",
    name: "SMT - Aplicação de Solda e Componentes",
    resource: "Operador de SMT",
    resourceCount: 1,
    processingTime: 4.0,
    standardDeviation: 0.8,
    yieldRate: 0.98,
    setupTime: 15,
    description: "Montagem em superfície automatizada de placas eletrônicas.",
    requiredInputs: [
      "Placas de Circuito Virgens (Painel FR4)",
      "Pasta de Solda sem chumbo (SAC305)",
      "Bobinas de Componentes SMD (Resistores, Capacitores, ICs)",
      "Stencil Metálico Laser de precisão"
    ],
    stepInstructions: [
      "Efetuar limpeza prévia do Stencil com álcool isopropílico 99%.",
      "Alimentar bobinas de componentes nas gavetas correspondentes nos feeders de SMT.",
      "Programar e carregar o arquivo CAD do circuito PCB na máquina Pick & Place.",
      "Verificar pressão pneumática de raspagem de pasta de solda na impressora semiautomática."
    ],
    automations: [
      {
        title: "Raspador Automático de Pressão Direta",
        type: "Pneumática Proporcional",
        status: "active",
        description: "Garante deposição uniforme da pasta de solda através de reguladores integrados dinâmicos."
      },
      {
        title: "Sensoreamento de Bobina Vazia por RFID",
        type: "Sistemas Digitais IoT",
        status: "proposed",
        description: "Alerta preventivo de esgotamento de componente com antecedência de 15 minutos, anulando tempos de máquina vazia (reduz setup residual)."
      }
    ],
    supportDocuments: [
      { name: "SOP-SMT-001: Operação e Setup de Impressão de Pasta de Solda", code: "SOP-SMT-001", type: "SOP", rev: "A.3" },
      { name: "CKL-SMT-14: Verificação de Alinhamento Laser Pick & Place", code: "CKL-SMT-14", type: "Checklist", rev: "B.0" }
    ]
  },
  {
    id: "step-2",
    name: "Forno de Soldagem por Refluxo",
    resource: "Forno/Operador",
    resourceCount: 1,
    processingTime: 4.8,
    standardDeviation: 0.9,
    yieldRate: 0.99,
    setupTime: 5,
    description: "Fixação térmica dos componentes na placa.",
    requiredInputs: [
      "Placas montadas úmidas (recém-saídas da linha SMT)",
      "Sensores térmicos de perfil de temperatura (Kic Thermoprofiler)",
      "Gases inertes (Nitrogênio N2 líquido para controle de oxigênio)"
    ],
    stepInstructions: [
      "Selecionar a curva térmica correta no painel conforme o tipo de solda sem chumbo.",
      "Carregar os painéis de placas na esteira de alimentação de forma contínua.",
      "Monitorar a vazão e estabilização de Nitrogênio para prevenir oxidação das junções de cobre.",
      "Registrar a temperatura de saída da zona de resfriamento estabilizada abaixo de 45°C."
    ],
    automations: [
      {
        title: "Controle PID Dedicado de Curvas de Forno",
        type: "Automação Industrial PLC",
        status: "active",
        description: "Evita o choque térmico regulando a modulação das resistências em cada uma das 7 zonas térmicas."
      },
      {
        title: "Monitoramento Térmico Via Câmera Infravermelho",
        type: "Visão Computacional",
        status: "proposed",
        description: "Altera instantaneamente a velocidade de tração da esteira em caso de flutuação de temperatura nas zonas centrais."
      }
    ],
    supportDocuments: [
      { name: "MNL-RFX-004: Manual de Segurança e Manutenção do Forno", code: "MNL-RFX-004", type: "Manual", rev: "C.1" },
      { name: "SOP-RFX-02: Calibração de Perfil Térmico por Termopar", code: "SOP-RFX-02", type: "SOP", rev: "A.2" }
    ]
  },
  {
    id: "step-3",
    name: "Inspeção Óptica Automática (AOI)",
    resource: "Técnico de Qualidade",
    resourceCount: 1,
    processingTime: 3.2,
    standardDeviation: 1.4,
    yieldRate: 0.93,
    setupTime: 0,
    description: "Inspeção de solda com correção manual por técnico.",
    requiredInputs: [
      "Placas soldadas saídas do forno de refluxo",
      "Gabarito eletrônico de fita de testes",
      "Bancada anti-estática de toque macio (ESD)",
      "Estação de solda manual de retoque rápido"
    ],
    stepInstructions: [
      "Rodar scanner 3D óptico sob o lote em teste procurando pontes de solda ou componentes desalinhados.",
      "Isolar e colocar etiquetas de reprovação em placas que contenham pinos levantados.",
      "Efetuar o re-fluxo manual delicado dos contatos danificados com ferro de solda Weller ESD.",
      "Alimentar o system ERP local com os dados estatísticos das falhas por milhão de componentes."
    ],
    automations: [
      {
        title: "Processamento de Imagem 3D Estéreo",
        type: "Machine Vision",
        status: "active",
        description: "Inspeção em nível submícron de juntas de soldagem, capturando desvios de altura de componentes."
      },
      {
        title: "Classificador de Defeitos Baseado em IA Generativa",
        type: "Deep Learning (IA)",
        status: "proposed",
        description: "Zera o número de alarmes falsos da câmera óptica diminuindo o retrabalho desnecessário de operadores em até 70%."
      }
    ],
    supportDocuments: [
      { name: "SOP-AOI-007: Identificação e Retrabalho de Juntas com Solda Fria", code: "SOP-AOI-007", type: "SOP", rev: "D.0" },
      { name: "FRM-QLD-102: Relatório de Não-Conformidade Técnica RNC", code: "FRM-QLD-102", type: "Form", rev: "A.1" }
    ]
  },
  {
    id: "step-4",
    name: "Montagem Mecânica Final",
    resource: "Operador de Bancada",
    resourceCount: 1,
    processingTime: 5.5,
    standardDeviation: 1.1,
    yieldRate: 0.995,
    setupTime: 12,
    description: "Integração final do circuito no gabinete plástico.",
    requiredInputs: [
      "Placas eletrônicas aprovadas no AOI",
      "Gabinete plástico ABS injetado",
      "Kits de parafusos Philips e molas de aterramento",
      "Parafusadeiras pneumáticas de torque digital calibrate"
    ],
    stepInstructions: [
      "Fixar e alinhar a placa eletrônica PCB central nos pinos do chassis guia de ABS.",
      "Conectar o chicote de cabos flexíveis de alimentação e botão liga-desliga.",
      "Parafusar em cruz com torquímetro pneumático calibrado em exatamente 0.8 N.m.",
      "Garantir o perfeito lacre visual do painel frontal evitando falhas de rebarba plástica."
    ],
    automations: [
      {
        title: "Parafusadora Pneumática de Desarmamento Magnético",
        type: "Mecânica Eletromagnética",
        status: "active",
        description: "Corta instantaneamente o torque de parafusagem garantindo que o invólucro plástico não seja espanado ou quebrado."
      },
      {
        title: "Célula de Parafusamento Robotizado (Cobot)",
        type: "Robótica Colaborativa",
        status: "proposed",
        description: "Efetua a inserção e fixação dos parafusos em paralelo, liberando o operador para tarefas de embalagem."
      }
    ],
    supportDocuments: [
      { name: "SOP-MEC-05: Torqueamento e Lacre Mecânico de Gabinetes", code: "SOP-MEC-05", type: "SOP", rev: "C.4" },
      { name: "SOP-SFT-09: Postura Ergonômica e Calçado de Segurança em Células", code: "SOP-SFT-09", type: "SOP", rev: "B.2" }
    ]
  },
  {
    id: "step-5",
    name: "Teste Funcional e Embalagem",
    resource: "Testador e Embalador",
    resourceCount: 1,
    processingTime: 4.2,
    standardDeviation: 0.6,
    yieldRate: 0.97,
    setupTime: 0,
    description: "Validação eletromecânica sob carga de estresse.",
    requiredInputs: [
      "Módulos montados integrados (Gabinete + PCB)",
      "Cabinas de teste com carga resistiva",
      "Leitor de código de barras USB",
      "Etiquetadora industrial Zebra e caixas de papelão corrugado"
    ],
    stepInstructions: [
      "Conectar o cabo de interface serial ao gabarito de testes.",
      "Iniciar a rotina do software enviando comandos elétricos de stress em 12V.",
      "Checar as medições de resposta na tela de teste procurando atenuações de sinal rf.",
      "Confirmada a calibração, escanear o código do produto e lacrar o blister protetor ESD."
    ],
    automations: [
      {
        title: "Gabarito de Teste Pneumático por Cama de Agulhas",
        type: "Eletropneumática",
        status: "active",
        description: "Estabelece contatos térmicos e elétricos instantâneos reduzindo o tempo de conexão estática para 1 segundo."
      },
      {
        title: "Embaladora Holográfica com Impressão de Serial Dinâmico",
        type: "Termofita IoT",
        status: "proposed",
        description: "Integra o teste OK diretamente com a emissão do QR Code de rastreabilidade, acelerando a fase logística."
      }
    ],
    supportDocuments: [
      { name: "SOP-TST-022: Teste Estatístico Paramétrico sob Estresse de Temperatura", code: "SOP-TST-022", type: "SOP", rev: "F.1" },
      { name: "MNL-PKG-101: Normas de Embalagem para Exportações Marítimas", code: "MNL-PKG-101", type: "Manual", rev: "A.0" }
    ]
  }
];

export const INITIAL_CHARTER: ProjectCharter = {
  title: "Projeto de Estabilização e Capacidade do Fluxo PCB",
  problemStatement: "A linha de montagem apresenta gargalos intermitentes de vazão e alto índice de retrabalho na inspeção óptica, fazendo com que o Lead Time médio passe de 45 minutos e gerando atrasos crônicos na entrega.",
  goal: "Reduzir o Lead Time total do sistema em 40%, aumentar o nível sigma do processo para após 3.5σ e eliminar filas acumuladas nos postos de montagem mecânica.",
  metric: "cycle_time",
  targetValue: 25
};

export const generateDefaultDeliverables = (projectId: string): Deliverable[] => [
  {
    id: `del-def-1-${projectId}`,
    projectId,
    phaseId: "DEFINE",
    name: "Project Charter Formalizado",
    description: "Definição clara do escopo do projeto, business case, meta quantificada e patrocinador.",
    required: true,
    weight: 3,
    status: "not_started",
    responsibleUserId: "Marco Antônio (Black Belt)",
    dueDate: "2026-06-30",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-def-2-${projectId}`,
    projectId,
    phaseId: "DEFINE",
    name: "Mapeamento SIPOC de Alto Nível",
    description: "Mapeamento de Fornecedores, Entradas, Processos, Saídas e Clientes primários.",
    required: true,
    weight: 2,
    status: "not_started",
    responsibleUserId: "Soraia (Process Owner)",
    dueDate: "2026-07-05",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-meas-1-${projectId}`,
    projectId,
    phaseId: "MEASURE",
    name: "Coleta de Dados e Cronoanálise",
    description: "Criação de base de dados estocásticos sobre taxas de chegada e tempos de ciclo reais.",
    required: true,
    weight: 2,
    status: "not_started",
    responsibleUserId: "Técnico de Processo SMT",
    dueDate: "2026-07-15",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-meas-2-${projectId}`,
    projectId,
    phaseId: "MEASURE",
    name: "Amostragem Gage R&R para Metrologia",
    description: "Validação do sistema de medição e repetitividade dos sensores ópticos.",
    required: false,
    weight: 1,
    status: "not_started",
    responsibleUserId: "Equipe de Qualidade",
    dueDate: "2026-07-20",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-ana-1-${projectId}`,
    projectId,
    phaseId: "ANALYZE",
    name: "Estudo de Gargalos e Capacidade (G/G/1)",
    description: "Análise quantitativa de taxas de utilização e tempos de fila estocásticos.",
    required: true,
    weight: 3,
    status: "not_started",
    responsibleUserId: "Fabiano (Admin/LSS)",
    dueDate: "2026-07-30",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-ana-2-${projectId}`,
    projectId,
    phaseId: "ANALYZE",
    name: "Ishikawa e 5 Porquês da Causa Raiz",
    description: "Análise qualitativa dos principais desvios térmicos do forno de refusão.",
    required: true,
    weight: 2,
    status: "not_started",
    responsibleUserId: "Soraia (Process Owner)",
    dueDate: "2026-08-05",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-imp-1-${projectId}`,
    projectId,
    phaseId: "IMPROVE",
    name: "Desenho de Soluções com Co-Piloto IA",
    description: "Propostas de melhoria, automações com IA e simulação de alteração de layout.",
    required: true,
    weight: 3,
    status: "not_started",
    responsibleUserId: "Marco Antônio (Black Belt)",
    dueDate: "2026-08-15",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-imp-2-${projectId}`,
    projectId,
    phaseId: "IMPROVE",
    name: "Estudo de Viabilidade Econômica (ROI)",
    description: "Simulador de ROI de melhorias, faturamento adicional e payback esperado.",
    required: false,
    weight: 2,
    status: "not_started",
    responsibleUserId: "Controller Financeiro",
    dueDate: "2026-08-20",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  },
  {
    id: `del-cont-1-${projectId}`,
    projectId,
    phaseId: "CONTROL",
    name: "Especificação de Planos de Controle CEP",
    description: "Criação de limites de controle UCL/LCL estatísticos estáveis baseados em amostragem.",
    required: true,
    weight: 3,
    status: "not_started",
    responsibleUserId: "Equipe de Qualidade",
    dueDate: "2026-08-30",
    approvedBy: null,
    approvedAt: null,
    evidenceIds: [],
    createdAt: "2026-06-14T10:38:26-07:00"
  }
];

export const INITIAL_SIPOC: Sipoc = {
  suppliers: "Almoxarifado central, Fornecedor de PCBs e componentes ativos, Fábrica de Injeção Plástica",
  inputs: "Placas virgens, pasta de solda sem chumbo, MCUs, conectores, gabinetes plásticos e parafusos",
  processDescription: "Abastecimento SMT -> Refluxo térmico -> Inspeção óptica/Reparo -> Montagem Mecânica -> Teste Funcional",
  outputs: "Dispositivos PCB integrados prontos para remessa, relatórios de não-conformidade",
  customers: "Distribuidoras regionais, Clientes B2B e canais de exportação",
};

export const INITIAL_CONTROL_PLAN: ControlPlan[] = [
  {
    id: "cp-1",
    stepName: "AOI Inspeção",
    metric: "Fração de rejeito em primeira passagem (FPP)",
    lcl: 0.88,
    ucl: 0.99,
    target: 0.96,
    frequency: "A cada lote de produção",
    responsible: "Técnico de Qualidade",
    reactionPlan: "Parar alimentação do forno, recalibrar bicos de deposição e rechecar vácuo.",
    currentReading: 0.94,
    enableAlarm: true,
    warningEmail: "monitoria.lote@empresa.com",
    criticalEmail: "engenharia.qualidade@empresa.com",
  },
  {
    id: "cp-2",
    stepName: "Montagem Mecânica",
    metric: "Lead time local da etapa",
    lcl: 3.5,
    ucl: 7.5,
    target: 5.5,
    frequency: "Monitoramento diário por amostra",
    responsible: "Líder de Célula",
    reactionPlan: "Efetuar rodízio de operadores fatigados e examinar ferramentas pneumáticas.",
    currentReading: 5.2,
    enableAlarm: true,
    warningEmail: "lider.celula@empresa.com",
    criticalEmail: "diretor.operacoes@empresa.com",
  },
];
