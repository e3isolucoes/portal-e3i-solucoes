export { COLORS, DESIGN_SYSTEM, ACCESSIBILITY } from "../../utils/designSystem";
