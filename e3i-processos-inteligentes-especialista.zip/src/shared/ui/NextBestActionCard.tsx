import React from "react";
import { 
  Zap, 
  ArrowRight, 
  Clock, 
  BarChart, 
  Layers, 
  AlertTriangle,
  Award,
  TrendingUp,
  Sliders,
  Sparkles
} from "lucide-react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";
import { NextBestAction } from "../../domain/enterprise-architecture/nextBestActionEngine";

export interface NextBestActionCardProps {
  action: NextBestAction;
  mode: UsabilityMode;
  onExecute: (stepId: string) => void;
  className?: string;
}

export default function NextBestActionCard({
  action,
  mode,
  onExecute,
  className = ""
}: NextBestActionCardProps) {
  const isExpert = isExpertMode(mode);

  // Badge styles helper for Priority
  const getPriorityBadgeStyles = (priority: string) => {
    switch (priority) {
      case "CRÍTICA":
        return "bg-rose-100 text-rose-800 border-rose-200";
      case "ALTA":
        return "bg-amber-100 text-amber-800 border-amber-200";
      default:
        return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  // Badge styles helper for Effort
  const getEffortBadgeStyles = (effort: string) => {
    switch (effort) {
      case "ALTO":
        return "bg-amber-50 text-amber-600 border-amber-200";
      case "MÉDIO":
        return "bg-indigo-50 text-indigo-600 border-indigo-200";
      default:
        return "bg-emerald-50 text-emerald-600 border-emerald-200";
    }
  };

  return (
    <div 
      id={`nba-card-${action.id}`}
      className={`bg-white border-2 border-[#C49746]/30 hover:border-[#C49746] rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden font-sans text-left relative ${className}`}
    >
      {/* Visual Accent Badge - Top Corner */}
      <div className="absolute top-0 right-0 bg-[#C49746] text-white text-[9px] font-mono font-bold uppercase tracking-widest px-3 py-1 rounded-bl-lg">
        Recomendado
      </div>

      {/* Internal Padding */}
      <div className="p-5 md:p-6 space-y-4">
        
        {/* Module Segment Indicator */}
        <div className="flex flex-wrap items-center gap-2 -mt-1">
          <span className="text-[10px] font-mono font-black text-amber-800 uppercase tracking-wider bg-amber-50 px-2 py-0.5 rounded border border-amber-150">
            {action.suggestedModule}
          </span>
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getPriorityBadgeStyles(action.priority)} font-bold`}>
            {action.priority}
          </span>
        </div>

        {/* Title */}
        <div className="space-y-1 pr-14">
          <h3 className="text-base md:text-lg font-black text-slate-950 font-sans tracking-tight leading-snug">
            {isExpert ? action.titleTechnical : action.titleSimple}
          </h3>
          <p className="text-[11px] font-mono text-slate-400">
            Target Módulo: <span className="text-[#C49746] font-bold">E3I {action.targetStepId.toUpperCase()}</span>
          </p>
        </div>

        <hr className="border-slate-100" />

        {/* Dynamic Dual Context */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Reason Block */}
          <div className="space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-slate-400" /> Por que isso importa?
            </span>
            <p className="text-xs text-slate-700 leading-relaxed text-justify">
              {isExpert ? action.reasonTechnical : action.reasonSimple}
            </p>
          </div>

          {/* Impact Block */}
          <div className="space-y-1 bg-[#FAF9F5] p-3 rounded-lg border border-amber-100">
            <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-[#C49746]" /> Impacto Estimado
            </span>
            <p className="text-xs text-slate-800 leading-relaxed text-justify font-medium">
              {isExpert ? action.impactTechnical : action.impactSimple}
            </p>
          </div>

        </div>

        {/* Metadata Details Row */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
          <div className="flex items-center gap-4">
            {/* Esforço */}
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <div className="text-left leading-none">
                <span className="text-[9px] font-mono uppercase text-slate-400 block font-bold">Esforço</span>
                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border inline-block mt-0.5 ${getEffortBadgeStyles(action.effort)}`}>
                  {action.effort}
                </span>
              </div>
            </div>
          </div>

          {/* Action Trigger Button */}
          <button
            type="button"
            onClick={() => onExecute(action.targetStepId)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#C49746] hover:bg-[#A97E34] text-white font-bold text-xs rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer group select-none min-h-[44px]"
          >
            <span>{action.actionLabel}</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>

      </div>
    </div>
  );
}
