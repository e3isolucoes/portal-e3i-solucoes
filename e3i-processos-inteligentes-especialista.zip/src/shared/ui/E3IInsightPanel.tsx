import React, { useState } from "react";
import { 
  Compass, 
  HelpCircle, 
  Lightbulb, 
  Zap, 
  BookOpen, 
  ChevronDown, 
  ChevronUp,
  Sparkles,
  Info
} from "lucide-react";
import { UsabilityMode, isExpertMode } from "../../domain/usabilityMode";

export interface E3IInsightPanelProps {
  title: string;
  businessExplanation: string; // O que estou vendo? (Linguagem simples)
  whyItMatters: string; // Por que isso importa?
  nextAction: string; // O que fazer agora?
  frameworkName?: string; // Qual framework está por trás?
  technicalDetails?: string; // Detalhes técnicos
  mode: UsabilityMode;
  className?: string;
}

export default function E3IInsightPanel({
  title,
  businessExplanation,
  whyItMatters,
  nextAction,
  frameworkName,
  technicalDetails,
  mode,
  className = ""
}: E3IInsightPanelProps) {
  const isExpert = isExpertMode(mode);
  const [isTechnicalExpanded, setIsTechnicalExpanded] = useState(isExpert);
  const [isOpen, setIsOpen] = useState(true);

  if (!isOpen) {
    return (
      <div className={`fixed bottom-4 right-4 z-40 ${className}`}>
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 text-white rounded-xl shadow-lg hover:bg-slate-800 transition-all cursor-pointer font-sans text-xs font-bold"
          id="btn-open-insight-panel"
        >
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>E3I Insights: {title}</span>
        </button>
      </div>
    );
  }

  return (
    <div className={`bg-amber-50/45 border border-amber-200/80 rounded-2xl p-5 shadow-3xs font-sans text-left transition-all ${className}`} id="e3i-insight-panel">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-amber-200/50 pb-3.5 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-amber-550 text-white rounded-lg shadow-3xs">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[9px] font-mono font-black uppercase text-amber-700 tracking-wider">E3I Insight Co-Piloto</span>
            <h4 className="text-xs font-bold text-slate-900 mt-0.5">{title}</h4>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setIsOpen(false)}
          className="text-slate-400 hover:text-slate-600 font-mono text-[10px] uppercase font-bold tracking-wider px-2 py-1 hover:bg-amber-100/50 rounded-md transition-all cursor-pointer"
        >
          Minimizar
        </button>
      </div>

      {/* Content Space */}
      <div className="space-y-4 text-xs">
        {/* 1. O que estou vendo? */}
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-[10px] font-mono font-black uppercase text-amber-800 tracking-wider">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>O que estou vendo?</span>
          </div>
          <p className="text-slate-750 leading-relaxed font-sans">{businessExplanation}</p>
        </div>

        {/* 2. Por que isso importa? */}
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-[10px] font-mono font-black uppercase text-amber-800 tracking-wider">
            <Info className="w-3.5 h-3.5" />
            <span>Por que isso importa?</span>
          </div>
          <p className="text-slate-750 leading-relaxed font-sans">{whyItMatters}</p>
        </div>

        {/* 3. O que fazer agora? */}
        <div className="space-y-1 bg-amber-100/40 border border-amber-200/50 p-3 rounded-xl">
          <div className="flex items-center gap-1.5 text-[10px] font-mono font-black uppercase text-amber-900 tracking-wider">
            <Zap className="w-3.5 h-3.5 text-amber-600" />
            <span>O que fazer agora?</span>
          </div>
          <p className="text-amber-950 font-medium leading-relaxed font-sans mt-1">{nextAction}</p>
        </div>

        {/* 4. Qual framework está por trás? */}
        {frameworkName && (
          <div className="flex items-center gap-2 py-1.5 text-[10px] font-sans border-t border-b border-amber-200/40">
            <span className="font-mono text-slate-400 uppercase tracking-wider">Framework Científico:</span>
            <span className="font-bold text-slate-700 bg-amber-100/60 px-2 py-0.5 rounded border border-amber-200/30 font-mono">{frameworkName}</span>
          </div>
        )}

        {/* 5. Ver detalhe técnico */}
        {technicalDetails && (
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setIsTechnicalExpanded(!isTechnicalExpanded)}
              className="w-full flex items-center justify-between py-1 px-2.5 bg-slate-100 hover:bg-slate-200 border border-slate-250 rounded-lg text-[10px] font-mono uppercase font-black tracking-wider text-slate-650 transition-all cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                Dossiê Técnico para Black Belt
              </span>
              {isTechnicalExpanded ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>

            {isTechnicalExpanded && (
              <div className="mt-2.5 p-3.5 bg-slate-900 text-slate-100 rounded-xl border border-slate-850 shadow-inner font-mono text-[11px] leading-relaxed animate-fade-in relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 blur-xl rounded-full" />
                <span className="text-[8px] font-black uppercase tracking-wider text-amber-400 block mb-1.5">Mapeamento de Processo & Rigor Científico</span>
                <p className="whitespace-pre-line text-slate-300">{technicalDetails}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
