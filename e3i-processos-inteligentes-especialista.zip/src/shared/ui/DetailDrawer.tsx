import React, { useEffect } from "react";
import { X } from "lucide-react";

export interface DetailDrawerProps {
  isOpen: boolean;
  title: string;
  subTitle?: string;
  onClose: () => void;
  children: React.ReactNode;
}

const DetailDrawer: React.FC<DetailDrawerProps> = ({
  isOpen,
  title,
  subTitle,
  onClose,
  children
}) => {
  // Prevent scrolling behind drawer
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-5000 flex justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-950/40 backdrop-blur-3xs animate-fade-in"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative w-full max-w-md h-full bg-white shadow-2xl border-l border-slate-200 flex flex-col justify-between z-10 animate-slide-in font-sans text-left">
        {/* Header */}
        <div className="px-5 py-5 border-b border-slate-100 flex items-start justify-between">
          <div>
            <h3 className="text-sm font-black uppercase text-slate-950 font-mono tracking-wider">{title}</h3>
            {subTitle && (
              <p className="text-[11px] text-slate-500 mt-1 uppercase font-mono tracking-wide">{subTitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-650 cursor-pointer p-1 rounded-full hover:bg-slate-50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-grow overflow-y-auto p-5 space-y-4">
          {children}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-150 text-xs text-slate-700 font-bold transition-all rounded-lg cursor-pointer"
          >
            Fechar Painel
          </button>
        </div>
      </div>
    </div>
  );
};

export default DetailDrawer;
