import React from "react";
import { AlertTriangle, HelpCircle, X } from "lucide-react";

export interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  type?: "danger" | "warning" | "info";
  onConfirm: () => void;
  onClose: () => void;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmLabel = "Confirmar",
  cancelLabel = "Cancelar",
  type = "info",
  onConfirm,
  onClose
}) => {
  if (!isOpen) return null;

  const colorConfig = {
    danger: {
      icon: <AlertTriangle className="w-5 h-5 text-red-650" />,
      badge: "bg-red-50 border-red-200",
      btn: "bg-red-600 hover:bg-red-700 text-white"
    },
    warning: {
      icon: <AlertTriangle className="w-5 h-5 text-amber-600" />,
      badge: "bg-amber-50 border-amber-200",
      btn: "bg-amber-600 hover:bg-amber-700 text-white"
    },
    info: {
      icon: <HelpCircle className="w-5 h-5 text-[#C49746]" />,
      badge: "bg-amber-50/50 border-amber-100",
      btn: "bg-slate-900 hover:bg-slate-800 text-white"
    }
  };

  const cfg = colorConfig[type];

  // Stop mouse clicks from closing when clicking modal content body
  const stopPropagation = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 z-5000 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white border border-slate-200 shadow-xl max-w-md w-full rounded-lg overflow-hidden animate-scale-in"
        onClick={stopPropagation}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-1.5 border rounded-sm ${cfg.badge}`}>
              {cfg.icon}
            </div>
            <h4 className="text-xs font-black uppercase font-mono tracking-wider text-slate-950">{title}</h4>
          </div>
          <button 
            type="button" 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 cursor-pointer transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 font-sans">
          <p className="text-xs text-slate-600 leading-relaxed">{message}</p>
        </div>

        {/* Actions Footer */}
        <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 text-xs text-slate-600 bg-white hover:bg-slate-100 rounded-lg cursor-pointer transition-colors font-semibold"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={`px-4 py-2 text-xs rounded-lg cursor-pointer transition-colors font-semibold shadow-xs ${cfg.btn}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
