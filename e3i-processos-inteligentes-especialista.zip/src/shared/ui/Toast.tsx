import React, { createContext, useContext, useState, useEffect } from "react";
import { CheckCircle, AlertCircle, Info, AlertTriangle, X } from "lucide-react";

export type ToastType = "success" | "error" | "info" | "warning";

export interface ToastMessage {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
}

interface ToastContextType {
  success: (message: string) => void;
  error: (message: string) => void;
  info: (message: string) => void;
  warning: (message: string) => void;
  show: (type: ToastType, message: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast deve ser usado dentro de um ToastProvider");
  }
  return context;
}

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const show = (type: ToastType, message: string, duration = 4000) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message, duration }]);
  };

  const success = (msg: string) => show("success", msg);
  const error = (msg: string) => show("error", msg);
  const info = (msg: string) => show("info", msg);
  const warning = (msg: string) => show("warning", msg);

  const remove = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ success, error, info, warning, show }}>
      {children}
      {/* Toast Render Area */}
      <div className="fixed bottom-5 right-5 z-5500 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
        {toasts.map((t) => {
          return (
            <ToastItem key={t.id} toast={t} onClose={() => remove(t.id)} />
          );
        })}
      </div>
    </ToastContext.Provider>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onClose: () => void }> = ({ toast, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, toast.duration || 4000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);

  const styleConfig = {
    success: {
      bg: "bg-[#062419] border-emerald-500/30 text-emerald-100",
      icon: <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />,
      border: "border-l-4 border-l-emerald-500"
    },
    error: {
      bg: "bg-[#2A080C] border-red-500/30 text-red-100",
      icon: <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />,
      border: "border-l-4 border-l-red-500"
    },
    info: {
      bg: "bg-[#0B1528] border-blue-500/30 text-blue-100",
      icon: <Info className="w-4 h-4 text-blue-400 shrink-0" />,
      border: "border-l-4 border-l-blue-500"
    },
    warning: {
      bg: "bg-[#251A07] border-amber-500/30 text-amber-100",
      icon: <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />,
      border: "border-l-4 border-l-amber-500"
    }
  };

  const cfg = styleConfig[toast.type];

  return (
    <div className={`pointer-events-auto flex items-start gap-3 p-4 border rounded shadow-md tracking-tight text-xs font-sans animate-fade-in ${cfg.bg} ${cfg.border}`}>
      {cfg.icon}
      <div className="flex-grow font-semibold text-slate-100">{toast.message}</div>
      <button 
        onClick={onClose}
        className="text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
