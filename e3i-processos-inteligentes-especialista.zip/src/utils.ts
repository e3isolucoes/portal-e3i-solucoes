/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProcessStep, ProcessMetrics, SimulationLog } from "./types";

/**
 * Numerical approximation of the Inverse Cumulative Standard Normal Distribution (Probit function).
 * Used to calculate the Six Sigma Level from the total process yield.
 * Probit(p) maps a probability [0, 1] to standard deviations from the mean.
 */
export function probit(p: number): number {
  if (p <= 0.0000001) return -4.5;
  if (p >= 0.9999999) return 4.5;

  // Polynomial approximation coefficients (Wichura's algorithm)
  const a1 = -39.6968302866538, a2 = 220.946098424521, a3 = -275.928510446969;
  const a4 = 138.357751867269, a5 = -30.6647980381698, a6 = 2.50662827745924;
  const b1 = -54.4760987982241, b2 = 161.585836858041, b3 = -155.698979859887;
  const b4 = 66.8013118877197, b5 = -13.2806815528857;
  const c1 = -0.00778489400243029, c2 = -0.322396458041136, c3 = -2.40075827716184;
  const c4 = -2.54973253934373, c5 = 4.37466414146497, c6 = 2.93816398269878;
  const d1 = 0.00778469570904146, d2 = 0.32246712907004, d3 = 2.44513413714299, d4 = 3.75440866190742;

  const p_low = 0.02425;
  const p_high = 1 - p_low;

  if (p < p_low) {
    const q = Math.sqrt(-2 * Math.log(p));
    return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
           ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
  } else if (p <= p_high) {
    const q = p - 0.5;
    const r = q * q;
    return (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q /
           ((((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1));
  } else {
    const q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
            ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
  }
}

/**
 * Generates float values following a Normal Distribution using the Box-Muller transform
 */
export function boxMullerRandom(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random(); 
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return Math.max(0.1, mean + z * stdDev); // clamp at 0.1 to avoid negative times
}

/**
 * Analyzes process steps, calculates utilization, queue delays under G/G/c queue models,
 * identifies bottlenecks, and computes total compounded yield / Six Sigma metrics.
 */
export function calculateProcessMetrics(steps: ProcessStep[], arrivalRate: number): ProcessMetrics {
  let bottleneckStepName = "";
  let maxUtilization = -1;
  let processingTimeSum = 0;
  let rolledFirstPassYield = 1.0;
  let varianceSum = 0;

  // First pass: Calculate Capacity & simple sum metrics
  const analyzedSteps = steps.map((step) => {
    // Capacity = (60 mins / processingTime) * resourceCount
    const capacityPerHour = (60 / step.processingTime) * step.resourceCount;
    const utilization = (arrivalRate / capacityPerHour) * 100;
    
    processingTimeSum += step.processingTime;
    rolledFirstPassYield *= step.yieldRate;
    varianceSum += Math.pow(step.standardDeviation, 2);

    if (utilization > maxUtilization) {
      maxUtilization = utilization;
      bottleneckStepName = step.name;
    }

    return {
      ...step,
      capacityPerHour,
      utilization,
    };
  });

  // Calculate Stochastic Queueing and WIP for each step using Allen-Cunneen G/G/c approximation
  let systemLeadTime = 0;
  let systemWip = 0;

  analyzedSteps.forEach((step) => {
    const cap = step.capacityPerHour || 1;
    const rho = arrivalRate / cap; // Utilization ratio
    
    let avgQueueTime = 0; // minutes
    
    if (rho >= 0.999) {
      // Step saturated! Queue grows infinitely. Represent as a high warning threshold.
      avgQueueTime = 240 + (rho - 0.999) * 1000;
    } else {
      // G/G/c approximation:
      // Ca^2 = 1.0 (exponential arriving process)
      // Cv^2 = (std_dev / mean_service_time)^2 (variability of processing time)
      const Cv2 = Math.pow(step.standardDeviation / step.processingTime, 2);
      const Ca2 = 1.0;
      const variabilityFactor = (Ca2 + Cv2) / 2;
      const c = step.resourceCount;
      
      // G/G/c waiting approximation
      if (c === 1) {
        avgQueueTime = (rho / (1 - rho)) * variabilityFactor * step.processingTime;
      } else {
        const exponent = Math.sqrt(2 * (c + 1)) - 1;
        const delayProb = Math.pow(rho, exponent);
        avgQueueTime = (delayProb / (c * (1 - rho))) * variabilityFactor * step.processingTime;
      }
    }

    const totalStepLeadTime = step.processingTime + avgQueueTime; // core plus queue
    systemLeadTime += totalStepLeadTime;

    // Little's Law WIP = arrival rate * lead time
    // arrivalRate is units/hour, wait times are in minutes, so convert rate to units/minute (arrivalRate / 60)
    const stepWip = (arrivalRate / 60) * totalStepLeadTime;
    systemWip += stepWip;
  });

  // Six Sigma calculations
  const dpmo = (1 - rolledFirstPassYield) * 1000000;
  
  // Sigma Level = Z-score + 1.5 shift
  const sigmaLevel = probit(rolledFirstPassYield) + 1.5;

  return {
    arrivalRate,
    totalSteps: steps.length,
    bottleneckStepName,
    systemCapacity: analyzedSteps.reduce((min, s) => Math.min(min, s.capacityPerHour || 9999), 9999),
    systemUtilization: maxUtilization,
    leadTime: systemLeadTime,
    processingTimeSum,
    rolledFirstPassYield,
    sigmaLevel: Math.max(1.0, Math.min(6.0, sigmaLevel)), // bound between 1 to 6
    dpmo,
    systemWip,
    stdevProcess: Math.sqrt(varianceSum),
  };
}

/**
 * Runs a Monte Carlo simulation for 30 consecutive batches/days
 * and generates statistical measurements to support DMAIC analysis
 */
export function runMonteCarloSimulation(steps: ProcessStep[], arrivalRate: number): {
  logs: SimulationLog[];
  dailyAverages: { day: number; cycleTime: number; defectRate: number; wip: number }[];
} {
  const logs: SimulationLog[] = [];
  const dailyAverages: { day: number; cycleTime: number; defectRate: number; wip: number }[] = [];
  
  // Run simulation for 20 days/cycles to feed charts and measure phase data
  for (let day = 1; day <= 20; day++) {
    let dayTotalCycleTime = 0;
    let dayDefects = 0;
    const batchSize = 15; // Simulate 15 units flowing through the line each day

    for (let unit = 1; unit <= batchSize; unit++) {
      let cumulativeTime = 0;
      const isDayDefective = false;

      steps.forEach((step) => {
        // Stochastic processing duration using Box-Muller transform
        const duration = boxMullerRandom(step.processingTime, step.standardDeviation);
        
        // Add setup time if this is the first unit (Lean SMED concept)
        const setupTimeSpent = unit === 1 ? step.setupTime / batchSize : 0;
        
        // Quality test based on yield rate
        const isDefective = Math.random() > step.yieldRate;
        if (isDefective) {
          dayDefects++;
        }

        // Simple dynamic queuing delay based on current load (simulated)
        const loadFactor = arrivalRate / ((60 / step.processingTime) * step.resourceCount);
        const queueDuration = loadFactor > 0.9 
          ? boxMullerRandom(12, 4) 
          : boxMullerRandom(step.processingTime * loadFactor * 0.4, step.standardDeviation * 0.2);

        cumulativeTime += duration + setupTimeSpent + queueDuration;

        // Record a log sample for first 3 units of the latest day to show in a telemetry-alike logs
        if (day === 20 && unit <= 5) {
          const timestamp = new Date();
          timestamp.setMinutes(timestamp.getMinutes() - (300 - (unit * 30 + step.processingTime)));
          
          logs.push({
            timestamp: timestamp.toISOString().split('T')[1].substring(0, 8),
            unitId: unit + (day - 1) * batchSize,
            stepId: step.id,
            stepName: step.name,
            duration: parseFloat((duration).toFixed(2)),
            setupApplied: parseFloat(setupTimeSpent.toFixed(2)),
            defect: isDefective,
            queueDuration: parseFloat(queueDuration.toFixed(2)),
            completedAt: new Date(timestamp.getTime() + cumulativeTime * 60000).toISOString().split('T')[1].substring(0, 8),
          });
        }
      });
      dayTotalCycleTime += cumulativeTime;
    }

    const avgDayCycleTime = dayTotalCycleTime / batchSize;
    const dayDefectRate = dayDefects / (batchSize * steps.length);
    const dayWip = (arrivalRate / 60) * avgDayCycleTime;

    dailyAverages.push({
      day,
      cycleTime: parseFloat(avgDayCycleTime.toFixed(2)),
      defectRate: parseFloat((dayDefectRate * 100).toFixed(2)),
      wip: parseFloat(dayWip.toFixed(2)),
    });
  }

  return { logs, dailyAverages };
}
