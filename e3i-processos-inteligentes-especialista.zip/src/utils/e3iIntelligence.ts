export const DISCOVERY_QUESTIONS = [
  "Qual é o nome do processo e em qual área ele acontece?",
  "Qual é o objetivo principal do processo? Que resultado ele precisa entregar?",
  "Quem é o dono ou responsável pelo processo?",
  "Quais são as etapas do processo, do início ao fim?",
  "Quais sistemas, planilhas, e-mails, formulários ou documentos são usados?",
  "Onde acontecem atrasos, retrabalho, filas, aprovações manuais ou erros?",
  "Quais riscos existem se o processo falhar? Há impacto em cliente, SLA, financeiro, compliance ou operação?",
  "Qual é a frequência, volume mensal aproximado e tempo médio de execução?",
  "Quais indicadores existem hoje ou deveriam existir?",
  "Quais evidências ou documentos comprovam que o processo foi executado corretamente?",
];

export interface ProcessDraft {
  name: string;
  area: string;
  owner: string;
  objective: string;
  frequency: string;
  status: string;
  criticality: string;
  steps: string;
  systems: string;
  pain_points: string;
  risks: string;
  indicators: string;
  documents: string;
  cycle_time_hours: number;
  monthly_volume: number;
  rework_percentage: number;
  documentation_level: number;
  standardization_level: number;
  automation_level: number;
  control_level: number;
}

export interface ProcessScores {
  maturity_score: number;
  risk_score: number;
  automation_score: number;
  priority_score: number;
  maturity_stage: string;
  priority_label: string;
  estimated_rework_hours_month: number;
}

export interface ImprovementAction {
  title: string;
  framework: string;
  why: string;
  expected_benefit: string;
  impact: number;
  effort: number;
  urgency: number;
  value_score: number;
  suggested_owner: string;
  first_step: string;
  metric: string;
}

export interface ContinuousImprovementAnalysis {
  executive_summary: string;
  health_label: string;
  lean_wastes: string[];
  cbok_gaps: string[];
  root_cause_hypotheses: string[];
  suggested_kpis: string[];
  sipoc: {
    Fornecedores: string[];
    Entradas: string[];
    Processo: string[];
    Saídas: string[];
    Clientes: string[];
  };
  dmaic_plan: {
    Define: string;
    Measure: string;
    Analyze: string;
    Improve: string;
    Control: string;
  };
  pdca_cycle: {
    Plan: string;
    Do: string;
    Check: string;
    Act: string;
  };
  project_charter: {
    Problema: string;
    Objetivo: string;
    "Escopo inicial": string;
    "Fora do escopo inicial": string;
    "Dono sugerido": string;
    "Critério de sucesso": string;
  };
  actions: ImprovementAction[];
  quick_wins: ImprovementAction[];
}

export interface AssistantResult {
  process: ProcessDraft;
  confidence: number;
  missing_fields: string[];
  assumptions: string[];
  questions: string[];
  flow_dot: string;
  flow_markdown: string;
  // Compatibility fields
  processName?: string;
  objective?: string;
  steps?: string[];
  metrics?: {
    confidenceScore: number;
    reworkEst: number;
  };
  sipoc?: {
    Suppliers: string[];
    Inputs: string[];
    Process: string;
    Outputs: string[];
    Customers: string[];
  };
  smartDetected?: {
    s: boolean;
    m: boolean;
    a: boolean;
    r: boolean;
    t: boolean;
  };
}

export function detectSmartObjective(objectiveText: string, fullText: string) {
  const combined = (objectiveText + " " + fullText).toLowerCase();
  
  const specificKeywords = [
    "chamado", "ti", "suporte", "estoque", "contas", "nota fiscal", "faturamento", "fechamento",
    "cadastro", "vendas", "leads", "produção", "logística", "expedição", "pagamento", "compras",
    "atendimento", "sac", "rh", "contrato", "proposta", "recebimento", "comercial"
  ];
  const s = specificKeywords.some(kw => combined.includes(kw)) || objectiveText.length > 30;

  const m = combined.includes("%") || 
            /\b\d+\s*(?:horas|dias|minutos|chamados|notas|por cento)\b/i.test(combined) ||
            combined.includes("redução de") || combined.includes("reducao de") || 
            combined.includes("aumentar para") || combined.includes("meta de") ||
            combined.includes("kpi") || combined.includes("indicador");

  const a = combined.includes("padronizar") || combined.includes("organizar") || 
            combined.includes("otimizar") || combined.includes("garantir") || 
            combined.includes("controlar") || combined.includes("reduzir") || combined.includes("resolver");

  const r = combined.includes("custo") || combined.includes("qualidade") || 
            combined.includes("sla") || combined.includes("gargalo") || 
            combined.includes("retrabalho") || combined.includes("risco") || 
            combined.includes("satisfação") || combined.includes("satisfacao") ||
            combined.includes("compliance") || combined.includes("agilidade");

  const t = /\b\d+\s*(?:dias|meses|semanas|horas|trimestre|ano|prazo|limite)\b/i.test(combined) ||
            combined.includes("mensal") || combined.includes("diário") || combined.includes("diario") ||
            combined.includes("semanal") || combined.includes("anual") || 
            combined.includes("em até") || combined.includes("em ate") || 
            combined.includes("tempo médio") || combined.includes("tempo medio");

  return { s, m, a, r, t };
}

const KNOWN_SYSTEMS = [
  "ServiceNow",
  "Jira",
  "ERP",
  "SAP",
  "TOTVS",
  "Totvs",
  "Oracle",
  "BlackLine",
  "Sankhya",
  "Salesforce",
  "HubSpot",
  "Power BI",
  "Looker Studio",
  "BigQuery",
  "Excel",
  "Google Sheets",
  "Planilhas",
  "E-mail",
  "Email",
  "WhatsApp",
  "Teams",
  "Slack",
  "Formulário",
  "Google Forms",
  "SharePoint",
];

const AREA_KEYWORDS: Record<string, string[]> = {
  "Tecnologia": ["ti", "tecnologia", "sistema", "incidente", "chamado", "deploy", "service desk", "suporte"],
  "Operações": ["operação", "operacional", "logística", "produção", "estoque", "execução"],
  "Financeiro": ["financeiro", "pagamento", "cobrança", "conciliação", "faturamento", "tesouraria"],
  "Contabilidade": ["contábil", "contabilidade", "controladoria", "balancete", "demonstração", "dre", "ifrs", "cpc", "razão geral", "ativo imobilizado", "patrimonial", "fechamento"],
  "Atendimento": ["atendimento", "cliente", "solicitação", "sac", "reclamação"],
  "Comercial": ["comercial", "venda", "lead", "proposta", "contrato", "crm"],
  "Recursos Humanos": ["rh", "recursos humanos", "admissão", "demissão", "folha", "benefícios", "férias", "décimo terceiro"],
  "Jurídico": ["jurídico", "contrato", "cláusula", "compliance", "legal"],
  "Compras": ["compras", "fornecedor", "cotação", "pedido", "requisição"],
  "Backoffice": ["backoffice", "administrativo", "cadastro", "documentação"],
};

const STEP_CONNECTORS = ["->", "→", "=>", " | "];

const SECTION_ALIASES: Record<string, string[]> = {
  name_area: ["nome do processo e area", "nome do processo", "processo e area"],
  objective_result: [
    "objetivo principal e resultado",
    "objetivo e resultado",
    "objetivo do processo",
    "objetivo",
  ],
  owner: [
    "dono ou responsavel pelo processo",
    "dono do processo",
    "responsavel pelo processo",
    "owner do processo",
  ],
  steps: [
    "etapas do processo inicio ao fim",
    "etapas do processo",
    "passos do processo",
    "fluxo do processo",
    "etapas",
  ],
  systems_documents: [
    "sistemas planilhas e documentos utilizados",
    "sistemas planilhas documentos utilizados",
    "sistemas e documentos utilizados",
    "sistemas utilizados",
    "ferramentas utilizadas",
    "sistemas",
    "ferramentas",
    "tecnologias",
  ],
  pain_points: [
    "gargalos atrasos retrabalho erros",
    "gargalos atrasos retrabalho e erros",
    "gargalos do processo",
    "gargalos",
    "dores",
    "problemas",
  ],
  risks: [
    "riscos e impactos em caso de falha",
    "riscos impactos em caso de falha",
    "riscos e impactos",
    "riscos",
  ],
  frequency_volume_time: [
    "frequencia volume e tempo medio",
    "frequencia volume tempo medio",
    "frequencia volume e tempo",
    "frequencia volume tempo",
    "frequencia",
    "volume",
    "tempo medio",
  ],
  indicators: ["indicadores de desempenho kpis", "indicadores de desempenho", "indicadores", "kpis"],
  evidence: ["evidencias de execucao correta", "evidencias execucao correta", "documentos evidencias", "evidencias", "documentos"],
};

const FIELD_LABELS: Record<string, string[]> = {
  name: ["nome", "nome do processo"],
  area: ["área", "area"],
  objective: ["objetivo", "objetivo principal"],
  result: ["resultado"],
  owner: ["responsável", "responsavel", "dono", "owner"],
  frequency: ["frequência", "frequencia"],
  volume: ["volume"],
  time: ["tempo médio", "tempo medio", "tempo"],
};

export function normalizeText(text: string | null | undefined): string {
  return (text || "").trim();
}

function _lower(text: string | null | undefined): string {
  return normalizeText(text).toLowerCase();
}

function _ascii(text: string | null | undefined): string {
  const norm = normalizeText(text).normalize("NFD");
  return norm.replace(/[\u0300-\u036f]/g, "");
}

function _norm_key(text: string | null | undefined): string {
  const clean = _ascii(text).toLowerCase();
  const replaced = clean.replace(/[^a-z0-9]+/g, " ");
  return replaced.replace(/\s+/g, " ").trim();
}

export function splitLines(text: string | null | undefined): string[] {
  if (!text) return [];
  return text
    .split(/\r?\n/)
    .map((line) => line.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim())
    .filter((line) => line.length > 0);
}

export function uniquePreserveOrder(items: string[]): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const item of items) {
    const clean = item.replace(/\s+/g, " ").trim();
    if (clean && !seen.has(clean.toLowerCase())) {
      seen.add(clean.toLowerCase());
      result.push(clean);
    }
  }
  return result;
}

export function linesText(items: string[]): string {
  return uniquePreserveOrder(items).join("\n");
}

function _splitConnectedSteps(text: string): string[] {
  for (const connector of STEP_CONNECTORS) {
    if (text.includes(connector)) {
      return text.split(connector).map((p) => p.trim()).filter((p) => p.length > 0);
    }
  }
  return [];
}

export function splitItems(text: string): string[] {
  if (!text) return [];
  const connected = _splitConnectedSteps(text);
  if (connected.length > 0) {
    return uniquePreserveOrder(connected);
  }
  const parts: string[] = [];
  const lines = text.split(/\r?\n/);
  for (let line of lines) {
    line = line.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim();
    if (!line) continue;
    if (line.includes(":")) {
      parts.push(line);
    } else if (line.includes(";")) {
      parts.push(...line.split(";").map((p) => p.trim()).filter((p) => p.length > 0));
    } else {
      parts.push(line);
    }
  }
  return uniquePreserveOrder(parts);
}

function _isSectionHeading(line: string): string | null {
  const normalized = _norm_key(line);
  if (!normalized || normalized.length > 110) return null;
  for (const [section, aliases] of Object.entries(SECTION_ALIASES)) {
    for (const alias of aliases) {
      const alias_norm = _norm_key(alias);
      if (normalized === alias_norm || normalized.startsWith(alias_norm + " ")) {
        return section;
      }
    }
  }
  return null;
}

export function splitIntoSections(text: string): Record<string, string> {
  const sections: Record<string, string[]> = {};
  let current: string | null = null;
  const lines = normalizeText(text).split(/\r?\n/);

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    let inlineValue = "";
    let heading: string | null = null;

    if (line.includes(":")) {
      const index = line.indexOf(":");
      const maybeHeading = line.substring(0, index);
      const maybeValue = line.substring(index + 1);
      heading = _isSectionHeading(maybeHeading);
      inlineValue = maybeValue.trim();
    }

    if (!heading) {
      heading = _isSectionHeading(line);
    }

    if (heading) {
      current = heading;
      if (!sections[current]) sections[current] = [];
      if (inlineValue) {
        sections[current].push(inlineValue);
      }
      continue;
    }

    if (current) {
      if (!sections[current]) sections[current] = [];
      sections[current].push(line);
    }
  }

  const result: Record<string, string> = {};
  for (const [key, val] of Object.entries(sections)) {
    result[key] = val.join("\n").trim();
  }
  return result;
}

function _lineValueForLabels(text: string, labels: string[]): string {
  const labels_norm = new Set(labels.map((l) => _norm_key(l)));
  const lines = normalizeText(text).split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim();
    if (!line.includes(":")) continue;
    const parts = line.split(":");
    const label = parts[0];
    const value = parts.slice(1).join(":");
    if (labels_norm.has(_norm_key(label)) && value.trim()) {
      return value.trim().replace(/^[\s\-;\.\t]+|[\s\-;\.\t]+$/g, "");
    }
  }
  return "";
}

export function fieldValue(text: string, field: string, sections?: Record<string, string>): string {
  const sect = sections || splitIntoSections(text);
  const labels = FIELD_LABELS[field] || [];
  const sectionOrderMap: Record<string, string[]> = {
    name: ["name_area"],
    area: ["name_area"],
    objective: ["objective_result"],
    result: ["objective_result"],
    owner: ["owner"],
    frequency: ["frequency_volume_time"],
    volume: ["frequency_volume_time"],
    time: ["frequency_volume_time"],
  };
  const section_order = sectionOrderMap[field] || [];
  for (const section of section_order) {
    const val = _lineValueForLabels(sect[section] || "", labels);
    if (val) return val;
  }
  return _lineValueForLabels(text, labels);
}

export function sectionItems(text: string, sectionName: string, maxItems = 12): string[] {
  const sections = splitIntoSections(text);
  const section = sections[sectionName] || "";
  if (!section) return [];
  const items: string[] = [];
  const lines = section.split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim();
    if (!line) continue;
    const connected = _splitConnectedSteps(line);
    if (connected.length > 0) {
      items.push(...connected);
    } else {
      items.push(line);
    }
  }
  return uniquePreserveOrder(items).slice(0, maxItems);
}

export function extractLabeledSection(text: string, labels: string[]): string {
  const label_pattern = labels.map((l) => l.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")).join("|");
  const stop_pattern = [
    "nome do processo",
    "nome",
    "área",
    "area",
    "objetivo",
    "resultado",
    "finalidade",
    "propósito",
    "proposito",
    "etapas",
    "passos",
    "fluxo",
    "sistemas",
    "ferramentas",
    "tecnologias",
    "planilhas",
    "gargalos",
    "dores",
    "problemas",
    "riscos",
    "impactos",
    "indicadores",
    "kpis",
    "documentos",
    "evidências",
    "evidencias",
    "responsável",
    "responsavel",
    "dono",
    "owner",
    "volume",
    "tempo",
    "retrabalho",
    "frequência",
    "frequencia",
  ]
    .map((l) => l.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
    .join("|");

  const pattern = new RegExp(
    `(?:^|[\\n.;])\\s*(?:${label_pattern})\\b\\s*(?:do processo|utilizados|usados|existentes|estimado|estimada)?\\s*(?:são|sao|é|:|-)?\\s*([\\s\\S]*?)(?=(?:[\\n.;])\\s*(?:${stop_pattern})\\b|$)`,
    "i"
  );
  const match = text.match(pattern);
  if (!match) return "";
  return match[1].trim().replace(/^[\s\-:;\.\n\t]+|[\s\-:;\.\n\t]+$/g, "");
}

export function inferArea(text: string): string {
  const explicit = fieldValue(text, "area");
  if (explicit) return explicit.substring(0, 80);
  const low = _lower(text);
  let bestArea = "Operações";
  let maxScore = 0;
  for (const [area, keywords] of Object.entries(AREA_KEYWORDS)) {
    let score = 0;
    for (const kw of keywords) {
      if (low.includes(kw)) score++;
    }
    if (score > maxScore) {
      maxScore = score;
      bestArea = area;
    }
  }
  return maxScore > 0 ? bestArea : "Operações";
}

export function inferFrequency(text: string): string {
  const explicit = fieldValue(text, "frequency");
  const combined = `${_lower(explicit)} ${_lower(text)}`;
  const rules: [string, string[]][] = [
    ["Diário", ["diário", "diaria", "todo dia", "todos os dias", "diariamente"]],
    ["Semanal", ["semanal", "toda semana", "semanalmente"]],
    ["Mensal", ["mensal", "todo mês", "todo mes", "mensalmente", "month-end", "fechamento contábil mensal", "fechamento contabil mensal"]],
    ["Trimestral", ["trimestral", "trimestre"]],
    ["Anual", ["anual", "ano", "anualmente"]],
  ];
  for (const [label, keywords] of rules) {
    for (const kw of keywords) {
      if (combined.includes(kw)) return label;
    }
  }
  return "Sob demanda";
}

export function inferCriticality(text: string): string {
  const low = _lower(text);
  const criticalTerms = [
    "crítico",
    "critico",
    "parada",
    "compliance",
    "legal",
    "cvm",
    "auditoria",
    "multa",
    "demonstrações financeiras",
    "demonstracoes financeiras",
    "balanço patrimonial",
    "balanco patrimonial",
    "dre",
    "acionistas",
    "perda de credibilidade",
    "números distorcidos",
    "numeros distorcidos",
  ];
  for (const kw of criticalTerms) {
    if (low.includes(kw)) return "Crítica";
  }
  const highTerms = ["alto impacto", "alta", "risco", "atraso", "retrabalho", "perda"];
  for (const kw of highTerms) {
    if (low.includes(kw)) return "Alta";
  }
  if (low.includes("baixo impacto") || low.includes("baixa")) return "Baixa";
  return "Média";
}

export function cleanOwnerValue(val: string): string | null {
  let v = val.trim();
  if (v.includes("?")) {
    return null;
  }
  v = v.replace(/^[\s\-•\t\d\)\.\:\,\;\"\'\?]+/, "").trim();
  if (v.toLowerCase().startsWith("ou ")) {
    v = v.substring(3).trim();
  }
  if (v.toLowerCase().startsWith("e ")) {
    v = v.substring(2).trim();
  }
  if (v.toLowerCase().startsWith("pelo ") || v.toLowerCase().startsWith("pela ") || v.toLowerCase().startsWith("do ") || v.toLowerCase().startsWith("da ")) {
    return null;
  }
  const low = v.toLowerCase();
  if (
    low.includes("quem é") || 
    low.includes("qual é") || 
    low.includes("quem e") || 
    low.includes("qual e") || 
    low.includes("quais são") || 
    low.includes("quais sao") ||
    low.includes("dono do processo") ||
    low.includes("responsável pelo processo") ||
    low.includes("responsavel pelo processo") ||
    low === "dono do processo" || 
    low === "responsavel" || 
    low === "responsável" ||
    low === "owner"
  ) {
    return null;
  }
  if (v.length < 3) return null;
  return v;
}

export function cleanProcessNameValue(val: string): string | null {
  let v = val.trim();
  if (v.includes("?")) {
    return null;
  }
  v = v.replace(/^[\s\-•\t\d\)\.\:\,\;\"\'\?]+/, "").trim();
  if (v.toLowerCase().startsWith("ou ")) {
    v = v.substring(3).trim();
  }
  if (v.toLowerCase().startsWith("e ")) {
    v = v.substring(2).trim();
  }
  const low = v.toLowerCase();
  if (
    low.includes("qual é") ||
    low.includes("qual e") ||
    low.includes("quais são") ||
    low.includes("quais sao") ||
    low.includes("nome do processo") ||
    low === "processo" ||
    low === "fluxo" ||
    low === "rotina"
  ) {
    return null;
  }
  if (v.length < 3) return null;
  return v;
}

export function extractOwner(text: string): string {
  const explicit = fieldValue(text, "owner");
  if (explicit) {
    const cleaned = cleanOwnerValue(explicit);
    if (cleaned) return cleaned.substring(0, 120);
  }
  const patterns = [
    /(?:respons[aá]vel|responsavel|dono|owner)\s*(?:do processo)?\s*(?:é|:|-)?\s*([^\n.;]+)/i,
    /(?:área responsável|area responsavel)\s*(?:é|:|-)?\s*([^\n.;]+)/i,
  ];
  for (const pat of patterns) {
    const match = text.match(pat);
    if (match) {
      const val = match[1].trim();
      const cleaned = cleanOwnerValue(val);
      if (cleaned) {
        return cleaned.substring(0, 120);
      }
    }
  }
  return "Dono do processo";
}

export function extractProcessName(text: string): string {
  const explicit = fieldValue(text, "name");
  if (explicit) {
    const cleaned = cleanProcessNameValue(explicit);
    if (cleaned) return cleaned.substring(0, 100);
  }
  const patterns = [
    /(?:nome do processo)\s*(?:é|:|-)?\s*([^\n.;]+)/i,
    /(?:processo|fluxo|rotina)\s+(?:de|do|da)\s+([^\n.;]+)/i,
  ];
  for (const pat of patterns) {
    const match = text.match(pat);
    if (match) {
      const name = match[1].replace(/^[\s\-\:\.\;\,\"\']+|[\s\-\:\.\;\,\"\']+$/g, "").trim();
      const cleaned = cleanProcessNameValue(name);
      if (cleaned) {
        return cleaned[0].toUpperCase() + cleaned.substring(1);
      }
    }
  }
  const lines = splitLines(text);
  for (const rawLine of lines) {
    const cleanLine = rawLine.replace(/^(eu quero mapear|mapear|analisar|descrever)\s+/i, "").trim();
    const cleaned = cleanProcessNameValue(cleanLine);
    if (cleaned && cleaned.length >= 3) {
      return cleaned[0].toUpperCase() + cleaned.substring(1);
    }
  }
  return "Processo a validar";
}

export function extractObjective(text: string, name: string): string {
  const sections = splitIntoSections(text);
  const obj = fieldValue(text, "objective", sections);
  const res = fieldValue(text, "result", sections);
  const parts: string[] = [];
  if (obj) parts.push(`Objetivo: ${obj}`);
  if (res) parts.push(`Resultado esperado: ${res}`);
  if (parts.length > 0) return parts.join("\n").substring(0, 900);

  const sect = sections.objective_result || extractLabeledSection(text, ["objetivo principal", "objetivo", "finalidade", "propósito", "proposito", "meta"]);
  if (sect) return sect.substring(0, 900);

  // Look for Portuguese narrative statements about the process goal or intent
  const narrativeRegexes = [
    /(?:objetivo principal|objetivo principal do processo|objetivo do processo|objetivo|meta da área|meta|finalidade|propósito|proposito|intuito)\s+(?:da|do|de|é|e|seria)\s*(?:de|para)?\s*([^\n.;]+)/i,
    /(?:com o objetivo de|com o intuito de|para poder|focado em|focando em|busca-se|visa)\s+([^\n.;]+)/i,
    /(?:serve para|tem como objetivo|busca)\s+([^\n.;]+)/i,
    /(?:eu quero|queremos|precisamos|desejamos)\s*(?:com esse processo|com este mapeamento)?\s*(?:de|para|melhorar|reduzir|otimizar|organizar|resolver)\s+([^\n.;]+)/i,
  ];

  for (const regex of narrativeRegexes) {
    const m = text.match(regex);
    if (m && m[1] && m[1].trim().length > 10) {
      return m[1].trim().replace(/^[\s\.\-\:]+|[\s\.\-\:]+$/g, "").substring(0, 900);
    }
  }

  return `Executar e controlar o processo de ${name.toLowerCase()}, garantindo previsibilidade, qualidade, responsáveis claros e oportunidades de melhoria contínua.`;
}

export function extractSteps(text: string): string[] {
  const items = sectionItems(text, "steps", 15);
  if (items.length > 0) return items;

  const sect = extractLabeledSection(text, ["etapas", "passos", "fluxo"]);
  if (sect) {
    const split = splitItems(sect);
    if (split.length > 0) return split.slice(0, 15);
  }

  const explicit: string[] = [];
  let capture = false;
  const lines = text.split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    const low = line.toLowerCase();
    if (/^(etapas|passos|fluxo)\b/.test(low)) {
      capture = true;
      const index = line.indexOf(":");
      const afterColon = index !== -1 ? line.substring(index + 1) : "";
      explicit.push(...splitItems(afterColon));
      continue;
    }
    if (capture) {
      if (/^(gargalos|dores|problemas|riscos|sistemas|indicadores|documentos)\b/.test(low)) {
        capture = false;
      } else {
        explicit.push(...splitItems(line));
      }
    }
  }
  if (explicit.length > 0) {
    return uniquePreserveOrder(explicit).slice(0, 15);
  }

  const connected = _splitConnectedSteps(text);
  if (connected.length >= 2) {
    return uniquePreserveOrder(connected).slice(0, 15);
  }

  const sequence_patterns = [
    /(?:primeiro|inicia|começa|comeca)\s+([^.;]+)/i,
    /(?:depois|em seguida|na sequência|na sequencia)\s+([^.;]+)/i,
    /(?:por fim|finalmente|termina|encerra)\s+([^.;]+)/i,
  ];
  for (const pat of sequence_patterns) {
    const matches = Array.from(text.matchAll(new RegExp(pat, "gi")));
    for (const match of matches) {
      explicit.push(match[1].trim());
    }
  }
  if (explicit.length > 0) {
    return uniquePreserveOrder(explicit).slice(0, 15);
  }

  return [
    "Receber demanda ou entrada do processo",
    "Analisar informações e validar requisitos",
    "Executar atividade principal",
    "Revisar resultado e tratar pendências",
    "Registrar evidências e encerrar processo",
  ];
}

export function extractSystems(text: string): string[] {
  const low = _lower(text);
  const found = KNOWN_SYSTEMS.filter((s) => low.includes(s.toLowerCase()));
  const sect = splitIntoSections(text).systems_documents || extractLabeledSection(text, ["sistemas", "ferramentas", "tecnologias"]);
  if (sect) {
    const lines = sect.split(/\r?\n/);
    for (const line of lines) {
      if (_norm_key(line).startsWith("sistemas") || _norm_key(line).startsWith("ferramentas") || _norm_key(line).startsWith("tecnologias")) {
        const parts = line.split(":");
        const value = parts.length > 1 ? parts.slice(1).join(":") : line;
        found.push(...splitItems(value));
      }
    }
    if (found.length === 0) {
      found.push(...splitItems(sect));
    }
  }
  return uniquePreserveOrder(found.length > 0 ? found : ["Planilhas", "E-mail"]);
}

function _extractByKeywords(text: string, keywords: string[], defaults: string[], maxItems = 8): string[] {
  const candidates: string[] = [];
  const lines = text.split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim();
    const low = line.toLowerCase();
    if (keywords.some((kw) => low.includes(kw))) {
      candidates.push(line);
    }
  }
  if (candidates.length > 0) {
    return uniquePreserveOrder(candidates).slice(0, maxItems);
  }
  const low = _lower(text);
  const inferred: string[] = [];
  if (low.match(/retrabalho|erro|corrigir|inconsistente/)) {
    inferred.push("Retrabalho e correções frequentes");
  }
  if (low.match(/atraso|fila|espera|demora|pendência|pendencia/)) {
    inferred.push("Espera, filas ou atrasos entre etapas");
  }
  if (low.match(/manual|planilha|e-mail|email|whatsapp/)) {
    inferred.push("Execução manual com baixa rastreabilidade");
  }
  if (low.match(/aprovação|aprovacao|autorizar/)) {
    inferred.push("Aprovações manuais ou pouco padronizadas");
  }
  if (low.match(/dependência|dependencia|pessoa-chave|conhecimento/)) {
    inferred.push("Dependência de conhecimento informal ou pessoa-chave");
  }
  return uniquePreserveOrder(inferred.length > 0 ? inferred : defaults).slice(0, maxItems);
}

export function extractPainPoints(text: string): string[] {
  const items = sectionItems(text, "pain_points", 10);
  if (items.length > 0) return items;
  const sect = extractLabeledSection(text, ["gargalos", "dores", "problemas"]);
  if (sect) return splitItems(sect).slice(0, 10);
  return _extractByKeywords(
    text,
    ["dor", "gargalo", "problema", "retrabalho", "atraso", "fila", "manual", "demora"],
    ["Processo ainda precisa ser validado com usuários para identificar gargalos reais"]
  );
}

export function extractRisks(text: string): string[] {
  const items = sectionItems(text, "risks", 10);
  if (items.length > 0) return items;
  const sect = extractLabeledSection(text, ["riscos"]);
  if (sect) return splitItems(sect).slice(0, 10);
  return _extractByKeywords(
    text,
    ["risco", "falha", "erro", "perda", "multa", "sla", "compliance", "cliente", "cvm", "auditoria"],
    ["Perda de prazo, baixa rastreabilidade e decisões sem evidência suficiente"]
  );
}

export function extractIndicators(text: string): string[] {
  const items = sectionItems(text, "indicators", 10);
  if (items.length > 0) return items;
  const sect = extractLabeledSection(text, ["indicadores", "kpis"]);
  if (sect) return splitItems(sect).slice(0, 10);
  const low = _lower(text);
  const indicators: string[] = [];
  if (low.includes("sla")) indicators.push("SLA atendido x rompido");
  if (low.match(/tempo|atraso|demora|ciclo|days to close/)) indicators.push("Tempo médio de ciclo");
  if (low.match(/retrabalho|erro|correção|correcao|lançamentos manuais|lancamentos manuais/)) indicators.push("Taxa de retrabalho");
  if (low.match(/volume|demanda|chamado|pedido|solicitação|solicitacao|lançamentos|lancamentos/)) indicators.push("Volume mensal de demandas");
  if (low.match(/backlog|pendência|pendencia|fila/)) indicators.push("Backlog e pendências abertas");
  if (low.match(/custo|financeiro|economia|fechamento/)) indicators.push("Custo estimado por execução");
  if (indicators.length === 0) {
    return ["Volume", "Tempo de ciclo", "Retrabalho", "SLA/Prazo", "Backlog"];
  }
  return uniquePreserveOrder(indicators);
}

export function extractDocuments(text: string): string[] {
  const items = sectionItems(text, "evidence", 10);
  const sects = splitIntoSections(text);
  const sysSect = sects.systems_documents || "";
  if (sysSect) {
    const lines = sysSect.split(/\r?\n/);
    for (const line of lines) {
      if (_norm_key(line).startsWith("documentos") || _norm_key(line).startsWith("planilhas")) {
        items.push(line);
      }
    }
  }
  if (items.length > 0) return uniquePreserveOrder(items).slice(0, 10);
  const sect = extractLabeledSection(text, ["documentos", "evidências", "evidencias"]);
  if (sect) return splitItems(sect).slice(0, 10);
  const candidates: string[] = [];
  const lines = text.split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.replace(/^[\s\-•\t\d\)\.\:\,\;]+/, "").trim();
    if (line && _lower(line).match(/documento|evidência|evidencia|manual|procedimento|política|politica|checklist|balancete|dossiê|dossie/)) {
      candidates.push(line);
    }
  }
  return uniquePreserveOrder(candidates.length > 0 ? candidates : ["Checklist de execução", "Evidências de conclusão", "Procedimento operacional padrão"]).slice(0, 8);
}

function extractNumber(patterns: RegExp[], text: string, defaultValue: number): number {
  for (const pat of patterns) {
    const match = text.match(pat);
    if (match) {
      const numStr = match[1].replace(/\./g, "").replace(",", ".");
      const num = parseFloat(numStr);
      if (!isNaN(num)) return num;
    }
  }
  return defaultValue;
}

export function inferMonthlyVolume(text: string): number {
  const explicit = fieldValue(text, "volume");
  const source = `${explicit}\n${text}`;
  if (source.match(/milh(?:ar|ares)|milhões|milhoes/i)) {
    return 1000;
  }
  const match = extractNumber(
    [
      /(?:volume|demandas|chamados|pedidos|solicitações|solicitacoes|lançamentos|lancamentos).*?(\d+[\d\.,]*)/i,
      /(\d+[\d\.,]*)\s*(?:por mês|por mes|mensais|\/mês|\/mes)/i,
    ],
    source,
    0
  );
  return Math.round(match);
}

export function inferCycleTimeHours(text: string): number {
  const explicit = fieldValue(text, "time");
  const source = `${explicit}\n${text}`;
  const low = _lower(source);
  const matchRange = low.match(/(?:entre\s+o\s+)?(\d+)[ºoªa]?\s*(?:e|a|ao|até|ate)\s*(?:o\s+)?(\d+)[ºoªa]?\s*dia\s*(?:útil|util)/i);
  if (matchRange) {
    const start_day = parseInt(matchRange[1]);
    const end_day = parseInt(matchRange[2]);
    const business_days = Math.max(1, end_day - start_day + 1);
    return business_days * 8;
  }
  const matchSingle = low.match(/(\d+)[ºoªa]?\s*dia\s*(?:útil|util)/i);
  if (matchSingle) {
    return Math.max(1, parseInt(matchSingle[1])) * 8;
  }
  const matchDays = low.match(/(\d+[\d\.,]*)\s*(?:dia|dias)/i);
  if (matchDays) {
    const dVal = parseFloat(matchDays[1].replace(/\./g, "").replace(",", "."));
    if (!isNaN(dVal)) return dVal * 8;
  }
  return extractNumber(
    [
      /(?:tempo médio|tempo medio|ciclo|leva|dura).*?(\d+[\d\.,]*)\s*(?:h|hora|horas)/i,
      /(\d+[\d\.,]*)\s*(?:h|hora|horas)/i,
    ],
    source,
    0
  );
}

export function inferReworkPercentage(text: string): number {
  const value = extractNumber(
    [
      /(?:retrabalho|erro|correção|correcao).*?(\d+[\d\.,]*)\s*%/i,
      /(\d+[\d\.,]*)\s*%\s*(?:de retrabalho|retrabalho)/i,
    ],
    text,
    -1
  );
  if (value >= 0) {
    return Math.max(0, Math.min(100, value));
  }
  const low = _lower(text);
  if (low.match(/retrabalho|estorno|lançamentos errados|lancamentos errados/)) {
    return 15;
  }
  return 5;
}

export function inferLevels(text: string): {
  documentation_level: number;
  standardization_level: number;
  automation_level: number;
  control_level: number;
} {
  const low = _lower(text);
  let documentation = 1;
  let standardization = 1;
  let automation = 1;
  let control = 1;

  if (low.match(/documento|evidência|evidencia|manual|procedimento|checklist|pop|dossiê|dossie|relatório|relatorio/)) {
    documentation = 3;
  }
  if (low.match(/balancete|dre|balanço|balanco|dossiê|dossie|assinadas|validadas/)) {
    documentation = Math.max(documentation, 4);
  }

  if (low.match(/padrão|padrao|padronizado|normas contábeis|normas contabeis|ifrs|cpc|cut-off|cutoff|calendário|calendario/)) {
    standardization = 3;
  }
  if (low.match(/fast close|bloqueio definitivo|validação final|validacao final/)) {
    standardization = Math.max(standardization, 4);
  }

  if (low.match(/sistema|erp|sap|totvs|oracle|servicenow|jira|workflow|api|blackline|automatizada/)) {
    automation = 3;
  }
  if (low.match(/plataformas de conciliação automatizada|plataformas de conciliacao automatizada|automação|automacao/)) {
    automation = Math.max(automation, 4);
  }

  if (low.match(/indicador|kpi|dashboard|sla|controle|monitoramento|conciliadas|auditoria|relatório de auditoria|relatorio de auditoria/)) {
    control = 3;
  }
  if (low.match(/sem ressalvas|assinadas|validadas|auditoria interna|auditoria externa/)) {
    control = Math.max(control, 4);
  }

  return {
    documentation_level: documentation,
    standardization_level: standardization,
    automation_level: automation,
    control_level: control,
  };
}

export function buildProcessFromInterview(text: string): ProcessDraft {
  const norm = normalizeText(text);
  const name = extractProcessName(norm);
  const levels = inferLevels(norm);
  const monthly_volume = inferMonthlyVolume(norm);
  const cycle_time_hours = inferCycleTimeHours(norm);
  const rework_percentage = inferReworkPercentage(norm);

  const draft: ProcessDraft = {
    name,
    area: inferArea(norm),
    owner: extractOwner(norm),
    objective: extractObjective(norm, name),
    frequency: inferFrequency(norm),
    status: "Em diagnóstico",
    criticality: inferCriticality(norm),
    steps: linesText(extractSteps(norm)),
    systems: linesText(extractSystems(norm)),
    pain_points: linesText(extractPainPoints(norm)),
    risks: linesText(extractRisks(norm)),
    indicators: linesText(extractIndicators(norm)),
    documents: linesText(extractDocuments(norm)),
    cycle_time_hours,
    monthly_volume,
    rework_percentage: Math.max(0, Math.min(100, rework_percentage)),
    ...levels,
  };

  draft.status = inferStatus(draft, norm);
  return draft;
}

function inferStatus(process: ProcessDraft, text: string): string {
  const required = [process.name, process.owner, process.objective, process.steps, process.risks, process.indicators];
  const countExist = required.filter((item) => item && item !== "Dono do processo").length;
  if (countExist >= 5 && splitLines(process.steps).length >= 4) {
    return "Mapeado";
  }
  return "Em diagnóstico";
}

export function missingFieldsForProcess(process: ProcessDraft): string[] {
  const labels: Record<string, string> = {
    name: "nome do processo",
    owner: "responsável",
    objective: "objetivo",
    steps: "etapas",
    pain_points: "gargalos/dores",
    risks: "riscos",
    indicators: "indicadores",
    systems: "sistemas utilizados",
  };
  const missing: string[] = [];
  for (const [key, label] of Object.entries(labels)) {
    const value = (process as any)[key];
    if (!value || (typeof value === "string" && value.startsWith("Processo ainda precisa"))) {
      missing.push(label);
    }
  }
  if (process.owner === "Dono do processo") {
    missing.push("nome do responsável real");
  }
  if ((process.monthly_volume || 0) <= 0) {
    missing.push("volume mensal numérico");
  }
  if ((process.cycle_time_hours || 0) <= 0) {
    missing.push("tempo médio em horas");
  }
  return uniquePreserveOrder(missing);
}

export function buildAssumptions(process: ProcessDraft, interviewText: string): string[] {
  const assumptions: string[] = [];
  const low = _lower(interviewText);
  if (!low.includes("responsável") && !low.includes("responsavel") && process.owner === "Dono do processo") {
    assumptions.push("Responsável não foi informado; usei 'Dono do processo' como placeholder.");
  }
  if (low.match(/milhar|milhões|milhoes/)) {
    assumptions.push("Volume foi descrito como faixa ampla; usei 1.000 como placeholder para priorização e recomendo validar o número real.");
  } else if ((process.monthly_volume || 0) <= 0) {
    assumptions.push("Volume mensal não foi informado em número; deixei 0 para evitar falsa precisão.");
  }
  if ((process.cycle_time_hours || 0) <= 0) {
    assumptions.push("Tempo médio de ciclo não foi informado em horas e deve ser validado com a operação.");
  } else if (low.includes("dia útil") || low.includes("dia util")) {
    assumptions.push("Tempo médio foi convertido de dias úteis para horas usando 8 horas por dia útil.");
  }
  if (!low.includes("retrabalho")) {
    assumptions.push("Retrabalho foi estimado em nível conservador e deve ser medido posteriormente.");
  }
  if (process.status === "Em diagnóstico") {
    assumptions.push("Status inicial definido como 'Em diagnóstico' para orientar a validação do processo.");
  } else {
    assumptions.push("Status inicial definido como 'Mapeado' porque a descrição trouxe nome, área, responsável, objetivo, etapas, riscos e indicadores.");
  }
  return assumptions;
}

export function buildFollowUpQuestions(missingFields: string[]): string[] {
  if (missingFields.length === 0) {
    return ["As informações estão suficientes para uma primeira versão. Valide o desenho com o dono do processo antes de automatizar."];
  }
  const questionMap: Record<string, string> = {
    "nome do processo": "Qual nome curto e claro representa melhor este processo?",
    responsável: "Quem é o dono do processo e quem deve aprovar mudanças nele?",
    "nome do responsável real": "Qual pessoa ou área será responsável por manter este processo atualizado?",
    objetivo: "Qual resultado o processo precisa entregar e para quem?",
    etapas: "Quais são as etapas do início ao fim, na ordem em que acontecem?",
    "gargalos/dores": "Onde há mais atraso, retrabalho, espera, erro ou dependência manual?",
    riscos: "O que acontece se o processo falhar? Existe impacto em SLA, cliente, financeiro ou compliance?",
    indicadores: "Hoje vocês medem prazo, volume, retrabalho, SLA, backlog ou custo?",
    "sistemas utilizados": "Quais sistemas, planilhas ou canais são usados durante o processo?",
    "volume mensal numérico": "Qual é o volume mensal aproximado em número? Ex.: 500 lançamentos, 1.200 notas ou 80 solicitações.",
    "tempo médio em horas": "Qual é o tempo médio real do ciclo em horas ou dias úteis?",
  };
  return missingFields.map((f) => questionMap[f] || `Detalhe melhor: ${f}.`);
}

function criticalityWeight(criticality: string | null | undefined): number {
  const mapping: Record<string, number> = {
    baixa: 20,
    média: 45,
    media: 45,
    alta: 70,
    crítica: 90,
    critica: 90,
  };
  return mapping[(criticality || "").trim().toLowerCase()] || 45;
}

export function calculateProcessScores(process: ProcessDraft): ProcessScores {
  const documentation_level = process.documentation_level || 1;
  const standardization_level = process.standardization_level || 1;
  const automation_level = process.automation_level || 1;
  const control_level = process.control_level || 1;
  const indicator_bonus = splitLines(process.indicators).length > 0 ? 1 : 0;

  const matScore =
    (documentation_level / 5) * 25 +
    (standardization_level / 5) * 25 +
    (automation_level / 5) * 20 +
    (control_level / 5) * 20 +
    indicator_bonus * 10;
  const maturity_score = Math.round(Math.max(0, Math.min(100, matScore)));

  const critWeight = criticalityWeight(process.criticality);
  const risksBonus = Math.min(splitLines(process.risks).length * 8, 24);
  const reworkBonus = Math.min((process.rework_percentage || 0) * 0.8, 24);
  const cycleBonus = Math.min((process.cycle_time_hours || 0) * 0.6, 18);
  const risk_score = Math.round(Math.max(0, Math.min(100, critWeight + risksBonus + reworkBonus + cycleBonus)));

  const manuality = (6 - Math.max(1, Math.min(5, automation_level))) * 12;
  const volume_score = Math.min((process.monthly_volume || 0) / 10, 35);
  const pain_score = Math.min(splitLines(process.pain_points).length * 8, 24);
  const rework_score = Math.min((process.rework_percentage || 0) * 0.7, 21);
  const automation_score = Math.round(Math.max(0, Math.min(100, manuality + volume_score + pain_score + rework_score)));

  const priority_score = Math.round(Math.max(0, Math.min(100, risk_score * 0.45 + automation_score * 0.4 + (100 - maturity_score) * 0.15)));

  let maturity_stage = "Informal";
  if (maturity_score >= 85) maturity_stage = "Otimizado";
  else if (maturity_score >= 65) maturity_stage = "Gerenciado";
  else if (maturity_score >= 45) maturity_stage = "Medido parcialmente";
  else if (maturity_score >= 25) maturity_stage = "Documentação inicial";

  let priority_label = "Prioridade baixa";
  if (priority_score >= 75) priority_label = "Prioridade alta";
  else if (priority_score >= 50) priority_label = "Prioridade média";

  const estimated_rework_hours_month = Math.round((process.monthly_volume || 0) * (process.cycle_time_hours || 0) * ((process.rework_percentage || 0) / 100) * 100) / 100;

  return {
    maturity_score,
    risk_score,
    automation_score,
    priority_score,
    maturity_stage,
    priority_label,
    estimated_rework_hours_month,
  };
}

export function buildRecommendations(process: ProcessDraft, scores: ProcessScores): string[] {
  const recommendations: string[] = [];
  if (scores.maturity_score < 50) {
    recommendations.push("Formalizar o processo com etapas, responsáveis, entradas, saídas e critérios de qualidade.");
  }
  if (splitLines(process.indicators).length === 0) {
    recommendations.push("Definir indicadores mínimos: volume, tempo de ciclo, retrabalho, SLA e pendências em aberto.");
  }
  if (scores.risk_score >= 70) {
    recommendations.push("Criar plano de mitigação para riscos críticos, com responsável, prazo e evidência de controle.");
  }
  if (scores.automation_score >= 70) {
    recommendations.push("Priorizar automação das etapas repetitivas de maior volume antes de expandir o processo.");
  }
  if ((process.rework_percentage || 0) >= 15) {
    recommendations.push("Investigar causas de retrabalho e criar checklist preventivo na entrada do processo.");
  }
  if ((process.documentation_level || 1) <= 2) {
    recommendations.push("Gerar POP, matriz RACI e documentação de treinamento para reduzir dependência de pessoas-chave.");
  }
  if ((process.control_level || 1) <= 2) {
    recommendations.push("Implantar pontos de controle, alertas de atraso e revisão periódica dos indicadores.");
  }
  if (recommendations.length === 0) {
    recommendations.push("Manter monitoramento contínuo e revisar oportunidades de otimização a cada ciclo mensal.");
  }
  return recommendations;
}

export function generateContinuousImprovementAnalysis(process: ProcessDraft, scores: ProcessScores): ContinuousImprovementAnalysis {
  const text = `${process.name} ${process.objective} ${process.steps} ${process.systems} ${process.pain_points} ${process.risks} ${process.indicators} ${process.documents}`.toLowerCase();
  
  // Wastes
  const lean_wastes: string[] = [];
  const reworkVal = process.rework_percentage || 0;
  const cycleVal = process.cycle_time_hours || 0;
  const volVal = process.monthly_volume || 0;

  if (reworkVal >= 10 || text.match(/retrabalho|erro|falha|reabertura|ajuste|inconsistente/)) {
    lean_wastes.push("Defeitos e retrabalho: há sinais de falhas, correções ou baixa qualidade na entrada/execução.");
  }
  if (cycleVal >= 24 || text.match(/atraso|espera|fila|pendência|pendencia|sla rompido|aprovação manual|aprovacao manual/)) {
    lean_wastes.push("Espera e atrasos: o processo aparenta ter etapas paradas, aprovações lentas ou tempo de ciclo elevado.");
  }
  if (text.match(/muitas aprovações|muitas aprovacoes|validação repetida|validacao repetida|duplicidade|duplo lançamento|duplo lancamento/)) {
    lean_wastes.push("Processamento excessivo: existem indícios de validações, aprovações ou atividades repetidas além do necessário.");
  }
  if (text.match(/transferência|transferencias|handoff|grupos|grupo responsável|e-mail|email|whatsapp/)) {
    lean_wastes.push("Handoffs e transferências: há passagem de trabalho entre áreas/canais que pode gerar perda de contexto.");
  }
  if (text.match(/backlog|fila|pendências|pendencias|acumulado/) || volVal >= 500) {
    lean_wastes.push("Estoque, filas e backlog: o volume ou a fila operacional podem estar criando acúmulo de trabalho.");
  }
  if (text.match(/planilha|evidência|evidencia|procurar|buscar|documento|manual/)) {
    lean_wastes.push("Busca manual de informação: há esforço para localizar dados, documentos ou evidências fora do fluxo.");
  }
  if (text.match(/dependência|dependencia|pessoa-chave|pessoa chave|conhecimento informal/)) {
    lean_wastes.push("Talento/conhecimento subutilizado: o conhecimento parece concentrado em pessoas, criando risco de continuidade.");
  }
  if (text.match(/relatório manual|relatorio manual|informação sem uso|informacao sem uso/)) {
    lean_wastes.push("Produção de informação sem uso claro: pode haver geração de controles ou relatórios sem decisão associada.");
  }
  if (lean_wastes.length === 0) {
    lean_wastes.push("Nenhum desperdício Lean crítico foi inferido pelas regras atuais; recomenda-se validar em entrevista com a área.");
  }

  // CBOK
  const cbok_gaps: string[] = [];
  const docLevel = process.documentation_level || 1;
  const stdLevel = process.standardization_level || 1;
  const autLevel = process.automation_level || 1;
  const ctrlLevel = process.control_level || 1;

  if (docLevel <= 2 || splitLines(process.steps).length < 3) {
    cbok_gaps.push("Modelagem e documentação: detalhar fluxo, entradas, saídas, regras de negócio, exceções e evidências.");
  }
  if (stdLevel <= 2) {
    cbok_gaps.push("Desenho e padronização: definir padrão de execução, critérios de qualidade, handoffs e papéis por etapa.");
  }
  if (ctrlLevel <= 2 || splitLines(process.indicators).length === 0) {
    cbok_gaps.push("Gestão de desempenho: criar indicadores, metas, cadência de análise e responsáveis por cada métrica.");
  }
  if (scores.risk_score >= 65 || splitLines(process.risks).length > 0) {
    cbok_gaps.push("Governança e controle: explicitar riscos, controles preventivos, responsáveis, política de evidências e Auditoria.");
  }
  if (scores.automation_score >= 65 && autLevel <= 3) {
    cbok_gaps.push("Tecnologia e transformação: avaliar automações, integrações e redução de atividades manuais repetitivas.");
  }
  if (splitLines(process.pain_points).length > 0) {
    cbok_gaps.push("Análise de processos: investigar causas raiz dos gargalos antes de redesenhar ou automatizar o fluxo.");
  }
  if (cbok_gaps.length === 0) {
    cbok_gaps.push("Maturidade BPM adequada para o estágio atual; manter ciclo contínuo de medição, revisão e melhoria.");
  }

  // Causes
  const root_cause_hypotheses: string[] = [];
  if (reworkVal >= 15) {
    root_cause_hypotheses.push("Retrabalho pode estar ligado a critérios de entrada pouco claros, falta de checklist ou qualidade inconsistente das solicitações.");
  }
  if (scores.risk_score >= 70) {
    root_cause_hypotheses.push("Risco elevado pode estar relacionado a controles insuficientes, evidências frágeis ou dependência excessiva de validação manual.");
  }
  if (scores.automation_score >= 70) {
    root_cause_hypotheses.push("Potencial de automação alto sugere tarefas repetitivas, alto volume ou uso de sistemas desconectados.");
  }
  if (text.match(/transferência|grupos|handoff|e-mail|email|whatsapp/)) {
    root_cause_hypotheses.push("Handoffs entre áreas/canais podem estar causando perda de contexto, fila e aumento do tempo de ciclo.");
  }
  if (docLevel <= 2) {
    root_cause_hypotheses.push("Baixa documentação pode gerar variação na execução, treinamento informal e dificuldade de escalar a operação.");
  }
  if (root_cause_hypotheses.length === 0) {
    root_cause_hypotheses.push("As causas raiz ainda precisam ser validadas com dados de execução e entrevistas com usuários do processo.");
  }

  // SIPOC
  const steps = splitLines(process.steps);
  const systems = splitLines(process.systems);
  const indicators = splitLines(process.indicators);
  const owner = process.owner || "Dono do processo";
  const area = process.area || "Operações";

  const sipoc = {
    Fornecedores: [owner, `Áreas demandantes de ${area}`, "Sistemas e bases de dados envolvidos"],
    Entradas: splitLines(process.documents).slice(0, 3).concat(systems.slice(0, 3)),
    Processo: steps.length > 0 ? steps : ["Mapear etapas do processo"],
    Saídas: indicators.slice(0, 3).concat(["Entrega validada", "Evidência do processo"]),
    Clientes: ["Gestores da área", "Usuários internos", "Áreas impactadas pelo resultado"],
  };
  if (sipoc.Entradas.length === 0) {
    sipoc.Entradas = ["Solicitação", "Dados de entrada", "Regra de negócio"];
  }

  // SUGGESTED KPIS
  const suggested_kpis = [
    "Lead time / tempo médio de ciclo",
    "Volume executado por período",
    "Percentual de retrabalho",
    "Backlog ou pendências em aberto",
    "Cumprimento de SLA/prazo",
  ];
  if (text.match(/erro|falha|ajuste|qualidade|retrabalho/)) suggested_kpis.push("Taxa de erro ou não conformidade");
  if (text.match(/aprovação|aprovacao|validação|validacao/)) suggested_kpis.push("Tempo médio de aprovação/validação");
  if (text.match(/transferência|grupo|handoff/)) suggested_kpis.push("Quantidade de handoffs por execução");
  if (text.match(/custo|financeiro|contabilidade|fechamento/)) suggested_kpis.push("Custo estimado por execução");

  // DMAIC
  const dmaic_plan = {
    Define: `Definir o problema central do ${process.name}, escopo, cliente impactado, meta de melhoria e patrocinador do processo.`,
    Measure: "Medir lead time, volume, retrabalho, SLA, backlog, erros e variação entre executores antes de propor solução.",
    Analyze: "Usar Pareto, 5 Porquês e análise de causa raiz para separar sintomas de causas reais dos gargalos.",
    Improve: "Executar melhorias de baixo esforço primeiro: padronização, checklist, redução de handoffs, automação simples e ajuste de regras.",
    Control: `Criar rotina de controle com indicadores, responsável, frequência de revisão e gatilhos de ação. Prioridade atual: ${scores.priority_label}.`,
  };

  // PDCA
  const pdca_cycle = {
    Plan: "Selecionar uma dor prioritária, definir meta mensurável, responsável, prazo e hipótese de melhoria.",
    Do: "Testar a melhoria em pequena escala, preferencialmente em um fluxo ou equipe piloto.",
    Check: "Comparar indicadores antes/depois: tempo, retrabalho, SLA, fila, esforço manual e percepção do usuário.",
    Act: "Padronizar a melhoria se houver ganho, ajustar se o resultado for parcial ou abandonar se não gerar valor.",
  };

  // Project Charter
  const project_charter = {
    Problema: `O processo ${process.name} apresenta oportunidades de melhoria em maturidade, risco, automação ou controle.`,
    Objetivo: "Reduzir desperdícios, aumentar previsibilidade, melhorar controle e preparar o fluxo para automação segura.",
    "Escopo inicial": "Mapear AS IS, validar SIPOC, priorizar gargalos, criar indicadores mínimos e testar quick wins.",
    "Fora do escopo inicial": "Automação complexa, integração profunda com sistemas e redesenho organizacional sem validação prévia.",
    "Dono sugerido": owner,
    "Critério de sucesso": `Elevar maturidade, reduzir risco/retrabalho e melhorar a prioridade operacional atual (${scores.priority_score}/100).`,
  };

  // ACTIONS
  const actions: ImprovementAction[] = [];
  const _scoreValue = (imp: number, eff: number, urg: number) => Math.round(imp * 11 + urg * 8 - eff * 5);

  if (docLevel <= 3) {
    actions.push({
      title: "Criar SIPOC e mapa AS IS validado",
      framework: "CBOK + SIPOC",
      why: "Sem uma visão clara de fornecedores, entradas, etapas, saídas e clientes, a melhoria vira opinião.",
      expected_benefit: "Clareza de escopo, redução de ambiguidade e base para redesenho do processo.",
      impact: 4,
      effort: 2,
      urgency: 4,
      value_score: _scoreValue(4, 2, 4),
      suggested_owner: owner,
      first_step: "Reunir responsável, executor e cliente interno para validar as etapas reais do processo.",
      metric: "% de etapas validadas com dono e evidência",
    });
  }

  if (reworkVal >= 10) {
    actions.push({
      title: "Implantar checklist de qualidade na entrada",
      framework: "Lean + Poka-Yoke",
      why: "Retrabalho costuma nascer de entradas incompletas, critérios pouco claros ou ausência de validação preventiva.",
      expected_benefit: "Menos retrabalho, menos devoluções e melhor qualidade desde o início do fluxo.",
      impact: 5,
      effort: 2,
      urgency: 5,
      value_score: _scoreValue(5, 2, 5),
      suggested_owner: owner,
      first_step: "Listar os cinco erros mais comuns e transformá-los em checklist obrigatório de entrada.",
      metric: "% de retrabalho e quantidade de devoluções",
    });
  }

  if (scores.risk_score >= 65) {
    actions.push({
      title: "Criar matriz de riscos e controles do processo",
      framework: "Gestão de riscos + CBOK",
      why: "Riscos sem controle definido aumentam exposição operacional, perda de prazo e fragilidade de auditoria.",
      expected_benefit: "Mais segurança, previsibilidade e rastreabilidade sobre decisões e evidências críticas.",
      impact: 5,
      effort: 3,
      urgency: 5,
      value_score: _scoreValue(5, 3, 5),
      suggested_owner: owner,
      first_step: "Classificar riscos por probabilidade, impacto, controle existente, dono e evidência necessária.",
      metric: "% de riscos críticos com controle e dono definidos",
    });
  }

  if (scores.automation_score >= 60) {
    actions.push({
      title: "Montar radar de automação por impacto e esforço",
      framework: "Lean Automation + Matriz impacto/esforço",
      why: "Automatizar sem priorização pode consumir esforço em tarefas que não resolvem a dor principal.",
      expected_benefit: "Backlog de automações mais pragmático, com quick wins antes de integrações complexas.",
      impact: 4,
      effort: 2,
      urgency: 4,
      value_score: _scoreValue(4, 2, 4),
      suggested_owner: owner,
      first_step: "Separar tarefas repetitivas, regras claras e alto volume para avaliar automação simples primeiro.",
      metric: "Horas manuais potencialmente reduzidas por mês",
    });
  }

  if (ctrlLevel <= 3 || indicators.length === 0) {
    actions.push({
      title: "Definir painel mínimo de gestão do processo",
      framework: "BPM Performance Management + OKR/KPI",
      why: "Sem indicador e rotina de acompanhamento, o processo só é percebido quando o problema aparece.",
      expected_benefit: "Gestão ativa de prazo, volume, retrabalho, SLA e fila operacional.",
      impact: 5,
      effort: 3,
      urgency: 4,
      value_score: _scoreValue(5, 3, 4),
      suggested_owner: owner,
      first_step: "Escolher de 3 a 5 indicadores e definir meta, fonte, frequência e responsável por cada um.",
      metric: "% de indicadores com meta, fonte e dono definidos",
    });
  }

  if (scores.priority_score >= 50) {
    actions.push({
      title: "Executar ciclo Kaizen de 15 dias",
      framework: "Kaizen + PDCA",
      why: "Melhorias pequenas, rápidas e validadas reduzem risco antes de grandes mudanças no fluxo.",
      expected_benefit: "Ganho incremental, aprendizado rápido e engajamento da equipe operacional.",
      impact: 4,
      effort: 2,
      urgency: 4,
      value_score: _scoreValue(4, 2, 4),
      suggested_owner: owner,
      first_step: "Escolher uma dor específica, definir meta simples e testar uma melhoria em piloto.",
      metric: "Resultado antes/depois da dor priorizada",
    });
  }

  if (actions.length === 0) {
    actions.push({
      title: "Manter rotina mensal de melhoria contínua",
      framework: "PDCA + Governança BPM",
      why: "Mesmo processos maduros precisam de revisão contínua para não perder aderência ao negócio.",
      expected_benefit: "Sustentação da maturidade e identificação precoce de novas oportunidades.",
      impact: 3,
      effort: 2,
      urgency: 2,
      value_score: _scoreValue(3, 2, 2),
      suggested_owner: owner,
      first_step: "Agendar revisão mensal de indicadores e registrar decisões de melhoria.",
      metric: "Quantidade de melhorias avaliadas por mês",
    });
  }

  // Sort actions by value_score descending
  actions.sort((a, b) => b.value_score - a.value_score);

  const quick_wins = actions.filter((a) => a.impact >= 4 && a.effort <= 2).slice(0, 5);

  let health_label = "Monitoramento contínuo";
  if (scores.priority_score >= 75) health_label = "Atenção executiva imediata";
  else if (scores.priority_score >= 50) health_label = "Melhoria recomendada";

  const top_action = actions.length > 0 ? actions[0].title : "manter monitoramento";
  const executive_summary =
    `O processo apresenta maturidade ${scores.maturity_score}/100, risco ${scores.risk_score}/100, ` +
    `potencial de automação ${scores.automation_score}/100 e prioridade ${scores.priority_score}/100. ` +
    `A principal recomendação é: ${top_action}. O foco deve ser gerar valor por melhoria contínua, ` +
    `reduzindo desperdícios, retrabalho, riscos e esforço manual antes de investir em automações complexas.`;

  return {
    executive_summary,
    health_label,
    lean_wastes,
    cbok_gaps,
    root_cause_hypotheses,
    sipoc,
    suggested_kpis,
    dmaic_plan,
    pdca_cycle,
    project_charter,
    actions,
    quick_wins,
  };
}

export function buildAssistantResult(interview_text: string): AssistantResult {
  const process = buildProcessFromInterview(interview_text);
  const missing = missingFieldsForProcess(process);
  const assumptions = buildAssumptions(process, interview_text);
  const questions = buildFollowUpQuestions(missing);

  // Calculate scores
  const scores = calculateProcessScores(process);

  // Confidence calculation
  let conf = 35;
  conf += Math.min(splitLines(process.steps).length * 4, 24);
  conf += process.owner && process.owner !== "Dono do processo" ? 10 : 0;
  conf += process.area && process.area !== "Operações" ? 8 : 0;
  conf += splitLines(process.pain_points).length > 1 ? 8 : 0;
  conf += splitLines(process.risks).length > 1 ? 8 : 0;
  conf += splitLines(process.indicators).length > 1 ? 8 : 0;
  conf += interview_text.split(/\s+/).length >= 60 ? 5 : 0;
  conf += process.monthly_volume > 0 ? 4 : 0;
  conf += process.cycle_time_hours > 0 ? 4 : 0;
  const confidence = Math.max(35, Math.min(95, conf));

  // Graphviz representation template as fallback or display
  const stepsList = splitLines(process.steps);
  const flow_markdown = stepsList.length > 0 ? stepsList.join(" → ") : "Receber demanda → Executar → Encerrar";

  let dot_lines = [
    'digraph Processo {',
    '  graph [rankdir=LR, bgcolor="transparent", pad="0.2", nodesep="0.35", ranksep="0.45"];',
    '  node [shape=box, style="rounded,filled", color="#1E3A8A", fillcolor="#EFF6FF", fontname="Arial", fontsize=10];',
    '  edge [color="#1E3A8A", arrowsize=0.8];',
    '  start [label="Início", shape=circle, fillcolor="#DCFCE7", color="#16A34A"];',
    '  end [label="Fim", shape=doublecircle, fillcolor="#F1F5F9", color="#334155"];',
  ];
  let previous = "start";
  stepsList.forEach((st, idx) => {
    const node = `step_${idx + 1}`;
    let label = st.replace(/[\"']/g, "").trim();
    if (label.length > 55) label = label.substring(0, 54) + "…";
    dot_lines.push(`  ${node} [label="${idx + 1}. ${label}"];`);
    dot_lines.push(`  ${previous} -> ${node};`);
    previous = node;
  });
  dot_lines.push(`  ${previous} -> end;`);
  dot_lines.push("}");
  const flow_dot = dot_lines.join("\n");

  const ci = generateContinuousImprovementAnalysis(process, scores);
  const smartDetected = detectSmartObjective(process.objective, interview_text);

  return {
    process,
    confidence,
    missing_fields: missing,
    assumptions,
    questions,
    flow_dot,
    flow_markdown,
    // Compatibility fields
    processName: process.name,
    objective: process.objective,
    steps: stepsListInOrder(process.steps),
    metrics: {
      confidenceScore: confidence,
      reworkEst: process.rework_percentage,
    },
    sipoc: {
      Suppliers: ci.sipoc.Fornecedores,
      Inputs: ci.sipoc.Entradas,
      Process: process.name || "Fluxo de Trabalho",
      Outputs: ci.sipoc.Saídas,
      Customers: ci.sipoc.Clientes,
    },
    smartDetected,
  };
}

// Helper to keep code robust and types clean
function stepsListInOrder(stepsStr: string): string[] {
  return splitLines(stepsStr);
}

export function buildExecutiveReport(process: ProcessDraft, scores: ProcessScores): string {
  const recommendations = buildRecommendations(process, scores);
  const ci = generateContinuousImprovementAnalysis(process, scores);
  const today = new Date().toLocaleDateString("pt-BR");

  const bulletLines = (text: string | null | undefined) => {
    const lines = splitLines(text);
    if (lines.length === 0) return "- Não informado";
    return lines.map((l) => `- ${l}`).join("\n");
  };

  const listLines = (items: string[]) => {
    if (items.length === 0) return "- Não informado";
    return items.map((l) => `- ${l}`).join("\n");
  };

  const actions_md = ci.actions
    .slice(0, 6)
    .map(
      (action) =>
        `- **${action.title}** (${action.framework}) — valor ${action.value_score}/100. ` +
        `Métrica: ${action.metric}. Primeiro passo: ${action.first_step}`
    )
    .join("\n");

  const sipoc_md = Object.entries(ci.sipoc)
    .map(([key, value]) => `**${key}:** ${value.join(", ")}`)
    .join("\n\n");

  const dmaic_md = Object.entries(ci.dmaic_plan)
    .map(([phase, desc]) => `- **${phase}:** ${desc}`)
    .join("\n");

  const pdca_md = Object.entries(ci.pdca_cycle)
    .map(([phase, desc]) => `- **${phase}:** ${desc}`)
    .join("\n");

  return `# Relatório Executivo — ${process.name}

**Data:** ${today}  
**Área:** ${process.area}  
**Responsável:** ${process.owner}  
**Status:** ${process.status}  
**Criticidade:** ${process.criticality}

## 1. Objetivo do processo

${process.objective || "Objetivo não informado."}

## 2. Diagnóstico resumido

O processo apresenta **score de maturidade ${scores.maturity_score}/100**, classificado como **${scores.maturity_stage}**. 
O risco operacional estimado é **${scores.risk_score}/100** e o potencial de automação é **${scores.automation_score}/100**. 
A prioridade consolidada é **${scores.priority_score}/100**, com classificação **${scores.priority_label}**.

**Leitura executiva:** ${ci.executive_summary}

## 3. Indicadores estimados

- Tempo médio de ciclo: ${process.cycle_time_hours || 0} horas
- Volume mensal estimado: ${process.monthly_volume || 0} ocorrências
- Retrabalho estimado: ${process.rework_percentage || 0}%
- Horas mensais potencialmente impactadas por retrabalho: ${scores.estimated_rework_hours_month} horas

## 4. Etapas informadas

${bulletLines(process.steps)}

## 5. Principais dores

${bulletLines(process.pain_points)}

## 6. Riscos identificados

${bulletLines(process.risks)}

## 7. Indicadores existentes ou sugeridos

${bulletLines(process.indicators)}

## 8. Recomendações prioritárias

${recommendations.map((r) => `- ${r}`).join("\n")}

## 9. Inteligência de melhoria contínua

### 9.1 Desperdícios Lean inferidos

${listLines(ci.lean_wastes)}

### 9.2 Lacunas orientadas por gestão de processos / CBOK

${listLines(ci.cbok_gaps)}

### 9.3 Hipóteses de causa raiz

${listLines(ci.root_cause_hypotheses)}

### 9.4 SIPOC inicial

${sipoc_md}

### 9.5 Plano DMAIC sugerido

${dmaic_md}

### 9.6 Ciclo PDCA sugerido

${pdca_md}

### 9.7 Backlog inicial de melhoria contínua

${actions_md}

### 9.8 KPIs recomendados

${listLines(ci.suggested_kpis)}

## 10. Mini Project Charter

**Problema:** ${ci.project_charter.Problema}
**Objetivo:** ${ci.project_charter.Objetivo}
**Escopo inicial:** ${ci.project_charter["Escopo inicial"]}
**Fora do escopo inicial:** ${ci.project_charter["Fora do escopo inicial"]}
**Dono sugerido:** ${ci.project_charter["Dono sugerido"]}
**Critério de sucesso:** ${ci.project_charter["Critério de sucesso"]}

## 11. Próximos passos sugeridos

1. Validar o mapa do processo com o responsável da área.
2. Confirmar os desperdícios Lean em uma entrevista curta com executores reais.
3. Priorizar as dores com maior impacto no tempo, custo, risco e experiência do usuário.
4. Rodar um ciclo Kaizen/PDCA de baixo esforço antes de automações complexas.
5. Criar painel mínimo de controle e revisar os indicadores mensalmente.
`;
}
