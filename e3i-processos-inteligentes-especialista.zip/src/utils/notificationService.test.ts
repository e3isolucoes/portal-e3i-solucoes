/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect, beforeEach } from "vitest";
import {
  NotificationEventPayload,
  dispatchNotificationEvent,
  runFullQueueTick,
  generateDailyDigestForUser,
  executeDeadlineEscalationCheck,
  notificationQueue,
  notificationLogs,
  deadLetterQueue,
  processedKeys,
  setSecureSmtpPassword,
  getSecureSmtpPassword,
  smtpConfigurations,
  userPreferences,
  escalationRules,
  templates,
  DeadlineTask,
  NotificationRule,
  generateIdempotencyKey
} from "./notificationService";

describe("Fase 13: Central Notification Engine & Deliveries Test Suit", () => {
  beforeEach(() => {
    // Reset state before each test
    notificationQueue.length = 0;
    notificationLogs.length = 0;
    deadLetterQueue.length = 0;
    processedKeys.clear();

    // Default mock setup
    setSecureSmtpPassword("ALGAR_TECH", "algar-smtp-secure-9102");
    setSecureSmtpPassword("VALE_SA", "vale-iron-vault-781");

    // Clear and restore original configs
    smtpConfigurations["ALGAR_TECH"] = {
      companyId: "ALGAR_TECH",
      host: "smtp.algartech.com.br",
      port: 587,
      tls: true,
      username: "notificador@algartech.com.br",
      senderEmail: "notificador@algartech.com.br",
      senderName: "Algar Tech DMAIC Hub",
      limitRatePerSec: 10,
      allowedDomains: ["algartech.com.br", "e3i.com", "gmail.com"],
      retryPolicy: "exponential",
      maxRetries: 3,
      backoffMs: 10
    };

    smtpConfigurations["VALE_SA"] = {
      companyId: "VALE_SA",
      host: "smtp.vale.com",
      port: 465,
      tls: true,
      username: "governance@vale.com",
      senderEmail: "governance@vale.com",
      senderName: "Vale Lean Platform",
      limitRatePerSec: 5,
      allowedDomains: ["vale.com", "corasa.com.br"],
      retryPolicy: "fixed",
      maxRetries: 2,
      backoffMs: 20
    };
  });

  it("should deliver notification successfully when SMTP configuration is valid", () => {
    const payload: NotificationEventPayload = {
      id: "EV-001",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: {
        empresa: "Algar Tech",
        projeto: "Otimização Service Desk",
        fase: "Define",
        tarefa: "Esboçar SIPOC",
        responsavel: "responsavel@algartech.com.br"
      },
      recipients: ["responsavel@algartech.com.br"],
      correlationId: "TASK-123"
    };

    const res = dispatchNotificationEvent(payload);
    expect(res.createdCount).toBe(2); // Internal and Email (user pref default has two channels)
    expect(notificationQueue.length).toBe(2);

    // Run queue tick
    const tick = runFullQueueTick();
    expect(tick.succeeded).toBe(2);
    expect(notificationQueue[0].status).toBe("Entregue");
  });

  it("should fail delivery and register in DLQ when SMTP credentials are invalid", () => {
    // Set invalid credentials
    setSecureSmtpPassword("ALGAR_TECH", "errado-password");

    const payload: NotificationEventPayload = {
      id: "EV-002",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: {
        empresa: "Algar Tech",
        tarefa: "Esboçar SIPOC",
        responsavel: "responsavel@algartech.com.br"
      },
      recipients: ["responsavel@algartech.com.br"]
    };

    dispatchNotificationEvent(payload);

    // 1st Attempt: fails, schedules retry
    const tick1 = runFullQueueTick();
    expect(tick1.processed).toBe(2);
    expect(tick1.succeeded).toBe(0);
    expect(notificationQueue[0].status).toBe("Aguardando envio");
    expect(notificationQueue[0].attempts).toBe(1);

    // Bypass wait timer artificially
    notificationQueue.forEach(n => { n.nextAttemptAt = undefined; });

    // 2nd Attempt: fails, schedules retry
    runFullQueueTick();
    notificationQueue.forEach(n => { n.nextAttemptAt = undefined; });

    // 3rd Attempt: fails, schedules retry
    runFullQueueTick();
    notificationQueue.forEach(n => { n.nextAttemptAt = undefined; });

    // 4th Attempt: exceeds limit (maxRetries: 3), flags DLQ
    const tickLast = runFullQueueTick();
    expect(tickLast.dlqCount).toBe(2);
    expect(notificationQueue[0].status).toBe("Falhou");
    expect(deadLetterQueue.length).toBe(2);
  });

  it("should gracefully handle SMTP host timeout and trigger retries", () => {
    smtpConfigurations["ALGAR_TECH"].host = "timeout.smtp.com";

    const payload: NotificationEventPayload = {
      id: "EV-003",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: { empresa: "Algar Tech", tarefa: "Lógica" },
      recipients: ["responsavel@algartech.com.br"]
    };

    dispatchNotificationEvent(payload);
    const tick = runFullQueueTick();
    expect(tick.succeeded).toBe(0);
    expect(notificationQueue[0].status).toBe("Aguardando envio");
    expect(notificationQueue[0].errHistory[0]).toContain("Connection timeout");
  });

  it("should support and test secure TLS SMTP connection parameters", () => {
    // Switch VALE to TLS
    const cfg = smtpConfigurations["VALE_SA"];
    expect(cfg.tls).toBe(true);
    expect(cfg.port).toBe(465);

    const payload: NotificationEventPayload = {
      id: "EV-VALE-01",
      companyId: "VALE_SA",
      event: "Tarefa criada",
      metadata: { empresa: "Vale SA", tarefa: "Inspeção Mina" },
      recipients: ["coordenador@vale.com"]
    };

    dispatchNotificationEvent(payload);
    const tick = runFullQueueTick();
    expect(tick.succeeded).toBe(1); // defaulted to Email only
  });

  it("should mark notification as Cancelled when receiver domain is not authorized", () => {
    const payload: NotificationEventPayload = {
      id: "EV-004",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: { empresa: "Algar Tech", tarefa: "Faturar" },
      recipients: ["hacker@unknown-domain.com"]
    };

    dispatchNotificationEvent(payload);
    const tick = runFullQueueTick();
    expect(tick.succeeded).toBe(0);
    expect(notificationQueue[0].status).toBe("Cancelada");
    expect(notificationQueue[0].errHistory[0]).toContain("Destinatário inválido para o domínio permitido");
  });

  it("should prevent duplicate event transmission via robust Idempotency controls", () => {
    const payload: NotificationEventPayload = {
      id: "EV-DUPLICATE",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: { empresa: "Algar Tech" },
      recipients: ["responsavel@algartech.com.br"]
    };

    const res1 = dispatchNotificationEvent(payload);
    expect(res1.createdCount).toBe(2);

    // Duplicate call immediately
    const res2 = dispatchNotificationEvent(payload);
    expect(res2.createdCount).toBe(0);
    expect(res2.duplicateSkipped).toBe(1);
  });

  it("should assemble, dispatch and resolve user Daily Digests correctly", () => {
    const recipient = "responsavel@algartech.com.br";
    const payload1: NotificationEventPayload = {
      id: "DIG-01",
      companyId: "ALGAR_TECH",
      event: "Tarefa criada",
      metadata: { empresa: "Algar", tarefa: "Limpar" },
      recipients: [recipient]
    };
    const payload2: NotificationEventPayload = {
      id: "DIG-02",
      companyId: "ALGAR_TECH",
      event: "Tarefa atribuída",
      metadata: { empresa: "Algar", tarefa: "Aferir" },
      recipients: [recipient]
    };

    dispatchNotificationEvent(payload1);
    dispatchNotificationEvent(payload2);

    expect(notificationQueue.length).toBe(4); // 2 channels each

    const digest = generateDailyDigestForUser(recipient, "ALGAR_TECH");
    expect(digest.clearedCount).toBe(4); // clean non-mandatory list
    expect(digest.digestSubject).toContain("Resumo Diário");
    expect(digest.digestBody).toContain("Limpar");
    expect(digest.digestBody).toContain("Aferir");

    // All original non-mandatory ones are now successfully cleared
    expect(notificationQueue.every(n => n.status === "Entregue")).toBe(true);
  });

  it("should process and verify chronological Escalation periods and Substitutes", () => {
    const task: DeadlineTask = {
      id: "TASK-ESC-X",
      name: "Análise de Variância ANOVA",
      companyId: "ALGAR_TECH",
      projectId: "PROJ-91",
      projectName: "Redução de Scrap",
      phaseName: "Analyze",
      responsibleEmail: "responsavel@algartech.com.br",
      leaderEmail: "lider@algartech.com.br",
      managerEmail: "gestor@algartech.com.br",
      sponsorEmail: "patrocinador@algartech.com.br",
      deadlineDate: "2026-06-15T00:00:00Z"
    };

    const rule: NotificationRule = {
      id: "R-ESC",
      companyId: "ALGAR_TECH",
      eventName: "Prazo vencido",
      daysBefore: 3,
      sendTime: "09:00",
      weekdaysOnly: false,
      timezone: "America/Sao_Paulo",
      repeat: false,
      escalationEnabled: true,
      alertLimit: 10,
      recipients: ["responsavel@algartech.com.br"],
      substituteManager: "substituto@algartech.com.br" // custom substitute configured
    };

    // Test 3 days before
    const esc1 = executeDeadlineEscalationCheck(task, "2026-06-12T09:00:00Z", rule);
    expect(esc1.triggeredLogs[0]).toContain("3 dias antes");
    expect(esc1.sentCount).toBe(2); // Internal + Email

    // Test deadline today
    const esc2 = executeDeadlineEscalationCheck(task, "2026-06-15T09:00:00Z", rule);
    expect(esc2.triggeredLogs[0]).toContain("Vencimento hoje");

    // Test 1 day after -> responsible and leader
    const esc3 = executeDeadlineEscalationCheck(task, "2026-06-16T09:00:00Z", rule);
    expect(esc3.triggeredLogs[0]).toContain("1 dia depois");

    // Test 3 days after -> substitute manager instead of main manager
    const esc4 = executeDeadlineEscalationCheck(task, "2026-06-18T09:00:00Z", rule);
    expect(esc4.triggeredLogs[0]).toContain("substituto@algartech.com.br");

    // Test 7 days after -> sponsor
    const esc5 = executeDeadlineEscalationCheck(task, "2026-06-22T09:00:00Z", rule);
    expect(esc5.triggeredLogs[0]).toContain("patrocinador");
  });

  it("should block mailing during weekends if weekdaysOnly constraint is true", () => {
    const task: DeadlineTask = {
      id: "TASK-ESC-SUNDAY",
      name: "ANOVA",
      companyId: "ALGAR_TECH",
      projectId: "PROJ-91",
      projectName: "Scrap",
      phaseName: "Analyze",
      responsibleEmail: "responsavel@algartech.com.br",
      leaderEmail: "lider@algartech.com.br",
      managerEmail: "gestor@algartech.com.br",
      sponsorEmail: "patrocinador@algartech.com.br",
      deadlineDate: "2026-06-15T00:00:00Z"
    };

    const rule: NotificationRule = {
      id: "R-ESC",
      companyId: "ALGAR_TECH",
      eventName: "Prazo vencido",
      daysBefore: 3,
      sendTime: "09:00",
      weekdaysOnly: true, // ONLY weekdays
      timezone: "America/Sao_Paulo",
      repeat: false,
      escalationEnabled: true,
      alertLimit: 10,
      recipients: ["responsavel@algartech.com.br"]
    };

    // June 14, 2026 is Sunday, daysDiff is -1
    const esc = executeDeadlineEscalationCheck(task, "2026-06-14T09:00:00Z", rule);
    expect(esc.triggeredLogs[0]).toContain("Cancelado: Envio cancelado devido a restrição de dias úteis");
  });

  it("should bypass disabled preferences if the notification is labeled Mandatory", () => {
    const recipient = "alvo-preferencia-desativada@algartech.com.br"; // user disabled Task created
    const payload: NotificationEventPayload = {
      id: "EV-MANDATORY-BYPASS",
      companyId: "ALGAR_TECH",
      event: "Evento de segurança", // security incident is MANDATORY
      metadata: { empresa: "Algar Tech" },
      recipients: [recipient]
    };

    const res = dispatchNotificationEvent(payload);
    expect(res.createdCount).toBe(1); // delivered successfully bypass preference veto
  });

  it("should enforce company isolation (independent configs and templates)", () => {
    // Algar has host, Vale has host
    expect(smtpConfigurations["ALGAR_TECH"].host).not.toBe(smtpConfigurations["VALE_SA"].host);
    expect(smtpConfigurations["ALGAR_TECH"].senderName).toContain("Algar");
    expect(smtpConfigurations["VALE_SA"].senderName).toContain("Vale");
  });
});
