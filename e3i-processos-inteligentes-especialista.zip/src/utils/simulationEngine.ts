/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// --- DOMAIN TYPES & SCHEMAS FOR SIMULATION ENGINE ---

export type NodeType = "start" | "task" | "gateway" | "end";

export type DistributionConfig =
  | { type: "constant"; value: number }
  | { type: "uniform"; min: number; max: number }
  | { type: "triangular"; min: number; max: number; mode: number }
  | { type: "normal"; mean: number; standardDeviation: number }
  | { type: "exponential"; rate: number }
  | { type: "poisson"; lambda: number }
  | { type: "beta"; alpha: number; beta: number; min?: number; max?: number }
  | { type: "weibull"; shape: number; scale: number }
  | { type: "empirical"; observations: number[] };

export interface BPMNNode {
  id: string;
  name: string;
  type: NodeType;
  gatewayType?: "XOR" | "AND" | "OR";
  distribution?: DistributionConfig;
  resource?: string; // resource ID or capacity name required
  resourceCount?: number; // fallback capacity
  costPerMinute?: number;
  setupTime?: number;
  yieldRate?: number; // 0 to 1 for TASK quality check
  exceptionHandlerId?: string; // Redirect error flows here
}

export interface GatewayRoute {
  id: string;
  gatewayId: string;
  targetNodeId: string;
  condition?: string; // Condition text like "rework", "ok", or JS-evaluate-alike
  probability?: number; // 0 to 100
  priority?: number; // for OR/XOR ordering
  isDefault: boolean;
}

export interface SimulationConfig {
  runs: number; // replication count
  horizon: number; // working duration in simulated TimeUnit
  timeUnit: "minutes" | "hours" | "days";
  seed: number;
  resourceCapacities: Record<string, number>;
  initialCount: number; // WIP initially in system
  arrivalRate: number; // arrivals per hour
  workCalendar?: {
    shiftStart: number; // minute of the day
    shiftEnd: number; // minute of the day
  };
  downtimeIntervals?: {
    resourceName: string;
    mtbf: number; // Mean Time Between Failures (minutes)
    mttr: number; // Mean Time To Repair (minutes)
  }[];
  resourceCosts: Record<string, number>; // Cost per hour
  queueLimits?: Record<string, number>; // Maximum items in queue before rejection/bypass
}

// Result models
export interface NodeSimulationMetrics {
  nodeId: string;
  nodeName: string;
  visits: number;
  processingTimeMean: number;
  waitingTimeMean: number;
  waitingTimeMax: number;
  totalCost: number;
  reworkCount: number;
  rejectedCount: number; // due to queue limits
}

export interface SimulationResult {
  version: string;
  engineVersion: string;
  seed: number;
  executedAt: string;
  userEmail: string;
  companyId: string;
  projectId: string;
  parameters: {
    runs: number;
    horizon: number;
    arrivalRate: number;
  };
  metrics: {
    cycleTimeMean: number;
    cycleTimeMedian: number;
    cycleTime95Percentile: number;
    queueTimeMean: number;
    throughput: number;
    wipMean: number;
    totalReworks: number;
    totalCostMean: number;
    defectPercentage: number;
    bottlenecks: string[];
    resourceUtilizations: Record<string, number>;
    confidenceInterval: {
      lower: number;
      upper: number;
    };
  };
  nodeMetrics: NodeSimulationMetrics[];
  scenariosComparison?: {
    variationPercentage: number;
    direction: "improvement" | "degradation" | "neutral";
    recommendations: string[];
  };
}

// Deterministic PRNG using Mulberry32 for complete mathematical reproducibility
export class PRNG {
  private seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  // Returns range [0, 1)
  next(): number {
    let t = (this.seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
}

// Helper to generate gamma variables
function sampleGamma(alpha: number, prng: PRNG): number {
  if (alpha < 1) {
    return sampleGamma(alpha + 1, prng) * Math.pow(prng.next() || 0.0001, 1 / alpha);
  }
  const d = alpha - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  while (true) {
    const u1 = prng.next() || 0.0001;
    const u2 = prng.next();
    const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    const v = 1 + c * z;
    if (v <= 0) continue;
    const v3 = v * v * v;
    const u = prng.next() || 0.0001;
    if (u < 1 - 0.0331 * Math.pow(z, 4)) return d * v3;
    if (Math.log(u) < 0.5 * z * z + d * (1 - v3 + Math.log(v3))) return d * v3;
  }
}

// Sample duration from the statistical distributions config
export function sampleDistribution(config: DistributionConfig, prng: PRNG): number {
  switch (config.type) {
    case "constant":
      return Math.max(0, config.value);

    case "uniform":
      return Math.max(0, config.min + prng.next() * (config.max - config.min));

    case "triangular": {
      const u = prng.next();
      const { min, max, mode } = config;
      if (max === min) return min;
      const F = (mode - min) / (max - min);
      if (u < F) {
        return Math.max(0, min + Math.sqrt(u * (max - min) * (mode - min)));
      } else {
        return Math.max(0, max - Math.sqrt((1 - u) * (max - min) * (max - mode)));
      }
    }

    case "normal": {
      const u1 = prng.next() || 0.0001;
      const u2 = prng.next();
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      return Math.max(0.01, config.mean + z * config.standardDeviation);
    }

    case "exponential": {
      const u = prng.next() || 0.0001;
      if (config.rate <= 0) return 0.1;
      return Math.max(0.01, -Math.log(u) / config.rate);
    }

    case "poisson": {
      // For lambda > 30, use gaussian approximation for runtime safety and speed
      if (config.lambda > 30) {
        const u1 = prng.next() || 0.0001;
        const u2 = prng.next();
        const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
        return Math.max(0, Math.round(config.lambda + z * Math.sqrt(config.lambda)));
      }
      const L = Math.exp(-config.lambda);
      let k = 0;
      let p = 1;
      do {
        k++;
        p *= prng.next() || 0.0001;
      } while (p > L && k < 1000);
      return Math.max(0, k - 1);
    }

    case "beta": {
      const x = sampleGamma(Math.max(0.1, config.alpha), prng);
      const y = sampleGamma(Math.max(0.1, config.beta), prng);
      const base = x / (x + y || 0.0001);
      const min = config.min !== undefined ? config.min : 0;
      const max = config.max !== undefined ? config.max : 1;
      return Math.max(0, min + base * (max - min));
    }

    case "weibull": {
      const u = prng.next() || 0.0001;
      if (config.scale <= 0 || config.shape <= 0) return 0.1;
      return Math.max(0.01, config.scale * Math.pow(-Math.log(u), 1 / config.shape));
    }

    case "empirical": {
      const obs = config.observations;
      if (!obs || obs.length === 0) return 1.0;
      const idx = Math.floor(prng.next() * obs.length);
      return Math.max(0, obs[idx]);
    }

    default:
      return 1.0;
  }
}

// Validate routes and gateway setup
export interface RouteValidationError {
  nodeId?: string;
  routeId?: string;
  severity: "error" | "warning";
  type:
    | "negative_probability"
    | "sum_mismatch"
    | "no_outputs"
    | "missing_destination"
    | "infinite_loop"
    | "missing_default"
    | "conflicting_conditions"
    | "disconnected_element";
  message: string;
}

export function validateBPMNRoutes(nodes: BPMNNode[], routes: GatewayRoute[]): RouteValidationError[] {
  const errors: RouteValidationError[] = [];
  const startNode = nodes.find((n) => n.type === "start");
  const endNodes = nodes.filter((n) => n.type === "end");

  // Validate negative probabilities & missing targets
  routes.forEach((route) => {
    if (route.probability !== undefined && route.probability < 0) {
      errors.push({
        nodeId: route.gatewayId,
        routeId: route.id,
        severity: "error",
        type: "negative_probability",
        message: `A rota para "${route.targetNodeId}" possui probabilidade negativa: ${route.probability}%`,
      });
    }

    const destinationExists = nodes.some((n) => n.id === route.targetNodeId);
    if (!destinationExists) {
      errors.push({
        nodeId: route.gatewayId,
        routeId: route.id,
        severity: "error",
        type: "missing_destination",
        message: `A rota de saída de "${route.gatewayId}" não possui um nó de destino válido (${route.targetNodeId}).`,
      });
    }
  });

  // Validate Gateways specifically
  const gateways = nodes.filter((n) => n.type === "gateway");
  gateways.forEach((gateway) => {
    const gatewayRoutes = routes.filter((r) => r.gatewayId === gateway.id);

    if (gatewayRoutes.length === 0) {
      errors.push({
        nodeId: gateway.id,
        severity: "error",
        type: "no_outputs",
        message: `O gateway "${gateway.name || gateway.id}" não possui nenhuma rota de saída cadastrada.`,
      });
      return;
    }

    // XOR or OR specifics
    if (gateway.gatewayType === "XOR" || gateway.gatewayType === "OR") {
      const hasDefault = gatewayRoutes.some((r) => r.isDefault);
      const isProbabilityBased = gatewayRoutes.every((r) => r.probability !== undefined || r.isDefault);

      if (!hasDefault && gatewayRoutes.length > 1) {
        errors.push({
          nodeId: gateway.id,
          severity: "warning",
          type: "missing_default",
          message: `O gateway "${gateway.name || gateway.id}" não possui uma rota padrão (isDefault) de escape.`,
        });
      }

      if (gateway.gatewayType === "XOR" && isProbabilityBased) {
        // sum probability of non-defaults should equal 100% (or including default)
        const totalProb = gatewayRoutes.reduce((sum, r) => sum + (r.probability || 0), 0);
        if (totalProb !== 100) {
          // If a default exists, the non-default sum can be less than 100% and we subtract it, but if it exceeds it, or if no default exists and it is not 100
          if (!hasDefault || totalProb > 100) {
            errors.push({
              nodeId: gateway.id,
              severity: "error",
              type: "sum_mismatch",
              message: `A soma das probabilidades de saída do gateway "${gateway.name}" é de ${totalProb}%. Deve ser exatamente 100%.`,
            });
          }
        }
      }

      // Check conflicting equal conditions
      const conditions = gatewayRoutes.map((r) => r.condition).filter(Boolean);
      const uniqueConditions = new Set(conditions);
      if (conditions.length !== uniqueConditions.size) {
        errors.push({
          nodeId: gateway.id,
          severity: "warning",
          type: "conflicting_conditions",
          message: `O gateway "${gateway.name || gateway.id}" possui condições duplicadas ou conflitantes.`,
        });
      }
    }
  });

  // Check isolated elements (Disconnected)
  // Simple DFS from Start and reverse DFS from End
  const adj: Record<string, string[]> = {};
  const revAdj: Record<string, string[]> = {};

  nodes.forEach((n) => {
    adj[n.id] = [];
    revAdj[n.id] = [];
  });

  routes.forEach((r) => {
    if (adj[r.gatewayId] && adj[r.targetNodeId]) {
      adj[r.gatewayId].push(r.targetNodeId);
      revAdj[r.targetNodeId].push(r.gatewayId);
    }
  });

  // Forward paths from all Task nodes as well
  nodes.forEach((node) => {
    if (node.type === "task") {
      // Find default route or matching outbound from here
      const outbound = routes.filter((r) => r.gatewayId === node.id);
      outbound.forEach((route) => {
        if (adj[node.id] && adj[route.targetNodeId]) {
          adj[node.id].push(route.targetNodeId);
          revAdj[route.targetNodeId].push(node.id);
        }
      });
      // Register exception Handler routing as dynamically reachable target
      if (node.exceptionHandlerId && adj[node.id] && adj[node.exceptionHandlerId]) {
        adj[node.id].push(node.exceptionHandlerId);
        revAdj[node.exceptionHandlerId].push(node.id);
      }
    }
  });

  const reachedFromStart = new Set<string>();
  const canReachEnd = new Set<string>();

  function dfsStart(u: string) {
    if (reachedFromStart.has(u)) return;
    reachedFromStart.add(u);
    (adj[u] || []).forEach(dfsStart);
  }

  function dfsEnd(u: string) {
    if (canReachEnd.has(u)) return;
    canReachEnd.add(u);
    (revAdj[u] || []).forEach(dfsEnd);
  }

  if (startNode) {
    dfsStart(startNode.id);
  }

  endNodes.forEach((end) => dfsEnd(end.id));

  nodes.forEach((node) => {
    if (!reachedFromStart.has(node.id)) {
      errors.push({
        nodeId: node.id,
        severity: "error",
        type: "disconnected_element",
        message: `O elemento "${node.name || node.id}" não é alcançável a partir do nó inicial (Start).`,
      });
    } else if (!canReachEnd.has(node.id)) {
      // Endless traps or dead-ends
      errors.push({
        nodeId: node.id,
        severity: "error",
        type: "disconnected_element",
        message: `O elemento "${node.name || node.id}" não possui caminhos válidos que finalizem em um nó de término (End).`,
      });
    }
  });

  // Infinite Cycle detection (No exit loops, cycle of size 2 or higher containing tasks without external bypasses)
  // Since rework and loops are allowed, loops themselves aren't validation errors unless there is NO exits
  // A cycle with no escape route. If from all nodes in cycle, they exclusively point to each other
  nodes.forEach((node) => {
    if (node.type === "gateway" || node.type === "task") {
      const visited = new Set<string>();
      let foundPathToEnd = false;

      function checkPath(u: string) {
        if (nodeNodesAreEnd(u)) {
          foundPathToEnd = true;
          return;
        }
        if (visited.has(u)) return;
        visited.add(u);
        (adj[u] || []).forEach(checkPath);
      }

      function nodeNodesAreEnd(id: string) {
        return nodes.find((n) => n.id === id)?.type === "end";
      }

      checkPath(node.id);
      if (!foundPathToEnd && reachedFromStart.has(node.id)) {
        errors.push({
          nodeId: node.id,
          severity: "error",
          type: "infinite_loop",
          message: `Ciclo infinito absoluto detectado a partir do nó "${node.name}". Não há caminhos de saída rumo ao término do processo.`,
        });
      }
    }
  });

  return errors;
}

// --- DES SIMULATION ENGINE IMPLEMENTATION ---

interface SimEvent {
  time: number;
  type: "arrival" | "task_complete" | "resource_available" | "downtime_start" | "downtime_end";
  tokenId: string;
  nodeId: string;
  resourceName?: string;
}

interface SimToken {
  id: string;
  createTime: number;
  entryTime: number;
  currentNodeId: string;
  travelHistory: {
    nodeId: string;
    waitingTime: number;
    processingTime: number;
    costSpent: number;
  }[];
  consecutiveReworks: Record<string, number>;
  activeParallelBranches: number; // for AND joins
}

export function runDiscreteEventSimulation(
  nodes: BPMNNode[],
  routes: GatewayRoute[],
  config: SimulationConfig,
  metadata?: { userEmail?: string; companyId?: string; projectId?: string; modelVersion?: string }
): SimulationResult {
  const prng = new PRNG(config.seed);

  // Constants
  const ENGINE_VERSION = "E3I-SIM-10.0-PRO";
  const MODEL_VERSION = metadata?.modelVersion || "1.0.0";
  const horizonMinutes = config.horizon * (config.timeUnit === "hours" ? 60 : config.timeUnit === "days" ? 1440 : 1);

  // Setup resource pools
  const resourcesAvailable: Record<string, number> = { ...config.resourceCapacities };
  const resourceMax: Record<string, number> = { ...config.resourceCapacities };
  const resourceBusyTime: Record<string, number> = {};
  const activeDowntime: Record<string, boolean> = {};

  Object.keys(resourceMax).forEach((r) => {
    resourceBusyTime[r] = 0;
    activeDowntime[r] = false;
  });

  // Check validation first
  const routesErrors = validateBPMNRoutes(nodes, routes);
  const fatalErrors = routesErrors.filter((e) => e.severity === "error");
  if (fatalErrors.length > 0) {
    throw new Error(`Erro de Validação de Domínio: A simulação não pode ser iniciada devido a erros de rota. Primeiro erro: ${fatalErrors[0].message}`);
  }

  // Node records map for tracking metrics
  const nodeVisits: Record<string, number> = {};
  const nodeProcessingTimes: Record<string, number[]> = {};
  const nodeWaitingTimes: Record<string, number[]> = {};
  const nodeReworkCounts: Record<string, number> = {};
  const nodeRejections: Record<string, number> = {};
  const nodeCosts: Record<string, number> = {};

  nodes.forEach((n) => {
    nodeVisits[n.id] = 0;
    nodeProcessingTimes[n.id] = [];
    nodeWaitingTimes[n.id] = [];
    nodeReworkCounts[n.id] = 0;
    nodeRejections[n.id] = 0;
    nodeCosts[n.id] = 0;
  });

  const completedCycles: number[] = [];
  const completedCosts: number[] = [];
  let totalWipOverTime = 0;
  let wipObservationsCount = 0;
  let reworksCount = 0;

  // Queue storage per task node
  const queues: Record<string, SimToken[]> = {};
  nodes.forEach((n) => {
    if (n.type === "task") queues[n.id] = [];
  });

  // AND parallel gateways state tracking
  // gatewayId -> tokenUniqueFamilyId -> array of route IDs received
  const parallelJoins: Record<string, Record<string, string[]>> = {};

  // Event list (sorted by time)
  const eventList: SimEvent[] = [];

  function scheduleEvent(evt: SimEvent) {
    eventList.push(evt);
    eventList.sort((a, b) => a.time - b.time);
  }

  // Arrival Generator (Start Node)
  const startNode = nodes.find((n) => n.type === "start");
  if (startNode) {
    // Generate initial queue if requested
    for (let i = 0; i < config.initialCount; i++) {
      const tokenId = `token-init-${i}`;
      scheduleArrival(0, tokenId);
    }

    // Program scheduled arrivals through the horizon
    let nextArrivalTime = 0;
    const arrivalRatePerMinute = config.arrivalRate / 60; // default rate
    let tokenIndex = 0;

    while (nextArrivalTime < horizonMinutes) {
      // Exponential distribution of inter-arrival times: -ln(U) / lambda
      const u = prng.next() || 0.0001;
      const interArrival = -Math.log(u) / arrivalRatePerMinute;
      nextArrivalTime += interArrival;

      if (nextArrivalTime < horizonMinutes) {
        scheduleArrival(nextArrivalTime, `token-${tokenIndex++}`);
      }
    }
  }

  function scheduleArrival(time: number, tokenId: string) {
    scheduleEvent({
      time,
      type: "arrival",
      tokenId,
      nodeId: startNode?.id || "",
    });
  }

  // Schedule resource downtime events if configure
  if (config.downtimeIntervals) {
    config.downtimeIntervals.forEach((dt) => {
      let nextMtbf = sampleDistribution({ type: "exponential", rate: 1 / dt.mtbf }, prng);
      while (nextMtbf < horizonMinutes) {
        scheduleEvent({
          time: nextMtbf,
          type: "downtime_start",
          tokenId: "",
          nodeId: "",
          resourceName: dt.resourceName,
        });
        const mttrValue = sampleDistribution({ type: "exponential", rate: 1 / dt.mttr }, prng);
        scheduleEvent({
          time: nextMtbf + mttrValue,
          type: "downtime_end",
          tokenId: "",
          nodeId: "",
          resourceName: dt.resourceName,
        });
        nextMtbf += mttrValue + sampleDistribution({ type: "exponential", rate: 1 / dt.mtbf }, prng);
      }
    });
  }

  // Active tokens record lookup board
  const tokensMap: Record<string, SimToken> = {};

  // Track resource utilization over time
  // List of state changes for integration
  let lastTime = 0;

  // Run the Event Loop!
  while (eventList.length > 0) {
    const event = eventList.shift()!;
    const currentTime = event.time;

    if (currentTime > horizonMinutes) break;

    // Integrate WIP and resource usage over time
    const sliceDuration = currentTime - lastTime;
    if (sliceDuration > 0) {
      const currentWip = Object.values(tokensMap).filter((t) => t.currentNodeId).length;
      totalWipOverTime += currentWip * sliceDuration;
      wipObservationsCount += sliceDuration;

      // Integrate busy resources time
      Object.keys(resourceMax).forEach((rName) => {
        const busyCount = resourceMax[rName] - resourcesAvailable[rName];
        resourceBusyTime[rName] += busyCount * sliceDuration;
      });
    }
    lastTime = currentTime;

    switch (event.type) {
      case "downtime_start": {
        const rName = event.resourceName!;
        activeDowntime[rName] = true;
        // Reduce available pool immediately (can turn negative to simulate preemptive/waiting logic)
        resourcesAvailable[rName]--;
        break;
      }

      case "downtime_end": {
        const rName = event.resourceName!;
        activeDowntime[rName] = false;
        resourcesAvailable[rName]++;
        // Trigger potential queue releases
        triggerQueueCheck(currentTime, rName);
        break;
      }

      case "arrival": {
        // Token entry point
        const token: SimToken = {
          id: event.tokenId,
          createTime: currentTime,
          entryTime: currentTime,
          currentNodeId: startNode?.id || "",
          travelHistory: [],
          consecutiveReworks: {},
          activeParallelBranches: 1,
        };
        tokensMap[token.id] = token;
        nodeVisits[startNode?.id || ""]++;

        // Shift token past start node to its target destination
        routeTokenOut(currentTime, token, startNode?.id || "");
        break;
      }

      case "task_complete": {
        const token = tokensMap[event.tokenId];
        if (!token) break;

        const node = nodes.find((n) => n.id === event.nodeId)!;
        const resourceName = node.resource || "";

        // Sample processing time
        const duration = node.distribution ? sampleDistribution(node.distribution, prng) : 10;
        const setupDuration = node.setupTime || 0;
        const totalTaskDuration = duration + setupDuration;

        // Release resource
        if (resourceName && resourceMax[resourceName] !== undefined) {
          resourcesAvailable[resourceName]++;
          triggerQueueCheck(currentTime, resourceName);
        }

        // Quality check based on yieldRate (LSS Six Sigma)
        let isDefective = false;
        if (node.yieldRate !== undefined && node.yieldRate < 1) {
          isDefective = prng.next() > node.yieldRate;
        }

        // Calculate cost: operation cost + duration * resourceCostHour
        const rCostPerHour = config.resourceCosts[resourceName] || 0;
        const taskCost = totalTaskDuration * (node.costPerMinute || 0) + (totalTaskDuration * rCostPerHour) / 60;

        nodeVisits[node.id]++;
        nodeProcessingTimes[node.id].push(totalTaskDuration);
        nodeCosts[node.id] += taskCost;

        // Save segment log to token
        const wait = currentTime - token.entryTime - totalTaskDuration;
        nodeWaitingTimes[node.id].push(Math.max(0, wait));

        token.travelHistory.push({
          nodeId: node.id,
          waitingTime: Math.max(0, wait),
          processingTime: totalTaskDuration,
          costSpent: taskCost,
        });

        if (isDefective) {
          reworksCount++;
          nodeReworkCounts[node.id] = (nodeReworkCounts[node.id] || 0) + 1;
          token.consecutiveReworks[node.id] = (token.consecutiveReworks[node.id] || 0) + 1;

          // REP LIMIT: Break infinite loops if limit exceeded
          const loopLimit = 3; // Max 3 loops budget
          if (token.consecutiveReworks[node.id] > loopLimit) {
            nodeRejections[node.id]++;
            // Reroute to alternative termination/exception handler if defined
            const altPath = node.exceptionHandlerId || nodes.find((n) => n.type === "end" && n.name.toLowerCase().includes("erro"))?.id;
            if (altPath) {
              token.entryTime = currentTime;
              token.currentNodeId = altPath;
              nodeVisits[altPath]++;
              finalizeTermination(currentTime, token);
            } else {
              // Direct kill token
              delete tokensMap[token.id];
            }
            break;
          } else {
            // Self-retry representing immediate manual rework
            transferToNode(currentTime, token, node.id);
            break;
          }
        }

        routeTokenOut(currentTime, token, node.id, isDefective);
        break;
      }
    }
  }

  // Accumulate idle queues and finalize metrics
  function triggerQueueCheck(time: number, rName: string) {
    if (activeDowntime[rName]) return; // locked

    // Check all Tasks requiring this resource
    nodes.forEach((n) => {
      if (n.type === "task" && n.resource === rName) {
        const queue = queues[n.id];
        while (queue && queue.length > 0 && resourcesAvailable[rName] > 0) {
          const nextTok = queue.shift()!;
          resourcesAvailable[rName]--;

          const nodeDist = n.distribution || { type: "constant", value: 10 };
          const pDuration = sampleDistribution(nodeDist, prng);
          const setup = n.setupTime || 0;

          scheduleEvent({
            time: time + pDuration + setup,
            type: "task_complete",
            tokenId: nextTok.id,
            nodeId: n.id,
          });
        }
      }
    });
  }

  function routeTokenOut(time: number, token: SimToken, fromNodeId: string, isRework: boolean = false) {
    // Find outbound route paths
    const outGates = routes.filter((r) => r.gatewayId === fromNodeId);

    if (outGates.length === 0) {
      // Direct task sequence check if task output connects directly without explicit gateway
      const sequentialTaskRoute = routes.find((r) => r.gatewayId === fromNodeId);
      if (sequentialTaskRoute) {
        transferToNode(time, token, sequentialTaskRoute.targetNodeId);
      } else {
        // Alternative fallback termination
        finalizeTermination(time, token);
      }
      return;
    }

    const currentFromNode = nodes.find((n) => n.id === fromNodeId);

    // GATEWAY ROUTING ENGINE
    if (currentFromNode?.type === "gateway") {
      const gType = currentFromNode.gatewayType || "XOR";

      if (gType === "XOR") {
        // Determine single correct route
        let targetRoute: GatewayRoute | null = null;

        // Check if condition based or probability based
        const isProb = outGates.every((r) => r.probability !== undefined || r.isDefault);

        if (isProb) {
          const roll = prng.next() * 100;
          let cumulative = 0;
          const defaultRoute = outGates.find((r) => r.isDefault);

          for (const route of outGates) {
            if (route.isDefault) continue;
            cumulative += route.probability || 0;
            if (roll <= cumulative) {
              targetRoute = route;
              break;
            }
          }

          if (!targetRoute && defaultRoute) {
            targetRoute = defaultRoute;
          }
        } else {
          // Conditions evaluation (simulate matching logic)
          // Look at priority or first match
          const sortedGates = [...outGates].sort((a, b) => (a.priority || 99) - (b.priority || 99));
          const hasReworkActive = isRework || Object.values(token.consecutiveReworks).some((c) => c > 0);

          for (const r of sortedGates) {
            if (r.isDefault) continue;
            // Simulated triggers
            if (r.condition === "rework" && hasReworkActive) {
              targetRoute = r;
              break;
            }
            if (r.condition === "normal" && !hasReworkActive) {
              targetRoute = r;
              break;
            }
            // Prioritize priority codes
            if (r.condition && r.condition.includes(">")) {
              targetRoute = r;
              break;
            }
          }

          if (!targetRoute) {
            targetRoute = outGates.find((r) => r.isDefault) || outGates[0];
          }
        }

        if (targetRoute) {
          transferToNode(time, token, targetRoute.targetNodeId);
        }
      } else if (gType === "AND") {
        // Fork fork fork all parallel paths
        outGates.forEach((route) => {
          const branchToken: SimToken = {
            ...token,
            id: `${token.id}-br-${route.id}`,
            activeParallelBranches: outGates.length,
          };
          tokensMap[branchToken.id] = branchToken;
          transferToNode(time, branchToken, route.targetNodeId);
        });
        // Remove parent container
        delete tokensMap[token.id];
      } else if (gType === "OR") {
        // OR gateway: sample combinations of active paths
        const activeRoutes = outGates.filter((route) => {
          if (route.isDefault) return false;
          // Sample based on probability or prioritary triggers
          if (route.probability !== undefined) {
             return prng.next() * 100 <= route.probability;
          }
          return prng.next() > 0.4; // 60% probability fallback
        });

        const routesToTake = activeRoutes.length > 0 ? activeRoutes : [outGates.find((r) => r.isDefault) || outGates[0]];
        routesToTake.forEach((route) => {
          const branchToken: SimToken = {
            ...token,
            id: `${token.id}-or-${route.id}`,
          };
          tokensMap[branchToken.id] = branchToken;
          transferToNode(time, branchToken, route.targetNodeId);
        });
        delete tokensMap[token.id];
      }
    } else {
      // Sequential task output
      const target = outGates[0]?.targetNodeId;
      if (target) transferToNode(time, token, target);
    }
  }

  function transferToNode(time: number, token: SimToken, targetNodeId: string) {
    const node = nodes.find((n) => n.id === targetNodeId)!;
    token.currentNodeId = targetNodeId;
    token.entryTime = time;

    if (node.type === "end") {
      nodeVisits[node.id]++;
      finalizeTermination(time, token);
    } else if (node.type === "gateway") {
      nodeVisits[node.id]++;
      routeTokenOut(time, token, node.id);
    } else if (node.type === "task") {
      const resourceName = node.resource || "";

      // Check Queue limits
      if (config.queueLimits && config.queueLimits[node.id] !== undefined) {
        const currentQueueSize = queues[node.id].length;
        if (currentQueueSize >= config.queueLimits[node.id]) {
          nodeRejections[node.id]++;
          // Token overflows: direct bypass or rejection routing
          const excPath = node.exceptionHandlerId;
          if (excPath) {
            transferToNode(time, token, excPath);
          } else {
            // direct kill
            delete tokensMap[token.id];
          }
          return;
        }
      }

      // Check resource count
      if (!resourceName) {
        const duration = node.distribution ? sampleDistribution(node.distribution, prng) : 10;
        const setup = node.setupTime || 0;

        scheduleEvent({
          time: time + duration + setup,
          type: "task_complete",
          tokenId: token.id,
          nodeId: node.id,
        });
      } else if (resourcesAvailable[resourceName] > 0 && !activeDowntime[resourceName]) {
        resourcesAvailable[resourceName]--;

        const duration = node.distribution ? sampleDistribution(node.distribution, prng) : 10;
        const setup = node.setupTime || 0;

        scheduleEvent({
          time: time + duration + setup,
          type: "task_complete",
          tokenId: token.id,
          nodeId: node.id,
        });
      } else {
        // Enqueue
        queues[node.id].push(token);
      }
    }
  }

  function finalizeTermination(time: number, token: SimToken) {
    const cycleTime = time - token.createTime;
    completedCycles.push(cycleTime);

    // Calculate total costs summed on nodes
    const totalCostSpent = token.travelHistory.reduce((sum, s) => sum + s.costSpent, 0);
    completedCosts.push(totalCostSpent);

    delete tokensMap[token.id];
  }

  // Core Math Calculation - average, quartiles, and utilizations
  const resultsCount = completedCycles.length;

  const cycleTimeMean = resultsCount > 0 ? completedCycles.reduce((sum, c) => sum + c, 0) / resultsCount : 0;
  const totalCostMean = resultsCount > 0 ? completedCosts.reduce((sum, c) => sum + c, 0) / resultsCount : 0;

  // Median & percentiles
  const sortedCycles = [...completedCycles].sort((a, b) => a - b);
  const cycleTimeMedian = sortedCycles[Math.floor(resultsCount / 2)] || 0;
  const cycleTime95Percentile = sortedCycles[Math.floor(resultsCount * 0.95)] || 0;

  // Resource Utilizations integration over final duration
  const resourceUtilizations: Record<string, number> = {};
  const simTotalDuration = Math.max(1, lastTime);

  Object.keys(resourceMax).forEach((r) => {
    const maxPoss = resourceMax[r] * simTotalDuration;
    const busyInt = resourceBusyTime[r] || 0;
    resourceUtilizations[r] = Math.min(100, Math.max(0, (busyInt / maxPoss) * 100));
  });

  // Compile individual Node Metrics
  const calculatedNodeMetrics: NodeSimulationMetrics[] = nodes.map((n) => {
    const vis = nodeVisits[n.id] || 0;
    const pTimes = nodeProcessingTimes[n.id] || [];
    const wTimes = nodeWaitingTimes[n.id] || [];

    const pMean = pTimes.length > 0 ? pTimes.reduce((s, x) => s + x, 0) / pTimes.length : 0;
    const wMean = wTimes.length > 0 ? wTimes.reduce((s, x) => s + x, 0) / wTimes.length : 0;
    const wMax = wTimes.length > 0 ? Math.max(...wTimes) : 0;

    return {
      nodeId: n.id,
      nodeName: n.name || n.id,
      visits: vis,
      processingTimeMean: parseFloat(pMean.toFixed(2)),
      waitingTimeMean: parseFloat(wMean.toFixed(2)),
      waitingTimeMax: parseFloat(wMax.toFixed(2)),
      totalCost: parseFloat((nodeCosts[n.id] || 0).toFixed(2)),
      reworkCount: nodeReworkCounts[n.id] || 0,
      rejectedCount: nodeRejections[n.id] || 0,
    };
  });

  // Confidence Interval 95%
  // Margin of Error = z * (std_dev / sqrt(n))
  let stdDevVarianceCycleTime = 0;
  if (resultsCount > 1) {
    const variance = completedCycles.reduce((sum, c) => sum + Math.pow(c - cycleTimeMean, 2), 0) / (resultsCount - 1);
    stdDevVarianceCycleTime = Math.sqrt(variance);
  }
  const zScore95 = 1.96;
  const marginError = resultsCount > 0 ? zScore95 * (stdDevVarianceCycleTime / Math.sqrt(resultsCount)) : 0;

  // Bottleneck detection (Task with maximum queue/waiting time)
  const bottlenecks = calculatedNodeMetrics
    .filter((nm) => nodes.find((n) => n.id === nm.nodeId)?.type === "task")
    .sort((a, b) => b.waitingTimeMean - a.waitingTimeMean)
    .slice(0, 2)
    .map((nm) => nm.nodeName);

  const defectPercentage = resultsCount > 0 ? (reworksCount / (resultsCount * nodes.filter((n) => n.type === "task").length)) * 100 : 0;

  return {
    version: MODEL_VERSION,
    engineVersion: ENGINE_VERSION,
    seed: config.seed,
    executedAt: new Date().toISOString(),
    userEmail: metadata?.userEmail || "anon-sixsigma@e3i.com",
    companyId: metadata?.companyId || "global_kms_system",
    projectId: metadata?.projectId || "active_lss_project",
    parameters: {
      runs: config.runs,
      horizon: config.horizon,
      arrivalRate: config.arrivalRate,
    },
    metrics: {
      cycleTimeMean: parseFloat(cycleTimeMean.toFixed(2)),
      cycleTimeMedian: parseFloat(cycleTimeMedian.toFixed(2)),
      cycleTime95Percentile: parseFloat(cycleTime95Percentile.toFixed(2)),
      queueTimeMean: parseFloat(
        (calculatedNodeMetrics.reduce((s, n) => s + n.waitingTimeMean, 0) / (calculatedNodeMetrics.length || 1)).toFixed(2)
      ),
      throughput: parseFloat((resultsCount / (horizonMinutes / 60)).toFixed(2)), // completed items per hour
      wipMean: parseFloat(((totalWipOverTime / wipObservationsCount) || 0).toFixed(2)),
      totalReworks: reworksCount,
      totalCostMean: parseFloat(totalCostMean.toFixed(2)),
      defectPercentage: parseFloat(defectPercentage.toFixed(2)),
      bottlenecks,
      resourceUtilizations,
      confidenceInterval: {
        lower: parseFloat(Math.max(0, cycleTimeMean - marginError).toFixed(2)),
        upper: parseFloat((cycleTimeMean + marginError).toFixed(2)),
      },
    },
    nodeMetrics: calculatedNodeMetrics,
  };
}

// Scenario comparison, parameter overrides & recommendation mapping
export function compareScenarios(
  current: SimulationResult,
  future: SimulationResult
): {
  variationPercentage: number; // cycle time change
  direction: "improvement" | "degradation" | "neutral";
  recommendations: string[];
} {
  const diff = future.metrics.cycleTimeMean - current.metrics.cycleTimeMean;
  const variationPercentage = current.metrics.cycleTimeMean > 0 ? (diff / current.metrics.cycleTimeMean) * 100 : 0;

  let direction: "improvement" | "degradation" | "neutral" = "neutral";
  if (variationPercentage < -2) direction = "improvement"; // negative diff is speed enhancement
  else if (variationPercentage > 2) direction = "degradation";

  const recommendations: string[] = [];

  // Generate automated insights based on stats comparison
  if (direction === "improvement") {
    recommendations.push(
      `O cenário futuro reduz o tempo de ciclo médio em **${Math.abs(variationPercentage).toFixed(1)}%**, acelerando a entrega.`
    );
  } else if (direction === "degradation") {
    recommendations.push(
      `Alerta de gargalo: O tempo de ciclo médio aumentou em **${variationPercentage.toFixed(1)}%**. Revise a sobrecarga de recursos.`
    );
  }

  // Compare Resource Utilizations to point out overloads
  Object.keys(current.metrics.resourceUtilizations).forEach((key) => {
    const futUtil = future.metrics.resourceUtilizations[key] || 0;
    if (futUtil > 90) {
      recommendations.push(
        `O recurso **${key}** está atuando no limite crítico de saturação (${futUtil.toFixed(1)}% de utilização). Recomendado contratação de pessoal.`
      );
    }
  });

  // Rework rates comparison
  if (future.metrics.totalReworks < current.metrics.totalReworks) {
    recommendations.push(
      `Consolidação da qualidade: Redução de retrabalhos de **${current.metrics.totalReworks}** para **${future.metrics.totalReworks}** ocorrências.`
    );
  }

  // WIP reduction
  if (future.metrics.wipMean < current.metrics.wipMean) {
    recommendations.push(
      `Otimização de Gargalos (Teoria das Restrições): Redução de inventário em fluxo (WIP) médio para **${future.metrics.wipMean}** unidades.`
    );
  }

  return {
    variationPercentage: parseFloat(variationPercentage.toFixed(2)),
    direction,
    recommendations,
  };
}
