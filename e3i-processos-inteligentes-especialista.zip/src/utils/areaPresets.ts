import { ProcessStep } from "../types";

export type AreaId = 
  | "finance" 
  | "it_governance" 
  | "hr" 
  | "data_ai" 
  | "legal_risk"
  | "core_inbound" 
  | "core_ops" 
  | "core_outbound" 
  | "core_sales";

export interface CorporateArea {
  id: AreaId;
  name: string;
  type: "CORE" | "SUPPORT";
  icon: string;
  shortDesc: string;
  frameworks: string[];
}

export const CORPORATE_AREAS: CorporateArea[] = [
  // Support processes
  {
    id: "finance",
    name: "Finanças, Controladoria & FP&A",
    type: "SUPPORT",
    icon: "💰",
    shortDesc: "Modelo econômico, planejamento orçamentário e análise de fluxo de caixa.",
    frameworks: ["BSC (Balanced Scorecard)", "OKR (Objectives & Key Results)", "PMBOK Framework"]
  },
  {
    id: "it_governance",
    name: "TI, Governança & Sistemas",
    type: "SUPPORT",
    icon: "🖥️",
    shortDesc: "Segurança de dados, compliance com LGPD, integridade e uptime de redes.",
    frameworks: ["COBIT 2019", "NIST Cybersecurity Framework", "ISO/IEC 27001"]
  },
  {
    id: "hr",
    name: "Cultura, Treinamento & RH",
    type: "SUPPORT",
    icon: "👥",
    shortDesc: "Engajamento, recrutamento, capacitação profissional e formação de Green/Black Belts.",
    frameworks: ["Scrum (Agile HR)", "Kanban de Talentos", "ISO 10015"]
  },
  {
    id: "data_ai",
    name: "Ciência de Dados, IA & P&D",
    type: "SUPPORT",
    icon: "🔬",
    shortDesc: "Pipelines estatísticos preditivos, Big Data e governança informacional.",
    frameworks: ["CRISP-DM Cycle", "DAMA DMBOK (Governança)", "COSO ERM"]
  },
  {
    id: "legal_risk",
    name: "Compliance Jurídico & Riscos",
    type: "SUPPORT",
    icon: "⚖️",
    shortDesc: "Conformidade contratual, riscos estocásticos, disputas e matriz de contingência.",
    frameworks: ["ISO 31000 Gestão de Risco", "Juridic Kanban", "PMBOK Risk Plan"]
  },
  // Core processes
  {
    id: "core_inbound",
    name: "Suprimentos & Triagem de Entrada",
    type: "CORE",
    icon: "📥",
    shortDesc: "Recepção de suprimentos, auditoria cadastral XML e triagem de pedidos de compra.",
    frameworks: ["ISO 9001 Qualidade", "PMBOK Procurement", "Kanban WIP"]
  },
  {
    id: "core_ops",
    name: "Execução Operacional Core",
    type: "CORE",
    icon: "⚙️",
    shortDesc: "Atividade principal de geração de receita da empresa (SMT ou AP).",
    frameworks: ["Lean Six Sigma (DMAIC)", "Teoria das Restrições", "Scrum do Time"]
  },
  {
    id: "core_outbound",
    name: "Expedição & Logística de Saída",
    type: "CORE",
    icon: "🚚",
    shortDesc: "Faturamento mercantil, roteirização de frota e tracking de clientes.",
    frameworks: ["BSC - Clientes", "ISO 31000 Logística", "PMBOK Integration"]
  },
  {
    id: "core_sales",
    name: "Vendas, CRM & Pós-Venda",
    type: "CORE",
    icon: "🤝",
    shortDesc: "Qualificação de oportunidades comerciais e prevenção de interrupções contratuais.",
    frameworks: ["CRISP-DM Predict Churn", "DAMA DMBOK Cadastral", "OKR Comercial"]
  }
];

export const getInitialStepsForArea = (areaId: AreaId, defaultOpsSteps: ProcessStep[]): ProcessStep[] => {
  switch (areaId) {
    case "finance":
      return [
        {
          id: "fin-1",
          name: "Lançamento de Provisões e Opex",
          resource: "Analista Financeiro",
          resourceCount: 2,
          processingTime: 6.0,
          standardDeviation: 1.2,
          yieldRate: 0.96,
          setupTime: 10,
          description: "Entrada e conferência de custos recorrentes da empresa para fins orçamentários.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "fin-2"
        },
        {
          id: "fin-2",
          name: "Análise de Mix do Balanced Scorecard",
          resource: "Controller Sênior",
          resourceCount: 1,
          processingTime: 12.0,
          standardDeviation: 2.5,
          yieldRate: 0.94,
          setupTime: 0,
          description: "Mapeamento orçamentário e apuração de margens da grade utilizando Simplex do P.O.",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "fin-3"
        },
        {
          id: "fin-3",
          name: "Aprovação do Board Financeiro",
          resource: "Diretoria (CFO)",
          resourceCount: 1,
          processingTime: 8.0,
          standardDeviation: 3.0,
          yieldRate: 0.88,
          setupTime: 0,
          description: "Análise final do fluxo de caixa e liberação de verbas operacionais baseadas em OKRs.",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "fin-4",
          noStepId: "fin-1"
        },
        {
          id: "fin-4",
          name: "Encerramento e Liberação de Recursos",
          resource: "Tesoureiro",
          resourceCount: 1,
          processingTime: 3.5,
          standardDeviation: 0.5,
          yieldRate: 0.99,
          setupTime: 2,
          description: "Pagamento e liquidação sistêmica bancária via ERP.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    case "it_governance":
      return [
        {
          id: "it-1",
          name: "Monitoramento de Incidentes de Uptime",
          resource: "NOC Analyst",
          resourceCount: 3,
          processingTime: 3.0,
          standardDeviation: 0.5,
          yieldRate: 0.98,
          setupTime: 5,
          description: "Avaliação preventiva de indisponibilidades em rede e sistemas core conforme COBIT DSS01.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "it-2"
        },
        {
          id: "it-2",
          name: "Auditoria de Logs e Tratamento de Incidentes",
          resource: "Analista de Cyber-sec",
          resourceCount: 1,
          processingTime: 9.5,
          standardDeviation: 2.0,
          yieldRate: 0.92,
          setupTime: 0,
          description: "Varredura e segurança perimetral baseado no framework NIST (Detectar e Proteger).",
          x: 350,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "it-3",
          noStepId: "it-1"
        },
        {
          id: "it-3",
          name: "Deploy de Ajustes e Resolução",
          resource: "Squad DevOps",
          resourceCount: 1,
          processingTime: 5.0,
          standardDeviation: 1.0,
          yieldRate: 0.97,
          setupTime: 15,
          description: "Deploy controlado de contingência conforme ISO 27001.",
          x: 600,
          y: 70,
          shapeType: "END"
        }
      ];

    case "hr":
      return [
        {
          id: "hr-1",
          name: "Mapeamento Kanban de Candidatos",
          resource: "Recrutador de Gente",
          resourceCount: 2,
          processingTime: 8.0,
          standardDeviation: 1.5,
          yieldRate: 0.92,
          setupTime: 0,
          description: "Atração e qualificação visual em funil ágil de candidatos para postos críticos.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "hr-2"
        },
        {
          id: "hr-2",
          name: "Formação de Green/Black Belts",
          resource: "Agile HR Coach",
          resourceCount: 1,
          processingTime: 15.0,
          standardDeviation: 3.0,
          yieldRate: 0.95,
          setupTime: 30,
          description: "Capacitação técnica corporativa em ferramentas estatísticas de análise e Lean (ISO 10015).",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "hr-3"
        },
        {
          id: "hr-3",
          name: "Homologação de Certificação do Analista",
          resource: "Comitê de Excelência",
          resourceCount: 1,
          processingTime: 6.0,
          standardDeviation: 1.0,
          yieldRate: 0.85,
          setupTime: 0,
          description: "Apresentação e aprovação de projetos Lean com retorno financeiro comprovado.",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "hr-4",
          noStepId: "hr-2"
        },
        {
          id: "hr-4",
          name: "Formatura e Alocação de Squads",
          resource: "Gestor de Portfólio",
          resourceCount: 1,
          processingTime: 4.0,
          standardDeviation: 0.5,
          yieldRate: 0.99,
          setupTime: 0,
          description: "Engajamento formal do recurso nos fluxos de valor da empresa.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    case "data_ai":
      return [
        {
          id: "data-1",
          name: "Compreensão de Dados Operacionais",
          resource: "Cientista de Dados",
          resourceCount: 1,
          processingTime: 10.0,
          standardDeviation: 2.0,
          yieldRate: 0.95,
          setupTime: 5,
          description: "Análise exploratória inicial de variáveis de fila sob normas do CRISP-DM e DAMA DMBoK.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "data-2"
        },
        {
          id: "data-2",
          name: "Modelagem Preditiva de Gargalos",
          resource: "Membro Squad IA",
          resourceCount: 1,
          processingTime: 14.5,
          standardDeviation: 4.0,
          yieldRate: 0.90,
          setupTime: 20,
          description: "Treinamento de Redes Neurais para antecipar saturação severa de postos físicos de trabalho.",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "data-3"
        },
        {
          id: "data-3",
          name: "Validação A/B de Acurácia de Predição",
          resource: "Especialista Quality Assurance",
          resourceCount: 1,
          processingTime: 8.0,
          standardDeviation: 1.5,
          yieldRate: 0.92,
          setupTime: 0,
          description: "Teste de exatidão de acionamento do gatilho estocástico de fila.",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "data-4",
          noStepId: "data-2"
        },
        {
          id: "data-4",
          name: "Habilitação Automática de Trigger",
          resource: "Engenheiro de Machine Learning",
          resourceCount: 1,
          processingTime: 3.5,
          standardDeviation: 0.2,
          yieldRate: 0.99,
          setupTime: 5,
          description: "Disponibilização da API preditiva em produção via MLOps seguro.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    case "legal_risk":
      return [
        {
          id: "risk-1",
          name: "Diagnóstico e Registro de Risco",
          resource: "Analista de Riscos",
          resourceCount: 2,
          processingTime: 7.0,
          standardDeviation: 1.8,
          yieldRate: 0.94,
          setupTime: 0,
          description: "Identificação das vulnerabilidades operacionais e mapeamento na forma da ISO 31000.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "risk-2"
        },
        {
          id: "risk-2",
          name: "Análises de Impacto e Cláusulas Comerciais",
          resource: "Advogado Societário",
          resourceCount: 1,
          processingTime: 11.0,
          standardDeviation: 2.2,
          yieldRate: 0.95,
          setupTime: 10,
          description: "Modelagem de riscos contratuais integrados ao PMBOK de riscos da empresa.",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "risk-3"
        },
        {
          id: "risk-3",
          name: "Homologação do Parecer de Compliance",
          resource: "Comitê Estatutário Jurídico",
          resourceCount: 1,
          processingTime: 9.0,
          standardDeviation: 1.5,
          yieldRate: 0.89,
          setupTime: 0,
          description: "Veredito regulatório quanto a contingências econômico-sociais.",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "risk-4",
          noStepId: "risk-1"
        },
        {
          id: "risk-4",
          name: "Arquivamento e Assinatura Digital",
          resource: "Docusign Bot / Analista",
          resourceCount: 1,
          processingTime: 3.0,
          standardDeviation: 0.2,
          yieldRate: 0.99,
          setupTime: 2,
          description: "Finalização cadastral e controle de versão de riscos.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    case "core_inbound":
      return [
        {
          id: "inb-1",
          name: "Triagem Cadastral e Conferência XML",
          resource: "Analista de Recebimento",
          resourceCount: 2,
          processingTime: 4.5,
          standardDeviation: 1.0,
          yieldRate: 0.92,
          setupTime: 0,
          description: "Entrada cadastral no portal ERP, revisão de tributações de notas de compras.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "inb-2"
        },
        {
          id: "inb-2",
          name: "Auditoria Física da Carga",
          resource: "Conferente",
          resourceCount: 2,
          processingTime: 8.0,
          standardDeviation: 1.8,
          yieldRate: 0.96,
          setupTime: 15,
          description: "Checagem de quantidades, avarias físicas e conformidade do código de barras de insumos.",
          x: 350,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "inb-3",
          noStepId: "inb-1"
        },
        {
          id: "inb-3",
          name: "Liberação Logística e Endereçamento",
          resource: "Operador de Empilhadeira",
          resourceCount: 1,
          processingTime: 5.5,
          standardDeviation: 0.8,
          yieldRate: 0.99,
          setupTime: 0,
          description: "Locação e endereçamento no almoxarifado sob regras de Kanban FIFO.",
          x: 600,
          y: 70,
          shapeType: "END"
        }
      ];

    case "core_outbound":
      return [
        {
          id: "out-1",
          name: "Picking & Consolidação de Cargas",
          resource: "Separador Almoxarifado",
          resourceCount: 3,
          processingTime: 5.0,
          standardDeviation: 1.0,
          yieldRate: 0.95,
          setupTime: 10,
          description: "Separação física das expedições nos paletes com base no sequenciamento FIFO.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "out-2"
        },
        {
          id: "out-2",
          name: "Faturamento e Emissão das NF-e",
          resource: "Faturista Digital",
          resourceCount: 1,
          processingTime: 3.5,
          standardDeviation: 0.6,
          yieldRate: 0.98,
          setupTime: 0,
          description: "Fechamento contábil de saída e transmissão de XML para a Receita Federal.",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "out-3"
        },
        {
          id: "out-3",
          name: "Conferência de Expedição de Segurança",
          resource: "Supervisor Logístico",
          resourceCount: 1,
          processingTime: 6.0,
          standardDeviation: 1.2,
          yieldRate: 0.97,
          setupTime: 0,
          description: "Auditoria final do lacre, peso, motorista e CTE antes do tráfego rodoviário (ISO 31000).",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "out-4",
          noStepId: "out-1"
        },
        {
          id: "out-4",
          name: "Despacho Físico para Destino",
          resource: "Motorista Transportadora",
          resourceCount: 4,
          processingTime: 14.0,
          standardDeviation: 2.5,
          yieldRate: 0.99,
          setupTime: 20,
          description: "Transporte e entrega confirmada na perspectiva do cliente do Balanced Scorecard.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    case "core_sales":
      return [
        {
          id: "sales-1",
          name: "Prospecção e Triagem de Leads",
          resource: "SDR Comercial",
          resourceCount: 2,
          processingTime: 5.0,
          standardDeviation: 1.1,
          yieldRate: 0.90,
          setupTime: 0,
          description: "Recepção e filtro qualificatório de novos contatos gerados via OKR de Atração.",
          x: 100,
          y: 70,
          shapeType: "START",
          nextStepId: "sales-2"
        },
        {
          id: "sales-2",
          name: "Desenho da Proposta de Valor",
          resource: "Engenheiro de Soluções",
          resourceCount: 1,
          processingTime: 11.5,
          standardDeviation: 2.0,
          yieldRate: 0.94,
          setupTime: 15,
          description: "Precificação e especificação detalhada sob conformidade de margens internas.",
          x: 350,
          y: 70,
          shapeType: "ACTIVITY",
          nextStepId: "sales-3"
        },
        {
          id: "sales-3",
          name: "Negociação de Cláusulas SLA",
          resource: "Gerente de Contas",
          resourceCount: 1,
          processingTime: 8.5,
          standardDeviation: 1.8,
          yieldRate: 0.88,
          setupTime: 0,
          description: "Discussão estrita de tempos de ciclos (Lead Time acordado) para evitar contingências.",
          x: 600,
          y: 70,
          shapeType: "DECISION",
          yesStepId: "sales-4",
          noStepId: "sales-1"
        },
        {
          id: "sales-4",
          name: "Prevenção de Rolagem / Churn",
          resource: "Customer Success VIP",
          resourceCount: 1,
          processingTime: 4.5,
          standardDeviation: 0.8,
          yieldRate: 0.99,
          setupTime: 5,
          description: "Monitoramento de satisfação e aderência à cultura da empresa.",
          x: 850,
          y: 70,
          shapeType: "END"
        }
      ];

    default: // core_ops fallback
      return defaultOpsSteps;
  }
};
