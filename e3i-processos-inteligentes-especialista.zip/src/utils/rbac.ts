/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

export type Permission =
  | "platform:view"
  | "company:view"
  | "company:manage"
  | "project:view"
  | "project:create"
  | "project:edit"
  | "project:delete"
  | "process:view"
  | "process:create"
  | "process:edit"
  | "process:delete"
  | "process:advanced-analysis"
  | "process:export"
  | "operation:view"
  | "operation:manage-kanban"
  | "operation:create-action"
  | "operation:edit-action"
  | "operation:export"
  | "report:view"
  | "report:export"
  | "admin:view"
  | "admin:manage-users"
  | "admin:manage-settings"
  | "ai:use"
  | "ai:advanced";

export type AuthenticatedUser = {
  id: string;
  name: string;
  roles: string[];
  permissions: Permission[];
};

// Map of legacy & production roles to the new permission schema
export const ROLE_PERMISSIONS_MAP: Record<string, Permission[]> = {
  "Administrador": [
    "platform:view", "company:view", "company:manage",
    "project:view", "project:create", "project:edit", "project:delete",
    "process:view", "process:create", "process:edit", "process:delete", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "admin:view", "admin:manage-users", "admin:manage-settings",
    "ai:use", "ai:advanced"
  ],
  "Admin": [
    "platform:view", "company:view", "company:manage",
    "project:view", "project:create", "project:edit", "project:delete",
    "process:view", "process:create", "process:edit", "process:delete", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "admin:view", "admin:manage-users", "admin:manage-settings",
    "ai:use", "ai:advanced"
  ],
  "Executivo": [
    "platform:view", "company:view",
    "project:view",
    "process:view", "process:export",
    "operation:view", "operation:export",
    "report:view", "report:export",
    "ai:use"
  ],
  "Gestor de Portfólio": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:advanced-analysis", "process:export",
    "operation:view",
    "report:view", "report:export",
    "ai:use"
  ],
  "Dono do Processo": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:create", "process:edit", "process:delete", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban",
    "report:view",
    "ai:use"
  ],
  "Líder do Projeto": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:create", "process:edit", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban",
    "report:view",
    "ai:use"
  ],
  "Analista": [
    "platform:view", "company:view",
    "project:view", "project:create", "project:edit",
    "process:view", "process:create", "process:edit", "process:advanced-analysis", "process:export",
    "operation:view", "operation:manage-kanban", "operation:create-action", "operation:edit-action", "operation:export",
    "report:view", "report:export",
    "ai:use"
  ],
  "Colaborador": [
    "platform:view", "company:view",
    "project:view",
    "process:view",
    "operation:view",
    "report:view",
    "ai:use"
  ],
  "Auditor": [
    "platform:view", "company:view",
    "project:view",
    "process:view", "process:export",
    "operation:view", "operation:export",
    "report:view", "report:export"
  ],
  "Visualizador": [
    "platform:view", "company:view",
    "project:view",
    "process:view",
    "operation:view",
    "report:view"
  ]
};

/**
 * Checks if a user has a specific permission.
 */
export function hasPermission(
  user: AuthenticatedUser | null,
  permission: Permission
): boolean {
  if (!user) return false;
  return Boolean(user.permissions.includes(permission));
}

/**
 * Helper to register and audit access violations in simulation logs
 */
export function auditPermissionAccess(
  user: AuthenticatedUser | null,
  requiredPermission: Permission,
  resourceName: string,
  isAllowed: boolean
): void {
  const timestamp = new Date().toISOString();
  const userName = user?.name || "Anonymous";
  const userRoles = user?.roles?.join(", ") || "None";
  
  if (isAllowed) {
    console.warn(
      `[RBAC AUDIT SUCCESS] - User "${userName}" with roles [${userRoles}] successfully accessed "${resourceName}" via permission "${requiredPermission}" at ${timestamp}.`
    );
  } else {
    console.error(
      `[RBAC AUDIT VIOLATION] - User "${userName}" with roles [${userRoles}] attempted UNAUTHORIZED access to "${resourceName}" requiring "${requiredPermission}" at ${timestamp}!`
    );
  }
}

/**
 * Creates an AuthenticatedUser structured object from a generic LoggedUser and current role
 */
export function buildAuthenticatedUser(
  loggedUser: { fullName: string; email: string } | null,
  roleName: string
): AuthenticatedUser | null {
  if (!loggedUser) return null;
  
  // Clean fallback mapping & sanitize role format
  const sanitizedRole = ROLE_PERMISSIONS_MAP[roleName] ? roleName : "Visualizador";
  const permissions = ROLE_PERMISSIONS_MAP[sanitizedRole] || [];
  
  return {
    id: loggedUser.email,
    name: loggedUser.fullName,
    roles: [sanitizedRole],
    permissions: permissions
  };
}

/**
 * React PermissionGuard component
 */
interface PermissionGuardProps {
  user: AuthenticatedUser | null;
  permission: Permission;
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

export function PermissionGuard({
  user,
  permission,
  fallback = null,
  children
}: PermissionGuardProps) {
  if (!hasPermission(user, permission)) {
    return React.createElement(React.Fragment, null, fallback);
  }
  return React.createElement(React.Fragment, null, children);
}
