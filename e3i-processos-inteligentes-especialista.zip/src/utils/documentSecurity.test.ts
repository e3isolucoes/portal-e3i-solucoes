/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect } from "vitest";
import {
  SecureDocument,
  DocumentIntegrityRecord,
  CustodyLog,
  calculateSHA256,
  computeDocumentHash,
  verifyDocumentSecurity,
  signDocumentKMS,
  requestTimestampToken,
  buildVisualWatermark,
  isRetentionPeriodExceeded,
  executeSecureDisposal,
  REVOLKED_CERTIFICATES_SET
} from "./documentSecurity";

describe("Fase 12 - Testes de Integridade de Documentos, Assinaturas Digitais e Cadeia de Custódia (E3I)", () => {
  
  // Helper to create a pristine document for tests
  const createMockDocument = (): SecureDocument => {
    const rawDoc: Omit<SecureDocument, "hash"> = {
      id: "sop-01",
      companyId: "E3I-Fase-12",
      projectId: "DMAIC-ZERO-DEFECTS",
      processId: "PROC-MAIN",
      title: "POP-01: Preparação de Lotes de Amostragem",
      objective: "Definir diretrizes estritas contra vazamento de informações industriais.",
      scope: "Fábrica e setor administrativo.",
      content: "1. Limpar bancada. 2. Identificar sela com lacre. 3. Carregar no container.",
      version: 1,
      author: "Marco Antonio Miranda",
      generatedBy: "marcoantoniomiranda713@gmail.com",
      generatedAt: "2026-06-15T12:00:00Z",
      classification: "Confidencial",
      retentionPolicy: "SOP - Retenção de 5 anos",
      retentionYears: 5,
      legalHold: false,
      status: "Aprovado",
    };

    const hash = computeDocumentHash(rawDoc);
    return {
      ...rawDoc,
      hash,
    };
  };

  it("1. Arquivo original: deve aprovar a integridade de um documento original saudável", () => {
    const doc = createMockDocument();
    const verification = verifyDocumentSecurity(doc);
    
    expect(verification.integrityOk).toBe(true);
    expect(verification.isValid).toBe(true);
  });

  it("2. Arquivo alterado: deve detectar alteração de bytes finais e invalidar o arquivo", () => {
    const doc = createMockDocument();
    
    // Tamper with content!
    const tamperedDoc = {
      ...doc,
      content: "1. Limpar bancada. 2. Identificar sela com SILENCIO. 3. Carregar no container.", // tampered step
    };

    const verification = verifyDocumentSecurity(tamperedDoc);
    expect(verification.integrityOk).toBe(false);
    expect(verification.isValid).toBe(false);
    expect(verification.details).toContain("CRÍTICO: O conteúdo do documento foi alterado");
  });

  it("3. Hash divergente: deve invalidar se o hash gravado no metadado for alterado de forma maldosa", () => {
    const doc = createMockDocument();
    const tamperedDoc = {
      ...doc,
      hash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", // corrupted empty hash
    };

    const verification = verifyDocumentSecurity(tamperedDoc);
    expect(verification.integrityOk).toBe(false);
    expect(verification.isValid).toBe(false);
  });

  it("4. Assinatura inválida: deve apontar falha crítica se o token de assinatura digital do KMS for corrompido", () => {
    const doc = createMockDocument();
    
    // Sign securely
    const signedData = signDocumentKMS(doc, "KMS-HSM-CERT-001", "marcoantoniomiranda713@gmail.com");
    const signedDoc: SecureDocument = {
      ...doc,
      signature: signedData.signature,
      certificateId: signedData.certificateId,
      signedAt: signedData.signedAt,
    };

    // Damage the signature string
    const brokenSignDoc = {
      ...signedDoc,
      signature: signedDoc.signature?.substring(0, 30) + "FF", // damaged
    };

    const verification = verifyDocumentSecurity(brokenSignDoc);
    expect(verification.integrityOk).toBe(true); // file bytes are intact
    expect(verification.signatureOk).toBe(false);
    expect(verification.isValid).toBe(false);
    expect(verification.details).toContain("CRÍTICO: A assinatura digital é inválida");
  });

  it("5. Certificado revogado: deve invalidar a segurança de assinaturas de funcionários demitidos ou certificados cancelados", () => {
    const doc = createMockDocument();
    
    // Sign with revoked credential "KMS-HSM-CERT-REVOKED"
    const signedData = signDocumentKMS(doc, "KMS-HSM-CERT-REVOKED", "desligado@empresa.com");
    const signedDoc: SecureDocument = {
      ...doc,
      signature: signedData.signature,
      certificateId: signedData.certificateId,
      signedAt: signedData.signedAt,
    };

    const verification = verifyDocumentSecurity(signedDoc);
    expect(verification.integrityOk).toBe(true);
    expect(verification.signatureOk).toBe(true); // cryptographic formula matches
    expect(verification.notRevoked).toBe(false); // but certificate is in revoked list!
    expect(verification.isValid).toBe(false);
    expect(verification.details).toContain("FALHA: O certificado digital responsável pela assinatura foi revogado");
  });

  it("6. Versão anterior: deve permitir a coexistência de hashes separados para versões diferentes sem cruzamento de assinatura", () => {
    const docV1 = createMockDocument();
    
    // Create V2
    const docV2Raw: Omit<SecureDocument, "hash"> = {
      ...docV1,
      version: 2,
      content: docV1.content + " Novo passo de segurança.",
      generatedAt: "2026-06-15T13:00:00Z",
    };
    const hashV2 = computeDocumentHash(docV2Raw);
    const docV2: SecureDocument = {
      ...docV2Raw,
      hash: hashV2,
    };

    // Both should contain unique independent security status
    expect(docV1.hash).not.toBe(docV2.hash);
    expect(verifyDocumentSecurity(docV1).isValid).toBe(true);
    expect(verifyDocumentSecurity(docV2).isValid).toBe(true);
  });

  it("7. Documento revogado: deve retornar inválido se o status do documento for explicitamente definido como 'Revogado'", () => {
    const doc = createMockDocument();
    const signedData = signDocumentKMS(doc, "KMS-HSM-CERT-001", "marcoantoniomiranda713@gmail.com");
    
    const revokedDoc: SecureDocument = {
      ...doc,
      status: "Revogado",
      signature: signedData.signature,
      certificateId: signedData.certificateId,
      signedAt: signedData.signedAt,
    };

    const verification = verifyDocumentSecurity(revokedDoc);
    expect(verification.integrityOk).toBe(true);
    expect(verification.isValid).toBe(false);
    expect(verification.details).toContain("FALHA: O documento possui assinatura íntegra, mas foi explicitamente REVOGADO");
  });

  it("8. Watermark: deve construir informações visuais e textuais ricas adequadas para controle físico de mídias", () => {
    const doc = createMockDocument();
    const watermarkControlled = buildVisualWatermark(doc, true);
    const watermarkUncontrolled = buildVisualWatermark(doc, false);

    expect(watermarkControlled).toContain("CÓPIA CONTROLADA");
    expect(watermarkControlled).toContain(doc.id);
    expect(watermarkControlled).toContain("CONFIDENCIAL");
    expect(watermarkControlled).toContain(doc.hash.substring(0, 10).toUpperCase());

    expect(watermarkUncontrolled).toContain("NÃO CONTROLADA");
  });

  it("9. Carimbo de tempo (TSA): deve simular o registro de evidências e carimbo de tempo válidos auditados por autoridade fiduciária", () => {
    const doc = createMockDocument();
    const tsa = requestTimestampToken(doc.hash, "Comissão ICP-Brasil Cora TSA");

    expect(tsa.authority).toBe("Comissão ICP-Brasil Cora TSA");
    expect(tsa.token.length).toBe(32);
    expect(tsa.validationResult).toBe("VALID");
    expect(tsa.policy).toBe("AD-RB_PROV_TS_N1");
  });

  it("10. Usuário sem permissão: deve impedir sumariamente o descarte físico se o usuário não possuir privilégios de auditoria", () => {
    const doc = createMockDocument();
    const logs: CustodyLog[] = [];
    
    const result = executeSecureDisposal(doc, ["GUEST_USER"], logs, "invasor@empresa.com");
    
    expect(result.success).toBe(false);
    expect(result.document.isDeleted).not.toBe(true);
    expect(logs.length).toBe(1);
    expect(logs[0].action).toBe("Tentativa de Exclusão Impedida");
    expect(logs[0].user).toBe("invasor@empresa.com");
  });

  it("11. Política de retenção e Bloqueio Legal: deve obedecer prazos de expiração e impedir exclusão sob Legal Hold de segurança", () => {
    const doc = createMockDocument();
    
    // Under Legal Hold
    const docLocked: SecureDocument = {
      ...doc,
      legalHold: true,
    };

    const logs: CustodyLog[] = [];
    const result = executeSecureDisposal(docLocked, ["ADMIN", "DOCUMENT_DISPOSAL"], logs, "marcoantoniomiranda713@gmail.com");

    expect(result.success).toBe(false);
    expect(logs[0].action).toBe("Tentativa de Exclusão Impedida");
    expect(logs[0].description).toContain("Bloqueio Legal (Legal Hold) ativo impede o descarte");

    // Exceeded retention calculation
    const legacyDocByDate: SecureDocument = {
      ...doc,
      generatedAt: "2015-01-01T12:00:00Z", // 11 years ago, exceeds SOP retention (5 years)
      retentionYears: 5,
    };

    expect(isRetentionPeriodExceeded(legacyDocByDate)).toBe(true);
  });

  it("12. Cadeia de custódia: deve auditar todo o ciclo operacional sequencialmente rastreando IPs e ações reais", () => {
    const doc = createMockDocument();
    const logs: CustodyLog[] = [];

    // Simulate flow
    const log1: CustodyLog = {
      id: "CUST-001",
      documentId: doc.id,
      version: doc.version,
      timestamp: new Date().toISOString(),
      user: "marcoantoniomiranda713@gmail.com",
      action: "Criação",
      description: "Documento inicial gerado a partir do fluxo Kanban.",
      ip: "192.168.1.10",
    };
    logs.push(log1);

    const signed = signDocumentKMS(doc, "KMS-HSM-CERT-001", "marcoantoniomiranda713@gmail.com");
    const log2: CustodyLog = {
      id: "CUST-002",
      documentId: doc.id,
      version: doc.version,
      timestamp: signed.signedAt,
      user: "marcoantoniomiranda713@gmail.com",
      action: "Assinatura",
      description: `Certificado KMS-HSM-CERT-001 aplicado com chave e hash ${doc.hash.substring(0,8)}.`,
      ip: "192.168.1.10",
    };
    logs.push(log2);

    expect(logs.length).toBe(2);
    expect(logs[0].action).toBe("Criação");
    expect(logs[1].action).toBe("Assinatura");
  });

});
