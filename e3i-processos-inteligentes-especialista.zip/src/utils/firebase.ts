import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User 
} from "firebase/auth";

// Safe fallback config
const fallbackConfig = {
  projectId: "gen-lang-client-0360031080",
  appId: "1:870938220410:web:b573fd07cb196e48cde8c3",
  apiKey: "PLACEHOLDER_SEE_ENV",
  authDomain: "gen-lang-client-0360031080.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-88233372-0053-49a7-9126-399c0b141e9e",
  storageBucket: "gen-lang-client-0360031080.firebasestorage.app",
  messagingSenderId: "870938220410"
};

// Prioritize environment variables over the JSON config for security
const getFirebaseConfig = () => {
  const env = (import.meta as any).env || {};
  return {
    apiKey: env.VITE_FIREBASE_API_KEY || fallbackConfig.apiKey,
    authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || fallbackConfig.authDomain,
    projectId: env.VITE_FIREBASE_PROJECT_ID || fallbackConfig.projectId,
    storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || fallbackConfig.storageBucket,
    messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || fallbackConfig.messagingSenderId,
    appId: env.VITE_FIREBASE_APP_ID || fallbackConfig.appId,
    measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || "",
  };
};

const activeConfig = getFirebaseConfig();

// Initialize Firebase dynamically
const app = getApps().length === 0 ? initializeApp(activeConfig) : getApp();
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Request Calendar scopes as specified in user request
provider.addScope("https://www.googleapis.com/auth/calendar");

let isSigningIn = false;
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Não foi possível obter o Access Token do Firebase Auth.");
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    if (error && error.code === "auth/popup-closed-by-user") {
      console.warn("Sign in popup closed by user (cancelled).");
      return null;
    }
    if (error && error.code === "auth/operation-not-allowed") {
      throw new Error(
        "O provedor 'Google' não está habilitado no Console do Firebase do seu projeto. " +
        "Acesse 'Authentication' > 'Sign-in method' no Console do Firebase e ative o provedor 'Google'."
      );
    }
    console.error("Sign in error:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};
