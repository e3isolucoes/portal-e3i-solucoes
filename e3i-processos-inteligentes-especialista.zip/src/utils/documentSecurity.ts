/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SecureDocument {
  id: string;
  companyId: string;
  projectId: string;
  processId: string;
  title: string;
  objective: string;
  scope: string;
  content: string; // Dynamic steps or prose compiled
  version: number;
  author: string;
  generatedBy: string; // user email / id
  generatedAt: string; // ISO string
  approvedBy?: string;
  approvedAt?: string;
  signedAt?: string;
  classification: "Público" | "Uso Interno" | "Confidencial" | "Restrito";
  retentionPolicy: string; // configured policy desc
  retentionYears: number; // calculated years limit
  legalHold: boolean; // prevents deletion or archiving
  hash: string; // SHA-256 of metadata + content
  status: "Rascunho" | "Em Validação" | "Aprovado" | "Revogado" | "Arquivado";
  certificateId?: string; // certificate ID from KMS/HSM
  signature?: string; // SHA-256 signature representation
  timestampAuthority?: string; // TSA name
  timestampToken?: string; // TSA token hex
  timestampTokenId?: string; // unique ID
  isDeleted?: boolean; // soft-delete flag
}

export interface DocumentIntegrityRecord {
  documentId: string;
  version: number;
  algorithm: "SHA-256";
  hash: string;
  generatedBy: string;
  generatedAt: string;
  signedAt?: string;
  timestampTokenId?: string;
}

export interface CustodyLog {
  id: string;
  documentId: string;
  version: number;
  timestamp: string;
  user: string;
  action:
    | "Criação"
    | "Alteração"
    | "Aprovação"
    | "Assinatura"
    | "Download"
    | "Compartilhamento"
    | "Revogação"
    | "Substituição"
    | "Arquivamento"
    | "Exclusão autorizada"
    | "Bloqueio Legal Ativado"
    | "Bloqueio Legal Desativado"
    | "Tentativa de Exclusão Impedida"
    | "Restauração";
  description: string;
  ip: string;
}

// -------------------------------------------------------------
// Deterministic Synchronous SHA-255 Algorithm (Pure TS/JS)
// -------------------------------------------------------------
export function calculateSHA256(input: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }

  let i;
  let result = "";

  const hash = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];

  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];

  const asciiLength = input.length;
  const rLength = asciiLength * 8;
  const padded: number[] = [];

  for (i = 0; i < asciiLength; i++) {
    padded.push(input.charCodeAt(i));
  }
  padded.push(0x80);

  while (padded.length % 64 !== 56) {
    padded.push(0x00);
  }

  // append length as 64-bit big-endian int
  padded.push(0);
  padded.push(0);
  padded.push(0);
  padded.push(0);
  padded.push((rLength >>> 24) & 0xff);
  padded.push((rLength >>> 16) & 0xff);
  padded.push((rLength >>> 8) & 0xff);
  padded.push(rLength & 0xff);

  for (let b = 0; b < padded.length; b += 64) {
    const w: number[] = [];
    for (i = 0; i < 16; i++) {
      const offset = b + i * 4;
      w[i] =
        (padded[offset] << 24) |
        (padded[offset + 1] << 16) |
        (padded[offset + 2] << 8) |
        padded[offset + 3];
    }
    for (i = 16; i < 64; i++) {
      const s0 = rightRotate(w[i - 15], 7) ^ rightRotate(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = rightRotate(w[i - 2], 17) ^ rightRotate(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }

    let [a, c_b, c, d, e, f, g, h_val] = hash;

    for (i = 0; i < 64; i++) {
      const s1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h_val + s1 + ch + k[i] + w[i]) | 0;
      const s0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
      const maj = (a & c_b) ^ (a & c) ^ (c_b & c);
      const temp2 = (s0 + maj) | 0;

      h_val = g;
      g = f;
      f = e;
      e = (d + temp1) | 0;
      d = c;
      c = c_b;
      c_b = a;
      a = (temp1 + temp2) | 0;
    }

    hash[0] = (hash[0] + a) | 0;
    hash[1] = (hash[1] + c_b) | 0;
    hash[2] = (hash[2] + c) | 0;
    hash[3] = (hash[3] + d) | 0;
    hash[4] = (hash[4] + e) | 0;
    hash[5] = (hash[5] + f) | 0;
    hash[6] = (hash[6] + g) | 0;
    hash[7] = (hash[7] + h_val) | 0;
  }

  for (i = 0; i < 8; i++) {
    let hex = (hash[i] >>> 0).toString(16);
    while (hex.length < 8) hex = "0" + hex;
    result += hex;
  }
  return result;
}

// -------------------------------------------------------------
// Document Serialization Helper
// -------------------------------------------------------------
export function serializeDocumentBytes(doc: Omit<SecureDocument, "hash">): string {
  // We serialize the exact content of the document alongside metadata to compute SHA-256 of bytes
  return [
    doc.id,
    doc.companyId,
    doc.projectId,
    doc.processId,
    doc.title,
    doc.objective,
    doc.scope,
    doc.content,
    doc.version,
    doc.classification,
    doc.author,
    doc.generatedAt,
  ].join("::|::");
}

// Calculates hash of a document
export function computeDocumentHash(doc: Omit<SecureDocument, "hash">): string {
  const bytes = serializeDocumentBytes(doc);
  return calculateSHA256(bytes);
}

// -------------------------------------------------------------
// Digital Signature & KMS Simulation
// -------------------------------------------------------------
// Simulated database of authorized credentials or certificates in the trusted HSM chain
const TRUSTED_CERTIFICATES = {
  "KMS-HSM-CERT-001": { owner: "Marco Antonio Miranda", role: "Master Black Belt", organization: "E3I Processos", active: true },
  "KMS-HSM-CERT-012": { owner: "Pedro Santos Filho", role: "Lead Audit ISO 9001", organization: "E3I Processos", active: true },
  "KMS-HSM-CERT-REVOKED": { owner: "Funcionário Desligado", role: "Ex-Coordenador", organization: "E3I Processos", active: false }, // revoked!
};

export const REVOLKED_CERTIFICATES_SET = new Set(["KMS-HSM-CERT-REVOKED"]);

/**
 * Sign Document simulated KMS/HSM service
 * If any byte of the document changes, verification will catch it because it's tied to hash.
 */
export function signDocumentKMS(
  doc: SecureDocument,
  certId: keyof typeof TRUSTED_CERTIFICATES | string,
  userEmail: string
): { signature: string; certificateId: string; signedAt: string } {
  const timestamp = new Date().toISOString();
  
  // Real cryptographic-representative private signing calculation using seed values
  const signatureMaterial = doc.hash + "::KMS-PRIVATE-KEY-SECRET-HSM-CHAIN-AUTH::" + certId + "::" + timestamp;
  const signature = calculateSHA256(signatureMaterial);

  return {
    signature,
    certificateId: certId,
    signedAt: timestamp,
  };
}

/**
 * Verifies validity of document signature and integrity of current document content
 */
export function verifyDocumentSecurity(
  doc: SecureDocument,
  revokedCertificates: Set<string> = REVOLKED_CERTIFICATES_SET
): {
  isValid: boolean;
  integrityOk: boolean;
  signatureOk: boolean;
  notRevoked: boolean;
  details: string;
} {
  // 1. Recalculate Hash
  const currentHash = computeDocumentHash(doc);
  const integrityOk = currentHash === doc.hash;

  if (!integrityOk) {
    return {
      isValid: false,
      integrityOk: false,
      signatureOk: false,
      notRevoked: true,
      details: "CRÍTICO: O conteúdo do documento foi alterado de forma não autorizada! O hash calculado não coincide com o metadado gravado.",
    };
  }

  // 2. Signature verification
  if (!doc.signature || !doc.certificateId || !doc.signedAt) {
    return {
      isValid: doc.status !== "Revogado",
      integrityOk: true,
      signatureOk: false,
      notRevoked: true,
      details: doc.status === "Revogado" ? "AVISO: Documento foi revogado." : "O documento não possui assinatura digital HSM.",
    };
  }

  // Cryptographically re-verify signature link
  const expectedMaterial = doc.hash + "::KMS-PRIVATE-KEY-SECRET-HSM-CHAIN-AUTH::" + doc.certificateId + "::" + doc.signedAt;
  const signatureOk = calculateSHA256(expectedMaterial) === doc.signature;

  if (!signatureOk) {
    return {
      isValid: false,
      integrityOk: true,
      signatureOk: false,
      notRevoked: true,
      details: "CRÍTICO: A assinatura digital é inválida. O certificado ou os metadados do KMS foram corrompidos.",
    };
  }

  // 3. Certificate revocation list check
  const notRevoked = !revokedCertificates.has(doc.certificateId);
  const isDocumentRevoked = doc.status === "Revogado";

  if (!notRevoked) {
    return {
      isValid: false,
      integrityOk: true,
      signatureOk: true,
      notRevoked: false,
      details: "FALHA: O certificado digital responsável pela assinatura foi revogado/cancelado na cadeia de custódia.",
    };
  }

  if (isDocumentRevoked) {
    return {
      isValid: false,
      integrityOk: true,
      signatureOk: true,
      notRevoked: true,
      details: "FALHA: O documento possui assinatura íntegra, mas foi explicitamente REVOGADO por decisão de governança.",
    };
  }

  return {
    isValid: true,
    integrityOk: true,
    signatureOk: true,
    notRevoked: true,
    details: "SUCESSO: Integridade certificada de dados, carimbo temporal válido e assinatura HSM confirmada de forma segura.",
  };
}

// -------------------------------------------------------------
// Timestamping Authority (TSA) Integration
// -------------------------------------------------------------
export interface TimestampRecord {
  certifiedAt: string;
  authority: string;
  token: string;
  policy: string;
  validationResult: "VALID" | "FAILED";
}

export function requestTimestampToken(
  documentHash: string,
  requestAuthority: string = "ICP-Brasil / Cora TSA"
): TimestampRecord {
  const now = new Date().toISOString();
  // Safe cryptographic token representation for time proof validation
  const tokenPayload = documentHash + "::TSA-TIME-STAMP-POL-2026::" + now;
  const token = calculateSHA256(tokenPayload).substring(0, 32);

  return {
    certifiedAt: now,
    authority: requestAuthority,
    token,
    policy: "AD-RB_PROV_TS_N1",
    validationResult: "VALID",
  };
}

// -------------------------------------------------------------
// Visual Watermark Builder
// -------------------------------------------------------------
export function buildVisualWatermark(
  doc: SecureDocument,
  isControlledCopy: boolean = true
): string {
  const shortHash = doc.hash.substring(0, 10).toUpperCase();
  const titleSlug = doc.title.substring(0, 15);
  const classificationLabel = doc.classification.toUpperCase();
  const formattedDate = doc.generatedAt.split("T")[0];
  const controlStatus = isControlledCopy ? "CÓPIA CONTROLADA" : "NÃO CONTROLADA";

  return `[${controlStatus}] Empresa: ${doc.companyId} | Doc: ${doc.id} (V${doc.version}) | Classif: ${classificationLabel} | Gerado em: ${formattedDate} por ${doc.author} | Hash SHA256: ${shortHash}...`;
}

// -------------------------------------------------------------
// Retention and Disposal Policies Configuration
// -------------------------------------------------------------
export interface RetentionPolicy {
  type: "SOP" | "Checklist" | "Manual" | "Form";
  retentionYears: number;
  description: string;
  requiresAnonymization: boolean;
}

export const RETENTION_POLICIESBY_TYPE: Record<RetentionPolicy["type"], RetentionPolicy> = {
  SOP: {
    type: "SOP",
    retentionYears: 5,
    description: "SOP (POP) - Procedimento Operacional Padrão de Engenharia de Processos.",
    requiresAnonymization: true,
  },
  Manual: {
    type: "Manual",
    retentionYears: 10,
    description: "Manual Geral do SGQ (Sistema de Gestão de Qualidade) corporativo.",
    requiresAnonymization: false,
  },
  Checklist: {
    type: "Checklist",
    retentionYears: 1,
    description: "Checklist operacional de execução rápida e validação de turnaround.",
    requiresAnonymization: true,
  },
  Form: {
    type: "Form",
    retentionYears: 2,
    description: "Formulários de registro e coletas de variabilidade Lean Sigma.",
    requiresAnonymization: true,
  },
};

/**
 * Checks if a document has exceeded its retention policy time
 */
export function isRetentionPeriodExceeded(doc: SecureDocument): boolean {
  const genDate = new Date(doc.generatedAt);
  const expiryDate = new Date(genDate.setFullYear(genDate.getFullYear() + doc.retentionYears));
  return new Date() > expiryDate;
}

/**
 * Performs authorized secure deletion or disposal depending on policy and legal hold settings
 */
export function executeSecureDisposal(
  doc: SecureDocument,
  userPermissions: string[],
  custodiansLog: CustodyLog[],
  userEmail: string
): {
  success: boolean;
  document: SecureDocument;
  logMessage: string;
} {
  // Check legal hold
  if (doc.legalHold) {
    const errorEvent: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: doc.id,
      version: doc.version,
      timestamp: new Date().toISOString(),
      user: userEmail,
      action: "Tentativa de Exclusão Impedida",
      description: `FALHA NO REQUISITO DE RETENÇÃO: Bloqueio Legal (Legal Hold) ativo impede o descarte do documento fiscal ou operacional.`,
      ip: "10.0.8.20",
    };
    custodiansLog.push(errorEvent);

    return {
      success: false,
      document: doc,
      logMessage: "FALHA: Bloqueio Legal ativo no documento. Cancelando processo de descarte.",
    };
  }

  // Check disposal permissions
  const hasDisposalRights =
    userPermissions.includes("DOCUMENT_DISPOSAL") ||
    userPermissions.includes("MASTER_BLACK_BELT") ||
    userPermissions.includes("ADMIN");

  if (!hasDisposalRights) {
    const errorEvent: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: doc.id,
      version: doc.version,
      timestamp: new Date().toISOString(),
      user: userEmail,
      action: "Tentativa de Exclusão Impedida",
      description: `FALHA DE PRIVILÉGIO: Usuário tentou descartar o documento sem permissões da auditoria.`,
      ip: "10.0.8.20",
    };
    custodiansLog.push(errorEvent);

    return {
      success: false,
      document: doc,
      logMessage: "FALHA: Usuário sem autoridade ou direitos de descarte de documentos.",
    };
  }

  // Excedeu retenção? Ou descarte forçado por expiração.
  const isPeriodExceeded = isRetentionPeriodExceeded(doc);
  const disposalNotice = isPeriodExceeded
    ? "Exclusão autorizada decorrente da expiração do prazo de retenção"
    : "Descarte antecipado autorizado por comissão de governança SGQ";

  // Create disposable state with soft delete, and optional anonymization of author names if policy requested
  const policy = RETENTION_POLICIESBY_TYPE[doc.id.startsWith("sop") ? "SOP" : "Manual"] || RETENTION_POLICIESBY_TYPE.SOP;
  const anonymizedAuthor = policy.requiresAnonymization ? "AUDITED_ANONYMIZED_USER" : doc.author;

  const updatedDoc: SecureDocument = {
    ...doc,
    isDeleted: true,
    status: "Arquivado",
    author: anonymizedAuthor,
    generatedBy: policy.requiresAnonymization ? "ANONYMIZED_EMAIL" : doc.generatedBy,
  };

  const successEvent: CustodyLog = {
    id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
    documentId: doc.id,
    version: doc.version,
    timestamp: new Date().toISOString(),
    user: userEmail,
    action: "Exclusão autorizada",
    description: `${disposalNotice}. Autorizado por ${userEmail}. Anonimização executada: ${policy.requiresAnonymization ? "Sim" : "Não"}.`,
    ip: "10.0.8.20",
  };
  custodiansLog.push(successEvent);

  return {
    success: true,
    document: updatedDoc,
    logMessage: "SUCESSO: Documento descartado e destruído de forma segura, com sua cadeia de custódia permanentemente preservada.",
  };
}
