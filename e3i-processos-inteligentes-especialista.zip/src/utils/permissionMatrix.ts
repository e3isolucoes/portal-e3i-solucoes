export type UserProfileRole =
  | "Administrador"
  | "Executivo"
  | "Gestor de Portfólio"
  | "Dono do Processo"
  | "Líder do Projeto"
  | "Analista"
  | "Colaborador"
  | "Auditor"
  | "Visualizador";

export type PermissionType =
  | "visualizar"
  | "criar"
  | "editar"
  | "excluir"
  | "aprovar"
  | "rejeitar"
  | "atribuir"
  | "exportar"
  | "administrar"
  | "auditar";

// Matriz de Permissões: Roles mapped directly to permitted actions
export const PERMISSIONS_BY_ROLE: Record<UserProfileRole, PermissionType[]> = {
  Administrador: [
    "visualizar",
    "criar",
    "editar",
    "excluir",
    "aprovar",
    "rejeitar",
    "atribuir",
    "exportar",
    "administrar",
    "auditar"
  ],
  Executivo: ["visualizar", "exportar", "aprovar", "rejeitar"],
  "Gestor de Portfólio": [
    "visualizar",
    "criar",
    "editar",
    "atribuir",
    "exportar"
  ],
  "Dono do Processo": [
    "visualizar",
    "editar",
    "atribuir",
    "exportar"
  ],
  "Líder do Projeto": [
    "visualizar",
    "criar",
    "editar",
    "atribuir",
    "exportar"
  ],
  Analista: [
    "visualizar",
    "criar",
    "editar",
    "exportar"
  ],
  Colaborador: [
    "visualizar",
    "editar" // only editing assigned tasks, checklist completion, and evidence upload
  ],
  Auditor: [
    "visualizar",
    "aprovar",
    "rejeitar",
    "exportar",
    "auditar"
  ],
  Visualizador: ["visualizar"]
};

// Menu views allowed for each role
export const MODULE_ACCESS_BY_ROLE: Record<UserProfileRole, string[]> = {
  Administrador: [
    "DIAGNOSTIC",
    "MAP",
    "KANBAN",
    "OR_HUB",
    "E3I_INTELLIGENCE",
    "CLIENT_PROJECTS",
    "EXECUTIVE",
    "COMPLIANCE",
    "REPORTS",
    "ADMINISTRATION",
    "PORTFOLIO",
    "PROCESSES",
    "IMPROVEMENTS",
    "OPERATIONS"
  ],
  Executivo: [
    "EXECUTIVE",
    "COMPLIANCE",
    "REPORTS",
    "PORTFOLIO",
    "PROCESSES",
    "IMPROVEMENTS",
    "CLIENT_PROJECTS"
  ],
  "Gestor de Portfólio": [
    "PORTFOLIO",
    "CLIENT_PROJECTS",
    "EXECUTIVE",
    "PROCESSES",
    "IMPROVEMENTS",
    "REPORTS",
    "DIAGNOSTIC"
  ],
  "Dono do Processo": [
    "PROCESSES",
    "MAP",
    "OPERATIONS",
    "KANBAN",
    "IMPROVEMENTS",
    "EXECUTIVE",
    "COMPLIANCE",
    "DIAGNOSTIC"
  ],
  "Líder do Projeto": [
    "IMPROVEMENTS",
    "DMAIC",
    "DIAGNOSTIC",
    "PROCESSES",
    "MAP",
    "OPERATIONS",
    "KANBAN",
    "REPORTS"
  ],
  Analista: [
    "DIAGNOSTIC",
    "PROCESSES",
    "MAP",
    "OPERATIONS",
    "KANBAN",
    "IMPROVEMENTS",
    "OR_HUB",
    "SIGMA_TREND",
    "E3I_INTELLIGENCE",
    "REPORTS"
  ],
  Colaborador: [
    "OPERATIONS",
    "KANBAN",
    "PROCESSES",
    "IMPROVEMENTS"
  ],
  Auditor: [
    "COMPLIANCE",
    "PORTFOLIO",
    "CLIENT_PROJECTS",
    "IMPROVEMENTS",
    "PROCESSES",
    "REPORTS"
  ],
  Visualizador: [
    "EXECUTIVE",
    "PORTFOLIO",
    "PROCESSES",
    "REPORTS"
  ]
};

// Interface of Delegations and Substitutions
export interface DelegationRecord {
  id: string;
  grantorUser: string;
  grantorRole: UserProfileRole;
  delegateeName: string;
  delegateeRole: UserProfileRole;
  startDate: string; // ISO Date YYYY-MM-DD
  endDate: string;   // ISO Date YYYY-MM-DD
  status: "Ativa" | "Agendada" | "Expirada" | "Cancelada";
  reason: string;
  delegatedPermissions: PermissionType[];
}

export function isDateWithinRange(dateStr: string, startStr: string, endStr: string): boolean {
  const current = new Date(dateStr).getTime();
  const start = new Date(startStr).getTime();
  const end = new Date(endStr).getTime();
  return current >= start && current <= end;
}

// Global active delegations parser wrapper
export function getActiveDelegationForUser(
  currentUserRole: UserProfileRole,
  currentUserName: string,
  delegations: DelegationRecord[]
): DelegationRecord | null {
  const todayStr = new Date().toISOString().split("T")[0];
  
  const active = delegations.find(del => {
    if (del.status !== "Ativa" && del.status !== "Agendada") return false;
    
    // The delegatee must match the name of the user, or if name is empty, match by role
    const matchesUser = del.delegateeName 
      ? del.delegateeName === currentUserName 
      : del.delegateeRole === currentUserRole;
    if (!matchesUser) return false;

    // Check dates bounds
    return isDateWithinRange(todayStr, del.startDate, del.endDate);
  });

  return active || null;
}

// Permission checking helper taking delegations into account!
export function checkPermission(
  role: UserProfileRole,
  permission: PermissionType,
  delegations: DelegationRecord[] = [],
  currentUserName: string = ""
): { allowed: boolean; viaDelegation: boolean; sourceRole?: UserProfileRole } {
  // 1. Direct role check
  if (PERMISSIONS_BY_ROLE[role]?.includes(permission)) {
    return { allowed: true, viaDelegation: false };
  }

  // 2. Delegation check: Did someone delegate their authority to this user/role active today?
  const activeDelegation = getActiveDelegationForUser(role, currentUserName, delegations);
  if (activeDelegation && activeDelegation.delegatedPermissions.includes(permission)) {
    // If delegation allows this, yield true!
    return { 
      allowed: true, 
      viaDelegation: true, 
      sourceRole: activeDelegation.grantorRole 
    };
  }

  return { allowed: false, viaDelegation: false };
}

// Module checker taking dynamic delegations into account as well
export function checkModuleAllowed(
  role: UserProfileRole,
  viewKey: string,
  delegations: DelegationRecord[] = [],
  currentUserName: string = ""
): boolean {
  // Map module aliases if any
  let normalizedKey = viewKey;
  if (viewKey === "ADMIN") normalizedKey = "ADMINISTRATION";
  if (viewKey === "CLIENT_PROJECTS") normalizedKey = "PORTFOLIO";
  if (viewKey === "MAP" || viewKey === "BPM") normalizedKey = "PROCESSES";
  if (viewKey === "DMAIC" || viewKey === "OR_HUB" || viewKey === "SIGMA_TREND" || viewKey === "ROI_DASHBOARD") normalizedKey = "IMPROVEMENTS";
  if (viewKey === "KANBAN") normalizedKey = "OPERATIONS";
  if (viewKey === "REPORT") normalizedKey = "REPORTS";

  // Public views are always allowed
  if (normalizedKey === "PUBLIC_SALES") return true;

  // 1. Primary Allowed Modules check
  const roleViews = MODULE_ACCESS_BY_ROLE[role] || [];
  if (roleViews.includes(normalizedKey) || roleViews.includes(viewKey)) {
    return true;
  }

  // 2. Administration is strictly restricted to Administrador
  if (normalizedKey === "ADMINISTRATION" && role !== "Administrador") {
    // Check if under an active Administrator delegation
    const activeDel = getActiveDelegationForUser(role, currentUserName, delegations);
    if (activeDel && activeDel.grantorRole === "Administrador") {
      return true;
    }
    return false;
  }

  // 3. Delegatee can also access grantor's allowed modules
  const activeDelegation = getActiveDelegationForUser(role, currentUserName, delegations);
  if (activeDelegation) {
    const grantorViews = MODULE_ACCESS_BY_ROLE[activeDelegation.grantorRole] || [];
    if (grantorViews.includes(normalizedKey) || grantorViews.includes(viewKey)) {
      return true;
    }
  }

  return false;
}

export interface CustomKpiValue {
  id: string;
  name: string;
  value: string;
  unit: string;
  trend: "up" | "down" | "stable";
  colorClass: string;
  helpText: string;
}

// Generates dynamic customized KPIs according to selected profile (up to 5 or 6 maximum per role)
export function getCustomKpisForRole(
  role: UserProfileRole,
  stats: any,
  arrivalRate: number
): CustomKpiValue[] {
  const safeStats = {
    leadTime: stats?.leadTime ?? 15,
    processingTimeSum: stats?.processingTimeSum ?? 5,
    sigmaLevel: stats?.sigmaLevel ?? 4.25,
    dpmo: stats?.dpmo ?? 3400,
    systemWip: stats?.systemWip ?? 1,
    rolledFirstPassYield: stats?.rolledFirstPassYield ?? 0.95,
  };

  const formatMoney = (val: number) => {
    return "R$ " + Math.round(val).toLocaleString("pt-BR") + ",00";
  };

  switch (role) {
    case "Executivo":
      return [
        {
          id: "exe-roi",
          name: "ROI Total Estimado",
          value: formatMoney((safeStats.leadTime - safeStats.processingTimeSum) * arrivalRate * 125 * 12),
          unit: "Gerado ao Ano",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Retorno financeiro anual projetado com base em eliminações de gargalos estocásticos."
        },
        {
          id: "exe-saved",
          name: "Ganhos Operacionais",
          value: formatMoney((safeStats.leadTime - safeStats.processingTimeSum) * 85 * arrivalRate * 10),
          unit: "Acumulado",
          trend: "up",
          colorClass: "text-indigo-700 bg-indigo-50 border-indigo-200",
          helpText: "Ganhos financeiros diretos medidos por redução de estoques intermediários."
        },
        {
          id: "exe-success",
          name: "Projetos LSS no Prazo",
          value: "94,2%",
          unit: "Taxa de Sucesso",
          trend: "stable",
          colorClass: "text-amber-700 bg-amber-50 border-amber-200",
          helpText: "Percentual de projetos DMAIC com aderência estrita de cronograma corporativo."
        },
        {
          id: "exe-sla",
          name: "SLA Global Cumprido",
          value: "96,8%",
          unit: "Eficiência de Entrega",
          trend: "up",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Mediana global de atendimento ao cliente em todas as unidades de negócios."
        },
        {
          id: "exe-sigma",
          name: "Nível Sigma Corporativo",
          value: safeStats.sigmaLevel.toFixed(2) + " σ",
          unit: "Qualidade de Processos",
          trend: "up",
          colorClass: "text-purple-705 bg-purple-50 border-purple-200",
          helpText: "Maturidade operacional consolidada (Qualidade de Classe Mundial)."
        }
      ];

    case "Gestor de Portfólio": {
      const activeProjBudget = (safeStats.leadTime * 3500);
      return [
        {
          id: "port-active",
          name: "Projetos Ativos",
          value: "14",
          unit: "Iniciativas",
          trend: "up",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Projetos Six Sigma atualmente em execução nas áreas de negócios."
        },
        {
          id: "port-delayed",
          name: "Projetos com Atraso",
          value: "2",
          unit: "Sob Atenção",
          trend: "down",
          colorClass: "text-red-700 bg-red-50 border-red-200",
          helpText: "Projetos com marcos atrasados ou desvios em relação à linha de base."
        },
        {
          id: "port-capacity",
          name: "Utilização de Capacidade",
          value: "82,5%",
          unit: "Alocação de Recursos",
          trend: "stable",
          colorClass: "text-amber-700 bg-amber-50 border-amber-200",
          helpText: "Nível de saturação das equipes técnicas e Green/Black Belts."
        },
        {
          id: "port-roi",
          name: "ROI Estimado Portfólio",
          value: formatMoney(activeProjBudget * 9.2),
          unit: "Impacto Previsto",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-[#C49746]/30",
          helpText: "Valor consolidado de redução de desperdício nos projetos ativos."
        },
        {
          id: "port-completed",
          name: "Projetos Concluídos",
          value: "38",
          unit: "Iniciativas Entregues",
          trend: "up",
          colorClass: "text-[#C49746] bg-amber-50/55 border-[#C49746]/20",
          helpText: "Total de melhorias concluídas com homologação financeira."
        }
      ];
    }

    case "Dono do Processo": {
      const isSlaBreached = safeStats.leadTime > 30;
      return [
        {
          id: "proc-sla",
          name: "SLA do Processo",
          value: isSlaBreached ? "81,2%" : "98,5%",
          unit: "Meta: 30 minutos",
          trend: isSlaBreached ? "down" : "up",
          colorClass: isSlaBreached ? "text-red-700 bg-red-50 border-red-200" : "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Percentual de transações concluídas abaixo do SLA contratado."
        },
        {
          id: "proc-bottleneck",
          name: "Instabilidade do Gargalo",
          value: safeStats.systemWip.toFixed(1) + " un.",
          unit: "Estoque no Gargalo",
          trend: "up",
          colorClass: "text-amber-700 bg-amber-50 border-amber-200",
          helpText: "Gargalo atual do fluxo, calculando volume de peças presas in fila."
        },
        {
          id: "proc-cf",
          name: "Fator Variabilidade (CV)",
          value: (safeStats.dpmo / 100000).toFixed(2),
          unit: "Coef. de Variação",
          trend: "stable",
          colorClass: "text-indigo-700 bg-indigo-50 border-indigo-200",
          helpText: "Índice de variabilidade da demanda. Acima de 1,0 indica forte desregulação."
        },
        {
          id: "proc-controls",
          name: "Controles Implantados",
          value: "5 de 5",
          unit: "Aderência LSS",
          trend: "stable",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Controles estabelecidos no plano de controle LSS implementados em produção."
        },
        {
          id: "proc-deviations",
          name: "Não conformidades (DPMO)",
          value: Math.round(safeStats.dpmo).toLocaleString("pt-BR"),
          unit: "por Milhão",
          trend: "down",
          colorClass: "text-purple-701 bg-purple-50 border-purple-200",
          helpText: "Taxa estocástica de defeitos e falhas operacionais detectados."
        }
      ];
    }

    case "Líder do Projeto":
      return [
        {
          id: "lead-dmaic",
          name: "Fase DMAIC Atual",
          value: "Melhoria (I)",
          unit: "Progresso: 75%",
          trend: "up",
          colorClass: "text-[#C49746] bg-amber-50/55 border-[#C49746]/20",
          helpText: "Fase metodológica ativa do projeto LSS no funil corporativo."
        },
        {
          id: "lead-deliverables",
          name: "Entregáveis Concluídos",
          value: "14 de 17",
          unit: "Aprovados",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Proporção de fases técnicas validadas institucionalmente."
        },
        {
          id: "lead-overdue",
          name: "Pendências Atrasadas",
          value: "1",
          unit: "Tarefa em Atraso",
          trend: "down",
          colorClass: "text-amber-700 bg-amber-50 border-amber-200",
          helpText: "Tarefas do plano de melhoria com data limite ultrapassada."
        },
        {
          id: "lead-duration",
          name: "Duração Média Ativa",
          value: "18,2 dias",
          unit: "Por Etapa",
          trend: "stable",
          colorClass: "text-indigo-700 bg-indigo-50 border-indigo-200",
          helpText: "Média de dias decorridos para conclusão de documentos chave."
        },
        {
          id: "lead-productivity",
          name: "Eficiência Gerencial",
          value: "91,5%",
          unit: "Adesão de Prazos",
          trend: "up",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Capacidade da equipe em seguir o cronograma do Project Charter."
        }
      ];

    case "Analista":
      return [
        {
          id: "ana-va",
          name: "Tempo Útil (Valor Agregado)",
          value: safeStats.processingTimeSum.toFixed(1) + " min",
          unit: "Tempo de Toque Real",
          trend: "stable",
          colorClass: "text-[#C49746] bg-amber-50/60 border-amber-200",
          helpText: "Soma absoluta do tempo gasto agregando valor em todas as etapas operacionais."
        },
        {
          id: "ana-lead",
          name: "Tempo de Ciclo (Lead Time)",
          value: safeStats.leadTime.toFixed(1) + " min",
          unit: "Duração de Ponta a Ponta",
          trend: "down",
          colorClass: "text-indigo-700 bg-indigo-50 border-indigo-205",
          helpText: "tempo de atravessamento estocástico aproximado incluindo as filas de espera."
        },
        {
          id: "ana-waste",
          name: "Tempo Espera (NVA Fila)",
          value: (safeStats.leadTime - safeStats.processingTimeSum).toFixed(1) + " min",
          unit: "Inércia em Filas",
          trend: "down",
          colorClass: "text-red-700 bg-red-50 border-red-200",
          helpText: "Desperdício medido em inércia ou congestionamento no lead time."
        },
        {
          id: "ana-yield",
          name: "FPY - First Pass Yield",
          value: (safeStats.rolledFirstPassYield * 105).toFixed(1) + "%",
          unit: "Rendimento de Saída",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-250",
          helpText: "Percentual de unidades que saem sem nenhuma necessidade de retrabalho."
        },
        {
          id: "ana-sims",
          name: "Modelos Simulados",
          value: "18",
          unit: "Cenários Monte Carlo",
          trend: "up",
          colorClass: "text-purple-702 bg-purple-50 border-purple-200",
          helpText: "Total de testes estatísticos de distribuição executados para balanceamento."
        }
      ];

    case "Colaborador":
      return [
        {
          id: "col-done",
          name: "Minhas Tarefas Concluídas",
          value: "11",
          unit: "Esta Semana",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Tarefas concluídas pelo operador sob sua responsabilidade na melhoria."
        },
        {
          id: "col-pending",
          name: "Pendentes na Fila",
          value: "3",
          unit: "Em andamento",
          trend: "stable",
          colorClass: "text-amber-700 bg-amber-50 border-amber-201",
          helpText: "Tarefas operacionais aguardando sua execução imediata."
        },
        {
          id: "col-sop",
          name: "Adesão de POPs / Manuais",
          value: "100%",
          unit: "Trabalho Padronizado",
          trend: "stable",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Nível de conformidade na execução padronizada das operações de rotina."
        },
        {
          id: "col-safety",
          name: "Dias Sem Incidentes",
          value: "450 dias",
          unit: "Meta: Zero Acidentes",
          trend: "up",
          colorClass: "text-[#C49746] bg-amber-50/50 border-[#C49746]/20",
          helpText: "Indicador de segurança operacional na linha ou posto de trabalho."
        },
        {
          id: "col-speed",
          name: "Eficiência de Ciclo Individual",
          value: "95,4%",
          unit: "Ref. Tempo Padrão",
          trend: "up",
          colorClass: "text-purple-703 bg-purple-50 border-purple-200",
          helpText: "Consistência pessoal de tempo de ciclo em relação ao padrão científico."
        }
      ];

    case "Auditor":
      return [
        {
          id: "aud-revising",
          name: "Entregáveis LSS em Análise",
          value: "4",
          unit: "Fases Pendentes",
          trend: "up",
          colorClass: "text-amber-700 bg-amber-50 border-amber-200",
          helpText: "Fases do projeto DMAIC aguardando auditoria formal de comprovação de evidências."
        },
        {
          id: "aud-compliance",
          name: "Maturidade de Conformidade",
          value: "98,2%",
          unit: "Adesão Normativa",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-250",
          helpText: "Robustez das provas colhidas para homologação dos ganhos financeiros."
        },
        {
          id: "aud-nonconformities",
          name: "Não Conformidades Críticas",
          value: "0",
          unit: "Ativas",
          trend: "down",
          colorClass: "text-[#C49746] bg-amber-50/55 border-[#C49746]/20",
          helpText: "Quantidade de inconsistências metodológicas ou falhas em plano de controle LSS."
        },
        {
          id: "aud-audited",
          name: "Controles Auditados",
          value: "27 de 27",
          unit: "SOPs Verificados",
          trend: "stable",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Manuais e padrões industriais validados nas auditorias de campo."
        },
        {
          id: "aud-blockers",
          name: "Bloqueios Ativos de Projeto",
          value: "0",
          unit: "Sem Impedimentos",
          trend: "down",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Projetos impedidos de avançar de fase por falta de critérios de qualidade."
        }
      ];

    case "Visualizador":
      return [
        {
          id: "vis-progress",
          name: "Progresso Consolidado LSS",
          value: "84,0%",
          unit: "Adesão Global",
          trend: "up",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Progresso ponderado do portfólio de planos de melhorias corporativas."
        },
        {
          id: "vis-roi",
          name: "ROI Consolidado",
          value: formatMoney((safeStats.leadTime - safeStats.processingTimeSum) * arrivalRate * 100 * 12),
          unit: "Homologado",
          trend: "up",
          colorClass: "text-[#C49746] bg-amber-50/60 border-amber-300",
          helpText: "Retorno financeiro validado de forma independente pelos auditores."
        },
        {
          id: "vis-flow",
          name: "Eficiência de Fluxo",
          value: ((safeStats.processingTimeSum / safeStats.leadTime) * 105).toFixed(1) + "%",
          unit: "Adesão Geral",
          trend: "stable",
          colorClass: "text-indigo-700 bg-indigo-50 border-indigo-200",
          helpText: "Razão entre valor agregado de toque e o tempo de atravessamento global."
        },
        {
          id: "vis-milestones",
          name: "Cronograma de Entregáveis",
          value: "95,0%",
          unit: "Metas Alcançadas",
          trend: "up",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Performance geral de prazo contratual de melhoria operacional."
        },
        {
          id: "vis-maturity",
          name: "Maturidade Operacional",
          value: "Nível 4",
          unit: "Meta: Nível 5",
          trend: "up",
          colorClass: "text-purple-704 bg-purple-50 border-purple-200",
          helpText: "Estágio de maturidade da gestão de processos industriais baseada no LSS."
        }
      ];

    case "Administrador":
    default:
      return [
        {
          id: "adm-users",
          name: "Usuários Ativos",
          value: "32",
          unit: "Colaboradores",
          trend: "up",
          colorClass: "text-indigo-701 bg-indigo-50 border-indigo-200",
          helpText: "Quantidade de engenheiros de processos e líderes operacionais logados."
        },
        {
          id: "adm-licenses",
          name: "Utilização de Licenças",
          value: "76,8%",
          unit: "Capacidade: 50 Contas",
          trend: "stable",
          colorClass: "text-blue-700 bg-blue-50 border-blue-200",
          helpText: "Adesão de faturamento da assinatura corporativa de SaaS."
        },
        {
          id: "adm-audit",
          name: "Eventos Gravados (Auditoria)",
          value: "1.428 un.",
          unit: "Logs de Segurança",
          trend: "up",
          colorClass: "text-[#C49746] bg-amber-50 border-[#C49746]/20",
          helpText: "Ações operacionais gravadas na trilha de auditoria para conformidade B2B."
        },
        {
          id: "adm-tenants",
          name: "Empresas Isoladas (SaaS)",
          value: "5",
          unit: "Multi-Inquilino",
          trend: "stable",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Número de organizações com isolamento de dados de nível corporativo seguro."
        },
        {
          id: "adm-logs",
          name: "Incidentes de Acesso",
          value: "0 / 100%",
          unit: "Segurança Impecável",
          trend: "down",
          colorClass: "text-emerald-700 bg-emerald-50 border-emerald-200",
          helpText: "Invasões ou bloqueios de requisições sem tokens válidos nas últimas 48h."
        }
      ];
  }
}
