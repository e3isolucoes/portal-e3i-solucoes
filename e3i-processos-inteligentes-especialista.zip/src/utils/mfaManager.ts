/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserProfileRole, PERMISSIONS_BY_ROLE } from "./permissionMatrix";
import { logAuditEvent } from "./auditLogger";

export type MFAMethod = "totp" | "webauthn" | "passkey";

export interface MFAUserConfig {
  enabled: boolean;
  activeMethod?: MFAMethod;
  secretTOTP?: string; // Base32 or QR key representation
  recoveryCodes: string[];
  registeredDevices: {
    id: string;
    name: string;
    registeredAt: string;
    lastUsedAt: string;
  }[];
  consecutiveFailures: number;
  lockedUntil?: string; // ISO timestamp
}

// In-Memory Database / LocalStorage bridge for simulated secure MFA configurations
class MultiFactorAuthEngine {
  private userConfigs: Map<string, MFAUserConfig> = new Map();

  constructor() {
    this.hydrateFromStorage();
  }

  private hydrateFromStorage() {
    try {
      if (typeof window !== "undefined") {
        const stored = localStorage.getItem("e3i_mfa_user_databases");
        if (stored) {
          const parsed = JSON.parse(stored);
          Object.keys(parsed).forEach(email => {
            this.userConfigs.set(email, parsed[email]);
          });
        }
      }
    } catch {}
  }

  private persist() {
    try {
      if (typeof window !== "undefined") {
        const data: Record<string, MFAUserConfig> = {};
        this.userConfigs.forEach((config, email) => {
          data[email] = config;
        });
        localStorage.setItem("e3i_mfa_user_databases", JSON.stringify(data));
      }
    } catch {}
  }

  /**
   * Determine if a user MUST have MFA enabled based on their role and permissions.
   * Mandated for: Admins, Auditors, and anyone with "exportar" or security/sensitive access.
   */
  public isMFARequired(role: UserProfileRole): boolean {
    if (role === "Administrador" || role === "Auditor") {
      return true;
    }
    const permissions = PERMISSIONS_BY_ROLE[role] || [];
    if (permissions.includes("exportar") || permissions.includes("administrar") || permissions.includes("auditar")) {
      return true;
    }
    return false;
  }

  /**
   * Retrieve or initialize MFA config for a user.
   */
  public getUserConfig(email: string): MFAUserConfig {
    let config = this.userConfigs.get(email);
    if (!config) {
      config = {
        enabled: false,
        recoveryCodes: [],
        registeredDevices: [],
        consecutiveFailures: 0
      };
      this.userConfigs.set(email, config);
      this.persist();
    }
    return config;
  }

  /**
   * Generate 8 unique backup recovery codes.
   */
  public generateRecoveryCodes(): string[] {
    const codes: string[] = [];
    for (let i = 0; i < 8; i++) {
      const segment1 = Math.floor(100000 + Math.random() * 900000).toString();
      codes.push(`E3I-${segment1}`);
    }
    return codes;
  }

  /**
   * Safe registration of MFA TOTP or WebAuthn device.
   */
  public setupMFA(email: string, method: MFAMethod, secret?: string): { secret: string; recoveryCodes: string[] } {
    const config = this.getUserConfig(email);
    const mfaSecret = secret || "E3ITOTPSECRET" + Math.floor(10000000 + Math.random() * 90000000).toString(16).toUpperCase();
    const recoveryCodes = this.generateRecoveryCodes();

    config.secretTOTP = mfaSecret;
    config.activeMethod = method;
    config.recoveryCodes = recoveryCodes;
    config.registeredDevices = [
      {
        id: `dev-${Date.now()}`,
        name: method === "totp" ? "Authenticator App (TOTP)" : "Biometric Passkey (WebAuthn)",
        registeredAt: new Date().toISOString(),
        lastUsedAt: new Date().toISOString()
      }
    ];
    // Not enabled yet, user needs to confirm with a subsequent TOTP Token Challenge
    this.persist();
    return { secret: mfaSecret, recoveryCodes };
  }

  /**
   * Confirms and activates MFA for user.
   */
  public confirmMFAActivation(email: string, token: string): boolean {
    const config = this.getUserConfig(email);
    if (!config.secretTOTP) return false;

    // Standard simulation of correct TOTP code
    const isValid = token === "123456" || token === "e3i-mfa-bypass-dev" || (token.length === 6 && !isNaN(Number(token)));
    
    if (isValid) {
      config.enabled = true;
      config.consecutiveFailures = 0;
      this.persist();

      logAuditEvent({
        organizationId: "e3i_corp",
        companyId: "multi_tenant_security",
        userId: email,
        userEmail: email,
        userName: email,
        action: "MFA Ativado & Confirmado",
        entityType: "security_profile",
        entityId: email,
        newValue: `Method: ${config.activeMethod}`
      });

      return true;
    }
    return false;
  }

  /**
   * Verify an MFA code during login or critical actions.
   * Strict rateliminate: locks account for 3 minutes after 5 consecutive failures.
   */
  public verifyCode(email: string, token: string): { success: boolean; error?: string; usedRecoveryCode?: boolean } {
    const config = this.getUserConfig(email);
    if (!config.enabled) {
      return { success: true }; // MFA not active
    }

    // Check Lockout
    if (config.lockedUntil) {
      const lockTime = new Date(config.lockedUntil).getTime();
      if (Date.now() < lockTime) {
        const remainingSec = Math.ceil((lockTime - Date.now()) / 1000);
        
        logAuditEvent({
          organizationId: "e3i_corp",
          companyId: "security_auditing",
          userId: email,
          userEmail: email,
          userName: email,
          action: "Tentativa de login bloqueada (Lockout ativo)",
          entityType: "blockout",
          entityId: email
        });

        return {
          success: false,
          error: `Múltiplas tentativas incorretas. Conta bloqueada temporariamente. Tente novamente em ${remainingSec} segundos.`
        };
      } else {
        // Lock expired
        config.lockedUntil = undefined;
        config.consecutiveFailures = 0;
        this.persist();
      }
    }

    // 1. Check recovery code usage
    if (token.startsWith("E3I-")) {
      const idx = config.recoveryCodes.indexOf(token);
      if (idx !== -1) {
        // Use and consume recovery code (immutable once consumed)
        config.recoveryCodes.splice(idx, 1);
        config.consecutiveFailures = 0;
        this.persist();

        logAuditEvent({
          organizationId: "e3i_corp",
          companyId: "multi_tenant_security",
          userId: email,
          userEmail: email,
          userName: email,
          action: "Código de Recuperação MFA Consumido",
          entityType: "security_profile",
          entityId: email,
          newValue: `Remaining codes count: ${config.recoveryCodes.length}`
        });

        return { success: true, usedRecoveryCode: true };
      }
    }

    // 2. Normal token validation (simulating TOTP and Passkey)
    const isMockValid = token === "123456" || token === "e3i-mfa-bypass-dev" || (token.startsWith("fingerprint_passkey_") && config.activeMethod === "passkey");
    const isTotp = token.length === 6 && !isNaN(Number(token)) && token !== "000000"; // any 6 digit non-zero is verified for demo flow unless bad input
    
    const isValid = isMockValid || (config.activeMethod === "totp" && isTotp && token !== "999999"); // 999999 triggers bad code in test

    if (isValid) {
      config.consecutiveFailures = 0;
      if (config.registeredDevices.length > 0) {
        config.registeredDevices[0].lastUsedAt = new Date().toISOString();
      }
      this.persist();
      return { success: true };
    } else {
      // Failure logic & progressive clamping lock
      config.consecutiveFailures += 1;
      let errorMsg = `Código MFA inválido. Tentativa ${config.consecutiveFailures} de 5.`;

      if (config.consecutiveFailures >= 5) {
        const lockoutDurationMs = 3 * 60 * 1000; // 3 minutes lockout
        config.lockedUntil = new Date(Date.now() + lockoutDurationMs).toISOString();
        errorMsg = "Bloqueio imediato de segurança: Limite de tentativas violado. Conta suspensa por 3 minutos.";
        
        logAuditEvent({
          organizationId: "e3i_corp",
          companyId: "multi_tenant_security",
          userId: email,
          userEmail: email,
          userName: email,
          action: "Bloqueio de Perfil por Força Bruta (MFA)",
          entityType: "security_profile",
          entityId: email,
          newValue: "LOCKED_OUT_3_MIN"
        });
      } else {
        logAuditEvent({
          organizationId: "e3i_corp",
          companyId: "multi_tenant_security",
          userId: email,
          userEmail: email,
          userName: email,
          action: `Falha de Verificação MFA - Tentativa: ${config.consecutiveFailures}`,
          entityType: "security_profile",
          entityId: email
        });
      }

      this.persist();
      return { success: false, error: errorMsg };
    }
  }

  /**
   * Revoke MFA entirely for user.
   */
  public revokeMFA(email: string): void {
    const config = this.getUserConfig(email);
    config.enabled = false;
    config.secretTOTP = undefined;
    config.activeMethod = undefined;
    config.recoveryCodes = [];
    config.registeredDevices = [];
    config.consecutiveFailures = 0;
    config.lockedUntil = undefined;
    this.persist();

    logAuditEvent({
      organizationId: "e3i_corp",
      companyId: "multi_tenant_security",
      userId: email,
      userEmail: email,
      userName: email,
      action: "Dispositivo & MFA Revogados pelo Usuário",
      entityType: "security_profile",
      entityId: email,
      newValue: "MFA_REVOKED_DEACTIVATED"
    });
  }
}

export const MFAAuth = new MultiFactorAuthEngine();
