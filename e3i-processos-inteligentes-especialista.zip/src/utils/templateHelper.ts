/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BusinessType } from "./industry";
import { PROCESS_TEMPLATES } from "../presets";

export const getInitialTemplate = () => {
  let type: BusinessType = "SERVICES";
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem("lss_business_type");
    if (saved) type = saved as BusinessType;
  }
  let firstTplId = "manufacturing-pcb";
  if (type === "SERVICES") firstTplId = "financial-ap";
  else if (type === "RETAIL") firstTplId = "retail-checkout";
  else if (type === "LOGISTICS") firstTplId = "logistics-fulfillment";
  else if (type === "TECHNOLOGY") firstTplId = "saas-software-delivery";
  else if (type === "HEALTHCARE") firstTplId = "healthcare-patient-flow";
  else if (type === "FINANCE") firstTplId = "accounting-close";
  else if (type === "HUMAN_RESOURCES") firstTplId = "hr-recruitment-funnel";
  
  return PROCESS_TEMPLATES.find((t) => t.id === firstTplId) || PROCESS_TEMPLATES[0];
};
