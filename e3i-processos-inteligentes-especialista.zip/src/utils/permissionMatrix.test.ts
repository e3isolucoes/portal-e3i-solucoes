import { describe, test, expect } from "vitest";
import {
  UserProfileRole,
  PermissionType,
  PERMISSIONS_BY_ROLE,
  MODULE_ACCESS_BY_ROLE,
  checkPermission,
  checkModuleAllowed,
  getCustomKpisForRole,
  isDateWithinRange,
  DelegationRecord
} from "./permissionMatrix";

describe("E3I Processos Inteligentes - Matriz de Permissões e Segurança RBAC", () => {

  // Test 1: Menu por Perfil & Rotas (Module & page level checks)
  test("1. Validação de Menus/Módulos por Perfil", () => {
    // Administrador has all access
    expect(checkModuleAllowed("Administrador", "ADMINISTRATION")).toBe(true);
    expect(checkModuleAllowed("Administrador", "DIAGNOSTIC")).toBe(true);
    expect(checkModuleAllowed("Administrador", "MAP")).toBe(true);

    // Auditor has access to Compliance and Reports, but not Enterprise Engineering or Administration
    expect(checkModuleAllowed("Auditor", "COMPLIANCE")).toBe(true);
    expect(checkModuleAllowed("Auditor", "REPORTS")).toBe(true);
    expect(checkModuleAllowed("Auditor", "ADMINISTRATION")).toBe(false);

    // Colaborador has access to Operations, processes and SOPs, but not administrative setup
    expect(checkModuleAllowed("Colaborador", "OPERATIONS")).toBe(true);
    expect(checkModuleAllowed("Colaborador", "PROCESSES")).toBe(true);
    expect(checkModuleAllowed("Colaborador", "ADMINISTRATION")).toBe(false);
  });

  // Test 2: Ações & Botões (Granular permissions: Approve, Edit, Delete, Export)
  test("2. Validação de Botões e Ações (Editar, Excluir, Aprovar, Exportar)", () => {
    // Executivo can Approve & Export, but cannot Edit or Delete low-level SMT steps directly
    expect(checkPermission("Executivo", "aprovar").allowed).toBe(true);
    expect(checkPermission("Executivo", "exportar").allowed).toBe(true);
    expect(checkPermission("Executivo", "excluir").allowed).toBe(false);

    // Auditor can Audit & Approve, but cannot Delete
    expect(checkPermission("Auditor", "auditar").allowed).toBe(true);
    expect(checkPermission("Auditor", "aprovar").allowed).toBe(true);
    expect(checkPermission("Auditor", "excluir").allowed).toBe(false);

    // Colaborador cannot Approve or Administer, but can View
    expect(checkPermission("Colaborador", "visualizar").allowed).toBe(true);
    expect(checkPermission("Colaborador", "aprovar").allowed).toBe(false);
    expect(checkPermission("Colaborador", "administrar").allowed).toBe(false);

    // Visualizador can only view
    expect(checkPermission("Visualizador", "visualizar").allowed).toBe(true);
    expect(checkPermission("Visualizador", "criar").allowed).toBe(false);
    expect(checkPermission("Visualizador", "aprovar").allowed).toBe(false);
  });

  // Test 3: Delegação e Cobertura de Ausências (Temporary delegations with date checks)
  test("3. Delegação e Cobertura de Ausências Temporárias", () => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split("T")[0];

    const mockDelegations: DelegationRecord[] = [
      {
        id: "del-test-1",
        grantorUser: "Marco Antonio Miranda",
        grantorRole: "Administrador",
        delegateeName: "Ana Silva",
        delegateeRole: "Auditor",
        startDate: yesterdayStr,
        endDate: tomorrowStr,
        status: "Ativa",
        reason: "Licença",
        delegatedPermissions: ["aprovar", "administrar", "visualizar"]
      }
    ];

    // On today, delegation is active
    const todayStr = new Date().toISOString().split("T")[0];
    const insideRange = isDateWithinRange(todayStr, yesterdayStr, tomorrowStr);
    expect(insideRange).toBe(true);

    // Ana Silva, our delegatee Auditor, gets Administration access via active delegation!
    const moduleAllowedWithDelegation = checkModuleAllowed("Auditor", "ADMINISTRATION", mockDelegations, "Ana Silva");
    expect(moduleAllowedWithDelegation).toBe(true);

    // Other Auditor (John Doe) should NOT get delegate benefits since the delegation is targeted specifically to Ana Silva!
    const otherUserAllowed = checkModuleAllowed("Auditor", "ADMINISTRATION", mockDelegations, "John Doe");
    expect(otherUserAllowed).toBe(false);
  });

  // Test 4: Isolamento Multi-Empresas (Multitenancy environment sandboxing)
  test("4. Isolamento e Proteção de Dados Intercompany", () => {
    // Verify metadata isolation:
    const kpisCompanyA = getCustomKpisForRole("Executivo", { leadTime: 12, processingTimeSum: 4, systemWip: 5, rolledFirstPassYield: 0.95 }, 10);
    // KPIs should return normalized formatted arrays
    expect(kpisCompanyA.length).toBeLessThanOrEqual(6);
    expect(kpisCompanyA[0].name).toBeDefined();
  });

  // Test 5: Tentativas de Acesso Indevido (Access policy boundary violations)
  test("5. Reconhecimento de Violação de Acesso (Anti-Hacking)", () => {
    // Attempting unauthorized module should return false
    const hackingAttemptModule = checkModuleAllowed("Visualizador", "ADMINISTRATION");
    expect(hackingAttemptModule).toBe(false);

    const helperAdminAction = checkPermission("Analista", "administrar").allowed;
    expect(helperAdminAction).toBe(false);
  });
});
