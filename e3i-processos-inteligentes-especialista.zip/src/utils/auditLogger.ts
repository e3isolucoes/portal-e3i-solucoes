/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db, auth } from "../firebase";
import { collection, doc, setDoc, serverTimestamp } from "firebase/firestore";

export interface AuditEvent {
  id: string;
  organizationId: string;
  companyId: string;
  projectId?: string;
  userId: string;
  userEmail: string;
  userName: string;
  action: string; // Criar, Editar, Excluir, Aprovar, Rejeitar, etc.
  entityType: string; // "deliverable" | "project" | "company" | "user" | "delegation"
  entityId: string;
  previousValue?: any;
  newValue?: any;
  createdAt: string;
}

// In-memory audit trail array for instant client-side inspection / reporting
let clientAuditTrail: AuditEvent[] = [];

try {
  const saved = localStorage.getItem("e3i_compliance_audit_logs");
  if (saved) {
    clientAuditTrail = JSON.parse(saved);
  }
} catch (e) {
  console.warn("Unable to load client-side compliance logs: ", e);
}

/**
 * Commits a secure, company-isolated audit log event.
 * If Firestore is available and corporate mode is enabled, it sends an append-only transaction log.
 */
export async function logAuditEvent(params: Omit<AuditEvent, "id" | "createdAt">): Promise<AuditEvent> {
  const eventId = "audit-" + Date.now() + "-" + Math.random().toString(36).substring(2, 6);
  const nowStr = new Date().toISOString();

  const fullEvent: AuditEvent = {
    id: eventId,
    ...params,
    createdAt: nowStr,
  };

  // 1. Maintain local history
  clientAuditTrail.unshift(fullEvent);
  if (clientAuditTrail.length > 500) {
    clientAuditTrail = clientAuditTrail.slice(0, 500); // keep it lightweight
  }
  
  try {
    localStorage.setItem("e3i_compliance_audit_logs", JSON.stringify(clientAuditTrail));
  } catch (e) {
    console.error("Local storage error on audit logging: ", e);
  }

  // 2. Output secure trace log to developer console safely without credentials
  console.log(`[E3I SECURITY AUDIT EVENT] Action: "${fullEvent.action}" | Entity: "${fullEvent.entityType}" ID "${fullEvent.entityId}"`);

  // 3. Write append-only document to Firestore if authenticated and not in sandbox training mode
  const isSandbox = typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true";
  
  if (auth.currentUser && !isSandbox) {
    try {
      const logDocRef = doc(collection(db, "access_logs"), eventId);
      // Ensure the exact fields match the firestore.rules expected by `isValidAccessLog()`
      await setDoc(logDocRef, {
        userId: auth.currentUser.uid,
        userEmail: auth.currentUser.email || fullEvent.userEmail,
        action: `${fullEvent.action} ${fullEvent.entityType} ID: ${fullEvent.entityId}`,
        timestamp: serverTimestamp(), // strict firebase rule match
      });
      console.log(`[E3I SECURITY AUDIT CLOUD] Log ${eventId} locked successfully into Firestore 'access_logs'.`);
    } catch (dbErr) {
      console.error("[E3I SECURITY AUDIT ERROR] Could not commit compliance record to cloud database:", dbErr);
    }
  }

  return fullEvent;
}

/**
 * Returns the current local compliance audit trail
 */
export function getLocalAuditTrail(): AuditEvent[] {
  return clientAuditTrail;
}

/**
 * Clears the local compliance logs
 */
export function clearLocalAuditTrail(): void {
  clientAuditTrail = [];
  localStorage.removeItem("e3i_compliance_audit_logs");
}
