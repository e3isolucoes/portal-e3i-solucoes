/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect } from "vitest";
import {
  PRNG,
  sampleDistribution,
  validateBPMNRoutes,
  runDiscreteEventSimulation,
  compareScenarios,
  BPMNNode,
  GatewayRoute,
  SimulationConfig
} from "./simulationEngine";

describe("Fase 10 - Motor de Simulação Estocástica de Processos & Validação de Rotas (E3I)", () => {

  describe("1. Reprodutibilidade da Semente (PRNG Mulberry32)", () => {
    it("deve gerar exatamente a mesma sequência de floats flutuantes com a mesma semente", () => {
      const prng1 = new PRNG(1337);
      const prng2 = new PRNG(1337);

      const seq1 = Array.from({ length: 15 }, () => prng1.next());
      const seq2 = Array.from({ length: 15 }, () => prng2.next());

      expect(seq1).toEqual(seq2);
    });

    it("deve gerar sequências distintas para sementes distintas", () => {
      const prng1 = new PRNG(1234);
      const prng2 = new PRNG(5678);

      const seq1 = Array.from({ length: 10 }, () => prng1.next());
      const seq2 = Array.from({ length: 10 }, () => prng2.next());

      expect(seq1).not.toEqual(seq2);
    });
  });

  describe("2. Amostragem de Distribuições Estatísticas", () => {
    const prng = new PRNG(42);

    it("Constant: deve retornar sempre o valor estático positivo", () => {
      const val = sampleDistribution({ type: "constant", value: 12.5 }, prng);
      expect(val).toBe(12.5);
    });

    it("Uniform: deve gerar números contidos na faixa limite configurada [min, max]", () => {
      for (let i = 0; i < 50; i++) {
        const val = sampleDistribution({ type: "uniform", min: 10, max: 20 }, prng);
        expect(val).toBeGreaterThanOrEqual(10);
        expect(val).toBeLessThanOrEqual(20);
      }
    });

    it("Triangular: deve aproximar a distribuição triangular concentrando-se próximo à moda", () => {
      const samples: number[] = [];
      for (let i = 0; i < 100; i++) {
        const val = sampleDistribution({ type: "triangular", min: 10, max: 30, mode: 15 }, prng);
        expect(val).toBeGreaterThanOrEqual(10);
        expect(val).toBeLessThanOrEqual(30);
        samples.push(val);
      }
      const avg = samples.reduce((s, x) => s + x, 0) / samples.length;
      expect(avg).toBeGreaterThanOrEqual(11);
      expect(avg).toBeLessThanOrEqual(23);
    });

    it("Normal: deve obedecer médias gaussianas e desvio padrão", () => {
      const samples: number[] = [];
      for (let i = 0; i < 200; i++) {
        samples.push(sampleDistribution({ type: "normal", mean: 100, standardDeviation: 10 }, prng));
      }
      const avg = samples.reduce((s, x) => s + x, 0) / samples.length;
      expect(avg).toBeCloseTo(100, 0); // mean should approach 100
    });

    it("Exponential: deve gerar taxas exponenciais decrescentes", () => {
      const samples: number[] = [];
      for (let i = 0; i < 100; i++) {
        samples.push(sampleDistribution({ type: "exponential", rate: 0.5 }, prng));
      }
      const avg = samples.reduce((s, x) => s + x, 0) / samples.length;
      expect(avg).toBeGreaterThan(0.5); // Mean is 1/rate = 2
      expect(avg).toBeLessThan(4);
    });

    it("Poisson: deve simular contagens de ocorrências discretas", () => {
      const samples: number[] = [];
      for (let i = 0; i < 100; i++) {
        samples.push(sampleDistribution({ type: "poisson", lambda: 4.5 }, prng));
      }
      const avg = samples.reduce((s, x) => s + x, 0) / samples.length;
      expect(avg).toBeGreaterThanOrEqual(2.5);
      expect(avg).toBeLessThanOrEqual(6.5);
    });

    it("Beta: deve amostrar taxas entre o intervalo normalizado", () => {
      for (let i = 0; i < 50; i++) {
        const val = sampleDistribution({ type: "beta", alpha: 2.0, beta: 5.0, min: 0, max: 100 }, prng);
        expect(val).toBeGreaterThanOrEqual(0);
        expect(val).toBeLessThanOrEqual(100);
      }
    });

    it("Weibull: deve simular distribuições Weibull para falhas operacionais", () => {
      for (let i = 0; i < 50; i++) {
        const val = sampleDistribution({ type: "weibull", shape: 1.5, scale: 10 }, prng);
        expect(val).toBeGreaterThan(0);
      }
    });

    it("Empirical: deve amostrar elementos exclusivamente da série histórica enviada", () => {
      const dataset = [2.5, 4.0, 9.8, 12.1, 15.0];
      for (let i = 0; i < 100; i++) {
        const val = sampleDistribution({ type: "empirical", observations: dataset }, prng);
        expect(dataset).toContain(val);
      }
    });
  });

  describe("3. Validação Geométrica de Rotas e Parâmetros (BPMN)", () => {
    it("deve acusar erro caso a soma de probabilidades de rotas XOR seja de tamanho diferente de 100%", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Início", type: "start" },
        { id: "xor", name: "Decisão", type: "gateway", gatewayType: "XOR" },
        { id: "end_ok", name: "Fim Sucedido", type: "end" },
        { id: "end_fail", name: "Fim Falhado", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "xor", isDefault: false },
        { id: "r2", gatewayId: "xor", targetNodeId: "end_ok", probability: 40, isDefault: false },
        { id: "r3", gatewayId: "xor", targetNodeId: "end_fail", probability: 45, isDefault: false } // sum = 85%, invalid XOR
      ];

      const errors = validateBPMNRoutes(nodes, routes);
      const sumErr = errors.find((e) => e.type === "sum_mismatch");
      expect(sumErr).toBeDefined();
    });

    it("deve acusar erro caso existam probabilidades negativas", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Início", type: "start" },
        { id: "xor", name: "Decisão", type: "gateway", gatewayType: "XOR" },
        { id: "end_ok", name: "Fim", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "xor", isDefault: false },
        { id: "r2", gatewayId: "xor", targetNodeId: "end_ok", probability: -20, isDefault: false }
      ];

      const errors = validateBPMNRoutes(nodes, routes);
      const negErr = errors.find((e) => e.type === "negative_probability");
      expect(negErr).toBeDefined();
    });

    it("deve validar gateways sem nenhuma rota de saída cadastrada", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Início", type: "start" },
        { id: "xor", name: "Decisão Vazia", type: "gateway", gatewayType: "XOR" }
      ];

      const routes: GatewayRoute[] = [];

      const errors = validateBPMNRoutes(nodes, routes);
      const noOuts = errors.find((e) => e.type === "no_outputs" || e.type === "disconnected_element");
      expect(noOuts).toBeDefined();
    });

    it("deve identificar elementos isolados / desconectados no fluxo", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Início", type: "start" },
        { id: "end", name: "Fim", type: "end" },
        { id: "isolated", name: "Órfão", type: "task" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "end", isDefault: false }
      ];

      const errors = validateBPMNRoutes(nodes, routes);
      const discErr = errors.filter((e) => e.type === "disconnected_element");
      expect(discErr.length).toBeGreaterThan(0);
    });

    it("deve sinalizar ciclos infinitos absolutos sem válvula de escape", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Início", type: "start" },
        { id: "task1", name: "Loopador", type: "task" },
        { id: "task2", name: "Preso", type: "task" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "task1", isDefault: false },
        { id: "r2", gatewayId: "task1", targetNodeId: "task2", isDefault: false },
        { id: "r3", gatewayId: "task2", targetNodeId: "task1", isDefault: false } // continuous infinite loop trap, no End node reachable
      ];

      const errors = validateBPMNRoutes(nodes, routes);
      const loopErr = errors.find((e) => e.type === "infinite_loop" || e.type === "disconnected_element");
      expect(loopErr).toBeDefined();
    });
  });

  describe("4. Simulação de Execuções e Gateways Reais", () => {
    
    // Simple XOR gateway test
    it("deve direcionar e bifurcar tokens através do Gateway XOR", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Start", type: "start" },
        { id: "xor", name: "XOR Split", type: "gateway", gatewayType: "XOR" },
        { id: "end_a", name: "End A", type: "end" },
        { id: "end_b", name: "End B", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "xor", isDefault: false },
        { id: "r2", gatewayId: "xor", targetNodeId: "end_a", probability: 100, isDefault: false }, // 100% force to a
        { id: "r3", gatewayId: "xor", targetNodeId: "end_b", probability: 0, isDefault: false }
      ];

      const config: SimulationConfig = {
        runs: 1,
        horizon: 480,
        timeUnit: "minutes",
        seed: 1234,
        resourceCapacities: { "Operator": 1 },
        initialCount: 5,
        arrivalRate: 0, // rely on initial Count for immediate exits
        resourceCosts: {}
      };

      const result = runDiscreteEventSimulation(nodes, routes, config);
      
      expect(result.metrics.throughput).toBeGreaterThan(0);
      const nodeA = result.nodeMetrics.find((n) => n.nodeId === "end_a");
      const nodeB = result.nodeMetrics.find((n) => n.nodeId === "end_b");
      
      expect(nodeA?.visits).toBe(5);
      expect(nodeB?.visits).toBe(0);
    });

    // Parallel Gateway AND test
    it("deve simular Gateway Paralelo AND para disparos de sub-processos bifurcados", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Start", type: "start" },
        { id: "and", name: "AND Fork", type: "gateway", gatewayType: "AND" },
        { id: "end_top", name: "End Top", type: "end" },
        { id: "end_bot", name: "End Bottom", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r_entry", gatewayId: "start", targetNodeId: "and", isDefault: false },
        { id: "r_top", gatewayId: "and", targetNodeId: "end_top", isDefault: false },
        { id: "r_bot", gatewayId: "and", targetNodeId: "end_bot", isDefault: false }
      ];

      const config: SimulationConfig = {
        runs: 1,
        horizon: 240,
        timeUnit: "minutes",
        seed: 9999,
        resourceCapacities: {},
        initialCount: 3,
        arrivalRate: 0,
        resourceCosts: {}
      };

      const result = runDiscreteEventSimulation(nodes, routes, config);
      const nodeTop = result.nodeMetrics.find((n) => n.nodeId === "end_top");
      const nodeBot = result.nodeMetrics.find((n) => n.nodeId === "end_bot");

      expect(nodeTop?.visits).toBe(3);
      expect(nodeBot?.visits).toBe(3);
    });

    // Retrabalho (Rework) and Repetition Limits test
    it("deve simular loops de retrabalho com limite de repetição (Repetition Limit) de segurança ativo", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Start", type: "start" },
        { id: "task_inspection", name: "Inspeção LSS", type: "task", yieldRate: 0.0, exceptionHandlerId: "end_killed" }, // 0% yield causes continuous failures
        { id: "end_healthy", name: "End Perfect", type: "end" },
        { id: "end_killed", name: "Alter Termination (Overflow)", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "task_inspection", isDefault: false },
        { id: "r2", gatewayId: "task_inspection", targetNodeId: "end_healthy", isDefault: true }
      ];

      const config: SimulationConfig = {
        runs: 1,
        horizon: 1500,
        timeUnit: "minutes",
        seed: 4444,
        resourceCapacities: { "Inspector": 2 },
        initialCount: 1,
        arrivalRate: 0,
        resourceCosts: { "Inspector": 40 }
      };

      const result = runDiscreteEventSimulation(nodes, routes, config);
      const rejectionsSum = result.nodeMetrics.reduce((sum, n) => sum + n.rejectedCount, 0);
      const finalVisitsToFailure = result.nodeMetrics.find((n) => n.nodeId === "end_killed")?.visits || 0;
      
      expect(rejectionsSum).toBeGreaterThan(0);
      expect(finalVisitsToFailure).toBe(1); // token safely redirected to alternate termination limit
    });

    // Saturated queue scenario (Scenario with saturation / bottleneck)
    it("deve registrar tempos significativos de gargalos/filas em cenários saturados", () => {
      const nodes: BPMNNode[] = [
        { id: "start", name: "Start", type: "start" },
        { id: "task_heavy", name: "Trabalho Pesado", type: "task", distribution: { type: "constant", value: 30 }, resource: "Operator" },
        { id: "end", name: "End", type: "end" }
      ];

      const routes: GatewayRoute[] = [
        { id: "r1", gatewayId: "start", targetNodeId: "task_heavy", isDefault: false },
        { id: "r2", gatewayId: "task_heavy", targetNodeId: "end", isDefault: false }
      ];

      const config: SimulationConfig = {
        runs: 5,
        horizon: 600, // 10 hours
        timeUnit: "minutes",
        seed: 777,
        resourceCapacities: { "Operator": 1 }, // Cap = 60/30 * 1 = 2 items/hour
        initialCount: 0,
        arrivalRate: 10, // Arrival = 10 items/hour (Saturated! Ratio = 5.0)
        resourceCosts: { "Operator": 25 }
      };

      const result = runDiscreteEventSimulation(nodes, routes, config);
      const nm = result.nodeMetrics.find((n) => n.nodeId === "task_heavy")!;
      expect(nm.waitingTimeMean).toBeGreaterThan(0);
      expect(result.metrics.bottlenecks).toContain("Trabalho Pesado");
    });
  });

  describe("5. Comparação Analítica de Cenários (As-Is vs To-Be)", () => {
    it("deve carregar comparador e aferir redução percentual de custo e tempo com recomendações vinculadas", () => {
      const currentSim: any = {
        metrics: {
          cycleTimeMean: 120.0,
          totalCostMean: 450.0,
          totalReworks: 14,
          wipMean: 40.5,
          resourceUtilizations: { "Operador": 95.0 }
        }
      };

      const futureSim: any = {
        metrics: {
          cycleTimeMean: 60.0, // improvement of 50%
          totalCostMean: 220.0,
          totalReworks: 3,
          wipMean: 12.0,
          resourceUtilizations: { "Operador": 65.0 }
        }
      };

      const comparison = compareScenarios(currentSim, futureSim);
      expect(comparison.variationPercentage).toBe(-50);
      expect(comparison.direction).toBe("improvement");
      expect(comparison.recommendations.length).toBeGreaterThan(0);
    });
  });

});
