/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, test, expect } from "vitest";
import { validateUpload } from "./uploadValidator";

describe("E3I Processos Inteligentes - Validador de uploads corporativos", () => {
  // Mock File Creator Helper
  const createMockFile = (name: string, size: number, type: string): File => {
    const blob = new Blob(["a".repeat(size)], { type });
    return new File([blob], name, { type });
  };

  test("1. Permite uploads dentro dos conformes de extensão, tamanho e permissões válidas", () => {
    const validFile = createMockFile("sipoc_quadro_branco.png", 2 * 1024 * 1024, "image/png");
    const res = validateUpload(
      validFile,
      "Administrador",
      "Carlos Alberto",
      "comp_e3i_tech",
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(true);
    expect(res.sanitizedName).toBe("sipoc_quadro_branco.png");
    expect(res.error).toBeUndefined();
  });

  test("2. Bloqueia uploads para perfis sem permissões de edição ou criação", () => {
    const validFile = createMockFile("relatorio_kaizen.pdf", 500 * 1024, "application/pdf");
    const res = validateUpload(
      validFile,
      "Visualizador", // Visualizador has no "editar" permission
      "Paula Santos",
      "comp_e3i_tech",
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(false);
    expect(res.error).toContain("Permissão Negada");
  });

  test("3. Impede uploads sem vínculo a empresa ou projeto ativos", () => {
    const validFile = createMockFile("cronograma.xlsx", 100 * 1024, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    const res = validateUpload(
      validFile,
      "Administrador",
      "Carlos Alberto",
      "", // missing company
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(false);
    expect(res.error).toContain("Associação Restrita");
  });

  test("4. Sanitiza e protege nomes de arquivos contra ataques de Directory Traversal", () => {
    // Attempting a traversal name with malicious characters
    const dirtyFile = createMockFile("../../../etc/passwd_evidencia.pdf", 450, "application/pdf");
    const res = validateUpload(
      dirtyFile,
      "Administrador",
      "Carlos Alberto",
      "comp_e3i_tech",
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(true);
    // Path slashes must be rewritten to safer underscores and the dot prefix check assigns a secure fallback template
    expect(res.sanitizedName).not.toContain("../");
    expect(res.sanitizedName).toContain("compliance_attachment_");
  });

  test("5. Enforca limites de tamanho rígido (Bloqueio acima de 15MB)", () => {
    const oversizedFile = createMockFile("dados_gigantesconao_organizados.xlsx", 16 * 1024 * 1024, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    const res = validateUpload(
      oversizedFile,
      "Administrador",
      "Carlos Alberto",
      "comp_e3i_tech",
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(false);
    expect(res.error).toContain("excedeu o limite máximo de 15MB");
  });

  test("6. Bloqueia extensões executáveis perigosas ou do lado do cliente", () => {
    const badFile = createMockFile("malware.exe", 1024, "application/octet-stream");
    const res = validateUpload(
      badFile,
      "Administrador",
      "Carlos Alberto",
      "comp_e3i_tech",
      "proj_lean_reduction"
    );

    expect(res.valid).toBe(false);
    expect(res.error).toContain("Extensão bloqueada");
  });
});
