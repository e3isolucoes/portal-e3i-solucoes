/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BusinessType = "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "FINANCE" | "HUMAN_RESOURCES";

export function mapIndustryToBusinessType(industryStr?: string): BusinessType {
  if (!industryStr) return "INDUSTRIAL";
  const norm = industryStr.toLowerCase();
  if (norm.includes("industrial") || norm.includes("manufatura")) return "INDUSTRIAL";
  if (norm.includes("serviço") || norm.includes("service")) return "SERVICES";
  if (norm.includes("varejo") || norm.includes("retail")) return "RETAIL";
  if (norm.includes("logíst") || norm.includes("logistic") || norm.includes("transporte")) return "LOGISTICS";
  if (norm.includes("tecnolog") || norm.includes("tech")) return "TECHNOLOGY";
  if (norm.includes("saúde") || norm.includes("health") || norm.includes("med")) return "HEALTHCARE";
  if (norm.includes("financ") || norm.includes("risk") || norm.includes("banc")) return "FINANCE";
  if (norm.includes("recurso") || norm.includes("human") || norm.includes("hr")) return "HUMAN_RESOURCES";
  return "INDUSTRIAL"; // fallback default
}

export function getIndustryIcon(industry?: string): string {
  const ind = (industry || "").toUpperCase();
  if (ind.includes("LOGISTIC") || ind.includes("LOGÍSTIC") || ind.includes("DISTRIB") || ind.includes("ENTREGA") || ind.includes("TRANSPORT")) return "🚚";
  if (ind.includes("MANUFACTUR") || ind.includes("INDÚSTR") || ind.includes("INDUSTR") || ind.includes("FABRI") || ind.includes("METAL")) return "🏭";
  if (ind.includes("FINANC") || ind.includes("BANCO") || ind.includes("INVEST")) return "🏦";
  if (ind.includes("RETAIL") || ind.includes("VAREJO") || ind.includes("LOJA") || ind.includes("COMERC") || ind.includes("COMÉRC")) return "🛒";
  if (ind.includes("HEALTH") || ind.includes("SAÚDE") || ind.includes("SAUDE") || ind.includes("HOSP") || ind.includes("FARMA")) return "🏥";
  if (ind.includes("SERV") || ind.includes("CONSULT") || ind.includes("TI") || ind.includes("DESENV") || ind.includes("BUSINESS") || ind.includes("B2B")) return "💼";
  if (ind.includes("TECNOLO") || ind.includes("TECH") || ind.includes("SOFTWARE") || ind.includes("DIGITAL")) return "💻";
  return "🏢";
}
