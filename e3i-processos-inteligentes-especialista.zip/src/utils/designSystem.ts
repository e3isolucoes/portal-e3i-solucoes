/**
 * E3I Processos Inteligentes - Centralized Design System
 * 
 * Defines cohesive design tokens, typography, spacing, semantic colors,
 * responsive styles, accessibility helpers, and unified layouts.
 * Highly aligned with the E3I core identity: slate and royal blue.
 */

// 1. Color Tokens (HEX and Tailwind equivalents)
export const COLORS = {
  brand: {
    dark: "#0F172A",     // Deep dark blue-slate
    royal: "#1E3A8A",    // Brand royal blue
    slate: "#334155",    // Dark slate gray
    gold: "#C49746",     // E3I gold accent
    white: "#FFFFFF",    // Absolute white
    lightBg: "#FAF9F5",  // Warm off-white
    border: "#E2E8F0",   // Slate-200 border
  },
  semantic: {
    success: {
      text: "text-emerald-800",
      bg: "bg-emerald-50",
      border: "border-emerald-200",
      accent: "bg-emerald-500",
    },
    warning: {
      text: "text-amber-800",
      bg: "bg-amber-50",
      border: "border-amber-200",
      accent: "bg-amber-500",
    },
    error: {
      text: "text-rose-800",
      bg: "bg-rose-50",
      border: "border-rose-200",
      accent: "bg-rose-600",
    },
    info: {
      text: "text-sky-800",
      bg: "bg-sky-50",
      border: "border-sky-200",
      accent: "bg-sky-500",
    },
    risk: {
      text: "text-red-900 bg-red-50/50",
      bg: "bg-red-50",
      border: "border-red-200",
      accent: "bg-red-650",
    },
    neutral: {
      text: "text-slate-700",
      bg: "bg-slate-50",
      border: "border-slate-200",
      accent: "bg-slate-500",
    }
  }
};

// 2. Component Class Tokens for Strict Standardization
export const DESIGN_SYSTEM = {
  // Layout Elements
  card: "bg-white border border-slate-200/80 rounded-xl shadow-xs p-5 md:p-6 transition-all hover:shadow-sm focus-within:ring-2 focus-within:ring-sky-500/10",
  kpiCard: "bg-white border border-slate-200 rounded-xl p-4 md:p-5 flex flex-col justify-between hover:border-[#C49746]/50 transition-all shadow-3xs",
  
  // Interactive Elements
  button: {
    primary: "px-4 py-2.5 bg-[#1E3A8A] text-white hover:bg-slate-900 active:scale-[0.98] transition-all rounded-lg font-sans font-bold text-xs uppercase tracking-wide cursor-pointer flex items-center justify-center gap-2 focus:ring-2 focus:ring-sky-500 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed",
    secondary: "px-4 py-2.5 bg-white text-slate-800 hover:bg-slate-50 border border-slate-200 active:scale-[0.98] transition-all rounded-lg font-sans font-bold text-xs uppercase tracking-wide cursor-pointer flex items-center justify-center gap-2 focus:ring-2 focus:ring-[#1E3A8A]/20 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed",
    accent: "px-4 py-2.5 bg-[#C49746] text-white hover:bg-[#B38635] active:scale-[0.98] transition-all rounded-lg font-sans font-bold text-xs uppercase tracking-wide cursor-pointer flex items-center justify-center gap-2 focus:ring-2 focus:ring-[#C49746]/20 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed",
    danger: "px-4 py-2.5 bg-rose-600 text-white hover:bg-rose-700 active:scale-[0.98] transition-all rounded-lg font-sans font-bold text-xs uppercase tracking-wide cursor-pointer flex items-center justify-center gap-2 focus:ring-2 focus:ring-rose-500/20 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed",
    text: "px-3 py-1.5 text-slate-600 hover:text-slate-900 font-sans font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 focus:outline-none focus:underline"
  },

  // Forms
  input: "w-full bg-[#FAF9F5]/30 border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:border-[#1E3A8A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500/30 transition-all font-sans",
  select: "w-full bg-[#FAF9F5]/30 border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 focus:border-[#1E3A8A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500/30 transition-all cursor-pointer font-sans",
  textarea: "w-full bg-[#FAF9F5]/30 border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:border-[#1E3A8A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500/30 transition-all font-sans resize-y min-h-[80px]",
  checkbox: "h-4 w-4 rounded border-slate-350 text-[#1E3A8A] focus:ring-[#1E3A8A]/30 transition-all cursor-pointer",
  radio: "h-4 w-4 border-slate-350 text-[#1E3A8A] focus:ring-[#1E3A8A]/30 transition-all cursor-pointer",

  // Table Design
  table: {
    container: "overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-3xs",
    table: "min-w-full divide-y divide-slate-100",
    thead: "bg-slate-50/80 font-sans text-[10.5px] font-extrabold uppercase tracking-widest text-slate-500 text-left border-b border-slate-200",
    th: "px-4 py-3.5",
    tbody: "divide-y divide-slate-100 bg-white",
    tr: "hover:bg-slate-50/45 transition-colors",
    td: "px-4 py-3.5 text-sm font-sans text-slate-700 leading-relaxed"
  },

  // Indicators / Badges
  badge: {
    neutral: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider font-mono bg-slate-100 text-slate-700 border border-slate-200/80",
    success: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider font-mono bg-emerald-50 text-emerald-800 border border-emerald-200",
    warning: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider font-mono bg-amber-50 text-amber-800 border border-amber-200",
    error: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider font-mono bg-rose-50 text-rose-800 border border-rose-200",
    info: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider font-mono bg-sky-50 text-sky-800 border border-sky-200"
  },

  // Navigation / Pagination / Tabs
  tabs: {
    list: "flex border-b border-slate-200 gap-1",
    tab: "px-4 py-2.5 -mb-px text-xs font-bold font-sans uppercase tracking-wide cursor-pointer border-b-2 transition-all outline-none",
    active: "border-[#C49746] text-slate-900 font-black",
    inactive: "border-transparent text-slate-505 hover:text-slate-800"
  }
};

// 3. Accessibility & Usability Assistants (Suficiente contraste, foco, zoom)
export const ACCESSIBILITY = {
  srOnly: "absolute w-px h-px p-0 -m-px overflow-hidden clip-rect-0 border-0", // screen reader only
  touchTarget: "min-h-[44px] min-w-[44px] flex items-center justify-center", // Touch area compliance
  focusRing: "focus:ring-2 focus:ring-[#1E3A8A] focus:outline-none focus:ring-offset-2", // Keyboard focus visually
  textContrast: "text-slate-900 text-left font-sans font-medium tracking-tight"
};
