/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { checkPermission, UserProfileRole } from "./permissionMatrix";

export interface FileValidationResult {
  valid: boolean;
  error?: string;
  sanitizedName?: string;
}

/**
 * Validates a business file upload against size, type, extension, user permissions,
 * and strict association with current workspace company and project.
 */
export function validateUpload(
  file: File,
  currentUserRole: UserProfileRole,
  currentUserName: string,
  companyId: string,
  projectId: string
): FileValidationResult {
  // 1. Permission check: Only user profiles with editing capability can load audit evidence
  const perm = checkPermission(currentUserRole, "editar", [], currentUserName);
  if (!perm.allowed) {
    return {
      valid: false,
      error: "Permissão Negada: Seu perfil de usuário não tem permissão para anexar evidências técnicas."
    };
  }

  // 2. Destino and Associação check
  if (!companyId || companyId === "default_company" || !projectId || projectId === "project-default") {
    return {
      valid: false,
      error: "Associação Restrita: O arquivo deve estar vinculado à empresa e ao projeto LSS ativos."
    };
  }

  // 3. Security Name Sanitization & anti-path-traversal protection
  let sanitized = file.name
    .replace(/[/\\]/g, "_") // remove directory traversals
    .replace(/[<>:"|?*'%$#@!]/g, "") // remove shell characters
    .trim();

  if (!sanitized || sanitized.startsWith(".")) {
    sanitized = `compliance_attachment_${Date.now()}_secured.pdf`;
  }

  // 4. File extension validation
  const fileNameLower = file.name.toLowerCase();
  const allowedExtensions = [".pdf", ".png", ".jpg", ".jpeg", ".xlsx", ".docx", ".zip", ".csv"];
  const hasAllowedExt = allowedExtensions.some(ext => fileNameLower.endsWith(ext));

  if (!hasAllowedExt) {
    return {
      valid: false,
      error: "Extensão bloqueada: Apenas PDF, PNG, JPG/JPEG, XLSX, DOCX, CSV ou ZIP são permitidos."
    };
  }

  // 5. File size safety clamp: 15MB max limit
  const maxBytes = 15 * 1024 * 1024;
  if (file.size > maxBytes) {
    return {
      valid: false,
      error: `Arquivo excedeu o limite máximo de 15MB de armazenamento corporativo. (Tamanho: ${(file.size / (1024 * 1024)).toFixed(2)}MB)`
    };
  }

  // 6. Basic MIME Validation based on browser reports
  const allowedMimePrefixes = [
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/jpg",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/zip",
    "text/csv",
    "application/x-zip-compressed",
    "application/octet-stream" // fallback for some binary extensions
  ];

  if (file.type && !allowedMimePrefixes.includes(file.type)) {
    const isOfficeDoc = file.type.includes("officedocument") || file.type.includes("excel") || file.type.includes("word");
    if (!isOfficeDoc) {
      return {
        valid: false,
        error: "Verificação MIME falhou: O arquivo possui assinatura interna que transgride políticas de segurança."
      };
    }
  }

  return {
    valid: true,
    sanitizedName: sanitized
  };
}
