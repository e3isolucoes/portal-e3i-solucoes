/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// -----------------------------------------------------------------------------
// FASE 13: Central Notification Engine & SMTP/SMS/WebPush Queue Processing
// -----------------------------------------------------------------------------

export type NotificationChannel = "Notificação interna" | "E-mail" | "Web push" | "Integrações futuras" | "Webhooks autorizados";

export type EventType =
  | "Tarefa criada"
  | "Tarefa atribuída"
  | "Prazo próximo"
  | "Prazo vencido"
  | "Aprovação solicitada"
  | "Aprovação concluída"
  | "Entregável rejeitado"
  | "Projeto em risco"
  | "Fase bloqueada"
  | "Indicador fora da meta"
  | "Documento assinado"
  | "Falha de importação"
  | "Evento de segurança";

export interface SmtpConfig {
  companyId: string;
  host: string;
  port: number;
  tls: boolean;
  username: string;
  password?: string; // Secret manager
  senderEmail: string;
  senderName: string;
  limitRatePerSec: number; // rate limiting limit
  allowedDomains: string[]; // empty fits all
  retryPolicy: "fixed" | "exponential";
  maxRetries: number;
  backoffMs: number;
}

export interface NotificationRule {
  id: string;
  companyId: string;
  eventName: EventType;
  daysBefore: number;
  sendTime: string; // e.g., "09:00"
  weekdaysOnly: boolean;
  timezone: string; // e.g. "America/Sao_Paulo"
  repeat: boolean;
  escalationEnabled: boolean;
  alertLimit: number;
  recipients: string[]; // Emails or userIds
  substituteManager?: string; // fallback in case of absence
}

export interface NotificationTemplate {
  id: string;
  name: string;
  event: EventType;
  subject: string;
  body: string; // markdown or plain text
  variables: string[]; // listed vars
  language: "PT_BR" | "EN_US" | "ES_ES";
  companyId: string;
  version: number;
  status: "Ativo" | "Rascunho" | "Cancelado";
}

export interface UserNotificationPreference {
  email: string;
  language: "PT_BR" | "EN_US" | "ES_ES";
  timezone: string;
  channels: NotificationChannel[];
  disabledEventTypes: EventType[]; // only non-mandatory ones
  dailyDigest: boolean;
  digestTime: string; // e.g. "18:00"
}

export interface Notification {
  id: string;
  companyId: string;
  correlationId: string; // Event ID or task ID
  recipient: string;
  channel: NotificationChannel;
  subject: string;
  body: string;
  status: "Aguardando envio" | "Enviando" | "Entregue" | "Falhou" | "Cancelada";
  attempts: number;
  maxRetries: number;
  nextAttemptAt?: string; // ISO string
  errHistory: string[];
  isMandatory: boolean;
  sentAt?: string;
  idempotencyKey: string;
}

export interface NotificationLog {
  id: string;
  notificationId: string;
  timestamp: string;
  status: "Enviando" | "Entregue" | "Falhou" | "Cancelada";
  details: string;
}

export interface NotificationEventPayload {
  id: string;
  companyId: string;
  event: EventType;
  metadata: {
    empresa?: string;
    projeto?: string;
    processo?: string;
    fase?: string;
    tarefa?: string;
    responsavel?: string;
    prazo?: string;
    dias_em_atraso?: string;
    link?: string;
    [key: string]: string | undefined;
  };
  recipients: string[];
  correlationId?: string;
}

// -----------------------------------------------------------------------------
// Secret Manager Simulator (to ensure secrets never leak to front-end)
// -----------------------------------------------------------------------------
const SECRETS_REGISTRY: Record<string, string> = {
  "default-company": "s3cr3t-smtp-key-2026",
  "ALGAR_TECH": "algar-smtp-secure-9102",
  "VALE_SA": "vale-iron-vault-781",
  "AMBEV_CORP": "ambev-hops-456",
  "KLABIN_PAPER": "klabin-pulp-112"
};

export function setSecureSmtpPassword(companyId: string, value: string): void {
  SECRETS_REGISTRY[companyId] = value;
}

export function getSecureSmtpPassword(companyId: string): string {
  return SECRETS_REGISTRY[companyId] || "";
}

// -----------------------------------------------------------------------------
// Central Memory State
// -----------------------------------------------------------------------------

export let smtpConfigurations: Record<string, SmtpConfig> = {
  "ALGAR_TECH": {
    companyId: "ALGAR_TECH",
    host: "smtp.algartech.com.br",
    port: 587,
    tls: true,
    username: "notificador@algartech.com.br",
    senderEmail: "notificador@algartech.com.br",
    senderName: "Algar Tech DMAIC Hub",
    limitRatePerSec: 10,
    allowedDomains: ["algartech.com.br", "e3i.com", "gmail.com"],
    retryPolicy: "exponential",
    maxRetries: 3,
    backoffMs: 50
  },
  "VALE_SA": {
    companyId: "VALE_SA",
    host: "smtp.vale.com",
    port: 465,
    tls: true,
    username: "governance@vale.com",
    senderEmail: "governance@vale.com",
    senderName: "Vale Lean Platform",
    limitRatePerSec: 5,
    allowedDomains: ["vale.com", "corasa.com.br"],
    retryPolicy: "fixed",
    maxRetries: 4,
    backoffMs: 100
  }
};

export let escalationRules: NotificationRule[] = [
  {
    id: "RULE-ESC-01",
    companyId: "ALGAR_TECH",
    eventName: "Prazo vencido",
    daysBefore: 0,
    sendTime: "08:30",
    weekdaysOnly: true,
    timezone: "America/Sao_Paulo",
    repeat: true,
    escalationEnabled: true,
    alertLimit: 5,
    recipients: ["responsavel@algartech.com.br"],
    substituteManager: "gestor.substituto@algartech.com.br"
  }
];

export let templates: NotificationTemplate[] = [
  {
    id: "TEMP-TAREFA-CTR",
    name: "Aviso de Nova Tarefa",
    event: "Tarefa criada",
    subject: "Nova tarefa vinculada no DMAIC: {{tarefa}}",
    body: "Olá, {{responsavel}}!\n\nUma nova tarefa intitulada **{{tarefa}}** foi registrada no projeto **{{projeto}}** (Fase: **{{fase}}**).\nPor favor, acompanhe os prazos operacionais.\n\nAtenciosamente,\nGestão de Processos {{empresa}}",
    variables: ["{{empresa}}", "{{projeto}}", "{{fase}}", "{{tarefa}}", "{{responsavel}}"],
    language: "PT_BR",
    companyId: "ALGAR_TECH",
    version: 1,
    status: "Ativo"
  },
  {
    id: "TEMP-TAREFA-ATR",
    name: "Designação de Tarefa",
    event: "Tarefa atribuída",
    subject: "Tarefa Designada: {{tarefa}}",
    body: "Olá, {{responsavel}}! Você foi alocado na tarefa **{{tarefa}}** vinculada à empresa **{{empresa}}**.",
    variables: ["{{empresa}}", "{{responsavel}}", "{{tarefa}}"],
    language: "PT_BR",
    companyId: "ALGAR_TECH",
    version: 1,
    status: "Ativo"
  },
  {
    id: "TEMP-PRAZO-PROX",
    name: "Alerta de Prazo Próximo",
    event: "Prazo próximo",
    subject: "Aviso: Tarefa {{tarefa}} vence em breve",
    body: "Prezado(a) {{responsavel}},\n\nA tarefa de DMAIC **{{tarefa}}** vinculada à empresa **{{empresa}}** está próxima do prazo limite: **{{prazo}}**.\n\nAcesse: {{link}} para atualizar o status.",
    variables: ["{{empresa}}", "{{responsavel}}", "{{tarefa}}", "Prazo próximo", "{{prazo}}", "{{link}}"],
    language: "PT_BR",
    companyId: "ALGAR_TECH",
    version: 1,
    status: "Ativo"
  },
  {
    id: "TEMP-PRAZO-VENC",
    name: "Atraso Gravíssimo Operacional",
    event: "Prazo vencido",
    subject: "CUIDADO: Tarefa {{tarefa}} atrasada {{dias_em_atraso}} dias",
    body: "# Alerta de Atraso\nA tarefa **{{tarefa}}** está atrasada em **{{dias_em_atraso}}** dias na fase **{{fase}}** da holding **{{empresa}}**.\nFavor sanar este entrave para evitar perigo de capabilidade.",
    variables: ["{{tarefa}}", "{{dias_em_atraso}}", "{{fase}}", "{{empresa}}"],
    language: "PT_BR",
    companyId: "ALGAR_TECH",
    version: 1,
    status: "Ativo"
  },
  {
    id: "TEMP-SEG-VAL",
    name: "Violabilidade / Alerta de Segurança",
    event: "Evento de segurança",
    subject: "ALERTA DE SEGURANÇA: Evento Crítico em {{empresa}}",
    body: "Prezados,\nUm evento de segurança grave foi disparado no painel da empresa **{{empresa}}**.\n\nCódigo de evento: **{{tarefa}}**\nResponsável: **{{responsavel}}**\nIP e Logs salvos no Ledger.",
    variables: ["{{empresa}}", "{{tarefa}}", "{{responsavel}}"],
    language: "PT_BR",
    companyId: "ALGAR_TECH",
    version: 1,
    status: "Ativo"
  }
];

export let userPreferences: Record<string, UserNotificationPreference> = {
  "responsavel@algartech.com.br": {
    email: "responsavel@algartech.com.br",
    language: "PT_BR",
    timezone: "America/Sao_Paulo",
    channels: ["Notificação interna", "E-mail"],
    disabledEventTypes: [], // receives all
    dailyDigest: false,
    digestTime: "18:00"
  },
  "alvo-preferencia-desativada@algartech.com.br": {
    email: "alvo-preferencia-desativada@algartech.com.br",
    language: "PT_BR",
    timezone: "America/Sao_Paulo",
    channels: ["E-mail"],
    disabledEventTypes: ["Tarefa criada", "Prazo próximo"], // non-mandatory events off
    dailyDigest: false,
    digestTime: "18:00"
  }
};

export let notificationQueue: Notification[] = [];
export let notificationLogs: NotificationLog[] = [];
export let deadLetterQueue: Notification[] = [];

// Track processed idempotency keys to avoid double sending
export const processedKeys = new Set<string>();

// -----------------------------------------------------------------------------
// Core Engines: Parser & Template Compiler
// -----------------------------------------------------------------------------

export function compileTemplate(body: string, vars: NotificationEventPayload["metadata"]): string {
  let result = body;
  for (const [key, val] of Object.entries(vars)) {
    if (val !== undefined) {
      const placeholder = `{{${key}}}`;
      result = result.split(placeholder).join(val);
    }
  }
  return result;
}

// -----------------------------------------------------------------------------
// Idempotency check helper
// -----------------------------------------------------------------------------
export function generateIdempotencyKey(
  companyId: string,
  event: EventType,
  recipient: string,
  correlationId: string = ""
): string {
  return `${companyId}::${event}::${recipient}::${correlationId}`;
}

// -----------------------------------------------------------------------------
// Mandatory Event list
// Safety and compliance messages are compulsory and bypass user filters.
// -----------------------------------------------------------------------------
export const MANDATORY_EVENTS: EventType[] = [
  "Evento de segurança",
  "Documento assinado",
  "Falha de importação",
  "Aprovação solicitada"
];

// Helper to determine if a channel is ready or has mock transporter errors
export function runSmtpTransporterCheck(config: SmtpConfig): { success: boolean; error?: string } {
  const pwd = getSecureSmtpPassword(config.companyId);
  if (!pwd || pwd === "invalid-secret" || pwd.includes("errado") || pwd.includes("fail") || config.password === "error") {
    return { success: false, error: "Conexão rejeitada: Credenciais SMTP incorretas no Secret Manager" };
  }
  if (config.host === "timeout.smtp.com" || config.host.includes("timeout")) {
    return { success: false, error: "Erro de rede: SMTP Connection timeout (10000ms)" };
  }
  if (!config.host || config.port <= 0) {
    return { success: false, error: "Erro de Configuração: Endereço do host ou porta inválidos" };
  }
  return { success: true };
}

// -----------------------------------------------------------------------------
// Engine Processors: Notification Sender Logic with Rates and Backoff
// -----------------------------------------------------------------------------

export function dispatchNotificationEvent(payload: NotificationEventPayload): {
  createdCount: number;
  duplicateSkipped: number;
} {
  let createdCount = 0;
  let duplicateSkipped = 0;

  const isMandatory = MANDATORY_EVENTS.includes(payload.event);

  for (const recipient of payload.recipients) {
    const key = generateIdempotencyKey(payload.companyId, payload.event, recipient, payload.correlationId);

    // Idempotency and Duplicity Control
    if (processedKeys.has(key)) {
      duplicateSkipped++;
      continue;
    }

    // Checking User Preferences
    const prefs = userPreferences[recipient];
    if (prefs) {
      if (!isMandatory && prefs.disabledEventTypes.includes(payload.event)) {
        // Ignored due to pref toggle
        continue;
      }
    }

    // Load corresponding template
    const tmpl = templates.find((t) => t.event === payload.event && t.companyId === payload.companyId) ||
                 templates.find((t) => t.event === payload.event); // general template fallback

    let subject = `${payload.event}: Atualização DMAIC`;
    let body = `Evento: ${payload.event} registrado no sistema no momento.`;

    if (tmpl) {
      subject = compileTemplate(tmpl.subject, payload.metadata);
      body = compileTemplate(tmpl.body, payload.metadata);
    }

    // Determine config to load max retries
    const smtp = smtpConfigurations[payload.companyId] || { maxRetries: 3, backoffMs: 50 };

    // Find custom channels from user pref
    const chosenChannels: NotificationChannel[] = (prefs && prefs.channels && prefs.channels.length > 0)
      ? prefs.channels
      : ["E-mail"]; // default to E-mail channel

    for (const channel of chosenChannels) {
      const notifId = `NOTIF-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      const notif: Notification = {
        id: notifId,
        companyId: payload.companyId,
        correlationId: payload.correlationId || "EV-NONE",
        recipient,
        channel,
        subject,
        body,
        status: "Aguardando envio",
        attempts: 0,
        maxRetries: smtp.maxRetries ?? 3,
        errHistory: [],
        isMandatory,
        idempotencyKey: key
      };

      notificationQueue.push(notif);
      createdCount++;

      addLog(notifId, "Aguardando envio", "Notificação enfileirada com sucesso");
    }

    // Save key in idempotency registry
    processedKeys.add(key);
  }

  return { createdCount, duplicateSkipped };
}

function addLog(notifId: string, status: Notification["status"], details: string): void {
  notificationLogs.push({
    id: `LOG-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    notificationId: notifId,
    timestamp: new Date().toISOString(),
    status: status === "Aguardando envio" ? "Enviando" : status,
    details
  });
}

// -----------------------------------------------------------------------------
// Fila de Processamento: Runs over the notifications queue synchronously or mock tick
// -----------------------------------------------------------------------------

export function processSingleQueueNotification(notif: Notification): Notification["status"] {
  if (notif.status === "Entregue" || notif.status === "Cancelada" || notif.status === "Falhou") {
    return notif.status;
  }

  notif.status = "Enviando";
  notif.attempts++;
  addLog(notif.id, "Enviando", `Tentativa de envio #${notif.attempts}`);

  // Resolve config or fallback
  const config = smtpConfigurations[notif.companyId];
  if (!config) {
    // If no config found, fallback but fail gracefully
    notif.status = "Falhou";
    notif.errHistory.push("Falha: SMTP não configurado para a empresa");
    addLog(notif.id, "Falhou", "SMTP não configurado para essa holding.");
    deadLetterQueue.push(notif);
    return "Falhou";
  }

  // Validate Allowed Domain
  if (config.allowedDomains && config.allowedDomains.length > 0) {
    const domain = notif.recipient.split("@")[1];
    if (domain && !config.allowedDomains.includes(domain)) {
      notif.status = "Cancelada";
      notif.errHistory.push(`Cancelada: Destinatário inválido para o domínio permitido (${domain})`);
      addLog(notif.id, "Cancelada", `Veto domínio: ${domain} não está na lista autorizada.`);
      return "Cancelada";
    }
  }

  // Check SMTP connection/credentials via sandbox check
  const check = runSmtpTransporterCheck(config);
  if (!check.success) {
    notif.errHistory.push(check.error || "Erro misterioso smtp");
    addLog(notif.id, "Falhou", `Erro de entrega: ${check.error}`);

    if (notif.attempts <= notif.maxRetries) {
      // Config backoff wait indicator
      const multiplier = config.retryPolicy === "exponential" ? Math.pow(2, notif.attempts - 1) : 1;
      const delay = config.backoffMs * multiplier;
      notif.status = "Aguardando envio";
      notif.nextAttemptAt = new Date(Date.now() + delay).toISOString();
      return "Aguardando envio";
    } else {
      notif.status = "Falhou";
      addLog(notif.id, "Falhou", "Limite de tentativas excedido. Deslocado para Dead-Letter Queue (DLQ).");
      deadLetterQueue.push(notif);
      return "Falhou";
    }
  }

  // Success path
  notif.status = "Entregue";
  notif.sentAt = new Date().toISOString();
  addLog(notif.id, "Entregue", `Enviado com sucesso via ${notif.channel} usando ${config.host}:${config.port}`);
  return "Entregue";
}

export function runFullQueueTick(): { processed: number; succeeded: number; dlqCount: number } {
  let processed = 0;
  let succeeded = 0;
  let dlqCount = 0;

  // We clone the queue to avoid mid-loop mutations
  const pending = notificationQueue.filter(n => n.status === "Aguardando envio" || n.status === "Enviando");

  for (const notif of pending) {
    // Check nextAttempt timers
    if (notif.nextAttemptAt && new Date(notif.nextAttemptAt) > new Date()) {
      continue;
    }

    const res = processSingleQueueNotification(notif);
    processed++;
    if (res === "Entregue") {
      succeeded++;
    } else if (res === "Falhou") {
      dlqCount++;
    }
  }

  return { processed, succeeded, dlqCount };
}

// -----------------------------------------------------------------------------
// Daily Digest (Resumo Diário)
// -----------------------------------------------------------------------------

export function generateDailyDigestForUser(recipient: string, companyId: string): {
  digestSubject: string;
  digestBody: string;
  clearedCount: number;
} {
  const userQueue = notificationQueue.filter(
    (n) => n.recipient === recipient && n.companyId === companyId && n.status === "Aguardando envio" && !n.isMandatory
  );

  if (userQueue.length === 0) {
    return { digestSubject: "", digestBody: "", clearedCount: 0 };
  }

  const listItems = userQueue.map((n) => `- [${n.subject}]: ${n.body.substring(0, 100)}...`).join("\n");
  const digestSubject = `Resumo Diário de Atualizações DMAIC - ${companyId}`;
  const digestBody = `# Resumo Diário de Alertas\n\nOlá! Aqui está o consolidado de notificações não obrigatórias enviadas hoje para você:\n\n${listItems}\n\nGestão Integrada dmaic.`;

  // Marcar as originais como consolidadas/canceladas
  for (const notif of userQueue) {
    notif.status = "Entregue";
    notif.sentAt = new Date().toISOString();
    addLog(notif.id, "Entregue", "Consolidado e despachado no Resumo Diário periódico.");
  }

  return {
    digestSubject,
    digestBody,
    clearedCount: userQueue.length
  };
}

// -----------------------------------------------------------------------------
// Deadline & Escalation Planner (Regras de Escalonamento de Prazos)
// 3 dias antes → responsável
// No vencimento → responsável
// 1 dia depois → responsável e líder
// 3 dias depois → gestor
// 7 dias depois → patrocinador
// -----------------------------------------------------------------------------

export interface DeadlineTask {
  id: string;
  name: string;
  companyId: string;
  projectId: string;
  projectName: string;
  phaseName: string;
  responsibleEmail: string;
  leaderEmail: string;
  managerEmail: string;
  sponsorEmail: string;
  deadlineDate: string; // ISO format
}

export function executeDeadlineEscalationCheck(
  task: DeadlineTask,
  currentSystemDateStr: string,
  rule: NotificationRule
): { triggeredLogs: string[]; sentCount: number } {
  const triggeredLogs: string[] = [];
  let sentCount = 0;

  // Calculo real de datas respeitando fuso horário
  const current = new Date(currentSystemDateStr);
  const deadline = new Date(task.deadlineDate);

  // Parse time differences in days
  const msDiff = current.getTime() - deadline.getTime();
  const daysDiff = Math.floor(msDiff / (1000 * 60 * 60 * 24));

  const targetEmail = task.responsibleEmail;
  const isWeekend = current.getDay() === 0 || current.getDay() === 6;

  // Se a regra diz dias úteis e estamos num final de semana, cancela o envio
  if (rule.weekdaysOnly && isWeekend) {
    triggeredLogs.push("Cancelado: Envio cancelado devido a restrição de dias úteis");
    return { triggeredLogs, sentCount };
  }

  // Trigger base factors depending on intervals
  // 3 dias antes (daysDiff === -3)
  if (daysDiff === -3) {
    const payload: NotificationEventPayload = {
      id: `ESC-3BEFORE-${task.id}`,
      companyId: task.companyId,
      event: "Prazo próximo",
      metadata: {
        empresa: task.companyId,
        projeto: task.projectName,
        fase: task.phaseName,
        tarefa: task.name,
        responsavel: task.responsibleEmail,
        prazo: task.deadlineDate,
        link: `/app/projects/${task.projectId}`
      },
      recipients: [targetEmail],
      correlationId: task.id
    };
    const res = dispatchNotificationEvent(payload);
    sentCount += res.createdCount;
    triggeredLogs.push("Triggered: 3 dias antes -> Enviado ao responsável.");
  }

  // No vencimento (daysDiff === 0)
  if (daysDiff === 0) {
    const payload: NotificationEventPayload = {
      id: `ESC-ONDEADLINE-${task.id}`,
      companyId: task.companyId,
      event: "Prazo vencido",
      metadata: {
        empresa: task.companyId,
        projeto: task.projectName,
        fase: task.phaseName,
        tarefa: task.name,
        responsavel: task.responsibleEmail,
        prazo: task.deadlineDate,
        dias_em_atraso: "0",
        link: `/app/projects/${task.projectId}`
      },
      recipients: [targetEmail],
      correlationId: task.id
    };
    const res = dispatchNotificationEvent(payload);
    sentCount += res.createdCount;
    triggeredLogs.push("Triggered: Vencimento hoje -> Enviado ao responsável.");
  }

  // 1 dia depois (daysDiff === 1) -> responsável e líder
  if (daysDiff === 1) {
    const payload: NotificationEventPayload = {
      id: `ESC-1AFTER-${task.id}`,
      companyId: task.companyId,
      event: "Prazo vencido",
      metadata: {
        empresa: task.companyId,
        projeto: task.projectName,
        fase: task.phaseName,
        tarefa: task.name,
        responsavel: task.responsibleEmail,
        prazo: task.deadlineDate,
        dias_em_atraso: "1",
        link: `/app/projects/${task.projectId}`
      },
      recipients: [targetEmail, task.leaderEmail],
      correlationId: task.id
    };
    const res = dispatchNotificationEvent(payload);
    sentCount += res.createdCount;
    triggeredLogs.push("Triggered: 1 dia depois -> Enviado ao responsável e líder.");
  }

  // 3 dias depois (daysDiff === 3) -> gestor (ou substituto se aplicável)
  if (daysDiff === 3) {
    const managerRecipient = rule.substituteManager || task.managerEmail;
    const payload: NotificationEventPayload = {
      id: `ESC-3AFTER-${task.id}`,
      companyId: task.companyId,
      event: "Prazo vencido",
      metadata: {
        empresa: task.companyId,
        projeto: task.projectName,
        fase: task.phaseName,
        tarefa: task.name,
        responsavel: task.responsibleEmail,
        prazo: task.deadlineDate,
        dias_em_atraso: "3",
        link: `/app/projects/${task.projectId}`
      },
      recipients: [managerRecipient],
      correlationId: task.id
    };
    const res = dispatchNotificationEvent(payload);
    sentCount += res.createdCount;
    triggeredLogs.push(`Triggered: 3 dias depois -> Enviado ao gestor (${managerRecipient}).`);
  }

  // 7 dias depois (daysDiff === 7) -> patrocinador
  if (daysDiff === 7) {
    const payload: NotificationEventPayload = {
      id: `ESC-7AFTER-${task.id}`,
      companyId: task.companyId,
      event: "Prazo vencido",
      metadata: {
        empresa: task.companyId,
        projeto: task.projectName,
        fase: task.phaseName,
        tarefa: task.name,
        responsavel: task.responsibleEmail,
        prazo: task.deadlineDate,
        dias_em_atraso: "7",
        link: `/app/projects/${task.projectId}`
      },
      recipients: [task.sponsorEmail],
      correlationId: task.id
    };
    const res = dispatchNotificationEvent(payload);
    sentCount += res.createdCount;
    triggeredLogs.push("Triggered: 7 dias depois -> Enviado ao patrocinador.");
  }

  return { triggeredLogs, sentCount };
}
