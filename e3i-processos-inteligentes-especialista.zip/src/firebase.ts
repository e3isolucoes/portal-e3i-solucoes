import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, doc, getDoc } from "firebase/firestore";

// List of mandatory Firebase environment variables for the client
const MANDATORY_FIREBASE_ENV_VARS = [
  "VITE_FIREBASE_API_KEY",
  "VITE_FIREBASE_AUTH_DOMAIN",
  "VITE_FIREBASE_PROJECT_ID",
  "VITE_FIREBASE_STORAGE_BUCKET",
  "VITE_FIREBASE_MESSAGING_SENDER_ID",
  "VITE_FIREBASE_APP_ID",
];

const viteEnv = (import.meta as any).env || {};
const isProd = viteEnv.PROD || viteEnv.MODE === "production";

// Check for missing variables
const missingVars = MANDATORY_FIREBASE_ENV_VARS.filter(
  (key) => !viteEnv[key]
);

if (missingVars.length > 0) {
  const errMsg = `[Firebase Config Error] Missing required client-side environment variables: ${missingVars.join(", ")}. Please configure them in your .env or platform settings.`;
  
  if (isProd) {
    // In production, we MUST fail fast to prevent silent database issues or security leaks
    console.error(errMsg);
    throw new Error(errMsg);
  } else {
    // In development or demo mode, log a clear warning so developers are aware
    console.warn(`${errMsg} (Running in non-production mode; please configure variables for real database access.)`);
  }
}

// Extract Firebase configuration from environment with safe non-empty fallback values for development
const firebaseConfig = {
  apiKey: viteEnv.VITE_FIREBASE_API_KEY || "PLACEHOLDER_KEY",
  authDomain: viteEnv.VITE_FIREBASE_AUTH_DOMAIN || "placeholder-domain.firebaseapp.com",
  projectId: viteEnv.VITE_FIREBASE_PROJECT_ID || "placeholder-project",
  storageBucket: viteEnv.VITE_FIREBASE_STORAGE_BUCKET || "placeholder-bucket.appspot.com",
  messagingSenderId: viteEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || "000000000000",
  appId: viteEnv.VITE_FIREBASE_APP_ID || "1:000000000000:web:0000000000000000000000",
};

// Initialize Firebase App dynamically
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Extract the optional but recommended custom Firestore database ID
const rawDatabaseId = viteEnv.VITE_FIREBASE_DATABASE_ID;
const databaseId = (rawDatabaseId && !(rawDatabaseId.startsWith("http://") || rawDatabaseId.startsWith("https://") || rawDatabaseId.includes("/") || rawDatabaseId.includes(".com")))
  ? rawDatabaseId
  : undefined;

// Export Firestore with proper database ID (or default instance if not provided)
export const db = databaseId 
  ? getFirestore(app, databaseId) 
  : getFirestore(app);

// Export Authentication instance
export const auth = getAuth(app);

// Connectivity Check per Core Requirement
async function testConnection() {
  if (firebaseConfig.apiKey === "PLACEHOLDER_KEY" || !viteEnv.VITE_FIREBASE_API_KEY) {
    console.warn("[Firebase Connection] Connection test skipped because Firebase has not been configured yet.");
    return;
  }

  try {
    await getDoc(doc(db, "test", "connection"));
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.warn("[Firebase Connection] Client is offline. Offline persistence enabled.");
    } else {
      console.warn("[Firebase Connection] Initial connection check status:", error);
    }
  }
}
testConnection();

// Structured Firestore Error handling for diagnostics
export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMsg = error instanceof Error ? error.message : String(error);
  const errorCode = (error as any)?.code || "";

  // Check if it is a permissions-related error
  const isPermissionError = 
    errorCode === "permission-denied" || 
    errorMsg.toLowerCase().includes("permission") || 
    errorMsg.toLowerCase().includes("insufficient");

  const errInfo: FirestoreErrorInfo = {
    error: errorMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  console.error("Firestore Error: ", JSON.stringify(errInfo));

  if (isPermissionError) {
    // Under core rules we MUST throw a JSON string representing FirestoreErrorInfo
    throw new Error(JSON.stringify(errInfo));
  } else {
    // For offline or other non-permission errors, we just log a warning and let the cache handle it gracefully
    console.warn(`[Firebase Graceful Fallback] Non-permission Firestore error logged: ${errorMsg}`);
  }
}
