import React, { useMemo, useState, useEffect } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  ReferenceLine,
  Brush
} from "recharts";
import { 
  BarChart3, 
  AlertTriangle, 
  CheckCircle2, 
  Info,
  Sliders,
  TrendingUp,
  Search,
  Maximize2
} from "lucide-react";
import { ProcessStep } from "../types";

interface GlobalCycleTimeHistogramProps {
  steps: ProcessStep[];
  selectedStepId?: string | null;
  onSelectStep?: (stepId: string | null) => void;
}

export default function GlobalCycleTimeHistogram({ 
  steps,
  selectedStepId,
  onSelectStep
}: GlobalCycleTimeHistogramProps) {
  // Zoom state (indices for the x-axis timeline)
  const [startIndex, setStartIndex] = useState<number>(0);
  const [endIndex, setEndIndex] = useState<number>(steps.length - 1);

  // Drag-to-pan states
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStartActiveIndex, setDragStartActiveIndex] = useState<number | null>(null);

  // Keep zoom boundaries synchronized with steps array changes
  useEffect(() => {
    setStartIndex(0);
    setEndIndex(Math.max(0, steps.length - 1));
  }, [steps]);

  // Compute global stats
  const stats = useMemo(() => {
    if (!steps || steps.length === 0) return null;

    const processingTimes = steps.map(s => s.processingTime);
    const count = steps.length;
    
    const globalMean = processingTimes.reduce((acc, val) => acc + val, 0) / count;
    
    const variance = processingTimes.reduce((acc, val) => acc + Math.pow(val - globalMean, 2), 0) / count;
    const globalSD = Math.sqrt(variance);
    const threshold2Sigma = globalMean + 2 * globalSD;

    // Identify steps with high variability (either they have high SD themselves, or their cycle time exceeds the 2-sigma limit)
    const highlyVariableSteps = steps.filter(s => s.processingTime > threshold2Sigma);

    return {
      globalMean,
      globalSD,
      threshold2Sigma,
      highlyVariableSteps,
      count
    };
  }, [steps]);

  // Drag-to-pan event handlers
  const handleMouseDown = (state: any) => {
    if (state && typeof state.activeTooltipIndex === "number") {
      setDragStartActiveIndex(state.activeTooltipIndex);
      setIsDragging(true);
    }
  };

  const handleMouseMove = (state: any) => {
    if (isDragging && dragStartActiveIndex !== null && state && typeof state.activeTooltipIndex === "number") {
      const diff = state.activeTooltipIndex - dragStartActiveIndex;
      if (diff !== 0) {
        const range = endIndex - startIndex;
        let newStart = startIndex - diff;
        let newEnd = endIndex - diff;

        // Bound movement within the steps limits
        if (newStart < 0) {
          newStart = 0;
          newEnd = range;
        }
        if (newEnd >= steps.length) {
          newEnd = steps.length - 1;
          newStart = Math.max(0, newEnd - range);
        }

        if (newStart !== startIndex || newEnd !== endIndex) {
          setStartIndex(newStart);
          setEndIndex(newEnd);
          // Update anchor to prevent rapid acceleration
          setDragStartActiveIndex(state.activeTooltipIndex);
        }
      }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragStartActiveIndex(null);
  };

  // Quick pan buttons handlers
  const handlePanLeft = () => {
    const range = endIndex - startIndex;
    const shift = Math.max(1, Math.floor(range / 3));
    let newStart = Math.max(0, startIndex - shift);
    let newEnd = newStart + range;
    if (newEnd >= steps.length) {
      newEnd = steps.length - 1;
      newStart = Math.max(0, newEnd - range);
    }
    setStartIndex(newStart);
    setEndIndex(newEnd);
  };

  const handlePanRight = () => {
    const range = endIndex - startIndex;
    const shift = Math.max(1, Math.floor(range / 3));
    let newEnd = Math.min(steps.length - 1, endIndex + shift);
    let newStart = Math.max(0, newEnd - range);
    setStartIndex(newStart);
    setEndIndex(newEnd);
  };

  // Handler to automatically zoom into the high-variability clusters
  const handleZoomToOutliers = () => {
    if (!steps || steps.length === 0 || !stats) return;

    const { threshold2Sigma } = stats;
    const outlierIndices = steps
      .map((s, idx) => (s.processingTime > threshold2Sigma ? idx : -1))
      .filter(idx => idx !== -1);

    let targetStart = 0;
    let targetEnd = steps.length - 1;

    if (outlierIndices.length > 0) {
      // Zoom into the cluster of outliers (with 1 step padding on each side for context)
      const minIdx = Math.min(...outlierIndices);
      const maxIdx = Math.max(...outlierIndices);
      targetStart = Math.max(0, minIdx - 1);
      targetEnd = Math.min(steps.length - 1, maxIdx + 1);
    } else {
      // Fallback: zoom into the step with the highest coefficient of variation (CV = SD / Mean)
      let maxCvIdx = 0;
      let maxCv = -1;
      steps.forEach((s, idx) => {
        const cv = s.standardDeviation / s.processingTime;
        if (cv > maxCv) {
          maxCv = cv;
          maxCvIdx = idx;
        }
      });
      targetStart = Math.max(0, maxCvIdx - 1);
      targetEnd = Math.min(steps.length - 1, maxCvIdx + 1);
    }

    setStartIndex(targetStart);
    setEndIndex(targetEnd);
  };

  // Determine if we are currently zoomed into outliers
  const isZoomedToOutliers = useMemo(() => {
    if (!steps || steps.length === 0 || !stats) return false;
    const { threshold2Sigma } = stats;
    const outlierIndices = steps
      .map((s, idx) => (s.processingTime > threshold2Sigma ? idx : -1))
      .filter(idx => idx !== -1);

    let targetStart = 0;
    let targetEnd = steps.length - 1;

    if (outlierIndices.length > 0) {
      const minIdx = Math.min(...outlierIndices);
      const maxIdx = Math.max(...outlierIndices);
      targetStart = Math.max(0, minIdx - 1);
      targetEnd = Math.min(steps.length - 1, maxIdx + 1);
    } else {
      let maxCvIdx = 0;
      let maxCv = -1;
      steps.forEach((s, idx) => {
        const cv = s.standardDeviation / s.processingTime;
        if (cv > maxCv) {
          maxCv = cv;
          maxCvIdx = idx;
        }
      });
      targetStart = Math.max(0, maxCvIdx - 1);
      targetEnd = Math.min(steps.length - 1, maxCvIdx + 1);
    }

    return startIndex === targetStart && endIndex === targetEnd;
  }, [steps, startIndex, endIndex, stats]);

  const handleBrushChange = (opts: any) => {
    if (opts && typeof opts.startIndex === "number" && typeof opts.endIndex === "number") {
      setStartIndex(opts.startIndex);
      setEndIndex(opts.endIndex);
    }
  };

  if (!steps || steps.length === 0 || !stats) {
    return (
      <div className="p-6 text-center text-gray-500 font-mono text-xs bg-white border border-[#1A1A1A]/10">
        Nenhuma etapa cadastrada no processo para análise de variabilidade.
      </div>
    );
  }

  const { globalMean, globalSD, threshold2Sigma, highlyVariableSteps } = stats;

  return (
    <div className="bg-white border border-[#1A1A1A]/15 p-6 space-y-6">
      
      {/* Header section */}
      <div className="border-b border-[#1A1A1A]/10 pb-4">
        <div className="flex items-center gap-2">
          <span className="p-1.5 bg-[#F5F2ED] text-[#C49746] rounded-none border border-[#1A1A1A]/10">
            <BarChart3 className="w-4 h-4" />
          </span>
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A] font-sans">
            Distribuição dos Tempos de Ciclo por Etapa (Análise de Desvio 2σ)
          </h3>
        </div>
        <p className="text-[11px] text-[#1A1A1A]/60 mt-1 font-sans">
          Mapeamento comparativo de tempos médios de processamento. Etapas com tempo superior ao limite estatístico de <strong className="font-mono">Média + 2σ</strong> indicam anomalias ou variabilidade crônica.
        </p>
      </div>

      {/* Interactive Zoom Controls & Presets Panel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FAF8F5] border border-[#1A1A1A]/10 p-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-3.5 h-3.5 text-[#C49746] shrink-0" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] font-sans">
            Controle de Zoom do Fluxo:
          </span>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setStartIndex(0);
              setEndIndex(steps.length - 1);
            }}
            className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border transition-all cursor-pointer ${
              startIndex === 0 && endIndex === steps.length - 1
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-[#1A1A1A] border-[#1A1A1A]/15 hover:bg-gray-50"
            }`}
            title="Mostrar todas as etapas do processo"
          >
            Ver Tudo (Reset)
          </button>

          <button
            onClick={handleZoomToOutliers}
            className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border transition-all cursor-pointer flex items-center gap-1 ${
              isZoomedToOutliers
                ? "bg-red-650 text-white border-red-600 shadow-sm"
                : "bg-white text-red-650 border-red-200 hover:bg-red-50/50"
            }`}
            title="Aproxima o gráfico nas etapas com maior variação estatística"
          >
            <TrendingUp className="w-3 h-3" />
            Focar Cluster Crítico (2σ)
          </button>

          <button
            onClick={() => {
              setStartIndex(0);
              setEndIndex(Math.max(0, Math.floor(steps.length / 2) - 1));
            }}
            className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border transition-all cursor-pointer ${
              startIndex === 0 && endIndex === Math.max(0, Math.floor(steps.length / 2) - 1)
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-[#1A1A1A] border-[#1A1A1A]/15 hover:bg-gray-50"
            }`}
          >
            Metade Inicial
          </button>

          <button
            onClick={() => {
              setStartIndex(Math.floor(steps.length / 2));
              setEndIndex(steps.length - 1);
            }}
            className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border transition-all cursor-pointer ${
              startIndex === Math.floor(steps.length / 2) && endIndex === steps.length - 1
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-[#1A1A1A] border-[#1A1A1A]/15 hover:bg-gray-50"
            }`}
          >
            Metade Final
          </button>

          {/* Pan Controls */}
          <div className="flex items-center gap-1 border-l border-[#1A1A1A]/10 pl-2 ml-1">
            <button
              onClick={handlePanLeft}
              disabled={startIndex === 0}
              className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border cursor-pointer transition-all ${
                startIndex === 0
                  ? "opacity-40 cursor-not-allowed bg-gray-50 text-gray-400 border-gray-200"
                  : "bg-white text-[#1A1A1A] border-[#1A1A1A]/15 hover:bg-gray-50"
              }`}
              title="Arrastar visualização para a Esquerda"
            >
              ← Pan Esq.
            </button>
            <button
              onClick={handlePanRight}
              disabled={endIndex === steps.length - 1}
              className={`px-2.5 py-1 text-[9.5px] font-bold font-mono uppercase tracking-wider border cursor-pointer transition-all ${
                endIndex === steps.length - 1
                  ? "opacity-40 cursor-not-allowed bg-gray-50 text-gray-400 border-gray-200"
                  : "bg-white text-[#1A1A1A] border-[#1A1A1A]/15 hover:bg-gray-50"
              }`}
              title="Arrastar visualização para a Direita"
            >
              Pan Dir. →
            </button>
          </div>
        </div>

        <div className="text-[9.5px] font-mono text-gray-500">
          Visualizando <span className="font-bold text-[#1A1A1A]">{endIndex - startIndex + 1}</span> de <span className="font-bold text-[#1A1A1A]">{steps.length}</span> etapas
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Side: Summary metrics card */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#FAF8F5] border border-[#1A1A1A]/15 p-4 space-y-3">
            <span className="block text-[8.5px] uppercase font-mono font-black tracking-widest text-gray-400">
              Métricas Globais de Referência
            </span>
            
            <div className="space-y-2.5 text-xs text-slate-800">
              <div className="flex justify-between items-baseline border-b border-[#1A1A1A]/10 pb-1.5">
                <span className="text-[10px] font-mono text-gray-500">Média Global do Processo (μ):</span>
                <span className="font-mono font-bold text-[#1A1A1A]">{globalMean.toFixed(2)} min</span>
              </div>
              <div className="flex justify-between items-baseline border-b border-[#1A1A1A]/10 pb-1.5">
                <span className="text-[10px] font-mono text-gray-500">Desvio Padrão Global (σ):</span>
                <span className="font-mono font-bold text-[#C49746]">{globalSD.toFixed(3)} min</span>
              </div>
              <div className="flex justify-between items-baseline border-b border-[#1A1A1A]/10 pb-1.5">
                <span className="text-[10px] font-mono text-gray-500">Limite Crítico (Média + 2σ):</span>
                <span className="font-mono font-bold text-red-600">{threshold2Sigma.toFixed(2)} min</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-[10px] font-mono text-gray-500">Etapas Fora do Limite:</span>
                <span className="font-mono font-bold text-red-600">{highlyVariableSteps.length} / {steps.length}</span>
              </div>
            </div>
          </div>

          {/* Feedback message card */}
          <div className={`p-4 border ${
            highlyVariableSteps.length > 0 
              ? "bg-red-50/50 border-red-200/60 text-red-950" 
              : "bg-emerald-50/50 border-emerald-200/60 text-emerald-950"
          }`}>
            <div className="flex items-start gap-2.5">
              <div className="mt-0.5">
                {highlyVariableSteps.length > 0 ? (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                )}
              </div>
              <div className="space-y-1 text-left">
                <h5 className="text-[11px] font-bold font-mono uppercase tracking-wide">
                  {highlyVariableSteps.length > 0 ? "Etapa Crítica Detectada!" : "Estabilidade Geral de Fluxo"}
                </h5>
                <p className="text-[10px] text-gray-600 leading-relaxed font-sans">
                  {highlyVariableSteps.length > 0 ? (
                    <>
                      As etapas em <strong className="text-red-600 font-semibold">Vermelho</strong> excedem o limite de variabilidade máxima e representam grandes riscos de gargalo por acúmulo de filas.
                    </>
                  ) : (
                    <>
                      Nenhuma etapa excede o teto crítico de 2 desvios padrão em relação à média global. O processo apresenta variação sob controle.
                    </>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Recharts BarChart container */}
        <div className="lg:col-span-8 border border-[#1A1A1A]/10 p-4 bg-gray-50/30 rounded-none space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <span className="block text-[8.5px] uppercase font-black tracking-widest text-[#1A1A1A]/40 font-mono">
                Visualização de Tempos de Processamento de cada Etapa
              </span>
              <span className="block text-[9.5px] text-[#C49746] font-mono mt-0.5 animate-pulse">
                {selectedStepId && selectedStepId !== "ALL" 
                  ? "🎯 Filtrado! Clique na barra dourada ou no botão de limpar para ver tudo"
                  : "↔ Clique/arraste para lados (Pan) | Clique em uma barra para FILTRAR etapas e diagnósticos"}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[9px] font-mono">
              {selectedStepId && selectedStepId !== "ALL" && (
                <span className="flex items-center gap-1 text-[#C49746] font-bold">
                  <span className="w-2 h-2 bg-[#C49746] rounded-none"></span> Selecionado
                </span>
              )}
              <span className="flex items-center gap-1 text-slate-500">
                <span className="w-2 h-2 bg-[#1A1A1A] rounded-none"></span> Dentro de ±2σ
              </span>
              <span className="flex items-center gap-1 text-red-600">
                <span className="w-2 h-2 bg-red-600 rounded-none"></span> Crítico (Excede Média + 2σ)
              </span>
            </div>
          </div>

          <div 
            className="h-64 w-full text-xs select-none"
            style={{ cursor: isDragging ? "grabbing" : "grab" }}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={steps} 
                margin={{ top: 15, right: 10, left: -25, bottom: 5 }}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F1F1" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  tick={{ fontSize: 9, fill: "#1A1A1A", fontFamily: "sans-serif", fontWeight: "bold" }} 
                  axisLine={{ stroke: "#1A1A1A", strokeWidth: 1 }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 9, fill: "#1A1A1A", fontFamily: "monospace" }} 
                  axisLine={{ stroke: "#1A1A1A", strokeWidth: 1 }}
                  tickLine={false}
                  label={{ value: "Tempo (min)", angle: -90, position: "insideLeft", offset: 10, fill: "#1A1A1A", fontSize: 9 }}
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload as ProcessStep;
                      const isExceeding = data.processingTime > threshold2Sigma;
                      const isSelected = selectedStepId && selectedStepId !== "ALL" && data.id === selectedStepId;
                      return (
                        <div className="bg-slate-900 text-white p-2.5 rounded-none shadow-xl text-[10px] border border-slate-800 font-mono space-y-1">
                          <p className="font-bold text-[#C49746] uppercase">{data.name}</p>
                          <p>Tempo de Ciclo: {data.processingTime.toFixed(1)} min</p>
                          <p>Desvio σ: {data.standardDeviation.toFixed(2)} min</p>
                          <p className={isSelected ? "text-amber-400 font-bold" : isExceeding ? "text-red-400 font-bold" : "text-emerald-400"}>
                            {isSelected ? "★ ATIVO (Filtrado)" : isExceeding ? "⚠ CRÍTICO (> Média + 2σ)" : "✓ Estável (< Média + 2σ)"}
                          </p>
                          <p className="text-[8px] text-slate-400 border-t border-slate-800 pt-1">
                            Clique para filtrar/desfiltrar
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="processingTime" radius={0}>
                  {steps.map((entry, index) => {
                    const isExceeding = entry.processingTime > threshold2Sigma;
                    const isSelected = selectedStepId && selectedStepId !== "ALL" && entry.id === selectedStepId;
                    const hasActiveFilter = selectedStepId && selectedStepId !== "ALL";
                    
                    let fillOpacity = isExceeding ? 1.0 : 0.7;
                    if (hasActiveFilter) {
                      fillOpacity = isSelected ? 1.0 : 0.15;
                    }
                    
                    const cellColor = isSelected ? "#C49746" : (isExceeding ? "#EF4444" : "#1A1A1A");

                    return (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={cellColor} 
                        fillOpacity={fillOpacity}
                        onClick={() => {
                          if (onSelectStep) {
                            onSelectStep(isSelected ? "ALL" : entry.id);
                          }
                        }}
                        className="cursor-pointer transition-all hover:stroke-[#C49746] hover:stroke-2"
                      />
                    );
                  })}
                </Bar>
                
                {/* Global Mean reference line */}
                <ReferenceLine 
                  y={globalMean} 
                  stroke="#1A1A1A" 
                  strokeWidth={1}
                  strokeDasharray="4 4"
                  label={{ 
                    value: `Média Global: ${globalMean.toFixed(1)}m`, 
                    fill: "#1A1A1A", 
                    fontSize: 8, 
                    fontWeight: "bold",
                    position: "left" 
                  }} 
                />

                {/* 2-Sigma critical reference line */}
                <ReferenceLine 
                  y={threshold2Sigma} 
                  stroke="#EF4444" 
                  strokeWidth={1.5}
                  strokeDasharray="2 2"
                  label={{ 
                    value: `Média + 2σ: ${threshold2Sigma.toFixed(1)}m`, 
                    fill: "#EF4444", 
                    fontSize: 8, 
                    fontWeight: "bold",
                    position: "right" 
                  }} 
                />

                {/* Controlled Brush for timeline zooming and panning */}
                <Brush
                  dataKey="name"
                  height={22}
                  stroke="#C49746"
                  fill="#FAF8F5"
                  startIndex={startIndex}
                  endIndex={endIndex}
                  onChange={handleBrushChange}
                  tickFormatter={(value) => {
                    return typeof value === "string" && value.length > 12 
                      ? `${value.slice(0, 12)}...` 
                      : value;
                  }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
}
