import React, { useState, useEffect } from "react";
import { 
  BarChart2, 
  Database, 
  Upload, 
  Play, 
  Plus, 
  Trash2, 
  Sparkles, 
  Download, 
  CheckCircle2, 
  Info, 
  Table, 
  LineChart as LineChartIcon, 
  Activity, 
  BookOpen, 
  FileSpreadsheet, 
  Home, 
  Edit
} from "lucide-react";
import { ProcessStep, ProcessMetrics } from "../types";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from "recharts";

interface BiStudioProps {
  steps: ProcessStep[];
  stats: ProcessMetrics;
  arrivalRate: number;
  onNavigateHome: () => void;
  onOpenStepDetails: (stepId: string) => void;
}

interface BiStudy {
  id: string;
  title: string;
  author: string;
  summary: string;
  metricsText: string;
  date: string;
}

export default function BiStudio({ steps, stats, arrivalRate, onNavigateHome, onOpenStepDetails }: BiStudioProps) {
  const [activeTab, setActiveTabRaw] = useState<"DATASOURCE" | "VISUALIZER" | "STUDY_BUILDER">("DATASOURCE");

  const savedScrollY = React.useRef<number>(0);

  const setActiveTab = (value: any) => {
    savedScrollY.current = window.scrollY;
    if (typeof value === "function") {
      setActiveTabRaw((prev) => value(prev));
    } else {
      setActiveTabRaw(value);
    }
  };

  useEffect(() => {
    if (savedScrollY.current > 0) {
      const targetScroll = savedScrollY.current;
      window.scrollTo(0, targetScroll);
      let count = 0;
      const restore = () => {
        window.scrollTo(0, targetScroll);
        count++;
        if (count < 15) {
          requestAnimationFrame(restore);
        }
      };
      requestAnimationFrame(restore);
    }
  }, [activeTab]);

  // State for data sources
  const [dataSourceType, setDataSourceType] = useState<"WORKSPACE" | "CSV_PASTE" | "CSV_PRESETS">("WORKSPACE");
  const [csvText, setCsvText] = useState<string>(
    "ID_Lote,Posto,Tempo_Ciclo_min,Pecas_Defeituosas,Responsavel,Turno\n" +
    "LOT-101,SMT,4.2,1,Carlos Silva,Mantuan\n" +
    "LOT-102,SMT,3.8,0,Carlos Silva,Mantuan\n" +
    "LOT-103,Forno,5.1,0,Roberto Lima,Vesper\n" +
    "LOT-104,Forno,4.7,0,Roberto Lima,Vesper\n" +
    "LOT-105,AOI,3.5,3,Elena Souza,Mantuan\n" +
    "LOT-106,AOI,5.2,1,Elena Souza,Vesper\n" +
    "LOT-107,Estação ESD,2.1,0,Julia Reis,Mantuan"
  );

  const [activePreset, setActivePreset] = useState<"MANUFACTURING" | "BANKING" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "HUMAN_RESOURCES">("MANUFACTURING");

  // Raw parsed tabular rows
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [parsedData, setParsedData] = useState<Record<string, any>[]>([]);
  const [parseError, setParseError] = useState<string | null>(null);

  // Chart Building Configuration
  const [chartType, setChartType] = useState<"BAR" | "LINE" | "AREA">("BAR");
  const [xAxisKey, setXAxisKey] = useState<string>("");
  const [yAxisKey, setYAxisKey] = useState<string>("");
  const [chartColor, setChartColor] = useState<string>("#4F46E5"); // Indigo default

  // Generated reports and studies state
  const [studies, setStudies] = useState<BiStudy[]>([
    {
      id: "study-1",
      title: "Cálculo Científico de Gargalos e Produtividade Operacional",
      author: "LSS Master Black Belt",
      summary: "Estudo micro-estruturado focado na maximização de vazão e capacidade operativa. Foram examinados os indicadores órfãos dos postos operacionais e traçadas ações imediatas para reduzir variabilidade sistemática.",
      metricsText: `Vazão Máxima: ${stats.systemCapacity.toFixed(1)} u/h\nEficiência Global: ${(stats.systemUtilization * 100).toFixed(1)}%\nPosto Crítico (Gargalo Principal): ${stats.bottleneckStepName}\nLead Time Estimado: ${stats.leadTime.toFixed(1)} minutos`,
      date: "28/05/2026"
    }
  ]);
  const [studyTitle, setStudyTitle] = useState("");
  const [studyAuthor, setStudyAuthor] = useState("");
  const [studySummary, setStudySummary] = useState("");

  // Parse standard process steps as secondary database
  const getWorkspaceAsTabularData = () => {
    return steps.map(s => ({
      ID: s.id,
      Etapa: s.name,
      Recurso: s.resource,
      Operadores: s.resourceCount,
      "Tempo Ciclo (min)": s.processingTime,
      "Variabilidade (Desvio)": s.standardDeviation,
      "Rendimento (%)": Math.round(s.yieldRate * 100),
      "Capacidade (u/h)": s.capacityPerHour ? parseFloat(s.capacityPerHour.toFixed(1)) : parseFloat((60 / s.processingTime * s.resourceCount).toFixed(1)),
      Setup: s.setupTime,
      "Calculado WIP": s.wip ? parseFloat(s.wip.toFixed(2)) : 1.0,
      "Gargalo Ativo": s.name === stats.bottleneckStepName ? "Sim" : "Não"
    }));
  };

  // Run Spreadsheet parser logic
  const runCsvParser = (textInput: string) => {
    try {
      if (!textInput.trim()) {
        throw new Error("O conteúdo da planilha está em branco.");
      }
      const lines = textInput.split("\n").map(l => l.trim()).filter(l => l.length > 0);
      if (lines.length < 2) {
        throw new Error("Uma base de dados válida precisa ter pelo menos um cabeçalho e uma linha de dados.");
      }

      // Detect separator
      let separator = ",";
      if (lines[0].includes(";")) separator = ";";
      else if (lines[0].includes("\t")) separator = "\t";

      const headers = lines[0].split(separator).map(h => h.trim().replace(/^["']|["']$/g, ""));
      const rows: Record<string, any>[] = [];

      for (let i = 1; i < lines.length; i++) {
        const currentLineValues = lines[i].split(separator).map(v => v.trim().replace(/^["']|["']$/g, ""));
        const rowObject: Record<string, any> = {};
        
        headers.forEach((h, index) => {
          const val = currentLineValues[index] !== undefined ? currentLineValues[index] : "";
          // Try to cast to number for charts rendering if numeric
          if (val !== "" && !isNaN(Number(val))) {
            rowObject[h] = Number(val);
          } else {
            rowObject[h] = val;
          }
        });
        rows.push(rowObject);
      }

      setParsedHeaders(headers);
      setParsedData(rows);
      setParseError(null);

      // Auto-configure axis suggestions
      if (headers.length > 1) {
        setXAxisKey(headers[0]);
        // Find first numeric header for Y-axis
        const numericHeader = headers.find((h, idx) => idx > 0 && typeof rows[0]?.[h] === "number");
        setYAxisKey(numericHeader || headers[1]);
      }
    } catch (e: any) {
      setParseError(e.message || "Erro inseperado no parse do arquivo csv.");
    }
  };

  // Re-run CSV parser when CSV presets are selected
  const applyPresetSheet = (presetType: "MANUFACTURING" | "BANKING" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "HUMAN_RESOURCES") => {
    setActivePreset(presetType);
    let mockCsv = "";
    if (presetType === "MANUFACTURING") {
      mockCsv = "ID_Lote,Posto,Tempo_Ciclo_min,Pecas_Defeituosas,Responsavel,Turno\n" +
                "LOT-101,SMT,4.2,1,Carlos Silva,Mantuan\n" +
                "LOT-102,SMT,3.8,0,Carlos Silva,Mantuan\n" +
                "LOT-103,Forno,5.1,0,Roberto Lima,Vesper\n" +
                "LOT-104,Forno,4.7,0,Roberto Lima,Vesper\n" +
                "LOT-105,AOI,3.5,3,Elena Souza,Mantuan\n" +
                "LOT-106,AOI,5.2,1,Elena Souza,Vesper\n" +
                "LOT-107,Estação ESD,2.1,0,Julia Reis,Mantuan";
    } else if (presetType === "BANKING") {
      mockCsv = "Chamado_ID,Atendente,Tempo_Atendimento_min,Prioridade,Fator_Reclamacao,Canal\n" +
                "CHM-901,Ana,12.5,Alta,1,Telefone\n" +
                "CHM-902,Ana,8.2,Baixa,0,E-mail\n" +
                "CHM-903,Bruno,15.4,Alta,2,Chat\n" +
                "CHM-904,Bruno,6.1,Baixa,0,WhatsApp\n" +
                "CHM-905,Carla,22.1,Alta,5,Telefone\n" +
                "CHM-906,Carla,11.8,Media,1,E-mail\n" +
                "CHM-907,Carla,18.2,Media,2,WhatsApp";
    } else if (presetType === "LOGISTICS") {
      mockCsv = "Pedido_ID,Doca,Tempo_Doca_min,Volume_m3,Status_Pedido,Responsavel\n" +
                "LOG-701,Doca A,45,12.5,Completado,Thiago Martins\n" +
                "LOG-702,Doca A,55,18.0,Atrasado,Thiago Martins\n" +
                "LOG-703,Doca B,30,8.5,Completado,Marcos Santos\n" +
                "LOG-704,Doca B,22,5.2,Completado,Marcos Santos\n" +
                "LOG-705,Doca C,85,24.0,Risco Gargalo,Paula Lima\n" +
                "LOG-706,Doca C,62,19.2,Completado,Paula Lima";
    } else if (presetType === "TECHNOLOGY") {
      mockCsv = "Sprint_ID,Squad,Lead_Time_dias,Bugs_Reportados,Story_Points,Status_Deploy\n" +
                "SPT-201,Squad Alfa,8.5,1,34,Sucesso\n" +
                "SPT-202,Squad Alfa,9.2,3,40,Sucesso\n" +
                "SPT-203,Squad Beta,12.4,5,28,Risco de Revert\n" +
                "SPT-204,Squad Beta,7.8,0,32,Sucesso\n" +
                "SPT-205,Squad Gama,14.5,8,45,Atrasado\n" +
                "SPT-206,Squad Gama,10.1,2,38,Sucesso";
    } else if (presetType === "HEALTHCARE") {
      mockCsv = "Paciente_ID,Setor,Tempo_Fila_min,Classificacao_Risco,Prioridade_Manchester,Atendido_SLA\n" +
                "PAC-001,Triagem,5,Verde,Pouco Urgente,Sim\n" +
                "PAC-002,Clinico Geral,35,Amarelo,Urgente,Sim\n" +
                "PAC-003,Ortopedia,48,Amarelo,Urgente,Não\n" +
                "PAC-004,Triagem,2,Vermelho,Emergencia,Sim\n" +
                "PAC-005,Pediatrico,22,Laranja,Muito Urgente,Sim\n" +
                "PAC-006,Clinico Geral,58,Verde,Pouco Urgente,Não\n" +
                "PAC-007,Fisioterapia,15,Azul,Não Urgente,Sim";
    } else if (presetType === "HUMAN_RESOURCES") {
      mockCsv = "Vaga_ID,Setor,Custo_Contratacao_R$,Tempo_Preenchimento_dias,Candidatos_Inscritos,Canal_Atraçao\n" +
                "VAG-101,Tecnologia,4500,28,150,LinkedIn\n" +
                "VAG-102,Tecnologia,6000,42,85,Headhunter\n" +
                "VAG-103,Financeiro,1500,18,220,Gupy\n" +
                "VAG-104,Comercial,2500,24,190,Indicação\n" +
                "VAG-105,Operações,800,14,310,Gupy\n" +
                "VAG-106,Logística,1200,21,140,LinkedIn";
    }
    setCsvText(mockCsv);
    runCsvParser(mockCsv);
  };

  useEffect(() => {
    if (dataSourceType === "WORKSPACE") {
      const data = getWorkspaceAsTabularData();
      if (data.length > 0) {
        setParsedHeaders(Object.keys(data[0]));
        setParsedData(data);
        setXAxisKey("Etapa");
        setYAxisKey("Calculado WIP");
        setParseError(null);
      }
    } else {
      runCsvParser(csvText);
    }
  }, [dataSourceType, csvText, steps]);

  const handleCreateStudy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studyTitle || !studySummary) return;

    const newStudy: BiStudy = {
      id: `study-${Date.now()}`,
      title: studyTitle,
      author: studyAuthor || "Supervisor LSS",
      summary: studySummary,
      metricsText: `Origem dos Dados: Planilha Importada por Conexão Direta BI.\nEstatísticas básicas: ${parsedData.length} amostras coletadas. Indicador X: ${xAxisKey} • Indicador Y correspondente: ${yAxisKey}`,
      date: new Date().toLocaleDateString("pt-BR")
    };

    setStudies([newStudy, ...studies]);
    setStudyTitle("");
    setStudyAuthor("");
    setStudySummary("");
  };

  const handleDeleteStudy = (id: string) => {
    setStudies(studies.filter(s => s.id !== id));
  };

  return (
    <div id="bi-studio-panel" className="space-y-8 animate-fade-in text-left select-none">
      
      {/* breadcrumbs UX */}
      <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-4 bg-[#FAF8F5] p-3 -mt-4">
        <div className="flex items-center gap-2 text-[10px] uppercase font-mono tracking-wider text-gray-400">
          <span className="hover:text-amber-700 cursor-pointer flex items-center gap-1" onClick={onNavigateHome}>
            <Home size={10} /> Página Inicial (Diagnóstico)
          </span>
          <span>/</span>
          <span className="text-gray-900 font-bold flex items-center gap-1">
            <BarChart2 size={10} /> Módulo 9. Estúdio BI LSS
          </span>
        </div>
        <button 
          onClick={onNavigateHome}
          className="bg-white border text-[10px] uppercase font-mono font-bold tracking-tight px-3 py-1 cursor-pointer transition-colors hover:bg-gray-50 flex items-center gap-1.5"
        >
          ← Voltar ao Início
        </button>
      </div>

      {/* Main Header visual theme styling */}
      <div className="border-[#1A1A1A] border p-6 bg-white shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 bg-indigo-600 text-white font-mono font-bold text-[8.5px] uppercase tracking-wider rounded-xs">
                BUSINESS INTELLIGENCE
              </span>
              <span className="text-gray-400">•</span>
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-tight flex items-center gap-1">
                <Sparkles size={11} className="text-indigo-600 animate-pulse" /> Decisão Baseada em Dados Científicos
              </span>
            </div>
            <h1 className="text-3xl font-serif tracking-tight text-gray-950">
              Estúdio Científico de BI &amp; Analytics
            </h1>
            <p className="text-xs text-gray-500 max-w-2xl mt-1.5 leading-relaxed font-sans">
              Centralize relatórios de desempenho operacional, crie dashboards interativos sob demanda e gere estudos preditivos. Conecte diretamente sua planilha de produção, financeiro ou logística para obter insights matemáticos e visuais.
            </p>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => {
                setActiveTab("DATASOURCE");
              }}
              className={`px-3 py-2 border text-xs font-mono font-bold uppercase transition-all rounded-sm flex items-center gap-1.5 cursor-pointer ${
                activeTab === "DATASOURCE" ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-750 hover:bg-gray-50"
              }`}
            >
              <Database size={12} />
              1. Conectar Fonte
            </button>
            <button
              onClick={() => {
                setActiveTab("VISUALIZER");
              }}
              className={`px-3 py-2 border text-xs font-mono font-bold uppercase transition-all rounded-sm flex items-center gap-1.5 cursor-pointer ${
                activeTab === "VISUALIZER" ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-750 hover:bg-gray-50"
              }`}
            >
              <BarChart2 size={12} />
              2. Criar Visões/Gráfico
            </button>
            <button
              onClick={() => {
                setActiveTab("STUDY_BUILDER");
              }}
              className={`px-3 py-2 border text-xs font-mono font-bold uppercase transition-all rounded-sm flex items-center gap-1.5 cursor-pointer ${
                activeTab === "STUDY_BUILDER" ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-750 hover:bg-gray-50"
              }`}
            >
              <BookOpen size={12} />
              3. Relatório &amp; Estudos
            </button>
          </div>
        </div>
      </div>

      {activeTab === "DATASOURCE" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Data source configuration card layout */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <h3 className="font-serif text-sm font-bold text-gray-900 flex items-center gap-2 border-b border-gray-100 pb-2">
                <Database size={15} className="text-indigo-600" />
                Origem Base de Dados
              </h3>
              
              <div className="space-y-2 text-xs">
                <button
                  onClick={() => setDataSourceType("WORKSPACE")}
                  className={`w-full text-left p-3 border transition-all rounded-sm flex items-center justify-between ${
                    dataSourceType === "WORKSPACE" ? "border-indigo-600 bg-indigo-50/10" : "border-gray-200 hover:bg-gray-50"
                  }`}
                >
                  <div>
                    <strong className="block text-gray-900 font-extrabold pr-2">🔗 Dados Ativos do Processo LSS</strong>
                    <span className="text-[10px] text-gray-400 block mt-0.5 font-normal">Sincroniza dinamicamente as etapas e WIPs do módulo ativo</span>
                  </div>
                  {dataSourceType === "WORKSPACE" && <CheckCircle2 size={15} className="text-indigo-600 shrink-0" />}
                </button>

                <button
                  onClick={() => {
                    setDataSourceType("CSV_PRESETS");
                    applyPresetSheet("MANUFACTURING");
                  }}
                  className={`w-full text-left p-3 border transition-all rounded-sm flex items-center justify-between ${
                    dataSourceType === "CSV_PRESETS" ? "border-indigo-600 bg-indigo-50/10" : "border-gray-200 hover:bg-gray-50"
                  }`}
                >
                  <div>
                    <strong className="block text-gray-900 font-extrabold">📂 Planilhas de Exemplo (Template BI)</strong>
                    <span className="text-[10px] text-gray-400 block mt-0.5 font-normal">Conecte planilhas prontas de Manufatura, Banco, Logística, TI, Saúde ou RH</span>
                  </div>
                  {dataSourceType === "CSV_PRESETS" && <CheckCircle2 size={15} className="text-indigo-600 shrink-0" />}
                </button>

                <button
                  onClick={() => setDataSourceType("CSV_PASTE")}
                  className={`w-full text-left p-3 border transition-all rounded-sm flex items-center justify-between ${
                    dataSourceType === "CSV_PASTE" ? "border-indigo-600 bg-indigo-50/10" : "border-gray-200 hover:bg-gray-50"
                  }`}
                >
                  <div>
                    <strong className="block text-gray-900 font-extrabold">📋 Colar CSV ou Planilha Externa</strong>
                    <span className="text-[10px] text-gray-400 block mt-0.5 font-normal">Cole dados em formato estruturado por delimitadores do Excel</span>
                  </div>
                  {dataSourceType === "CSV_PASTE" && <CheckCircle2 size={15} className="text-indigo-600 shrink-0" />}
                </button>
              </div>

              {dataSourceType === "CSV_PRESETS" && (
                <div className="pt-3 border-t border-gray-100 space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block font-mono">
                    Escolha o Template de Planilha:
                  </label>
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-1 text-[10px] font-mono">
                    <button
                      onClick={() => applyPresetSheet("MANUFACTURING")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "MANUFACTURING" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Manufatura (LSS Eletrônicos)
                    </button>
                    <button
                      onClick={() => applyPresetSheet("BANKING")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "BANKING" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Banco (Atendimento)
                    </button>
                    <button
                      onClick={() => applyPresetSheet("LOGISTICS")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "LOGISTICS" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Logística (Supply Chain)
                    </button>
                    <button
                      onClick={() => applyPresetSheet("TECHNOLOGY")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "TECHNOLOGY" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Tecnologia (DevOps &amp; SaaS)
                    </button>
                    <button
                      onClick={() => applyPresetSheet("HEALTHCARE")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "HEALTHCARE" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Saúde (Fluxo Hospitalar)
                    </button>
                    <button
                      onClick={() => applyPresetSheet("HUMAN_RESOURCES")}
                      className={`px-3 py-1.5 border text-left rounded-sm font-bold flex items-center gap-1.5 ${
                        activePreset === "HUMAN_RESOURCES" ? "bg-gray-950 text-white border-gray-950" : "bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <FileSpreadsheet size={12} /> Gestão (RH &amp; Contratação)
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-[#FAF8F5] p-4 border border-[#1A1A1A]/10 text-xs text-gray-700 leading-relaxed space-y-2.5">
              <strong className="font-bold flex items-center text-gray-900">
                <Info size={14} className="text-indigo-500 shrink-0 mr-1.5" /> Como funciona a conexão?
              </strong>
              <p>O Estúdio BI analisa a estrutura de colunas e dados numéricos/textuais para construir as visões correspondentes em tempo real. Você pode gerar gráficos de produtividade ou capabilidade simplesmente definindo o eixo X e eixo Y.</p>
              <div className="bg-white/80 p-2 border border-gray-200 text-[10px] font-mono whitespace-pre text-slate-500 overflow-x-auto">
                {"Coluna_A,Coluna_B,Valor\nJaneiro,Posto SMT,1250\nFevereiro,Posto Forno,1380"}
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-6">
            {dataSourceType !== "WORKSPACE" ? (
              <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
                <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                  <h3 className="font-serif text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Table size={15} className="text-indigo-600" />
                    Editor e Parser de Planilha CSV
                  </h3>
                  <span className="text-[10px] font-mono text-gray-400 bg-gray-50 px-2 py-0.5 rounded border border-gray-200">
                    Formato de Entrada: Delimitado por vírgulas
                  </span>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block font-mono">
                    Cole as linhas da planilha abaixo para atualizar os gráficos:
                  </label>
                  <textarea
                    value={csvText}
                    onChange={(e) => setCsvText(e.target.value)}
                    rows={8}
                    className="w-full font-mono text-[10.5px] border border-gray-300 p-3 rounded-sm leading-relaxed focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-slate-50 text-slate-800"
                    placeholder="Cole dados no formato CSV..."
                  />
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-[10.5px] text-gray-500 leading-normal font-sans">
                    Arraste ou substitua valores acima e clique para atualizar. O dashboard mapeia as colunas numéricas em formato flutuante.
                  </span>
                  
                  <button
                    onClick={() => runCsvParser(csvText)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 font-mono text-[10.5px] font-bold uppercase transition-all flex items-center gap-1.5 shrink-0"
                  >
                    <Play size={12} />
                    Carregar Planilha BI
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#FAF8F5]/80 border border-[#1A1A1A]/10 p-5 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-50 text-green-700 flex items-center justify-center font-bold text-lg border border-green-200">
                  ⚡
                </div>
                <div>
                  <strong className="text-gray-950 font-extrabold text-sm block">Conexão Ativa com o Processo LSS do Workspace!</strong>
                  <p className="text-xs text-slate-500 mt-0.5">As tabelas e gráficos abaixo estão consumindo os dados científicos reais das {steps.length} etapas operacionais ativas.</p>
                </div>
              </div>
            )}

            {parseError && (
              <div className="p-3 bg-red-50 text-red-700 border border-red-200 text-xs font-mono">
                🛑 <strong>Erro de Leitura da Planilha:</strong> {parseError}
              </div>
            )}

            {/* Render parsed data table */}
            <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                <h3 className="font-serif text-sm font-bold text-gray-900">
                  Visão Geral dos Dados Conectados ({parsedData.length} Linhas)
                </h3>
                <span className="text-[10px] font-mono text-gray-400">
                  Clique duplo em qualquer linha com relação a etapas para gerenciar
                </span>
              </div>

              <div className="overflow-x-auto border border-gray-200 rounded-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#FAF9F6] border-b border-gray-200 font-mono text-[10px] uppercase font-bold text-gray-650">
                      {parsedHeaders.map(h => (
                        <th key={h} className="py-2.5 px-3 border-r border-gray-200 last:border-r-0">
                          {h.replace("_", " ")}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 font-sans text-gray-750">
                    {parsedData.length === 0 ? (
                      <tr>
                        <td colSpan={parsedHeaders.length || 1} className="py-8 text-center text-gray-450 text-[11px]">
                          Nenhum dado carregado. Importe uma planilha acima.
                        </td>
                      </tr>
                    ) : (
                      parsedData.map((row, rIdx) => {
                        let isRelatedToStep = false;
                        let foundStepId = "";
                        
                        // Try to find physical step match
                        if (row["ID"]) {
                          const existsSpec = steps.find(s => s.id === row["ID"]);
                          if (existsSpec) {
                            isRelatedToStep = true;
                            foundStepId = existsSpec.id;
                          }
                        } else if (row["Etapa"]) {
                          const existsSpec = steps.find(s => s.name === row["Etapa"]);
                          if (existsSpec) {
                            isRelatedToStep = true;
                            foundStepId = existsSpec.id;
                          }
                        }

                        return (
                          <tr 
                            key={rIdx} 
                            onDoubleClick={() => {
                              if (isRelatedToStep && foundStepId) {
                                onOpenStepDetails(foundStepId);
                              }
                            }}
                            className={`hover:bg-indigo-50/25 transition-all ${
                              isRelatedToStep ? "cursor-help bg-amber-50/15" : ""
                            }`}
                            title={isRelatedToStep ? "Etapa do Workspace. Dê um clique duplo para entrar nos detalhes operacionais!" : undefined}
                          >
                            {parsedHeaders.map(h => (
                              <td key={h} className="py-2.5 px-3 border-r border-gray-200 last:border-r-0">
                                {typeof row[h] === "number" ? (
                                  <span className="font-mono font-semibold">{row[h]}</span>
                                ) : (
                                  <span>{row[h]}</span>
                                )}
                              </td>
                            ))}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {parsedData.some(row => row["ID"] || row["Etapa"]) && (
                <div className="flex items-center gap-1.5 p-2 bg-amber-50 text-amber-900 border border-amber-200/55 rounded-sm text-[10px] leading-relaxed">
                  <span className="text-sm">💡</span>
                  <span><strong>Super Interatividade Habilitada:</strong> Algumas linhas acima compartilham relação estrutural direta com as etapas mapeadas no fluxograma. Dê <strong>clique duplo</strong> em qualquer uma dessas linhas para detalhá-la e alterá-la instantaneamente!</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === "VISUALIZER" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <h3 className="font-serif text-sm font-bold text-gray-900 border-b border-gray-100 pb-2 flex items-center gap-2">
                <LineChartIcon size={15} className="text-indigo-600" />
                Configurar Gráficos de Visão
              </h3>

              <div className="space-y-3 text-xs">
                {/* Chart shape selection */}
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block text-[10px] tracking-widest uppercase font-mono">Tipo de Gráficos</label>
                  <div className="grid grid-cols-3 gap-1">
                    {(["BAR", "LINE", "AREA"] as const).map(t => (
                      <button
                        key={t}
                        onClick={() => setChartType(t)}
                        className={`py-1 px-2 border font-mono font-bold text-[9px] uppercase cursor-pointer rounded-xs transition-colors ${
                          chartType === t ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-700 hover:bg-gray-50"
                        }`}
                      >
                        {t === "BAR" ? "Barras 📊" : t === "LINE" ? "Linhas 📈" : "Área 🗻"}
                      </button>
                    ))}
                  </div>
                </div>

                {/* X Axis options */}
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block text-[10px] tracking-widest uppercase font-mono">Eixo X (Rótulos/Categorias)</label>
                  <select 
                    value={xAxisKey}
                    onChange={(e) => setXAxisKey(e.target.value)}
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                  >
                    <option value="">Selecione a Coluna...</option>
                    {parsedHeaders.map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>

                {/* Y Axis options */}
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block text-[10px] tracking-widest uppercase font-mono">Eixo Y (Indicadores Numéricos)</label>
                  <select 
                    value={yAxisKey}
                    onChange={(e) => setYAxisKey(e.target.value)}
                    className="w-full border border-[#1A1A1A]/20 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white font-mono"
                  >
                    <option value="">Selecione a Coluna Numérica...</option>
                    {parsedHeaders.map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>

                {/* Visual accent color selector */}
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block text-[10px] tracking-widest uppercase font-mono">Paleta de Destaque LSS</label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { hex: "#4F46E5", label: "Índigo" },
                      { hex: "#C49746", label: "Âmbar LSS" },
                      { hex: "#059669", label: "Esmeralda" },
                      { hex: "#DC2626", label: "Alerta Vermelho" }
                    ].map(c => (
                      <button
                        key={c.hex}
                        onClick={() => setChartColor(c.hex)}
                        className={`w-full h-7 rounded-sm border cursor-pointer flex items-center justify-center transition-all ${
                          chartColor === c.hex ? "ring-2 ring-offset-1 ring-indigo-500" : ""
                        }`}
                        style={{ backgroundColor: c.hex }}
                        title={c.label}
                      >
                        {chartColor === c.hex && (
                          <span className="text-[10px] font-bold text-white uppercase font-mono leading-none">✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#FAF8F5] p-4 border border-[#1A1A1A]/10 text-xs text-gray-750 space-y-2">
              <strong className="font-extrabold text-gray-950 block">💡 Dicas de Capabilidade:</strong>
              <p>O gráfico recalcula instantaneamente os eixos a partir do dado selecionado. Use o eixo X para postos, rotatividade de equipes ou lotes; e o eixo Y para acompanhar o tempo de ciclo, contagem de defeitos ou WIP.</p>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white border-2 border-slate-950 p-6 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-gray-100 pb-3">
                <div>
                  <h3 className="font-serif text-base font-bold text-gray-900 uppercase tracking-tight">
                    Gráfico de BI Customizado
                  </h3>
                  <span className="text-[10px] text-gray-400 font-mono">
                    Fonte: {dataSourceType === "WORKSPACE" ? "Dados Ativos LSS" : "Planilha CSV Conectada"} ({xAxisKey || "?"} • {yAxisKey || "?"})
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono bg-indigo-50 text-indigo-700 px-2 py-1 border border-indigo-200">
                    Sincronização Ativa
                  </span>
                </div>
              </div>

              {parsedData.length === 0 || !xAxisKey || !yAxisKey ? (
                <div className="h-72 border-2 border-dashed border-gray-200 flex flex-col justify-center items-center text-center p-6">
                  <Info size={30} className="text-gray-300 mb-2" />
                  <p className="text-xs text-gray-500 font-bold">Configurações pendentes de Eixo</p>
                  <p className="text-[10px] text-gray-400 max-w-sm mt-1">Por favor, garanta que suas fontes de dados tenham de fato colunas numéricas elegíveis para o eixo correspondente.</p>
                </div>
              ) : (
                <div className="h-80 w-full pt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    {chartType === "BAR" ? (
                      <BarChart data={parsedData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                        <XAxis dataKey={xAxisKey} stroke="#4B5563" fontSize={10} fontStyle="italic" />
                        <YAxis stroke="#4B5563" fontSize={10} />
                        <Tooltip contentStyle={{ fontSize: '11px', fontFamily: 'sans-serif', border: '1px solid #1A1A1A' }} />
                        <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                        <Bar dataKey={yAxisKey} fill={chartColor} name={yAxisKey.replace("_", " ")}>
                          {parsedData.map((entry, index) => {
                            // Highlight bottleneck if workspace data
                            const isWorkspaceBottleneck = dataSourceType === "WORKSPACE" && entry?.Etapa === stats.bottleneckStepName;
                            return (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={isWorkspaceBottleneck ? "#DC2626" : chartColor} 
                                fillOpacity={0.85}
                                stroke="#1A1A1A"
                                strokeWidth={1}
                              />
                            );
                          })}
                        </Bar>
                      </BarChart>
                    ) : chartType === "LINE" ? (
                      <LineChart data={parsedData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                        <XAxis dataKey={xAxisKey} stroke="#4B5563" fontSize={10} fontStyle="italic" />
                        <YAxis stroke="#4B5563" fontSize={10} />
                        <Tooltip contentStyle={{ fontSize: '11px', fontFamily: 'sans-serif', border: '1px solid #1A1A1A' }} />
                        <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                        <Line 
                          type="monotone" 
                          dataKey={yAxisKey} 
                          stroke={chartColor} 
                          strokeWidth={2.5}
                          activeDot={{ r: 6 }} 
                          name={yAxisKey.replace("_", " ")} 
                        />
                      </LineChart>
                    ) : (
                      <AreaChart data={parsedData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                        <XAxis dataKey={xAxisKey} stroke="#4B5563" fontSize={10} fontStyle="italic" />
                        <YAxis stroke="#4B5563" fontSize={10} />
                        <Tooltip contentStyle={{ fontSize: '11px', fontFamily: 'sans-serif', border: '1px solid #1A1A1A' }} />
                        <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                        <Area 
                          type="monotone" 
                          dataKey={yAxisKey} 
                          stroke={chartColor} 
                          fill={chartColor} 
                          fillOpacity={0.15} 
                          strokeWidth={2}
                          name={yAxisKey.replace("_", " ")} 
                        />
                      </AreaChart>
                    )}
                  </ResponsiveContainer>
                </div>
              )}

              {dataSourceType === "WORKSPACE" && (
                <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 bg-[#FAF9F6] p-2.5 border border-gray-200">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 bg-[#DC2626] rounded-full inline-block"></span> Posto Vermelho = Gargalo</span>
                  <span className="text-[9.5px]">Sincronização Científica com Little's Law e Filas</span>
                </div>
              )}
            </div>

            {/* ENRICHED C-LEVEL 360-DEGREE BUSINESS INTEL DECISION DASHBOARD */}
            {dataSourceType === "WORKSPACE" && steps.length > 0 && (() => {
              const systemLeadTime = steps.reduce((acc, curr) => acc + curr.processingTime, 0);
              const bottleneckObj = steps.reduce((prev, current) => {
                const prevRatio = prev.processingTime / (prev.resourceCount || 1);
                const currRatio = current.processingTime / (current.resourceCount || 1);
                return currRatio > prevRatio ? current : prev;
              }, steps[0]);
              const maxSystemThroughput = bottleneckObj ? Math.round(((bottleneckObj.resourceCount || 1) * 60 / bottleneckObj.processingTime) * 10) / 10 : 0;
              const systemUtilisation = maxSystemThroughput > 0 ? Math.round((arrivalRate / maxSystemThroughput) * 100 * 10) / 10 : 0;
              const rolledYield = Math.round(steps.reduce((acc, curr) => acc * (curr.yieldRate || 1), 1) * 1000) / 10;
              
              const capacityDemandData = steps.map(s => {
                const sCapacity = (s.resourceCount * 60) / s.processingTime;
                return {
                  name: s.name.length > 18 ? s.name.substring(0, 18) + "..." : s.name,
                  "Capacidade por Hora": Math.round(sCapacity * 10) / 10,
                  "Taxa de Entrada (Demanda)": arrivalRate,
                  "Recursos Alocados": s.resourceCount
                };
              });

              const qualityYieldData = steps.map(s => ({
                name: s.name.length > 18 ? s.name.substring(0, 18) + "..." : s.name,
                "Rendimento (%)": Math.round((s.yieldRate || 1) * 1000) / 10,
                "Perda / Retrabalho (%)": Math.round((1 - (s.yieldRate || 1)) * 1000) / 10
              }));

              const queueUtilizationData = steps.map(s => {
                const sCapacity = (s.resourceCount * 60) / s.processingTime;
                const util = (arrivalRate / sCapacity) * 100;
                const calcWip = util >= 100
                  ? Math.round((arrivalRate * s.processingTime / 60) * 3 * 10) / 10
                  : Math.round(( (util/100) / (1 - (util/100)) ) * 10) / 10;
                return {
                  name: s.name.length > 18 ? s.name.substring(0, 18) + "..." : s.name,
                  "Clientes / Itens Acumulados (WIP)": calcWip < 0 ? 0 : Math.min(calcWip, 120),
                  "Ocupação do Posto (%)": Math.round(Math.min(util, 100) * 10) / 10
                };
              });

              return (
                <div className="pt-8 border-t-2 border-dashed border-[#1A1A1A]/20 space-y-8">
                  <div className="bg-[#1A1A1A] text-[#FAF8F5] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,0.15)] flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">🔑</span>
                        <h4 className="font-mono text-xs font-extrabold tracking-widest text-[#E0E7FF] uppercase">
                          Painel Executivo 360° para Tomadores de Decisão (C-Level Summary)
                        </h4>
                      </div>
                      <h3 className="font-serif text-lg font-bold">Diagnóstico Macro de Capabilidade &amp; Lucratividade Operacional</h3>
                      <p className="text-[10px] text-gray-300 max-w-2xl mt-1">
                        Esta inteligência de negócios consolida conceitos avançados de Lean Six Sigma e Teoria das Restrições (TOC) para identificar onde as restrições físicas limitam a vazão financeira, o lead time e a satisfação de clientes na sua empresa.
                      </p>
                    </div>
                  </div>

                  {/* KPI EXECUTIVE CARD HIGHLIGHTS */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                      <div>
                        <span className="text-gray-400 font-mono text-[9px] font-bold uppercase block tracking-wider">Tempo de Travessia Livre (Lead Time)</span>
                        <span className="font-serif text-2xl font-extrabold text-indigo-600 block mt-1">{Math.round(systemLeadTime * 10) / 10}</span>
                        <span className="text-[10px] text-gray-400 font-serif italic">utos por unidade do início ao fim</span>
                      </div>
                      <div className="mt-2 text-[9.5px] border-t border-gray-100 pt-2 text-gray-500 font-sans leading-normal">
                        Sem filas acumuladas, esta é a jornada intrínseca de esforço bruto em todo o sistema.
                      </div>
                    </div>

                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                      <div>
                        <span className="text-gray-400 font-mono text-[9px] font-bold uppercase block tracking-wider">Vazão Máxima do Gargalo</span>
                        <span className="font-serif text-2xl font-extrabold text-[#C49746] block mt-1">{maxSystemThroughput}</span>
                        <span className="text-[10px] text-gray-400 font-serif">idades processadas por hora</span>
                      </div>
                      <div className="mt-2 text-[9.5px] border-t border-gray-100 pt-2 text-gray-500 font-sans leading-normal">
                        Definida pela capacidade física do recurso do posto mais lento: <strong className="text-gray-900 font-extrabold font-mono text-[9px]">{bottleneckObj?.name}</strong>.
                      </div>
                    </div>

                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                      <div>
                        <span className="text-gray-400 font-mono text-[9px] font-bold uppercase block tracking-wider">Uptime / Saturação do Sistema</span>
                        <span className={`font-serif text-2xl font-extrabold block mt-1 ${systemUtilisation >= 100 ? "text-red-600" : "text-emerald-700"}`}>
                          {systemUtilisation}%
                        </span>
                        <span className="text-[10px] text-gray-400 font-serif">da capacidade do gargalo utilizada</span>
                      </div>
                      <div className="mt-2 text-[9.5px] border-t border-gray-100 pt-2 text-gray-500 font-sans leading-normal">
                        {systemUtilisation >= 100 
                          ? "🚨 Alerta: Sobrecarga estrutural! Filas acumulando infinitamente." 
                          : "✓ Sistema equilibrado: Margem saudável de contingência ativa."}
                      </div>
                    </div>

                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                      <div>
                        <span className="text-gray-400 font-mono text-[9px] font-bold uppercase block tracking-wider">End-to-End FPY Yield (RTY)</span>
                        <span className="font-serif text-2xl font-extrabold text-blue-800 block mt-1">{rolledYield}%</span>
                        <span className="text-[10px] text-gray-400 font-serif">taxa de acerto de primeira passagem</span>
                      </div>
                      <div className="mt-2 text-[9.5px] border-t border-gray-100 pt-2 text-gray-500 font-sans leading-normal">
                        Probabilidade acumulada de que uma unidade traverse todas as fases livre de falhas ou retrabalhos.
                      </div>
                    </div>
                  </div>

                  {/* DETAILED INSIGHT GRAPHS SECTION */}
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 pt-2">
                    {/* INSIGHT CHART 1: CAPACITY VS DEMAND AT C-LEVEL */}
                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3">
                      <div>
                        <span className="text-[10px] font-mono font-extrabold text-orange-600 uppercase tracking-widest block">Análise de Balanço Tático</span>
                        <h4 className="font-serif text-sm font-bold text-gray-900">Capacidade Operacional de Atendimento vs. Demanda de Entrada</h4>
                        <p className="text-[10px] text-gray-400 mt-1">
                          Mostra a vazão de processamento calculada por hora (barras) comparada à demanda externa ativa (linha vermelha). Quando a barra cai abaixo da linha vermelha, o sistema estrangula gerando lead times desumanos.
                        </p>
                      </div>

                      <div className="h-64 pt-2">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={capacityDemandData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="name" fontSize={9} stroke="#6B7280" />
                            <YAxis fontSize={9} stroke="#6B7280" />
                            <Tooltip contentStyle={{ fontSize: '10px' }} />
                            <Legend wrapperStyle={{ fontSize: '9px' }} />
                            <Bar dataKey="Capacidade por Hora" fill="#0284C7" name="Capacidade Operacional (un/h)" />
                            <Bar dataKey="Taxa de Entrada (Demanda)" fill="#EF4444" fillOpacity={0.6} name="Demanda Entrada (un/h)" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* INSIGHT CHART 2: WIP ACCUMULATION & OCCUPATION */}
                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3">
                      <div>
                        <span className="text-[10px] font-mono font-extrabold text-blue-600 uppercase tracking-widest block">Mapeamento de Filas Dinâmicas</span>
                        <h4 className="font-serif text-sm font-bold text-gray-900">Estoque de Trabalho Pendente (WIP Teórico) &amp; Nível de Ocupação</h4>
                        <p className="text-[10px] text-gray-400 mt-1">
                          Calcula onde os chamados/clientes/pacientes ficam acumulados aguardando atendimento. Representa o atrito físico e o desperdício crônico descritos pela Lei de Little.
                        </p>
                      </div>

                      <div className="h-64 pt-2">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={queueUtilizationData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="name" fontSize={9} stroke="#6B7280" />
                            <YAxis fontSize={9} stroke="#6B7280" />
                            <Tooltip contentStyle={{ fontSize: '10px' }} />
                            <Legend wrapperStyle={{ fontSize: '9px' }} />
                            <Bar dataKey="Clientes / Itens Acumulados (WIP)" fill="#312E81" name="Estoque Acumulado (WIP)" />
                            <Bar dataKey="Ocupação do Posto (%)" fill="#F59E0B" fillOpacity={0.4} name="Ocupação / Carga do Posto (%)" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* INSIGHT CHART 3: YIELD & WASTE RATES */}
                    <div className="bg-white border border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3 xl:col-span-2">
                      <div>
                        <span className="text-[10px] font-mono font-extrabold text-emerald-700 uppercase tracking-widest block">Índice de Qualidade Intrínseca</span>
                        <h4 className="font-serif text-sm font-bold text-gray-900">Eficiência de Rendimento (%) vs. Taxa de Retrabalho &amp; Refugos</h4>
                        <p className="text-[10px] text-gray-400 mt-1">
                          Mostra onde estão ocorrendo desvios de qualidade extrema com a necessidade de intervenção rápida. Os desperdícios reduzem as margens de lucro líquido e drenam as horas de dedicação da equipe de suporte ou operacional.
                        </p>
                      </div>

                      <div className="h-64 pt-2">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={qualityYieldData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="name" fontSize={9} stroke="#6B7280" />
                            <YAxis fontSize={9} stroke="#6B7280" domain={[0, 100]} />
                            <Tooltip contentStyle={{ fontSize: '10px' }} />
                            <Legend wrapperStyle={{ fontSize: '9px' }} />
                            <Area type="monotone" dataKey="Rendimento (%)" stroke="#16A34A" fill="#16A34A" fillOpacity={0.12} name="Rendimento Direto sem Correção (%)" />
                            <Area type="monotone" dataKey="Perda / Retrabalho (%)" stroke="#DC2626" fill="#DC2626" fillOpacity={0.06} name="Perda ou Desgaste de Retrabalho (%)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {activeTab === "STUDY_BUILDER" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <h3 className="font-serif text-sm font-bold text-gray-900 border-b border-gray-100 pb-2 flex items-center gap-2">
                <Edit size={14} className="text-indigo-600" />
                Registrar Novo Estudo / Relatório BI
              </h3>

              <form onSubmit={handleCreateStudy} className="space-y-3 text-xs text-left">
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Título Científico do Relatório</label>
                  <input
                    type="text"
                    value={studyTitle}
                    onChange={(e) => setStudyTitle(e.target.value)}
                    placeholder="Ex: Análise de Capabilidade Térmica Forno"
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Autor / Profissional de Certificação</label>
                  <input
                    type="text"
                    value={studyAuthor}
                    onChange={(e) => setStudyAuthor(e.target.value)}
                    placeholder="Ex: Ana Silva (Black Belt)"
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Sumário Executivo &amp; Ação Recomendada</label>
                  <textarea
                    value={studySummary}
                    onChange={(e) => setStudySummary(e.target.value)}
                    rows={4}
                    placeholder="Descreva problemas observados na planilha conectada, anomalias sistêmicas identificadas e planos de ação kaizen recomendados de acordo com os dados coletados."
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                    required
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 font-mono text-[10.5px] font-bold uppercase transition-all flex items-center justify-center gap-1.5"
                  >
                    <Plus size={11} />
                    Adicionar aos Documentos Ativos
                  </button>
                </div>
              </form>
            </div>
            
            <div className="bg-[#FAF8F5] p-4 border border-[#1A1A1A]/10 text-xs text-gray-700 space-y-2.5">
              <strong className="font-bold flex items-center text-gray-950">
                <Sparkles size={14} className="text-amber-600" /> Estudos com Grounding Matemático
              </strong>
              <p>Registre seus diagnósticos diretamente acima. Os estudos geram sumários técnicos com as informações calculadas pelo sistema LSS para assegurar reprodutibilidade acadêmica de engenharia.</p>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6">
            <div className="border border-gray-250 bg-white">
              <div className="bg-gray-950 text-white p-4 font-mono text-[10.5px] font-bold flex justify-between items-center tracking-wider">
                <span>REPOSITÓRIO DE ESTUDOS CORPORATIVOS BI LSS</span>
                <span className="text-[8.5px] text-gray-400 font-normal uppercase">Histórico Técnico de Pesquisas</span>
              </div>

              <div className="p-6 space-y-6">
                {studies.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 space-y-2">
                    <p className="font-serif text-sm font-bold">Sumário de Estudos Vazio</p>
                    <p className="text-xs">Submeta novos estudos no formulário ao lado para compilar a documentação técnica.</p>
                  </div>
                ) : (
                  studies.map(study => (
                    <div 
                      key={study.id} 
                      className="border-b border-[#1A1A1A]/10 last:border-b-0 pb-6 last:pb-0 space-y-3 relative group text-left"
                    >
                      <button 
                        onClick={() => handleDeleteStudy(study.id)}
                        className="absolute right-0 top-0 text-gray-300 hover:text-red-500 transition-colors p-1"
                        title="Excluir Estudo"
                      >
                        <Trash2 size={13} />
                      </button>

                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 border border-indigo-200 text-indigo-700 font-mono font-bold text-[8px] uppercase rounded-sm bg-indigo-50/50">
                          {study.date}
                        </span>
                        <span className="text-[10px] text-gray-400 font-semibold font-serif italic">
                          Autor: {study.author}
                        </span>
                      </div>

                      <h4 className="font-serif text-base font-bold text-gray-950 leading-tight">
                        {study.title}
                      </h4>

                      <div className="bg-[#FAF8F5] border-l-2 border-indigo-600 p-3 text-[10px] font-mono leading-relaxed text-slate-700 whitespace-pre-wrap">
                        {study.metricsText}
                      </div>

                      <p className="text-xs text-gray-650 leading-relaxed font-sans mt-1">
                        {study.summary}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
