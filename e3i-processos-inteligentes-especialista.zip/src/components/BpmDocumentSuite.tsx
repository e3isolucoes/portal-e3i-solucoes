/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ProcessStep } from "../types";
import {
  FileText,
  Download,
  ChevronRight,
  Sparkles,
  Shield,
  FileSignature,
  Plus,
  Trash2,
  Key,
  Clock,
  Lock,
  Unlock,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  History,
  Calendar,
  ShieldCheck,
  Eye,
  Building,
  Briefcase,
  ShieldAlert,
  Copy,
  Check,
  Search,
  BookOpen
} from "lucide-react";
import {
  SecureDocument,
  DocumentIntegrityRecord,
  CustodyLog,
  calculateSHA256,
  computeDocumentHash,
  verifyDocumentSecurity,
  signDocumentKMS,
  requestTimestampToken,
  buildVisualWatermark,
  isRetentionPeriodExceeded,
  executeSecureDisposal,
  RETENTION_POLICIESBY_TYPE,
  REVOLKED_CERTIFICATES_SET
} from "../utils/documentSecurity";

interface BpmDocumentSuiteProps {
  steps: ProcessStep[];
  stats: any;
  activeAreaId: string;
  onNavigateToMap: () => void;
}

export default function BpmDocumentSuite({ steps, stats, activeAreaId, onNavigateToMap }: BpmDocumentSuiteProps) {
  // Current user email simulation (conforming to environment context metadata)
  const currentLoggedUser = "marcoantoniomiranda713@gmail.com";
  const userPermissions = ["ADMIN", "DOCUMENT_DISPOSAL", "MASTER_BLACK_BELT"]; // default rich permissions for sandbox editing

  // List of active certificates
  const certificatesPool = [
    { id: "KMS-HSM-CERT-001", name: "Marco Antonio Miranda (Master Black Belt)", status: "Ativo" },
    { id: "KMS-HSM-CERT-012", name: "Pedro Santos Filho (Audit Lead ISO 9001)", status: "Ativo" },
    { id: "KMS-HSM-CERT-REVOKED", name: "Funcionário Desligado (Ex-Coordenador)", status: "REVOGADO" }
  ];

  // 1. Core Documents State
  const [docs, setDocs] = useState<SecureDocument[]>(() => {
    // Bootstrap initial documents with real hashes, signatures and timestamps!
    const doc1Raw: Omit<SecureDocument, "hash"> = {
      id: "sop-01",
      companyId: "E3I Processos Inteligentes",
      projectId: "DMAIC-A3-PROCON",
      processId: "PROC-MAIN",
      title: "POP-01: Preparação de Lotes e Setup Operacional",
      objective: "Definir padrões de Setup SMED mínimos para mitigar o tempo improdutivo de ociosidade.",
      scope: "Aplicável a todas as estações e postos de trabalho da linha principal.",
      content: `1. Identificar o lote de ordens de serviço a ser liberado.\n2. Limpar a bancada de trabalho conforme preceito 5S.\n3. Sinalizar início de setup no painel Kanban.`,
      version: 1,
      author: "Marco Antonio Miranda",
      generatedBy: "marcoantoniomiranda713@gmail.com",
      generatedAt: "2026-06-15T10:00:00Z",
      classification: "Uso Interno",
      retentionPolicy: "SOP - Retenção de 5 anos",
      retentionYears: 5,
      legalHold: false,
      status: "Aprovado",
      certificateId: "KMS-HSM-CERT-001",
      signedAt: "2026-06-15T10:05:00Z"
    };
    
    const doc1Hash = computeDocumentHash(doc1Raw);
    const doc1WithSignature: SecureDocument = {
      ...doc1Raw,
      hash: doc1Hash
    };
    
    // sign
    const d1Sign = signDocumentKMS(doc1WithSignature, "KMS-HSM-CERT-001", "marcoantoniomiranda713@gmail.com");
    doc1WithSignature.signature = d1Sign.signature;

    // request time stamp
    const d1Tsa = requestTimestampToken(doc1Hash, "Cora TSA ICP-Brasil");
    doc1WithSignature.timestampAuthority = d1Tsa.authority;
    doc1WithSignature.timestampToken = d1Tsa.token;
    doc1WithSignature.timestampTokenId = "TSA-TKN-7719";

    // doc 2
    const doc2Raw: Omit<SecureDocument, "hash"> = {
      id: "sop-02",
      companyId: "E3I Processos Inteligentes",
      projectId: "DMAIC-A3-PROCON",
      processId: "PROC-MAIN",
      title: "POP-02: Gestão de Filas e Escalonamento",
      objective: "Garantir o atendimento dentro da meta de SLA estocástico calculada.",
      scope: "Foco exclusivo no balanceamento do Gargalo Operacional do Negócio.",
      content: `1. Acompanhar o WIP nominal de cartões acumulados.\n2. Se o posto restritivo ultrapassar 5 cartões parados, acionar robô RPA auxiliar.\n3. Auditar taxas de descarte a cada amostragem por carta CEP.`,
      version: 1,
      author: "Pedro Santos Filho",
      generatedBy: "pedro.santos@empresa.com",
      generatedAt: "2026-06-12T14:30:00Z",
      classification: "Confidencial",
      retentionPolicy: "SOP - Retenção de 5 anos",
      retentionYears: 5,
      legalHold: true, // starts locked by compliance team
      status: "Aprovado",
      certificateId: "KMS-HSM-CERT-012",
      signedAt: "2026-06-12T14:40:00Z"
    };

    const doc2Hash = computeDocumentHash(doc2Raw);
    const doc2WithSignature: SecureDocument = {
      ...doc2Raw,
      hash: doc2Hash
    };
    
    const d2Sign = signDocumentKMS(doc2WithSignature, "KMS-HSM-CERT-012", "pedro.santos@empresa.com");
    doc2WithSignature.signature = d2Sign.signature;

    const d2Tsa = requestTimestampToken(doc2Hash, "Cora TSA ICP-Brasil");
    doc2WithSignature.timestampAuthority = d2Tsa.authority;
    doc2WithSignature.timestampToken = d2Tsa.token;
    doc2WithSignature.timestampTokenId = "TSA-TKN-4190";

    return [doc1WithSignature, doc2WithSignature];
  });

  const [selectedDocId, setSelectedDocId] = useState<string>("sop-01");
  const [activeTab, setActiveTab] = useState<"explorer" | "verification">("explorer");

  // 2. Custody Logs database (In memory, initial bootstrapped logs)
  const [custodyLogs, setCustodyLogs] = useState<CustodyLog[]>(() => [
    {
      id: "CUST-B01",
      documentId: "sop-01",
      version: 1,
      timestamp: "2026-06-15T10:00:00Z",
      user: "marcoantoniomiranda713@gmail.com",
      action: "Criação",
      description: "Esboço de procedimento operacional padrão gerado a partir do mapeamento de fluxo.",
      ip: "10.120.200.41"
    },
    {
      id: "CUST-B02",
      documentId: "sop-01",
      version: 1,
      timestamp: "2026-06-15T10:05:00Z",
      user: "marcoantoniomiranda713@gmail.com",
      action: "Assinatura",
      description: "Assinatura digital HSM/KMS vinculada perante o certificado KMS-HSM-CERT-001.",
      ip: "10.120.200.41"
    },
    {
      id: "CUST-B03",
      documentId: "sop-02",
      version: 1,
      timestamp: "2026-06-12T14:30:00Z",
      user: "pedro.santos@empresa.com",
      action: "Criação",
      description: "Procedimento de suporte de filas e contingenciamento carregado.",
      ip: "10.120.55.12"
    },
    {
      id: "CUST-B04",
      documentId: "sop-02",
      version: 1,
      timestamp: "2026-06-12T14:40:00Z",
      user: "pedro.santos@empresa.com",
      action: "Assinatura",
      description: "Assinado eletronicamente sob chave física KMS.",
      ip: "10.120.55.12"
    },
    {
      id: "CUST-B05",
      documentId: "sop-02",
      version: 1,
      timestamp: "2026-06-12T14:45:00Z",
      user: "marcoantoniomiranda713@gmail.com",
      action: "Bloqueio Legal Ativado",
      description: "Ativado Bloqueio Legal (Legal Hold) por motivos de compliance de auditoria regulamentar do CNPJ.",
      ip: "10.120.200.41"
    }
  ]);

  // Secondary verification certificates list to allow dynamically testing certificate revocations!
  const [revokedCerts, setRevokedCerts] = useState<Set<string>>(new Set(["KMS-HSM-CERT-REVOKED"]));

  // Feedback states
  const [systemAlert, setSystemAlert] = useState<{ type: "success" | "error" | "warning"; message: string } | null>(null);
  const [copiedDocId, setCopiedDocId] = useState<string | null>(null);

  // Settings config
  const [enableWatermark, setEnableWatermark] = useState<boolean>(true);
  const [userSelectedCertificate, setUserSelectedCertificate] = useState<string>("KMS-HSM-CERT-001");

  // Custom document generation fields
  const [newTitle, setNewTitle] = useState("");
  const [newObjective, setNewObjective] = useState("");
  const [newScope, setNewScope] = useState("");
  const [newClassification, setNewClassification] = useState<SecureDocument["classification"]>("Uso Interno");

  // VERIFICATION PORTAL STATES (SCRATCHPAD FOR AUDITING)
  const [verifyDocId, setVerifyDocId] = useState("");
  const [verifyContent, setVerifyContent] = useState("");
  const [verifyHashMetadata, setVerifyHashMetadata] = useState("");
  const [verifySignatureMetadata, setVerifySignatureMetadata] = useState("");
  const [verifyCertificateId, setVerifyCertificateId] = useState("");
  const [verifySignedAt, setVerifySignedAt] = useState("");
  const [verifyStatus, setVerifyStatus] = useState<SecureDocument["status"]>("Aprovado");
  const [verificationResult, setVerificationResult] = useState<any>(null);

  // Quick feedback notification helper
  const triggerAlert = (type: "success" | "error" | "warning", msg: string) => {
    setSystemAlert({ type, message: msg });
    setTimeout(() => setSystemAlert(null), 5000);
  };

  const selectedDoc = docs.find(d => d.id === selectedDocId && !d.isDeleted);

  // Sync user credentials with selected document signature status
  const handleSignDocument = (docId: string) => {
    const target = docs.find(d => d.id === docId);
    if (!target) return;

    if (target.signature) {
      triggerAlert("warning", "Este documento já se encontra assinado pelo KMS!");
      return;
    }

    const { signature, certificateId, signedAt } = signDocumentKMS(target, userSelectedCertificate, currentLoggedUser);
    
    // Update local state
    setDocs(prev => prev.map(d => {
      if (d.id === docId) {
        return {
          ...d,
          signature,
          certificateId,
          signedAt,
          status: "Aprovado" as const
        };
      }
      return d;
    }));

    // Register custody item
    const newCustody: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: docId,
      version: target.version,
      timestamp: signedAt,
      user: currentLoggedUser,
      action: "Assinatura",
      description: `Assinatura criptográfica vinculada via cofre KMS utilizando certificado ${certificateId}.`,
      ip: "192.168.12.8"
    };
    setCustodyLogs(prev => [...prev, newCustody]);

    triggerAlert("success", "Assinatura vinculada e carimbada pelo cofre KMS com absoluto sucesso!");
  };

  // Toggle Legal Hold
  const handleToggleLegalHold = (docId: string) => {
    setDocs(prev => prev.map(d => {
      if (d.id === docId) {
        const nextState = !d.legalHold;
        
        // Log to custody
        const newCustody: CustodyLog = {
          id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
          documentId: docId,
          version: d.version,
          timestamp: new Date().toISOString(),
          user: currentLoggedUser,
          action: nextState ? "Bloqueio Legal Ativado" : "Bloqueio Legal Desativado",
          description: nextState 
            ? "Compliance: Ativado Legal Hold em virtude de processos fiscalizatórios." 
            : "Compliance: Desabilitado bloqueio legal. Documento elegível para retenção comum.",
          ip: "192.168.12.8"
        };
        setTimeout(() => setCustodyLogs(prevL => [...prevL, newCustody]), 10);

        return { ...d, legalHold: nextState };
      }
      return d;
    }));
    triggerAlert("success", "Configuração de Bloqueio Legal (Legal Hold) atualizada!");
  };

  // Trigger download (audited)
  const handleDownloadAndAudit = (doc: SecureDocument) => {
    // Audit download event
    const newCustody: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: doc.id,
      version: doc.version,
      timestamp: new Date().toISOString(),
      user: currentLoggedUser,
      action: "Download",
      description: `Visualização e download de cópia isolada iniciada. Hash do arquivo: ${doc.hash.substring(0, 12)}...`,
      ip: "192.168.12.8"
    };
    setCustodyLogs(prev => [...prev, newCustody]);

    // Download prose
    const contentToDownload = `--- GOVERNANÇA DE COMPLIANCE DOCUMENTAL E3I ---\n` +
      `Identificador: ${doc.id}\n` +
      `Processo/Projeto: ${doc.projectId} | ${doc.processId}\n` +
      `Versão: ${doc.version} | Classificação: ${doc.classification}\n` +
      `Autor Original: ${doc.author}\n` +
      `Integridade Hash SHA-256: ${doc.hash}\n` +
      `Status Operacional: ${doc.status}\n` +
      `TSA Token: ${doc.timestampToken || "Não carimbado"}\n` +
      `KMS Signature: ${doc.signature || "Não assinado"}\n` +
      `Célula de Certificado: ${doc.certificateId || "Nenhum"}\n` +
      `\n--- CONTEÚDO PRINCIPAL ---\n` +
      `Objetivo: ${doc.objective}\n` +
      `Escopo: ${doc.scope}\n` +
      `Metodologia:\n${doc.content}\n` +
      `\nEste documento constitui propriedade intelectual corporativa regulados pela ISO 9001 e ISO 27001.\n`;

    const blob = new Blob([contentToDownload], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${doc.id}_v${doc.version}_secured.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    triggerAlert("success", "Download realizado eletronicamente e registrado em cadeia de custódia!");
  };

  // Execute Secure Disposal Soft-Delete
  const handleSecureDisposal = (doc: SecureDocument) => {
    // Execute secure disposal utilizing document security domain function
    const dummyLogs: CustodyLog[] = [];
    const result = executeSecureDisposal(doc, userPermissions, dummyLogs, currentLoggedUser);
    
    if (!result.success) {
      if (dummyLogs.length > 0) {
        setCustodyLogs(prev => [...prev, ...dummyLogs]);
      }
      triggerAlert("error", result.logMessage);
      return;
    }

    // Success path
    setDocs(prev => prev.map(d => {
      if (d.id === doc.id) {
        return result.document;
      }
      return d;
    }));
    
    if (dummyLogs.length > 0) {
      setCustodyLogs(prev => [...prev, ...dummyLogs]);
    }

    triggerAlert("success", result.logMessage);

    // Auto-select other doc if deleted
    const remaining = docs.filter(d => d.id !== doc.id && !d.isDeleted);
    if (remaining.length > 0) {
      setSelectedDocId(remaining[0].id);
    }
  };

  // Compile POP / Add New Doc
  const handleCompilePop = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      triggerAlert("error", "Por favor forneça um título para o documento.");
      return;
    }

    const docId = "sop-" + Date.now();
    const contentStr = steps.length > 0
      ? steps.map((s, idx) => `${idx + 1}. Executar posto "${s.name}" utilizando equipe "${s.resource}". Tempo nominal de ciclo: ${s.processingTime} minutos. Rendimento de qualidade esperado: ${Math.round(s.yieldRate * 100)}%.`).join("\n")
      : "1. Executar triagem preliminar de processo.\n2. Lançar no painel de indicadores DMAIC da área.";

    const rawDoc: Omit<SecureDocument, "hash"> = {
      id: docId,
      companyId: "E3I Processos Inteligentes",
      projectId: "DMAIC-A3-PROCON",
      processId: "PROC-MAIN",
      title: newTitle,
      objective: newObjective || "Padronizar o tempo de ciclo médio geral e estabelecer capabilidade sigma estável.",
      scope: newScope || "Área de Operações Core da Unidade de Negócio.",
      content: contentStr,
      version: 1,
      author: "Marco Antonio Miranda",
      generatedBy: currentLoggedUser,
      generatedAt: new Date().toISOString(),
      classification: newClassification,
      retentionPolicy: "SOP - Retenção de 5 anos",
      retentionYears: 5,
      legalHold: false,
      status: "Rascunho", // Default drafted
    };

    const hash = computeDocumentHash(rawDoc);
    const completedDoc: SecureDocument = {
      ...rawDoc,
      hash
    };

    // Auto request timestamp
    const tsa = requestTimestampToken(hash, "Cora TSA ICP-Brasil");
    completedDoc.timestampAuthority = tsa.authority;
    completedDoc.timestampToken = tsa.token;
    completedDoc.timestampTokenId = "TSA-TKN-" + Math.floor(1000 + Math.random() * 9000);

    setDocs(prev => [...prev, completedDoc]);
    setSelectedDocId(docId);

    // Custody log
    const newCustody: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: docId,
      version: 1,
      timestamp: rawDoc.generatedAt,
      user: currentLoggedUser,
      action: "Criação",
      description: `Documento compilado a partir de ${steps.length} postos do Kanban ativos. Hash auto-calculado: ${hash.substring(0,10)}...`,
      ip: "192.168.12.8"
    };
    setCustodyLogs(prev => [...prev, newCustody]);

    // clean fields
    setNewTitle("");
    setNewObjective("");
    setNewScope("");
    
    triggerAlert("success", "Novo POP gerado com Hash de integridade de bytes e timestamping automático!");
  };

  // Load selected doc data to verification form
  const handlePopulateForVerification = (doc: SecureDocument, simulateTamper: boolean = false) => {
    setActiveTab("verification");
    setVerifyDocId(doc.id);
    setVerifyContent(simulateTamper ? doc.content + "\n[TAMPERED_BY_ATTACKER_ALTERATION]" : doc.content);
    setVerifyHashMetadata(doc.hash);
    setVerifySignatureMetadata(doc.signature || "");
    setVerifyCertificateId(doc.certificateId || "");
    setVerifySignedAt(doc.signedAt || "");
    setVerifyStatus(doc.status);
    setVerificationResult(null); // clear old
  };

  // Perform cryptographic check in UI
  const handleRunVerificationCheck = () => {
    // Build a temporary document matching the fields specified in form to run domain validator
    const dummyDoc: SecureDocument = {
      id: verifyDocId,
      companyId: "E3I Processos Inteligentes",
      projectId: "DMAIC-A3-PROCON",
      processId: "PROC-MAIN",
      title: docs.find(d => d.id === verifyDocId)?.title || "POP-01: Preparação de Lotes e Setup Operacional",
      objective: docs.find(d => d.id === verifyDocId)?.objective || "Definir padrões de Setup SMED mínimos para mitigar o tempo improdutivo de ociosidade.",
      scope: docs.find(d => d.id === verifyDocId)?.scope || "Aplicável a todas as estações e postos de trabalho da linha principal.",
      content: verifyContent,
      version: docs.find(d => d.id === verifyDocId)?.version || 1,
      author: docs.find(d => d.id === verifyDocId)?.author || "Marco Antonio Miranda",
      generatedBy: docs.find(d => d.id === verifyDocId)?.generatedBy || "marcoantoniomiranda713@gmail.com",
      generatedAt: docs.find(d => d.id === verifyDocId)?.generatedAt || "2026-06-15T10:00:00Z",
      classification: docs.find(d => d.id === verifyDocId)?.classification || "Uso Interno",
      retentionPolicy: "SOP - Retenção de 5 anos",
      retentionYears: 5,
      legalHold: false,
      hash: verifyHashMetadata, // inputted metadata
      status: verifyStatus,
      signature: verifySignatureMetadata || undefined,
      certificateId: verifyCertificateId || undefined,
      signedAt: verifySignedAt || undefined
    };

    // Run verification against revoked certs
    const check = verifyDocumentSecurity(dummyDoc, revokedCerts);
    
    // Also compute what the current computed hash of the submitted text IS in real time!
    const calculatedHashRealtime = computeDocumentHash(dummyDoc);

    setVerificationResult({
      ...check,
      calculatedHash: calculatedHashRealtime,
      metadataMatched: calculatedHashRealtime === verifyHashMetadata,
      timestamp: new Date().toISOString()
    });

    // Write log to custody for AUDITING the validation itself!
    const auditCustody: CustodyLog = {
      id: "CUST-" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      documentId: verifyDocId || "VALIDATOR_PORTAL",
      version: dummyDoc.version,
      timestamp: new Date().toISOString(),
      user: currentLoggedUser,
      action: "Compartilhamento", // acts as audit analysis
      description: `Tentativa de averiguação externa. Resultado: integridade=${check.integrityOk}, assinatura=${check.signatureOk}, aprovado=${check.isValid}.`,
      ip: "10.250.99.1"
    };
    setCustodyLogs(prev => [...prev, auditCustody]);
  };

  // Toggle dynamic certificate revocation in CRL list
  const handleToggleCertificateRevocation = (certId: string) => {
    setRevokedCerts(prev => {
      const copy = new Set(prev);
      if (copy.has(certId)) {
        copy.delete(certId);
        triggerAlert("success", `Certificado ${certId} restaurado da lista de revogação.`);
      } else {
        copy.add(certId);
        triggerAlert("warning", `Certificado ${certId} revogado com sucesso na cadeia de confiança.`);
      }
      return copy;
    });
  };

  // Helper to copy text
  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    triggerAlert("success", `${label} copiado para a área de transferência!`);
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* HUD DASHBOARD STATISTICS ROW */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white border border-[#1A1A1A]/10 p-4 shadow-3xs rounded-xl">
        <div className="space-y-1">
          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Total de Procedimentos</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-gray-950">{docs.filter(d => !d.isDeleted).length}</span>
            <span className="text-[9px] font-bold text-emerald-600">ativos</span>
          </div>
        </div>

        <div className="space-y-1 border-l border-gray-100 pl-4">
          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Assinados por HSM</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-indigo-755">{docs.filter(d => d.signature && !d.isDeleted).length}</span>
            <span className="text-[9px] font-bold text-gray-500">criptografados</span>
          </div>
        </div>

        <div className="space-y-1 border-l border-gray-100 pl-4 font-sans">
          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Bloqueio Legal (Holds)</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-amber-650">{docs.filter(d => d.legalHold && !d.isDeleted).length}</span>
            <span className="text-[9px] font-bold text-amber-600">retidos</span>
          </div>
        </div>

        <div className="space-y-1 border-l border-gray-100 pl-4">
          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Revogados / Históricos</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-rose-700">{docs.filter(d => d.status === "Revogado" && !d.isDeleted).length}</span>
            <span className="text-[9px] font-bold text-rose-500">revocados</span>
          </div>
        </div>
      </div>

      {/* ALERT ROW */}
      {systemAlert && (
        <div className={`p-3.5 border-l-4 text-xs font-bold font-sans flex items-center gap-2.5 animate-pulse ${
          systemAlert.type === "success" 
            ? "bg-emerald-50 border-emerald-500 text-emerald-950" 
            : systemAlert.type === "error" 
              ? "bg-rose-50 border-rose-500 text-rose-950" 
              : "bg-amber-50 border-amber-500 text-amber-950"
        }`}>
          {systemAlert.type === "success" ? <CheckCircle2 size={16} className="text-emerald-600 shrink-0" /> : <AlertTriangle size={16} className="text-rose-600 shrink-0" />}
          <span>{systemAlert.message}</span>
        </div>
      )}

      {/* SCENARIO BAR */}
      <div className="flex justify-between items-center border-b border-gray-200">
        <div className="flex space-x-1">
          <button
            onClick={() => setActiveTab("explorer")}
            className={`py-2.5 px-4 text-xs font-bold uppercase border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "explorer" ? "border-[#C49746] text-[#C49746]" : "border-transparent text-gray-500 hover:text-gray-900"
            }`}
          >
            <BookOpen size={14} />
            Gerenciador de Documentos Auditados
          </button>
          
          <button
            onClick={() => {
              setActiveTab("verification");
              // Clear on switch
              setVerificationResult(null);
            }}
            className={`py-2.5 px-4 text-xs font-bold uppercase border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "verification" ? "border-indigo-600 text-indigo-700" : "border-transparent text-gray-500 hover:text-gray-900"
            }`}
          >
            <ShieldCheck size={14} className="text-indigo-600" />
            Portal de Verificação &amp; Autenticidade
          </button>
        </div>

        {/* WATERMARK OPTIONS TOGGLE */}
        {activeTab === "explorer" && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Watermark nas Visualizações:</span>
            <button
              onClick={() => setEnableWatermark(!enableWatermark)}
              className={`text-[9px] uppercase font-bold px-3 py-1 border transition-all ${
                enableWatermark 
                  ? "bg-emerald-50 text-emerald-700 border-emerald-200" 
                  : "bg-slate-50 text-slate-500 border-slate-200"
              }`}
            >
              {enableWatermark ? "✓ Ativo" : "✕ Oculto"}
            </button>
          </div>
        )}
      </div>

      {activeTab === "explorer" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT 4-PANEL COLUMN (Explorer and creators) */}
          <div className="lg:col-span-4 space-y-4">
            
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-3xs">
              <div className="bg-slate-50 p-3 border-b border-slate-200">
                <span className="block text-[9px] font-mono uppercase font-black tracking-widest text-slate-500">Documentos de Engenharia Ativos</span>
              </div>
              <div className="divide-y divide-slate-150">
                {docs.filter(d => !d.isDeleted).map((doc) => {
                  const isSelected = selectedDocId === doc.id;
                  let classificationColor = "text-gray-500 bg-gray-100";
                  if (doc.classification === "Confidencial") classificationColor = "text-[#C49746] bg-amber-50 border-amber-100 border";
                  else if (doc.classification === "Restrito") classificationColor = "text-rose-700 bg-rose-50 border-rose-100 border";

                  return (
                    <button
                      key={doc.id}
                      onClick={() => setSelectedDocId(doc.id)}
                      className={`w-full p-4 flex flex-col text-left transition-colors cursor-pointer ${
                        isSelected ? "bg-amber-500/10 text-slate-900 border-l-4 border-[#C49746]" : "bg-transparent text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <div className="w-full flex justify-between items-start gap-1">
                        <span className="text-[8px] font-mono font-bold text-gray-400">V{doc.version} | ID: {doc.id}</span>
                        {doc.signature && (
                          <span className="text-[7.5px] font-mono text-indigo-700 bg-indigo-50 px-1 border border-indigo-200 uppercase font-black">HSM</span>
                        )}
                      </div>

                      <p className={`text-xs font-bold leading-normal truncate mt-1 ${isSelected && "text-gray-950"}`}>{doc.title}</p>
                      
                      <div className="flex items-center gap-1.5 mt-2.5">
                        <span className={`text-[8.5px] px-1.5 py-0.5 uppercase font-bold leading-none ${classificationColor}`}>
                          {doc.classification}
                        </span>
                        
                        <span className={`text-[8.5px] px-1.5 py-0.5 uppercase font-mono font-bold leading-none ${
                          doc.status === "Aprovado" 
                            ? "bg-green-50 text-green-700" 
                            : doc.status === "Revogado" 
                              ? "bg-rose-50 text-rose-700" 
                              : "bg-slate-100 text-slate-600"
                        }`}>
                          {doc.status}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* EXPEDIDOR DE POP */}
            <form onSubmit={handleCompilePop} className="bg-white border border-slate-200 p-4 rounded-xl space-y-4 shadow-3xs">
              <div>
                <span className="block text-[9px] font-mono uppercase font-black text-[#C49746] tracking-wider mb-1">
                  Gerador de POP ISO 9001
                </span>
                <p className="text-[10px] text-slate-500 leading-normal">
                  Consolide os {steps.length} postos do Kanban ativos e publique como um manual autenticado perante a cadeia de custódia corporativa.
                </p>
              </div>

              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-[8px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
                    Título do POP
                  </label>
                  <input
                    type="text"
                    placeholder="ex: POP-32: Testes de Vazão Estocástica"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-[8px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
                    Objetivo
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Qual o objetivo central de qualidade?"
                    value={newObjective}
                    onChange={(e) => setNewObjective(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50/50 resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[8px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
                      Classificação de Acesso
                    </label>
                    <select
                      value={newClassification}
                      onChange={(e) => setNewClassification(e.target.value as any)}
                      className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50/50"
                    >
                      <option value="Público">Público</option>
                      <option value="Uso Interno">Uso Interno</option>
                      <option value="Confidencial">Confidencial</option>
                      <option value="Restrito">Restrito</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
                      Certificado de Assinatura
                    </label>
                    <select
                      value={userSelectedCertificate}
                      onChange={(e) => setUserSelectedCertificate(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50/50 text-[10px]"
                    >
                      {certificatesPool.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.id} ({c.status})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#1A1A1A] hover:bg-black text-white p-2.5 rounded-lg text-[10px] font-bold uppercase transition flex items-center justify-center gap-1.5 cursor-pointer shadow-3xs"
                >
                  <Sparkles size={11} className="text-[#C49746]" />
                  Compilar Manual do Kanban
                </button>
              </div>
            </form>

            {/* TRUSTED CERTIFICATE AUTHORITIES STATE & CONTROLS */}
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3 text-xs">
              <span className="text-[9px] font-mono uppercase font-black text-slate-500 block">
                Cofre KMS &amp; HSM - Autoridades Certificadoras
              </span>
              <p className="text-[10px] text-slate-500 leading-normal">
                Audite e gerencie o cancelador de assinaturas (CRL) de colaboradores desligados ou chaves comprometidas no HSM.
              </p>

              <div className="space-y-1.5">
                {certificatesPool.map((c) => {
                  const isRevoked = revokedCerts.has(c.id);
                  return (
                    <div key={c.id} className="flex justify-between items-center bg-white border border-slate-150 p-2 rounded-lg">
                      <div>
                        <p className="font-bold text-[10px] leading-tight text-gray-850">{c.name.split(" ")[0]} ({c.id})</p>
                        <p className="text-[8.5px] text-gray-400">Cargo: {c.name.substring(c.name.indexOf("("))}</p>
                      </div>
                      <button
                        onClick={() => handleToggleCertificateRevocation(c.id)}
                        className={`text-[8.5px] uppercase font-bold py-1 px-2.5 rounded-md transition-colors ${
                          isRevoked 
                            ? "bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold border border-rose-100" 
                            : "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-150"
                        }`}
                      >
                        {isRevoked ? "Revogado" : "Ativo"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* RIGHT 8-PANEL COLUMN (Detail and sub-securities) */}
          <div className="lg:col-span-8 space-y-4">
            {selectedDoc ? (
              <div className="border border-slate-200 bg-white shadow-3xs rounded-xl overflow-hidden">
                
                {/* 1. Header with details and action */}
                <div className="border-b border-slate-150 p-5 bg-slate-50/50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[8.5px] font-mono font-bold bg-[#C49746]/10 text-[#C49746] px-1.5 py-0.5 border border-[#C49746]/20 uppercase">
                        SOP DOCUMENT
                      </span>
                      <span className="text-[8.5px] font-mono font-bold text-gray-400">
                        V{selectedDoc.version} | {selectedDoc.id}
                      </span>
                    </div>

                    <h3 className="font-serif font-black text-slate-900 uppercase text-base tracking-tight">
                      {selectedDoc.title}
                    </h3>

                    <p className="text-[9.5px] text-slate-550">
                      Criado em: <strong className="text-slate-700">{selectedDoc.generatedAt.replace("T", " ").substring(0, 16)}</strong> por <strong className="text-slate-700">{selectedDoc.author}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleDownloadAndAudit(selectedDoc)}
                      className="border border-slate-200 hover:border-slate-350 bg-white px-3 py-2 text-slate-700 rounded-lg text-xs font-extrabold shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                      title="Fazer Download Criptografado e Assinado"
                    >
                      <Download size={13} />
                      Exportar
                    </button>

                    <button
                      onClick={() => handlePopulateForVerification(selectedDoc, false)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg text-xs font-extrabold shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <ShieldCheck size={13} />
                      Auditar no Verificador
                    </button>
                  </div>
                </div>

                {/* 2. Watermark overlay layout preview if checked */}
                {enableWatermark && (
                  <div className="bg-amber-500/5 border-b border-amber-300/30 px-5 py-2 text-center select-none text-[8.5px] font-mono font-black tracking-wide text-amber-800 break-all leading-normal">
                    {buildVisualWatermark(selectedDoc, true)}
                  </div>
                )}

                {/* 3. Real content prose body */}
                <div className="p-6 space-y-6">
                  
                  {/* General objective & scope */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 border border-slate-100 rounded-lg">
                    <div className="space-y-1">
                      <span className="text-[8px] font-mono uppercase font-black text-slate-400 tracking-wider">Objetivo do Procedimento</span>
                      <p className="text-slate-800 font-medium leading-relaxed">{selectedDoc.objective}</p>
                    </div>

                    <div className="space-y-1 border-t md:border-t-0 md:border-l border-slate-200 pt-3 md:pt-0 md:pl-4">
                      <span className="text-[8px] font-mono uppercase font-black text-slate-400 tracking-wider">Área de Aplicação / Escopo</span>
                      <p className="text-slate-800 font-medium leading-relaxed">{selectedDoc.scope}</p>
                    </div>
                  </div>

                  {/* Prose instructions content */}
                  <div className="space-y-2 text-xs">
                    <span className="block text-[8px] font-mono uppercase font-black text-slate-400 tracking-wider">Instruções Operacionais e Sequências</span>
                    <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 font-mono text-[11px] text-stone-800 whitespace-pre-line leading-relaxed">
                      {selectedDoc.content}
                    </div>
                  </div>

                  {/* CRYPTO SECURITY SUMMARY BOX */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                    <div className="bg-slate-900 px-4 py-2.5 text-white flex justify-between items-center">
                      <div className="flex items-center gap-1.5">
                        <Key size={14} className="text-[#C49746]" />
                        <span className="text-[9px] font-mono uppercase font-bold tracking-widest text-[#C49746]">
                          Criptografia &amp; Autenticidade Digital
                        </span>
                      </div>
                      <span className="text-[9px] font-mono text-gray-400 uppercase font-bold">SHA-256 HSM Proof</span>
                    </div>

                    <div className="p-4 space-y-4 text-xs font-sans">
                      
                      {/* SHA-256 Hex Display */}
                      <div className="space-y-1">
                        <span className="text-[8px] font-mono uppercase font-black text-slate-400">Hash de Integridade do Arquivo (Bytes Finais)</span>
                        <div className="flex items-center justify-between bg-slate-50 border border-slate-200 p-2 text-[10px] rounded-lg">
                          <code className="text-gray-800 font-mono font-bold select-all break-all pr-2">
                            {selectedDoc.hash}
                          </code>
                          <button
                            onClick={() => handleCopyText(selectedDoc.hash, "Hash SHA-256")}
                            className="text-slate-400 hover:text-indigo-600 transition"
                            title="Copiar Hash Completo"
                          >
                            <Copy size={12} />
                          </button>
                        </div>
                        <p className="text-[9.5px] text-slate-400 leading-normal">
                          Qualquer alteração em um único caractere invalida este hash de forma determinística na auditoria.
                        </p>
                      </div>

                      {/* KMS HSM Digital Sign status */}
                      <div className="border-t border-slate-100 pt-3 flex flex-col md:flex-row justify-between md:items-center gap-4">
                        <div className="space-y-1">
                          <span className="text-[8px] font-mono uppercase font-black text-slate-400 block">Chave de Assinatura Eletrônica</span>
                          {selectedDoc.signature ? (
                            <div className="space-y-2">
                              <span className="text-[10px] font-mono text-emerald-700 font-black bg-emerald-50 border border-emerald-250 py-0.5 px-2 rounded flex items-center gap-1 w-fit">
                                <Shield size={10} />
                                ASSINADO SOB HSM ({selectedDoc.certificateId})
                              </span>
                              <p className="text-[9px] text-slate-500 font-mono tracking-tight leading-none truncate max-w-sm">
                                Assinatura: {selectedDoc.signature}
                              </p>
                            </div>
                          ) : (
                            <div className="space-y-1">
                              <span className="text-[10px] text-rose-700 bg-rose-50 px-2 py-0.5 border border-rose-200 uppercase font-black rounded flex items-center gap-1 w-fit">
                                <AlertTriangle size={10} />
                                AGUARDANDO ASSINATURA DIGITADO
                              </span>
                              <p className="text-[9.5px] text-slate-500">Documento pendente de certificação oficial no cofre.</p>
                            </div>
                          )}
                        </div>

                        {!selectedDoc.signature && (
                          <div className="flex items-center gap-1.5 shrink-0">
                            <select
                              value={userSelectedCertificate}
                              onChange={(e) => setUserSelectedCertificate(e.target.value)}
                              className="border border-slate-200 text-[10px] rounded p-1 bg-white"
                            >
                              {certificatesPool.map(c => (
                                <option key={c.id} value={c.id}>{c.id}</option>
                              ))}
                            </select>
                            <button
                              onClick={() => handleSignDocument(selectedDoc.id)}
                              className="bg-indigo-600 hover:bg-indigo-700 border-indigo-700 text-white px-3 py-1.5 rounded text-[10px] font-extrabold uppercase transition flex items-center gap-1 hover:shadow shadow-3xs cursor-pointer"
                            >
                              <FileSignature size={11} />
                              Assinar (KMS)
                            </button>
                          </div>
                        )}
                      </div>

                      {/* TSA Timestamp Authority integration */}
                      <div className="border-t border-slate-100 pt-3 space-y-1 font-sans">
                        <span className="text-[8px] font-mono uppercase font-black text-slate-400 block">Certificado de Carimbo de Tempo (Cora TSA)</span>
                        <div className="flex flex-col sm:flex-row justify-between gap-2 text-[10px] bg-indigo-50/25 border border-indigo-100 p-2.5 rounded-lg">
                          <div>
                            <p className="font-extrabold text-[#C49746] uppercase font-mono text-[9px] tracking-wide">
                              {selectedDoc.timestampAuthority || "Aguardando Emissão"}
                            </p>
                            <p className="text-gray-600 mt-1">
                              ID Ref: <span className="font-mono text-gray-800">{selectedDoc.timestampTokenId || "Pendente"}</span>
                            </p>
                          </div>

                          <div className="text-right">
                            <p className="font-mono text-gray-500 text-[9px]">Token de Validade:</p>
                            <span className="font-mono bg-white p-1 text-[8.5px] border font-bold text-gray-700 block mt-0.5 max-w-xs truncate">
                              {selectedDoc.timestampToken || "Nenhum token ativado."}
                            </span>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* SECTION 4: TIME DE RETENÇÃO E POLÍTICA DE DESCARTE */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                    <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2">
                      <Clock size={15} className="text-[#C49746]" />
                      <span className="text-[10px] font-mono uppercase font-black tracking-widest text-slate-700">
                        Políticas de Retenção e Descarte Seguro
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-sans">
                      
                      <div className="space-y-1">
                        <span className="text-[8px] font-mono uppercase font-black text-slate-500">Regulamentação de Tempo</span>
                        <p className="font-bold text-gray-800">SOP / POP Industrial</p>
                        <p className="text-slate-500 leading-normal text-[10.5px]">
                          Prazo de retenção física/geral obrigatória de <strong className="text-slate-800">5 anos</strong>. Requer anonimização automática sob o expurgo do descarte.
                        </p>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[8px] font-mono uppercase font-black text-slate-500">Válvula de Bloqueio de Deletion</span>
                        <p className="font-bold text-gray-800 flex items-center gap-1">
                          {selectedDoc.legalHold ? (
                            <>
                              <Lock size={12} className="text-amber-600 animate-bounce" />
                              <span className="text-amber-700">BLOQUEIO LEGAL ATIVO</span>
                            </>
                          ) : (
                            <>
                              <Unlock size={12} className="text-gray-400" />
                              <span className="text-emerald-700">LIVRE PARA EXPURGO</span>
                            </>
                          )}
                        </p>
                        <p className="text-slate-500 leading-normal text-[10.5px]">
                          Trava legal (Legal Hold) que suspende temporariamente qualquer descarte de segurança.
                        </p>
                        <button
                          onClick={() => handleToggleLegalHold(selectedDoc.id)}
                          className={`mt-1.5 text-[8.5px] uppercase font-bold py-1 px-2.5 rounded transition ${
                            selectedDoc.legalHold 
                              ? "bg-slate-200 hover:bg-slate-300 text-slate-700" 
                              : "bg-amber-600 hover:bg-amber-700 text-white"
                          }`}
                        >
                          {selectedDoc.legalHold ? "Desativar Trava" : "Ativar Legal Hold"}
                        </button>
                      </div>

                      <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-200 pt-3 md:pt-0 md:pl-4">
                        <span className="text-[8px] font-mono uppercase font-black text-slate-500 block">Excluir com Preservação</span>
                        <button
                          onClick={() => {
                            if (confirm("Deseja realmente aplicar o expurgo e descarte seguro deste documento regulado?")) {
                              handleSecureDisposal(selectedDoc);
                            }
                          }}
                          className="w-full bg-rose-600 hover:bg-rose-700 border-rose-700 text-white rounded p-2 text-[10px] font-extrabold uppercase shadow-3xs flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Trash2 size={12} />
                          Descarregar Expurgo
                        </button>
                        <p className="text-[9px] text-gray-400 leading-tight">
                          O descarte higieniza os dados sensíveis dos autores de acordo com a LGPD e ISO 27001, mantendo registros da cadeia de custódia intactos.
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* SECTION 5: CADEIA DE CUSTÓDIA TIMELINE GRAPH */}
                  <div className="space-y-3 font-sans">
                    <div className="flex items-center gap-1.5 border-b border-gray-150 pb-2">
                      <History size={15} className="text-[#C49746]" />
                      <span className="text-[10px] font-mono uppercase font-black tracking-widest text-[#C49746]">
                        Cadeia de Custódia (Registro Geral Auditado)
                      </span>
                    </div>

                    <div className="relative border-l-2 border-slate-200 pl-4 space-y-4 text-xs font-sans">
                      {custodyLogs
                        .filter(l => l.documentId === selectedDoc.id)
                        .map((log) => (
                          <div key={log.id} className="relative group">
                            <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-indigo-600 ring-4 ring-white" />
                            <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-lg space-y-1 hover:border-[#C49746] transition-colors">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[10px] gap-1">
                                <span className="font-mono text-[9px] text-gray-500">{log.timestamp.replace("T", " ").substring(0, 16)}</span>
                                <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase shrink-0 w-fit ${
                                  log.action === "Criação" 
                                    ? "bg-stone-100 text-stone-700" 
                                    : log.action === "Assinatura" 
                                      ? "bg-indigo-50 text-indigo-700" 
                                      : log.action.includes("Bloqueio")
                                        ? "bg-amber-100 text-amber-700"
                                        : log.action.includes("Impedida")
                                          ? "bg-rose-100 text-rose-700"
                                          : "bg-emerald-50 text-emerald-700"
                                }`}>
                                  {log.action}
                                </span>
                              </div>
                              <p className="text-gray-800 leading-relaxed font-medium">{log.description}</p>
                              <div className="flex justify-between items-center text-[9px] text-gray-400 mt-2">
                                <span>Operador: <strong className="text-gray-550">{log.user}</strong></span>
                                <span>Terminal: <strong className="text-gray-500">{log.ip}</strong></span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>

                </div>

                {/* Foot card note */}
                <div className="bg-slate-900 p-4 text-[10px] text-slate-400 flex justify-between tracking-wide leading-none font-mono">
                  <span>ISO 9001:2015 COMPLIANT // SUCESSO DE AUDITORIA</span>
                  <span>E3I DIGITAL CUSTODIAN SUITE</span>
                </div>

              </div>
            ) : (
              <div className="bg-white border-2 border-dashed border-slate-300 rounded-xl p-16 text-center text-slate-400 font-sans space-y-4">
                <FileText size={40} className="mx-auto text-slate-350" />
                <h3 className="font-bold text-gray-800">Nenhum Documento Ativo Selecionado</h3>
                <p className="text-xs max-w-sm mx-auto">
                  Por favor selecione um dos Manuais de Qualidade na listagem lateral ou compile um POP instantâneo dos postos operacionais.
                </p>
              </div>
            )}
          </div>

        </div>
      ) : (
        
        // PÁGINA DE VERIFICAÇÃO - CORE REQUIREMENT 6
        <div className="space-y-6 font-sans">
          
          {/* Introductory notice */}
          <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-5 text-indigo-950 font-sans space-y-1">
            <h3 className="text-xs font-mono font-black uppercase tracking-wider flex items-center gap-1.5 text-indigo-900">
              <ShieldCheck size={16} />
              Portal de Auditores - Verificador Independente de Autenticidade
            </h3>
            <p className="text-[11px] leading-relaxed text-indigo-805">
              Insira o texto bruto e os metadados criptográficos para recalcular o hash SHA-256 em tempo real. O verificador submete os resultados perante a cadeia fiduciária, a lista de certificados revogados (CRL), chaves do KMS do HSM e autoridade temporal ICP-Brasil Cora TSA.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* INPUT PANEL FOR VERIFICATION (lg:col-span-7) */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-5 shadow-3xs text-xs">
              <h4 className="text-xs font-bold uppercase text-slate-800 tracking-wider">Metadados e Corpo para Verificação</h4>

              {/* SIMULATION HOTKEYS FOR FAST TESTING */}
              <div className="bg-slate-55/50 border border-slate-200 p-3 rounded-lg space-y-2">
                <span className="text-[8.5px] uppercase font-mono font-bold text-slate-500 block">Atalhos Rápidos de Simulação de Auditoria (Casos de Teste)</span>
                
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) handlePopulateForVerification(doc, false);
                    }}
                    className="bg-indigo-50 hover:bg-indigo-150 border border-indigo-200/50 hover:border-indigo-300 text-indigo-800 px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    1. Caso Saudável (Original)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) handlePopulateForVerification(doc, true); // tampered
                    }}
                    className="bg-rose-50 hover:bg-rose-100 border border-rose-200/30 hover:border-rose-300 text-rose-800 px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    2. Caso Violado (Alterado)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) {
                        handlePopulateForVerification(doc, false);
                        setVerifyHashMetadata("8f59d99c4d9bc213219ee944ab8afbf4c8996fb4c49bcf8c8a14959955"); // random bad hash
                      }
                    }}
                    className="bg-amber-50 hover:bg-amber-100 border border-amber-250 hover:border-amber-300 text-amber-800 px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    3. Hash Divergente
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) {
                        handlePopulateForVerification(doc, false);
                        setVerifySignatureMetadata("a9fe0146ff99cd3100346bfb1c1103cdef993d98" + "FF"); // corrupted signatures
                      }
                    }}
                    className="bg-purple-50 hover:bg-purple-100 border border-purple-200 hover:border-purple-300 text-[#7C3AED] px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    4. Assinatura Inválida
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) {
                        handlePopulateForVerification(doc, false);
                        setVerifyCertificateId("KMS-HSM-CERT-REVOKED"); // Signed by revoked cert (e.g. employee left)
                      }
                    }}
                    className="bg-stone-100 hover:bg-stone-200 border border-stone-300 text-stone-800 px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    5. Certificado Revogado
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const doc = docs[0];
                      if (doc) {
                        handlePopulateForVerification(doc, false);
                        setVerifyStatus("Revogado");
                      }
                    }}
                    className="bg-[#C49746]/10 hover:bg-[#C49746]/20 border border-[#C49746]/30 text-amber-900 px-2 py-1 text-[9.5px] font-bold rounded transition-all"
                  >
                    6. Documento Revogado
                  </button>
                </div>
              </div>

              {/* GRID OF METADATA FIELDS FOR VALIDATOR */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">ID do Documento</label>
                  <input
                    type="text"
                    value={verifyDocId}
                    onChange={(e) => setVerifyDocId(e.target.value)}
                    placeholder="ex: sop-01"
                    className="w-full border border-slate-200 rounded p-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">Status Reportado</label>
                  <select
                    value={verifyStatus}
                    onChange={(e) => setVerifyStatus(e.target.value as any)}
                    className="w-full border border-slate-200 rounded p-2 text-xs bg-white"
                  >
                    <option value="Rascunho">Rascunho</option>
                    <option value="Em Validação">Em Validação</option>
                    <option value="Aprovado">Aprovado</option>
                    <option value="Revogado">Revogado</option>
                    <option value="Arquivado">Arquivado</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">Hash SHA-256 Gravado de Metadados</label>
                  <input
                    type="text"
                    value={verifyHashMetadata}
                    onChange={(e) => setVerifyHashMetadata(e.target.value)}
                    placeholder="Hash de 64 caracteres hexadecimais para comparar"
                    className="w-full border border-slate-200 rounded p-2 text-xs font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">Assinatura Digital de KMS / HSM</label>
                  <input
                    type="text"
                    value={verifySignatureMetadata}
                    onChange={(e) => setVerifySignatureMetadata(e.target.value)}
                    placeholder="Assinatura física criptográfica de canais HSM"
                    className="w-full border border-slate-200 rounded p-2 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">ID do Certificado Emissor</label>
                  <input
                    type="text"
                    value={verifyCertificateId}
                    onChange={(e) => setVerifyCertificateId(e.target.value)}
                    placeholder="ex: KMS-HSM-CERT-001"
                    className="w-full border border-slate-200 rounded p-2 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">Data/Hora Assinalada</label>
                  <input
                    type="text"
                    value={verifySignedAt}
                    onChange={(e) => setVerifySignedAt(e.target.value)}
                    placeholder="ex: 2026-06-15T10:05:00Z"
                    className="w-full border border-slate-200 rounded p-2 text-xs font-mono"
                  />
                </div>
              </div>

              {/* BODY TEXT AREA */}
              <div className="space-y-1">
                <label className="block text-[8px] font-mono uppercase font-black text-slate-500 mb-1">Conteúdo/Bytes Brutos das Instruções Operacionais</label>
                <textarea
                  rows={4}
                  value={verifyContent}
                  onChange={(e) => setVerifyContent(e.target.value)}
                  placeholder="Cole aqui o conteúdo exato das instruções passo a passo para recalcular a integridade física..."
                  className="w-full border border-slate-200 rounded-lg p-3 font-mono text-[11px] bg-slate-50/50 resize-none leading-relaxed"
                />
              </div>

              <button
                type="button"
                onClick={handleRunVerificationCheck}
                className="w-full bg-indigo-650 hover:bg-indigo-750 text-white font-black text-xs uppercase p-3 transition flex items-center justify-center gap-2 shadow-2xs cursor-pointer"
              >
                <RefreshCw size={14} className="animate-spin-slow" />
                Examinar e Confrontar Integridade de Chaves
              </button>
            </div>

            {/* RESULTS VIEWPORT PANEL (lg:col-span-5) */}
            <div className="lg:col-span-5 space-y-4">
              
              {verificationResult ? (
                <div className="bg-white border border-slate-200 shadow-3xs rounded-xl p-5 space-y-5 text-xs">
                  
                  {/* Status header badge */}
                  <div className="flex justify-between items-center border-b border-gray-150 pb-3">
                    <span className="text-[9px] font-mono uppercase font-bold text-slate-400">Resultado do Barômetro Técnico</span>
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded ${
                      verificationResult.isValid 
                        ? "bg-green-50 text-green-700 border border-green-250" 
                        : "bg-rose-50 text-rose-700 border border-rose-250 animate-pulse"
                    }`}>
                      {verificationResult.isValid ? "✓ AUTÊNTICO" : "✕ CONTESTADO / INVÁLIDO"}
                    </span>
                  </div>

                  {/* Summary card description */}
                  <div className={`p-4 border text-[10.5px] leading-relaxed font-sans rounded-lg font-medium shadow-3xs ${
                    verificationResult.isValid 
                      ? "bg-emerald-50/50 border-emerald-200 text-emerald-900" 
                      : "bg-rose-50/50 border-rose-200 text-rose-950"
                  }`}>
                    {verificationResult.details}
                  </div>

                  {/* DYNAMIC PROGRESS CHECKS */}
                  <div className="space-y-3 font-sans">
                    
                    {/* Check 1: Content Hash integrity */}
                    <div className="flex justify-between items-start gap-2.5">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-800 text-[11px] block">1. Integridade Física do Conteúdo</span>
                        <span className="text-[9.5px] text-slate-500 leading-snug block">
                          Os bytes brutos conferem com a semente cadastrada de mídias?
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-black shrink-0 ${
                        verificationResult.integrityOk ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                      }`}>
                        {verificationResult.integrityOk ? "Íntegro" : "Violado"}
                      </span>
                    </div>

                    {/* Check 2: Hash matched metadata */}
                    <div className="flex justify-between items-start gap-2.5 border-t border-slate-100 pt-2.5">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-800 text-[11px] block">2. Reconhecimento de Hash</span>
                        <span className="text-[9.5px] text-slate-500 leading-snug block">
                          O Hash calculado coincide com a declaração de metadados?
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-black shrink-0 ${
                        verificationResult.metadataMatched ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                      }`}>
                        {verificationResult.metadataMatched ? "Idêntico" : "Divergente"}
                      </span>
                    </div>

                    {/* Check 3: Signature verify */}
                    <div className="flex justify-between items-start gap-2.5 border-t border-slate-100 pt-2.5">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-800 text-[11px] block">3. Token Criptográfico KMS/HSM</span>
                        <span className="text-[9.5px] text-slate-500 leading-snug block">
                          A assinatura confere matematicamente com os dados?
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-black shrink-0 ${
                        verificationResult.signatureOk ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                      }`}>
                        {verificationResult.signatureOk ? "Válido" : "Inválido"}
                      </span>
                    </div>

                    {/* Check 4: Certificate Revocation Check */}
                    <div className="flex justify-between items-start gap-2.5 border-t border-slate-100 pt-2.5">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-800 text-[11px] block">4. Auditoria de Revogação de Certificados</span>
                        <span className="text-[9.5px] text-slate-500 leading-snug block">
                          O certificado digital emissor está livre de suspensão/CRL?
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-black shrink-0 ${
                        verificationResult.notRevoked ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800 animate-bounce"
                      }`}>
                        {verificationResult.notRevoked ? "Confiável" : "REVOGADO"}
                      </span>
                    </div>

                  </div>

                  {/* COMPUTED SPECIFICS COMPARED */}
                  <div className="bg-slate-50 p-3 rounded-lg border text-[9.5px] space-y-2 font-mono">
                    <div>
                      <span className="text-slate-400 block font-bold">SHA-256 RECALCULADO EM TEMPO REAL:</span>
                      <span className="text-gray-800 font-extrabold select-all break-all">{verificationResult.calculatedHash}</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block font-bold">SHA-256 CONFRONTADO DE ENTRADA:</span>
                      <span className="text-gray-800 font-extrabold select-all break-all">{verifyHashMetadata || "[NENHUM METADADO DECLARADO]"}</span>
                    </div>
                  </div>

                  {/* TIME AND STAMP AUDIT */}
                  <div className="border-t border-slate-100 pt-3 text-[10px] text-slate-500 flex justify-between font-mono">
                    <span>Auditado em: {verificationResult.timestamp.split("T")[0]}</span>
                    <span>Código de Status: E3I-F12</span>
                  </div>

                </div>
              ) : (
                <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl p-12 text-center text-slate-400 font-sans space-y-3 shadow-3xs min-h-[300px] flex flex-col items-center justify-center">
                  <Shield size={32} className="text-indigo-400" />
                  <h4 className="font-bold text-gray-700">Aguardando Exame de Autenticidade</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed max-w-xs mx-auto">
                    Preencha ou selecione um caso de teste à esquerda para auditar instantaneamente chaves, hashes e assinaturas corporativas.
                  </p>
                </div>
              )}

              {/* EXTRA INFO ABOUT HOW TO DO INDEPENDENT VERIFICATION */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4.5 space-y-2.5 text-xs text-slate-600 font-sans leading-relaxed">
                <h5 className="font-bold text-gray-800 flex items-center gap-1">
                  <Building size={13} className="text-[#C49746]" />
                  Por que a marca d'água não é prova de autenticidade única?
                </h5>
                <p className="text-[10px] text-slate-500 leading-normal">
                  No ecossistema de alto isolamento E3I, o carimbo visual de marca d'água serve estritamente como <span className="font-bold text-gray-800">orientação física complementar</span>. A única prova jurídica incontrovertível constitui a integridade do hash do arquivo, a verificação da assinatura física no cofre HSM e a validação de timestamps da autoridade fiduciária.
                </p>
              </div>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}
