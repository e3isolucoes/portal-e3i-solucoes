import React, { useEffect, useRef } from "react";
import { motion, useMotionValue, useTransform, animate } from "motion/react";

interface CountUpProps {
  value: number;
  decimals?: number;
  duration?: number; // duration in seconds
  useLocale?: boolean;
}

/**
 * Premium Count-up animation component using motion/react.
 * Animates the numeric value transition dynamically while triggering a subtle scale-and-fade entrance effect.
 */
export default function CountUp({ value, decimals = 2, duration = 0.8, useLocale = false }: CountUpProps) {
  const count = useMotionValue(0);
  
  const rounded = useTransform(count, (latest) => {
    if (useLocale) {
      const parts = latest.toFixed(decimals).split('.');
      const integerPart = parseInt(parts[0] || "0", 10).toLocaleString("pt-BR");
      return parts[1] ? `${integerPart},${parts[1]}` : integerPart;
    }
    return latest.toFixed(decimals);
  });
  
  const prevValueRef = useRef(value);

  useEffect(() => {
    // Always start animation from the last known value
    count.set(prevValueRef.current);
    
    const controls = animate(count, value, {
      duration: duration,
      ease: "easeOut"
    });
    
    prevValueRef.current = value;
    return () => controls.stop();
  }, [value, duration, count]);

  return (
    <motion.span
      key={value}
      initial={{ opacity: 0.4, scale: 0.97, y: 3 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="inline-block"
    >
      <motion.span>{rounded}</motion.span>
    </motion.span>
  );
}

