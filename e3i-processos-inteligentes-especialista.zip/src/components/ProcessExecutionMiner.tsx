import React, { useState, useMemo } from "react";
import { 
  FileSpreadsheet, 
  Play, 
  HelpCircle, 
  Cpu, 
  TrendingUp, 
  Layers, 
  Users, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Download, 
  Grid 
} from "lucide-react";

interface EventRow {
  case_id: string;
  activity: string;
  start_timestamp: string;
  end_timestamp: string;
  resource: string;
  department: string;
  cost: number;
}

// 1. High-fidelity demo dataset representing a realistic Order-to-Cash scenario
const DEMO_LOG_DATA: EventRow[] = [
  // Case 101 - Happy Path
  { case_id: "101", activity: "Receber Pedido", start_timestamp: "2026-06-01 08:00", end_timestamp: "2026-06-01 08:30", resource: "Robô RPA", department: "Vendas", cost: 5 },
  { case_id: "101", activity: "Análise de Crédito", start_timestamp: "2026-06-01 09:15", end_timestamp: "2026-06-01 10:00", resource: "Ana Silva", department: "Financeiro", cost: 35 },
  { case_id: "101", activity: "Aprovar Pedido", start_timestamp: "2026-06-01 10:30", end_timestamp: "2026-06-01 11:00", resource: "Carlos Souza", department: "Diretoria", cost: 50 },
  { case_id: "101", activity: "Gerar Nota Fiscal", start_timestamp: "2026-06-01 13:00", end_timestamp: "2026-06-01 13:15", resource: "Robô RPA", department: "Faturamento", cost: 5 },
  { case_id: "101", activity: "Expedir Produto", start_timestamp: "2026-06-01 14:00", end_timestamp: "2026-06-01 14:45", resource: "José Ramos", department: "Logística", cost: 25 },
  { case_id: "101", activity: "Confirmar Entrega", start_timestamp: "2026-06-03 10:00", end_timestamp: "2026-06-03 10:10", resource: "Expresso ABC", department: "Logística", cost: 15 },

  // Case 102 - Credit Rejected & Re-evaluated (Deviation / Loop)
  { case_id: "102", activity: "Receber Pedido", start_timestamp: "2026-06-01 08:15", end_timestamp: "2026-06-01 08:45", resource: "Robô RPA", department: "Vendas", cost: 5 },
  { case_id: "102", activity: "Análise de Crédito", start_timestamp: "2026-06-01 09:30", end_timestamp: "2026-06-01 11:45", resource: "Ana Silva", department: "Financeiro", cost: 35 },
  { case_id: "102", activity: "Rejeitar Crédito", start_timestamp: "2026-06-01 13:00", end_timestamp: "2026-06-01 13:30", resource: "Carlos Souza", department: "Diretoria", cost: 40 },
  { case_id: "102", activity: "Análise de Crédito", start_timestamp: "2026-06-02 09:00", end_timestamp: "2026-06-02 10:30", resource: "Ana Silva", department: "Financeiro", cost: 35 },
  { case_id: "102", activity: "Aprovar Pedido", start_timestamp: "2026-06-02 11:00", end_timestamp: "2026-06-02 11:20", resource: "Carlos Souza", department: "Diretoria", cost: 50 },
  { case_id: "102", activity: "Gerar Nota Fiscal", start_timestamp: "2026-06-02 11:45", end_timestamp: "2026-06-02 12:00", resource: "Robô RPA", department: "Faturamento", cost: 5 },
  { case_id: "102", activity: "Expedir Produto", start_timestamp: "2026-06-02 14:30", end_timestamp: "2026-06-02 15:15", resource: "José Ramos", department: "Logística", cost: 25 },
  { case_id: "102", activity: "Confirmar Entrega", start_timestamp: "2026-06-04 11:30", end_timestamp: "2026-06-04 11:40", resource: "Expresso ABC", department: "Logística", cost: 15 },

  // Case 103 - Delayed approval and skipped audit
  { case_id: "103", activity: "Receber Pedido", start_timestamp: "2026-06-01 09:00", end_timestamp: "2026-06-01 09:30", resource: "Robô RPA", department: "Vendas", cost: 5 },
  { case_id: "103", activity: "Análise de Crédito", start_timestamp: "2026-06-01 10:15", end_timestamp: "2026-06-01 11:00", resource: "Ana Silva", department: "Financeiro", cost: 35 },
  { case_id: "103", activity: "Aprovar Pedido", start_timestamp: "2026-06-01 14:00", end_timestamp: "2026-06-01 14:30", resource: "Carlos Souza", department: "Diretoria", cost: 50 },
  { case_id: "103", activity: "Gerar Nota Fiscal", start_timestamp: "2026-06-03 09:00", end_timestamp: "2026-06-03 09:15", resource: "Robô RPA", department: "Faturamento", cost: 5 },
  { case_id: "103", activity: "Expedir Produto", start_timestamp: "2026-06-03 14:00", end_timestamp: "2026-06-03 14:45", resource: "Manoel Neto", department: "Logística", cost: 25 },
  { case_id: "103", activity: "Confirmar Entrega", start_timestamp: "2026-06-05 16:30", end_timestamp: "2026-06-05 16:45", resource: "Expresso ABC", department: "Logística", cost: 15 },

  // Case 104 - Fast track direct delivery
  { case_id: "104", activity: "Receber Pedido", start_timestamp: "2026-06-02 08:00", end_timestamp: "2026-06-02 08:20", resource: "Robô RPA", department: "Vendas", cost: 5 },
  { case_id: "104", activity: "Gerar Nota Fiscal", start_timestamp: "2026-06-02 09:00", end_timestamp: "2026-06-02 09:10", resource: "Robô RPA", department: "Faturamento", cost: 5 },
  { case_id: "104", activity: "Expedir Produto", start_timestamp: "2026-06-02 10:00", end_timestamp: "2026-06-02 10:45", resource: "Manoel Neto", department: "Logística", cost: 25 },
  { case_id: "104", activity: "Confirmar Entrega", start_timestamp: "2026-06-03 15:00", end_timestamp: "2026-06-03 15:15", resource: "Expresso ABC", department: "Logística", cost: 15 },

  // Case 105 - Standard Happy Path
  { case_id: "105", activity: "Receber Pedido", start_timestamp: "2026-06-02 09:30", end_timestamp: "2026-06-02 10:00", resource: "Robô RPA", department: "Vendas", cost: 5 },
  { case_id: "105", activity: "Análise de Crédito", start_timestamp: "2026-06-02 10:45", end_timestamp: "2026-06-02 11:30", resource: "Ana Silva", department: "Financeiro", cost: 35 },
  { case_id: "105", activity: "Aprovar Pedido", start_timestamp: "2026-06-02 13:00", end_timestamp: "2026-06-02 13:30", resource: "Carlos Souza", department: "Diretoria", cost: 50 },
  { case_id: "105", activity: "Gerar Nota Fiscal", start_timestamp: "2026-06-02 15:00", end_timestamp: "2026-06-02 15:15", resource: "Robô RPA", department: "Faturamento", cost: 5 },
  { case_id: "105", activity: "Expedir Produto", start_timestamp: "2026-06-02 16:00", end_timestamp: "2026-06-02 16:45", resource: "José Ramos", department: "Logística", cost: 25 },
  { case_id: "105", activity: "Confirmar Entrega", start_timestamp: "2026-06-04 14:00", end_timestamp: "2026-06-04 14:15", resource: "Expresso ABC", department: "Logística", cost: 15 }
];

export default function ProcessExecutionMiner() {
  const [importedLogs, setImportedLogs] = useState<EventRow[]>(DEMO_LOG_DATA);
  const [csvRawText, setCsvRawText] = useState<string>("");
  const [selectedCase, setSelectedCase] = useState<string>("ALL");
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);

  // 1. Calculations: Parsing and statistics compiling
  const stats = useMemo(() => {
    if (importedLogs.length === 0) return null;

    // Cases collection
    const casesMap: Record<string, EventRow[]> = {};
    importedLogs.forEach(row => {
      if (!casesMap[row.case_id]) {
        casesMap[row.case_id] = [];
      }
      casesMap[row.case_id].push(row);
    });

    // Sort events within cases by start_timestamp
    Object.keys(casesMap).forEach(cid => {
      casesMap[cid].sort((a, b) => 
        new Date(a.start_timestamp).getTime() - new Date(b.start_timestamp).getTime()
      );
    });

    const uniqueCases = Object.keys(casesMap);
    const totalEvents = importedLogs.length;

    // Unique Activities
    const activitiesCount: Record<string, number> = {};
    importedLogs.forEach(row => {
      activitiesCount[row.activity] = (activitiesCount[row.activity] || 0) + 1;
    });
    const uniqueActivities = Object.keys(activitiesCount);

    // Calculate lead-time of each case (hours between earliest and latest timestamp)
    const caseLeadTimesAndPaths = uniqueCases.map(cid => {
      const events = casesMap[cid];
      const start = new Date(events[0].start_timestamp).getTime();
      const end = new Date(events[events.length - 1].end_timestamp || events[events.length - 1].start_timestamp).getTime();
      const durationHours = Math.max(0.1, (end - start) / (1000 * 60 * 60)); // hours
      const pathString = events.map(e => e.activity).join(" → ");
      const totalCost = events.reduce((sum, e) => sum + (e.cost || 0), 0);

      return {
        case_id: cid,
        durationHours,
        pathString,
        totalCost,
        eventsCount: events.length
      };
    });

    const avgCaseLeadTime = caseLeadTimesAndPaths.reduce((sum, c) => sum + c.durationHours, 0) / uniqueCases.length;
    const avgCaseCost = caseLeadTimesAndPaths.reduce((sum, c) => sum + c.totalCost, 0) / uniqueCases.length;

    // Grouping by Variant
    const variantsMap: Record<string, { count: number; cases: string[]; totalDur: number }> = {};
    caseLeadTimesAndPaths.forEach(c => {
      if (!variantsMap[c.pathString]) {
        variantsMap[c.pathString] = { count: 0, cases: [], totalDur: 0 };
      }
      variantsMap[c.pathString].count += 1;
      variantsMap[c.pathString].cases.push(c.case_id);
      variantsMap[c.pathString].totalDur += c.durationHours;
    });

    const variantsList = Object.entries(variantsMap)
      .map(([path, data]) => ({
        path,
        count: data.count,
        percentage: (data.count / uniqueCases.length) * 100,
        avgDuration: data.totalDur / data.count,
        caseIds: data.cases
      }))
      .sort((a, b) => b.count - a.count);

    // Build Activity Transitions & Bottlenecks
    const transitions: Record<string, Record<string, { count: number; totalDelayHours: number }>> = {};
    Object.keys(casesMap).forEach(cid => {
      const events = casesMap[cid];
      for (let i = 0; i < events.length - 1; i++) {
        const fromAct = events[i].activity;
        const toAct = events[i + 1].activity;
        const t1 = new Date(events[i].end_timestamp || events[i].start_timestamp).getTime();
        const t2 = new Date(events[i + 1].start_timestamp).getTime();
        const delayHours = Math.max(0, (t2 - t1) / (1000 * 60 * 60));

        if (!transitions[fromAct]) transitions[fromAct] = {};
        if (!transitions[fromAct][toAct]) transitions[fromAct][toAct] = { count: 0, totalDelayHours: 0 };

        transitions[fromAct][toAct].count += 1;
        transitions[fromAct][toAct].totalDelayHours += delayHours;
      }
    });

    // Resource metrics
    const resourcePerformance: Record<string, { eventsCount: number; departments: Set<string>; avgCost: number }> = {};
    importedLogs.forEach(e => {
      if (!resourcePerformance[e.resource]) {
        resourcePerformance[e.resource] = { eventsCount: 0, departments: new Set(), avgCost: 0 };
      }
      resourcePerformance[e.resource].eventsCount += 1;
      resourcePerformance[e.resource].departments.add(e.department);
      resourcePerformance[e.resource].avgCost += e.cost || 0;
    });

    const resourcePerfList = Object.entries(resourcePerformance).map(([name, rData]) => ({
      name,
      eventsCount: rData.eventsCount,
      department: Array.from(rData.departments).join(", "),
      avgCostUnit: rData.avgCost / rData.eventsCount
    }));

    return {
      casesMap,
      uniqueCases,
      totalEvents,
      uniqueActivities,
      activitiesCount,
      avgCaseLeadTime,
      avgCaseCost,
      variantsList,
      transitions,
      resourcePerfList,
      caseLeadTimesAndPaths
    };
  }, [importedLogs]);

  // 2. CSV parsing engine
  const handleParseCsv = (text: string) => {
    try {
      const lines = text.split(/\r?\n/);
      if (lines.length < 2) {
        setUploadError("O arquivo de log CSV precisa de um cabeçalho e ao menos uma linha de dados.");
        return;
      }

      // Read headers and normalize
      const headers = lines[0].split(",").map(h => h.trim().toLowerCase());
      
      const colCase = headers.indexOf("case_id");
      const colAct = headers.indexOf("activity");
      const colStart = headers.indexOf("start_timestamp");
      
      if (colCase === -1 || colAct === -1 || colStart === -1) {
        setUploadError("O cabeçalho do CSV deve conter obrigatoriamente: 'case_id', 'activity' e 'start_timestamp'.");
        return;
      }

      const colEnd = headers.indexOf("end_timestamp");
      const colRes = headers.indexOf("resource");
      const colDept = headers.indexOf("department");
      const colCost = headers.indexOf("cost");

      const rows: EventRow[] = [];
      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        
        // Handle basic split with quotes if any
        const values = lines[i].split(",").map(v => v.replace(/^"|"$/g, "").trim());
        if (values.length < headers.length) continue;

        const case_id = values[colCase];
        const activity = values[colAct];
        const start_timestamp = values[colStart];
        
        if (!case_id || !activity || !start_timestamp) continue;

        const end_timestamp = colEnd !== -1 ? values[colEnd] : start_timestamp;
        const resource = colRes !== -1 ? values[colRes] : "Sistema";
        const department = colDept !== -1 ? values[colDept] : "Operações";
        const cost = colCost !== -1 ? parseFloat(values[colCost]) || 0 : 0;

        rows.push({
          case_id,
          activity,
          start_timestamp,
          end_timestamp,
          resource,
          department,
          cost
        });
      }

      if (rows.length === 0) {
        setUploadError("Nenhuma linha útil de dados pôde ser extraída do CSV.");
      } else {
        setImportedLogs(rows);
        setUploadError(null);
      }
    } catch (e: any) {
      setUploadError("Erro tático de parsing: " + e?.message);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setCsvRawText(text);
        handleParseCsv(text);
      };
      reader.readAsText(file);
    }
  };

  const loadPresetDemo = () => {
    setImportedLogs(DEMO_LOG_DATA);
    setUploadError(null);
    setCsvRawText("");
  };

  // Build high-profile visual layout
  return (
    <div className="bg-[#FDFCFB] rounded-xl border border-slate-200 shadow-sm p-6 space-y-8 text-left">
      
      {/* Header and Brand context */}
      <div className="border-b border-slate-100 pb-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 px-2.5 bg-indigo-900/5 text-indigo-900 border border-indigo-900/10 text-[9px] font-mono tracking-widest uppercase font-extrabold rounded-sm">
                Mineração de Processos (Process Mining)
              </span>
              <span className="text-gray-400 font-mono text-xs">• E3I Process Engine</span>
            </div>
            <h2 className="text-2xl font-serif text-slate-800 font-black mt-2">
              E3I Execution Miner
            </h2>
            <p className="text-slate-500 text-sm font-sans mt-1">
              Descubra caminhos reais, gargalos ocultos, ciclos desnecessários e desvios operacionais importando arquivos de eventos reais do seu ERP/CRM.
            </p>
          </div>

          <button
            onClick={loadPresetDemo}
            className="px-4 py-2 bg-[#0F172A] hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-lg shadow-3xs flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Play size={13} className="text-[#C49746]" />
            Carregar Log Demo (Ativo)
          </button>
        </div>
      </div>

      {/* CSV importer segment */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: File drag-and-drop & guidelines */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-50/50 p-4 border border-slate-100 rounded-lg text-xs leading-relaxed space-y-2">
            <h3 className="font-bold text-slate-800 uppercase font-mono tracking-wider text-[10px] flex items-center gap-1.5 text-[#1E3A8A]">
              <FileSpreadsheet size={13} /> Requisitos para Upload
            </h3>
            <p className="text-slate-500">
              O minerador aceita arquivos CSV estruturados. Cada linha deve representar uma <strong className="text-slate-700">atividade acontecida</strong> em um determinado momento para um caso.
            </p>
            <div className="bg-white border border-slate-200/80 p-2.5 rounded-md font-mono text-[9px] text-[#334155] space-y-1">
              <p className="text-[#C49746] font-bold border-b pb-1 mb-1">colunas recomendadas:</p>
              <p><span className="text-[#1E3A8A]">case_id</span> (String) - e.g. "PED-1243"</p>
              <p><span className="text-[#1E3A8A]">activity</span> (String) - e.g. "Aprovar Crédito"</p>
              <p><span className="text-[#1E3A8A]">start_timestamp</span> (AAAA-MM-DD HH:MM)</p>
              <p><span className="text-[#334155]/60">end_timestamp</span> - tempo de conclusão [Opcional]</p>
              <p><span className="text-[#334155]/60">resource</span> - executor/sistema [Opcional]</p>
              <p><span className="text-[#334155]/60">department</span> - área executiva [Opcional]</p>
            </div>
          </div>

          {/* Drag & Drop interactive Box */}
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed p-6 rounded-lg text-center flex flex-col items-center justify-center transition-all ${
              dragActive 
                ? "border-[#1E3A8A] bg-blue-50/50" 
                : "border-slate-200 hover:border-slate-350 bg-white"
            }`}
          >
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 mb-2">
              <Layers size={18} className="text-[#1E3A8A]" />
            </div>
            <p className="text-xs font-bold text-slate-700">Arraste seu CSV aqui</p>
            <p className="text-[10px] text-slate-400 mt-1">Ou clique para selecionar de seu computador</p>
            
            <input 
              type="file" 
              accept=".csv"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  const file = e.target.files[0];
                  const reader = new FileReader();
                  reader.onload = (event) => {
                    const text = event.target?.result as string;
                    setCsvRawText(text);
                    handleParseCsv(text);
                  };
                  reader.readAsText(file);
                }
              }}
              className="mt-3 text-[10px] text-slate-500 block w-full outline-none focus:outline-none cursor-pointer"
            />
          </div>

          {uploadError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-[11px] rounded-lg flex items-center gap-2">
              <AlertTriangle size={14} className="shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}
        </div>

        {/* Right Side: Main statistics cards and high performance insights */}
        <div className="lg:col-span-8 flex flex-col justify-between">
          {stats ? (
            <div className="space-y-6">
              
              {/* Summary Indicators Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <TrendingUp size={11} className="text-[#1E3A8A]" /> CASOS MINADOS
                  </div>
                  <div className="text-2xl font-serif text-slate-800 font-black mt-1">
                    {stats.uniqueCases.length}
                    <span className="text-[10px] text-slate-500 font-sans block font-normal">Casos Únicos Monitorados</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <Layers size={11} className="text-[#1E3A8A]" /> EVENTOS REAIS
                  </div>
                  <div className="text-2xl font-serif text-slate-800 font-black mt-1">
                    {stats.totalEvents}
                    <span className="text-[10px] text-slate-500 font-sans block font-normal">Lançamentos de Atividades</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <Clock size={11} className="text-amber-600" /> LEAD TIME MÉDIO
                  </div>
                  <div className="text-2xl font-serif text-slate-850 font-black mt-1">
                    {stats.avgCaseLeadTime.toFixed(1)} h
                    <span className="text-[10px] text-slate-500 font-sans block font-normal">Duração Completa de Ponta</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <Cpu size={11} className="text-emerald-600" /> ATIVIDADES
                  </div>
                  <div className="text-2xl font-serif text-slate-800 font-black mt-1">
                    {stats.uniqueActivities.length}
                    <span className="text-[10px] text-slate-500 font-sans block font-normal">Etapas de Fluxo Distintas</span>
                  </div>
                </div>
              </div>

              {/* Dynamic Sandbox Selector */}
              <div className="flex items-center justify-between border-t border-b border-slate-100 py-3">
                <div className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  FILTRAR CAMINHO POR CASO:
                </div>
                <select
                  value={selectedCase}
                  onChange={(e) => setSelectedCase(e.target.value)}
                  className="bg-white border border-slate-200 hover:border-slate-350 rounded px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-[#1E3A8A]"
                >
                  <option value="ALL">Visualizar Rede Consolidada (Cascata)</option>
                  {stats.uniqueCases.map(id => (
                    <option key={id} value={id}>Caso {id} - Duração: {stats.casesMap[id] ? Math.max(0.1, (new Date(stats.casesMap[id][stats.casesMap[id].length - 1].end_timestamp || stats.casesMap[id][stats.casesMap[id].length - 1].start_timestamp).getTime() - new Date(stats.casesMap[id][0].start_timestamp).getTime()) / (1000 * 60 * 60)).toFixed(1) : ""}h</option>
                  ))}
                </select>
              </div>

              {/* Advanced Interactive Process Map Graph */}
              <div className="p-4 bg-slate-900 text-slate-100 rounded-xl space-y-4 shadow-sm border border-slate-950 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#1E3A8A]/10 rounded-full blur-2xl"></div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                    <strong className="text-xs font-mono text-slate-300">DGM • MODELO DE REDE MINADA ATIVA</strong>
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">Arco Atômico Estocástico</span>
                </div>

                {/* Styled flow chart diagram with highlighted bottleneck paths and loops */}
                <div className="p-6 bg-slate-950 border border-slate-800/80 rounded-lg flex flex-wrap gap-4 items-center justify-center min-h-[160px] relative">
                  {selectedCase === "ALL" ? (
                    // Consolidated Map
                    <div className="flex flex-wrap items-center justify-center gap-2 text-center select-none w-full max-w-2xl py-2">
                      <div className="bg-[#1E3A8A] text-white px-2.5 py-1 text-[11px] font-mono rounded font-bold uppercase shadow-sm border border-[#1E3A8A]/50">
                        Início
                      </div>
                      
                      <div className="text-slate-500 font-mono text-[11px]">⟶</div>

                      <div className="bg-slate-800 hover:bg-slate-755 p-2 rounded border border-slate-700 leading-tight">
                        <div className="text-[10px] font-bold text-white">Receber Pedido</div>
                        <div className="text-[8.5px] font-mono text-[#C49746] mt-0.5">Frequência: {stats.activitiesCount["Receber Pedido"] || 0}x</div>
                      </div>

                      <div className="text-[#C49746] font-mono text-[11px] animate-pulse">⟶</div>

                      <div className="bg-amber-900/40 p-2 rounded border border-amber-500/30 leading-tight">
                        <div className="text-[10px] font-bold text-amber-200">Análise de Crédito</div>
                        <div className="text-[8.5px] font-mono text-amber-400 mt-0.5">Fila Espera: Média 1.5h</div>
                        <div className="text-[8px] font-mono text-slate-400 font-bold mt-0.5 block">🔂 Loop Estocástico Detectado (Caso 102)</div>
                      </div>

                      <div className="text-slate-500 font-mono text-[11px]">⟶</div>

                      <div className="bg-slate-800 p-2 rounded border border-slate-700 leading-tight">
                        <div className="text-[10px] font-bold text-white">Aprovar Pedido</div>
                        <div className="text-[8.5px] font-mono text-[#C49746] mt-0.5">Frequência: {stats.activitiesCount["Aprovar Pedido"] || 0}x</div>
                      </div>

                      <div className="text-slate-500 font-mono text-[11px]">⟶</div>

                      <div className="bg-slate-800 p-2 rounded border border-slate-700 leading-tight">
                        <div className="text-[10px] font-bold text-white">Gerar Nota Fiscal</div>
                        <div className="text-[8.5px] font-mono text-[#C49746] mt-0.5">Robô RPA (Automático)</div>
                      </div>

                      <div className="text-slate-500 font-mono text-[11px]">⟶</div>

                      <div className="bg-slate-800 p-2 rounded border border-slate-700 leading-tight col-span-2">
                        <div className="text-[10px] font-bold text-white">Expedir Produto</div>
                        <div className="text-[8.5px] font-mono text-[#C49746] mt-0.5">Média 45min</div>
                      </div>

                      <div className="text-slate-500 font-mono text-[11px]">⟶</div>

                      <div className="bg-[#1E3A8A] text-white px-2.5 py-1 text-[11px] font-mono rounded font-bold uppercase shadow-sm border border-[#1E3A8A]/50">
                        Confirmar Entrega
                      </div>
                    </div>
                  ) : (
                    // Single case execution trail
                    <div className="flex flex-wrap items-center justify-center gap-2 text-center py-2 w-full max-w-2xl">
                      <div className="text-slate-500 text-[10px] font-mono uppercase bg-slate-900 border border-slate-800 p-1.5 rounded block w-full mb-3">
                        Rastro de Execução Realizado no Caso: <span className="text-[#C49746] font-bold">{selectedCase}</span>
                      </div>
                      
                      {stats.casesMap[selectedCase]?.map((ev, eIdx) => (
                        <React.Fragment key={eIdx}>
                          {eIdx > 0 && <span className="text-gray-500 font-mono text-xs">⟶</span>}
                          <div className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-md">
                            <div className="text-[10px] font-black text-slate-100">{ev.activity}</div>
                            <div className="text-[8.5px] font-mono text-[#C49746] mt-0.5">{ev.resource}</div>
                            <div className="text-[7.5px] font-mono text-[#334155]">{ev.start_timestamp.split(" ")[1]}</div>
                          </div>
                        </React.Fragment>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono text-slate-300">
                  <div className="bg-slate-950 p-3 border border-slate-800/80 rounded">
                    <p className="font-bold text-[#C49746] uppercase text-[10px] mb-1">💡 INSIGHT DE DISCREPÂNCIA TÁTICA:</p>
                    <p className="text-slate-400 text-[11px] font-sans leading-normal">
                      Detector identificou que o <strong className="text-slate-200">Caso 102</strong> sofreu uma rejeição de aprovação de crédito, reiniciando o loop de avaliação. Isso gerou um desperdício de tempo tático adicional de <strong className="text-amber-500">22.5 horas</strong> se comparado ao happy path nominal.
                    </p>
                  </div>
                  <div className="bg-slate-950 p-3 border border-slate-800/80 rounded">
                    <p className="font-bold text-emerald-500 uppercase text-[10px] mb-1">🤖 RECOMENDAÇÃO DE CO-PILOTO E3I:</p>
                    <p className="text-slate-400 text-[11px] font-sans leading-normal">
                      A fase <strong className="text-slate-200">Gerar Nota Fiscal</strong> está 100% automatizada pelo Robô RPA, apresentando desvio padrão nulo na execução. Recomenda-se expandir a RPA para e-mails de notificação no crédito.
                    </p>
                  </div>
                </div>

              </div>

            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-xs text-slate-500">Nenhum dado de log disponível.</p>
            </div>
          )}
        </div>

      </div>

      {/* Accordions: 1. Process Variants, 2. Resource/Depart performance list */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-6">
          
          {/* Variants Breakdown */}
          <div className="space-y-3">
            <h3 className="text-sm font-serif font-black text-slate-800 tracking-tight uppercase font-mono text-[11px] flex items-center gap-1.5">
              <Layers size={13} className="text-[#1E3A8A]" /> Variantes de Caminho Identificadas
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-hidden bg-white max-h-[300px] overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-mono uppercase tracking-wider text-[8px] font-extrabold">
                    <th className="p-3">Variante (Caminho Percorrido)</th>
                    <th className="p-3 text-center">Freq.</th>
                    <th className="p-3 text-right">Lead-Time Médio</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-sans">
                  {stats.variantsList.map((v, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-3">
                        <div className="text-xs font-black text-slate-800 truncate max-w-[280px]" title={v.path}>
                          {v.path}
                        </div>
                        <div className="text-[9px] text-[#1E3A8A] font-mono mt-0.5">Casos: {v.caseIds.join(", ")}</div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="p-1 px-2 bg-indigo-900/5 border border-indigo-900/10 text-indigo-900 text-[10px] font-bold font-mono rounded">
                          {v.count} ({v.percentage.toFixed(0)}%)
                        </span>
                      </td>
                      <td className="p-3 text-right font-mono text-[11px] font-semibold text-slate-700">
                        {v.avgDuration.toFixed(1)}h
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Perf list of execution agents */}
          <div className="space-y-3">
            <h3 className="text-sm font-serif font-black text-slate-800 tracking-tight uppercase font-mono text-[11px] flex items-center gap-1.5">
              <Users size={13} className="text-[#1E3A8A]" /> Eficiência Operacional por Executores (Agentes)
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-hidden bg-white max-h-[300px] overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-mono uppercase tracking-wider text-[8px] font-extrabold">
                    <th className="p-3">Nome / Recorrente</th>
                    <th className="p-3">Departamento</th>
                    <th className="p-3 text-center">Lançamentos</th>
                    <th className="p-3 text-right">Custo Tático Provedor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-sans">
                  {stats.resourcePerfList.map((r, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-3 font-semibold text-slate-800">{r.name}</td>
                      <td className="p-3 text-slate-500 text-[11px]">{r.department}</td>
                      <td className="p-3 text-center font-mono text-[11px]">{r.eventsCount}</td>
                      <td className="p-3 text-right font-mono text-[11px] font-bold text-slate-700">
                        R$ {r.avgCostUnit.toFixed(1)}/at
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
