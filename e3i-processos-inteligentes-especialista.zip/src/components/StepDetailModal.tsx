import React, { useState } from "react";
import { 
  FileText, 
  Cpu, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Activity, 
  Download, 
  Compass, 
  Zap, 
  FileSpreadsheet, 
  Wrench, 
  AlertCircle,
  Eye,
  Settings2,
  Layers,
  Link,
  Sparkles,
  ExternalLink,
  ArrowRight
} from "lucide-react";
import { ProcessStep } from "../types";
import { AreaId, CORPORATE_AREAS } from "../utils/areaPresets";
import { useToast } from "../shared/ui/Toast";

interface StepDetailModalProps {
  step: ProcessStep;
  onClose: () => void;
  onUpdateStep: (updatedStep: ProcessStep) => void;
  onNavigateToArea?: (areaId: string) => void;
}

export default function StepDetailModal({ step, onClose, onUpdateStep, onNavigateToArea }: StepDetailModalProps) {
  const { warning } = useToast();
  const [activeTab, setActiveTab] = useState<"instructions" | "subprocesses" | "automations" | "documents" | "linkedprocesses">("instructions");
  
  // Custom states to add new operational items interactively
  const [newInput, setNewInput] = useState("");
  const [newInstruction, setNewInstruction] = useState("");
  
  // New automation form states
  const [autoTitle, setAutoTitle] = useState("");
  const [autoType, setAutoType] = useState("Software / RPA");
  const [autoStatus, setAutoStatus] = useState<"active" | "proposed">("proposed");
  const [autoDesc, setAutoDesc] = useState("");

  // New document form states
  const [docName, setDocName] = useState("");
  const [docCode, setDocCode] = useState("");
  const [docType, setDocType] = useState<"SOP" | "Checklist" | "Manual" | "Form">("SOP");

  // Selected document to read in the interactive e-Reader
  const [readingDoc, setReadingDoc] = useState<any | null>(null);

  // New subprocess form states
  const [subName, setSubName] = useState("");
  const [subResource, setSubResource] = useState("");
  const [subTime, setSubTime] = useState<number>(5.0);
  const [subYield, setSubYield] = useState<number>(0.99);
  const [subDesc, setSubDesc] = useState("");

  // New linked process form states
  const [linkAreaId, setLinkAreaId] = useState<AreaId>("finance");
  const [linkDescription, setLinkDescription] = useState("");

  // AI interactive suggestion states
  const [aiSubProposals, setAiSubProposals] = useState<any[]>([]);
  const [aiLinkProposals, setAiLinkProposals] = useState<any[]>([]);
  const [isGeneratingSubAi, setIsGeneratingSubAi] = useState(false);
  const [isGeneratingLinkAi, setIsGeneratingLinkAi] = useState(false);

  // Fallback defaults if list variables aren't defined
  const requiredInputs = step.requiredInputs || [];
  const stepInstructions = step.stepInstructions || [];
  const automations = step.automations || [];
  const supportDocuments = step.supportDocuments || [];
  const subProcesses = step.subProcesses || [];
  const linkedProcesses = step.linkedProcesses || [];

  // Handle subprocess adding
  const handleAddSubProcess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subName.trim()) return;
    const newSub = {
      id: `sub-${Date.now()}`,
      name: subName.trim(),
      resource: subResource.trim() || "Operador de Linha",
      processingTime: Number(subTime) || 2,
      yieldRate: Number(subYield) || 0.99,
      description: subDesc.trim() || undefined
    };
    onUpdateStep({ ...step, subProcesses: [...subProcesses, newSub] });
    setSubName("");
    setSubResource("");
    setSubTime(5.0);
    setSubYield(0.99);
    setSubDesc("");
  };

  const handleRemoveSubProcess = (subId: string) => {
    const updated = subProcesses.filter(s => s.id !== subId);
    onUpdateStep({ ...step, subProcesses: updated });
  };

  // Handle process linking
  const handleAddLinkProcess = (e: React.FormEvent) => {
    e.preventDefault();
    const targetArea = CORPORATE_AREAS.find(a => a.id === linkAreaId);
    if (!targetArea) return;
    const newLnk = {
      targetAreaId: linkAreaId,
      targetAreaName: targetArea.name.split(",")[0],
      description: linkDescription.trim() || "Dependência de entrega mútua"
    };
    if (linkedProcesses.some(l => l.targetAreaId === linkAreaId)) {
      warning("Este relacionamento de processo já foi adicionado!");
      return;
    }
    onUpdateStep({ ...step, linkedProcesses: [...linkedProcesses, newLnk] });
    setLinkDescription("");
  };

  const handleRemoveLinkProcess = (targetAreaId: string) => {
    const updated = linkedProcesses.filter(l => l.targetAreaId !== targetAreaId);
    onUpdateStep({ ...step, linkedProcesses: updated });
  };

  // AI Interactive Suggestions Mechanics
  const handleTriggerSubAi = () => {
    setIsGeneratingSubAi(true);
    setTimeout(() => {
      const name = step.name;
      const proposals = [
        {
          id: `ai-sub-1-${Date.now()}`,
          name: `Homologação e Checklist de ${name}`,
          resource: "Supervisor de Linha / Líder",
          processingTime: 2.5,
          yieldRate: 0.995,
          description: "Auditoria preventiva rápida do posto de trabalho antes de iniciar o processamento final."
        },
        {
          id: `ai-sub-2-${Date.now()}`,
          name: "Execução do Setup Rápido (SMED)",
          resource: "Operador de Set",
          processingTime: 4.5,
          yieldRate: 0.98,
          description: "Troca rápida de ferramental e alinhamento milimétrico com base nas premissas Lean Six Sigma."
        }
      ];
      setAiSubProposals(proposals);
      setIsGeneratingSubAi(false);
    }, 400);
  };

  const handleTriggerLinkAi = () => {
    setIsGeneratingLinkAi(true);
    setTimeout(() => {
      const proposals = [
        {
          id: `ai-lnk-1-${Date.now()}`,
          targetAreaId: "it_governance" as AreaId,
          targetAreaName: "TI, Governança & Sistemas",
          description: "Integração automática do log de processamento de lote com o sistema SAP/ERP centralizada."
        },
        {
          id: `ai-lnk-2-${Date.now()}`,
          targetAreaId: "legal_risk" as AreaId,
          targetAreaName: "Compliance Jurídico & Riscos",
          description: "Auditoria na norma ISO/IEC e mitigação de multas regulatórias associadas à qualidade desta etapa."
        }
      ];
      setAiLinkProposals(proposals);
      setIsGeneratingLinkAi(false);
    }, 400);
  };

  const handleApproveSubAi = (prop: any) => {
    onUpdateStep({
      ...step,
      subProcesses: [...subProcesses, {
        id: `ai-sub-added-${Date.now()}-${Math.random()}`,
        name: prop.name,
        resource: prop.resource,
        processingTime: prop.processingTime,
        yieldRate: prop.yieldRate,
        description: prop.description
      }]
    });
    setAiSubProposals(prev => prev.filter(p => p.id !== prop.id));
  };

  const handleApproveLinkAi = (prop: any) => {
    const newLnk = {
      targetAreaId: prop.targetAreaId,
      targetAreaName: prop.targetAreaName,
      description: prop.description
    };
    if (linkedProcesses.some(l => l.targetAreaId === prop.targetAreaId)) {
      setAiLinkProposals(prev => prev.filter(p => p.id !== prop.id));
      return;
    }
    onUpdateStep({
      ...step,
      linkedProcesses: [...linkedProcesses, newLnk]
    });
    setAiLinkProposals(prev => prev.filter(p => p.id !== prop.id));
  };

  // Handle updates
  const handleAddInput = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInput.trim()) return;
    const updatedInputs = [...requiredInputs, newInput.trim()];
    onUpdateStep({ ...step, requiredInputs: updatedInputs });
    setNewInput("");
  };

  const handleRemoveInput = (index: number) => {
    const updatedInputs = requiredInputs.filter((_, i) => i !== index);
    onUpdateStep({ ...step, requiredInputs: updatedInputs });
  };

  const handleAddInstruction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInstruction.trim()) return;
    const updatedInst = [...stepInstructions, newInstruction.trim()];
    onUpdateStep({ ...step, stepInstructions: updatedInst });
    setNewInstruction("");
  };

  const handleRemoveInstruction = (index: number) => {
    const updatedInst = stepInstructions.filter((_, i) => i !== index);
    onUpdateStep({ ...step, stepInstructions: updatedInst });
  };

  const handleAddAutomation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!autoTitle.trim() || !autoDesc.trim()) return;
    const newAuto = {
      title: autoTitle.trim(),
      type: autoType,
      status: autoStatus,
      description: autoDesc.trim()
    };
    onUpdateStep({ ...step, automations: [...automations, newAuto] });
    setAutoTitle("");
    setAutoDesc("");
  };

  const handleRemoveAutomation = (index: number) => {
    const updatedAutos = automations.filter((_, i) => i !== index);
    onUpdateStep({ ...step, automations: updatedAutos });
  };

  const handleAddDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName.trim() || !docCode.trim()) return;
    const newDoc = {
      name: `${docType}-${docCode.toUpperCase()}: ${docName.trim()}`,
      code: docCode.toUpperCase(),
      type: docType,
      rev: "A.0"
    };
    onUpdateStep({ ...step, supportDocuments: [...supportDocuments, newDoc] });
    setDocName("");
    setDocCode("");
  };

  const handleRemoveDocument = (index: number) => {
    const updatedDocs = supportDocuments.filter((_, i) => i !== index);
    onUpdateStep({ ...step, supportDocuments: updatedDocs });
  };

  // Generate dynamic SOP/Checklist prose content based on document details
  const getDocumentMockProse = (doc: any) => {
    const stepName = step.name;
    const executor = step.resource;

    if (doc.type === "SOP") {
      return `================================================================================
PROCEDIMENTO OPERACIONAL PADRÃO (SOP) • REFERÊNCIA ISO-9001:2015
CÓDIGO: ${doc.code} • STATUS: EM VIGOR • REVISÃO: ${doc.rev}
ÁREA EMISSORA: ENGENHARIA DE MANUFATURA E QUALIDADE SIX SIGMA
================================================================================

1. OBJETIVO GERAL:
Descrever formalmente as rotinas sequenciais para realizar o processo de
"${stepName}" de forma a mitigar a variabilidade operacional, atingindo estabilidade
estatística e garantindo o nível de capabilidade planejado.

2. RESPONSABILIDADE PRIMÁRIA:
Este procedimento deve ser executado obrigatoriamente pelo operacional com
perfil de "${executor}" ou equivalente, devidamente certificado.

3. REQUISITOS FÍSICOS E EPIs OBRIGATÓRIOS:
- Pulseira de Aterramento Eletrostático (ESD).
- Jaleco anti-estático com filamento de carbono.
- Óculos de proteção contra respingos.
- Calçado de segurança com biqueira reforçada.

4. SEQUÊNCIA DETALHADA DE OPERAÇÃO (STANDARD WORK):
${stepInstructions.map((ins, i) => `${i + 1}. [EXECUÇÃO] ${ins}`).join("\n")}

5. CONTROLES DA QUALIDADE E CEP (CONTROLE ESTATÍSTICO DE PROCESSO):
- Parar a linha imediatamente em caso de rejeito reincidente.
- Limites operacionais recomendados: [LCL: ${(step.processingTime * 0.7).toFixed(1)} min - UCL: ${(step.processingTime * 1.3).toFixed(1)} min].

Documento assinado digitalmente pela Coordenação Industrial DMADV/DMAIC.`;
    } else if (doc.type === "Checklist") {
      return `================================================================================
CHECKLIST DE CONFORMIDADE OPERACIONAL • CONTROLE DA QUALIDADE
CÓDIGO: ${doc.code} • STATUS: LIBERADO • REVISÃO: ${doc.rev}
================================================================================

FOLHA DE VERIFICAÇÃO DIÁRIA - ETAPA PROTOCOLO: ${stepName}

[ ] VERIFICAÇÃO DE INGRESSOS (INPUTS):
${requiredInputs.map(inp => `  - Confirmar integridade física de: "${inp}"`).join("\n")}

[ ] PARÂMETROS OPERACIONAIS DE MAQUINÁRIO:
  - Verificar temperatura nominal estipulada de projeto.
  - Testar pressão de vácuo nas mangueiras flexíveis.
  - Sensor de segurança infravermelho desobstruído.

[ ] SETUP E LIMPEZA DA BANCADA (Lean 5S):
  - Retirar lotes ou sobras do turno anterior.
  - Efetuar varredura e higienização geral de poeiras.

[Aprovado por Técnico de Linha] Assinatura diária com registro no livro de ocorrências CEP.`;
    } else {
      return `================================================================================
MANUAL TÉCNICO E ESPECIFICAÇÃO DE EXECUÇÃO
CÓDIGO: ${doc.code} • STATUS: HOMOLOGADO • REVISÃO: ${doc.rev}
================================================================================

MANUAL OPERACIONAL DETALHADO DO POOL DE RECURSOS: ${executor}

1. INTRODUÇÃO:
Este guia documenta o funcionamento mecânico, elétrico e preventivo da bancada correspondente à atividade de "${stepName}".

2. CAPACIDADE TEÓRICA DO POSTO:
- Tempo de ciclo padrão (Touch Time): ${step.processingTime} min.
- Desvio-Padrão Operacional Esperado: ${step.standardDeviation} min.
- Capacidade máxima horária: ${((60 / step.processingTime) * (step.resourceCount || 1)).toFixed(1)} unidades/hora.

3. PLANO DE MANUTENÇÃO PREVENTIVA (TPM):
- Limpeza mecânica sob vácuo a cada 24 horas de máquina ativa.
- Teste de isolamento de carcaça contra surtos ESD de 12V.

Para maiores consultorias operacionais, acione o departamento de Engenharia Avançada.`;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#1A1A1A]/60 backdrop-blur-xs select-none animate-fade-in">
      
      {/* Central Card */}
      <div className="w-full max-w-4xl bg-[#FDFCFB] border-2 border-[#1A1A1A] shadow-[12px_12px_0px_0px_rgba(26,26,26,1)] flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="bg-[#FAF8F5] border-b border-[#1A1A1A] px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-[#C49746]/10 text-[#C49746] rounded-xs">
              <Compass size={20} className="animate-spin-slow" />
            </span>
            <div>
              <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-widest flex items-center gap-1">
                Ficha Operacional Avançada • Six Sigma
              </span>
              <h3 className="text-lg font-serif font-bold text-gray-950 uppercase tracking-tight">{step.name}</h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="text-xs font-bold font-mono text-gray-400 hover:text-black hover:underline cursor-pointer transition-all"
          >
            ✕ FECHAR
          </button>
        </div>

        {/* Mini stats ribbon */}
        <div className="bg-gray-100/80 px-6 py-2 border-b border-[#1A1A1A]/10 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono">
          <div>
            <span className="text-gray-500 uppercase text-[8px] block">Executor Padrão:</span>
            <strong className="text-gray-900">{step.resource} (x{step.resourceCount})</strong>
          </div>
          <div>
            <span className="text-gray-500 uppercase text-[8px] block">Tempo de Ciclo (min):</span>
            <strong className="text-[#C49746]">{step.processingTime} min (σ {step.standardDeviation})</strong>
          </div>
          <div>
            <span className="text-gray-500 uppercase text-[8px] block">Rendimento (Yield):</span>
            <strong className="text-emerald-700">{(step.yieldRate * 100).toFixed(1)}% de eficácia</strong>
          </div>
          <div>
            <span className="text-gray-500 uppercase text-[8px] block">Capacidade Teórica:</span>
            <strong className="text-blue-700">{((60 / step.processingTime) * (step.resourceCount || 1)).toFixed(1)} un/h</strong>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap border-b border-[#1A1A1A]/10 bg-white">
          <button
            onClick={() => { setActiveTab("instructions"); setReadingDoc(null); }}
            className={`flex-1 min-w-[120px] py-3 text-center text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === "instructions" ? "bg-amber-50 text-[#C49746] border-b-2 border-[#C49746]" : "text-gray-500 hover:text-gray-800"
            }`}
          >
            <CheckCircle2 size={13} />
            Ingressos e Instruções
          </button>
          
          <button
            onClick={() => { setActiveTab("subprocesses"); setReadingDoc(null); }}
            className={`flex-1 min-w-[120px] py-3 text-center text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === "subprocesses" ? "bg-amber-50 text-[#C49746] border-b-2 border-[#C49746]" : "text-gray-500 hover:text-gray-800"
            }`}
          >
            <Layers size={13} />
            Subprocessos ({subProcesses.length})
          </button>

          <button
            onClick={() => { setActiveTab("automations"); setReadingDoc(null); }}
            className={`flex-1 min-w-[120px] py-3 text-center text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === "automations" ? "bg-amber-50 text-[#C49746] border-b-2 border-[#C49746]" : "text-gray-500 hover:text-gray-800"
            }`}
          >
            <Cpu size={13} />
            Automações ({automations.length})
          </button>
          
          <button
            onClick={() => { setActiveTab("documents"); setReadingDoc(null); }}
            className={`flex-1 min-w-[120px] py-3 text-center text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === "documents" ? "bg-amber-50 text-[#C49746] border-b-2 border-[#C49746]" : "text-gray-500 hover:text-gray-800"
            }`}
          >
            <FileText size={13} />
            Documentos ({supportDocuments.length})
          </button>

          <button
            onClick={() => { setActiveTab("linkedprocesses"); setReadingDoc(null); }}
            className={`flex-1 min-w-[120px] py-3 text-center text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === "linkedprocesses" ? "bg-amber-50 text-[#C49746] border-b-2 border-[#C49746]" : "text-gray-500 hover:text-gray-800"
            }`}
          >
            <Link size={13} />
            Vínculos ({linkedProcesses.length})
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-grow overflow-y-auto p-6 space-y-6">

          {/* TAB 1: INSTRUCTIONS & INPUTS */}
          {activeTab === "instructions" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Left Side: Required Inputs Checklist */}
              <div className="md:col-span-5 space-y-4 pr-0 md:pr-4 border-b md:border-b-0 md:border-r border-[#1A1A1A]/10 pb-6 md:pb-0 text-left">
                <div className="space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-[#C49746] flex items-center gap-1">
                    <Wrench size={12} /> Materiais e Ingressos Básicos
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Recursos físicos e matérias-primas cruciais necessários para que o operador dê início às atividades na estação de trabalho de maneira adequada.
                  </p>
                </div>

                <ul className="space-y-2 pt-2">
                  {requiredInputs.map((input, index) => (
                    <li key={index} className="flex items-start gap-2 text-[11px] text-gray-800 font-mono bg-[#FAF8F5] border border-gray-100 p-2 rounded-xs">
                      <span className="text-emerald-600 font-sans font-extrabold mt-0.5">✓</span>
                      <span className="flex-grow font-sans">{input}</span>
                      <button
                        onClick={() => handleRemoveInput(index)}
                        className="text-[9px] text-red-500 hover:text-red-700 font-mono hover:underline cursor-pointer"
                        title="Remover material"
                      >
                        Excluir
                      </button>
                    </li>
                  ))}
                  {requiredInputs.length === 0 && (
                    <p className="text-[10.5px] text-gray-400 italic">Nenhum material de entrada listado. Adicione um abaixo.</p>
                  )}
                </ul>

                {/* Form to insert new inputs */}
                <form onSubmit={handleAddInput} className="flex gap-2 pt-2">
                  <input
                    type="text"
                    value={newInput}
                    onChange={(e) => setNewInput(e.target.value)}
                    placeholder="Adicionar entrada..."
                    className="flex-grow bg-white border border-[#1A1A1A]/15 px-2.5 py-1 text-xs focus:outline-none focus:border-[#C49746]"
                  />
                  <button
                    type="submit"
                    className="bg-[#C49746] hover:bg-[#854D0E] text-white text-[10px] font-bold uppercase tracking-wider px-3 transition-colors cursor-pointer"
                  >
                    + Novo
                  </button>
                </form>
              </div>

              {/* Right Side: Step-by-Step Execution Guide */}
              <div className="md:col-span-7 space-y-4 text-left">
                <div className="space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 flex items-center gap-1">
                    <Activity size={12} className="text-[#C49746]" /> Roteiro Operacional de Trabalho (Standard Work)
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Procedimento de execução física estrito aplicável ao operador. Reduz o desvio-padrão (σ) do processo ao padronizar o ritmo tático.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  {stepInstructions.map((inst, index) => (
                    <div key={index} className="flex items-start gap-3 bg-white border border-gray-100 p-3 shadow-2xs hover:border-gray-200 transition-all">
                      <span className="w-5 h-5 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center font-mono text-[9px] font-bold shrink-0">
                        0{index + 1}
                      </span>
                      <div className="flex-grow text-[11px] leading-relaxed text-gray-700 font-sans">
                        {inst}
                      </div>
                      <button
                        onClick={() => handleRemoveInstruction(index)}
                        className="text-red-500 hover:text-red-700 hover:underline text-[9px] font-mono shrink-0 cursor-pointer"
                        title="Excluir instrução"
                      >
                        Remover
                      </button>
                    </div>
                  ))}
                  {stepInstructions.length === 0 && (
                    <p className="text-[10.5px] text-gray-400 italic">Nenhuma instrução operacional cadastrada para este posto.</p>
                  )}
                </div>

                {/* Form to add a new operational step */}
                <form onSubmit={handleAddInstruction} className="space-y-2 pt-4">
                  <textarea
                    rows={2}
                    value={newInstruction}
                    onChange={(e) => setNewInstruction(e.target.value)}
                    placeholder="Descreva detalhadamente a instrução física a ser cumprida pelo operador..."
                    className="w-full bg-white border border-[#1A1A1A]/15 p-2.5 text-xs focus:outline-none focus:border-[#C49746] resize-none"
                  />
                  <div className="text-right">
                    <button
                      type="submit"
                      className="bg-[#1A1A1A] hover:bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest py-1.5 px-4 rounded-xs transition-colors cursor-pointer"
                    >
                      Inserir Instrução no Roteiro
                    </button>
                  </div>
                </form>
              </div>

            </div>
          )}

          {/* TAB 2: AUTOMATIONS */}
          {activeTab === "automations" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
              
              {/* Left Side: Sugesstions and current list */}
              <div className="md:col-span-8 space-y-4">
                <div className="space-y-1 border-b border-[#1A1A1A]/5 pb-3">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-[#C49746] flex items-center gap-1">
                    <Cpu size={12} /> Automações Tecnológicas Cadastradas
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Sistemas automatizados e sensores integrados à bancada de trabalho para aumento de rendimento e mitigação de fadiga humana.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-3 pt-2">
                  {automations.map((automation, index) => (
                    <div key={index} className="bg-white border border-[#1A1A1A]/15 p-4 flex flex-col justify-between gap-3 relative shadow-2xs hover:shadow-xs transition-all">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className={`text-[8px] font-mono font-bold uppercase px-2 py-0.5 rounded-xs ${
                            automation.status === 'active' 
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300/30' 
                              : 'bg-amber-100 text-[#C49746] border border-amber-300/30'
                          }`}>
                            {automation.status === 'active' ? 'Ativa • Equipamento Instalado' : 'Proposta para Implementação'}
                          </span>
                          <span className="text-[9px] font-sans text-gray-400">| Tipo: {automation.type}</span>
                        </div>
                        <h5 className="text-xs font-extrabold text-gray-950 uppercase tracking-tight">{automation.title}</h5>
                        <p className="text-[11.5px] text-gray-600 leading-normal font-sans">{automation.description}</p>
                      </div>

                      <div className="text-right border-t border-gray-100 pt-2 flex justify-end">
                        <button
                          onClick={() => handleRemoveAutomation(index)}
                          className="text-red-500 hover:text-red-700 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <Trash2 size={11} /> Remover Sugestão
                        </button>
                      </div>
                    </div>
                  ))}

                  {automations.length === 0 && (
                    <div className="p-4 bg-gray-50 border border-dashed border-gray-200 text-center rounded-sm">
                      <p className="text-[11px] text-gray-400 italic font-sans">Nenhuma automação cadastrada para este posto de manufatura.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Right Side: Add Automation Recommendation Form */}
              <div className="md:col-span-4 bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-4">
                <div className="space-y-1 border-b pb-2">
                  <span className="text-[8px] font-mono font-bold uppercase tracking-wider text-[#C49746] block">Fase IMPROVE</span>
                  <h4 className="text-xs font-bold uppercase tracking-tight text-gray-900">Sugerir Engenharia / Automação</h4>
                </div>

                <form onSubmit={handleAddAutomation} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Título da Melhoria</label>
                    <input
                      required
                      type="text"
                      value={autoTitle}
                      onChange={(e) => setAutoTitle(e.target.value)}
                      placeholder="Ex: Leitor laser duplo infravermelho"
                      className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Tipo de Tecnologia</label>
                      <select
                        value={autoType}
                        onChange={(e) => setAutoType(e.target.value)}
                        className="w-full bg-white border border-[#1A1A1A]/15 p-1 focus:outline-none"
                      >
                        <option value="PLC / CLP">PLC / CLP</option>
                        <option value="Sensoriamento IoT">Sensoriamento IoT</option>
                        <option value="Machine Vision">Machine Vision</option>
                        <option value="Robótica CoBot">Robótica CoBot</option>
                        <option value="Pneumática">Pneumática</option>
                        <option value="Software / AI">Software / AI</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Status de Entrada</label>
                      <select
                        value={autoStatus}
                        onChange={(e: any) => setAutoStatus(e.target.value)}
                        className="w-full bg-white border border-[#1A1A1A]/15 p-1 focus:outline-none"
                      >
                        <option value="proposed">💡 Proposta (Desejável)</option>
                        <option value="active">🟢 Ativa (Instalada)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Impactos no Kaizen & Rendimento</label>
                    <textarea
                      required
                      rows={3}
                      value={autoDesc}
                      onChange={(e) => setAutoDesc(e.target.value)}
                      placeholder="Explique como essa tecnologia irá resgatar segundos de desvio padrão ou aumentar a taxa de conversão Yield..."
                      className="w-full bg-white border border-[#1A1A1A]/15 p-2 focus:outline-none focus:border-[#C49746] resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1A1A1A] hover:bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest py-2 px-2.5 transition-colors cursor-pointer text-center"
                  >
                    Propor Melhoria Kaizen
                  </button>
                </form>
              </div>

            </div>
          )}

          {/* TAB 3: DOCUMENTS */}
          {activeTab === "documents" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
              
              {/* Left Side: Document Explorer list */}
              <div className="md:col-span-6 space-y-4">
                <div className="space-y-1 border-b pb-3 border-gray-100">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-[#C49746] flex items-center gap-1.5">
                    <FileText size={13} /> Biblioteca Técnica de Procedimentos CEP
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Instruções formais de ISO-9001 e folhas de verificação oficiais associadas a esta fase para auditorias fabris periódicas.
                  </p>
                </div>

                <div className="space-y-2.5 pt-2">
                  {supportDocuments.map((doc, index) => (
                    <div 
                      key={index}
                      className="border border-[#1A1A1A]/10 bg-white p-3.5 flex items-center justify-between shadow-2xs hover:border-[#C49746]/30 hover:bg-amber-50/5 transition-all group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="p-2 bg-gray-100 text-gray-600 rounded-sm group-hover:bg-[#C49746]/15 group-hover:text-[#C49746] transition-colors shrink-0">
                          <FileSpreadsheet size={15} />
                        </span>
                        <div className="min-w-0">
                          <p className="text-xs font-extrabold text-gray-950 uppercase tracking-tight truncate font-sans">{doc.name}</p>
                          <p className="text-[9.5px] font-mono text-gray-500">
                            Código: <span className="text-[#C49746] font-bold">{doc.code}</span> | Revista: {doc.rev} | Tipo: {doc.type}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 ml-4">
                        <button
                          onClick={() => setReadingDoc(doc)}
                          className="bg-transparent text-gray-800 hover:text-black hover:underline font-mono text-[9px] font-bold flex items-center gap-1 border border-gray-200 hover:border-black p-1 px-2 cursor-pointer transition-all"
                        >
                          <Eye size={10} /> Ler SOP
                        </button>
                        <button
                          onClick={() => handleRemoveDocument(index)}
                          className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50"
                          title="Remover documento da lista"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))}

                  {supportDocuments.length === 0 && (
                    <p className="text-[11px] text-gray-400 italic">Nenhum documento operacional vinculado a esta máquina. Gere um ao lado.</p>
                  )}
                </div>
              </div>

              {/* Right Side: Form to attach new procedure or interactive reader */}
              <div className="md:col-span-6 border border-[#1A1A1A]/10 bg-[#FAF8F5] p-5 flex flex-col justify-between min-h-[300px]">
                
                {readingDoc ? (
                  /* Interactive SOP e-Reader Display */
                  <div className="space-y-4 h-full flex flex-col justify-between animate-fade-in">
                    <div className="flex items-start justify-between border-b pb-2">
                      <div>
                        <span className="text-[8px] font-mono font-bold bg-[#C49746]/10 text-[#C49746] px-2 py-0.5 rounded-xs uppercase tracking-wider">
                          ISO-9001 e-Reader
                        </span>
                        <h5 className="text-[11px] font-extrabold text-gray-950 uppercase mt-1 tracking-tight truncate max-w-xs">{readingDoc.name}</h5>
                      </div>
                      <button 
                        onClick={() => setReadingDoc(null)}
                        className="text-[9px] font-bold text-gray-400 hover:text-[#C49746] hover:underline"
                      >
                        ✕ Fechar Leitor
                      </button>
                    </div>

                    <pre className="p-3 bg-gray-950 text-emerald-300 text-[9px] font-mono leading-relaxed overflow-y-auto max-h-60 rounded-sm text-left whitespace-pre-wrap select-text h-64 border border-[#1A1A1A]">
                      {getDocumentMockProse(readingDoc)}
                    </pre>

                    <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                      <span className="text-[8.5px] font-mono text-gray-400">Páginas: 1 de 1 • Imprimir disponível em PDF</span>
                      <button
                        type="button"
                        onClick={() => {
                          const element = document.createElement("a");
                          const file = new Blob([getDocumentMockProse(readingDoc)], {type: 'text/plain'});
                          element.href = URL.createObjectURL(file);
                          element.download = `${readingDoc.code}_PROCEDIMENTO.txt`;
                          document.body.appendChild(element);
                          element.click();
                          document.body.removeChild(element);
                        }}
                        className="bg-[#1A1A1A] hover:bg-gray-800 text-white text-[9.5px] font-bold uppercase tracking-widest py-1.5 px-3 flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <Download size={11} /> Baixar .TXT
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Create / Attach standard document */
                  <div className="space-y-4 text-left">
                    <div className="space-y-1 border-b pb-2">
                      <span className="text-[8px] font-mono font-bold uppercase tracking-wider text-[#C49746] block">Registro ISO-9001</span>
                      <h4 className="text-xs font-bold uppercase tracking-tight text-gray-900">Cadastrar Novo Procedimento Técnica</h4>
                    </div>

                    <form onSubmit={handleAddDocument} className="space-y-3.5 text-xs">
                      <div>
                        <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Título do Documento</label>
                        <input
                          required
                          type="text"
                          value={docName}
                          onChange={(e) => setDocName(e.target.value)}
                          placeholder="Ex: Operação Segura do Trilho Pick and Place"
                          className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Identificador Único</label>
                          <input
                            required
                            type="text"
                            value={docCode}
                            onChange={(e) => setDocCode(e.target.value)}
                            placeholder="Ex: SOP-SMT-501"
                            className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 font-mono focus:outline-none focus:border-[#C49746]"
                          />
                        </div>

                        <div>
                          <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Tipo Regulatório</label>
                          <select
                            value={docType}
                            onChange={(e: any) => setDocType(e.target.value)}
                            className="w-full bg-white border border-[#1A1A1A]/15 p-1 focus:outline-none"
                          >
                            <option value="SOP">SOP (Procedimento)</option>
                            <option value="Checklist">Folha Checklist</option>
                            <option value="Manual">Manual de Posto</option>
                          </select>
                        </div>
                      </div>

                      <div className="p-3 bg-amber-50/50 border border-[#C49746]/10 text-[9px] text-[#C49746] flex items-start gap-1.5 leading-relaxed rounded-xs">
                        <AlertCircle size={10} className="shrink-0 mt-0.5" />
                        <span>Nossos documentos são gerados automaticamente seguindo padrões estritos de qualidade Six Sigma (DMADV) e estarão disponíveis para leitura e exportação imediata.</span>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-[#1A1A1A] hover:bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest py-2 px-3 transition-colors cursor-pointer text-center"
                      >
                        Publicar Documento de Apoio
                      </button>
                    </form>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB: SUBPROCESSES */}
          {activeTab === "subprocesses" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
              
              {/* Left Column: Vertical Timeline / Subprocess List */}
              <div className="md:col-span-12 lg:col-span-7 space-y-4">
                <div className="space-y-1 border-b border-gray-100 pb-3">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-[#C49746] flex items-center gap-1.5">
                    <Layers size={13} /> Subprocessos e Atividades de Drill-Down
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Mapeamento granular em profundidade das micro-atividades executadas no escopo desta etapa operacional.
                  </p>
                </div>

                <div className="relative border-l border-gray-200 pl-4 ml-2.5 pt-1 space-y-4">
                  {subProcesses.map((sub, idx) => (
                    <div key={sub.id} className="relative group bg-white border border-gray-200 p-3 shadow-2xs hover:border-[#C49746]/30 transition-all">
                      {/* Timeline Dot */}
                      <span className="absolute -left-[23px] top-4 w-3.5 h-3.5 rounded-full border-2 border-[#C49746] bg-white flex items-center justify-center font-mono text-[6.5px] font-bold text-gray-900 shadow-xs z-10">
                        {idx + 1}
                      </span>
                      
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h5 className="text-[11.5px] font-bold text-gray-900 tracking-tight">{sub.name}</h5>
                          <span className="text-[9px] font-mono text-gray-500 bg-gray-50 px-1.5 py-0.5 border border-gray-100 mt-1 inline-block">
                            👥 Resp: {sub.resource} | ⏱️ {sub.processingTime} min | 🟢 Yield: {(sub.yieldRate * 100).toFixed(0)}%
                          </span>
                          {sub.description && (
                            <p className="text-[10px] text-gray-600 mt-1.5 leading-relaxed bg-[#FAF9F6] p-1.5 border border-gray-100/50 font-sans">
                              {sub.description}
                            </p>
                          )}
                        </div>
                        
                        <button
                          type="button"
                          onClick={() => handleRemoveSubProcess(sub.id)}
                          className="text-red-500 hover:text-red-700 p-1 cursor-pointer transition-colors"
                          title="Remover Subprocesso"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))}

                  {subProcesses.length === 0 && (
                    <div className="p-5 bg-gray-50/50 border border-dashed border-gray-200 text-center rounded-sm -ml-4">
                      <p className="text-[10.5px] text-gray-400 italic font-sans">Nenhum subprocesso cadastrado. Detalhe este fluxo ao lado ou peça sugestões da IA Co-pilot.</p>
                    </div>
                  )}
                </div>

                {/* AI Interactive Proposals Block (Requires explicit approval) */}
                <div className="mt-6 border border-indigo-100 bg-indigo-50/30 p-4 rounded-xs text-left">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <Sparkles size={14} className="text-indigo-600 animate-pulse" />
                      <span className="text-[10px] uppercase font-black tracking-widest text-[#1A1A1A]">Advisor Inteligente IA (DMAIC)</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleTriggerSubAi}
                      disabled={isGeneratingSubAi}
                      className="text-[9.5px] font-mono font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-3 py-1 cursor-pointer transition-all flex items-center gap-1"
                    >
                      {isGeneratingSubAi ? "Gerando..." : "⚡ Sugerir Subprocessos"}
                    </button>
                  </div>
                  
                  {aiSubProposals.length > 0 && (
                    <div className="mt-3.5 space-y-2.5">
                      <p className="text-[9.5px] text-gray-500 leading-normal">
                        A IA sugeriu os seguintes micro-procedimentos baseados no contexto desta operação. **Aprovação explícita obrigatória**:
                      </p>
                      {aiSubProposals.map((prop) => (
                        <div key={prop.id} className="bg-white border border-indigo-200/60 p-3 rounded-xs relative shadow-2xs">
                          <span className="absolute top-2 right-2 text-[7.5px] font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-1 py-0.2 rounded-xs">RECOMENDADO</span>
                          <h6 className="text-[11px] font-bold text-gray-900 pr-20">{prop.name}</h6>
                          <div className="text-[8.5px] font-mono text-gray-500 mt-0.5">Resp: {prop.resource} | Tempo: {prop.processingTime} min | Yield: {(prop.yieldRate*100).toFixed(1)}%</div>
                          <p className="text-[9.5px] text-gray-600 leading-relaxed mt-1">{prop.description}</p>
                          <div className="mt-2.5 flex justify-end gap-1.5 font-mono">
                            <button
                              type="button"
                              onClick={() => setAiSubProposals(prev => prev.filter(p => p.id !== prop.id))}
                              className="px-2 py-0.5 text-[8.5px] font-bold uppercase text-gray-500 hover:text-gray-900 cursor-pointer"
                            >
                              Recusar
                            </button>
                            <button
                              type="button"
                              onClick={() => handleApproveSubAi(prop)}
                              className="px-3 py-0.5 text-[8.5px] font-bold uppercase text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm cursor-pointer"
                            >
                              ✓ Aprovar & Adicionar
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: Add Subprocess Form */}
              <div className="md:col-span-12 lg:col-span-5 bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-4 h-fit">
                <div className="space-y-1 border-b pb-2">
                  <span className="text-[8px] font-mono font-bold uppercase tracking-wider text-[#C49746] block">Fuga de Variabilidade</span>
                  <h4 className="text-xs font-bold uppercase tracking-tight text-gray-900">Mapear Novo Subprocesso</h4>
                </div>

                <form onSubmit={handleAddSubProcess} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Nome do Subprocesso / Micro-Etapa</label>
                    <input
                      required
                      type="text"
                      value={subName}
                      onChange={(e) => setSubName(e.target.value)}
                      placeholder="Ex: Inspeção micro-visual de juntas de solda"
                      className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                    />
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Executor Responsável</label>
                    <input
                      type="text"
                      value={subResource}
                      onChange={(e) => setSubResource(e.target.value)}
                      placeholder="Ex: Auditor de Trilha SMT"
                      className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Tempo de Ciclo (Min)</label>
                      <input
                        type="number"
                        step="0.1"
                        min="0.1"
                        value={subTime}
                        onChange={(e) => setSubTime(Number(e.target.value))}
                        className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                      />
                    </div>

                    <div>
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Taxa Yield (0-1.0)</label>
                      <input
                        type="number"
                        step="0.01"
                        min="0.5"
                        max="1.0"
                        value={subYield}
                        onChange={(e) => setSubYield(Number(e.target.value))}
                        className="w-full bg-white border border-[#1A1A1A]/15 px-3 py-1.8 focus:outline-none focus:border-[#C49746]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Descrição Detalhada do Trabalho</label>
                    <textarea
                      rows={3}
                      value={subDesc}
                      onChange={(e) => setSubDesc(e.target.value)}
                      placeholder="Instruções sucintas recomendadas para estabilidade estatística do subprocesso..."
                      className="w-full bg-white border border-[#1A1A1A]/15 p-2 focus:outline-none focus:border-[#C49746] resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1A1A1A] hover:bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest py-2 px-3 transition-colors cursor-pointer text-center"
                  >
                    Mapear Atividade Granular
                  </button>
                </form>
              </div>

            </div>
          )}

          {/* TAB: LINKED PROCESSES */}
          {activeTab === "linkedprocesses" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
              
              {/* Left Column: List of Relations */}
              <div className="md:col-span-12 lg:col-span-7 space-y-4">
                <div className="space-y-1 border-b border-gray-100 pb-3">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-[#C49746] flex items-center gap-1.5">
                    <Link size={13} /> Conexões Inter-Processos da Cadeia de Valor
                  </h4>
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                    Mapas e dependências cruzadas entre diferentes postas de trabalho e departamentos corporativos.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-3 pt-1">
                  {linkedProcesses.map((lnk) => (
                    <div 
                      key={lnk.targetAreaId} 
                      className="border border-[#1A1A1A]/10 bg-white p-4 rounded-xs shadow-2xs hover:border-[#C49746]/20 transition-all flex flex-col justify-between"
                    >
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] font-mono font-bold bg-[#E8F0FE] text-blue-800 px-2.5 py-0.5 rounded-sm uppercase tracking-wide">
                            🔗 Vínculo Estrutural
                          </span>
                          <button
                            type="button"
                            onClick={() => handleRemoveLinkProcess(lnk.targetAreaId)}
                            className="text-red-500 hover:text-red-700 text-[10px] font-bold hover:underline transition-colors cursor-pointer border-none bg-transparent p-0"
                          >
                            Excluir
                          </button>
                        </div>
                        <h5 className="text-xs font-black text-gray-950 uppercase tracking-tight">
                          Posto Conectado: {lnk.targetAreaName}
                        </h5>
                        <p className="text-[11px] text-gray-600 leading-relaxed font-sans">{lnk.description}</p>
                      </div>

                      {onNavigateToArea && (
                        <div className="mt-3.5 pt-2.5 border-t border-gray-100/60 flex justify-end">
                          <button
                            type="button"
                            onClick={() => onNavigateToArea(lnk.targetAreaId)}
                            className="bg-[#C49746] hover:bg-[#854D0E] text-white font-sans text-[9px] font-bold uppercase py-1.5 px-3 flex items-center gap-1 cursor-pointer shadow-sm hover:translate-y-[-1px] duration-150 border-none"
                            title="Ir para o mapa visual de atividades deste setor"
                          >
                            <span>🔍 Investigar Setor {lnk.targetAreaName}</span>
                            <ArrowRight size={11} />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}

                  {linkedProcesses.length === 0 && (
                    <div className="p-5 bg-gray-50/50 border border-dashed border-gray-200 text-center rounded-sm">
                      <p className="text-[10.5px] text-gray-400 italic font-sans">Nenhum vínculo inter-processo estabelecido para esta máquina de trabalho.</p>
                    </div>
                  )}
                </div>

                {/* AI Suggestions for Department Links (Requires explicit confirmation) */}
                <div className="mt-6 border border-indigo-100 bg-indigo-50/30 p-4 rounded-xs text-left">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <Sparkles size={14} className="text-indigo-600 animate-pulse" />
                      <span className="text-[10px] uppercase font-black tracking-widest text-[#1A1A1A]">Advisor IA: Sincronização S&OP</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleTriggerLinkAi}
                      disabled={isGeneratingLinkAi}
                      className="text-[9.5px] font-mono font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-3 py-1 cursor-pointer transition-all"
                    >
                      {isGeneratingLinkAi ? "Calculando..." : "⚡ Sugerir Sincronizações S&OP"}
                    </button>
                  </div>
                  
                  {aiLinkProposals.length > 0 && (
                    <div className="mt-3.5 space-y-2.5">
                      <p className="text-[9.5px] text-gray-500 leading-normal">
                        A IA sugeriu conexões de upstream/downstream relevantes com outros elos. **Aprovação explícita obrigatória**:
                      </p>
                      {aiLinkProposals.map((prop) => (
                        <div key={prop.id} className="bg-white border border-indigo-200/60 p-3 rounded-xs relative shadow-2xs">
                          <span className="absolute top-2 right-2 text-[7.5px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-xs">ANÁLISE DE CADEIA</span>
                          <h6 className="text-[11px] font-bold text-gray-900">{prop.targetAreaName}</h6>
                          <p className="text-[9.5px] text-gray-600 leading-relaxed mt-1">{prop.description}</p>
                          <div className="mt-2.5 flex justify-end gap-1.5 font-mono">
                            <button
                              type="button"
                              onClick={() => setAiLinkProposals(prev => prev.filter(p => p.id !== prop.id))}
                              className="px-2 py-0.5 text-[8.5px] font-bold uppercase text-gray-500 hover:text-gray-900 cursor-pointer"
                            >
                              Recusar
                            </button>
                            <button
                              type="button"
                              onClick={() => handleApproveLinkAi(prop)}
                              className="px-3 py-0.5 text-[8.5px] font-bold uppercase text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm cursor-pointer"
                            >
                              ✓ Aprovar Relacionamento
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: Add Linked Process Form */}
              <div className="md:col-span-12 lg:col-span-5 bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-4 h-fit">
                <div className="space-y-1 border-b pb-2">
                  <span className="text-[8px] font-mono font-bold uppercase tracking-wider text-[#C49746] block">S&OP Alinhamento</span>
                  <h4 className="text-xs font-bold uppercase tracking-tight text-gray-900">Relacionar com Setor do Valor</h4>
                </div>

                <form onSubmit={handleAddLinkProcess} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Setor Destino (Cadeia de Valor)</label>
                    <select
                      value={linkAreaId}
                      onChange={(e: any) => setLinkAreaId(e.target.value)}
                      className="w-full bg-white border border-[#1A1A1A]/15 p-2 focus:outline-none"
                    >
                      {CORPORATE_AREAS.filter(a => a.id !== step.id).map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.icon} {a.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Motivação / Conexão Sistêmica</label>
                    <textarea
                      required
                      rows={4}
                      value={linkDescription}
                      onChange={(e) => setLinkDescription(e.target.value)}
                      placeholder="Ex: Fornece o lote eletrônico validado necessário para que o setor de auditoria e liberação de carga dê andamento..."
                      className="w-full bg-white border border-[#1A1A1A]/15 p-2 focus:outline-none focus:border-[#C49746] resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1A1A1A] hover:bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest py-2 px-3 transition-colors cursor-pointer text-center"
                  >
                    Estabelecer Relacionamento
                  </button>
                </form>
              </div>

            </div>
          )}

        </div>

        {/* Footer info and update actions */}
        <div className="bg-[#FAF8F5] border-t border-[#1A1A1A] px-6 py-4 flex items-center justify-between">
          <p className="text-[9px] text-gray-500 font-mono">
            ID Operacional: <strong className="text-gray-900">{step.id}</strong> | Última modificação registrada localmente.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="bg-[#1A1A1A] hover:bg-gray-800 text-white font-sans font-bold text-xs uppercase tracking-widest py-2 px-6 shadow-xs cursor-pointer transition-colors"
          >
            Concluir & Voltar ao Fluxo
          </button>
        </div>

      </div>
    </div>
  );
}
