import React, { useState } from "react";
import { 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle2, 
  Cpu, 
  Sparkles, 
  Send, 
  RefreshCw, 
  Mail, 
  Phone, 
  User, 
  Settings, 
  Layers,
  AlertTriangle,
  Code,
  HelpCircle,
  MessageSquare
} from "lucide-react";
import { AiService, ParseProcessResult } from "../services/AiService";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";
import { Company } from "../types";

// Firebase imports if needed
import { db } from "../firebase";
import { doc, updateDoc, arrayUnion } from "firebase/firestore";

function ParsedProcessResultView({ 
  result,
  originalText,
  onUpdateResult
}: { 
  result: ParseProcessResult;
  originalText: string;
  onUpdateResult?: (updated: ParseProcessResult) => void;
}) {
  const [showMermaidCode, setShowMermaidCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedbackInput, setFeedbackInput] = useState("");
  const [chatHistory, setChatHistory] = useState<{ role: "user" | "model"; content: string }[]>([]);
  const [isRefining, setIsRefining] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(result.mermaidDiagram);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRefine = async (customFeedback?: string) => {
    const finalFeedback = customFeedback || feedbackInput;
    if (!finalFeedback || finalFeedback.trim().length === 0) return;

    setIsRefining(true);
    setErrorMessage(null);
    
    const newUserMessage = { role: "user" as const, content: finalFeedback };
    const updatedHistory = [...chatHistory, newUserMessage];
    setChatHistory(updatedHistory);
    setFeedbackInput("");

    try {
      const updatedResult = await AiService.parseProcess(originalText, finalFeedback, updatedHistory);
      
      setChatHistory([
        ...updatedHistory, 
        { role: "model" as const, content: "Processo atualizado com sucesso! Veja as novas informações no fluxograma e nos elementos-chave." }
      ]);
      
      if (onUpdateResult) {
        onUpdateResult(updatedResult);
      }
    } catch (error: any) {
      console.error("Erro ao refinar processo:", error);
      setErrorMessage("Erro ao atualizar processo com IA: " + (error.message || error));
    } finally {
      setIsRefining(false);
    }
  };

  const questionsToRender = result.interactiveQuestions && result.interactiveQuestions.length > 0 
    ? result.interactiveQuestions 
    : [
        "Quem é o responsável por iniciar ou autorizar a primeira etapa?",
        "Que outra ferramenta ou planilha é usada durante a execução?",
        "Qual o tempo médio estimado ou gargalo que costuma ocorrer no fluxo?"
      ];

  return (
    <div className="space-y-6 animate-fadeIn font-sans text-left mt-6 border-t-2 border-dashed border-gray-300 pt-6">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="text-amber-500 animate-pulse" size={20} />
        <h4 className="text-lg font-bold text-indigo-950 font-serif">Mapeamento e Diagnóstico do Processo via IA</h4>
      </div>
      <p className="text-xs text-gray-500">
        Com base no relato do processo, a IA interpretou a estrutura lógica, identificou gargalos operacionais e desenhou o fluxo correspondente.
      </p>

      {/* 1. Extração de Elementos-Chave (4 Bento Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 bg-amber-50 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] rounded">
          <span className="text-[10px] font-mono font-bold uppercase text-amber-800 tracking-wider flex items-center gap-1">
            🚀 Gatilho / Entrada
          </span>
          <p className="text-xs text-gray-800 mt-2 font-medium leading-relaxed">
            {result.gatilho || "Não identificado"}
          </p>
        </div>

        <div className="p-4 bg-indigo-50 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] rounded">
          <span className="text-[10px] font-mono font-bold uppercase text-indigo-800 tracking-wider flex items-center gap-1">
            👥 Atores / Responsáveis
          </span>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {result.atores && result.atores.length > 0 ? (
              result.atores.map((ator, idx) => (
                <span key={idx} className="text-[10px] bg-white border border-[#1A1A1A] px-2 py-0.5 rounded font-mono font-bold text-gray-800 shadow-2xs">
                  {ator}
                </span>
              ))
            ) : (
              <span className="text-xs text-gray-400 italic">Nenhum ator explícito mencionado.</span>
            )}
          </div>
        </div>

        <div className="p-4 bg-sky-50 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] rounded">
          <span className="text-[10px] font-mono font-bold uppercase text-sky-800 tracking-wider flex items-center gap-1">
            💻 Sistemas / Ferramentas
          </span>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {result.sistemas && result.sistemas.length > 0 ? (
              result.sistemas.map((sistema, idx) => (
                <span key={idx} className="text-[10px] bg-white border border-[#1A1A1A] px-2 py-0.5 rounded font-mono font-bold text-gray-800 shadow-2xs">
                  {sistema}
                </span>
              ))
            ) : (
              <span className="text-xs text-gray-400 italic">Nenhum software explícito mencionado.</span>
            )}
          </div>
        </div>

        <div className="p-4 bg-emerald-50 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] rounded">
          <span className="text-[10px] font-mono font-bold uppercase text-emerald-800 tracking-wider flex items-center gap-1">
            📦 Entregável Final / Resultado
          </span>
          <p className="text-xs text-gray-800 mt-2 font-medium leading-relaxed">
            {result.entregavelFinal || "Não especificado"}
          </p>
        </div>
      </div>

      {/* 2. Análise de Lacunas (Gap Analysis) */}
      <div className="p-5 bg-rose-50 border-2 border-rose-950 rounded shadow-[4px_4px_0px_0px_rgba(159,18,57,1)] space-y-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="text-rose-800" size={20} />
          <h5 className="text-sm font-black font-mono text-rose-950 uppercase tracking-wide">
            Pontos de Atenção (Análise de Lacunas IA)
          </h5>
        </div>
        <p className="text-[11px] text-rose-900 leading-normal font-medium">
          Identificamos as seguintes lacunas, ambiguidades ou riscos na modelagem do seu fluxo operacional:
        </p>
        <ul className="space-y-1.5 mt-2 text-xs text-rose-950 font-medium font-sans">
          {result.gapAnalysis && result.gapAnalysis.length > 0 ? (
            result.gapAnalysis.map((gap, idx) => (
              <li key={idx} className="flex items-start gap-2 bg-white/60 p-2 rounded border border-rose-200">
                <span className="text-rose-700 font-extrabold select-none">•</span>
                <span>{gap}</span>
              </li>
            ))
          ) : (
            <li className="italic text-gray-500">Nenhum ponto crítico identificado. Fluxo aparentemente redondo!</li>
          )}
        </ul>
      </div>

      {/* 3. Geração Visual (Fluxograma Automático) */}
      <div className="bg-stone-50 border-2 border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] rounded p-5 space-y-4">
        <div className="flex items-center justify-between border-b pb-2">
          <span className="text-xs font-mono font-black text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
            📊 Fluxograma Operacional Automatizado
          </span>
          <span className="text-[10px] font-mono bg-indigo-100 text-indigo-900 border border-indigo-200 px-2.5 py-0.5 rounded font-black uppercase">
            Auto-Gerado por IA
          </span>
        </div>

        {/* Custom Gorgeous Responsive React Flowchart Timeline */}
        <div className="flex flex-col items-center py-6 space-y-4 max-w-lg mx-auto bg-white border border-gray-200 rounded p-4 shadow-sm relative overflow-x-hidden">
          {result.flowchartSteps && result.flowchartSteps.length > 0 ? (
            result.flowchartSteps.map((step, idx) => {
              const isStart = step.type === "start";
              const isEnd = step.type === "end";
              const isDecision = step.type === "decision";
              
              return (
                <div key={step.id} className="w-full flex flex-col items-center relative">
                  {/* Arrow connector from previous */}
                  {idx > 0 && (
                    <div className="h-6 w-0.5 bg-indigo-300 flex items-center justify-center relative -mt-1 mb-2">
                      <div className="absolute -bottom-1 border-t-4 border-t-indigo-500 border-x-4 border-x-transparent w-0 h-0" />
                    </div>
                  )}

                  {/* Node container */}
                  <div className={`w-full max-w-sm p-3.5 border-2 rounded transition-all hover:scale-[1.02] shadow-xs flex items-start gap-3 relative ${
                    isStart ? 'bg-emerald-50 border-emerald-950 text-emerald-950 shadow-[2px_2px_0px_rgba(5,150,105,0.4)]' :
                    isEnd ? 'bg-slate-900 border-slate-950 text-white shadow-[2px_2px_0px_rgba(26,26,26,0.5)]' :
                    isDecision ? 'bg-amber-50 border-amber-950 text-amber-950 shadow-[2px_2px_0px_rgba(217,119,6,0.4)]' :
                    'bg-white border-indigo-950 text-gray-900 shadow-[2px_2px_0px_rgba(79,70,229,0.3)]'
                  }`}>
                    {/* Visual icon badge */}
                    <div className={`w-6 h-6 rounded-full shrink-0 flex items-center justify-center font-mono text-[10px] font-black border ${
                      isStart ? 'bg-emerald-600 border-emerald-800 text-white' :
                      isEnd ? 'bg-indigo-900 border-indigo-950 text-white' :
                      isDecision ? 'bg-amber-500 border-amber-700 text-white' :
                      'bg-indigo-100 border-indigo-300 text-indigo-900'
                    }`}>
                      {isStart ? "▶" : isEnd ? "🏁" : isDecision ? "❓" : idx}
                    </div>

                    {/* Step Content */}
                    <div className="flex-1 min-w-0">
                      <h6 className="text-xs font-extrabold tracking-tight break-words">{step.label}</h6>
                      {(step.actor || step.system) && (
                        <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                          {step.actor && (
                            <span className="text-[8px] bg-stone-100 border border-stone-300 text-stone-800 px-1.5 py-0.5 rounded font-mono font-bold uppercase truncate max-w-[120px]">
                              👥 {step.actor}
                            </span>
                          )}
                          {step.system && (
                            <span className="text-[8px] bg-indigo-50 border border-indigo-200 text-indigo-800 px-1.5 py-0.5 rounded font-mono font-bold uppercase truncate max-w-[120px]">
                              💻 {step.system}
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Decision diamond marker */}
                    {isDecision && (
                      <div className="absolute -right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 bg-amber-500 border border-amber-950 rotate-45" />
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <span className="text-xs text-gray-400 italic">Não foi possível montar os passos sequenciais.</span>
          )}
        </div>

        {/* Mermaid Code Viewer Accordion */}
        <div className="border border-gray-300 rounded overflow-hidden">
          <button
            type="button"
            onClick={() => setShowMermaidCode(!showMermaidCode)}
            className="w-full bg-gray-100 hover:bg-gray-250 p-3 flex items-center justify-between text-xs font-mono font-bold text-gray-700 cursor-pointer border-none outline-none"
          >
            <span className="flex items-center gap-1.5">
              <Code size={14} /> {showMermaidCode ? "Ocultar" : "Ver"} Código Mermaid.js do Fluxograma
            </span>
            <span>{showMermaidCode ? "▲" : "▼"}</span>
          </button>
          
          {showMermaidCode && (
            <div className="p-3 bg-stone-900 text-stone-300 text-[11px] font-mono whitespace-pre overflow-x-auto relative">
              <button
                type="button"
                onClick={handleCopy}
                className="absolute right-2 top-2 bg-stone-800 hover:bg-stone-700 text-stone-300 px-2 py-1 rounded text-[9px] font-mono font-bold border border-stone-700 cursor-pointer"
              >
                {copied ? "Copiado!" : "Copiar"}
              </button>
              {result.mermaidDiagram}
            </div>
          )}
        </div>
      </div>

      {/* 4. ITERATIVE AI REFINEMENT & CLARIFICATION CENTER */}
      <div className="p-5 bg-gradient-to-br from-indigo-50 to-indigo-100 border-2 border-indigo-950 rounded shadow-[4px_4px_0px_0px_rgba(49,46,129,1)] space-y-4">
        <div className="flex items-center gap-2">
          <MessageSquare className="text-indigo-900 animate-bounce" size={20} />
          <h5 className="text-sm font-black font-mono text-indigo-950 uppercase tracking-wide">
            Co-piloto de Refinamento (Iteração Dinâmica)
          </h5>
        </div>
        
        <p className="text-[11px] text-indigo-900 leading-normal font-medium">
          A IA estruturou seu processo, mas podemos deixá-lo ainda mais rico! Responda a uma das perguntas formuladas abaixo ou digite novos detalhes para re-modelar o fluxo instantaneamente:
        </p>

        {/* Dynamic Clarifying Questions (Clickable suggestions) */}
        <div className="space-y-2">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-850 flex items-center gap-1">
            <HelpCircle size={12} /> Perguntas de Clarificação Recomendadas:
          </span>
          <div className="grid grid-cols-1 gap-2">
            {questionsToRender.map((question, qIdx) => (
              <button
                key={qIdx}
                type="button"
                onClick={() => setFeedbackInput(`Sobre "${question}": `)}
                className="text-left text-xs bg-white hover:bg-indigo-50 border border-indigo-200 hover:border-indigo-500 p-2.5 rounded transition-all flex items-start gap-2 text-indigo-950 font-medium cursor-pointer shadow-2xs"
              >
                <span className="text-indigo-600 font-extrabold select-none shrink-0 font-mono">#{qIdx+1}</span>
                <span>{question}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Chat History Log */}
        {chatHistory.length > 0 && (
          <div className="bg-white/80 border border-indigo-250 rounded p-3 max-h-[160px] overflow-y-auto space-y-2.5 shadow-inner">
            <span className="text-[9px] font-mono font-bold text-indigo-800 uppercase block tracking-wider">Histórico de Ajustes</span>
            {chatHistory.map((msg, mIdx) => (
              <div key={mIdx} className="text-xs space-y-0.5">
                <span className={`font-mono text-[9px] font-bold block ${msg.role === 'user' ? 'text-indigo-700' : 'text-emerald-700'}`}>
                  {msg.role === 'user' ? '👤 Seu Ajuste:' : '✨ Co-piloto:'}
                </span>
                <p className="text-gray-800 leading-relaxed pl-1.5 border-l-2 border-indigo-200">{msg.content}</p>
              </div>
            ))}
          </div>
        )}

        {/* Input area */}
        <div className="space-y-2">
          <textarea
            value={feedbackInput}
            onChange={(e) => setFeedbackInput(e.target.value)}
            placeholder="Ex: No passo 2, quem faz é a equipe fiscal pelo sistema SAP. Ou digite sua resposta para uma das perguntas de clarificação acima..."
            className="w-full text-xs bg-white border-2 border-indigo-950 p-3 rounded font-sans focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs leading-relaxed"
            rows={3}
            disabled={isRefining}
          />

          {errorMessage && (
            <p className="text-xs text-rose-600 font-semibold">{errorMessage}</p>
          )}

          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => handleRefine()}
              disabled={isRefining || !feedbackInput.trim()}
              className="bg-indigo-900 hover:bg-indigo-950 text-white font-mono font-black uppercase text-[11px] px-5 py-2.5 rounded shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] border-2 border-[#1A1A1A] transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRefining ? (
                <>
                  <RefreshCw size={12} className="animate-spin" /> Atualizando Mapeamento...
                </>
              ) : (
                <>
                  <Sparkles size={12} /> Atualizar Modelagem ✨
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface GuidedProcessDescriptionProps {
  selectedProjectId: string | null;
  selectedCompanyId: string;
  companies: Company[];
  lockedCompanyName: string | null;
  onSuccess: (message: string) => void;
  clientPortalRequests: any[];
  setClientPortalRequests: React.Dispatch<React.SetStateAction<any[]>>;
  useGuidedScript: boolean;
  setUseGuidedScript: (val: boolean) => void;
  projects?: any[];
  onProjectsUpdate?: (projects: any[]) => void;
}

export default function GuidedProcessDescription({
  selectedProjectId,
  selectedCompanyId,
  companies,
  lockedCompanyName,
  onSuccess,
  clientPortalRequests,
  setClientPortalRequests,
  useGuidedScript,
  setUseGuidedScript,
  projects,
  onProjectsUpdate
}: GuidedProcessDescriptionProps) {
  // Solicitante Details
  const [guidedContactName, setGuidedContactName] = useState("");
  const [guidedContactEmail, setGuidedContactEmail] = useState("");
  const [guidedContactPhone, setGuidedContactPhone] = useState("");
  const [guidedProcessName, setGuidedProcessName] = useState("");

  // Guided Steps Answers
  const [guidedGatilho, setGuidedGatilho] = useState("");
  const [guidedFluxo, setGuidedFluxo] = useState("");
  const [guidedDesvios, setGuidedDesvios] = useState("");
  const [guidedFerramentas, setGuidedFerramentas] = useState("");
  const [guidedEntrega, setGuidedEntrega] = useState("");
  const [guidedRegras, setGuidedRegras] = useState("");

  // Wizard state: 0 = contact details, 1-6 = script questions, 7 = review & AI preview
  const [wizardStep, setWizardStep] = useState(0);
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
  const [previewCompiledText, setPreviewCompiledText] = useState("");
  const [parsedAnalysisResult, setParsedAnalysisResult] = useState<any>(null);
  const [isSubmittingGuided, setIsSubmittingGuided] = useState(false);

  const [parsedProcessResult, setParsedProcessResult] = useState<ParseProcessResult | null>(null);
  const [isParsingProcess, setIsParsingProcess] = useState(false);

  // Free text fallback if toggle is turned off
  const [freeTextName, setFreeTextName] = useState("");
  const [freeTextValue, setFreeTextValue] = useState("");

  // State for the Linking Modal
  const [isLinkingModalOpen, setIsLinkingModalOpen] = useState(false);
  const [linkingCompanyId, setLinkingCompanyId] = useState(selectedCompanyId || "");
  const [linkingProjectName, setLinkingProjectName] = useState("");
  const [linkingProcessName, setLinkingProcessName] = useState("");
  const [linkingProjectId, setLinkingProjectId] = useState("");
  const [isCreatingNewProject, setIsCreatingNewProject] = useState(false);
  const [linkingMode, setLinkingMode] = useState<"guided" | "freetext">("guided");

  const handleCompanyChange = (compId: string) => {
    setLinkingCompanyId(compId);
    const activeProjs = projects || CompanyProjectRepository.getProjects() || [];
    const filteredProjs = activeProjs.filter((p: any) => p.companyId === compId);
    if (filteredProjs.length > 0) {
      setLinkingProjectId(filteredProjs[0].id);
      setLinkingProjectName(filteredProjs[0].name);
      setIsCreatingNewProject(false);
    } else {
      setLinkingProjectId("new");
      setLinkingProjectName("");
      setIsCreatingNewProject(true);
    }
  };

  // Intercept handlers for modal trigger
  const handleOpenLinkModalGuided = () => {
    if (!guidedContactName || !guidedProcessName) {
      alert("Por favor, preencha as informações do solicitante e o nome do processo.");
      return;
    }
    setLinkingMode("guided");
    setLinkingProcessName(guidedProcessName.trim());
    
    const initialCompId = selectedCompanyId || (companies && companies.length > 0 ? companies[0].id : "");
    setLinkingCompanyId(initialCompId);
    
    const activeProjs = projects || CompanyProjectRepository.getProjects() || [];
    const filteredProjs = activeProjs.filter((p: any) => p.companyId === initialCompId);
    
    const matchedProj = filteredProjs.find(p => p.id === selectedProjectId);
    if (matchedProj) {
      setLinkingProjectId(matchedProj.id);
      setLinkingProjectName(matchedProj.name);
      setIsCreatingNewProject(false);
    } else if (filteredProjs.length > 0) {
      setLinkingProjectId(filteredProjs[0].id);
      setLinkingProjectName(filteredProjs[0].name);
      setIsCreatingNewProject(false);
    } else {
      setLinkingProjectId("new");
      setLinkingProjectName("");
      setIsCreatingNewProject(true);
    }
    
    setIsLinkingModalOpen(true);
  };

  const handleOpenLinkModalFreeText = () => {
    if (!freeTextName || !freeTextValue) {
      alert("Por favor, informe seu nome e digite a descrição do processo.");
      return;
    }
    setLinkingMode("freetext");
    setLinkingProcessName("Mapeamento Texto Livre");
    
    const initialCompId = selectedCompanyId || (companies && companies.length > 0 ? companies[0].id : "");
    setLinkingCompanyId(initialCompId);
    
    const activeProjs = projects || CompanyProjectRepository.getProjects() || [];
    const filteredProjs = activeProjs.filter((p: any) => p.companyId === initialCompId);
    
    const matchedProj = filteredProjs.find(p => p.id === selectedProjectId);
    if (matchedProj) {
      setLinkingProjectId(matchedProj.id);
      setLinkingProjectName(matchedProj.name);
      setIsCreatingNewProject(false);
    } else if (filteredProjs.length > 0) {
      setLinkingProjectId(filteredProjs[0].id);
      setLinkingProjectName(filteredProjs[0].name);
      setIsCreatingNewProject(false);
    } else {
      setLinkingProjectId("new");
      setLinkingProjectName("");
      setIsCreatingNewProject(true);
    }
    
    setIsLinkingModalOpen(true);
  };

  // Helper to compile final guided message string
  const getCompiledWording = () => {
    const greeting = `Olá! Para criarmos um padrão perfeito do processo "${guidedProcessName || '[NOME DO PROCESSO]'}", preciso que você o descreva com o máximo de detalhes possível. Não se preocupe com termos técnicos. Apenas responda às perguntas abaixo pensando no seu dia a dia real:`;
    
    const block1 = `1. O Ponto de Partida (Gatilho)
Como esse processo começa? (Ex: Você recebe um e-mail? O cliente liga? Um sistema emite um alerta?)
Exatamente qual informação ou documento chega até você para o trabalho começar?
R: ${guidedGatilho || "Não preenchido."}`;

    const block2 = `2. O Passo a Passo Detalhado (O Fluxo)
Descreva a sequência de ações. Use o modelo: Quem (Cargo) faz O que e Onde (Sistema/Papel).
Exemplo: "Eu (Analista) abro o sistema X, clico em 'Novo Pedido' e digito o CPF do cliente."
Escreva todas as etapas, desde a primeira ação até a conclusão.
R: ${guidedFluxo || "Não preenchido."}`;

    const block3 = `3. Os Desvios e Tomadas de Decisão (E se der errado?)
Quais decisões você precisa tomar no meio do caminho? (Ex: "Eu preciso checar se o valor é maior que R$ 5.000")
O que acontece se a resposta for SIM? Para onde o processo vai?
O que acontece se a resposta for NÃO ou se houver um erro? Quem você aciona?
R: ${guidedDesvios || "Não preenchido."}`;

    const block4 = `4. Ferramentas e Sistemas
Quais sistemas, planilhas, sites ou blocos de papel você usa durante esse processo? (Cite os nomes das ferramentas).
R: ${guidedFerramentas || "Não preenchido."}`;

    const block5 = `5. O Ponto Final (A Entrega)
Como você sabe que a sua parte terminou?
O que você gera no final e para quem você envia? (Ex: Um relatório PDF enviado por e-mail para o gerente; Um produto embalado na esteira).
R: ${guidedEntrega || "Não preenchido."}`;

    const block6 = `6. Regras, Prazos e Gargalos
Existe algum prazo obrigatório a ser cumprido? (Ex: Deve ser feito em até 2 horas).
Qual é o erro ou problema mais comum que costuma travar esse processo?
R: ${guidedRegras || "Não preenchido."}`;

    return `${greeting}

==================================================
RELATO ESTRUTURADO DE PROCESSO: ${(guidedProcessName || 'MAPEAMENTO').toUpperCase()}
==================================================
Solicitante: ${guidedContactName || "Não especificado"}
E-mail: ${guidedContactEmail || "Não especificado"}
Telefone: ${guidedContactPhone || "Não especificado"}

${block1}

${block2}

${block3}

${block4}

${block5}

${block6}`;
  };

  const handleGenerateGuidedPreview = async () => {
    setIsGeneratingPreview(true);
    const compiled = getCompiledWording();
    setPreviewCompiledText(compiled);

    try {
      // Call our robust process parser to extract actors, tools, gatilho, and Mermaid
      const parsedRes = await AiService.parseProcess(compiled);
      setParsedProcessResult(parsedRes);

      // Map parsed result into the existing parsedAnalysisResult to ensure everything renders correctly
      const mappedAnalysis = {
        sipoc: {
          Suppliers: parsedRes.atores && parsedRes.atores.length > 0 ? parsedRes.atores : ["Cliente"],
          Inputs: [parsedRes.gatilho || "Insumo Inicial"],
          Process: guidedProcessName || "Fluxo Geral",
          Outputs: [parsedRes.entregavelFinal || "Resultado Final"],
          Customers: ["Próxima etapa"]
        },
        metrics: {
          confidenceScore: 95,
          reworkEst: parsedRes.gapAnalysis && parsedRes.gapAnalysis.length > 0 ? Math.min(30, parsedRes.gapAnalysis.length * 5) : 5,
          tempoMedioCiclo: "A calcular sob demanda"
        },
        steps: parsedRes.flowchartSteps ? parsedRes.flowchartSteps.map(s => s.label) : []
      };
      setParsedAnalysisResult(mappedAnalysis);

      // Now we can optionally call suggestStructure to merge average cycle times if needed, or stick to this more structured result
      try {
        const promptToParse = `Setor de atuação com o relato do processo "${guidedProcessName || "Mapeamento Guiado"}": ${compiled}`;
        const suggestRes = await AiService.suggestStructure(promptToParse);
        if (suggestRes && suggestRes.sipoc && suggestRes.steps) {
          setParsedAnalysisResult({
            ...mappedAnalysis,
            metrics: {
              ...mappedAnalysis.metrics,
              tempoMedioCiclo: `${suggestRes.steps.reduce((acc, s) => acc + s.processingTime, 0)} minutos`
            }
          });
        }
      } catch (innerErr) {
        console.warn("Could not get cycle time from suggestStructure:", innerErr);
      }

    } catch (e) {
      console.error("[Portal AI Parser] falhou ao gerar passos estruturados:", e);
      // Fallback
      setParsedProcessResult(null);
      // Run old suggestStructure
      try {
        const promptToParse = `Setor de atuação com o relato do processo "${guidedProcessName || "Mapeamento Guiado"}": ${compiled}`;
        const result = await AiService.suggestStructure(promptToParse);

        if (result && result.sipoc && result.steps) {
          const analysis = {
            sipoc: {
              Suppliers: result.sipoc.suppliers.split(",").map(s => s.trim()),
              Inputs: result.sipoc.inputs.split(",").map(i => i.trim()),
              Process: result.sipoc.processDescription || guidedProcessName || "Fluxo Geral",
              Outputs: result.sipoc.outputs.split(",").map(o => o.trim()),
              Customers: result.sipoc.customers.split(",").map(c => c.trim())
            },
            metrics: {
              confidenceScore: 94,
              reworkEst: result.steps[0] ? Math.round(100 - (result.steps[0].yieldRate * 100)) : 15,
              tempoMedioCiclo: `${result.steps.reduce((acc, s) => acc + s.processingTime, 0)} minutos`
            },
            steps: result.steps.map(s => s.name)
          };
          setParsedAnalysisResult(analysis);
        }
      } catch (errFallback) {
        const fallbackSteps: string[] = [];
        if (guidedGatilho) fallbackSteps.push("Recebimento do Gatilho");
        if (guidedFluxo) fallbackSteps.push("Execução das Etapas Básicas");
        if (guidedDesvios) fallbackSteps.push("Tratamento de Exceções");
        if (guidedFerramentas) fallbackSteps.push("Integração de Sistemas");
        if (guidedEntrega) fallbackSteps.push("Entrega Final do Produto/Relatório");

        if (fallbackSteps.length === 0) {
          fallbackSteps.push("Início do Fluxo", "Processamento Operacional", "Verificação de Qualidade", "Fechamento");
        }

        setParsedAnalysisResult({
          sipoc: {
            Suppliers: ["Fornecedores da " + (guidedProcessName || "Operação")],
            Inputs: ["Insumos e Informações iniciais"],
            Process: guidedProcessName || "Fluxo Geral",
            Outputs: ["Entrega e Resultados"],
            Customers: ["Clientes / Próximo setor da cadeia"]
          },
          metrics: {
            confidenceScore: 82,
            reworkEst: 18,
            tempoMedioCiclo: "A calcular sob demanda"
          },
          steps: fallbackSteps
        });
      }
    } finally {
      setIsGeneratingPreview(false);
      setWizardStep(7); // To Preview Step
    }
  };

  const handleSubmitGuidedRequest = async (
    finalProjId: string, 
    finalProjName: string, 
    finalProcName: string,
    finalCompId: string,
    finalCompName: string
  ) => {
    setIsSubmittingGuided(true);

    const compiledTextFinal = previewCompiledText || getCompiledWording();
    const reqId = "req_" + Date.now().toString();
    const solId = "sol_" + Date.now().toString();
    const clientCompany = finalCompName;

    const newReq = {
      id: reqId,
      clientName: guidedContactName.trim(),
      text: compiledTextFinal,
      status: "Em Análise",
      timestamp: new Date().toISOString(),
      projectId: finalProjId,
      projectName: finalProjName,
      processName: finalProcName,
      companyId: finalCompId,
      companyName: finalCompName
    };

    // Specialist's core solicitation structure
    const newSolicitation = {
      id: solId,
      clientCompany: finalCompName,
      companyId: finalCompId,
      clientName: guidedContactName.trim(),
      clientEmail: (guidedContactEmail || "cliente@sandbox.com").trim(),
      contactPhone: (guidedContactPhone || "").trim(),
      processName: finalProcName.trim(),
      projectName: finalProjName.trim(),
      projectId: finalProjId,
      projectGoal: "Análise estratégica de gargalo via Roteiro Guiado",
      urgency: "Média",
      rawText: compiledTextFinal,
      status: "Pendente",
      createdAt: new Date().toISOString(),
      analysisResult: parsedAnalysisResult || {
        sipoc: {
          Suppliers: ["Fornecedores"],
          Inputs: ["Insumos"],
          Process: finalProcName.trim(),
          Outputs: ["Resultados"],
          Customers: ["Clientes"]
        },
        metrics: {
          confidenceScore: 90,
          reworkEst: 15,
          tempoMedioCiclo: "A calcular"
        },
        steps: []
      }
    };

    // Save as client request (Firestore vs. localStorage)
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    if (urlToken) {
      try {
        const docId = urlToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
        if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
          console.log("[Portal] Modo de Treinamento - ignorando escrita síncrona Firestore.");
          setClientPortalRequests((prev) => [...prev, newReq]);
        } else {
          await updateDoc(doc(db, "shared_portals", docId), {
            requests: arrayUnion(newReq)
          });
          setClientPortalRequests((prev) => [...prev, newReq]);
        }
      } catch (e) {
        console.error("[Portal] Erro ao gravar solicitação no Firestore:", e);
      }
    } else {
      const localReqs = JSON.parse(localStorage.getItem("lss_local_portal_requests") || "[]");
      const updated = [...localReqs, newReq];
      localStorage.setItem("lss_local_portal_requests", JSON.stringify(updated));
      setClientPortalRequests(updated);
    }

    // Always append directly to the specialist queue
    try {
      const existingSols = JSON.parse(localStorage.getItem("lss_project_solicitations") || "[]");
      localStorage.setItem("lss_project_solicitations", JSON.stringify([...existingSols, newSolicitation]));
      console.log("[Portal] Solicitação inserida com sucesso na fila do especialista.");
    } catch (e) {
      console.error("[Portal] Erro ao gravar na fila do especialista:", e);
    }

    // --- SAVE TO SELECTED PROJECT DATASTORE AS AN IMPROVEMENT DRAFT ---
    if (finalProjId) {
      try {
        const store = CompanyProjectRepository.getProjectDataStore();
        const currentData = store[finalProjId] || {};
        const currentDrafts = currentData.processDrafts || [];

        const newDraft = {
          id: "draft_" + Date.now().toString(),
          processName: finalProcName.trim(),
          compiledText: compiledTextFinal,
          createdAt: new Date().toISOString(),
          status: "Rascunho",
          analysisResult: parsedAnalysisResult || null,
          createdBy: guidedContactName.trim()
        };

        const updatedData = {
          ...currentData,
          processDrafts: [...currentDrafts, newDraft]
        };

        const updatedStore = {
          ...store,
          [finalProjId]: updatedData
        };

        CompanyProjectRepository.saveProjectDataStore(updatedStore);
        console.log("[Portal] Rascunho de melhoria salvo com sucesso no Workspace do projeto via repositório!");
      } catch (e) {
        console.error("[Portal] Falha ao salvar rascunho de melhoria no repositório de projetos:", e);
      }
    }

    onSuccess("Seu relato de processo foi validado e enviado com sucesso! Ele foi adicionado na fila de auditoria do especialista e salvo como rascunho de melhoria no projeto selecionado.");
    
    // Clear inputs and reset
    setGuidedGatilho("");
    setGuidedFluxo("");
    setGuidedDesvios("");
    setGuidedFerramentas("");
    setGuidedEntrega("");
    setGuidedRegras("");
    setGuidedProcessName("");
    setWizardStep(0);
    setIsSubmittingGuided(false);
  };

  const handleFreeTextAnalysis = async () => {
    if (!freeTextValue || freeTextValue.trim().length === 0) {
      alert("Por favor, descreva seu processo em texto livre antes de analisar.");
      return;
    }

    setIsParsingProcess(true);
    try {
      const parsedRes = await AiService.parseProcess(freeTextValue);
      setParsedProcessResult(parsedRes);

      // Map parsed result into the existing parsedAnalysisResult so that we sync
      const mappedAnalysis = {
        sipoc: {
          Suppliers: parsedRes.atores && parsedRes.atores.length > 0 ? parsedRes.atores : ["Cliente"],
          Inputs: [parsedRes.gatilho || "Insumo Inicial"],
          Process: "Mapeamento Manual",
          Outputs: [parsedRes.entregavelFinal || "Resultado Final"],
          Customers: ["Próxima etapa"]
        },
        metrics: {
          confidenceScore: 92,
          reworkEst: parsedRes.gapAnalysis && parsedRes.gapAnalysis.length > 0 ? Math.min(30, parsedRes.gapAnalysis.length * 5) : 5,
          tempoMedioCiclo: "A calcular sob demanda"
        },
        steps: parsedRes.flowchartSteps ? parsedRes.flowchartSteps.map(s => s.label) : []
      };
      setParsedAnalysisResult(mappedAnalysis);
    } catch (error: any) {
      console.error("Erro ao analisar texto livre:", error);
      alert("Falha ao analisar o processo com IA: " + error.message);
    } finally {
      setIsParsingProcess(false);
    }
  };

  const handleSubmitFreeText = async (
    finalProjId: string, 
    finalProjName: string, 
    finalProcName: string,
    finalCompId: string,
    finalCompName: string
  ) => {
    setIsSubmittingGuided(true);

    const reqId = "req_" + Date.now().toString();
    const solId = "sol_" + Date.now().toString();
    const clientCompany = finalCompName;

    const newReq = {
      id: reqId,
      clientName: freeTextName.trim(),
      text: freeTextValue.trim(),
      status: "Em Análise",
      timestamp: new Date().toISOString(),
      projectId: finalProjId,
      projectName: finalProjName,
      processName: finalProcName,
      companyId: finalCompId,
      companyName: finalCompName
    };

    const newSolicitation = {
      id: solId,
      clientCompany: finalCompName,
      companyId: finalCompId,
      clientName: freeTextName.trim(),
      clientEmail: "cliente@manual.com",
      contactPhone: "",
      processName: finalProcName.trim(),
      projectName: finalProjName.trim(),
      projectId: finalProjId,
      projectGoal: "Fluxo sob demanda",
      urgency: "Média",
      rawText: freeTextValue.trim(),
      status: "Pendente",
      createdAt: new Date().toISOString(),
      analysisResult: parsedAnalysisResult || {
        sipoc: {
          Suppliers: ["Fornecedores"],
          Inputs: ["Dados/Entrada"],
          Process: finalProcName.trim(),
          Outputs: ["Resultados"],
          Customers: ["Clientes"]
        },
        metrics: {
          confidenceScore: 78,
          reworkEst: 15,
          tempoMedioCiclo: "A calcular"
        },
        steps: ["Receber Solicitação Manual", "Mapeamento", "Aprovação do Especialista"]
      }
    };

    // Save client request
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    if (urlToken) {
      try {
        const docId = urlToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
        if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
          setClientPortalRequests((prev) => [...prev, newReq]);
        } else {
          await updateDoc(doc(db, "shared_portals", docId), {
            requests: arrayUnion(newReq)
          });
          setClientPortalRequests((prev) => [...prev, newReq]);
        }
      } catch (e) {
        console.error("[Portal] Erro registrando rascunho de texto livre:", e);
      }
    } else {
      const localReqs = JSON.parse(localStorage.getItem("lss_local_portal_requests") || "[]");
      const updated = [...localReqs, newReq];
      localStorage.setItem("lss_local_portal_requests", JSON.stringify(updated));
      setClientPortalRequests(updated);
    }

    try {
      const existingSols = JSON.parse(localStorage.getItem("lss_project_solicitations") || "[]");
      localStorage.setItem("lss_project_solicitations", JSON.stringify([...existingSols, newSolicitation]));
    } catch (e) {
      console.error("[Portal Error] Sync manual solicitation:", e);
    }

    // Save as rascunho to selected project datastore too!
    if (finalProjId) {
      try {
        const store = CompanyProjectRepository.getProjectDataStore();
        const currentData = store[finalProjId] || {};
        const currentDrafts = currentData.processDrafts || [];

        const newDraft = {
          id: "draft_" + Date.now().toString(),
          processName: finalProcName.trim(),
          compiledText: freeTextValue.trim(),
          createdAt: new Date().toISOString(),
          status: "Rascunho",
          analysisResult: parsedAnalysisResult || null,
          createdBy: freeTextName.trim()
        };

        const updatedData = {
          ...currentData,
          processDrafts: [...currentDrafts, newDraft]
        };

        const updatedStore = {
          ...store,
          [finalProjId]: updatedData
        };

        CompanyProjectRepository.saveProjectDataStore(updatedStore);
        console.log("[Portal] Rascunho de texto livre salvo.");
      } catch (e) {
        console.error("[Portal Error] Saving processDraft manual:", e);
      }
    }

    onSuccess("Sua demanda foi enviada com sucesso para nossos Especialistas em Processos e registrada como rascunho de melhoria no projeto!");
    setFreeTextValue("");
    setIsSubmittingGuided(false);
  };

  return (
    <div id="guided-process-description-wrapper" className="bg-white p-6 border-2 border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b pb-4 mb-6 gap-4 font-sans">
        <div className="text-left">
          <h3 className="text-xl font-bold font-serif text-gray-900 flex items-center gap-2">
            <Layers className="text-indigo-900" size={20} />
            Mapeador de Processos E3I
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            Preencha o formulário para descrever detalhadamente seu fluxo de trabalho e receber um diagnóstico técnico instantâneo por IA antes do envio.
          </p>
        </div>
        
        {/* Toggle between structured form and manual text */}
        <div className="flex bg-[#F5F2ED] p-1 border border-gray-300 rounded gap-1 self-start md:self-auto shadow-inner">
          <button
            id="toggle-guided-script-btn"
            type="button"
            onClick={() => { setUseGuidedScript(true); }}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-all cursor-pointer rounded flex items-center gap-1 ${useGuidedScript ? 'bg-indigo-950 text-white shadow' : 'bg-transparent text-gray-700 hover:bg-gray-200'}`}
          >
            📋 Formulário Estruturado
          </button>
          <button
            id="toggle-free-speech-btn"
            type="button"
            onClick={() => { setUseGuidedScript(false); }}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-all cursor-pointer rounded flex items-center gap-1 ${!useGuidedScript ? 'bg-indigo-950 text-white shadow' : 'bg-transparent text-gray-700 hover:bg-gray-200'}`}
          >
            📝 Texto Livre
          </button>
        </div>
      </div>

      {useGuidedScript ? (
        // --- 6-STEP GUIDED WIZARD + DYNAMIC LSS PREVIEW BOARD ---
        <div className="space-y-6 text-left">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* COLUMN 1: The Interactive Step Container (7 cols) */}
            <div className="lg:col-span-7 bg-white border border-gray-200 p-5 rounded-md space-y-6 shadow-xs">
              
              {/* Progressive Stepper Bar */}
              <div className="flex items-center justify-between gap-1.5 border-b pb-4 overflow-x-auto scrollbar-hide">
                {[
                  { label: "Início", desc: "Identificação" },
                  { label: "1. Gatilho", desc: "Como começa" },
                  { label: "2. Fluxo", desc: "Etapas" },
                  { label: "3. Decisões", desc: "Regras" },
                  { label: "4. Sistemas", desc: "Ferramentas" },
                  { label: "5. Entrega", desc: "Como termina" },
                  { label: "6. Gargalos", desc: "SLAs" },
                  { label: "Análise IA", desc: "Laudo" }
                ].map((step, idx) => {
                  const isActive = wizardStep === idx;
                  const isCompleted = wizardStep > idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        // Allow navigation if step 0 has been filled
                        if (idx === 0 || (guidedContactName && guidedProcessName)) {
                          setWizardStep(idx);
                        } else {
                          alert("Preencha primeiro seu Nome e o Nome do Processo na etapa inicial!");
                        }
                      }}
                      className="flex flex-col items-center gap-1 shrink-0 group cursor-pointer focus:outline-none"
                    >
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center font-mono text-[10px] font-bold border transition-all ${
                        isActive ? 'bg-indigo-950 text-white border-indigo-950 font-bold scale-110 shadow-xs' :
                        isCompleted ? 'bg-emerald-600 text-white border-emerald-600' :
                        'bg-white text-gray-400 border-gray-300 hover:border-gray-500'
                      }`}>
                        {isCompleted ? "✓" : idx}
                      </span>
                      <span className={`text-[9px] font-mono leading-none tracking-tight transition-all hidden sm:inline ${
                        isActive ? 'text-indigo-900 font-bold' :
                        isCompleted ? 'text-emerald-700' :
                        'text-gray-405'
                      }`}>
                        {step.label}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Step Forms */}
              {wizardStep === 0 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-b pb-3 text-left">
                    <span className="text-[9px] font-mono font-bold uppercase bg-indigo-100 text-indigo-800 px-2.5 py-0.5 rounded">Identificação Operacional</span>
                    <h4 className="text-sm font-bold text-gray-900 font-serif mt-1.5">Quem está descrevendo este processo e qual é o nome do fluxo?</h4>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1">
                        <User size={12} /> Seu Nome Completo:
                      </label>
                      <input
                        id="guided-contact-name-input"
                        type="text"
                        value={guidedContactName}
                        onChange={e => setGuidedContactName(e.target.value)}
                        placeholder="Ex: Carlos Alberto Miranda"
                        className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans shadow-2xs"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1">
                          <Mail size={12} /> E-mail Corporativo:
                        </label>
                        <input
                          id="guided-contact-email-input"
                          type="email"
                          value={guidedContactEmail}
                          onChange={e => setGuidedContactEmail(e.target.value)}
                          placeholder="Ex: carlos@empresa.com"
                          className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans shadow-2xs"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1">
                          <Phone size={12} /> Telefone / WhatsApp:
                        </label>
                        <input
                          id="guided-contact-phone-input"
                          type="tel"
                          value={guidedContactPhone}
                          onChange={e => setGuidedContactPhone(e.target.value)}
                          placeholder="Ex: (11) 98888-7777"
                          className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans shadow-2xs"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1">
                        <Settings size={12} className="text-indigo-700" /> Nome do Processo Comercial / Operacional:
                      </label>
                      <input
                        id="guided-process-name-input"
                        type="text"
                        value={guidedProcessName}
                        onChange={e => setGuidedProcessName(e.target.value)}
                        placeholder="Ex: Faturamento de Notas Fiscais, Solicitação de Reembolso..."
                        className="w-full border-2 border-indigo-150 p-2.5 text-xs font-bold rounded bg-indigo-50/20 focus:border-indigo-600 outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-4 flex justify-end">
                    <button
                      id="guided-step-0-next-btn"
                      type="button"
                      onClick={() => {
                        if (!guidedContactName || !guidedProcessName) {
                          alert("Por favor, preencha seu nome e o nome do processo para iniciar!");
                          return;
                        }
                        setWizardStep(1);
                      }}
                      className="bg-indigo-950 hover:bg-slate-900 text-white text-xs font-mono font-bold uppercase py-2.5 px-5 cursor-pointer rounded flex items-center gap-1.5 shadow transition-all hover:translate-x-0.5"
                    >
                      Iniciar Descrição <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 1 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-amber-500 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-amber-700 font-bold uppercase tracking-wider block">Etapa 1 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">1. O Ponto de Partida (Gatilho)</h4>
                    <p className="text-xs text-gray-650 leading-normal">Como esse processo começa? Qual documento, e-mail ou alerta eletrônico dá início de fato às atividades cotidianas?</p>
                  </div>
                  
                  <textarea
                    id="guided-step-1-textarea"
                    value={guidedGatilho}
                    onChange={e => setGuidedGatilho(e.target.value)}
                    placeholder="Ex: O cliente envia uma folha física de alta médica ou um e-mail de faturamento com anexo..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-2">
                    <button id="guided-step-1-back-btn" type="button" onClick={() => setWizardStep(0)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                    <button 
                      id="guided-step-1-next-btn"
                      type="button" 
                      onClick={() => setWizardStep(2)} 
                      className="bg-indigo-950 hover:bg-indigo-900 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1 shadow"
                    >
                      Próximo <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 2 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-indigo-600 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-indigo-700 font-bold uppercase tracking-wider block">Etapa 2 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">2. O Passo a Passo Detalhado (O Fluxo)</h4>
                    <p className="text-xs text-gray-650 leading-normal">Descreva as tarefas diárias em ordem cronológica. Pense no formato: "Quem faz", "O que faz" e "Onde registra".</p>
                  </div>
                  
                  <textarea
                    id="guided-step-2-textarea"
                    value={guidedFluxo}
                    onChange={e => setGuidedFluxo(e.target.value)}
                    placeholder="Ex: &#10;1. Eu abro o sistema e preencho a ficha cadastral do cliente.&#10;2. Envio os lotes de boletos para homologação financeira..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-2">
                    <button id="guided-step-2-back-btn" type="button" onClick={() => setWizardStep(1)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                    <button 
                      id="guided-step-2-next-btn"
                      type="button" 
                      onClick={() => setWizardStep(3)} 
                      className="bg-indigo-950 hover:bg-indigo-900 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1 shadow"
                    >
                      Próximo <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-rose-500 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-rose-700 font-bold uppercase tracking-wider block">Etapa 3 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">3. Os Desvios e Tomadas de Decisão</h4>
                    <p className="text-xs text-gray-650 leading-normal">Quais decisões você toma no meio do caminho? O que acontece quando algo falha ou necessita aprovação de um superior?</p>
                  </div>
                  
                  <textarea
                    id="guided-step-3-textarea"
                    value={guidedDesvios}
                    onChange={e => setGuidedDesvios(e.target.value)}
                    placeholder="Ex: Se o valor exceder R$ 2.000,00, encaminho por e-mail para autorização do gerente de contas. Se houver erro de digitação, reinicio..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-2">
                    <button id="guided-step-3-back-btn" type="button" onClick={() => setWizardStep(2)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                    <button 
                      id="guided-step-3-next-btn"
                      type="button" 
                      onClick={() => setWizardStep(4)} 
                      className="bg-indigo-950 hover:bg-indigo-900 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1 shadow"
                    >
                      Próximo <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 4 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-sky-500 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-sky-700 font-bold uppercase tracking-wider block">Etapa 4 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">4. Sistemas, Planilhas e Ferramentas</h4>
                    <p className="text-xs text-gray-650 leading-normal">Quais softwares, planilhas Excel, pastas compartilhadas em rede ou blocos manuais de papel você usa?</p>
                  </div>
                  
                  <textarea
                    id="guided-step-4-textarea"
                    value={guidedFerramentas}
                    onChange={e => setGuidedFerramentas(e.target.value)}
                    placeholder="Ex: ERP SAP, Google Sheets, Outlook Corporativo, rascunhos de papel no caderno de anotações diárias..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-2">
                    <button id="guided-step-4-back-btn" type="button" onClick={() => setWizardStep(3)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                    <button 
                      id="guided-step-4-next-btn"
                      type="button" 
                      onClick={() => setWizardStep(5)} 
                      className="bg-indigo-950 hover:bg-indigo-900 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1 shadow"
                    >
                      Próximo <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 5 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-emerald-500 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-emerald-700 font-bold uppercase tracking-wider block">Etapa 5 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">5. O Ponto Final (A Entrega)</h4>
                    <p className="text-xs text-gray-650 leading-normal">Como e quando o processo é concluído? Qual arquivo ou produto final é de fato entregue ou despachado?</p>
                  </div>
                  
                  <textarea
                    id="guided-step-5-textarea"
                    value={guidedEntrega}
                    onChange={e => setGuidedEntrega(e.target.value)}
                    placeholder="Ex: O arquivo de lote de liquidação de nota fiscal emitido é anexado no sistema e enviado à Tesouraria Central..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-2">
                    <button id="guided-step-5-back-btn" type="button" onClick={() => setWizardStep(4)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                    <button 
                      id="guided-step-5-next-btn"
                      type="button" 
                      onClick={() => setWizardStep(6)} 
                      className="bg-indigo-950 hover:bg-indigo-900 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1 shadow"
                    >
                      Próximo <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {wizardStep === 6 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-l-4 border-purple-500 pl-3.5 space-y-1">
                    <span className="text-[9px] font-mono text-purple-700 font-bold uppercase tracking-wider block">Etapa 6 de 6</span>
                    <h4 className="text-sm font-semibold text-gray-950 font-serif">6. Prazos e Gargalos Operacionais</h4>
                    <p className="text-xs text-gray-600 leading-normal">Quais são os acordos de prazos acordados (SLAs)? Qual o problema cotidiano que costuma causar gargalo e retrabalho?</p>
                  </div>
                  
                  <textarea
                    id="guided-step-6-textarea"
                    value={guidedRegras}
                    onChange={e => setGuidedRegras(e.target.value)}
                    placeholder="Ex: SLA limite de 48 horas corporativas. Mais de 20% das vezes deparamos com dados de faturamento cadastrados errados..."
                    className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 bg-white shadow-inner font-sans outline-none"
                  />

                  <div className="flex justify-between items-center pt-4 border-t flex-wrap gap-2">
                    <button id="guided-step-6-back-btn" type="button" onClick={() => setWizardStep(5)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-3 cursor-pointer">Voltar</button>
                    
                    <div className="flex gap-2">
                      <button 
                        id="guided-step-6-preview-btn"
                        type="button" 
                        onClick={handleGenerateGuidedPreview}
                        disabled={isGeneratingPreview}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-mono font-bold uppercase py-2.5 px-6 cursor-pointer rounded flex items-center gap-1.5 shadow transition-all hover:translate-y-0.5"
                      >
                        {isGeneratingPreview ? (
                          <>
                            <RefreshCw size={14} className="animate-spin" /> Processando Prévia...
                          </>
                        ) : (
                          <>
                            <Sparkles size={14} /> Processar Prévia
                          </>
                        )}
                      </button>

                      <button
                        id="guided-submit-direct-btn"
                        type="button"
                        onClick={handleOpenLinkModalGuided}
                        disabled={isSubmittingGuided}
                        className="bg-[#1A1A1A] text-white text-xs font-mono font-bold uppercase py-2.5 px-5 hover:bg-indigo-950 cursor-pointer flex items-center gap-1.5 rounded transition-all shadow"
                      >
                        {isSubmittingGuided ? (
                          <>
                            <RefreshCw size={14} className="animate-spin" /> Enviando...
                          </>
                        ) : (
                          <>
                            <Send size={14} /> Enviar Direto
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 7 && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="border-b pb-2">
                    <span className="text-[9px] font-mono font-bold uppercase bg-indigo-150 text-indigo-900 px-2.5 py-0.5 rounded">Etapa de Revisão</span>
                    <h4 className="text-sm font-bold text-gray-900 font-serif mt-1">Status Final das Respostas</h4>
                    <p className="text-xs text-gray-500">Seu relato técnico compilado está pronto para envio estratégico. Você pode ajustar os textos.</p>
                  </div>

                  <div className="bg-gray-50 border border-gray-300 rounded p-4 space-y-3">
                    <span className="text-[9px] font-mono font-bold text-gray-400 block uppercase tracking-wider pb-1.5 border-b">Relato compilado das respostas</span>
                    <div className="bg-white border rounded p-3 font-mono text-[11px] text-gray-700 whitespace-pre-line max-h-[300px] overflow-y-auto leading-relaxed shadow-xs">
                      {previewCompiledText || getCompiledWording()}
                    </div>
                  </div>

                  {parsedProcessResult && (
                    <ParsedProcessResultView 
                      result={parsedProcessResult} 
                      originalText={previewCompiledText || getCompiledWording()}
                      onUpdateResult={setParsedProcessResult}
                    />
                  )}

                  <div className="flex justify-between items-center pt-4">
                    <button
                      id="guided-step-7-back-btn"
                      type="button"
                      onClick={() => setWizardStep(6)}
                      className="text-xs font-mono font-bold text-gray-600 hover:text-gray-950 uppercase px-4 py-2 cursor-pointer bg-white border border-gray-300 rounded"
                    >
                      ✏️ Voltar e Ajustar
                    </button>
                    <button
                      id="guided-step-7-submit-btn"
                      type="button"
                      onClick={handleOpenLinkModalGuided}
                      disabled={isSubmittingGuided}
                      className="bg-indigo-700 text-white text-xs font-mono font-bold uppercase px-6 py-3 hover:bg-indigo-800 cursor-pointer flex items-center gap-1.5 shadow"
                    >
                      {isSubmittingGuided ? (
                        <>
                          <RefreshCw size={14} className="animate-spin" /> Enviando...
                        </>
                      ) : (
                        <>
                          <Send size={14} /> Confirmar & Enviar para Fila de Avaliação
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* COLUMN 2: AI Preview & Review Card (5 cols) */}
            <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-4 col-span-1">
              
              {/* Process filling progress board */}
              <div className="bg-white border-2 border-[#1A1A1A] rounded p-5 space-y-4 shadow-[4px_4px_0px_rgba(26,26,26,1)]">
                
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-[10.5px] font-mono font-extrabold text-indigo-950 uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
                    <Settings size={14} className="text-[#C49746]" /> Painel de Progresso LSS
                  </span>
                  
                  {/* Progress Badge */}
                  <span className="text-[10px] font-mono bg-indigo-50 border border-indigo-200 text-indigo-900 px-2 py-0.5 rounded-xs font-bold">
                    {Math.round(
                      ((guidedContactName ? 1 : 0) + 
                       (guidedProcessName ? 1 : 0) + 
                       (guidedGatilho ? 1 : 0) + 
                       (guidedFluxo ? 1 : 0) + 
                       (guidedDesvios ? 1 : 0) + 
                       (guidedFerramentas ? 1 : 0) + 
                       (guidedEntrega ? 1 : 0) + 
                       (guidedRegras ? 1 : 0)) / 8 * 100
                    )}% Preenchido
                  </span>
                </div>

                {/* Progress bar visualizer */}
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div 
                    className="bg-indigo-900 h-1.5 rounded-full transition-all duration-300" 
                    style={{ 
                      width: `${Math.round(
                        ((guidedContactName ? 1 : 0) + 
                         (guidedProcessName ? 1 : 0) + 
                         (guidedGatilho ? 1 : 0) + 
                         (guidedFluxo ? 1 : 0) + 
                         (guidedDesvios ? 1 : 0) + 
                         (guidedFerramentas ? 1 : 0) + 
                         (guidedEntrega ? 1 : 0) + 
                         (guidedRegras ? 1 : 0)) / 8 * 100
                      )}%`
                    }}
                  />
                </div>

                {parsedAnalysisResult ? (
                  // Shows analysis result if available
                  <div className="space-y-4 animate-fadeIn">
                    
                    <div className="p-3 bg-emerald-50 text-emerald-950 text-[11px] rounded border border-emerald-250 flex items-center gap-2">
                      <CheckCircle2 size={16} className="text-emerald-700 shrink-0" />
                      <span>Processo analisado para o projeto corporativo!</span>
                    </div>

                    {/* Calculated metrics preview */}
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="bg-indigo-50/70 border border-indigo-150 p-2 rounded">
                        <span className="text-[8px] text-indigo-800 font-mono block font-bold uppercase font-black">Eficiência Líquida</span>
                        <strong className="text-[13px] font-mono text-indigo-950 font-black">{100 - (parsedAnalysisResult.metrics.reworkEst || 15)}%</strong>
                      </div>
                      <div className="bg-[#FAF9F6] border border-gray-250 p-2 rounded">
                        <span className="text-[8px] text-[#C49746] font-mono block font-bold uppercase font-black">Tempo de Ciclo</span>
                        <strong className="text-[13px] font-mono text-[#C49746] font-black">{parsedAnalysisResult.metrics.tempoMedioCiclo}</strong>
                      </div>
                      <div className="bg-emerald-50 border border-emerald-150 p-2 rounded">
                        <span className="text-[8px] text-emerald-800 font-mono block font-bold uppercase font-black">Confiança IA</span>
                        <strong className="text-[13px] font-mono text-emerald-950 font-black">{parsedAnalysisResult.metrics.confidenceScore}%</strong>
                      </div>
                    </div>

                    {/* Decoded SIPOC values preview */}
                    <div className="space-y-1 bg-slate-50 border p-3 rounded text-left">
                      <span className="text-[9px] font-mono font-bold uppercase text-gray-400 block pb-1 border-b mb-1.5">Eixos SIPOC Preenchidos:</span>
                      <div className="grid grid-cols-5 gap-1 text-[8px] text-center font-bold font-mono">
                        <div className="bg-white border p-1 rounded-xs truncate shadow-3xs" title={parsedAnalysisResult.sipoc.Suppliers.join(', ')}>
                          <span className="text-indigo-600 block">S (Forn)</span>
                          <span className="text-gray-500 block truncate">{parsedAnalysisResult.sipoc.Suppliers[0] || "IA"}</span>
                        </div>
                        <div className="bg-white border p-1 rounded-xs truncate shadow-3xs" title={parsedAnalysisResult.sipoc.Inputs.join(', ')}>
                          <span className="text-sky-600 block">I (Entr)</span>
                          <span className="text-gray-500 block truncate">{parsedAnalysisResult.sipoc.Inputs[0] || "IA"}</span>
                        </div>
                        <div className="bg-indigo-100 border border-indigo-300 p-1 rounded-xs truncate shadow-3xs" title={parsedAnalysisResult.sipoc.Process}>
                          <span className="text-indigo-950 block">P (Proc)</span>
                          <span className="text-indigo-850 block truncate font-black">{parsedAnalysisResult.sipoc.Process || "Mapeio"}</span>
                        </div>
                        <div className="bg-white border p-1 rounded-xs truncate shadow-3xs" title={parsedAnalysisResult.sipoc.Outputs.join(', ')}>
                          <span className="text-amber-600 block">O (Saíd)</span>
                          <span className="text-gray-500 block truncate">{parsedAnalysisResult.sipoc.Outputs[0] || "IA"}</span>
                        </div>
                        <div className="bg-white border p-1 rounded-xs truncate shadow-3xs" title={parsedAnalysisResult.sipoc.Customers.join(', ')}>
                          <span className="text-emerald-600 block">C (Clie)</span>
                          <span className="text-gray-500 block truncate">{parsedAnalysisResult.sipoc.Customers[0] || "IA"}</span>
                        </div>
                      </div>
                    </div>

                    {/* Chronological steps identified */}
                    <div className="space-y-2 bg-[#FAF9F6] p-3 rounded border text-left">
                      <span className="text-[10px] font-bold text-gray-700 block text-left">Etapas do Processo Identificadas:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {parsedAnalysisResult.steps.map((st: string, idx: number) => (
                          <span key={idx} className="text-[9px] font-mono bg-white border border-gray-300 rounded px-2 py-0.5 text-gray-800 shadow-3xs flex items-center gap-1">
                            <span className="text-indigo-700 font-bold">{idx + 1}.</span> {st}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  // Real-time SIPOC drafting preview as the user types
                  <div className="space-y-4 text-left font-sans text-xs animate-fadeIn">
                    <p className="text-[11px] text-gray-500">Mapeamento dinâmico baseado em suas respostas em andamento:</p>
                    
                    <div className="space-y-2">
                      <div className="border border-indigo-100 p-2.5 rounded bg-gray-50/50">
                        <span className="text-[8px] font-mono text-indigo-700 block font-bold uppercase">PROCESSO</span>
                        <strong className="text-[12px] font-serif text-gray-900 block truncate" title={guidedProcessName}>
                          {guidedProcessName || "[Aguardando título do processo...]"}
                        </strong>
                      </div>

                      <div className="border border-amber-200 p-2.5 rounded bg-amber-500/5">
                        <span className="text-[8px] font-mono text-amber-700 block font-bold uppercase">GATILHO (INPUTS)</span>
                        <p className="text-[11px] text-gray-700 line-clamp-2">
                          {guidedGatilho || "Aguardando preenchimento da Etapa 1..."}
                        </p>
                      </div>

                      <div className="border border-indigo-200 p-2.5 rounded bg-indigo-50/50">
                        <span className="text-[8px] font-mono text-indigo-700 block font-bold uppercase">FLUXO (PROCESS)</span>
                        <p className="text-[11px] text-gray-700 line-clamp-2">
                          {guidedFluxo || "Aguardando preenchimento da Etapa 2..."}
                        </p>
                      </div>

                      <div className="border border-rose-200 p-2.5 rounded bg-rose-50/30">
                        <span className="text-[8px] font-mono text-rose-700 block font-bold uppercase">TRATAMENTO DE DESVIOS</span>
                        <p className="text-[11px] text-gray-700 line-clamp-2">
                          {guidedDesvios || "Aguardando preenchimento da Etapa 3..."}
                        </p>
                      </div>

                      <div className="border border-sky-200 p-2.5 rounded bg-sky-50/30">
                        <span className="text-[8px] font-mono text-sky-700 block font-bold uppercase">FERRAMENTAS</span>
                        <p className="text-[11px] text-gray-705 line-clamp-2">
                          {guidedFerramentas || "Aguardando preenchimento da Etapa 4..."}
                        </p>
                      </div>

                      <div className="border border-emerald-250 p-2.5 rounded bg-emerald-500/5">
                        <span className="text-[8px] font-mono text-emerald-700 block font-bold uppercase">ENTREGA FINAL (OUTPUTS)</span>
                        <p className="text-[11px] text-gray-700 line-clamp-2">
                          {guidedEntrega || "Aguardando preenchimento da Etapa 5..."}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      ) : (
        // --- MANUAL FREE TEXT DECLARED INTERPRETATION FORM ---
        <div id="manual-free-form" className="space-y-4 text-left max-w-xl mx-auto py-4">
          <div className="space-y-3.5">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-700 block text-left font-sans">Nome do Solicitante:</label>
              <input 
                id="free-text-name-input"
                type="text" 
                placeholder="Exágono: Mirandela de Souza" 
                value={freeTextName} 
                onChange={e => setFreeTextName(e.target.value)} 
                className="w-full border p-2.5 text-xs rounded bg-white shadow-2xs outline-indigo-500 font-sans" 
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-700 block text-left font-sans">Descreva à mão livre seu processo:</label>
              <textarea 
                id="free-text-descr-textarea"
                placeholder="Descreva seu processo fornecendo o gatilho inicial, as etapas sequenciais, as ferramentas, as tomadas de decisão e a entrega final." 
                value={freeTextValue} 
                onChange={e => setFreeTextValue(e.target.value)} 
                className="w-full border p-3 text-xs h-40 rounded bg-white shadow-inner font-sans outline-indigo-500 hover:ring-1 hover:ring-indigo-200" 
              />
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button 
                id="free-text-analyze-btn"
                type="button"
                onClick={handleFreeTextAnalysis} 
                disabled={isParsingProcess}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono font-bold px-6 py-2.5 uppercase text-xs cursor-pointer flex items-center gap-1.5 transition-all shadow-sm"
              >
                {isParsingProcess ? (
                  <>
                    <RefreshCw size={12} className="animate-spin" /> Analisando...
                  </>
                ) : (
                  <>
                    <Sparkles size={12} /> Analisar com IA ✨
                  </>
                )}
              </button>

              <button 
                id="free-text-submit-btn"
                onClick={handleOpenLinkModalFreeText} 
                disabled={isSubmittingGuided}
                className="bg-[#1A1A1A] hover:bg-slate-800 text-white font-mono font-bold px-6 py-2.5 uppercase text-xs cursor-pointer flex items-center gap-1.5 transition-all shadow-sm"
              >
                {isSubmittingGuided ? (
                  <>
                    <RefreshCw size={12} className="animate-spin" /> Enviando...
                  </>
                ) : (
                  <>
                    <Send size={12} /> Registrar Demanda
                  </>
                )}
              </button>
            </div>

            {parsedProcessResult && (
              <div className="mt-4 border-t pt-4">
                <ParsedProcessResultView 
                  result={parsedProcessResult} 
                  originalText={freeTextValue}
                  onUpdateResult={setParsedProcessResult}
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Dynamic Link and Create Project Modal */}
      {isLinkingModalOpen && (
        <div className="fixed inset-0 bg-[#1A1A1A]/80 flex items-center justify-center z-50 p-4 font-sans backdrop-blur-xs">
          <div className="bg-white border-4 border-[#1A1A1A] max-w-md w-full p-6 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] relative transition-all">
            <h4 className="text-lg font-bold font-serif text-gray-900 mb-2 border-b-2 border-dashed border-[#1A1A1A] pb-2 flex items-center gap-2">
              <Layers className="text-indigo-900 animate-pulse" size={18} />
              Vincular a Empresa, Projeto e Processo
            </h4>
            
            <p className="text-xs text-gray-500 mb-4 leading-relaxed">
              Associe esta descrição de processo a uma empresa e projeto cadastrados na ferramenta, definindo também o nome oficial de identificação.
            </p>
            
            <div className="space-y-4 font-sans">
              {/* Company Select */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-gray-700 block text-left">
                  Empresa do Sistema:
                </label>
                <select
                  value={linkingCompanyId}
                  onChange={(e) => handleCompanyChange(e.target.value)}
                  className="w-full border-2 border-[#1A1A1A] p-2 text-xs rounded bg-white font-mono text-gray-950"
                >
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      🏢 {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Project Select */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-gray-700 block text-left">
                  Projeto de Mapeamento:
                </label>
                <select
                  value={linkingProjectId}
                  onChange={(e) => {
                    const val = e.target.value;
                    setLinkingProjectId(val);
                    if (val === "new") {
                      setIsCreatingNewProject(true);
                      setLinkingProjectName("");
                    } else {
                      setIsCreatingNewProject(false);
                      const activeProjs = projects || CompanyProjectRepository.getProjects() || [];
                      const matched = activeProjs.find(p => p.id === val);
                      if (matched) {
                        setLinkingProjectName(matched.name);
                      }
                    }
                  }}
                  className="w-full border-2 border-[#1A1A1A] p-2 text-xs rounded bg-white font-mono text-gray-950"
                >
                  {(projects || CompanyProjectRepository.getProjects() || [])
                    .filter((p: any) => p.companyId === linkingCompanyId)
                    .map((p: any) => (
                      <option key={p.id} value={p.id}>
                        📁 {p.name}
                      </option>
                    ))}
                  <option value="new">➕ Criar Novo Projeto nesta Empresa...</option>
                </select>
              </div>

              {/* New Project Name input */}
              {isCreatingNewProject && (
                <div className="space-y-1 bg-amber-50/50 p-3 border border-dashed border-amber-300 rounded">
                  <label className="text-[11px] font-bold text-amber-800 block text-left">
                    Nome do Novo Projeto:
                  </label>
                  <input
                    type="text"
                    value={linkingProjectName}
                    onChange={(e) => setLinkingProjectName(e.target.value)}
                    placeholder="Ex: Redução de Desperdício na Fábrica"
                    className="w-full border-2 border-amber-500 p-2 text-xs rounded bg-white focus:outline-none text-gray-950"
                    required
                  />
                  <span className="text-[9px] text-amber-600 block mt-1">
                    Um novo projeto com esse nome será criado automaticamente sob a empresa selecionada.
                  </span>
                </div>
              )}

              {/* Process Name input */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-gray-700 block text-left">
                  Nome do Processo:
                </label>
                <input
                  type="text"
                  value={linkingProcessName}
                  onChange={(e) => setLinkingProcessName(e.target.value)}
                  placeholder="Ex: Faturamento de Pedidos"
                  className="w-full border-2 border-[#1A1A1A] p-2 text-xs rounded bg-white focus:outline-none text-gray-950"
                  required
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3 font-sans">
              <button
                type="button"
                onClick={() => setIsLinkingModalOpen(false)}
                className="border-2 border-[#1A1A1A] px-4 py-2 text-xs font-bold rounded hover:bg-gray-100 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (!linkingProjectName.trim()) {
                    alert("Por favor, informe o nome do projeto.");
                    return;
                  }
                  if (!linkingProcessName.trim()) {
                    alert("Por favor, informe o nome do processo.");
                    return;
                  }

                  let finalProjId = linkingProjectId;
                  let finalProjName = linkingProjectName.trim();
                  let finalProcName = linkingProcessName.trim();
                  let finalCompId = linkingCompanyId;
                  const finalCompName = companies.find(c => c.id === linkingCompanyId)?.name || "Empresa Selecionada";

                  const currentProjs = projects || CompanyProjectRepository.getProjects() || [];

                  if (isCreatingNewProject) {
                    const newProjId = "proj_" + Date.now().toString();
                    const newProj = {
                      id: newProjId,
                      companyId: finalCompId,
                      name: finalProjName,
                      objective: "Projeto de Mapeamento de Processos criado no ambiente do cliente.",
                      status: "Planejado" as const,
                      createdAt: new Date().toISOString()
                    };

                    CompanyProjectRepository.saveProjects([...currentProjs, newProj]);
                    if (onProjectsUpdate) {
                      onProjectsUpdate([...currentProjs, newProj]);
                    }
                    finalProjId = newProjId;
                  }

                  setIsLinkingModalOpen(false);

                  if (linkingMode === "guided") {
                    await handleSubmitGuidedRequest(finalProjId, finalProjName, finalProcName, finalCompId, finalCompName);
                  } else {
                    await handleSubmitFreeText(finalProjId, finalProjName, finalProcName, finalCompId, finalCompName);
                  }
                }}
                className="bg-indigo-950 hover:bg-indigo-900 text-white border-2 border-[#1A1A1A] px-4 py-2 text-xs font-bold rounded transition-colors shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] cursor-pointer"
              >
                Vincular & Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
