import React, { useState, useMemo } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  ReferenceLine
} from "recharts";
import { 
  BarChart3, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  HelpCircle, 
  RefreshCw, 
  Sliders, 
  Activity, 
  ArrowRight,
  TrendingDown
} from "lucide-react";
import { ProcessStep } from "../types";

interface DmaicCycleTimeHistogramProps {
  steps: ProcessStep[];
  selectedStep: ProcessStep;
}

export default function DmaicCycleTimeHistogram({ steps, selectedStep }: DmaicCycleTimeHistogramProps) {
  // Active step selection state (defaults to the currently selected step in the wizard)
  const [activeStepId, setActiveStepId] = useState<string>(selectedStep?.id || steps[0]?.id || "");
  const [regenerateKey, setRegenerateKey] = useState<number>(0);

  // Find the selected step object
  const currentStep = useMemo(() => {
    return steps.find(s => s.id === activeStepId) || selectedStep || steps[0];
  }, [steps, activeStepId, selectedStep]);

  // Generate simulated normal distribution samples (100 samples)
  const statsAndBins = useMemo(() => {
    if (!currentStep) return null;

    const mean = currentStep.processingTime;
    const sd = currentStep.standardDeviation || 0.1;
    
    // Box-Muller transform for normal distribution
    const samples: number[] = [];
    const count = 100;
    
    // We want the same random set for a given step unless regenerated explicitly
    const seedRandom = (i: number) => {
      // Simple pseudo-random hash based on step ID + i + regenerateKey
      const str = currentStep.id + i + regenerateKey;
      let hash = 0;
      for (let j = 0; j < str.length; j++) {
        hash = str.charCodeAt(j) + ((hash << 5) - hash);
      }
      return Math.abs(Math.sin(hash)) % 1;
    };

    for (let i = 0; i < count; i++) {
      let u1 = seedRandom(i * 2);
      let u2 = seedRandom(i * 2 + 1);
      if (u1 === 0) u1 = 0.0001;
      if (u2 === 0) u2 = 0.0001;
      
      const randStd = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const val = mean + randStd * sd;
      samples.push(Math.max(0.1, Math.round(val * 10) / 10));
    }

    // Define normal limits (using exactly ±2.0 standard deviations per user's specification)
    const lowerNormalLimit = Math.max(0.1, mean - 2.0 * sd);
    const upperNormalLimit = mean + 2.0 * sd;

    // Define 3-sigma control limits for reference lines
    const lcl = Math.max(0.1, mean - 3 * sd);
    const ucl = mean + 3 * sd;

    // Bins calculation
    const minVal = Math.max(0.1, mean - 3 * sd);
    const maxVal = mean + 3 * sd;
    const range = maxVal - minVal;
    
    const numBins = 10;
    const binWidth = range / numBins;
    
    const binList = Array.from({ length: numBins }, (_, i) => {
      const start = minVal + i * binWidth;
      const end = start + binWidth;
      return {
        start,
        end,
        label: `${start.toFixed(1)}-${end.toFixed(1)}`,
        count: 0,
        isOutlier: false
      };
    });

    let outlierCount = 0;
    samples.forEach(v => {
      let placed = false;
      for (let i = 0; i < numBins; i++) {
        if (v >= binList[i].start && v < binList[i].end) {
          binList[i].count++;
          placed = true;
          break;
        }
      }
      if (!placed && v >= binList[numBins - 1].end) {
        binList[numBins - 1].count++;
      }

      if (v < lowerNormalLimit || v > upperNormalLimit) {
        outlierCount++;
      }
    });

    // Mark bin as outlier if its center falls outside the normal distribution limits (±2.0 SD)
    binList.forEach(bin => {
      const center = (bin.start + bin.end) / 2;
      if (center < lowerNormalLimit || center > upperNormalLimit) {
        bin.isOutlier = true;
      }
    });

    // Coefficient of variation
    const cv = sd / mean;
    const variabilityStatus = 
      cv > 0.4 ? "CRÍTICA" : 
      cv > 0.2 ? "MODERADA" : "ESTÁVEL";

    return {
      samples,
      bins: binList,
      mean,
      sd,
      lcl,
      ucl,
      lowerNormalLimit,
      upperNormalLimit,
      outlierCount,
      outlierPercentage: Math.round((outlierCount / count) * 100),
      cv,
      variabilityStatus
    };
  }, [currentStep, regenerateKey]);

  // Overall process steps variability summary
  const stepsVariabilityList = useMemo(() => {
    return steps.map(s => {
      const mean = s.processingTime;
      const sd = s.standardDeviation || 0.1;
      const cv = sd / mean;
      const status = 
        cv > 0.4 ? "CRÍTICA" : 
        cv > 0.2 ? "MODERADA" : "ESTÁVEL";
      return {
        id: s.id,
        name: s.name,
        mean,
        sd,
        cv,
        status
      };
    });
  }, [steps]);

  if (!currentStep || !statsAndBins) {
    return (
      <div className="p-4 text-center text-gray-500 font-mono text-xs">
        Selecione uma etapa do processo para visualizar a distribuição dos tempos de ciclo.
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm space-y-6">
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-150 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-[#F5F2ED] text-[#C49746] rounded-lg">
              <BarChart3 className="w-4 h-4" />
            </span>
            <h4 className="text-sm font-bold uppercase tracking-wider text-gray-900 font-serif">
              Análise de Histograma de Variabilidade (Seis Sigma)
            </h4>
          </div>
          <p className="text-[11px] text-gray-500 mt-1 font-sans">
            Distribuição amostral dos tempos de ciclo de cada posto de trabalho para detectar desvios severos.
          </p>
        </div>

        {/* Quick controls */}
        <div className="flex items-center gap-2">
          <label className="text-[10px] font-mono font-bold text-gray-400 uppercase">Etapa Ativa:</label>
          <select
            value={activeStepId}
            onChange={(e) => setActiveStepId(e.target.value)}
            className="bg-gray-50 border border-gray-200 rounded px-2.5 py-1 text-xs font-bold text-gray-800 focus:outline-none focus:ring-1 focus:ring-[#C49746] cursor-pointer"
          >
            {steps.map(s => (
              <option key={s.id} value={s.id}>
                {s.name} (σ = {s.standardDeviation}m)
              </option>
            ))}
          </select>

          <button
            onClick={() => setRegenerateKey(prev => prev + 1)}
            className="p-1.5 hover:bg-gray-100 rounded text-gray-500 transition-colors cursor-pointer"
            title="Regenerar amostras estocásticas (Novos dados)"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Grid of Steps Status Overview */}
      <div className="space-y-2">
        <span className="block text-[9px] uppercase font-black tracking-widest text-gray-400 font-mono">
          Painel de Estabilidade das Etapas do Processo:
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {stepsVariabilityList.map(item => {
            const isSelected = item.id === activeStepId;
            const statusColors = 
              item.status === "CRÍTICA" ? "border-red-200 bg-red-50 text-red-700" :
              item.status === "MODERADA" ? "border-amber-200 bg-amber-50 text-amber-700" :
              "border-emerald-200 bg-emerald-50 text-emerald-700";

            return (
              <div
                key={item.id}
                onClick={() => setActiveStepId(item.id)}
                className={`p-2.5 border rounded-lg cursor-pointer transition-all text-left relative ${
                  isSelected 
                    ? "border-[#C49746] bg-[#F5F2ED]/40 shadow-sm" 
                    : "border-gray-100 bg-gray-50/50 hover:bg-gray-50"
                }`}
              >
                <div className="text-[10px] font-black uppercase truncate text-gray-800 pr-4">
                  {item.name}
                </div>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-[9px] font-mono text-gray-400">CV = {item.cv.toFixed(2)}</span>
                  <span className={`text-[8px] font-mono font-bold px-1.5 py-0.2 rounded ${statusColors}`}>
                    {item.status}
                  </span>
                </div>
                {isSelected && (
                  <span className="absolute top-1 right-1.5 text-[8px] font-bold text-[#C49746] font-mono">●</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Chart & Key Metric Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        {/* Metric Summary Column */}
        <div className="lg:col-span-4 space-y-3.5">
          <div className="bg-[#1A1A1A] text-white p-4 rounded-xl space-y-3">
            <span className="block text-[8.5px] uppercase font-mono font-black tracking-widest text-gray-400">
              Métricas de Variabilidade LSS
            </span>
            
            <div className="space-y-2">
              <div className="flex justify-between items-baseline border-b border-gray-800 pb-1.5">
                <span className="text-[10px] text-gray-350 font-mono">Média Real (μ):</span>
                <span className="text-sm font-mono font-bold">{statsAndBins.mean.toFixed(1)} min</span>
              </div>
              <div className="flex justify-between items-baseline border-b border-gray-800 pb-1.5">
                <span className="text-[10px] text-gray-350 font-mono">Desvio Padrão (σ):</span>
                <span className="text-sm font-mono font-bold text-[#C49746]">{statsAndBins.sd.toFixed(2)} min</span>
              </div>
              <div className="flex justify-between items-baseline border-b border-gray-800 pb-1.5">
                <span className="text-[10px] text-gray-350 font-mono">Dispersion (CV):</span>
                <span className="text-sm font-mono font-bold">{statsAndBins.cv.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-[10px] text-gray-350 font-mono">Status de Estabilidade:</span>
                <span className={`text-[9.5px] font-mono font-bold ${
                  statsAndBins.variabilityStatus === "CRÍTICA" ? "text-red-400" :
                  statsAndBins.variabilityStatus === "MODERADA" ? "text-amber-400" : "text-emerald-400"
                }`}>
                  {statsAndBins.variabilityStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Outlier Alert Card */}
          <div className={`p-4 rounded-xl border ${
            statsAndBins.cv > 0.4 
              ? "bg-red-50/50 border-red-100 text-red-950" 
              : statsAndBins.cv > 0.2 
                ? "bg-amber-50/50 border-amber-100 text-amber-950" 
                : "bg-emerald-50/50 border-emerald-100 text-emerald-950"
          }`}>
            <div className="flex items-start gap-2.5">
              <div className="mt-0.5">
                {statsAndBins.cv > 0.2 ? (
                  <AlertTriangle className={`w-4 h-4 ${statsAndBins.cv > 0.4 ? "text-red-600" : "text-amber-600"}`} />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                )}
              </div>
              <div className="space-y-1 text-left">
                <h5 className="text-[11px] font-bold font-mono uppercase tracking-wide">
                  {statsAndBins.cv > 0.4 ? "Altíssima Variabilidade!" : statsAndBins.cv > 0.2 ? "Instabilidade Moderada" : "Processo Estável"}
                </h5>
                <p className="text-[10px] text-gray-600 leading-relaxed font-sans">
                  {statsAndBins.outlierPercentage}% das amostras simuladas caem fora do intervalo de distribuição padrão normal (<strong className="font-mono">±2σ</strong>). 
                  {statsAndBins.cv > 0.3 
                    ? " Isso indica que esta etapa frequentemente sofre interrupções, gargalos severos ou falta de padronização." 
                    : " O processo está sob controle estatístico saudável."}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Recharts Histogram Chart Panel */}
        <div className="lg:col-span-8 border border-gray-100 p-4 bg-gray-50/40 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="block text-[9px] uppercase font-black tracking-widest text-gray-400 font-mono">
                Histograma de Frequências Amostrais (n = 100)
              </span>
              <p className="text-[10px] text-gray-500 font-sans">
                As colunas em <span className="text-red-500 font-semibold">Vermelho</span> representam tempos de ciclo fora da curva normal esperada (Alta Variabilidade / Outliers maiores que ±2σ).
              </p>
            </div>
            
            <div className="flex items-center gap-3 text-[9px] font-mono">
              <span className="flex items-center gap-1 text-slate-500">
                <span className="w-2.5 h-2.5 bg-slate-350 rounded-xs"></span> Dentro de ±2σ
              </span>
              <span className="flex items-center gap-1 text-red-500">
                <span className="w-2.5 h-2.5 bg-red-500 rounded-xs"></span> Fora de ±2σ (Outliers)
              </span>
            </div>
          </div>

          <div className="h-56 w-full text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={statsAndBins.bins} 
                margin={{ top: 15, right: 10, left: -25, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F1F1" vertical={false} />
                <XAxis 
                  dataKey="label" 
                  tick={{ fontSize: 9, fill: "#64748B", fontFamily: "monospace" }} 
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 9, fill: "#64748B" }} 
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-2.5 rounded-lg shadow-xl text-[10px] border border-slate-800 font-mono space-y-1">
                          <p className="font-bold text-[#C49746]">Intervalo: {data.label} min</p>
                          <p>Ocorrências: {data.count} amostras</p>
                          <p className={data.isOutlier ? "text-red-400 font-bold animate-pulse" : "text-emerald-400"}>
                            {data.isOutlier ? "⚠ FORA DA CURVA COMUM (OUTLIER)" : "✓ Faixa Normal Estável"}
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                  {statsAndBins.bins.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.isOutlier ? "#EF4444" : "#64748B"} 
                      fillOpacity={entry.isOutlier ? 0.9 : 0.45}
                    />
                  ))}
                </Bar>
                
                {/* Mean reference line */}
                <ReferenceLine 
                  x={statsAndBins.bins[Math.floor(statsAndBins.bins.length / 2)]?.label} 
                  stroke="#C49746" 
                  strokeWidth={1.5}
                  strokeDasharray="3 3"
                  label={{ 
                    value: `Média: ${statsAndBins.mean.toFixed(1)}m`, 
                    fill: "#C49746", 
                    fontSize: 8, 
                    fontWeight: "bold",
                    position: "top" 
                  }} 
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Expert DMAIC PDCA integration Coach card */}
      <div className="bg-[#F5F2ED]/40 p-4 border border-[#F5F2ED] rounded-xl text-left space-y-2">
        <div className="flex items-center gap-1.5 text-gray-900 font-bold text-[10.5px] uppercase font-mono tracking-wider">
          <Sliders className="w-3.5 h-3.5 text-[#C49746]" />
          <span>Como usar esse Histograma no Giro PDCA?</span>
        </div>
        <p className="text-[10.5px] text-gray-700 leading-relaxed font-sans">
          A variabilidade é o maior inimigo da produtividade e da previsibilidade. No <strong>Planejamento (Plan)</strong>, mapeamos a teoria. Aqui na <strong>Medição (Measure / Do)</strong>, este Histograma expõe a realidade: etapas com alta taxa de outliers representam processos que oscilam descontroladamente.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
          <div className="p-2 bg-white rounded border border-gray-100 text-[10px] space-y-0.5">
            <span className="font-bold text-[#C49746] block font-mono uppercase">1. IDENTIFICAR O DESVIO:</span>
            <p className="text-gray-600">Amostras fora dos limites (barras vermelhas) representam gargalos especiais (problemas de máquina, atraso humano ou quebras).</p>
          </div>
          <div className="p-2 bg-white rounded border border-gray-100 text-[10px] space-y-0.5">
            <span className="font-bold text-emerald-600 block font-mono uppercase">2. AGIR NO PDCA (ACT):</span>
            <p className="text-gray-600">Crie planos de ação 5W2H para padronizar estas etapas críticas, reduzindo o desvio padrão e estabilizando o fluxo.</p>
          </div>
        </div>
      </div>

    </div>
  );
}
