import React, { useState, useEffect } from "react";
import { useBusinessContext } from "../contexts/BusinessContext";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import { z } from "zod";
import { initialProcessMappingSchema } from "../domain/e3i/e3i.validation";
import { 
  collection, 
  setDoc, 
  query, 
  where, 
  onSnapshot, 
  deleteDoc, 
  doc, 
  serverTimestamp 
} from "firebase/firestore";
import { 
  FileText, 
  Check, 
  Loader2, 
  Trash2, 
  Building, 
  Layers, 
  AlertCircle,
  CheckCircle2,
  X
} from "lucide-react";

// Macroprocesses list grouped by sector
export const MACRO_PROCESS_SECTORS = {
  INDUSTRIAL: [
    { id: "IND_M1", name: "M1 - Gestão de Suprimentos e Matéria-Prima" },
    { id: "IND_M2", name: "M2 - Produção e Montagem na Linha de Fábrica" },
    { id: "IND_M3", name: "M3 - Controle de Qualidade e Inspeção Técnica" },
    { id: "IND_M4", name: "M4 - Armazenamento, Embalagem e Distribuição" },
    { id: "IND_M5", name: "M5 - Manutenção Preventiva e Calibração de Máquinas" }
  ],
  SERVICES: [
    { id: "SRV_M1", name: "M1 - Atendimento Inicial e Triagem de Solicitações" },
    { id: "SRV_M2", name: "M2 - Execução e Entrega do Serviço Especializado" },
    { id: "SRV_M3", name: "M3 - Gestão de Contratos e Suporte ao Cliente (SLA)" },
    { id: "SRV_M4", name: "M4 - Faturamento, Cobrança e Conciliação Financeira" },
    { id: "SRV_M5", name: "M5 - Garantia da Qualidade e Pós-Venda" }
  ],
  RETAIL: [
    { id: "RET_M1", name: "M1 - Compras, Negociação e Gestão de Fornecedores" },
    { id: "RET_M2", name: "M2 - Recebimento, Conferência e Armazenagem" },
    { id: "RET_M3", name: "M3 - Exposição, Vendas e Atendimento de Frente de Loja" },
    { id: "RET_M4", name: "M4 - Checkout, Faturamento e Meios de Pagamento" },
    { id: "RET_M5", name: "M5 - Gestão de Devoluções e Trocas" }
  ],
  LOGISTICS: [
    { id: "LOG_M1", name: "M1 - Recebimento de Cargas e Conferência de Docas" },
    { id: "LOG_M2", name: "M2 - Armazenamento e Endereçamento Inteligente" },
    { id: "LOG_M3", name: "M3 - Picking (Separação) e Embalagem (Packing)" },
    { id: "LOG_M4", name: "M4 - Planejamento de Rotas e Distribuição (Last-Mile)" },
    { id: "LOG_M5", name: "M5 - Logística Reversa e Controle de Avarias" }
  ],
  GENERAL: [
    { id: "GEN_M1", name: "M1 - Processos Operacionais Gerais" },
    { id: "GEN_M2", name: "M2 - Administrativo e Gestão" },
    { id: "GEN_M3", name: "M3 - Relacionamento com Clientes" }
  ]
};

// Zod Validation Schema imported from src/domain/e3i/e3i.validation.ts

const formatMapDate = (dateVal: any) => {
  if (!dateVal) return { date: "-", time: "-" };
  let d: Date;
  if (dateVal instanceof Date) {
    d = dateVal;
  } else if (typeof dateVal === "string" || typeof dateVal === "number") {
    d = new Date(dateVal);
  } else if (typeof dateVal === "object" && dateVal.toDate && typeof dateVal.toDate === "function") {
    d = dateVal.toDate();
  } else if (typeof dateVal === "object" && dateVal.seconds) {
    d = new Date(dateVal.seconds * 1000);
  } else {
    d = new Date(dateVal);
  }
  
  if (isNaN(d.getTime())) {
    return { date: "-", time: "-" };
  }
  
  return {
    date: d.toLocaleDateString("pt-BR"),
    time: d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
  };
};

interface Toast {
  id: string;
  type: "success" | "error" | "loading";
  message: string;
}

export default function MapeadorInicialProcessos() {
  const { companyId, segmentConfig } = useBusinessContext();
  
  // Local states
  const [selectedSector, setSelectedSector] = useState<keyof typeof MACRO_PROCESS_SECTORS>("GENERAL");
  const [selectedMacroId, setSelectedMacroId] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successId, setSuccessId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mappings, setMappings] = useState<any[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Toast Helper Methods
  const addToast = (type: "success" | "error" | "loading", message: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, message }]);
    if (type !== "loading") {
      setTimeout(() => {
        removeToast(id);
      }, 4000);
    }
    return id;
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const updateToast = (id: string, type: "success" | "error", message: string) => {
    setToasts(prev => prev.map(t => t.id === id ? { ...t, type, message } : t));
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  // Validation States
  const [touched, setTouched] = useState<{
    selectedSector?: boolean;
    selectedMacroId?: boolean;
    description?: boolean;
  }>({});
  
  const [validationErrors, setValidationErrors] = useState<{
    selectedSector?: string;
    selectedMacroId?: string;
    description?: string;
  }>({});

  // Real-time Zod Validation effect
  useEffect(() => {
    const parsed = initialProcessMappingSchema.safeParse({
      selectedSector,
      selectedMacroId,
      description
    });

    if (parsed.success) {
      setValidationErrors({});
    } else {
      const errs: typeof validationErrors = {};
      parsed.error.issues.forEach((issue) => {
        const fieldName = issue.path[0] as keyof typeof validationErrors;
        if (fieldName) {
          errs[fieldName] = issue.message;
        }
      });
      setValidationErrors(errs);
    }
  }, [selectedSector, selectedMacroId, description]);

  // Handle touched input fields
  const handleBlur = (field: keyof typeof touched) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  // Automatically select sector based on the segmentConfig context
  useEffect(() => {
    if (segmentConfig?.segment) {
      const seg = segmentConfig.segment;
      if (seg === "manufatura") {
        setSelectedSector("INDUSTRIAL");
      } else if (seg === "servicos" || seg === "financeiro" || seg === "contabil" || seg === "fiscal" || seg === "rh" || seg === "saude" || seg === "tecnologia") {
        setSelectedSector("SERVICES");
      } else if (seg === "comercio") {
        setSelectedSector("RETAIL");
      } else if (seg === "logistica") {
        setSelectedSector("LOGISTICS");
      } else {
        setSelectedSector("GENERAL");
      }
    }
  }, [segmentConfig]);

  // Update selected macro ID when sector changes
  useEffect(() => {
    const list = MACRO_PROCESS_SECTORS[selectedSector];
    if (list && list.length > 0) {
      setSelectedMacroId(list[0].id);
    }
  }, [selectedSector]);

  // Real-time listener for current user's mappings
  useEffect(() => {
    const isSandboxMode = typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true";
    
    if (!auth.currentUser) {
      // Local fallback mode for anonymous or simulated dashboard client users
      try {
        const localSaved = localStorage.getItem("lss_local_initial_mappings");
        if (localSaved) {
          const list = JSON.parse(localSaved).map((item: any) => ({
            ...item,
            createdAt: new Date(item.createdAt)
          }));
          setMappings(list);
        } else {
          // Provide an initial beautiful default mapping
          const defaults = [
            {
              id: "MAP_LOCAL_123",
              companyId: companyId || "comp-default",
              macroProcessId: "M2 - Produção e Montagem na Linha de Fábrica",
              description: "Mapeamento inicial de exemplo do modo local. Identificamos gargalos na alimentação de componentes que afetam o tempo de ciclo geral.",
              userId: "anonymous",
              status: "Aguardando Análise",
              createdAt: new Date()
            }
          ];
          setMappings(defaults);
          localStorage.setItem("lss_local_initial_mappings", JSON.stringify(defaults));
        }
      } catch (e) {
        console.warn("Failed to load local initial process mappings:", e);
        setMappings([]);
      }
      return;
    }

    const q = query(
      collection(db, "initial_process_mappings"),
      where("userId", "==", auth.currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          ...data,
          createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt)) : new Date()
        });
      });
      list.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      setMappings(list);
    }, (err) => {
      console.warn("Utilizando cache ou fallback local para listagem no componente Mapeador:", err.message || err);
      // Log/throw firestore error according to Firebase skill rules
      try {
        handleFirestoreError(err, OperationType.GET, "initial_process_mappings");
      } catch (e) {
        console.error("Firestore permission or load error logged.");
      }
    });

    return () => unsubscribe();
  }, [auth.currentUser, companyId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mark all fields as touched upon submit attempt
    setTouched({
      selectedSector: true,
      selectedMacroId: true,
      description: true
    });

    const parsed = initialProcessMappingSchema.safeParse({
      selectedSector,
      selectedMacroId,
      description
    });

    if (!parsed.success) {
      setError("Por favor, corrija os erros de validação antes de enviar.");
      addToast("error", "Erro de validação: Corrija os campos do formulário.");
      return;
    }

    setIsSubmitting(true);
    setSuccessId(null);
    setError(null);

    // Add a loading feedback toast
    const toastId = addToast("loading", "Salvando seu mapeamento de processo no Firestore...");

    const mappingId = `MAP_${Math.floor(100000 + Math.random() * 900000)}`;
    const userUid = auth.currentUser?.uid || "anonymous";
    const activeCompId = companyId || "comp-default";
    
    const macroObj = MACRO_PROCESS_SECTORS[selectedSector].find(m => m.id === selectedMacroId);
    const macroName = macroObj ? macroObj.name : selectedMacroId;

    if (!auth.currentUser) {
      // Offline/Local/Simulated Client fallback saving
      setTimeout(() => {
        setIsSubmitting(false);
        setSuccessId(mappingId);
        
        const newLocal = {
          id: mappingId,
          companyId: activeCompId,
          macroProcessId: macroName,
          description: description,
          userId: userUid,
          status: "Aguardando Análise",
          createdAt: new Date().toISOString()
        };
        
        const updatedList = [newLocal, ...mappings];
        setMappings(updatedList);
        try {
          localStorage.setItem("lss_local_initial_mappings", JSON.stringify(updatedList));
        } catch (e) {
          console.warn("Error saving local mappings to localStorage:", e);
        }
        
        setDescription("");
        setTouched({});
        updateToast(toastId, "success", `Sucesso! Mapeamento ${mappingId} registrado localmente no seu navegador.`);
      }, 800);
      return;
    }

    try {
      await setDoc(doc(db, "initial_process_mappings", mappingId), {
        id: mappingId,
        companyId: activeCompId,
        macroProcessId: macroName,
        description: description,
        userId: userUid,
        status: "Aguardando Análise",
        createdAt: serverTimestamp()
      });

      setSuccessId(mappingId);
      setDescription("");
      setTouched({});
      updateToast(toastId, "success", `Sucesso! Mapeamento de processo ${mappingId} salvo com segurança.`);
    } catch (err: any) {
      console.error("Falha ao registrar mapeamento inicial:", err);
      const errMsg = "Erro de permissão ou conexão ao salvar no Firestore.";
      setError(errMsg);
      updateToast(toastId, "error", errMsg);
      // Standard Firebase Error reporting schema compliance
      handleFirestoreError(err, OperationType.WRITE, "initial_process_mappings/" + mappingId);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Deseja realmente remover este mapeamento?")) return;

    if (!auth.currentUser) {
      const updatedList = mappings.filter(m => m.id !== id);
      setMappings(updatedList);
      try {
        localStorage.setItem("lss_local_initial_mappings", JSON.stringify(updatedList));
      } catch (e) {
        console.warn("Error saving local mappings to localStorage:", e);
      }
      addToast("success", "Mapeamento removido localmente.");
      return;
    }

    const toastId = addToast("loading", "Excluindo registro...");
    try {
      await deleteDoc(doc(db, "initial_process_mappings", id));
      updateToast(toastId, "success", "Registro removido com sucesso!");
    } catch (err: any) {
      console.error("Erro ao deletar:", err);
      updateToast(toastId, "error", "Não foi possível excluir o mapeamento.");
      // Standard Firebase Error reporting schema compliance
      handleFirestoreError(err, OperationType.DELETE, "initial_process_mappings/" + id);
    }
  };

  // Helper styles for validation feedback
  const getFieldClassName = (fieldName: keyof typeof touched) => {
    const isTouched = touched[fieldName];
    const hasError = !!validationErrors[fieldName];
    
    let base = "w-full text-xs p-2.5 border rounded-none bg-white font-semibold cursor-pointer transition-all duration-200 outline-none ";
    if (fieldName === "description") {
      base = "w-full text-xs p-3 border rounded-none bg-white leading-relaxed transition-all duration-200 outline-none ";
    }

    if (!isTouched) {
      return base + "border-slate-300 focus:border-slate-900 focus:ring-1 focus:ring-slate-900";
    }
    if (hasError) {
      return base + "border-rose-500 bg-rose-50/10 focus:border-rose-600 focus:ring-1 focus:ring-rose-500";
    }
    return base + "border-emerald-500 bg-emerald-50/10 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500";
  };

  return (
    <div className="space-y-6" id="componente-mapeador-inicial">
      <div className="border-2 border-slate-950 p-6 bg-white rounded-none shadow-[2px_2px_0px_rgba(0,0,0,1)] text-left">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b pb-3">
          <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#D1A142]" />
            Mapeamento Inicial de Processos (Área do Cliente)
          </h3>
          <span className="text-[10px] bg-slate-100 text-slate-600 border border-slate-200 font-mono font-bold px-2 py-0.5">
            Empresa ID: {companyId || "Padrao"}
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {successId && (
            <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-none leading-relaxed animate-fadeIn">
              🎉 <strong>Mapeamento salvo com sucesso!</strong> ID: <strong className="font-mono underline">{successId}</strong>. O registro foi devidamente associado à empresa de ID <strong className="font-mono">{companyId || "Padrao"}</strong>.
            </div>
          )}

          {error && (
            <div className="p-4 bg-rose-50 border border-rose-300 text-rose-800 text-xs rounded-none leading-relaxed flex items-center gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* SELECTION OF SECTOR */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 block flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                Setor de Atuação:
              </label>
              <select
                value={selectedSector}
                onChange={(e) => {
                  setSelectedSector(e.target.value as any);
                  setTouched(prev => ({ ...prev, selectedSector: true }));
                }}
                onBlur={() => handleBlur("selectedSector")}
                className={getFieldClassName("selectedSector")}
              >
                <option value="GENERAL">Geral / Administrativo</option>
                <option value="INDUSTRIAL">Industrial / Manufatura</option>
                <option value="SERVICES">Prestação de Serviços</option>
                <option value="RETAIL">Comércio / Varejo</option>
                <option value="LOGISTICS">Transporte e Logística</option>
              </select>
              {touched.selectedSector && validationErrors.selectedSector ? (
                <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {validationErrors.selectedSector}
                </p>
              ) : touched.selectedSector ? (
                <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Setor selecionado com sucesso
                </p>
              ) : null}
            </div>

            {/* SELECTION OF MACROPROCESS */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 block flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                Macroprocesso Associado:
              </label>
              <select
                value={selectedMacroId}
                onChange={(e) => {
                  setSelectedMacroId(e.target.value);
                  setTouched(prev => ({ ...prev, selectedMacroId: true }));
                }}
                onBlur={() => handleBlur("selectedMacroId")}
                className={getFieldClassName("selectedMacroId")}
              >
                {MACRO_PROCESS_SECTORS[selectedSector].map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
              {touched.selectedMacroId && validationErrors.selectedMacroId ? (
                <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {validationErrors.selectedMacroId}
                </p>
              ) : touched.selectedMacroId ? (
                <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Macroprocesso válido
                </p>
              ) : null}
            </div>
          </div>

          {/* DESCRIPTION TEXTAREA */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-bold text-slate-700 block">
                Descreva como seu processo funciona utilizando suas próprias palavras:
              </label>
              <span className={`text-[10px] font-mono ${description.length < 15 ? "text-slate-400" : description.length > 5000 ? "text-rose-500 font-bold" : "text-emerald-600 font-bold"}`}>
                {description.length}/5000 caracteres
              </span>
            </div>
            <textarea
              required
              rows={6}
              placeholder="Ex: No início do mês recebemos faturas fiscais por e-mail. Nós fazemos a conferência manual das faturas com os pedidos de compra no sistema. Depois mandamos para assinatura da diretoria. Demoramos cerca de 3 dias só nessa etapa de aprovação."
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
                setTouched(prev => ({ ...prev, description: true }));
              }}
              onBlur={() => handleBlur("description")}
              className={getFieldClassName("description")}
            ></textarea>
            {touched.description && validationErrors.description ? (
              <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {validationErrors.description}
              </p>
            ) : touched.description ? (
              <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Detalhamento excelente! Mapeamento pronto para envio.
              </p>
            ) : (
              <p className="text-[10px] text-slate-400">
                Dica: Escreva livremente de forma simples e intuitiva, focando em como o trabalho acontece hoje.
              </p>
            )}
          </div>

          {/* SUBMISSION BUTTON */}
          <div className="pt-2 border-t flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-[#D1A142] text-slate-950 font-black text-xs uppercase hover:bg-[#b88c34] disabled:bg-slate-300 disabled:text-slate-500 rounded-none transition-all flex items-center gap-1.5 cursor-pointer shadow-[2px_2px_0px_rgba(0,0,0,1)]"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Salvar Mapeamento
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* MAPPED LIST */}
      {mappings.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-xs font-mono font-black text-slate-900 uppercase tracking-widest pl-1">
            Mapeamentos Enviados ({mappings.length})
          </h4>
          <div className="space-y-3">
            {mappings.map((map) => (
              <div 
                key={map.id}
                className="p-5 bg-white border border-slate-200 hover:border-slate-300 transition-all rounded-none text-left flex flex-col md:flex-row md:items-start justify-between gap-4 shadow-sm"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap text-xs">
                    <span className="font-mono font-black text-slate-900">{map.id}</span>
                    <span className="text-slate-400">•</span>
                    <span className="text-slate-500">
                      Registrado em {formatMapDate(map.createdAt).date} às {formatMapDate(map.createdAt).time}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider font-extrabold px-2 py-0.5 bg-slate-100 border border-slate-200 text-slate-800">
                      {map.macroProcessId}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap font-sans bg-slate-50 p-3 border border-slate-150">
                    {map.description}
                  </p>
                </div>

                <div className="shrink-0 flex md:flex-col items-end gap-2 justify-between h-full">
                  <span className="px-3 py-1 font-mono text-[10px] font-extrabold border border-amber-300 bg-amber-100 text-amber-800 rounded-full capitalize">
                    ● {map.status || "Aguardando Análise"}
                  </span>

                  <button
                    onClick={() => handleDelete(map.id)}
                    className="p-1.5 border border-transparent hover:border-rose-200 hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-all cursor-pointer rounded-none"
                    title="Remover"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 🔔 PREMIUM FLOAT TOAST NOTIFICATIONS */}
      {toasts.length > 0 && (
        <div className="fixed bottom-5 right-5 z-[9999] flex flex-col gap-3 max-w-sm w-full" id="toasts-container">
          {toasts.map((toast) => {
            let bgColor = "bg-white border-slate-900 text-slate-900";
            let icon = <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />;

            if (toast.type === "success") {
              bgColor = "bg-emerald-50 border-emerald-950 text-emerald-950";
              icon = <CheckCircle2 className="w-5.5 h-5.5 text-emerald-600 shrink-0" />;
            } else if (toast.type === "error") {
              bgColor = "bg-rose-50 border-rose-950 text-rose-950";
              icon = <AlertCircle className="w-5.5 h-5.5 text-rose-600 shrink-0" />;
            } else if (toast.type === "loading") {
              bgColor = "bg-slate-900 border-slate-950 text-white";
              icon = <Loader2 className="w-5.5 h-5.5 text-[#D1A142] animate-spin shrink-0" />;
            }

            return (
              <div
                key={toast.id}
                className={`flex items-start gap-3 p-4 border-2 shadow-[4px_4px_0px_rgba(0,0,0,1)] rounded-none animate-fadeIn ${bgColor}`}
                role="alert"
              >
                {icon}
                <div className="flex-1 text-xs font-bold leading-relaxed">
                  {toast.message}
                </div>
                <button
                  onClick={() => removeToast(toast.id)}
                  className="text-slate-400 hover:text-slate-900 shrink-0 transition-all p-0.5 cursor-pointer"
                  title="Fechar"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
