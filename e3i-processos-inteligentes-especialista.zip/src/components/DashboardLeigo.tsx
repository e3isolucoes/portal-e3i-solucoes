import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Flame, 
  Users, 
  Timer, 
  Sparkles, 
  HelpCircle, 
  ArrowRight, 
  Zap, 
  RefreshCw, 
  BarChart2, 
  TrendingUp, 
  CheckCircle2,
  Map,
  Flag,
  Plus,
  Trash2,
  Edit2,
  Check,
  Send,
  Loader2,
  MessageSquare,
  ClipboardList,
  CheckSquare,
  Square,
  Briefcase,
  Target,
  Award,
  Cpu,
  Layers,
  Info,
  FileText,
  Activity,
  Calendar,
  ChevronRight,
  Copy,
  ChevronDown,
  BookOpen,
  Lightbulb,
  Play,
  Home,
  Search,
  Compass,
  Heart,
  X,
  ChevronUp
} from "lucide-react";
import { ProcessStep, ProcessMetrics, ProjectCharter } from "../types";
import { calculateProcessMetrics } from "../utils";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import MapeadorDiagnostico360 from "./MapeadorDiagnostico360";
import { 
  collection, 
  addDoc, 
  setDoc,
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  serverTimestamp, 
  deleteDoc,
  doc 
} from "firebase/firestore";
import { LoggedUser } from "./AuthCover";
import MapeadorInicialProcessos from "./MapeadorInicialProcessos";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";

interface DashboardLeigoProps {
  stats: ProcessMetrics;
  steps: ProcessStep[];
  setSteps?: (steps: ProcessStep[]) => void;
  activeUser?: LoggedUser | null;
  businessType: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS";
  unitLabelPlural: string;
  arrivalRate: number;
  setArrivalRate?: (rate: number) => void;
  onNavigateToView?: (view: string) => void;
  globalCompanies?: any[];
  activeCompanyId?: string | null;
  setActiveCompanyId?: (id: string | null) => void;
  globalProjects?: any[];
  activeWorkspaceProjectId?: string | null;
  setActiveWorkspaceProjectId?: (id: string | null) => void;
  charter?: ProjectCharter;
  setCharter?: (charter: ProjectCharter) => void;
  onOpenOnboarding?: () => void;
}

export default function DashboardLeigo({
  stats,
  steps,
  setSteps,
  activeUser,
  businessType,
  unitLabelPlural,
  arrivalRate,
  setArrivalRate,
  onNavigateToView,
  globalCompanies = [],
  activeCompanyId = null,
  setActiveCompanyId,
  globalProjects = [],
  activeWorkspaceProjectId = null,
  setActiveWorkspaceProjectId,
  charter,
  setCharter,
  onOpenOnboarding
}: DashboardLeigoProps) {
  const [activeTab, setActiveTab] = useState<"inicio" | "diag" | "map" | "improve" | "specialist" | "tabela" | "mapeamento">("diag");
  const [showGlossary, setShowGlossary] = useState(false);
  const [showAnnotations, setShowAnnotations] = useState(true);

  // States for in-line project creation inside structural phases
  const [activeCreatingPhase, setActiveCreatingPhase] = useState<string | null>(null);
  const [newPhaseProjName, setNewPhaseProjName] = useState("");
  const [newPhaseProjObj, setNewPhaseProjObj] = useState("");
  const [selectedExistingProjId, setSelectedExistingProjId] = useState<Record<string, string>>({});

  // Auto tab selection fallback when no project is active
  useEffect(() => {
    if (!activeWorkspaceProjectId) {
      if (activeTab !== "diag" && activeTab !== "mapeamento") {
        setActiveTab("diag");
      }
    }
  }, [activeWorkspaceProjectId, activeTab]);

  const handleCreateAndLinkProject = (phaseName: string, projectName: string, projectObjective: string) => {
    if (!projectName.trim()) return;
    const email = activeUser?.email || "anonymous";
    const pid = "proj_" + Date.now().toString(36).substring(2, 6);
    
    // Create project object
    const newProject = {
      id: pid,
      companyId: activeCompanyId || "",
      name: projectName.trim(),
      objective: projectObjective.trim() || `Otimização DMAIC focada em ${phaseName}`,
      status: "Em Andamento" as const,
      createdAt: new Date().toISOString()
    };

    // Retrieve existing projects
    const currentProjs = CompanyProjectRepository.getProjects(email);
    // Save to repository
    CompanyProjectRepository.saveProjects([...currentProjs, newProject], email);

    // Set initial project template in local datastore
    const store = {
      steps: steps, // use currently configured steps
      arrivalRate: arrivalRate,
      charter: {
        id: "char_" + pid,
        title: newProject.name,
        businessCase: `Projeto iniciado a partir da fase: ${phaseName}`,
        problemStatement: `Problemas identificados e mapeados na etapa de estruturação de ${phaseName}.`,
        goalStatement: newProject.objective,
        scopeIn: "Escopo operacional delimitado pela estrutura.",
        scopeOut: "Áreas de suporte e controle financeiro corporativo.",
        team: "Grupo de Trabalho DMAIC: " + (activeUser?.fullName || "Analista Principal"),
        targetValue: 200
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(store, email);

    // Call state setters
    if (setActiveWorkspaceProjectId) {
      setActiveWorkspaceProjectId(pid);
    }
  };

  // Render Project selection/creation banner inside structuring tabs
  const renderProjectStructuralSelector = () => {
    const compProjects = globalProjects.filter((p: any) => p.companyId === activeCompanyId);
    
    const structurePhases = [
      {
        id: "fluxo_gargalos",
        title: "🎯 Fase de Fluxo & Capacidade (Gargalos)",
        description: "Otimização de postos de trabalho, redução de filas de espera, e balanceamento de linha operacional para máxima eficiência.",
        defaultProjName: "Otimização de Fluxo e Capacidade Operacional",
        defaultProjObj: "Reduzir o tempo de ciclo e eliminar gargalos identificados na estruturação da linha de fluxo."
      },
      {
        id: "sla_performance",
        title: "📋 Fase de Atendimento & SLA (Performance)",
        description: "Padronização do tempo de resposta, triagem de chamados/pedidos, e conformidade com metas contratuais de entrega (SLA).",
        defaultProjName: "Otimização de SLA e Performance de Atendimento",
        defaultProjObj: "Garantir a conformidade dos tempos de atendimento com os acordos de nível de serviço estabelecidos."
      },
      {
        id: "qualidade_desperdicios",
        title: "🛡️ Fase de Qualidade & Produtividade (Desperdícios)",
        description: "Mitigação de falhas humanas, prevenção de retrabalho na primeira passagem (First Pass Yield) e descarte de materiais/tempo.",
        defaultProjName: "Redução de Desperdícios e Garantia de Qualidade",
        defaultProjObj: "Aumentar a taxa de acerto perfeito e implementar controles estatísticos preventivos de qualidade."
      }
    ];

    const handleSelectExisting = (phaseId: string) => {
      const selectedId = selectedExistingProjId[phaseId];
      if (selectedId && setActiveWorkspaceProjectId) {
        setActiveWorkspaceProjectId(selectedId);
      }
    };

    const handleCreateNew = (phase: typeof structurePhases[0]) => {
      const name = newPhaseProjName.trim() || phase.defaultProjName;
      const obj = newPhaseProjObj.trim() || phase.defaultProjObj;
      handleCreateAndLinkProject(phase.title, name, obj);
      
      // Reset creation states
      setActiveCreatingPhase(null);
      setNewPhaseProjName("");
      setNewPhaseProjObj("");
    };

    return (
      <div className="bg-amber-50/50 border-2 border-amber-500/80 p-6 rounded-none space-y-6 shadow-[4px_4px_0px_0px_rgba(217,119,6,0.15)] mb-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xl">🏢</span>
              <h3 className="text-base md:text-lg font-serif font-black text-[#855B1B] uppercase tracking-tight">
                Vincule um Projeto DMAIC à Estrutura da Empresa
              </h3>
            </div>
            <p className="text-xs text-amber-900/85 leading-relaxed max-w-2xl font-medium">
              Você está visualizando a <strong>Estruturação da Empresa</strong>. Para liberar os simuladores avançados, gráficos estatísticos e acompanhar a evolução das metas, selecione um projeto existente ou crie um novo associado a uma das fases estruturais abaixo.
            </p>
          </div>
          <span className="text-[9px] bg-amber-500 text-white font-mono font-black tracking-widest px-2.5 py-1 rounded-none uppercase">
            ⚡ Requisito de Execução
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          {structurePhases.map((phase) => {
            const isCreating = activeCreatingPhase === phase.id;
            const currentSelectedId = selectedExistingProjId[phase.id] || "";

            return (
              <div 
                key={phase.id} 
                className="bg-white border border-slate-300 p-5 rounded-none flex flex-col justify-between hover:border-slate-500 transition-all shadow-3xs"
              >
                <div className="space-y-3">
                  <h4 className="text-xs font-serif font-black text-slate-900 uppercase tracking-wider pb-1.5 border-b border-slate-100">
                    {phase.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                    {phase.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 space-y-3">
                  {isCreating ? (
                    <div className="space-y-2 bg-slate-50 p-3 border border-slate-250">
                      <span className="text-[8.5px] font-mono text-[#855B1B] uppercase font-bold tracking-wider block">🆕 Criar Projeto DMAIC</span>
                      <input
                        type="text"
                        placeholder={`Ex: ${phase.defaultProjName}...`}
                        value={newPhaseProjName}
                        onChange={(e) => setNewPhaseProjName(e.target.value)}
                        className="w-full bg-white border border-slate-300 p-1.5 text-[11px] font-sans focus:outline-none focus:border-slate-800 text-slate-800"
                      />
                      <textarea
                        placeholder="Objetivo do projeto..."
                        value={newPhaseProjObj}
                        onChange={(e) => setNewPhaseProjObj(e.target.value)}
                        className="w-full bg-white border border-slate-300 p-1.5 text-[11px] h-12 resize-none focus:outline-none"
                      />
                      <div className="flex justify-end gap-1.5 pt-1">
                        <button 
                          type="button" 
                          onClick={() => setActiveCreatingPhase(null)} 
                          className="text-[9px] uppercase font-bold bg-white border border-slate-250 px-2 py-1 text-slate-500"
                        >
                          Cancelar
                        </button>
                        <button 
                          type="button" 
                          onClick={() => handleCreateNew(phase)} 
                          className="text-[9px] uppercase font-bold bg-amber-600 hover:bg-amber-700 text-white px-2.5 py-1"
                        >
                          Criar e Ativar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {compProjects.length > 0 ? (
                        <div className="space-y-1.5">
                          <label className="text-[8.5px] font-mono text-slate-400 uppercase tracking-wider block">Escolher Existente</label>
                          <div className="flex gap-1.5">
                            <select
                              value={currentSelectedId}
                              onChange={(e) => setSelectedExistingProjId(prev => ({ ...prev, [phase.id]: e.target.value }))}
                              className="flex-1 bg-slate-50 hover:bg-slate-100 border border-slate-300 px-2 py-1 text-[11px] font-semibold text-slate-800 cursor-pointer"
                            >
                              <option value="">-- Selecione --</option>
                              {compProjects.map((p: any) => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                              ))}
                            </select>
                            <button
                              type="button"
                              onClick={() => handleSelectExisting(phase.id)}
                              disabled={!currentSelectedId}
                              className="px-2.5 py-1 bg-slate-900 hover:bg-black disabled:bg-slate-100 disabled:text-slate-400 text-white text-[10px] font-bold uppercase transition-all"
                            >
                              Ativar
                            </button>
                          </div>
                        </div>
                      ) : (
                        <p className="text-[10px] text-slate-400 italic">Nenhum projeto cadastrado nesta empresa.</p>
                      )}

                      <div className="flex justify-center pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveCreatingPhase(phase.id);
                            setNewPhaseProjName("");
                            setNewPhaseProjObj("");
                          }}
                          className="text-[9.5px] uppercase font-bold text-amber-700 hover:text-amber-900 hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Plus size={11} /> Criar Novo para esta Fase
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderActiveProjectBadge = () => {
    if (!activeWorkspaceProjectId) return null;
    const activeProj = globalProjects.find((p: any) => p.id === activeWorkspaceProjectId);
    if (!activeProj) return null;

    return (
      <div className="bg-slate-50 border border-slate-250 p-3 rounded-none flex items-center justify-between gap-4 font-sans mb-4">
        <div className="flex items-center gap-2">
          <span className="text-emerald-500">🟢</span>
          <span className="text-xs text-slate-500 font-medium">Projeto DMAIC Ativo:</span>
          <strong className="text-xs text-slate-800 uppercase font-black tracking-tight">{activeProj.name}</strong>
        </div>
        <button
          type="button"
          onClick={() => setActiveWorkspaceProjectId && setActiveWorkspaceProjectId(null)}
          className="text-[9px] uppercase font-bold text-slate-500 hover:text-red-600 hover:underline cursor-pointer"
          title="Desconectar do projeto ativo para voltar a visualizar apenas a estruturação básica"
        >
          Desconectar Projeto
        </button>
      </div>
    );
  };

  // --- INICIO SIMPLIFIED MODE STATE ---
  const [simplifiedStep, setSimplifiedStep] = useState<"DEFINIR" | "MEDIR" | "ANALISAR" | "MELHORAR" | "CONTROLAR">("DEFINIR");
  const [selectedEmpresa, setSelectedEmpresa] = useState("1100 - E3I Soluções");
  const [selectedProjeto, setSelectedProjeto] = useState("Reduzir tempo de atendimento");
  
  // Glossary full list modal / display of terms Toggle
  const [showTermsModal, setShowTermsModal] = useState(false);

  // Simple checklist item check toggler states (saved in state so user can check/uncheck steps on screen!)
  const [checkedSubsteps, setCheckedSubsteps] = useState<Record<string, boolean>>({
    "DEFINIR_1": true,
    "DEFINIR_2": false,
    "DEFINIR_3": false,
    "MEDIR_1": true,
    "MEDIR_2": false,
    "MEDIR_3": false,
    "ANALISAR_1": true,
    "ANALISAR_2": false,
    "ANALISAR_3": false,
    "MELHORAR_1": true,
    "MELHORAR_2": false,
    "MELHORAR_3": false,
    "CONTROLAR_1": true,
    "CONTROLAR_2": true,
    "CONTROLAR_3": false,
  });

  const toggleSubstep = (id: string) => {
    setCheckedSubsteps(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Chatbot State
  const [chatHistory, setChatHistory] = useState<Array<{ role: "user" | "assistant"; text: string }>>([
    {
      role: "assistant",
      text: "Olá! Sou seu assistente de gestão Inteligente E3I. Como posso ajudar você hoje com seus objetivos de processos para as etapas do DMAIC?"
    }
  ]);
  const [userQuery, setUserQuery] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);

  const handleSendChat = async (messageText: string) => {
    if (!messageText.trim() || isChatLoading) return;
    
    const updatedHistory = [...chatHistory, { role: "user", text: messageText }];
    setChatHistory(updatedHistory);
    setUserQuery("");
    setIsChatLoading(true);
    
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (auth.currentUser) {
        try {
          const idToken = await auth.currentUser.getIdToken();
          headers["Authorization"] = `Bearer ${idToken}`;
        } catch (tokenErr) {
          console.warn("Failed to get ID Token for Chat:", tokenErr);
        }
      }

      const res = await fetch("/api/layperson-chat", {
        method: "POST",
        headers,
        body: JSON.stringify({ message: messageText, dmaicStep: simplifiedStep })
      });
      const data = await res.json();
      setChatHistory(prev => [...prev, { role: "assistant", text: data.reply || "Desculpe, não consegui obter resposta da IA." }]);
    } catch (error) {
      setChatHistory(prev => [...prev, { role: "assistant", text: "Erro ao se conectar ao assistente de IA. Certifique-se de configurar a API Key nas configurações do AI Studio!" }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // --- TABELA PERIÓDICA DA GESTÃO STATE ---
  const [activeTabelaElement, setActiveTabelaElement] = useState<string>("SWOT");
  const [swotStrengths, setSwotStrengths] = useState<string[]>(["Equipe resiliente e ágil", "Tecnologia de comunicação interna unificada", "Processo já mapeado e monitorado no painel"]);
  const [swotWeaknesses, setSwotWeaknesses] = useState<string[]>(["Frequência alta de retrabalho", "Falta de procedimentos padronizados (POP) formais", "Tempo de triagem ainda instável"]);
  const [swotOpportunities, setSwotOpportunities] = useState<string[]>(["Otimização automática baseada em simulações", "Treinamento focado e limites visuais de Kanban", "Integração estreita com as 2 esferas de KPI"]);
  const [swotThreats, setSwotThreats] = useState<string[]>(["Perda de contratos e quebra de SLA com clientes", "Sobrecarga de trabalho aumentando o estresse", "Dados faltantes na entrada travando o processo"]);
  const [newSwotItem, setNewSwotItem] = useState("");
  const [activeSwotQuadrant, setActiveSwotQuadrant] = useState<"strengths" | "weaknesses" | "opportunities" | "threats">("strengths");

  // 5W2H State
  const [fiveW2hWhat, setFiveW2hWhat] = useState("Reduzir tempo de execução no gargalo principal");
  const [fiveW2hWhy, setFiveW2hWhy] = useState("Eliminar o estresse da equipe e evitar as reclamações de atraso (SLA)");
  const [fiveW2hWhere, setFiveW2hWhere] = useState("Estação de trabalho gargalo");
  const [fiveW2hWho, setFiveW2hWho] = useState("Coordenador de Área e Operadores");
  const [fiveW2hWhen, setFiveW2hWhen] = useState("Até o próximo dia 15");
  const [fiveW2hHow, setFiveW2hHow] = useState("Simplificando as telas de dados e aplicando limites de WIP no Kanban");
  const [fiveW2hHowMuch, setFiveW2hHowMuch] = useState("Custo zero (apenas foco operacional)");
  const [fiveW2hPlans, setFiveW2hPlans] = useState<Array<{ id: string; what: string; why: string; where: string; who: string; when: string; how: string; howMuch: string; linked: boolean }>>([
    {
      id: "plan_1",
      what: "Padronizar o cadastro inicial de reclamações do cliente",
      why: "Evita que dados incompletos paralisem toda a esteira do processo",
      where: "Triagem",
      who: "Auxiliar de Atendimento",
      when: "Próxima terça-feira",
      how: "Disponibilizar check-box de preenchimento obrigatório inteligente",
      howMuch: "Grátis",
      linked: true
    }
  ]);

  // Ishikawa State
  const [ishikawaProblem, setIshikawaProblem] = useState("Lentidão nas entregas e retrabalho no posto principal");
  const [ishikawaMethod, setIshikawaMethod] = useState<string[]>(["Falta de manual passo-a-passo formalizado", "Inconsistência na triagem inicial"]);
  const [ishikawaMachine, setIshikawaMachine] = useState<string[]>(["Sistemas internos com carregamento demorado", "Falta de notificações automáticas"]);
  const [ishikawaMeasurement, setIshikawaMeasurement] = useState<string[]>(["Poucos indicadores de meio mapeados online", "Foco apenas na verificação de resultado"]);
  const [ishikawaEnvironment, setIshikawaEnvironment] = useState<string[]>(["Ruído de conversas acima do confortável", "Bancadas sem marcações visuais claras"]);
  const [ishikawaManpower, setIshikawaManpower] = useState<string[]>(["Novos integrantes sem treinamento do fluxo", "Esgotamento devido a picos não gerenciados"]);
  const [ishikawaMaterial, setIshikawaMaterial] = useState<string[]>(["Dados de clientes sem validação de entrada", "Instruções desatualizadas ou rasuradas"]);
  const [newIshikawaCause, setNewIshikawaCause] = useState("");
  const [activeIshikawaCategory, setActiveIshikawaCategory] = useState<string>("method");

  // FMEA State
  const [fmeaFailureMode, setFmeaFailureMode] = useState("Cliente envia formulário faltando campos");
  const [fmeaSeverity, setFmeaSeverity] = useState<number>(8);
  const [fmeaOccurrence, setFmeaOccurrence] = useState<number>(6);
  const [fmeaDetection, setFmeaDetection] = useState<number>(4);
  const [fmeaRecords, setFmeaRecords] = useState<Array<{ id: string; stepName: string; failureMode: string; s: number; o: number; d: number; rpn: number }>>([
    {
      id: "fmea_1",
      stepName: "Mapeamento Primário",
      failureMode: "Item entra no fluxo sem a triagem correta realizada",
      s: 7,
      o: 5,
      d: 4,
      rpn: 140
    }
  ]);

  // Pop State
  const [popSelectedStepId, setPopSelectedStepId] = useState<string>("");

  // OEE State
  const [oeeAvailability, setOeeAvailability] = useState<number>(92);
  const [oeePerformance, setOeePerformance] = useState<number>(88);
  const [oeeQuality, setOeeQuality] = useState<number>(96);

  // OKRs State
  const [okrsList, setOkrsList] = useState<Array<{ id: string; objective: string; kr1: string; kr1Val: number; kr1Target: number; kr2: string; kr2Val: number; kr2Target: number }>>([
    {
      id: "okr_1",
      objective: "Alcançar Resposta Ultra-Rápida e Blindar o Processo",
      kr1: "Diminuir Lead Time de Processamento Médio",
      kr1Val: 18,
      kr1Target: 10,
      kr2: "Assegurar Rendimento Global (FTY) Estável",
      kr2Val: 85,
      kr2Target: 95
    }
  ]);

  // --- MAPPING FORM STATE ---
  const [isAddingStep, setIsAddingStep] = useState(false);
  const [newStepName, setNewStepName] = useState("");
  const [newStepResource, setNewStepResource] = useState("");
  const [newStepResourceCount, setNewStepResourceCount] = useState(1);
  const [newStepProcessingTime, setNewStepProcessingTime] = useState(5);
  const [newStepFailureRate, setNewStepFailureRate] = useState(0.05); // Friendly translation of yieldRate
  const [newStepDescription, setNewStepDescription] = useState("");

  const [editingStepId, setEditingStepId] = useState<string | null>(null);
  const [editStepName, setEditStepName] = useState("");
  const [editStepResource, setEditStepResource] = useState("");
  const [editStepResourceCount, setEditStepResourceCount] = useState(1);
  const [editStepProcessingTime, setEditStepProcessingTime] = useState(5);
  const [editStepFailureRate, setEditStepFailureRate] = useState(0.05);
  const [editStepDescription, setEditStepDescription] = useState("");

  // --- IMPROVEMENT TASKS (KAIZEN CHECKS) ---
  const [improvementTasks, setImprovementTasks] = useState<{ id: string; text: string; done: boolean }[]>([]);
  const [newTaskText, setNewTaskText] = useState("");

  // --- GEMINI LAYPERSON IMPROVEMENT ADVISOR STATE ---
  const [aiDiagnostic, setAiDiagnostic] = useState<string | null>(null);
  const [aiRecommendations, setAiRecommendations] = useState<{ title: string; description: string; expectedBenefit: string }[]>([]);
  const [aiAnalogy, setAiAnalogy] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // --- SPECIALIST ASSISTANCE FORM STATE ---
  const [specialistSubject, setSpecialistSubject] = useState("");
  const [specialistProblem, setSpecialistProblem] = useState("");
  const [specialistContact, setSpecialistContact] = useState("");
  const [specialistUrgency, setSpecialistUrgency] = useState<"Baixa" | "Média" | "Alta">("Média");
  const [isSubmittingSpecialist, setIsSubmittingSpecialist] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);
  const [submittedRequests, setSubmittedRequests] = useState<any[]>([]);

  // --- INITIAL PROCESS MAPPINGS STATE & FORM ---
  const [initialMappings, setInitialMappings] = useState<any[]>([]);
  const [mappingDesc, setMappingDesc] = useState("");
  const [mappingMacroId, setMappingMacroId] = useState("");
  const [isSubmittingMapping, setIsSubmittingMapping] = useState(false);
  const [mappingSuccess, setMappingSuccess] = useState<string | null>(null);
  const [mappingError, setMappingError] = useState<string | null>(null);

  const getMacroProcessesForType = (type: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS") => {
    switch (type) {
      case "INDUSTRIAL":
        return [
          { id: "M1", name: "M1 - Gestão de Suprimentos e Matéria-Prima" },
          { id: "M2", name: "M2 - Produção e Montagem na Linha de Fábrica" },
          { id: "M3", name: "M3 - Controle de Qualidade e Inspeção Técnica" },
          { id: "M4", name: "M4 - Armazenamento, Embalagem e Distribuição" },
          { id: "M5", name: "M5 - Manutenção Preventiva e Calibração de Máquinas" }
        ];
      case "SERVICES":
        return [
          { id: "M1", name: "M1 - Atendimento Inicial e Triagem de Solicitações" },
          { id: "M2", name: "M2 - Execução e Entrega do Serviço Especializado" },
          { id: "M3", name: "M3 - Gestão de Contratos e Suporte ao Cliente (SLA)" },
          { id: "M4", name: "M4 - Faturamento, Cobrança e Conciliação Financeira" },
          { id: "M5", name: "M5 - Garantia da Qualidade e Pós-Venda" }
        ];
      case "RETAIL":
        return [
          { id: "M1", name: "M1 - Compras, Negociação e Gestão de Fornecedores" },
          { id: "M2", name: "M2 - Recebimento, Conferência e Armazenagem" },
          { id: "M3", name: "M3 - Exposição, Vendas e Atendimento de Frente de Loja" },
          { id: "M4", name: "M4 - Checkout, Faturamento e Meios de Pagamento" },
          { id: "M5", name: "M5 - Gestão de Devoluções e Trocas" }
        ];
      case "LOGISTICS":
        return [
          { id: "M1", name: "M1 - Recebimento de Cargas e Conferência de Docas" },
          { id: "M2", name: "M2 - Armazenamento e Endereçamento Inteligente" },
          { id: "M3", name: "M3 - Picking (Separação) e Embalagem (Packing)" },
          { id: "M4", name: "M4 - Planejamento de Rotas e Distribuição (Last-Mile)" },
          { id: "M5", name: "M5 - Logística Reversa e Controle de Avarias" }
        ];
      default:
        return [
          { id: "M1", name: "M1 - Processos Operacionais Gerais" },
          { id: "M2", name: "M2 - Administrativo e Gestão" },
          { id: "M3", name: "M3 - Relacionamento com Clientes" }
        ];
    }
  };

  const macros = getMacroProcessesForType(businessType);

  useEffect(() => {
    if (macros.length > 0) {
      setMappingMacroId(macros[0].id);
    }
  }, [businessType]);

  // Load existing process mappings for the active user using onSnapshot
  useEffect(() => {
    const isSandboxMode = typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true";
    
    if (!auth.currentUser) {
      if (isSandboxMode) {
        setInitialMappings([
          {
            id: "MAP_SANDBOX_7483",
            companyId: activeCompanyId || "comp-default",
            macroProcessId: "M2 - Produção e Montagem na Linha de Fábrica",
            description: "No setor de montagem, as peças chegam da fundição e são colocadas na esteira. O operador para a esteira a cada 15 minutos para parafusar a tampa. Às vezes faltam parafusos e o processo para totalmente.",
            userId: "sandbox-user",
            status: "Aguardando Análise",
            createdAt: new Date(Date.now() - 3600000 * 2)
          }
        ]);
      }
      return;
    }

    const q = query(
      collection(db, "initial_process_mappings"),
      where("userId", "==", auth.currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          ...data,
          createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt)) : new Date()
        });
      });
      // Sort client side
      list.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      setInitialMappings(list);
    }, (error) => {
      console.warn("Utilizando cache ou fallback local para mapeamento inicial de processos:", error.message || error);
      if (isSandboxMode) {
        setInitialMappings([
          {
            id: "MAP_SANDBOX_7483",
            companyId: activeCompanyId || "comp-default",
            macroProcessId: "M2 - Produção e Montagem na Linha de Fábrica",
            description: "No setor de montagem, as peças chegam da fundição e são colocadas na esteira. O operador para a esteira a cada 15 minutos para parafusar a tampa. Às vezes faltam parafusos e o processo para totalmente.",
            userId: "sandbox-user",
            status: "Aguardando Análise",
            createdAt: new Date(Date.now() - 3600000 * 2)
          }
        ]);
      } else {
        setInitialMappings([]);
      }
    });

    return () => unsubscribe();
  }, [activeUser, activeCompanyId]);

  // Initialize friendly improvement tasks and synchronize them with Firestore in real-time
  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, "layperson_tasks"),
      where("userId", "==", auth.currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          text: data.text,
          done: !!data.done,
          createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt)) : new Date()
        });
      });
      
      // Sort tasks by creation time so they retain correct order
      list.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
      
      if (list.length > 0) {
        setImprovementTasks(list);
      } else {
        // Pre-populate defaults in Firestore
        let defaultTexts: string[] = [];
        if (businessType === "SERVICES") {
          defaultTexts = [
            "Eliminar aprovações desnecessárias para liberar o gargalo do atendimento",
            "Dividir os chamados simples dos complexos na triagem",
            "Configurar respostas rápidas prontas para dúvidas comuns"
          ];
        } else if (businessType === "INDUSTRIAL") {
          defaultTexts = [
            "Organizar ferramentas na bancada principal com marcações táteis",
            "Limpar o posto gargalo antes de ligar os motores para evitar paradas",
            "Implementar caixa de conferência visual rápida na saída da prensa"
          ];
        } else if (businessType === "RETAIL") {
          defaultTexts = [
            "Separar o operador de caixa para focar apenas nas compras físicas",
            "Deixar troco facilitado em recipientes organizados",
            "Sinalizar a fila preferencial de forma legível"
          ];
        } else {
          defaultTexts = [
            "Organizar as prateleiras de insumos por ordem de saída frequente",
            "Criar checklist de expedição de embalagem rápida",
            "Fazer manutenção periódica dos pallets de movimentação"
          ];
        }

        if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
          const fakeList = defaultTexts.map((t, i) => ({
            id: `task_${Date.now()}_${i}`,
            text: t,
            done: false,
            createdAt: new Date(Date.now() + i * 1000)
          }));
          setImprovementTasks(fakeList);
          return;
        }

        defaultTexts.forEach(async (t, i) => {
          const taskId = `task_${Date.now()}_${i}`;
          try {
            await setDoc(doc(db, "layperson_tasks", taskId), {
              id: taskId,
              userId: auth.currentUser!.uid,
              text: t,
              done: false,
              createdAt: new Date(Date.now() + i * 1000)
            });
          } catch (err) {
            handleFirestoreError(err, OperationType.CREATE, `layperson_tasks/${taskId}`);
          }
        });
      }
    }, (error) => {
      console.warn("Erro de permissões ou rede no Firestore. Utilizando cache e dados locais para layperson_tasks :", error.message || error);
      
      // Load friendly local custom defaults instead of logging user blocker
      let defaultTexts: string[] = [];
      if (businessType === "SERVICES") {
        defaultTexts = [
          "Eliminar aprovações desnecessárias para liberar o gargalo do atendimento",
          "Dividir os chamados simples dos complexos na triagem",
          "Configurar respostas rápidas prontas para dúvidas comuns"
        ];
      } else if (businessType === "INDUSTRIAL") {
        defaultTexts = [
          "Organizar ferramentas na bancada principal com marcações táteis",
          "Limpar o posto gargalo antes de ligar os motores para evitar paradas",
          "Implementar caixa de conferência visual rápida na saída da prensa"
        ];
      } else if (businessType === "RETAIL") {
        defaultTexts = [
          "Separar o operador de caixa para focar apenas nas compras físicas",
          "Deixar troco facilitado em recipientes organizados",
          "Sinalizar a fila preferencial de forma legível"
        ];
      } else {
        defaultTexts = [
          "Organizar as prateleiras de insumos por ordem de saída frequente",
          "Criar checklist de expedição de embalagem rápida",
          "Fazer manutenção periódica dos pallets de movimentação"
        ];
      }
      
      const localLoaded = defaultTexts.map((text, idx) => ({
        id: `local_resilient_${idx}`,
        text,
        done: false,
        createdAt: new Date()
      }));
      setImprovementTasks(localLoaded);
    });

    return () => unsubscribe();
  }, [activeUser, businessType]);

  // Load existing specialist requests for the active user using onSnapshot
  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, "specialist_requests"),
      where("userId", "==", auth.currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          ...data,
          // Handle serverTimestamp fallback elegantly in UI
          createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt)) : new Date()
        });
      });
      // Sort client side
      list.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      setSubmittedRequests(list);
    }, (error) => {
      console.warn("Utilizando cache ou fallback local para solicitações de especialista:", error.message || error);
      
      // Robust empty load fallback
      setSubmittedRequests([]);
    });

    return () => unsubscribe();
  }, [activeUser]);

  // Synchronize first step as default selection for FMEA and POP dropdowns
  useEffect(() => {
    if (steps && steps.length > 0) {
      if (!popSelectedStepId) {
        setPopSelectedStepId(steps[0].id);
      }
    }
  }, [steps, popSelectedStepId]);

  // --- ANTES x DEPOIS SIMULATION COMPUTATIONS ---
  const antesSteps = steps.map(s => {
    const standardDeviation = parseFloat((s.standardDeviation * 1.35).toFixed(2));
    const yieldRate = parseFloat(Math.max(0.72, s.yieldRate - 0.035).toFixed(3));
    let processingTime = s.processingTime;
    let resourceCount = s.resourceCount;
    const isBottleneck = s.name === stats.bottleneckStepName;
    if (isBottleneck) {
      processingTime = parseFloat((s.processingTime + 1.5).toFixed(1));
      if (s.resourceCount > 1) {
        resourceCount = s.resourceCount - 1;
      }
    }
    return { ...s, standardDeviation, yieldRate, processingTime, resourceCount };
  });

  const depoisSteps = steps.map(s => {
    const standardDeviation = parseFloat((s.standardDeviation * 0.73).toFixed(2));
    const yieldRate = parseFloat(Math.min(0.999, s.yieldRate + 0.03).toFixed(3));
    let processingTime = s.processingTime;
    let resourceCount = s.resourceCount;
    const isBottleneck = s.name === stats.bottleneckStepName;
    if (isBottleneck) {
      processingTime = parseFloat(Math.max(0.5, s.processingTime - 1.5).toFixed(1));
      resourceCount = Math.min(5, s.resourceCount + 1);
    }
    return { ...s, standardDeviation, yieldRate, processingTime, resourceCount };
  });

  const antesStats = calculateProcessMetrics(antesSteps, arrivalRate);
  const depoisStats = calculateProcessMetrics(depoisSteps, arrivalRate);

  // Health Status Helpers
  const getUtilizationStatus = (util: number) => {
    if (util < 70) {
      return {
        label: "Excelente / Operação Livre",
        sub: "O fluxo corre tranquilamente. O pessoal dá conta das tarefas sem que novos pedidos virem filas irritantes.",
        color: "text-emerald-700 bg-emerald-50 border-emerald-300",
        badge: "🟢 SAUDÁVEL",
        indicatorColor: "bg-emerald-500"
      };
    } else if (util <= 90) {
      return {
        label: "Atenção / Ocupado de mais",
        sub: "Estamos perto do limite. Pequenos acúmulos temporários vão gerar gargalos e estresse na equipe.",
        color: "text-amber-700 bg-amber-50 border-amber-300",
        badge: "🟡 ALERTA",
        indicatorColor: "bg-amber-500"
      };
    } else {
      return {
        label: "Crítico / Risco de Congestionamento",
        sub: "Chega mais pedido do que a equipe consegue liberar. A fila vai crescer eternamente gerando grandes atrasos!",
        color: "text-rose-700 bg-rose-50 border-rose-300",
        badge: "🔴 IMEDIATO",
        indicatorColor: "bg-rose-500"
      };
    }
  };

  const getQualityStatus = (yieldRate: number) => {
    const pct = yieldRate * 100;
    if (pct >= 95) {
      return {
        label: "Qualidade Excelente / Sem Falhas",
        sub: "Tudo é feito corretamente de primeira. Quase nenhum desperdício de tempo corrigindo ou refeito trabalhos.",
        color: "text-emerald-700 bg-emerald-50 border-emerald-300",
        badge: "🟢 EXCELENTE",
        indicatorColor: "bg-emerald-500"
      };
    } else if (pct >= 85) {
      return {
        label: "Qualidade Regular",
        sub: "Alguns erros pontuais exigem refações ou duplas validações, reduzindo o ritmo da melhoria.",
        color: "text-amber-700 bg-amber-50 border-amber-300",
        badge: "🟡 REVISAR",
        indicatorColor: "bg-amber-500"
      };
    } else {
      return {
        label: "Erros Excessivos / Retrabalhos Altos",
        sub: "Muito retrabalho. Praticamente um em cada cinco itens exige conserto manual cabo-a-cabo, perdendo faturamento e irritando clientes.",
        color: "text-rose-700 bg-rose-50 border-rose-300",
        badge: "🔴 PREOCUPANTE",
        indicatorColor: "bg-rose-500"
      };
    }
  };

  const touchTime = stats.processingTimeSum || 1;
  const ratio = stats.leadTime / touchTime;
  const getDelayStatus = (r: number) => {
    if (r <= 1.5) {
      return {
        label: "Sem Atrasos de Fila",
        sub: "O tempo que o cliente aguarda é exatamente o tempo útil gasto trabalhando na ficha. Muito produtivo!",
        color: "text-emerald-700 bg-emerald-50 border-emerald-300",
        badge: "🟢 FLUIDO",
        indicatorColor: "bg-emerald-500"
      };
    } else if (r <= 3.0) {
      return {
        label: "Demora Moderada na Espera",
        sub: "O serviço passa de metade do trâmite parado em caixas de entrada virtuais por causa do excesso temporário de tarefas.",
        color: "text-amber-700 bg-amber-50 border-amber-300",
        badge: "🟡 ESPERA MÉDIA",
        indicatorColor: "bg-amber-500"
      };
    } else {
      return {
        label: "Atraso Extremo / Gargalo Travado",
        sub: "O pedido fica praticamente parado pegando poeira no computador antes de ser pego pela equipe.",
        color: "text-rose-700 bg-rose-50 border-rose-300",
        badge: "🔴 CONGESTIONADO",
        indicatorColor: "bg-rose-500"
      };
    }
  };

  const utilizationHealth = getUtilizationStatus(stats.systemUtilization);
  const qualityHealth = getQualityStatus(stats.rolledFirstPassYield);
  const delayHealth = getDelayStatus(ratio);

  // Friendly texts based on businessType
  const industryFriendlyTerms = {
    INDUSTRIAL: {
      capacityTitle: "Capacidade da Linha",
      capacityDesc: "Quantidade de produtos prontos por hora.",
      wipDesc: "Materiais parados na bancada física esperando montagem.",
      leadTimeDesc: "Tempo para transformar a matéria-prima em produto embalado de saída.",
      stepLabel: "Fase do Equipamento"
    },
    SERVICES: {
      capacityTitle: "Capacidade de Atendimento",
      capacityDesc: "Solicitações ou e-mails finalizados por hora.",
      wipDesc: "Documentos e planilhas abertos aguardando análise na caixa de entrada.",
      leadTimeDesc: "Tempo do primeiro clique do cliente até a entrega da solução resolvida.",
      stepLabel: "Setor de Análise"
    },
    RETAIL: {
      capacityTitle: "Vendas Concluídas",
      capacityDesc: "Fluxo de clientes pagos e despachados por hora.",
      wipDesc: "Pessoas esperando em pé próximas aos guichês.",
      leadTimeDesc: "Tempo desde a entrada na fila até sair com a nota e sacola na mão.",
      stepLabel: "Fase de Compra"
    },
    LOGISTICS: {
      capacityTitle: "Vazão de Despachos",
      capacityDesc: "Pacotes ou lotes triados e carregados por hora.",
      wipDesc: "Caixas e paletes parados na doca aguardando veículo.",
      leadTimeDesc: "Tempo desde que o pedido cai no terminal até o caminhão receber sinal de partida.",
      stepLabel: "Ponto de Controle"
    }
  }[businessType];

  // --- ACTIONS FOR PROCESS MAPPING ---
  const handleAddNewStep = () => {
    if (!setSteps) return;
    if (!newStepName.trim()) {
      alert("Por favor, digite o nome da etapa para mapear!");
      return;
    }

    const nStep: ProcessStep = {
      id: `step_${Date.now()}`,
      name: newStepName,
      resource: newStepResource || "Colaborador",
      resourceCount: newStepResourceCount,
      processingTime: newStepProcessingTime,
      standardDeviation: parseFloat((newStepProcessingTime * 0.2).toFixed(2)),
      yieldRate: 1 - newStepFailureRate,
      setupTime: 0,
      description: newStepDescription || "Nova etapa mapeada."
    };

    setSteps([...steps, nStep]);

    // Reset Form
    setNewStepName("");
    setNewStepResource("");
    setNewStepResourceCount(1);
    setNewStepProcessingTime(5);
    setNewStepFailureRate(0.05);
    setNewStepDescription("");
    setIsAddingStep(false);
  };

  const handleStartEdit = (step: ProcessStep) => {
    setEditingStepId(step.id);
    setEditStepName(step.name);
    setEditStepResource(step.resource);
    setEditStepResourceCount(step.resourceCount);
    setEditStepProcessingTime(step.processingTime);
    setEditStepFailureRate(parseFloat((1 - step.yieldRate).toFixed(2)));
    setEditStepDescription(step.description || "");
  };

  const handleSaveEdit = () => {
    if (!setSteps || !editingStepId) return;
    if (!editStepName.trim()) {
      alert("Por favor, digite o nome da etapa!");
      return;
    }

    const updated = steps.map(s => {
      if (s.id === editingStepId) {
        return {
          ...s,
          name: editStepName,
          resource: editStepResource || "Colaborador",
          resourceCount: editStepResourceCount,
          processingTime: editStepProcessingTime,
          standardDeviation: parseFloat((editStepProcessingTime * 0.2).toFixed(2)),
          yieldRate: 1 - editStepFailureRate,
          description: editStepDescription
        };
      }
      return s;
    });

    setSteps(updated);
    setEditingStepId(null);
  };

  const handleDeleteStep = (id: string) => {
    if (!setSteps) return;
    if (steps.length <= 1) {
      alert("O processo precisa ter pelo menos 1 etapa cadastrada!");
      return;
    }
    if (confirm("Gostaria de realmente remover esta etapa do desenho do fluxo?")) {
      setSteps(steps.filter(s => s.id !== id));
    }
  };

  // --- ACTIONS FOR 1-CLICK INSTANT IMPROVEMENT KAIZEN ---
  const applyImprovementAction = (actionType: "bottleneck_staff" | "bottleneck_speed" | "quality_zero") => {
    if (!setSteps || steps.length === 0) return;

    let updated = [...steps];
    if (actionType === "bottleneck_staff") {
      updated = steps.map(s => {
        if (s.name === stats.bottleneckStepName) {
          return { ...s, resourceCount: s.resourceCount + 1 };
        }
        return s;
      });
      alert(`⚡ Kaizen Aplicado! Adicionamos +1 colaborador temporário para apoiar no posto '${stats.bottleneckStepName}'. Veja os semáforos recalculados!`);
    } else if (actionType === "bottleneck_speed") {
      updated = steps.map(s => {
        if (s.name === stats.bottleneckStepName) {
          return { ...s, processingTime: Math.max(0.5, parseFloat((s.processingTime * 0.5).toFixed(1))) };
        }
        return s;
      });
      alert(`⚡ Kaizen Aplicado! Uma automação simples cortou o tempo de execução no gargalo '${stats.bottleneckStepName}' pela metade. Menos filas!`);
    } else if (actionType === "quality_zero") {
      // Find step with lowest yield
      let lowestYield = 1.0;
      steps.forEach(s => { if (s.yieldRate < lowestYield) lowestYield = s.yieldRate; });
      
      updated = steps.map(s => {
        if (s.yieldRate === lowestYield) {
          return { ...s, yieldRate: 0.99 }; // 99% accuracy
        }
        return s;
      });
      alert(`⚡ Kaizen Aplicado! Fornecemos um formulário inteligente e treinamento para eliminar quase 100% dos erros do posto menos preciso.`);
    }

    setSteps(updated);
  };

  // --- KAIZEN CHECKLIST ---
  const handleToggleTask = async (id: string, currentDone: boolean) => {
    if (!auth.currentUser) return;
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      setImprovementTasks(prev => prev.map(t => t.id === id ? { ...t, done: !currentDone } : t));
      return;
    }
    try {
      await setDoc(doc(db, "layperson_tasks", id), {
        done: !currentDone
      }, { merge: true });
    } catch (e) {
      console.error("Erro ao alterar tarefa: ", e);
    }
  };

  const handleAddImprovementTask = async () => {
    if (!newTaskText.trim() || !auth.currentUser) return;
    const taskId = `task_${Date.now()}`;
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      const newTask = {
        id: taskId,
        text: newTaskText.trim(),
        done: false,
        createdAt: new Date()
      };
      setImprovementTasks(prev => [...prev, newTask]);
      setNewTaskText("");
      return;
    }
    try {
      await setDoc(doc(db, "layperson_tasks", taskId), {
        id: taskId,
        userId: auth.currentUser.uid,
        text: newTaskText.trim(),
        done: false,
        createdAt: new Date()
      });
      setNewTaskText("");
    } catch (e) {
      console.error("Erro ao adicionar tarefa: ", e);
    }
  };

  const handleDeleteTask = async (id: string) => {
    if (!auth.currentUser) return;
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      setImprovementTasks(prev => prev.filter(t => t.id !== id));
      return;
    }
    try {
      await deleteDoc(doc(db, "layperson_tasks", id));
    } catch (e) {
      console.error("Erro ao remover tarefa: ", e);
    }
  };

  const handleSubAddTaskKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleAddImprovementTask();
    }
  };

  const handleRequestAiImprovement = async () => {
    setIsAiLoading(true);
    setAiError(null);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (auth.currentUser) {
        try {
          const idToken = await auth.currentUser.getIdToken();
          headers["Authorization"] = `Bearer ${idToken}`;
        } catch (tokenErr) {
          console.warn("Failed to get ID Token for Improvement:", tokenErr);
        }
      }

      const response = await fetch("/api/layperson-improve", {
        method: "POST",
        headers,
        body: JSON.stringify({
          steps: steps.map(s => ({
            name: s.name,
            resource: s.resource || "Equipe",
            resourceCount: s.resourceCount,
            processingTime: s.processingTime,
            yieldRate: s.yieldRate,
            description: s.description || ""
          })),
          arrivalRate
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Erro ao consultar o servidor da IA.");
      }

      const data = await response.json();
      setAiDiagnostic(data.diagnostic);
      setAiRecommendations(data.recommendations);
      setAiAnalogy(data.funnyAnalogy);
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "Erro ao consultar a Inteligência Artificial. Verifique se a sua chave do Gemini está cadastrada nas configurações.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleAddAiRecommendationToTasks = async (recTitle: string, recDesc: string) => {
    if (!auth.currentUser) return;
    const taskId = `task_${Date.now()}_ai`;
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      const newTask = {
        id: taskId,
        text: `${recTitle}: ${recDesc}`,
        done: false,
        createdAt: new Date()
      };
      setImprovementTasks(prev => [...prev, newTask]);
      alert(`💡 Adicionado com sucesso! A melhoria foi salva (modo sandbox) e vinculada ao seu plano Kaizen.`);
      return;
    }
    try {
      await setDoc(doc(db, "layperson_tasks", taskId), {
        id: taskId,
        userId: auth.currentUser.uid,
        text: `${recTitle}: ${recDesc}`,
        done: false,
        createdAt: new Date()
      });
      alert(`💡 Adicionado com sucesso! A melhoria foi salva e vinculada ao seu plano Kaizen.`);
    } catch (e) {
      console.error("Erro ao salvar recomendação da IA: ", e);
    }
  };

  // --- ACTIONS FOR INITIAL PROCESS MAPPING ---
  const handleSubmitMapping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mappingDesc.trim() || !mappingMacroId || isSubmittingMapping) {
      alert("Por favor, preencha a descrição do processo!");
      return;
    }

    setIsSubmittingMapping(true);
    setMappingSuccess(null);
    setMappingError(null);

    const mappingId = `MAP_${Math.floor(100000 + Math.random() * 900000)}`;
    const userUid = auth.currentUser?.uid || "anonymous";
    const companyId = activeCompanyId || globalCompanies[0]?.id || "comp-default";
    const selectedMacroObj = macros.find(m => m.id === mappingMacroId);
    const selectedMacroName = selectedMacroObj ? selectedMacroObj.name : mappingMacroId;

    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      setTimeout(() => {
        setIsSubmittingMapping(false);
        setMappingSuccess(mappingId);
        
        // Add to local state history
        const newLocalMapping = {
          id: mappingId,
          companyId: companyId,
          macroProcessId: selectedMacroName,
          description: mappingDesc,
          userId: userUid,
          status: "Aguardando Análise",
          createdAt: new Date()
        };
        setInitialMappings(prev => [newLocalMapping, ...prev]);
        setMappingDesc("");
      }, 650);
      return;
    }

    try {
      await setDoc(doc(db, "initial_process_mappings", mappingId), {
        id: mappingId,
        companyId: companyId,
        macroProcessId: selectedMacroName,
        description: mappingDesc,
        userId: userUid,
        status: "Aguardando Análise",
        createdAt: serverTimestamp()
      });

      setMappingSuccess(mappingId);
      setMappingDesc("");
    } catch (err: any) {
      console.error("Falha ao salvar mapeamento inicial no Firestore: ", err);
      setMappingError("Erro de permissões ou de conexão ao salvar mapeamento.");
    } finally {
      setIsSubmittingMapping(false);
    }
  };

  const handleDeleteMapping = async (id: string) => {
    if (!window.confirm("Deseja realmente remover este mapeamento de processo?")) return;

    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      setInitialMappings(prev => prev.filter(m => m.id !== id));
      return;
    }

    try {
      await deleteDoc(doc(db, "initial_process_mappings", id));
      alert("Mapeamento excluído com sucesso!");
    } catch (err: any) {
      console.error("Erro ao deletar mapeamento: ", err);
      alert("Não foi possível excluir o mapeamento.");
    }
  };

  // --- ACTIONS FOR SPECIALIST SOLICITATION SUPPORT ---
  const handleSubmitSpecialist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      alert("Acesso restrito. Você precisa estar autenticado para abrir chamações ao especialista!");
      return;
    }
    if (!specialistSubject.trim() || !specialistProblem.trim()) {
      alert("Por favor preencha todos os campos da sua dúvida!");
      return;
    }

    setIsSubmittingSpecialist(true);
    setSubmitSuccess(null);

    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      setTimeout(() => {
        setIsSubmittingSpecialist(false);
        setSubmitSuccess(`SOL_SANDBOX_${Math.floor(1000 + Math.random() * 9000)}`);
      }, 650);
      return;
    }

    try {
      const requestId = `SOL_${Math.floor(1000 + Math.random() * 9000)}`;
      await setDoc(doc(db, "specialist_requests", requestId), {
        id: requestId,
        userId: auth.currentUser.uid,
        userEmail: activeUser?.email || auth.currentUser.email || "leigo@optima.com",
        userName: activeUser?.fullName || "Cliente Leigo",
        companyName: activeUser?.planHired || "Minha Empresa",
        processName: specialistSubject,
        description: specialistProblem,
        urgency: specialistUrgency,
        contact: specialistContact || "Não informado",
        status: "Pendente",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      setSubmitSuccess(requestId);
      setSpecialistSubject("");
      setSpecialistProblem("");
      setSpecialistContact("");
    } catch (err: any) {
      console.error("Falha ao abrir chamado de especialista no Firestore: ", err);
      alert("Ocorreu um erro ao enviar a solicitação. Por favor, tente novamente.");
    } finally {
      setIsSubmittingSpecialist(false);
    }
  };

  return (
    <div id="layperson-dashboard-workspace" className="space-y-6 text-left font-sans max-w-7xl mx-auto px-1">
      
      {/* 👑 PROPOSTA DE FLUXO SIMPLIFICADO MAIN TITLE HEADER BANNER (ESTILO IMAGEM) */}
      <div className="text-center space-y-2 mb-4 animate-fadeIn">
        <h1 className="text-2xl md:text-3.5xl font-serif font-black text-[#0B2545] uppercase tracking-tight">
          E3I — Proposta de Fluxo Simplificado para Usuários Leigos
        </h1>
        <p className="text-xs md:text-sm text-slate-500 font-sans tracking-wide max-w-2xl mx-auto">
          Redesenho da jornada para deixar a ferramenta mais clara, guiada e fácil de usar.
        </p>
        <div className="w-20 h-1.5 bg-[#D1A142] mx-auto rounded-full mt-2"></div>
        
        {/* Toggle option for annotations */}
        <div className="pt-2 flex items-center justify-center gap-2">
          <label className="text-[10px] font-mono uppercase tracking-wider font-bold text-slate-450 cursor-pointer flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-sm select-none hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              checked={showAnnotations}
              onChange={(e) => setShowAnnotations(e.target.checked)}
              className="rounded-none border-gray-300 text-[#D1A142] focus:ring-amber-500 h-3.5 w-3.5 cursor-pointer"
            />
            <span>Visualizar anotações explicativas da proposta (IGUAL DA IMAGEM)</span>
          </label>
        </div>
      </div>

      <div className="relative flex flex-col xl:flex-row items-stretch justify-center w-full gap-5">
        
        {/* 📚 ANOTAÇÕES EXPLICATIVAS: COLUNA ESQUERDA (MOCKUP COMENTÁRIOS 1, 2, 3) */}
        {showAnnotations && (
          <div className="xl:w-[220px] flex flex-col justify-start space-y-16 shrink-0 py-16 hidden xl:flex text-left font-sans">
            
            {/* Anotação 1 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-hover hover:-translate-y-0.5">
              <div className="absolute top-1/2 -right-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -right-8 transform translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">1.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Reduzir excesso de botões</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Layout com as principais abas essenciais alinhadas horizontalmente para facilitar o controle visual direto.
                  </p>
                </div>
              </div>
            </div>

            {/* Anotação 2 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-hover hover:-translate-y-0.5">
              <div className="absolute top-1/2 -right-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -right-8 transform translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">2.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Mostrar apenas o próximo passo</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Foco centrado na pergunta "O que fazer agora", sinalizando a etapa atual da jornada e o botão principal de progresso.
                  </p>
                </div>
              </div>
            </div>

            {/* Anotação 3 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-hover hover:-translate-y-0.5">
              <div className="absolute top-1/2 -right-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -right-8 transform translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">3.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Usar linguagem simples</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Sinalizadores amigáveis de saúde e impacto de gargalo, livres de jargões técnicos matemáticos difíceis.
                  </p>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* CONTENEDOR CENTRAL: PAINEL PRINCIPAL DO Cockpit LEIGO (Com todas as Abas) */}
        <div className="flex-1 space-y-5">
          
          {/* Main Visual Board Box */}
          <div className="bg-white border-2 border-slate-900 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] rounded-none">
            
            {/* 🏛️ HEADER SUPERIOR PRINCIPAL (E3I ESTILO FOTO IMAGEM) */}
            <div className="p-4 border-b-2 border-slate-900 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 font-sans bg-white">
              {/* Logo & Empresa Select */}
              <div className="flex flex-wrap items-center gap-5">
                <div className="flex items-center gap-2">
                  <div className="bg-[#D1A142] text-slate-955 px-3 py-1 font-sans font-black flex flex-col items-center justify-center leading-none tracking-tight border-2 border-slate-900 shadow-3xs uppercase">
                    <span className="text-sm font-serif">E3I</span>
                    <span className="text-[7.5px] font-mono tracking-widest leading-none">Soluções</span>
                  </div>
                </div>
                
                <div className="h-6 w-px bg-slate-200 hidden md:block"></div>

                {/* Quick Select: Empresa */}
                <div className="flex flex-col text-left">
                  <label className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Empresa</label>
                  <select
                    value={activeCompanyId || ""}
                    onChange={(e) => setActiveCompanyId && setActiveCompanyId(e.target.value)}
                    className="text-xs font-black text-slate-850 bg-slate-50 border border-slate-300 p-1 rounded-sm focus:outline-none focus:border-slate-800 shrink-0 cursor-pointer max-w-[200px]"
                  >
                    {globalCompanies.length > 0 ? (
                      globalCompanies.map((c: any) => (
                        <option key={c.id} value={c.id}>
                          {c.cnpj ? `${c.cnpj.replace(/\D/g, "").substring(0, 4)} - ` : ""}{c.name}
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="comp-itau">Itaú Unibanco S.A.</option>
                        <option value="comp-ambev">Ambev Logística Global</option>
                        <option value="comp-petrobras">Petrobras Distribuição</option>
                      </>
                    )}
                  </select>
                </div>

                {/* Quick Select: Projeto DMAIC */}
                <div className="flex flex-col text-left">
                  <label className="text-[9px] uppercase font-bold text-slate-455 tracking-wider">Projeto DMAIC</label>
                  <select
                    value={activeWorkspaceProjectId || ""}
                    onChange={(e) => setActiveWorkspaceProjectId && setActiveWorkspaceProjectId(e.target.value)}
                    className="text-xs font-black text-slate-850 bg-slate-50 border border-slate-300 p-1 rounded-sm focus:outline-none focus:border-slate-800 shrink-0 cursor-pointer max-w-[200px]"
                  >
                    {globalProjects.length > 0 ? (
                      globalProjects
                        .filter((p: any) => !activeCompanyId || p.companyId === activeCompanyId)
                        .map((p: any) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))
                    ) : (
                      <>
                        <option value="proj_itau">Otimização de Ordens de Atendimento PJ</option>
                        <option value="proj_ambev">Melhoria do Lead Time de Operações SMT</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              {/* Right Status Indicator & Assistant user */}
              <div className="flex items-center justify-between md:justify-end gap-3 border-t md:border-t-0 pt-3 md:pt-0">
                {/* Green active pill */}
                <div className="bg-emerald-50 border border-emerald-300 text-emerald-850 px-3 py-1 rounded-full text-[10.5px] font-sans font-black tracking-normal flex items-center gap-1.5 select-none animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Modo Simplificado
                </div>

                <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>

                {/* User Profile avatar */}
                <div className="flex items-center gap-2 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-sm">
                  <div className="w-7 h-7 rounded-full bg-[#D1A142]/20 border border-amber-600 flex items-center justify-center text-xs font-bold text-amber-900 font-mono shadow-inner select-none">
                    M
                  </div>
                  <div className="flex flex-col text-left leading-none">
                    <span className="text-[11px] font-black text-slate-855 truncate">{activeUser?.fullName || "Marco A."}</span>
                    <span className="text-[9.5px] font-medium text-slate-500 mt-0.5">{activeUser?.role || "Analista"}</span>
                  </div>
                  <ChevronDown className="w-3 h-3 text-slate-400 ml-1 shrink-0" />
                </div>
              </div>
            </div>

            {/* 🧭 ABAS DE NAVEGAÇÃO HORIZONTAIS INTERATIVAS (IGUAL DA IMAGEM) */}
            <div className="bg-[#FAF9F6] border-b-2 border-slate-900 flex flex-wrap items-stretch justify-start divide-x-2 divide-slate-900 font-sans">
              {activeWorkspaceProjectId && (
                <button
                  type="button"
                  onClick={() => { setActiveTab("inicio"); }}
                  className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                    activeTab === "inicio"
                      ? "bg-white text-[#0B2545] border-b-[3px] border-[#D1A142]"
                      : "bg-[#FAF9F6] text-slate-500 hover:text-slate-950 hover:bg-slate-50"
                  }`}
                >
                  <Home className="w-4 h-4 text-[#0B2545]" />
                  <span>Início</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => { setActiveTab("diag"); }}
                className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                  activeTab === "diag"
                    ? "bg-white text-[#0B2545] border-b-[3px] border-[#D1A142]"
                    : "bg-[#FAF9F6] text-slate-500 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <Search className="w-4 h-4 text-[#0B2545]" />
                <span>Diagnóstico</span>
              </button>

              <button
                type="button"
                onClick={() => { setActiveTab("mapeamento"); }}
                className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                  activeTab === "mapeamento"
                    ? "bg-white text-[#0B2545] border-b-[3px] border-[#D1A142]"
                    : "bg-[#FAF9F6] text-slate-500 hover:text-slate-950 hover:bg-slate-50"
                }`}
              >
                <FileText className="w-4 h-4 text-[#0B2545]" />
                <span>Mapeamento Inicial</span>
              </button>

              {activeWorkspaceProjectId && (
                <>
                  <button
                    type="button"
                    onClick={() => { setActiveTab("map"); }}
                    className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                      activeTab === "map"
                        ? "bg-white text-[#0B2545] border-b-[3px] border-[#D1A142]"
                        : "bg-[#FAF9F6] text-slate-500 hover:text-slate-955 hover:bg-slate-50"
                    }`}
                  >
                    <Flag className="w-4 h-4 text-[#0B2545]" />
                    <span>Jornada DMAIC</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setActiveTab("improve"); }}
                    className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                      activeTab === "improve"
                        ? "bg-white text-[#0B2545] border-b-[3px] border-[#D1A142]"
                        : "bg-[#FAF9F6] text-slate-500 hover:text-slate-955 hover:bg-slate-50"
                    }`}
                  >
                    <BarChart2 className="w-4 h-4 text-[#0B2545]" />
                    <span>Resultados</span>
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={() => { setShowGlossary(!showGlossary); }}
                className={`px-5 py-3.5 flex items-center gap-2.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer select-none ${
                  showGlossary
                    ? "bg-amber-100/60 text-[#0B2545] border-b-[3px] border-[#D1A142]"
                    : "bg-[#FAF9F6] text-slate-500 hover:text-slate-955 hover:bg-slate-50"
                }`}
              >
                <HelpCircle className="w-4 h-4 text-[#0B2545]" />
                <span>Ajuda</span>
              </button>

              {/* Dropdown "Mais opções" */}
              {activeWorkspaceProjectId && (
                <div className="relative group flex items-stretch">
                  <button
                    type="button"
                    className={`px-5 py-3.5 flex items-center gap-1.5 font-black text-[11px] uppercase tracking-wider transition-all cursor-pointer h-full ${
                      activeTab === "tabela" || activeTab === "specialist"
                        ? "bg-amber-50 text-[#0B2545]"
                        : "bg-[#FAF9F6] text-slate-500 hover:text-slate-955"
                    }`}
                  >
                    <Layers className="w-4 h-4 text-[#0B2545]" />
                    <span>Mais opções</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                  
                  <div className="absolute left-0 top-full mt-0 bg-white border-2 border-slate-900 shadow-lg hidden group-hover:block z-30 min-w-[240px]">
                    <button
                      type="button"
                      onClick={() => { setActiveTab("tabela"); }}
                      className="w-full text-left px-4 py-3 text-xs font-black uppercase text-slate-800 hover:bg-slate-100 border-b border-slate-150 block cursor-pointer"
                    >
                      🧪 Tabela Periódica da Gestão
                    </button>
                    <button
                      type="button"
                      onClick={() => { setActiveTab("specialist"); }}
                      className="w-full text-left px-4 py-3 text-xs font-black uppercase text-slate-800 hover:bg-slate-100 block cursor-pointer"
                    >
                      📞 Suporte do Especialista
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Inner Dashboard View rendering slots */}
            <div className="p-4 bg-[#F8FAFC]">
              
              {/* inline notification of annotations for smaller screens */}
              {showAnnotations && (
                <div className="xl:hidden bg-amber-50 border border-amber-300 p-3 mb-4 rounded-sm text-xs text-amber-900 leading-snug space-y-1">
                  <strong className="block uppercase tracking-wider text-[10px] font-bold">Proposta de Usabilidade Simplificada (Anotações):</strong>
                  <ul className="list-disc pl-4 space-y-1">
                    <li><strong>Reduzir botões:</strong> Cockpit horizontal compacto com menos caminhos.</li>
                    <li><strong>O que fazer agora:</strong> Próximo passo destacado com acesso direto.</li>
                    <li><strong>Usar linguagem simples:</strong> Traduções práticas livre de jargão de consultores.</li>
                    <li><strong>Mais opções:</strong> Gaveta expandida para fluxos avançados secundários.</li>
                    <li><strong>Seu progresso:</strong> Anel radial dinâmico indica avanço da jornada.</li>
                    <li><strong>Ajuda e copiloto:</strong> Sidebar unificado reuniu glossário e assistente IA.</li>
                  </ul>
                </div>
              )}

      {/* 📖 GLOSSARY EXPANSION */}
      {showGlossary && (
        <div className="p-5 bg-amber-50 border border-amber-350 rounded-none animate-fadeIn space-y-4 shadow-sm" id="glossary-section-leigo">
          <h4 className="font-serif font-black text-slate-900 text-sm flex items-center gap-2 uppercase tracking-wide">
            <span>📚</span> Dicionário Prático: Traduzindo termos de consultores para o cotidiano
          </h4>
          <p className="text-xs text-slate-600">
            Abaixo estão os nomes complicados que os analistas usam e o que eles realmente significam na prática operação para quem cuida da empresa:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-white p-3.5 border border-[#1A1A1A]/10 rounded-none space-y-1">
              <strong className="text-xs font-mono text-slate-900 block border-b pb-1">DPMO (Erros estatísticos)</strong>
              <p className="text-[11.5px] text-slate-550 leading-relaxed">
                <strong>O nome bonito:</strong> Defeitos por milhão de oportunidades de produção.
                <br />
                <span className="text-amber-700 font-semibold">✨ Na prática:</span> Uma régua de segurança. É apenas o indicador de quantas falhas graves ou produtos estragados ocorrem na sua esteira de serviços. Quanto menos erros, menor o custo!
              </p>
            </div>
            <div className="bg-white p-3.5 border border-[#1A1A1A]/10 rounded-none space-y-1">
              <strong className="text-xs font-mono text-slate-900 block border-b pb-1">Desvio Padrão / Variabilidade</strong>
              <p className="text-[11.5px] text-slate-550 leading-relaxed">
                <strong>O nome bonito:</strong> Dispersão média quadrática dos dados de tempo operacional.
                <br />
                <span className="text-amber-700 font-semibold">✨ Na prática:</span> <strong>Falta de Padrão</strong> ou <strong>Instabilidade</strong>. Se o atendimento flutua muito (um dia é super rápido, outro é super devagar), a operação fica confusa. Queremos padrão previsível!
              </p>
            </div>
            <div className="bg-white p-3.5 border border-[#1A1A1A]/10 rounded-none space-y-1">
              <strong className="text-xs font-mono text-slate-900 block border-b pb-1">Estoque em Trâmite (W.I.P.)</strong>
              <p className="text-[11.5px] text-slate-550 leading-relaxed">
                <strong>O nome bonito:</strong> Work in Progress quantificado pela Lei de Little.
                <br />
                <span className="text-amber-700 font-semibold">✨ Na prática:</span> <strong>Pilhas Acumuladas</strong> de tarefas. São os e-mails não respondidos, relatórios aguardando assinatura ou materiais parados na mesa. Quanto mais coisas abertas no mesmo dia, mais lento é o negócio.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 🧩 1. SE ACTIVE TAB === INICIO -> RENDERIZAR PAINEL BENTO COMPLETO */}
      {activeTab === "inicio" && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Banner de Onboarding Interativo */}
          {onOpenOnboarding && (
            <div className="bg-[#FAF6EE] border-2 border-[#D1A142] p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[3px_3px_0px_0px_rgba(209,161,66,1)] rounded-none">
              <div className="flex items-center gap-3">
                <span className="text-2xl">💡</span>
                <div className="text-left">
                  <h4 className="font-serif font-black text-[#1A1A1A] text-sm uppercase tracking-tight">Novo na plataforma de Excelência Operacional?</h4>
                  <p className="text-xs text-slate-650 mt-0.5 font-sans">Sugerimos iniciar nosso Tour Guiado de 1 minuto para dominar os conceitos Lean Six Sigma sem esforço técnico.</p>
                </div>
              </div>
              <button
                onClick={onOpenOnboarding}
                className="px-4 py-2 bg-[#D1A142] hover:bg-amber-600 text-slate-950 font-black tracking-wide text-[10px] font-mono uppercase shrink-0 cursor-pointer shadow-3xs transition-all border border-slate-900"
              >
                🎓 Iniciar Tour Guiado
              </button>
            </div>
          )}

          {/* 🌟 CHEVRON PROGRESS TIMELINE (DEFINIR -> CONTROLAR) */}
          <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] rounded-none flex flex-col md:flex-row items-center justify-between gap-4 select-none">
            <div className="flex flex-col md:flex-row items-center w-full justify-around relative py-2 gap-4">
              
              {/* Connective absolute line behind timeline elements */}
              <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-200 hidden md:block -translate-y-1.5 z-0"></div>
              
              {[
                { id: "DEFINIR" as const, num: 1, label: "Definir", desc: "Estrutura do Problema" },
                { id: "MEDIR" as const, num: 2, label: "Medir", desc: "Cronometragem & Dados" },
                { id: "ANALISAR" as const, num: 3, label: "Analisar", desc: "Variabilidade & Causa" },
                { id: "MELHORAR" as const, num: 4, label: "Melhorar", desc: "Plano Kaizen & Alívio" },
                { id: "CONTROLAR" as const, num: 5, label: "Controlar", desc: "Padronização POP" }
              ].map((step, idx) => {
                const isActive = simplifiedStep === step.id;
                const isPrevious = 
                  (step.id === "DEFINIR" && (simplifiedStep === "MEDIR" || simplifiedStep === "ANALISAR" || simplifiedStep === "MELHORAR" || simplifiedStep === "CONTROLAR")) ||
                  (step.id === "MEDIR" && (simplifiedStep === "ANALISAR" || simplifiedStep === "MELHORAR" || simplifiedStep === "CONTROLAR")) ||
                  (step.id === "ANALISAR" && (simplifiedStep === "MELHORAR" || simplifiedStep === "CONTROLAR")) ||
                  (step.id === "MELHORAR" && (simplifiedStep === "CONTROLAR"));

                return (
                  <button
                    key={step.id}
                    onClick={() => setSimplifiedStep(step.id)}
                    className="flex flex-col items-center justify-center text-center focus:outline-none cursor-pointer z-10 transition-all uppercase group shrink-0"
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-sans font-black text-xs border-2 transition-all ${
                      isActive 
                        ? "bg-slate-950 text-white border-slate-950 shadow-xs scale-110" 
                        : isPrevious
                          ? "bg-emerald-500 text-white border-slate-900" 
                          : "bg-white text-slate-400 border-slate-200 group-hover:border-slate-800 group-hover:text-slate-850"
                    }`}>
                      {step.num}
                    </div>
                    <span className={`text-[11.5px] font-mono tracking-wider font-extrabold mt-1.5 block ${
                      isActive ? "text-slate-900 font-black" : "text-slate-400"
                    }`}>
                      {step.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 🍱 PAINEL MULTI-DASHBOARD BENTO GRID */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* COLUNA ESQUERDA: DIAGNÓSTICO E FLUXO DE AÇÃO PRINCIPAL DA ETAPA COMPLETA (8 cols) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* O QUE FAZER AGORA + DICA RÁPIDA */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* O que fazer agora block (2 cols) */}
                <div className="md:col-span-2 bg-white border-2 border-slate-900 p-5 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] rounded-none flex items-start gap-4 text-slate-850 font-sans animate-fadeIn">
                  <div className="w-12 h-12 bg-amber-500/10 border border-[#D1A142] flex items-center justify-center rounded-none shrink-0 text-amber-600">
                    <ClipboardList className="w-6 h-6" />
                  </div>
                  <div className="space-y-2 flex-1">
                    <h3 className="font-serif font-black text-[#1A1A1A] text-lg uppercase tracking-tight">O que fazer agora</h3>
                    <p className="text-xs text-slate-600 leading-relaxed font-sans">
                      {simplifiedStep === "DEFINIR" && "Você está na etapa Definir. Comece alinhando o objetivo do projeto e as metas desejadas."}
                      {simplifiedStep === "MEDIR" && "Você está na etapa Medir. Colete dados do processo e registre o tempo necessário para cada tarefa."}
                      {simplifiedStep === "ANALISAR" && "Você está na etapa Analisar. Encontre as causas-raiz dos atrasos e identifique o gargalo principal."}
                      {simplifiedStep === "MELHORAR" && "Você está na etapa Melhorar. Planeje ações práticas corretivas e elimine as atividades que não agregam valor."}
                      {simplifiedStep === "CONTROLAR" && "Você está na etapa Controlar. Estabeleça rotinas de monitoramento para garantir que os ganhos durem."}
                    </p>
                    
                    {/* Action Button: Continuar etapa atual */}
                    <button
                      onClick={() => {
                        if (simplifiedStep === "DEFINIR") {
                          setActiveTab("tabela");
                          setActiveTabelaElement("SWOT");
                        } else if (simplifiedStep === "MEDIR") {
                          setActiveTab("map");
                        } else if (simplifiedStep === "ANALISAR") {
                          setActiveTab("diag");
                        } else if (simplifiedStep === "MELHORAR") {
                          setActiveTab("improve");
                        } else {
                          setActiveTab("tabela");
                          setActiveTabelaElement("5W2H");
                        }
                      }}
                      className="px-4 py-2 bg-[#D1A142] hover:bg-amber-600 text-slate-950 font-black tracking-wide text-[11px] font-mono uppercase inline-flex items-center gap-1.5 cursor-pointer shadow-3xs translate-y-1 hover:translate-y-0.5 border border-slate-900"
                    >
                      Continuar etapa atual →
                    </button>
                  </div>
                </div>

                {/* Dica rápida (1 col) */}
                <div className="bg-[#FAF9F5] border-2 border-slate-900 p-5 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] rounded-none flex flex-col justify-between text-slate-800 font-sans">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1 text-xs font-mono font-black text-amber-600">
                      <Lightbulb className="w-4.5 h-4.5 text-amber-500 shrink-0 fill-amber-100" />
                      <span>Dica rápida</span>
                    </div>
                    <p className="text-[11px] text-slate-600 font-medium leading-relaxed leading-snug">
                      {simplifiedStep === "DEFINIR" && "Defina um objetivo claro. Assim o restante do projeto fica mais fácil."}
                      {simplifiedStep === "MEDIR" && "Utilize cronometragem direta ou dados históricos do sistema para ser fiel à realidade."}
                      {simplifiedStep === "ANALISAR" && "Use o diagrama de Ishikawa e os 5 porquês para separar os sintomas da causa real."}
                      {simplifiedStep === "MELHORAR" && "Mantenha o plano de ação simples e de baixo custo. Menos é mais na eliminação de perdas."}
                      {simplifiedStep === "CONTROLAR" && "Crie painéis visuais simples e checklists semanais de auditoria para fixar o padrão."}
                    </p>
                  </div>
                </div>
              </div>

              {/* TRÊS INDICADORES DE FEEDSTUFF DO SEMÁFORO RESUMIDO */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* 1. Saúde do Processo */}
                <div className="bg-white border-2 border-slate-900 p-5 shadow-[3px_3px_0px_rgba(0,0,0,1)] rounded-none text-slate-800 font-sans">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-100 shrink-0" />
                    Saúde do processo
                  </span>
                  
                  <div className="mt-2 text-left">
                    <span className="text-2.5xl font-black text-slate-900 font-serif tracking-tight leading-none">
                      {simplifiedStep === "DEFINIR" && "73%"}
                      {simplifiedStep === "MEDIR" && "76%"}
                      {simplifiedStep === "ANALISAR" && "64%"}
                      {simplifiedStep === "MELHORAR" && "82%"}
                      {simplifiedStep === "CONTROLAR" && "91%"}
                    </span>
                    <span className={`text-[11px] font-black uppercase font-mono ml-2 px-1.5 py-0.5 rounded-xs border shrink-0 ${
                      simplifiedStep === "ANALISAR" 
                        ? "bg-rose-50 text-rose-700 border-rose-300" 
                        : (simplifiedStep === "DEFINIR" || simplifiedStep === "MEDIR")
                          ? "bg-amber-50 text-amber-700 border-amber-300"
                          : "bg-emerald-50 text-emerald-700 border-emerald-300"
                    }`}>
                      {simplifiedStep === "ANALISAR" ? "Crítico" : (simplifiedStep === "DEFINIR" || simplifiedStep === "MEDIR") ? "Regular" : "Excelente"}
                    </span>
                  </div>

                  {/* Progress bar matching */}
                  <div className="mt-3.5 space-y-1 text-left">
                    <div className="w-full bg-slate-100 h-2 border border-slate-200 rounded-none relative overflow-hidden">
                      <div 
                        className={`h-full rounded-none transition-all ${
                          simplifiedStep === "ANALISAR" 
                            ? "bg-rose-500" 
                            : (simplifiedStep === "DEFINIR" || simplifiedStep === "MEDIR")
                              ? "bg-amber-400"
                              : "bg-emerald-500"
                        }`} 
                        style={{
                          width: 
                            simplifiedStep === "DEFINIR" ? "73%" :
                            simplifiedStep === "MEDIR" ? "76%" :
                            simplifiedStep === "ANALISAR" ? "64%" :
                            simplifiedStep === "MELHORAR" ? "82%" : "91%"
                        }}
                      ></div>
                    </div>
                    <span className="text-[9.5px] font-mono uppercase font-bold text-slate-400 mt-1 block tracking-wider leading-none">
                      Meta mínima: ≥ 80%
                    </span>
                  </div>
                </div>

                {/* 2. Principal Gargalo */}
                <div className="bg-white border-2 border-slate-900 p-5 shadow-[3px_3px_0px_rgba(0,0,0,1)] rounded-none text-slate-800 font-sans">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-450 tracking-wider flex items-center gap-1 text-amber-600">
                    <Flame className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    Principal gargalo
                  </span>
                  
                  <div className="mt-2.5 text-left leading-none">
                    <div className="text-[12.5px] font-black text-slate-900 uppercase truncate">
                      {simplifiedStep === "DEFINIR" && (stats.bottleneckStepName || "Tempo no Atendimento")}
                      {simplifiedStep === "MEDIR" && (steps[0]?.name || "Triagem Inicial")}
                      {simplifiedStep === "ANALISAR" && (stats.bottleneckStepName || "Processamento central")}
                      {simplifiedStep === "MELHORAR" && "Assinaturas de Escopo"}
                      {simplifiedStep === "CONTROLAR" && "Nenhum Ativo"}
                    </div>
                    <span className="text-[9.5px] text-slate-400 block mt-1">no fluxo operacional</span>
                  </div>

                  <div className="mt-4 text-left">
                    <span className={`text-[10px] font-bold uppercase font-mono px-2 py-0.5 border rounded-xs ${
                      simplifiedStep === "ANALISAR" ? "bg-rose-50 text-rose-700 border-rose-300" :
                      simplifiedStep === "CONTROLAR" ? "bg-emerald-50 text-emerald-700 border-emerald-300" :
                      "bg-amber-50 text-amber-700 border-amber-300"
                    }`}>
                      Impacto: {simplifiedStep === "ANALISAR" ? "Crítico 🚨" : simplifiedStep === "CONTROLAR" ? "Baixo" : "Alto ⚠️"}
                    </span>
                  </div>
                </div>

                {/* 3. Próxima Ação */}
                <div className="bg-white border-2 border-slate-900 p-5 shadow-[3px_3px_0px_rgba(0,0,0,1)] rounded-none text-slate-800 font-sans">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-450 tracking-wider flex items-center gap-1 text-slate-700">
                    <Play className="w-3.5 h-3.5 text-slate-800 shrink-0 fill-slate-200" />
                    Próxima ação
                  </span>
                  
                  <div className="mt-2 text-left leading-none">
                    <div className="text-xs font-black text-slate-950 uppercase tracking-tight leading-snug">
                      {simplifiedStep === "DEFINIR" && "Definir objetivos do Project Charter"}
                      {simplifiedStep === "MEDIR" && "Registrar Postos no Painel Geral"}
                      {simplifiedStep === "ANALISAR" && "Mapear desperdícios Lean no quadro"}
                      {simplifiedStep === "MELHORAR" && "Aplicar limite WIP e padronizar POP"}
                      {simplifiedStep === "CONTROLAR" && "Fixar controle semanal de Auditoria"}
                    </div>
                  </div>

                  <div className="mt-2.5 text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50/50 p-1 border border-indigo-100 rounded-2xs text-left w-max">
                    ⏳ ~10 min para concluir
                  </div>
                </div>

              </div>

              {/* CARD DETALHADO DO PASSO DMAIC COM PROGRESSO CIRCULAR INTEGRADO */}
              <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_rgba(0,0,0,1)] rounded-none text-slate-800 font-sans">
                
                {/* Header card with progress circular block */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center border-b pb-4">
                  <div className="md:col-span-8 flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-sm shrink-0">
                      {simplifiedStep === "DEFINIR" && "🎯"}
                      {simplifiedStep === "MEDIR" && "📊"}
                      {simplifiedStep === "ANALISAR" && "🔎"}
                      {simplifiedStep === "MELHORAR" && "💡"}
                      {simplifiedStep === "CONTROLAR" && "✅"}
                    </div>
                    <div>
                      <h3 className="font-serif font-black text-slate-900 text-lg uppercase tracking-tight">
                        {simplifiedStep === "DEFINIR" && "Definir: Alinhamento do projeto"}
                        {simplifiedStep === "MEDIR" && "Medir: Coleta e Mapeamento de Rotinas"}
                        {simplifiedStep === "ANALISAR" && "Analisar: Varredura de Gargalos & Perdas"}
                        {simplifiedStep === "MELHORAR" && "Melhorar: Implementação de Kaizens"}
                        {simplifiedStep === "CONTROLAR" && "Controlar: Blindagem & Sustentação"}
                      </h3>
                      <p className="text-xs text-slate-500 mt-1 font-sans">
                        {simplifiedStep === "DEFINIR" && "Entender o problema, definir o objetivo do projeto e as metas que queremos alcançar."}
                        {simplifiedStep === "MEDIR" && "Desenhar as etapas do fluxo de atendimento, recursos alocados e os tempos de cada etapa."}
                        {simplifiedStep === "ANALISAR" && "Identificar causas-raiz de retrabalho na esteira, focando nas perdas ou variabilidades altas."}
                        {simplifiedStep === "MELHORAR" && "Executar propostas corretivas de baixo custo e readequar a quantidade de pessoas no posto lento."}
                        {simplifiedStep === "CONTROLAR" && "Montar manual operacional POP, distribuir tarefas via RACI e assinar contratos de SLA estáveis."}
                      </p>
                    </div>
                  </div>

                  {/* Seu progresso circular radial (3 cols) */}
                  <div className="md:col-span-4 bg-slate-50 border border-slate-200 p-3 rounded-none flex items-center justify-center gap-3.5">
                    {/* Ring simulation */}
                    <div className="relative w-12 h-12 flex items-center justify-center">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="24" cy="24" r="20" className="stroke-slate-200 fill-none" strokeWidth="4" />
                        <circle 
                          cx="24" 
                          cy="24" 
                          r="20" 
                          className="stroke-[#D1A142] fill-none transition-all duration-300" 
                          strokeWidth="4" 
                          strokeDasharray="125.6"
                          strokeDashoffset={
                            simplifiedStep === "DEFINIR" ? "100.4" : // 20%
                            simplifiedStep === "MEDIR" ? "75.3" : // 40%
                            simplifiedStep === "ANALISAR" ? "50.2" : // 60%
                            simplifiedStep === "MELHORAR" ? "25.1" : "0" // 80% or 100%
                          }
                        />
                      </svg>
                      <span className="absolute text-[11px] font-black text-slate-855 font-sans">
                        {simplifiedStep === "DEFINIR" && "20%"}
                        {simplifiedStep === "MEDIR" && "40%"}
                        {simplifiedStep === "ANALISAR" && "64%"}
                        {simplifiedStep === "MELHORAR" ? "80%" : "100%"}
                      </span>
                    </div>
                    
                    <div className="text-left leading-none">
                      <div className="text-[10px] font-mono uppercase font-bold text-slate-400">Seu progresso</div>
                      <div className="text-[11.5px] font-mono text-slate-800 font-extrabold mt-1">
                        {simplifiedStep === "DEFINIR" && "1 de 5 concluídas"}
                        {simplifiedStep === "MEDIR" && "2 de 5 concluídas"}
                        {simplifiedStep === "ANALISAR" && "3 de 5 concluídas"}
                        {simplifiedStep === "MELHORAR" && "4 de 5 concluídas"}
                        {simplifiedStep === "CONTROLAR" && "5 de 5 concluídas"}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Checklist "O que você vai fazer agora (3 passos simples)" */}
                <div className="pt-4 space-y-3 font-sans">
                  <h4 className="text-[10px] uppercase font-mono font-bold text-slate-500 tracking-wider text-left">
                    O que você vai fazer agora (3 passos simples - Clique para marcar)
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    
                    {/* Substep 1 */}
                    <button
                      onClick={() => toggleSubstep(`${simplifiedStep}_1`)}
                      className={`p-3 border-2 transition-all text-left flex items-start gap-2.5 rounded-none cursor-pointer hover:border-slate-850 ${
                        checkedSubsteps[`${simplifiedStep}_1`]
                          ? "bg-emerald-50/50 border-emerald-500 text-slate-850"
                          : "bg-white border-slate-200 text-slate-500"
                      }`}
                    >
                      <div className={`mt-0.5 rounded-xs p-0.5 border shrink-0 flex items-center justify-center w-4.5 h-4.5 ${
                        checkedSubsteps[`${simplifiedStep}_1`] ? "bg-emerald-500 text-white border-emerald-600" : "bg-slate-50 border-slate-350"
                      }`}>
                        {checkedSubsteps[`${simplifiedStep}_1`] && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[11.5px] font-extrabold block leading-tight">
                          {simplifiedStep === "DEFINIR" && "1. Descrever o problema"}
                          {simplifiedStep === "MEDIR" && "1. Desenhar a rotina de postos"}
                          {simplifiedStep === "ANALISAR" && "1. Identificar perdas correntes"}
                          {simplifiedStep === "MELHORAR" && "1. Otimizar as filas correntes"}
                          {simplifiedStep === "CONTROLAR" && "1. Mapear metas contratuais"}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-medium flex-wrap">Fácil execução</span>
                      </div>
                    </button>

                    {/* Substep 2 */}
                    <button
                      onClick={() => toggleSubstep(`${simplifiedStep}_2`)}
                      className={`p-3 border-2 transition-all text-left flex items-start gap-2.5 rounded-none cursor-pointer hover:border-slate-850 ${
                        checkedSubsteps[`${simplifiedStep}_2`]
                          ? "bg-emerald-50/50 border-emerald-500 text-slate-850"
                          : "bg-white border-slate-200 text-slate-500"
                      }`}
                    >
                      <div className={`mt-0.5 rounded-xs p-0.5 border shrink-0 flex items-center justify-center w-4.5 h-4.5 ${
                        checkedSubsteps[`${simplifiedStep}_2`] ? "bg-[#D1A142] text-slate-950 border-amber-600" : "bg-slate-50 border-slate-350"
                      }`}>
                        {checkedSubsteps[`${simplifiedStep}_2`] && <Check className="w-3.5 h-3.5 stroke-[3] text-slate-950" />}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[11.5px] font-extrabold block leading-tight font-sans">
                          {simplifiedStep === "DEFINIR" && "2. Definir objetivo e metas"}
                          {simplifiedStep === "MEDIR" && "2. Configurar volumes de chegada"}
                          {simplifiedStep === "ANALISAR" && "2. Elaborar Diagrama de Causas"}
                          {simplifiedStep === "MELHORAR" && "2. Criar plano 5W2H prático"}
                          {simplifiedStep === "CONTROLAR" && "2. Fixar funções com Matriz RACI"}
                        </span>
                        <span className="text-[10px] text-indigo-500 block mt-0.5 font-medium font-mono">Em processamento</span>
                      </div>
                    </button>

                    {/* Substep 3 */}
                    <button
                      onClick={() => toggleSubstep(`${simplifiedStep}_3`)}
                      className={`p-3 border-2 transition-all text-left flex items-start gap-2.5 rounded-none cursor-pointer hover:border-slate-850 ${
                        checkedSubsteps[`${simplifiedStep}_3`]
                          ? "bg-emerald-50/50 border-emerald-500 text-slate-855"
                          : "bg-white border-slate-200 text-slate-500"
                      }`}
                    >
                      <div className={`mt-0.5 rounded-xs p-0.5 border shrink-0 flex items-center justify-center w-4.5 h-4.5 ${
                        checkedSubsteps[`${simplifiedStep}_3`] ? "bg-emerald-500 text-white border-emerald-600" : "bg-slate-50 border-slate-350"
                      }`}>
                        {checkedSubsteps[`${simplifiedStep}_3`] && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[11.5px] font-extrabold block leading-tight font-sans">
                          {simplifiedStep === "DEFINIR" && "3. Validar escopos e Charter"}
                          {simplifiedStep === "MEDIR" && "3. Cronometrar tempos gastos"}
                          {simplifiedStep === "ANALISAR" && "3. Isolar gargalo estatístico"}
                          {simplifiedStep === "MELHORAR" && "3. Testar simulação de alívios"}
                          {simplifiedStep === "CONTROLAR" && "3. Criar instrução operacional POP"}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-medium">Próximo passo</span>
                      </div>
                    </button>

                  </div>
                </div>

              </div>

            </div>

            {/* COLUNA DIREITA: AJUDA RÁPIDA / GLOSSÁRIO & CO-PILOTO CONTEXTUAL IA (4 cols style foto) */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* BOX CONTAINER "AJUDA RÁPIDA" DE DESIGN MODERNO INTEGRADO */}
              <div className="bg-white border-2 border-slate-900 shadow-[4px_4px_0px_rgba(26,26,26,1)] rounded-none text-slate-800 font-sans">
                
                {/* Header panel with close button */}
                <div className="bg-slate-50 p-4 border-b-2 border-slate-900 flex items-center justify-between">
                  <h3 className="font-serif font-black text-[#1A1A1A] text-sm uppercase tracking-wider flex items-center gap-1.5 leading-none">
                    <span>💡</span> Ajuda rápida
                  </h3>
                  <button 
                    onClick={() => setActiveTab("inicio")} 
                    className="p-1 text-slate-400 hover:text-slate-950 rounded-sm hover:bg-slate-100 cursor-pointer animate-pulse"
                    title="Ocultar Painel"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Sub panels Accordion structure inside */}
                <div className="p-4 space-y-4 font-sans">
                  
                  {/* ACCORDION 1: GLOSSÁRIO DESCOMPLICADO */}
                  <div className="border border-slate-300 bg-slate-50/30">
                    <button
                      onClick={() => setShowGlossary(!showGlossary)}
                      className="w-full text-left p-3 flex items-center justify-between font-mono text-xs font-black uppercase tracking-wider border-b border-rose-100 bg-white cursor-pointer"
                    >
                      <span className="flex items-center gap-1.5 text-slate-900 leading-none">
                        <BookOpen className="w-4 h-4 text-[#D1A142]" />
                        1. Glossário
                      </span>
                      {showGlossary ? <ChevronUp className="w-3.5 h-3.5 text-slate-600" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-600" />}
                    </button>
                    
                    {showGlossary && (
                      <div className="p-3 text-xs text-left text-slate-650 leading-relaxed space-y-2.5 animate-fadeIn bg-white">
                        <div>
                          <strong className="text-slate-900 block font-mono">Gargalo:</strong>
                          <p className="mt-0.5">É a etapa do processo que limita o fluxo e causa o maior atraso na esteira de atendimento.</p>
                        </div>
                        <div className="border-t border-dashed pt-2">
                          <strong className="text-slate-900 block font-mono">Project Charter:</strong>
                          <p className="mt-0.5">Documento simples padrão para descrever o problema, mapear objetivos, escopo e metas.</p>
                        </div>
                        <div className="border-t border-dashed pt-2">
                          <strong className="text-slate-900 block font-mono">POP (Procedimento Padrão):</strong>
                          <p className="mt-0.5">Checklist operacional impresso ou digital para guiar operadores sem risco de dúvidas.</p>
                        </div>
                        
                        <button
                          onClick={() => setShowTermsModal(true)}
                          className="text-[#D1A142] hover:text-[#A0702B] font-extrabold text-[11px] uppercase tracking-wide flex items-center gap-1 cursor-pointer pt-1"
                        >
                          Ver mais termos do glossário LSS →
                        </button>
                      </div>
                    )}
                  </div>

                  {/* ACCORDION 2: ASSISTENTE DE INTELIGÊNCIA ARTIFICIAL */}
                  <div className="border border-slate-300 bg-slate-50/30">
                    <div className="p-3 flex items-center justify-between font-mono text-xs font-black uppercase tracking-wider border-b bg-white text-slate-900 leading-none">
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-amber-500 fill-amber-100" />
                        2. Assistente IA
                      </span>
                    </div>

                    <div className="p-3 transition-all space-y-3 bg-white">
                      <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                        Olá! Sou seu assistente contextual para a etapa de <strong className="text-slate-900">{simplifiedStep}</strong>. Posso tirar dúvidas e dar dicas sobre seu projeto.
                      </p>

                      {/* Chat Messages Log list inside sidebar block */}
                      <div className="border border-slate-200 bg-slate-50 p-2.5 max-h-48 overflow-y-auto space-y-2.5 rounded-none shadow-inner text-[10.5px] leading-relaxed">
                        {chatHistory.map((msg, index) => (
                          <div key={index} className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>
                            <span className="text-[8.5px] font-mono tracking-wider font-extrabold text-slate-400 mb-0.5 uppercase">
                              {msg.role === "user" ? "Você" : "Mestre LSS"}
                            </span>
                            <div className={`p-2 border rounded-none ${
                              msg.role === "user"
                                ? "bg-slate-900 text-white border-slate-900 text-right"
                                : "bg-white text-slate-800 border-slate-200 text-left font-sans"
                            }`}>
                              {msg.text}
                            </div>
                          </div>
                        ))}
                        {isChatLoading && (
                          <div className="text-slate-500 italic flex items-center gap-1 text-[10px]">
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
                            <span>Consultor E3I está respondendo...</span>
                          </div>
                        )}
                      </div>

                      {/* Msg Input block */}
                      <div className="flex gap-1">
                        <input
                          type="text"
                          placeholder="Pergunte algo ao consultor..."
                          value={userQuery}
                          onChange={(e) => setUserQuery(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === "Enter" && userQuery.trim() && !isChatLoading) {
                              handleSendChat(userQuery);
                            }
                          }}
                          className="flex-1 text-xs px-2 py-1.5 bg-white border border-slate-250 focus:outline-none focus:border-slate-800 rounded-none shrink-0"
                        />
                        <button
                          disabled={isChatLoading || !userQuery.trim()}
                          onClick={() => handleSendChat(userQuery)}
                          className="p-2 bg-slate-900 text-white hover:bg-slate-850 transition-all cursor-pointer rounded-none flex items-center justify-center shrink-0 disabled:bg-slate-100 disabled:text-slate-350 disabled:border-slate-100 border border-slate-900"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Quick suggested anchors */}
                      <div className="pt-1.5 space-y-1 text-left">
                        <span className="text-[9px] uppercase font-mono tracking-wider font-bold text-slate-400 block mb-1">Dúvidas Frequentes</span>
                        <div className="flex flex-col gap-1">
                          {[
                            "O que é meta?",
                            "Como definir o objetivo?",
                            "O que é desperdício Lean?",
                            "Como achar meu gargalo?"
                          ].map((queryAnchor) => (
                            <button
                              key={queryAnchor}
                              onClick={() => {
                                if (!isChatLoading) handleSendChat(queryAnchor);
                              }}
                              className="text-[9.5px] font-mono font-bold text-slate-700 bg-slate-100 p-1 hover:bg-amber-100 hover:text-slate-950 rounded-2xs border cursor-pointer select-none truncate text-left w-full block transition-all"
                            >
                              💬 "{queryAnchor}"
                            </button>
                          ))}
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              </div>

            </div>

          </div>

          {/* 🏛️ SEÇÃO INFERIOR FOOTER: RECOMENDAÇÕES TECE & JORNADA SIMPLIFICADA */}
          <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_rgba(26,26,26,1)] rounded-none space-y-8 text-left">
            
            {/* Header section title */}
            <div className="border-b border-slate-150 pb-3 flex flex-col md:flex-row md:items-center justify-between gap-2">
              <div>
                <h3 className="font-serif font-black text-slate-955 text-base uppercase tracking-tight">Mudanças recomendadas para o desenvolvedor</h3>
                <p className="text-[11.5px] text-slate-550">
                  Resumo das melhorias estruturais implementadas neste redesenho de usabilidade focado em leigos.
                </p>
              </div>
            </div>

            {/* Column grid of 6 items */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { num: "🎯", title: "Ação Principal", text: "Priorizar 1 ação principal destacada por tela para evitar dispersão do leigo." },
                { num: "🔒", title: "Ocultação", text: "Ocultar painéis técnicos e fórmulas avançadas no modo simplificado da ferramenta." },
                { num: "💬", title: "Termos Leves", text: "Trocar jargões técnicos matemáticos por descrições e analogias amigáveis." },
                { num: "🎨", title: "Foco Cromático", text: "Reduzir cores concorrentes e banners simultâneos no cockpit geral do painel." },
                { num: "📊", title: "Blocos de KPI", text: "Agrupar métricas mais complexas em blocos intuitivos e semáforos fáceis de ler." },
                { num: "🤖", title: "Uso Contextual", text: "Acionar copiloto robotizado por etapa do projeto de forma 100% amigável." }
              ].map((rec, i) => (
                <div key={i} className="bg-slate-50 border border-slate-200 p-4 rounded-none space-y-1.5 flex flex-col justify-between font-sans">
                  <div className="w-8 h-8 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center font-bold font-mono">
                    {rec.num}
                  </div>
                  <div>
                    <h5 className="text-[11.5px] font-black text-slate-900 truncate uppercase mt-1">
                      {rec.title}
                    </h5>
                    <p className="text-[10px] text-slate-500 leading-normal font-sans mt-0.5">{rec.text}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Fluxo Simplificado do Usuário diagram path */}
            <div className="bg-slate-50 border border-slate-200 p-5 rounded-none space-y-3">
              <h4 className="text-[10.5px] uppercase font-mono tracking-widest font-extrabold text-[#7c7c7c] text-left">
                Fluxo Simplificado Operacional do Usuário
              </h4>
              <div className="flex flex-wrap items-center justify-around gap-2 text-slate-850 font-sans select-none">
                {[
                  { em: "🚪", label: "Entrar" },
                  { em: "🏢", label: "Escolher projeto" },
                  { em: "🧭", label: "Ver próximo passo" },
                  { em: "📝", label: "Preencher dados" },
                  { em: "📈", label: "Analisar resultado" },
                  { em: "✨", label: "Avançar" }
                ].map((item, idx, arr) => (
                  <React.Fragment key={idx}>
                    <div className="flex items-center gap-2 bg-white border border-slate-300 rounded-none shrink-0 shadow-3xs px-3.5 py-1.5">
                      <span>{item.em}</span>
                      <span className="text-[11.5px] font-black uppercase font-mono tracking-tight">{item.label}</span>
                    </div>
                    {idx < arr.length - 1 && <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 hidden sm:block" />}
                  </React.Fragment>
                ))}
              </div>
            </div>

            <div className="text-[11px] font-mono font-bold text-slate-500 flex items-center gap-1">
              ⭐ Foco: clareza, guia passo a passo e menos ruído visual para o usuário leigo.
            </div>

          </div>

        </div>
      )}

      {/* 📖 MODAL DE GLOSSÁRIO DE NEGÓCIOS INTEGRAL */}
      {showTermsModal && (
        <div className="fixed inset-0 bg-slate-950/60 flex items-center justify-center z-50 p-4 overflow-y-auto animate-fadeIn font-sans">
          <div className="bg-white border-3 border-slate-950 p-6 max-w-xl w-full shadow-[5px_5px_0px_rgba(0,0,0,1)] rounded-none space-y-5">
            <div className="flex items-center justify-between border-b pb-3.5 font-sans">
              <h2 className="font-serif font-black text-slate-900 text-lg uppercase tracking-tight flex items-center gap-2">
                <span>📚</span> Dicionário de Termos LSS Simplificado
              </h2>
              <button 
                onClick={() => setShowTermsModal(false)}
                className="p-1 text-slate-450 hover:text-slate-950 hover:bg-slate-100 rounded-none cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto pr-1 text-xs leading-relaxed text-left font-sans">
              <div>
                <strong className="text-slate-900 text-sm">🟢 DMAIC</strong>
                <p className="mt-1 text-slate-600 font-sans">Sigla para Definir, Medir, Analisar, Melhorar (Improve) e Controlar. É a bússola para organizar qualquer projeto de melhoria da empresa.</p>
              </div>
              <div className="border-t pt-3">
                <strong className="text-slate-900 text-sm">🟢 SIPOC</strong>
                <p className="mt-0.5 text-slate-600 font-sans">Mapeamento macro. Explica quem fornece (Supplier), o que entra (Input), como funciona (Process), o que sai (Output) e quem é o comprador (Customer).</p>
              </div>
              <div className="border-t pt-3">
                <strong className="text-slate-900 text-sm">🟢 Poka-Yoke (Blindagem de Erros)</strong>
                <p className="mt-0.5 text-slate-600 font-sans">Mecanismo à prova de falhas humanas na operação (como o formato único do chip de celular, que impede de preenchê-lo ao contrário).</p>
              </div>
              <div className="border-t pt-3">
                <strong className="text-slate-900 text-sm">🟢 Kanban</strong>
                <p className="mt-0.5 text-slate-600 font-sans">Painel com cartões visuais para controlar a quantidade máxima de tarefas em andamento, impedindo pilhas e esgotamento técnico.</p>
              </div>
              <div className="border-t pt-3">
                <strong className="text-slate-900 text-sm">🟢 Kaizen</strong>
                <p className="mt-0.5 text-slate-600 font-sans">Mapear melhorias incremental e de baixo custo diretamente no posto atrasado.</p>
              </div>
            </div>

            <div className="pt-2 border-t flex justify-end">
              <button
                onClick={() => setShowTermsModal(false)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider rounded-none cursor-pointer"
              >
                Certo, entendi!
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RENDERIZAR ABAS ORIGINAIS ADICIONAIS ADAPTADAS CONECTADAS SELECIONADAS */}
      <div className="mt-1"></div>

      {activeTab === "tabela" && (
        <div className="space-y-6 animate-fadeIn text-slate-800" id="view-tabela">
          
          {/* Main Info Box */}
          <div className="bg-[#1e1b4b] border-2 border-[#D1A142]/40 p-6 text-[#F5F2ED] rounded-none relative overflow-hidden shadow-lg">
            <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center justify-center p-4">
              <Layers size={180} className="text-[#D1A142]" />
            </div>
            <div className="relative z-10 space-y-2 max-w-4xl">
              <span className="text-[10px] uppercase font-mono font-black text-[#D1A142] tracking-widest px-2 py-0.5 bg-[#D1A142]/10 border border-[#D1A142]/30 rounded-none">
                🧪 SISTEMA INTEGRADO DE MODELAGEM
              </span>
              <h3 className="text-xl md:text-2xl font-serif font-black tracking-tight text-white leading-tight">
                Tabela Periódica da Gestão Operacional
              </h3>
              <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-sans max-w-3xl">
                O guia supremo de ferramentas essenciais para planejar, estruturar, executar, controlar e diagnosticar sua rotina de negócios. 
                <strong> Toque em qualquer elemento da tabela abaixo </strong> para abrir o simulador prático e acionar a ferramenta integrada de forma ultra-simplificada!
              </p>
            </div>
          </div>

          {/* PERIODIC TABLE VISUAL GRID */}
          <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_rgba(0,0,0,1)] rounded-none space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-150 pb-3 gap-2">
              <h4 className="text-xs font-mono font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                📂 Mapa Geral de Ferramentas Ativas
              </h4>
              <p className="text-[11px] text-slate-500 font-sans">
                Selecione um elemento para revelar seu playground inteligente abaixo.
              </p>
            </div>

            {/* Periodic Table Grid Layout */}
            <div className="space-y-4">
              {/* Rows of Categories */}
              {[
                {
                  id: "PLANEJAMENTO",
                  name: "🎯 Planejamento",
                  color: "border-blue-600 bg-blue-50/20 text-blue-900",
                  badge: "bg-blue-600",
                  elements: [
                    { id: "SWOT", sym: "SW", label: "SWOT", desc: "Forças e Oportunidades", active: swotStrengths.length > 0 },
                    { id: "OKR", sym: "OK", label: "OKR", desc: "Objetivos e Resultados", active: okrsList.length > 0 },
                    { id: "5W2H", sym: "5W", label: "5W2H", desc: "Planejamento de Ações", active: fiveW2hPlans.length > 0 },
                    { id: "BSC", sym: "BS", label: "BSC", desc: "Balanced Scorecard", active: true }
                  ]
                },
                {
                  id: "PROCESSOS",
                  name: "🌿 Processos",
                  color: "border-emerald-600 bg-emerald-50/20 text-emerald-900",
                  badge: "bg-emerald-600",
                  elements: [
                    { id: "BPM", sym: "BP", label: "BPM", desc: "Gestão Operacional", active: steps && steps.length > 0 },
                    { id: "SIPOC", sym: "SI", label: "SIPOC", desc: "Mapeamento Macro", active: steps && steps.length > 0 },
                    { id: "FLUXOGRAMA", sym: "FL", label: "Fluxograma", desc: "Desenho e Caminhos", active: steps && steps.length > 0 },
                    { id: "RACI", sym: "RA", label: "RACI", desc: "Responsabilidades", active: steps && steps.length > 0 }
                  ]
                },
                {
                  id: "EXECUÇÃO",
                  name: "🚀 Execução",
                  color: "border-amber-600 bg-amber-50/20 text-amber-900",
                  badge: "bg-[#D97706]",
                  elements: [
                    { id: "PDCA", sym: "PD", label: "PDCA", desc: "Melhoria Contínua", active: true },
                    { id: "KANBAN", sym: "KB", label: "Kanban", desc: "Quadro de Limites WIP", active: steps && steps.length > 0 },
                    { id: "POP", sym: "PO", label: "POP", desc: "Instrução Operacional", active: steps && steps.length > 0 },
                    { id: "SCRUM", sym: "SC", label: "Scrum", desc: "Sprint Operacional", active: true }
                  ]
                },
                {
                  id: "CONTROLE",
                  name: "📊 Controle",
                  color: "border-purple-600 bg-purple-50/20 text-purple-900",
                  badge: "bg-purple-600",
                  elements: [
                    { id: "KPI", sym: "KP", label: "KPI", desc: "3 Esferas de Métricas", active: true },
                    { id: "DASHBOARD", sym: "DB", label: "Dashboard", desc: "Fluxos de Simulador", active: true },
                    { id: "SLA", sym: "SL", label: "SLA", desc: "Metas de Acordo", active: true },
                    { id: "OEE", sym: "OE", label: "OEE", desc: "Eficiência Máquinas", active: true }
                  ]
                },
                {
                  id: "DIAGNÓSTICO",
                  name: "🔍 Diagnóstico",
                  color: "border-rose-600 bg-rose-50/20 text-rose-900",
                  badge: "bg-rose-600",
                  elements: [
                    { id: "ISHIKAWA", sym: "IS", label: "Ishikawa", desc: "Causa e Efeito (6M)", active: ishikawaMethod.length > 0 },
                    { id: "PARETO", sym: "PA", label: "Pareto", desc: "Análise 80/20", active: steps && steps.length > 0 },
                    { id: "FMEA", sym: "FM", label: "FMEA", desc: "Modos de Falha", active: fmeaRecords.length > 0 },
                    { id: "DMAIC", sym: "DM", label: "DMAIC", desc: "Entranhas do Six Sigma", active: true }
                  ]
                }
              ].map((row) => (
                <div key={row.id} className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center border border-slate-100 p-2 text-xs">
                  {/* Row Header */}
                  <div className="lg:col-span-2 font-mono font-black uppercase text-slate-800 flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 shrink-0 ${row.badge}`}></span>
                    <span>{row.name}</span>
                  </div>

                  {/* Row Elements */}
                  <div className="lg:col-span-10 grid grid-cols-2 md:grid-cols-4 gap-3">
                    {row.elements.map((el) => {
                      const isSelected = activeTabelaElement === el.id;
                      return (
                        <button
                          key={el.id}
                          type="button"
                          onClick={() => setActiveTabelaElement(el.id)}
                          className={`border-2 p-2.5 font-sans transition-all text-left flex items-start gap-2.5 relative select-none cursor-pointer ${
                            isSelected
                              ? `${row.color} border-slate-900 scale-[1.03] shadow-[2px_2px_0px_rgba(0,0,0,1)] ring-1 ring-slate-900`
                              : "border-slate-300 bg-white text-slate-700 hover:border-slate-650 hover:bg-slate-50/50"
                          }`}
                        >
                          {/* Element Symbol (Chemical-Like) */}
                          <div className={`p-1 w-8 h-8 rounded-none border border-slate-900 flex items-center justify-center font-mono font-black text-xs ${
                            isSelected ? "bg-slate-900 text-white" : "bg-slate-102 text-slate-805"
                          }`}>
                            {el.sym}
                          </div>

                          {/* Element Texts */}
                          <div className="flex-1 min-w-0">
                            <span className="font-mono font-black block text-[11px] text-slate-950 uppercase truncate leading-none">
                              {el.label}
                            </span>
                            <span className="text-[9.5px] text-slate-500 tracking-tight leading-snug block mt-0.5 truncate">
                              {el.desc}
                            </span>
                          </div>

                          {/* Connection Badge indicator */}
                          {el.active && (
                            <span className="absolute -top-1.5 -right-1 flex h-2.5 w-2.5">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" title="Ferramenta Alimentada com Seus Dados"></span>
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* INTERACTIVE PLAYGROUND DETAILS BOX */}
          {activeTabelaElement && (
            <div className="border-3 border-slate-950 bg-[#FAF9F6] p-6 shadow-[5px_5px_0px_rgba(0,0,0,1)] rounded-none space-y-6 animate-fadeIn">
              
              {/* Header of Active tool playground */}
              {(() => {
                const toolInfo: Record<string, { title: string; category: string; desc: string; icon: any; colorClass: string }> = {
                  SWOT: {
                    title: "Matriz SWOT Dinâmica",
                    category: "PLANEJAMENTO",
                    desc: "Análise estratégica projetando Forças (Strengths), Fraquezas (Weaknesses), Oportunidades (Opportunities) e Ameaças (Threats). Use para traçar rumos antes de desenhar fluxos.",
                    icon: <Layers size={22} />,
                    colorClass: "bg-blue-600 text-white"
                  },
                  OKR: {
                    title: "OKRs Práticos (Objetivos & Resultados-Chave)",
                    category: "PLANEJAMENTO",
                    desc: "Defina objetivos arrojados e resultados quantificáveis para ver o progresso real em vez de apenas promessas vazias.",
                    icon: <Target size={22} />,
                    colorClass: "bg-blue-600 text-white"
                  },
                  "5W2H": {
                    title: "Plano de Ação de 7 Passos (5W2H)",
                    category: "PLANEJAMENTO",
                    desc: "SUGESTÃO OP OPTIMA COMPLETO: Faça um plano robusto e envie os resultados diretamente para seu Kaizen Checklist do projeto. Perfeito para leigos executarem!",
                    icon: <FileText size={22} className="text-[#D97706]" />,
                    colorClass: "bg-[#D97706] text-white"
                  },
                  BSC: {
                    title: "Metodologia BSC (Balanced Scorecard)",
                    category: "PLANEJAMENTO",
                    desc: "Análise estratégica balanceando 4 dimensões essenciais para que lucros não destruam a satisfação do cliente ou a capacidade futura.",
                    icon: <Activity size={22} />,
                    colorClass: "bg-blue-600 text-white"
                  },
                  BPM: {
                    title: "BPM - Gestão dos Processos Integrados",
                    category: "PROCESSOS",
                    desc: "Acompanhe e faça a governança constante das regras de transição operacional das suas equipes de forma automatizada.",
                    icon: <Cpu size={22} />,
                    colorClass: "bg-emerald-600 text-white"
                  },
                  SIPOC: {
                    title: "SIPOC Automático Baseado no Seu Processo",
                    category: "PROCESSOS",
                    desc: "Diagrama de mapeamento macro relacionando Fornecedores (Suppliers), Entradas (Inputs), Processo (Process), Saídas (Outputs) e Clientes (Customers).",
                    icon: <Layers size={22} />,
                    colorClass: "bg-emerald-600 text-white"
                  },
                  FLUXOGRAMA: {
                    title: "Fluxograma Dinâmico do Processo",
                    category: "PROCESSOS",
                    desc: "Visualize graficamente os sequenciadores, tempos de ciclo, perdas e canais de tráfego ativos do seu modelo.",
                    icon: <Map size={22} />,
                    colorClass: "bg-emerald-600 text-white"
                  },
                  RACI: {
                    title: "Matriz RACI de Atribuição de Funções",
                    category: "PROCESSOS",
                    desc: "Mapeie papéis e responsabilidades para cada etapa: Responsável (R), Aprovador (A), Consultado (C) e Informado (I). Evite tarefas sem dono!",
                    icon: <Users size={22} />,
                    colorClass: "bg-emerald-600 text-white"
                  },
                  PDCA: {
                    title: "Ciclo PDCA de Gestão Contínua",
                    category: "EXECUÇÃO",
                    desc: "O motor de melhoria: Planejar (Plan), Executar (Do), Checar (Check) e Agir Corretivamente (Act). Monitore cada fase.",
                    icon: <RefreshCw size={22} />,
                    colorClass: "bg-amber-600 text-white"
                  },
                  KANBAN: {
                    title: "Quadro Kanban Interativo WIP",
                    category: "EXECUÇÃO",
                    desc: "Evite sobrecarregamento definindo limites para Trabalho em Andamento (WIP) nas suas raias de execução cotidianas.",
                    icon: <Users size={22} />,
                    colorClass: "bg-[#D97706] text-white"
                  },
                  POP: {
                    title: "POP - Procedimento Operacional Padrão",
                    category: "EXECUÇÃO",
                    desc: "Gere e copie um documento oficial detalhando exatamente o método de trabalho ideal para cada uma das suas posições operacionais.",
                    icon: <FileText size={22} />,
                    colorClass: "bg-[#D97706] text-white"
                  },
                  SCRUM: {
                    title: "Painel de Backlog Scrum Ágil",
                    category: "EXECUÇÃO",
                    desc: "Gerencie as entregas do piloto em pequenas metas semanais (Sprints) para que o leigo sinta resultados tangíveis rapidamente.",
                    icon: <Calendar size={22} />,
                    colorClass: "bg-[#D97706] text-white"
                  },
                  KPI: {
                    title: "KPI - Gestão pelas 3 Esferas Metrológicas",
                    category: "CONTROLE",
                    desc: "Monitore a integridade corporativa usando nossos medidores de Entrada, Processo e Resultados.",
                    icon: <Target size={22} />,
                    colorClass: "bg-purple-600 text-white"
                  },
                  DASHBOARD: {
                    title: "Painel de Instrumentos (Métricas)",
                    category: "CONTROLE",
                    desc: "Acompanhe de forma interativa a velocidade, gargalos estocásticos e perdas registradas na sua simulação.",
                    icon: <BarChart2 size={22} />,
                    colorClass: "bg-purple-600 text-white"
                  },
                  SLA: {
                    title: "SLA - Simulador de Prazos de Acordo",
                    category: "CONTROLE",
                    desc: "Compare o tempo prometido ao cliente com o tempo de fabricação estimado para emitir alertas automáticos antes do estouro.",
                    icon: <Timer size={22} />,
                    colorClass: "bg-purple-600 text-white"
                  },
                  OEE: {
                    title: "OEE - Eficiência Global de Processo",
                    category: "CONTROLE",
                    desc: "Métrica industrial e de serviços calculada pela multiplicação de: Disponibilidade x Performance x Qualidade de Primeira Passagem.",
                    icon: <Award size={22} />,
                    colorClass: "bg-purple-600 text-white"
                  },
                  ISHIKAWA: {
                    title: "Diagrama de Causa & Efeito (6M)",
                    category: "DIAGNÓSTICO",
                    desc: "O clássico Ishikawa (Espinha de Peixe) estruturado de forma prática para categorizar hipóteses de causas-raiz de falhas.",
                    icon: <Sparkles size={22} />,
                    colorClass: "bg-rose-600 text-white"
                  },
                  PARETO: {
                    title: "Gráfico de Pareto 80/20",
                    category: "DIAGNÓSTICO",
                    desc: "Identifique rapidamente as poucas etapas cruciais (20%) que representam a grande maioria dos desgastes e furos (80%).",
                    icon: <BarChart2 size={22} />,
                    colorClass: "bg-rose-600 text-white"
                  },
                  FMEA: {
                    title: "FMEA Prático - Análise Militar de Riscos",
                    category: "DIAGNÓSTICO",
                    desc: "Atribua pontuações de Severidade, Ocorrência e Detecção para priorizar as ações de prevenção antes que as falhas quebrem o negócio.",
                    icon: <ShieldCheck size={22} />,
                    colorClass: "bg-rose-600 text-white"
                  },
                  DMAIC: {
                    title: "Roteiro DMAIC Completo do Ciclo Six Sigma",
                    category: "DIAGNÓSTICO",
                    desc: "Siga o passo-a-passo rigoroso: Definir, Medir, Analisar, Incrementar e Controlar os projetos de melhoria contínua da empresa.",
                    icon: <Layers size={22} />,
                    colorClass: "bg-rose-600 text-white"
                  }
                }[activeTabelaElement] || {
                  title: "Ferramenta da Gestão",
                  category: "Geral",
                  desc: "Selecione uma ferramenta.",
                  icon: <Layers size={22} />,
                  colorClass: "bg-slate-900 text-white"
                };

                return (
                  <div className="space-y-6">
                    {/* Header Banner and Context */}
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b-2 border-slate-900 pb-4 gap-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-none border border-slate-950 flex items-center justify-center ${toolInfo.colorClass}`}>
                          {toolInfo.icon}
                        </div>
                        <div>
                          <span className="text-[9px] font-mono font-black uppercase bg-slate-900 text-white px-2 py-0.5 border border-slate-950 tracking-wider">
                            {toolInfo.category}
                          </span>
                          <h4 className="text-lg font-serif font-black text-slate-900 uppercase tracking-tight mt-1">
                            {toolInfo.title}
                          </h4>
                        </div>
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-500 uppercase bg-slate-102 px-2.5 py-1 border border-slate-205">
                        💡 Fácil de Usar para Leigos
                      </span>
                    </div>

                    <p className="text-xs md:text-sm text-slate-600 leading-relaxed font-sans max-w-4xl italic">
                      " {toolInfo.desc} "
                    </p>

                    {/* SWOT MATRIX INTERACTIVE CONTENT */}
                    {activeTabelaElement === "SWOT" && (
                      <div className="space-y-4 animate-fadeIn">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          
                          {/* Strengths */}
                          <div className="bg-emerald-50/20 border-2 border-emerald-600 p-4 space-y-3">
                            <h5 className="font-mono font-black text-[#047857] text-[11px] uppercase tracking-wide flex items-center gap-1">
                              💪 S - FORÇAS (Interno / Positivo)
                            </h5>
                            <ul className="space-y-1.5 text-xs text-slate-700 font-sans">
                              {swotStrengths.map((s, i) => (
                                <li key={i} className="flex items-center justify-between bg-white p-1.5 border border-emerald-100 rounded-xs">
                                  <span>🔹 {s}</span>
                                  <button
                                    onClick={() => setSwotStrengths((prev) => prev.filter((_, idx) => idx !== i))}
                                    className="text-red-500 hover:text-red-700 text-[10px] uppercase font-mono font-bold cursor-pointer hover:bg-red-50 p-1"
                                  >
                                    Remover
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Weaknesses */}
                          <div className="bg-amber-50/25 border-2 border-amber-600 p-4 space-y-3">
                            <h5 className="font-mono font-black text-amber-800 text-[11px] uppercase tracking-wide flex items-center gap-1">
                              ⚠️ W - FRAQUEZAS (Interno / Negativo)
                            </h5>
                            <ul className="space-y-1.5 text-xs text-slate-700 font-sans">
                              {swotWeaknesses.map((s, i) => (
                                <li key={i} className="flex items-center justify-between bg-white p-1.5 border border-amber-100 rounded-xs">
                                  <span>🔸 {s}</span>
                                  <button
                                    onClick={() => setSwotWeaknesses((prev) => prev.filter((_, idx) => idx !== i))}
                                    className="text-red-500 hover:text-red-700 text-[10px] uppercase font-mono font-bold cursor-pointer hover:bg-red-50 p-1"
                                  >
                                    Remover
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Opportunities */}
                          <div className="bg-blue-50/20 border-2 border-blue-600 p-4 space-y-3">
                            <h5 className="font-mono font-black text-blue-900 text-[11px] uppercase tracking-wide flex items-center gap-1">
                              🌱 O - OPORTUNIDADES (Externo / Positivo)
                            </h5>
                            <ul className="space-y-1.5 text-xs text-slate-700 font-sans">
                              {swotOpportunities.map((s, i) => (
                                <li key={i} className="flex items-center justify-between bg-white p-1.5 border border-blue-100 rounded-xs">
                                  <span>🔹 {s}</span>
                                  <button
                                    onClick={() => setSwotOpportunities((prev) => prev.filter((_, idx) => idx !== i))}
                                    className="text-red-500 hover:text-red-700 text-[10px] uppercase font-mono font-bold cursor-pointer hover:bg-red-50 p-1"
                                  >
                                    Remover
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Threats */}
                          <div className="bg-rose-50/20 border-2 border-rose-600 p-4 space-y-3">
                            <h5 className="font-mono font-black text-rose-900 text-[11px] uppercase tracking-wide flex items-center gap-1">
                              💀 T - AMEAÇAS (Externo / Negativo)
                            </h5>
                            <ul className="space-y-1.5 text-xs text-slate-700 font-sans">
                              {swotThreats.map((s, i) => (
                                <li key={i} className="flex items-center justify-between bg-white p-1.5 border border-rose-100 rounded-xs">
                                  <span>🔸 {s}</span>
                                  <button
                                    onClick={() => setSwotThreats((prev) => prev.filter((_, idx) => idx !== i))}
                                    className="text-red-500 hover:text-red-700 text-[10px] uppercase font-mono font-bold cursor-pointer hover:bg-red-50 p-1"
                                  >
                                    Remover
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>

                        </div>

                        {/* Add SWOT Input Form */}
                        <div className="bg-white border p-4 space-y-3 max-w-xl">
                          <p className="text-[10px] font-mono font-bold uppercase text-slate-600">✍️ Adicionar Item SWOT Customizado:</p>
                          <div className="flex flex-col sm:flex-row gap-2 select-none">
                            <select
                              value={activeSwotQuadrant}
                              onChange={(e: any) => setActiveSwotQuadrant(e.target.value)}
                              className="border border-slate-300 p-2 text-xs font-mono outline-none focus:border-slate-900 bg-slate-50"
                            >
                              <option value="strengths">💪 Força (S)</option>
                              <option value="weaknesses">⚠️ Fraqueza (W)</option>
                              <option value="opportunities">🌱 Oportunidade (O)</option>
                              <option value="threats">💀 Ameaça (T)</option>
                            </select>
                            <input
                              type="text"
                              placeholder="Digite aqui..."
                              value={newSwotItem}
                              onChange={(e) => setNewSwotItem(e.target.value)}
                              className="flex-1 border border-slate-350 p-2 text-xs outline-none focus:border-slate-900 bg-slate-50/50"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (!newSwotItem.trim()) return;
                                if (activeSwotQuadrant === "strengths") setSwotStrengths((prev) => [...prev, newSwotItem.trim()]);
                                if (activeSwotQuadrant === "weaknesses") setSwotWeaknesses((prev) => [...prev, newSwotItem.trim()]);
                                if (activeSwotQuadrant === "opportunities") setSwotOpportunities((prev) => [...prev, newSwotItem.trim()]);
                                if (activeSwotQuadrant === "threats") setSwotThreats((prev) => [...prev, newSwotItem.trim()]);
                                setNewSwotItem("");
                              }}
                              className="px-4 py-2 bg-[#1A1A1A] text-white hover:bg-blue-650 font-mono font-bold text-xs uppercase cursor-pointer"
                            >
                              Inserir
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* OKR PLAYGROUND */}
                    {activeTabelaElement === "OKR" && (
                      <div className="space-y-4 animate-fadeIn">
                        <div className="space-y-4">
                          {okrsList.map((okr, idx) => (
                            <div key={okr.id} className="bg-white border border-slate-300 p-4 space-y-4">
                              <div className="flex items-center justify-between border-b pb-2">
                                <span className="text-[10px] font-mono font-extrabold uppercase bg-blue-100 text-blue-900 px-2 py-0.5">
                                  Objetivo #{idx + 1}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => setOkrsList((prev) => prev.filter((o) => o.id !== okr.id))}
                                  className="text-[10px] font-mono font-bold text-red-500 hover:text-red-700 cursor-pointer"
                                >
                                  Excluir
                                </button>
                              </div>
                              <h5 className="font-bold text-sm text-slate-900">{okr.objective}</h5>

                              <div className="space-y-3.5 pl-4">
                                {/* KR 1 */}
                                <div className="space-y-1">
                                  <div className="flex justify-between text-xs font-mono">
                                    <span className="text-slate-650">🟢 KR1: {okr.kr1}</span>
                                    <span className="font-extrabold text-slate-900">{okr.kr1Val} / {okr.kr1Target}</span>
                                  </div>
                                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                                    <div
                                      className="bg-emerald-500 h-full transition-all"
                                      style={{ width: `${Math.min(100, (okr.kr1Val / okr.kr1Target) * 100)}%` }}
                                    ></div>
                                  </div>
                                  <div className="flex items-center gap-2 pt-1 font-mono text-[10px]">
                                    <span>Ajustar valor real:</span>
                                    <input
                                      type="range"
                                      min="0"
                                      max={okr.kr1Target * 1.5}
                                      value={okr.kr1Val}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        setOkrsList((prev) => prev.map((o) => o.id === okr.id ? { ...o, kr1Val: val } : o));
                                      }}
                                      className="w-32 accent-blue-600"
                                    />
                                  </div>
                                </div>

                                {/* KR 2 */}
                                <div className="space-y-1">
                                  <div className="flex justify-between text-xs font-mono">
                                    <span className="text-slate-650">🟣 KR2: {okr.kr2}</span>
                                    <span className="font-extrabold text-slate-900">{okr.kr2Val} / {okr.kr2Target}</span>
                                  </div>
                                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                                    <div
                                      className="bg-purple-500 h-full transition-all"
                                      style={{ width: `${Math.min(100, (okr.kr2Val / okr.kr2Target) * 100)}%` }}
                                    ></div>
                                  </div>
                                  <div className="flex items-center gap-2 pt-1 font-mono text-[10px]">
                                    <span>Ajustar valor real:</span>
                                    <input
                                      type="range"
                                      min="0"
                                      max={okr.kr2Target * 1.5}
                                      value={okr.kr2Val}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        setOkrsList((prev) => prev.map((o) => o.id === okr.id ? { ...o, kr2Val: val } : o));
                                      }}
                                      className="w-32 accent-purple-600"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 5W2H - NEW TOOL & INTEGRATION */}
                    {activeTabelaElement === "5W2H" && (
                      <div className="space-y-6 animate-fadeIn font-sans" id="sec-5w2h">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                          
                          {/* Form Section */}
                          <div className="lg:col-span-2 bg-white border border-slate-350 p-5 space-y-4 shadow-sm">
                            <span className="text-[9px] font-mono font-black uppercase text-[#D97706] bg-amber-50 px-2 py-0.5 border border-amber-300">
                              Novo Planejamento 5W2H
                            </span>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">📌 WHAT (O que será feito?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hWhat}
                                  onChange={(e) => setFiveW2hWhat(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">❓ WHY (Por que será feito?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hWhy}
                                  onChange={(e) => setFiveW2hWhy(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">📍 WHERE (Onde será feito?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hWhere}
                                  onChange={(e) => setFiveW2hWhere(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">👤 WHO (Quem executará?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hWho}
                                  onChange={(e) => setFiveW2hWho(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">📅 WHEN (Quando será feito?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hWhen}
                                  onChange={(e) => setFiveW2hWhen(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">🛠️ HOW (Como será feito?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hHow}
                                  onChange={(e) => setFiveW2hHow(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                              <div className="space-y-1 md:col-span-2">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-600">💰 HOW MUCH (Quanto custará?):</label>
                                <input
                                  type="text"
                                  value={fiveW2hHowMuch}
                                  onChange={(e) => setFiveW2hHowMuch(e.target.value)}
                                  className="w-full border border-slate-300 p-2 text-xs bg-slate-50/20 focus:bg-white"
                                />
                              </div>
                            </div>

                            {/* Link and Save Actions button */}
                            <button
                              type="button"
                              onClick={async () => {
                                if (!fiveW2hWhat.trim()) return;
                                const id = `5w2h_${Date.now()}`;
                                const newActionPlan = {
                                  id,
                                  what: fiveW2hWhat,
                                  why: fiveW2hWhy,
                                  where: fiveW2hWhere,
                                  who: fiveW2hWho,
                                  when: fiveW2hWhen,
                                  how: fiveW2hHow,
                                  howMuch: fiveW2hHowMuch,
                                  linked: true
                                };
                                setFiveW2hPlans((prev) => [...prev, newActionPlan]);

                                // AUTO CONNECT: Send task to Kaizen checklist!
                                const taskText = `[5W2H] ${fiveW2hWhat} (Atribuição: ${fiveW2hWho} | Até: ${fiveW2hWhen} | Como: ${fiveW2hHow})`;
                                if (!auth.currentUser) {
                                  // Sandbox fallback
                                  const newTask = {
                                    id: `task_${Date.now()}_5w`,
                                    text: taskText,
                                    done: false,
                                    createdAt: new Date()
                                  };
                                  setImprovementTasks(prev => [...prev, newTask]);
                                } else {
                                  const taskId = `task_${Date.now()}_5w`;
                                  if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
                                    setImprovementTasks(prev => [...prev, { id: taskId, text: taskText, done: false, createdAt: new Date() }]);
                                  } else {
                                    try {
                                      await setDoc(doc(db, "layperson_tasks", taskId), {
                                        id: taskId,
                                        userId: auth.currentUser.uid,
                                        text: taskText,
                                        done: false,
                                        createdAt: new Date()
                                      });
                                    } catch (err) {
                                      console.error(err);
                                    }
                                  }
                                }

                                alert(`✅ Plano 5W2H Adicionado!\n\nAção: "${fiveW2hWhat}" foi vinculada e enviada automaticamente como uma tarefa em aberto no "Plano Kaizen" da aba "Ideias de Alívio (Melhoria)"!`);
                                setFiveW2hWhat("");
                                setFiveW2hWhy("");
                                setFiveW2hWho("");
                                setFiveW2hWhen("");
                                setFiveW2hHow("");
                                setFiveW2hHowMuch("");
                              }}
                              className="w-full py-2.5 bg-[#D97706] hover:bg-slate-900 border border-slate-950 font-mono font-bold text-xs uppercase cursor-pointer text-white select-none transition-all"
                            >
                              🔌 Integrar &amp; Enviar p/ Plano Kaizen Checklist
                            </button>
                            <p className="text-[10px] text-slate-500 font-sans text-center">
                              A ferramenta de 5W2H é ideal para direcionar a execução. Ao clicar acima, a tarefa de controle entra na rotina diária dinamicamente!
                            </p>
                          </div>

                          {/* Historical Registered Action Plans (Showing Dynamic Connections) */}
                          <div className="space-y-4">
                            <h5 className="font-mono font-black text-slate-900 text-[11px] uppercase tracking-wide">
                              📋 Planos Gerados Habilitados ({fiveW2hPlans.length})
                            </h5>
                            {fiveW2hPlans.length === 0 ? (
                              <p className="text-xs text-slate-400 italic">Nenhum plano gerado de momento.</p>
                            ) : (
                              <div className="space-y-3">
                                {fiveW2hPlans.map((plan) => (
                                  <div key={plan.id} className="bg-amber-50/15 border border-[#D97706]/35 p-3.5 space-y-2 text-xs relative">
                                    <div className="flex justify-between items-start">
                                      <span className="font-extrabold text-slate-950 block">✔️ {plan.what}</span>
                                      <button
                                        type="button"
                                        onClick={() => setFiveW2hPlans((prev) => prev.filter((p) => p.id !== plan.id))}
                                        className="text-[10px] font-mono text-red-500 hover:text-red-700 cursor-pointer pl-2"
                                      >
                                        Remover
                                      </button>
                                    </div>
                                    <div className="grid grid-cols-2 gap-1.5 font-mono text-[10.5px] text-slate-600 border-t pt-2 border-slate-200/50">
                                      <div><span className="font-black text-slate-800">Por que:</span> {plan.why || "N/A"}</div>
                                      <div><span className="font-black text-slate-800">Quem:</span> {plan.who || "N/A"}</div>
                                      <div><span className="font-black text-slate-800">Prazo:</span> {plan.when || "N/A"}</div>
                                      <div><span className="font-black text-slate-800">Custo:</span> {plan.howMuch || "N/A"}</div>
                                    </div>
                                    <div className="text-[10px] bg-[#E8F5E9] text-[#1B5E20] border border-[#A5D6A7]/30 p-1 font-mono uppercase text-center mt-2">
                                      🟢 Conectado ao Kaizen Síncrono
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                        </div>
                      </div>
                    )}

                    {/* BSC INTERACTIVE SCORES */}
                    {activeTabelaElement === "BSC" && (
                      <div className="space-y-4 animate-fadeIn">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
                          {[
                            { name: "💵 Finanças", metric: "ROI / Lucro Operacional", status: "Dentro da Meta (85%)", color: "bg-blue-50 border-blue-200" },
                            { name: "👥 Clientes", metric: "NPS / Satisfação de Atendimento", status: "Abaixo do Esperado (72%)", color: "bg-purple-50 border-purple-200" },
                            { name: "⚙️ Processos Internos", metric: "Tempo de Ciclo / Yield Livre", status: "Crítico no Gargalo (60%)", color: "bg-emerald-50 border-emerald-200" },
                            { name: "🌱 Aprendizado", metric: "Treinamentos / Habilidades", status: "Meta Cumprida (90%)", color: "bg-amber-50 border-amber-200" }
                          ].map((quad, idx) => (
                            <div key={idx} className={`p-4 border-2 space-y-2 flex flex-col justify-between ${quad.color}`}>
                              <div>
                                <span className="font-black block uppercase text-[11px] border-b pb-1 mb-1">{quad.name}</span>
                                <span className="text-slate-605 text-[10.5px]">Métrica principal:</span>
                                <p className="font-extrabold text-slate-900 leading-tight">{quad.metric}</p>
                              </div>
                              <span className="px-1.5 py-0.5 bg-white text-slate-800 border text-center block text-[10px] font-bold mt-2">
                                {quad.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* BPM EXPLANATORY */}
                    {activeTabelaElement === "BPM" && (
                      <div className="space-y-4 animate-fadeIn text-xs">
                        <div className="bg-emerald-50/20 border border-emerald-300 p-4 space-y-3 font-mono">
                          <h5 className="font-extrabold uppercase text-emerald-900">🧭 Governança BPM (Business Process Management) Ativa</h5>
                          <p className="font-sans text-slate-650 leading-relaxed">
                            O BPM prega a melhoria contínua de ponta a ponta. Atualmente, o seu motor estocástico está monitorando:
                          </p>
                          <ul className="space-y-2 font-mono">
                            <li>🔹 Quantidade de etapas desenhadas: <strong>{steps.length} postos ativos</strong></li>
                            <li>🔹 Volume de entrada esperado: <strong>{arrivalRate.toFixed(1)} pedidos por hora</strong></li>
                            <li>🔹 Posto restritivo (Gargalo principal): <strong className="text-red-700 bg-red-50 px-2 py-0.5 border">"{stats.bottleneckStepName}"</strong></li>
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* DYNAMIC SIPOC VIEW */}
                    {activeTabelaElement === "SIPOC" && (
                      <div className="space-y-4 animate-fadeIn text-xs font-mono" id="sec-sipoc">
                        <div className="grid grid-cols-1 md:grid-cols-5 border-2 border-slate-900 divide-y md:divide-y-0 md:divide-x divide-slate-350 select-none">
                          
                          {/* Suppliers */}
                          <div className="p-4 bg-slate-50 space-y-2 flex flex-col justify-between">
                            <span className="font-black border-b border-slate-300 pb-1 uppercase tracking-wider block text-slate-900">S - FORNECEDOR</span>
                            <p className="text-[11px] text-slate-550 font-sans leading-snug">
                              De onde vêm os insumos? Normalmente representados por clientes externos ou áreas internas anteriores.
                            </p>
                            <span className="bg-slate-900 text-white p-1 text-[10px] text-center font-bold">📢 Entrada Externa</span>
                          </div>

                          {/* Inputs */}
                          <div className="p-4 bg-white space-y-2 flex flex-col justify-between">
                            <span className="font-black border-b border-slate-300 pb-1 uppercase tracking-wider block text-slate-900">I - ENTRADAS</span>
                            <p className="text-[11px] text-slate-550 font-sans leading-snug">
                              Materiais, dados cadastrais, e-mails de solicitação, chamados ou insumos físicos necessários para iniciar.
                            </p>
                            <span className="bg-emerald-100 text-emerald-900 p-1 text-[10px] text-center font-bold">📦 {arrivalRate} Pedidos/h</span>
                          </div>

                          {/* Process */}
                          <div className="p-4 bg-emerald-50/10 space-y-2 flex flex-col justify-between">
                            <span className="font-black border-b border-slate-300 pb-1 uppercase tracking-wider block text-slate-900">P - PROCESSO</span>
                            <div className="space-y-1">
                              {steps.map((s, idx) => (
                                <div key={s.id} className="text-[11.5px] truncate font-bold text-slate-800">
                                  {idx + 1}. {s.name}
                                </div>
                              ))}
                            </div>
                            <span className="bg-emerald-950 text-white p-1 text-[10px] text-center font-bold">⚙️ {steps.length} Estações</span>
                          </div>

                          {/* Outputs */}
                          <div className="p-4 bg-white space-y-2 flex flex-col justify-between">
                            <span className="font-black border-b border-slate-300 pb-1 uppercase tracking-wider block text-slate-900">O - SAÍDAS</span>
                            <p className="text-[11px] text-slate-550 font-sans leading-snug">
                              Serviço devidamente aprovado, produto pronto embalado, relatório emitido ou suporte resolvido ao final.
                            </p>
                            <span className="bg-blue-100 text-blue-900 p-1 text-[10px] text-center font-bold">💎 Rendimento Global</span>
                          </div>

                          {/* Customers */}
                          <div className="p-4 bg-slate-50 space-y-2 flex flex-col justify-between">
                            <span className="font-black border-b border-slate-300 pb-1 uppercase tracking-wider block text-slate-900">C - CLIENTE</span>
                            <p className="text-[11px] text-slate-550 font-sans leading-snug">
                              Destinatário final da operação que pagará pela entrega ou a próxima gerência corporativa.
                            </p>
                            <span className="bg-slate-900 text-white p-1 text-[10px] text-center font-bold">👥 Consumidor Final</span>
                          </div>

                        </div>
                      </div>
                    )}

                    {/* DYNAMIC FLOWCHART (FLUXOGRAMA) */}
                    {activeTabelaElement === "FLUXOGRAMA" && (
                      <div className="space-y-4 animate-fadeIn text-xs" id="sec-flowchart">
                        <div className="bg-white border p-6 overflow-x-auto">
                          <div className="flex items-center gap-4 min-w-[650px] justify-center py-4">
                            
                            {/* Start */}
                            <div className="bg-slate-900 text-white px-4 py-3 rounded-full font-mono text-xs font-bold shrink-0 border border-slate-950 select-none shadow">
                              📥 Início
                            </div>

                            <ChevronRight size={20} className="text-slate-400 shrink-0" />

                            {/* Dynamically drawn steps */}
                            {steps.map((step, idx) => {
                              const isBottleneck = step.name === stats.bottleneckStepName;
                              return (
                                <React.Fragment key={step.id}>
                                  <div
                                    className={`p-4 border-2 max-w-[160px] text-center space-y-1.5 shrink-0 select-none ${
                                      isBottleneck
                                        ? "border-red-600 bg-red-50/20 shadow-[3px_3px_0px_rgba(220,38,38,1)]"
                                        : "border-slate-800 bg-white shadow-[2px_2px_0px_rgba(30,41,59,1)]"
                                    }`}
                                  >
                                    <span className="text-[9px] font-mono font-black uppercase text-slate-400 block">Etapa #{idx + 1}</span>
                                    <strong className="text-xs text-slate-900 block truncate" title={step.name}>{step.name}</strong>
                                    <div className="text-[10px] font-mono space-y-0.5 text-slate-600 border-t pt-1">
                                      <div>⏱️ {step.processingTime} min</div>
                                      <div>🛡️ {(step.yieldRate * 100).toFixed(0)}% ok</div>
                                    </div>
                                    {isBottleneck && (
                                      <span className="text-[8px] font-mono font-black bg-red-600 text-white px-2 py-0.5 rounded-none block">🚨 GARGALO</span>
                                    )}
                                  </div>

                                  <ChevronRight size={20} className="text-slate-400 shrink-0" />
                                </React.Fragment>
                              );
                            })}

                            {/* End */}
                            <div className="bg-emerald-600 text-white px-4 py-3 rounded-full font-mono text-xs font-bold shrink-0 border border-emerald-950 select-none shadow">
                              🏁 Fim (SLA)
                            </div>

                          </div>
                        </div>
                      </div>
                    )}

                    {/* INTERACTIVE RACI MATRIX */}
                    {activeTabelaElement === "RACI" && (
                      <div className="space-y-4 animate-fadeIn text-xs font-mono" id="sec-raci">
                        <div className="bg-white border overflow-x-auto select-none">
                          <table className="w-full text-left font-mono border-collapse border-2 border-slate-950 min-w-[600px]">
                            <thead>
                              <tr className="bg-slate-900 text-white text-[10.5px]">
                                <th className="p-3 border border-slate-950">Etapa Operacional</th>
                                <th className="p-3 border border-slate-950 text-center">🏆 Gestor de Área</th>
                                <th className="p-3 border border-slate-950 text-center">🔧 Operadores</th>
                                <th className="p-3 border border-slate-950 text-center">🔍 Inspetor de Qualidade</th>
                                <th className="p-3 border border-slate-950 text-center">💬 Cliente Interno/Final</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                              {steps.map((step, idx) => (
                                <tr key={step.id} className="hover:bg-slate-50 text-[11px]">
                                  <td className="p-3 border border-slate-350 font-bold text-slate-900">
                                    {idx + 1}. {step.name}
                                  </td>
                                  <td className="p-3 border border-slate-350 text-center">
                                    <span className="bg-blue-100 text-blue-900 font-black px-2.5 py-1 text-xs border rounded-xs" title="Accountable (Quem Aprova)">A</span>
                                  </td>
                                  <td className="p-3 border border-slate-350 text-center">
                                    <span className="bg-emerald-100 text-emerald-900 font-black px-2.5 py-1 text-xs border rounded-xs" title="Responsible (Quem Executa)">R</span>
                                  </td>
                                  <td className="p-3 border border-slate-350 text-center">
                                    <span className="bg-purple-100 text-purple-900 font-black px-2.5 py-1 text-xs border rounded-xs" title="Consulted (Quem é Consultado)">C</span>
                                  </td>
                                  <td className="p-3 border border-slate-350 text-center">
                                    <span className="bg-slate-102 text-slate-600 font-black px-2.5 py-1 text-xs border rounded-xs" title="Informed (Quem é Informado)">I</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        <p className="text-[10px] text-slate-500 italic mt-1 font-sans">
                          A matriz RACI garante o equilíbrio das atribuições diárias nas etapas operacionais para evitar gargalos humanos por omissão de responsabilidade.
                        </p>
                      </div>
                    )}

                    {/* PDCA CYCLING CHECK */}
                    {activeTabelaElement === "PDCA" && (
                      <div className="space-y-4 animate-fadeIn">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
                          
                          {/* Plan */}
                          <div className="border border-blue-500 bg-white p-4 space-y-2 shadow-sm rounded-none">
                            <span className="text-[10px] font-mono font-black text-blue-700 block uppercase border-b pb-1">
                              📋 P - PLAN (Planejar)
                            </span>
                            <div className="space-y-1 font-sans pt-1">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" defaultChecked className="accent-blue-600" />
                                <span className="line-through text-slate-400">Desenhar o fluxo operacional</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" defaultChecked className="accent-blue-600" />
                                <span className="line-through text-slate-400">Identificar o gargalo online</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-blue-600" />
                                <span>Definir metas de performance</span>
                              </label>
                            </div>
                          </div>

                          {/* Do */}
                          <div className="border border-emerald-500 bg-white p-4 space-y-2 shadow-sm rounded-none">
                            <span className="text-[10px] font-mono font-black text-emerald-700 block uppercase border-b pb-1">
                              🛠️ D - DO (Executar)
                            </span>
                            <div className="space-y-1 font-sans pt-1">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" defaultChecked className="accent-emerald-600" />
                                <span className="line-through text-slate-400">Aplicar melhorias rápidas (Kaizen)</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-emerald-600" />
                                <span>Treinar operadores no novo padrão</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-emerald-600" />
                                <span>Manter os limites visuais de Kanban</span>
                              </label>
                            </div>
                          </div>

                          {/* Check */}
                          <div className="border border-purple-500 bg-white p-4 space-y-2 shadow-sm rounded-none">
                            <span className="text-[10px] font-mono font-black text-purple-700 block uppercase border-b pb-1">
                              🔍 C - CHECK (Checar)
                            </span>
                            <div className="space-y-1 font-sans pt-1">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" defaultChecked className="accent-purple-600" />
                                <span className="line-through text-slate-400">Investigar estatísticas no painel</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-purple-600" />
                                <span>Conferir perdas por retrabalho</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-purple-600" />
                                <span>Avaliar prazos síncronos de SLA</span>
                              </label>
                            </div>
                          </div>

                          {/* Act */}
                          <div className="border border-rose-500 bg-white p-4 space-y-2 shadow-sm rounded-none">
                            <span className="text-[10px] font-mono font-black text-rosy-700 block uppercase border-b pb-1">
                              🚀 A - ACT (Agir Corretivamente)
                            </span>
                            <div className="space-y-1 font-sans pt-1">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-rose-600" />
                                <span>Documentar as lições aprendidas</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-rose-600" />
                                <span>Girar o ciclo padrão novamente</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="accent-rose-600" />
                                <span>Escalar para toda a matriz</span>
                              </label>
                            </div>
                          </div>

                        </div>
                      </div>
                    )}

                    {/* SIMPLIFIED KANBAN BOARD POP */}
                    {activeTabelaElement === "KANBAN" && (
                      <div className="space-y-4 animate-fadeIn text-xs" id="sec-kanban">
                        <div className="bg-[#EAE8E4] border border-slate-300 p-4 rounded-none select-none">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            
                            {/* To Do */}
                            <div className="bg-[#FAF9F6] border-2 border-slate-400 p-2.5 min-h-[140px] space-y-3 flex flex-col justify-between">
                              <div>
                                <span className="font-bold border-b pb-1 block uppercase font-mono text-[9.5px]">📥 A Fazer (SLA Pendente)</span>
                                <div className="space-y-2 pt-2">
                                  <div className="bg-amber-100/50 p-2 border border-amber-300/60 font-sans text-[11px] font-medium">
                                    📋 Tratar desvios de cadastro no formulário inicial
                                  </div>
                                </div>
                              </div>
                              <span className="text-[9px] font-mono text-slate-400 block text-center uppercase">1 Item em Fila</span>
                            </div>

                            {/* Doing */}
                            <div className="bg-[#FAF9F6] border-2 border-indigo-950 p-2.5 min-h-[140px] space-y-3 flex flex-col justify-between">
                              <div>
                                <span className="font-bold border-b pb-1 block uppercase font-mono text-[9.5px] text-indigo-950">⚙️ Em Execução (Máx WIP: {steps.length})</span>
                                <div className="space-y-2 pt-2">
                                  <div className="bg-indigo-50/50 p-2 border border-indigo-300/45 font-sans text-[11px] font-medium">
                                    🧪 Testando balanceamento do posto: <strong>"{stats.bottleneckStepName}"</strong>
                                  </div>
                                </div>
                              </div>
                              <span className="text-[9px] font-mono text-indigo-900 block text-center uppercase">Ativo</span>
                            </div>

                            {/* Done */}
                            <div className="bg-[#FAF9F6] border-2 border-emerald-600 p-2.5 min-h-[140px] space-y-3 flex flex-col justify-between">
                              <div>
                                <span className="font-bold border-b pb-1 block uppercase font-mono text-[9.5px] text-emerald-800 font-extrabold flex items-center justify-between">
                                  <span>🏁 Concluído</span>
                                  <span className="text-emerald-700 bg-emerald-50 px-1 py-0.2 rounded font-mono text-[9px] border">FTY</span>
                                </span>
                                <div className="space-y-2 pt-2">
                                  <div className="bg-emerald-50/50 p-2 border border-emerald-300/40 text-slate-500 font-sans text-[11px] line-through">
                                    🍃 Desenhar mapa estrutural das etapas operacionais
                                  </div>
                                </div>
                              </div>
                              <span className="text-[9px] font-mono text-emerald-800 block text-center uppercase font-black">Finalizado</span>
                            </div>

                          </div>
                        </div>
                      </div>
                    )}

                    {/* POP - THE DOCUMENT GENERATOR */}
                    {activeTabelaElement === "POP" && (
                      <div className="space-y-4 animate-fadeIn font-sans" id="sec-pop">
                        <div className="bg-white border-2 border-slate-900 p-5 space-y-4 shadow rounded-none">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3">
                            <div>
                              <p className="text-[10px] font-mono font-bold uppercase text-slate-500">Selecione uma etapa para visualizar seu padrão:</p>
                              <select
                                value={popSelectedStepId}
                                onChange={(e) => setPopSelectedStepId(e.target.value)}
                                className="border border-slate-350 p-1.5 text-xs font-mono outline-none focus:border-slate-950 bg-slate-50 mt-1"
                              >
                                {steps.map((st) => (
                                  <option key={st.id} value={st.id}>{st.name}</option>
                                ))}
                              </select>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                const selectedStep = steps.find((s) => s.id === popSelectedStepId) || steps[0];
                                if (!selectedStep) return;
                                const docText = `====================================================
PROCEDIMENTO OPERACIONAL PADRÃO (POP)
====================================================
Etapa Mapeada: ${selectedStep.name}
Recurso Principal: ${selectedStep.resource}
Tempo de Ciclo Padrão: ${selectedStep.processingTime} min (SD: ${selectedStep.standardDeviation} min)
Rendimento Alvo (Yield): ${(selectedStep.yieldRate * 100).toFixed(0)}% de Acertos

ORIENTAÇÕES DE EXECUÇÃO:
1. Realize a verificação rápida dos dados de entrada antes de processar.
2. Siga rigorosamente a ordem sequencial dos campos obrigatórios.
3. Havendo qualquer anomalia ou erro estatístico, abra um registro síncrono.
4. Mantenha os limites de WIP Kanban sem acúmulos na bancada.
`;
                                navigator.clipboard.writeText(docText);
                                alert("📋 Texto do POP copiado com sucesso para a área de transferência!");
                              }}
                              className="px-4 py-2 border bg-slate-102 hover:bg-slate-200 text-slate-900 border-slate-350 font-mono font-bold text-xs uppercase cursor-pointer transition"
                            >
                              📋 Copiar Texto do POP
                            </button>
                          </div>

                          {/* Rendered Document */}
                          {(() => {
                            const selectedStep = steps.find((s) => s.id === popSelectedStepId) || steps[0];
                            if (!selectedStep) return <p className="text-xs text-slate-400 italic">Configure etapas no menu 'Desenhar as Etapas' primeiro.</p>;
                            return (
                              <div className="bg-slate-50 border p-5 font-mono text-xs text-slate-800 space-y-4">
                                <div className="text-center font-black text-sm border-b-2 border-slate-900 pb-2">
                                  📄 REGISTRO DE PADRÃO OPERACIONAL (POP)
                                </div>
                                <div className="grid grid-cols-2 gap-3 border-b pb-4">
                                  <div><strong>Área Processual:</strong> {businessType}</div>
                                  <div><strong>Etapa Mapeada:</strong> {selectedStep.name}</div>
                                  <div><strong>Recurso Chave:</strong> {selectedStep.resource} (Qtd: {selectedStep.resourceCount})</div>
                                  <div><strong>Tempo Ideal de Execução:</strong> {selectedStep.processingTime.toFixed(1)} minutos</div>
                                </div>
                                <div className="space-y-2">
                                  <strong>🛠️ Instruções de Trabalho da Rotina:</strong>
                                  <ol className="list-decimal pl-4 space-y-1 font-sans text-slate-650 leading-relaxed text-[11.5px]">
                                    <li>Verifique se o pedido/item que deu entrada de fato possui todos os anexos, dados e assinaturas limpas de conformidade operacional.</li>
                                    <li>Abra o formulário de cadastramento ou execute o processamento correspondente sem desvios, operando focado de ponta a ponta na tarefa.</li>
                                    <li>Ao pregar o encerramento da etapa, revise as pendências de retrabalho para certificar o rendimento global de <strong>{(selectedStep.yieldRate * 100).toFixed(0)}%</strong> livre de falhas de primeira passagem.</li>
                                    <li>Certifique-se de carimbar o status adiante na ferramenta de modo síncrono.</li>
                                  </ol>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                    )}

                    {/* SCRUM STORY BOARD */}
                    {activeTabelaElement === "SCRUM" && (
                      <div className="space-y-4 animate-fadeIn">
                        <div className="bg-white border p-4 space-y-3 font-mono text-xs">
                          <h5 className="font-extrabold text-slate-900 uppercase">🏃‍♂️ Planejamento de Sprint Ágil</h5>
                          <p className="font-sans text-slate-600 leading-relaxed">
                            O Scrum acelera entregas leigas dividindo em Sprints fáceis. Configurado para a atual Sprint Semanal:
                          </p>
                          <div className="space-y-2">
                            <div className="p-2 border bg-amber-50/50 flex justify-between items-center">
                              <span>🔸 Histórico 1: Reduzir tempo no posto <strong>"{stats.bottleneckStepName}"</strong></span>
                              <span className="bg-amber-100 text-amber-800 px-2 py-0.5 font-bold uppercase text-[9px] rounded-0">Em Andamento</span>
                            </div>
                            <div className="p-2 border bg-emerald-50/40 flex justify-between items-center">
                              <span>🔹 Histórico 2: Documentar POP de pelo menos 1 etapa crítica</span>
                              <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 font-bold uppercase text-[9px] rounded-0">Pronto</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* KPI GAUGE CHECK */}
                    {activeTabelaElement === "KPI" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs">
                        <div className="bg-[#E8EAF6] border border-indigo-200 p-5 space-y-4 rounded-none">
                          <h5 className="font-extrabold uppercase text-[#1A237E] flex items-center gap-1">📊 Sua Governança de 3 Esferas Conectada</h5>
                          <p className="font-sans text-slate-650 leading-relaxed">
                            Monitoramento online derivado do seu mapeamento e parâmetros atuais de chegada:
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-center">
                            <div className="bg-white p-3 border border-indigo-100 flex flex-col justify-between">
                              <span className="text-[10px] uppercase text-indigo-500">📥 1. Entrada (Pedidos)</span>
                              <strong className="text-slate-950 text-base mt-1">{arrivalRate.toFixed(1)} / h</strong>
                            </div>
                            <div className="bg-white p-3 border border-indigo-100 flex flex-col justify-between">
                              <span className="text-[10px] uppercase text-indigo-500">⚙️ 2. Processo (Lead Time)</span>
                              <strong className="text-slate-950 text-base mt-1">{stats.leadTime.toFixed(1)} min</strong>
                            </div>
                            <div className="bg-white p-3 border border-indigo-100 flex flex-col justify-between">
                              <span className="text-[10px] uppercase text-indigo-500">💎 3. Resultado (Rendimento)</span>
                              <strong className="text-emerald-700 text-base mt-1">{(stats.rolledFirstPassYield * 100).toFixed(1)}% ok</strong>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* DASHBOARD INTEGRATED STATS */}
                    {activeTabelaElement === "DASHBOARD" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div className="bg-white p-4 border text-center space-y-1">
                            <span className="text-slate-500 text-[10px] uppercase block">Tempo Mínimo Útil (Touch Time)</span>
                            <strong className="text-indigo-950 text-lg block">{stats.processingTimeSum.toFixed(1)} min</strong>
                          </div>
                          <div className="bg-white p-4 border text-center space-y-1">
                            <span className="text-slate-500 text-[10px] uppercase block">Atraso Agregado em Fila</span>
                            <strong className="text-indigo-950 text-lg block">{(stats.leadTime - stats.processingTimeSum).toFixed(1)} min</strong>
                          </div>
                          <div className="bg-white p-4 border text-center space-y-1">
                            <span className="text-slate-500 text-[10px] uppercase block">Nível Sigma Estimado</span>
                            <strong className="text-emerald-700 text-lg block">{stats.sigmaLevel.toFixed(2)} σ</strong>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SLA ANALYZER */}
                    {activeTabelaElement === "SLA" && (
                      <div className="space-y-4 animate-fadeIn text-xs font-mono">
                        <div className="bg-white border p-5 space-y-3">
                          <h5 className="font-extrabold uppercase text-slate-900 border-b pb-1.5">Acordo de SLA do Cliente (Service Level Agreement)</h5>
                          <p className="font-sans text-slate-650 leading-relaxed">
                            Simpifique sua promessa ao cliente final. Se você prometeu entregar em menos de <strong>30 minutos</strong>:
                          </p>
                          <div className="p-3 border flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
                            <div>
                              <span>⏱️ Seu Lead Time Médio estimado: <strong>{stats.leadTime.toFixed(1)} min</strong></span>
                            </div>
                            <span className={`px-3 py-1 font-mono font-bold uppercase border ${
                              stats.leadTime <= 30
                                ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                                : "bg-red-50 text-red-800 border-red-300 animate-pulse"
                            }`}>
                              {stats.leadTime <= 30 ? "🟢 SLA Confortável (Cumprindo)" : "🚨 SLA Comprometido (Atrasos)"}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* OEE MATHEMATICAL FORM */}
                    {activeTabelaElement === "OEE" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs" id="sec-oee">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {/* Inputs */}
                          <div className="bg-white border p-4 space-y-3 md:col-span-2">
                            <span className="font-extrabold uppercase border-b pb-1 block">Ajuste os Índices de Desempenho</span>
                            <div className="space-y-3 font-mono">
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span>📅 Disponibilidade (% tempo útil de trabalho):</span>
                                  <strong className="text-indigo-950">{oeeAvailability}%</strong>
                                </div>
                                <input type="range" min="50" max="100" value={oeeAvailability} onChange={(e) => setOeeAvailability(parseInt(e.target.value))} className="w-full accent-indigo-950" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span>🚀 Performance (% velocidade vs. ideal):</span>
                                  <strong className="text-indigo-950">{oeePerformance}%</strong>
                                </div>
                                <input type="range" min="50" max="100" value={oeePerformance} onChange={(e) => setOeePerformance(parseInt(e.target.value))} className="w-full accent-indigo-950" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span>🛡️ Qualidade (% itens sem falhas na primeira tentativa):</span>
                                  <strong className="text-indigo-950">{oeeQuality}%</strong>
                                </div>
                                <input type="range" min="55" max="100" value={oeeQuality} onChange={(e) => setOeeQuality(parseInt(e.target.value))} className="w-full accent-indigo-950" />
                              </div>
                            </div>
                          </div>

                          {/* Result */}
                          <div className="bg-[#1A1A1A] text-[#F5F2ED] border-2 border-slate-900 p-5 flex flex-col justify-between items-center text-center">
                            <div className="space-y-1">
                              <span className="text-[9px] font-mono font-black uppercase text-[#D1A142] tracking-wider block">Índice Global OEE</span>
                              <strong className="text-3xl font-serif font-black text-white">
                                {((oeeAvailability / 100) * (oeePerformance / 100) * (oeeQuality / 100) * 100).toFixed(1)}%
                              </strong>
                            </div>
                            <p className="text-[10px] text-slate-300 font-sans leading-tight mt-2">
                              {((oeeAvailability / 100) * (oeePerformance / 100) * (oeeQuality / 100) * 100) >= 85
                                ? "🌟 Classe Mundial: Eficiência excepcional de ponta a ponta!"
                                : "⚠️ Oportunidade Alta: Reduza pequenas paradas para atingir os 85% recomendados."}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ISHIKAWA (FISHBONE DIAGRAM) */}
                    {activeTabelaElement === "ISHIKAWA" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs" id="sec-ishikawa">
                        <div className="bg-white border p-4 space-y-4 overflow-x-auto text-slate-800">
                          
                          {/* Fishbone drawing container */}
                          <div className="relative min-w-[700px] border border-dashed border-slate-200 p-4 bg-[#FAF9F6] flex justify-center py-10">
                            
                            {/* Main spine bone */}
                            <div className="absolute left-4 right-[160px] top-1/2 h-1.5 bg-slate-900 -translate-y-1/2"></div>
                            
                            {/* Effect head */}
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 bg-red-650 text-white p-3 border-2 border-red-950 font-black font-sans uppercase text-center max-w-[150px] leading-tight z-10">
                              🚨 EFEITO:<br />
                              <span className="text-[10px] font-mono text-white/90 lowercase italic">{ishikawaProblem}</span>
                            </div>

                            {/* Upper Bones */}
                            <div className="grid grid-cols-3 w-full max-w-[500px] pr-[160px] gap-4 mb-24 z-10 relative">
                              {/* 1. Method */}
                              <button
                                onClick={() => setActiveIshikawaCategory("method")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "method" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">01. MÉTODO 📋</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaMethod.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>

                              {/* 2. Machine */}
                              <button
                                onClick={() => setActiveIshikawaCategory("machine")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "machine" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">02. MÁQUINA 💻</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaMachine.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>

                              {/* 3. Measurement */}
                              <button
                                onClick={() => setActiveIshikawaCategory("measurement")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "measurement" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">03. MEDIDA 📏</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaMeasurement.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>
                            </div>

                            {/* Lower Bones */}
                            <div className="grid grid-cols-3 w-full max-w-[500px] pr-[160px] gap-4 mt-24 z-10 absolute bottom-4">
                              {/* 4. Environment */}
                              <button
                                onClick={() => setActiveIshikawaCategory("environment")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "environment" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">04. MEIO AMB. 🌿</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaEnvironment.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>

                              {/* 5. Manpower */}
                              <button
                                onClick={() => setActiveIshikawaCategory("manpower")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "manpower" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">05. MÃO DE OBRA 👥</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaManpower.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>

                              {/* 6. Material */}
                              <button
                                onClick={() => setActiveIshikawaCategory("material")}
                                className={`p-2.5 border-2 text-left space-y-1 block hover:bg-slate-100/55 cursor-pointer rounded-none min-h-[90px] ${
                                  activeIshikawaCategory === "material" ? "border-indigo-650 bg-indigo-50/20" : "border-slate-800 bg-white"
                                }`}
                              >
                                <span className="font-black text-rose-700 block text-[9.5px]">06. MATÉRIA-P. 📦</span>
                                <ul className="space-y-0.5 text-[10px] text-slate-600 pl-1 list-disc">
                                  {ishikawaMaterial.slice(0, 2).map((c, i) => <li key={i} className="truncate">{c}</li>)}
                                </ul>
                              </button>
                            </div>

                          </div>

                          {/* Control panel to populate causes */}
                          <div className="bg-slate-50 border p-4 space-y-3">
                            <div className="flex items-center justify-between border-b pb-1.5 mb-1.5">
                              <span className="font-extrabold text-slate-800 uppercase block">
                                🔧 Gerenciador de Causas Ativo:{" "}
                                <span className="text-rose-700 font-black">
                                  {activeIshikawaCategory === "method" && "01. Método"}
                                  {activeIshikawaCategory === "machine" && "02. Máquina"}
                                  {activeIshikawaCategory === "measurement" && "03. Medida"}
                                  {activeIshikawaCategory === "environment" && "04. Meio Ambiente"}
                                  {activeIshikawaCategory === "manpower" && "05. Mão de Obra"}
                                  {activeIshikawaCategory === "material" && "06. Matéria-prima"}
                                </span>
                              </span>
                            </div>

                            <div className="space-y-2">
                              {/* List causes */}
                              <div className="flex flex-wrap gap-1.5 select-none">
                                {(() => {
                                  const activeList = activeIshikawaCategory === "method" ? ishikawaMethod
                                    : activeIshikawaCategory === "machine" ? ishikawaMachine
                                    : activeIshikawaCategory === "measurement" ? ishikawaMeasurement
                                    : activeIshikawaCategory === "environment" ? ishikawaEnvironment
                                    : activeIshikawaCategory === "manpower" ? ishikawaManpower
                                    : ishikawaMaterial;
                                  
                                  if (activeList.length === 0) return <p className="text-xs text-slate-400 italic">Nenhuma causa documentada nesta espinha.</p>;
                                  return activeList.map((c, idx) => (
                                    <span key={idx} className="bg-white border rounded px-2.5 py-1 text-slate-800 flex items-center gap-1.5 text-xs">
                                      <span>🔹 {c}</span>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (activeIshikawaCategory === "method") setIshikawaMethod((prev) => prev.filter((item) => item !== c));
                                          if (activeIshikawaCategory === "machine") setIshikawaMachine((prev) => prev.filter((item) => item !== c));
                                          if (activeIshikawaCategory === "measurement") setIshikawaMeasurement((prev) => prev.filter((item) => item !== c));
                                          if (activeIshikawaCategory === "environment") setIshikawaEnvironment((prev) => prev.filter((item) => item !== c));
                                          if (activeIshikawaCategory === "manpower") setIshikawaManpower((prev) => prev.filter((item) => item !== c));
                                          if (activeIshikawaCategory === "material") setIshikawaMaterial((prev) => prev.filter((item) => item !== c));
                                        }}
                                        className="text-red-500 hover:text-red-700 font-bold"
                                        title="Remover Causa"
                                      >
                                        x
                                      </button>
                                    </span>
                                  ));
                                })()}
                              </div>

                              {/* Form Input */}
                              <div className="flex gap-2 max-w-xl select-none pt-2">
                                <input
                                  type="text"
                                  placeholder="Escreva uma nova hipótese de falha..."
                                  value={newIshikawaCause}
                                  onChange={(e) => setNewIshikawaCause(e.target.value)}
                                  className="flex-1 border bg-white border-slate-350 p-2 text-xs"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (!newIshikawaCause.trim()) return;
                                    const txt = newIshikawaCause.trim();
                                    if (activeIshikawaCategory === "method") setIshikawaMethod((prev) => [...prev, txt]);
                                    if (activeIshikawaCategory === "machine") setIshikawaMachine((prev) => [...prev, txt]);
                                    if (activeIshikawaCategory === "measurement") setIshikawaMeasurement((prev) => [...prev, txt]);
                                    if (activeIshikawaCategory === "environment") setIshikawaEnvironment((prev) => [...prev, txt]);
                                    if (activeIshikawaCategory === "manpower") setIshikawaManpower((prev) => [...prev, txt]);
                                    if (activeIshikawaCategory === "material") setIshikawaMaterial((prev) => [...prev, txt]);
                                    setNewIshikawaCause("");
                                  }}
                                  className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#D97706] text-white font-mono font-bold text-xs uppercase cursor-pointer"
                                >
                                  Fixar Causa
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* REALISTIC PARETO CHART DECORATIONS */}
                    {activeTabelaElement === "PARETO" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs" id="sec-pareto">
                        <div className="bg-white border p-5 space-y-4">
                          <h5 className="font-extrabold uppercase text-slate-900 border-b pb-1.5">Conceito de Pareto 80/20 Aplicado ao Seu Fluxo</h5>
                          <p className="font-sans text-slate-650 leading-relaxed">
                            A análise estatística clássica indica que cerca de <strong>80% dos atrasos acumulados</strong> se justificam por furos na triagem ou retrabalhos excessivos no posto gargalo. No seu desenho ativo:
                          </p>

                          {/* Graphical visual representation of sorted failures */}
                          <div className="space-y-3.5 pr-4 select-none">
                            {steps.map((st, i) => {
                              // Let's fake an accumulated impact based on yield failure index
                              const failureIndex = (1 - st.yieldRate) * 100;
                              const widthPercentage = Math.max(15, Math.min(100, failureIndex * 8));
                              return (
                                <div key={st.id} className="space-y-1">
                                  <div className="flex justify-between font-mono text-[11px] text-slate-705">
                                    <span>💥 Etapa: "{st.name}"</span>
                                    <span>Falha média: {failureIndex.toFixed(0)}% • Impacto Pareto: {widthPercentage.toFixed(0)} pts</span>
                                  </div>
                                  <div className="w-full bg-slate-100 h-4 overflow-hidden rounded flex">
                                    <div
                                      className={`h-full transition-all flex items-center justify-end px-2 text-[9px] text-white font-black uppercase ${
                                        st.name === stats.bottleneckStepName ? "bg-red-500" : "bg-indigo-950"
                                      }`}
                                      style={{ width: `${widthPercentage}%` }}
                                    >
                                      {st.name === stats.bottleneckStepName ? "Foco Central" : "Secundário"}
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* FMEA RISK REDUCTION MODULATOR */}
                    {activeTabelaElement === "FMEA" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs" id="sec-fmea">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                          
                          {/* FMEA Register form */}
                          <div className="lg:col-span-2 bg-white border p-4 space-y-4">
                            <span className="text-[10px] font-mono font-black uppercase text-rose-700 bg-rose-50 px-2 py-0.5 border border-rose-200">
                              Novo Registro de Falha FMEA
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 select-none">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-650 block">Posto Afetado:</label>
                                <select
                                  value={popSelectedStepId}
                                  onChange={(e) => setPopSelectedStepId(e.target.value)}
                                  className="w-full border p-1.5 text-xs bg-slate-50"
                                >
                                  {steps.map((st) => (
                                    <option key={st.id} value={st.id}>{st.name}</option>
                                  ))}
                                </select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-650 block">Modo de Falha Crítica:</label>
                                <input
                                  type="text"
                                  value={fmeaFailureMode}
                                  onChange={(e) => setFmeaFailureMode(e.target.value)}
                                  className="w-full border p-1.5 text-xs bg-white"
                                />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <label className="text-[10px] font-bold text-slate-650">🚨 Severidade (S: 1 a 10):</label>
                                  <strong className="text-red-700 font-extrabold">{fmeaSeverity}</strong>
                                </div>
                                <input type="range" min="1" max="10" value={fmeaSeverity} onChange={(e) => setFmeaSeverity(parseInt(e.target.value))} className="w-full accent-red-650" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <label className="text-[10px] font-bold text-slate-650">🔄 Ocorrência (O: 1 a 10):</label>
                                  <strong className="text-[#D97706] font-extrabold">{fmeaOccurrence}</strong>
                                </div>
                                <input type="range" min="1" max="10" value={fmeaOccurrence} onChange={(e) => setFmeaOccurrence(parseInt(e.target.value))} className="w-full accent-[#D97706]" />
                              </div>
                              <div className="space-y-1 sm:col-span-2">
                                <div className="flex justify-between">
                                  <label className="text-[10px] font-bold text-slate-650">🔍 Detecção (D: 1 a 10 - MENOR valor é MAIOR sensibilidade de aviso):</label>
                                  <strong className="text-blue-900 font-extrabold">{fmeaDetection}</strong>
                                </div>
                                <input type="range" min="1" max="10" value={fmeaDetection} onChange={(e) => setFmeaDetection(parseInt(e.target.value))} className="w-full accent-blue-900" />
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                if (!fmeaFailureMode.trim()) return;
                                const selectedStep = steps.find((s) => s.id === popSelectedStepId) || steps[0];
                                if (!selectedStep) return;
                                const rpn = fmeaSeverity * fmeaOccurrence * fmeaDetection;
                                const newRec = {
                                  id: `fmea_${Date.now()}`,
                                  stepName: selectedStep.name,
                                  failureMode: fmeaFailureMode,
                                  s: fmeaSeverity,
                                  o: fmeaOccurrence,
                                  d: fmeaDetection,
                                  rpn
                                };
                                setFmeaRecords((prev) => [...prev, newRec]);
                                setFmeaFailureMode("");
                                alert(`💾 Registro de Risco FMEA Salvo!\n\nRPN calculado: ${rpn} pontos.`);
                              }}
                              className="w-full py-2 bg-slate-900 hover:bg-rose-650 text-white font-mono font-bold text-xs uppercase cursor-pointer border border-slate-950"
                            >
                              💾 Registrar Análise e Risco FMEA
                            </button>
                          </div>

                          {/* Historical records */}
                          <div className="space-y-3">
                            <h5 className="font-mono font-black text-rose-900 text-[11px] uppercase tracking-wide">
                              📋 Riscos Prioritários (FMEA Ativo)
                            </h5>
                            {fmeaRecords.map((r) => (
                              <div key={r.id} className="bg-white border p-3 text-xs leading-relaxed space-y-1 shadow-[2px_2px_0px_rgba(0,0,0,0.03)] flex flex-col justify-between">
                                <div className="flex justify-between items-start border-b pb-1">
                                  <strong className="text-slate-950 block">🔺 {r.stepName}</strong>
                                  <button
                                    type="button"
                                    onClick={() => setFmeaRecords((prev) => prev.filter((rec) => rec.id !== r.id))}
                                    className="text-[10px] font-mono text-red-500 hover:text-red-700 cursor-pointer pl-1.5"
                                  >
                                    Remover
                                  </button>
                                </div>
                                <p className="text-[11px] text-slate-650 font-sans">Falha: "{r.failureMode}"</p>
                                <div className="flex justify-between items-center bg-slate-102 p-1 font-mono text-[10px] mt-1.5">
                                  <span>S:{r.s} O:{r.o} D:{r.d}</span>
                                  <strong className="text-red-700">RPN: {r.rpn} {r.rpn >= 150 ? "🚨 ALTO" : "🟡 MÉDIO"}</strong>
                                </div>
                              </div>
                            ))}
                          </div>

                        </div>
                      </div>
                    )}

                    {/* DMAIC WIZARD REDIRECTOR */}
                    {activeTabelaElement === "DMAIC" && (
                      <div className="space-y-4 animate-fadeIn font-mono text-xs">
                        <div className="bg-slate-900 text-white p-5 space-y-3">
                          <h5 className="font-extrabold uppercase text-amber-400">Roteiro Completo Six Sigma (DMAIC)</h5>
                          <p className="font-sans text-slate-350 leading-relaxed">
                            O Ciclo DMAIC na suíte Optima é 100% automatizado síncrono. Você pode acessar o guia avançado do DMAIC direto nas abas principais do console de engenharia, ou conferir seus postos aqui.
                          </p>
                          <div className="grid grid-cols-5 text-center font-mono text-[10px] border divide-x border-slate-700 divide-slate-700 select-none">
                            <div className="p-2 bg-slate-800 text-white font-extrabold">D<span className="hidden md:inline"> (Definir)</span></div>
                            <div className="p-2 bg-slate-800 text-white font-extrabold">M<span className="hidden md:inline"> (Medir)</span></div>
                            <div className="p-2 bg-slate-800 text-white font-extrabold">A<span className="hidden md:inline"> (Analisar)</span></div>
                            <div className="p-2 bg-slate-800 text-white font-extrabold">I<span className="hidden md:inline"> (Melhorar)</span></div>
                            <div className="p-2 bg-[#D97706] text-slate-950 font-black">C<span className="hidden md:inline"> (Controlar)</span></div>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                );
              })()}

            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* 🔮 TAB 1: DIAGNÓSTICO E SAÚDE ATUAL (GESTÃO) */}
      {/* ========================================================= */}
      {activeTab === "diag" && (
        <div className="space-y-8 animate-fadeIn" id="view-diag">
          {renderActiveProjectBadge()}
          {!activeWorkspaceProjectId && renderProjectStructuralSelector()}
          
          {/* RAIO-X ANTES X DEPOIS PREVIEW */}
          <div className="bg-white border-2 border-slate-950 p-6 rounded-none shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
              <div>
                <h3 className="text-base md:text-lg font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500 animate-pulse" />
                  Antes x Depois: Projeção de Otimização LSS Automatizado
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xl">
                  Simulação de como o seu processo opera no modelo básico versus o modelo otimizado usando Kaizen e boas práticas de balanceamento.
                </p>
              </div>
              <span className="text-[10px] bg-indigo-100 text-indigo-800 px-3 py-1 font-mono font-bold tracking-wider rounded-none self-start md:self-auto uppercase">
                ⚙️ Projeção Lean Ativada
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* BEFORE CARD */}
              <div className="border border-red-300 bg-red-50/10 p-5 rounded-none flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex justify-between items-center border-b border-red-200 pb-2">
                    <span className="text-xs font-serif font-black text-red-800 uppercase tracking-wide">
                      🛑 Operação sem Padronização
                    </span>
                    <span className="text-[9px] font-mono text-red-700 bg-red-100 px-2 py-0.5 font-bold rounded-none uppercase">
                      Desorganizado / Gargalos Soltos
                    </span>
                  </div>
                  <p className="text-xs text-red-900/80 leading-relaxed font-sans">
                    Sem balanceamento e regras simples de revisão. Onde acumulam pilhas de faturas, os colaboradores ficam cansados e as falhas humanas disparam devido à correria desordenada.
                  </p>
                </div>

                <div className="pt-4 border-t border-red-200 grid grid-cols-3 gap-2 text-left font-mono">
                  <div className="bg-white p-2 border border-red-100">
                    <span className="text-[8px] uppercase text-red-500 block font-bold">Atraso Espera</span>
                    <strong className="text-red-950 text-xs block mt-1">{antesStats.leadTime.toFixed(1)} min</strong>
                  </div>
                  <div className="bg-white p-2 border border-red-100">
                    <span className="text-[8px] uppercase text-red-500 block font-bold">Vazão Total</span>
                    <strong className="text-red-950 text-xs block mt-1">{antesStats.systemCapacity.toFixed(1)}/h</strong>
                  </div>
                  <div className="bg-white p-2 border border-red-100">
                    <span className="text-[8px] uppercase text-red-500 block font-bold">Evitar Erros</span>
                    <strong className="text-red-950 text-xs block mt-1">{(antesStats.rolledFirstPassYield * 100).toFixed(0)}%</strong>
                  </div>
                </div>
              </div>

              {/* AFTER CARD */}
              <div className="border border-indigo-300 bg-indigo-50/10 p-5 rounded-none flex flex-col justify-between shadow-[2px_2px_0px_rgba(79,70,229,0.15)]">
                <div className="space-y-3">
                  <div className="flex justify-between items-center border-b border-indigo-200 pb-2">
                    <span className="text-xs font-serif font-black text-indigo-800 uppercase tracking-wide flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                      ✨ Operação Otimizada (Depois)
                    </span>
                    <span className="text-[9px] font-mono text-indigo-700 bg-indigo-100 px-2 py-0.5 font-bold rounded-none uppercase">
                      Colaboradores em Ritmo Ideal
                    </span>
                  </div>
                  <p className="text-xs text-indigo-950/80 leading-relaxed font-sans">
                     redistribuição das tarefas, padronização nos postos e checagens automatizadas. A equipe trabalha com conforto, no ritmo ideal de forma constante.
                  </p>
                </div>

                <div className="pt-4 border-t border-indigo-200 grid grid-cols-3 gap-2 text-left font-mono">
                  <div className="bg-white p-2 border border-indigo-100">
                    <span className="text-[8px] uppercase text-indigo-600 block font-bold">Atraso Espera</span>
                    <strong className="text-indigo-950 text-xs block mt-1 text-emerald-600 font-extrabold">{depoisStats.leadTime.toFixed(1)} min</strong>
                  </div>
                  <div className="bg-white p-2 border border-indigo-100">
                    <span className="text-[8px] uppercase text-indigo-600 block font-bold">Vazão Total</span>
                    <strong className="text-indigo-950 text-xs block mt-1 font-bold">{(depoisStats.systemCapacity).toFixed(1)}/h</strong>
                  </div>
                  <div className="bg-white p-2 border border-indigo-100">
                    <span className="text-[8px] uppercase text-indigo-600 block font-bold">Evitar Erros</span>
                    <strong className="text-indigo-950 text-xs block mt-1 font-bold text-emerald-600">{(depoisStats.rolledFirstPassYield * 100).toFixed(0)}%</strong>
                  </div>
                </div>
              </div>

            </div>

            {/* PERFORMANCE BAR COMPARISONS */}
            <div className="bg-slate-900 text-white p-4 rounded-none grid grid-cols-1 sm:grid-cols-3 gap-4 text-center divide-y sm:divide-y-0 sm:divide-x divide-slate-800 font-mono">
              <div className="py-2 sm:py-0 flex flex-col justify-center">
                <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold">Ganho de Tempo</span>
                <div className="flex items-center justify-center gap-1 mt-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                  <strong className="text-lg font-serif text-emerald-400">
                    {antesStats.leadTime > depoisStats.leadTime 
                      ? `${(((antesStats.leadTime - depoisStats.leadTime) / antesStats.leadTime) * 100).toFixed(0)}%` 
                      : "0%"
                    }
                  </strong>
                </div>
                <span className="text-[9px] text-slate-400 mt-0.5">menos tempo de cliente na fila</span>
              </div>

              <div className="py-2 sm:py-0 flex flex-col justify-center">
                <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold">Ganho de Entregas</span>
                <div className="flex items-center justify-center gap-1 mt-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                  <strong className="text-lg font-serif text-emerald-400">
                    +{(depoisStats.systemCapacity - antesStats.systemCapacity).toFixed(1)} {unitLabelPlural}/h
                  </strong>
                </div>
                <span className="text-[9px] text-slate-400 mt-0.5">capacidade de vendas ampliada</span>
              </div>

              <div className="py-2 sm:py-0 flex flex-col justify-center">
                <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold">Acertos Perfeitos</span>
                <div className="flex items-center justify-center gap-1 mt-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                  <strong className="text-lg font-serif text-indigo-300">
                    +{((depoisStats.rolledFirstPassYield - antesStats.rolledFirstPassYield) * 100).toFixed(0)}%
                  </strong>
                </div>
                <span className="text-[9px] text-slate-400 mt-0.5">peças certas na primeira tentativa</span>
              </div>
            </div>
          </div>

          {/* 🚦 AS 3 GRANDES SINALIZAÇÕES DE SAÚDE (SEMÁFOROS DE SAÚDE) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* SEMÁFORO 1: CARGA DE TRABALHO */}
            <div className={`p-6 border rounded-none text-left flex flex-col justify-between space-y-4 shadow-3xs transition-all ${utilizationHealth.color}`}>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">Carga de Trabalho</span>
                  <span className="text-xs font-mono font-black text-slate-900">{utilizationHealth.badge}</span>
                </div>
                <h3 className="text-base font-serif font-extrabold text-slate-900 leading-tight">
                  {utilizationHealth.label}
                </h3>
                <p className="text-xs text-slate-650 leading-relaxed">
                  {utilizationHealth.sub}
                </p>
              </div>
              
              <div className="border-t border-[#1A1A1A]/10 pt-4 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Aproveitamento da Equipe:</span>
                  <span className="font-mono font-extrabold text-slate-900">{stats.systemUtilization.toFixed(0)}%</span>
                </div>
                <div className="w-full bg-slate-200/50 h-1.5 rounded-none overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${utilizationHealth.indicatorColor}`}
                    style={{ width: `${Math.min(100, stats.systemUtilization)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* SEMÁFORO 2: VELOCIDADE */}
            <div className={`p-6 border rounded-none text-left flex flex-col justify-between space-y-4 shadow-3xs transition-all ${delayHealth.color}`}>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">Tempo de Atendimento</span>
                  <span className="text-xs font-mono font-black text-slate-900">{delayHealth.badge}</span>
                </div>
                <h3 className="text-base font-serif font-extrabold text-slate-900 leading-tight">
                  {delayHealth.label}
                </h3>
                <p className="text-xs text-slate-650 leading-relaxed">
                  {delayHealth.sub}
                </p>
              </div>
              
              <div className="border-t border-[#1A1A1A]/10 pt-4 space-y-2">
                <div className="grid grid-cols-2 gap-1 text-[11px] border-b border-dashed pb-2 mb-2">
                  <div>
                    <span className="text-slate-550 block">Trabalho Real:</span>
                    <span className="font-bold text-slate-800 font-mono text-xs">{stats.processingTimeSum.toFixed(0)} min</span>
                  </div>
                  <div>
                    <span className="text-slate-550 block">Tempo total:</span>
                    <span className="font-bold text-slate-800 font-mono text-xs">{stats.leadTime.toFixed(0)} min</span>
                  </div>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-mono">Lentidão gerada pela Fila:</span>
                  <span className="font-mono font-black text-slate-900">{ratio.toFixed(1)}x mais demorado</span>
                </div>
              </div>
            </div>

            {/* SEMÁFORO 3: QUALIDADE */}
            <div className={`p-6 border rounded-none text-left flex flex-col justify-between space-y-4 shadow-3xs transition-all ${qualityHealth.color}`}>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">Taxa de Acertos</span>
                  <span className="text-xs font-mono font-black text-slate-900">{qualityHealth.badge}</span>
                </div>
                <h3 className="text-base font-serif font-extrabold text-slate-900 leading-tight">
                  {qualityHealth.label}
                </h3>
                <p className="text-xs text-slate-650 leading-relaxed">
                  {qualityHealth.sub}
                </p>
              </div>
              
              <div className="border-t border-[#1A1A1A]/10 pt-4 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Pedidos Prontos de Primeira:</span>
                  <span className="font-mono font-extrabold text-slate-900">{(stats.rolledFirstPassYield * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full bg-slate-200/50 h-1.5 rounded-none overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${qualityHealth.indicatorColor}`}
                    style={{ width: `${stats.rolledFirstPassYield * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

          </div>

          {/* 🎚️ INTERACTIVE DEMAND DIAL */}
          {setArrivalRate && (
            <div className="p-6 bg-slate-50 rounded-none border border-slate-300 text-left space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-dashed border-slate-300 pb-3">
                <div>
                  <h3 className="text-sm font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-amber-600" />
                    Simular Volume de Clientes por Hora (Teste operacional)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Mova a barra abaixo para fingir que a empresa está recebendo mais pedidos e assista as reações dos semáforos de saúde!
                  </p>
                </div>
                <div className="bg-white px-3 py-1.5 border border-slate-200 rounded-none font-mono text-[11px] self-start md:self-auto font-bold uppercase">
                  Pedidos Recebidos: <span className="font-extrabold text-[#C49746] text-sm">{arrivalRate}</span> {unitLabelPlural}/h
                </div>
              </div>

              <div className="space-y-3 py-2">
                <input
                  type="range"
                  min="1"
                  max={Math.max(50, Math.ceil(stats.systemCapacity * 1.5))}
                  value={arrivalRate}
                  onChange={(e) => setArrivalRate(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-800 focus:outline-none"
                />
                <div className="flex justify-between text-[9.5px] font-mono text-slate-400">
                  <span>🍃 Operação Calma</span>
                  <span className="text-center font-bold text-amber-600">⚡ CAPACIDADE MÁXIMA DO SEU GARGALO: {stats.systemCapacity.toFixed(1)} {unitLabelPlural}/h</span>
                  <span>🔥 Volume Elevado</span>
                </div>
              </div>

              {arrivalRate > stats.systemCapacity ? (
                <div className="p-3 bg-rose-50 border border-rose-250 text-rose-800 text-xs rounded-none font-semibold animate-pulse">
                  ⚠️ <strong>Colapso Próximo!</strong> O negócio recebe {arrivalRate} pedidos/h, mas o seu gargalo <strong>({stats.bottleneckStepName})</strong> só suporta entregar {stats.systemCapacity.toFixed(1)} pedidos. Longas filas vão encher os computadores e irritar clientes!
                </div>
              ) : (
                <div className="p-3 bg-emerald-50 border border-emerald-250 text-emerald-800 text-xs rounded-none">
                  ✅ <strong>Ritmo Saudável!</strong> A equipe configurada de colaboradores consegue suprir o volume de entrada sem formar caixas acumuladas.
                </div>
              )}
            </div>
          )}

          {/* TABLE POSTS HEALTH */}
          <div className="space-y-4">
            <h3 className="text-sm font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-1.5">
              <ClipboardList className="w-4.5 h-4.5 text-slate-700" />
              Quadro de Postos: Capacidades e Alertas Individuais
            </h3>

            <div className="border border-slate-200 rounded-none overflow-hidden divide-y divide-slate-100 bg-white">
              <div className="hidden md:grid grid-cols-12 gap-4 bg-slate-50 p-3.5 font-mono text-[9.5px] uppercase font-bold text-slate-550 border-b">
                <div className="col-span-4">Setor / Etapa do Trabalho</div>
                <div className="col-span-2 text-center">Fazem o trabalho</div>
                <div className="col-span-2 text-center">Tempo por item</div>
                <div className="col-span-3">Status da Fila Local</div>
                <div className="col-span-1 text-center">Saúde</div>
              </div>

              {steps.map((step) => {
                const stepCap = (60 / step.processingTime) * step.resourceCount;
                const utilpct = (arrivalRate / stepCap) * 100;
                const isBottleneck = step.name === stats.bottleneckStepName;

                let badge = "🟢 Fluido";
                let badgeStyle = "bg-emerald-50 text-emerald-800 border-emerald-250";
                let dot = "bg-emerald-500";
                
                if (utilpct >= 90) {
                  badge = "🔴 Crítico";
                  badgeStyle = "bg-rose-50 text-rose-800 border-rose-200 font-bold";
                  dot = "bg-rose-500";
                } else if (utilpct >= 70) {
                  badge = "🟡 Atenção";
                  badgeStyle = "bg-amber-50 text-amber-800 border-amber-200";
                  dot = "bg-amber-500";
                }

                return (
                  <div 
                    key={step.id}
                    className={`grid grid-cols-1 md:grid-cols-12 gap-4 p-4 items-center ${
                      isBottleneck ? "bg-amber-50/20 border-l-4 border-l-amber-500" : ""
                    }`}
                  >
                    <div className="col-span-1 md:col-span-4 text-left">
                      <div className="flex items-center gap-2">
                        <strong className="text-slate-800 font-serif text-sm">{step.name}</strong>
                        {isBottleneck && (
                          <span className="text-[8px] bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded-none font-mono uppercase font-black">
                            ⚠️ Gargalo Lento
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                        {step.description || "Nenhum desperdício registrado neste setor."}
                      </span>
                    </div>

                    <div className="col-span-1 md:col-span-2 text-left md:text-center">
                      <span className="md:hidden text-[9px] uppercase font-mono font-bold text-slate-400 block pb-0.5">Responsáveis:</span>
                      <span className="inline-flex items-center gap-1 bg-slate-50 border border-slate-200 px-2 py-0.5 text-xs font-mono">
                        <Users className="w-3 h-3 text-slate-550" />
                        <strong>{step.resourceCount}</strong> pessoas ({step.resource})
                      </span>
                    </div>

                    <div className="col-span-1 md:col-span-2 text-left md:text-center">
                      <span className="md:hidden text-[9px] uppercase font-mono font-bold text-slate-400 block pb-0.5">Tempo Gasto:</span>
                      <span className="text-xs font-mono text-slate-750">
                        <strong>{step.processingTime.toFixed(1)}</strong> minutos
                      </span>
                    </div>

                    <div className="col-span-1 md:col-span-3 text-left">
                      <span className="md:hidden text-[9px] uppercase font-mono font-bold text-slate-400 block pb-0.5">Analítico:</span>
                      <span className="text-xs font-semibold block">
                        {utilpct >= 90 ? "⚠️ Caixa Acumuladora Sobrecarregada" : utilpct >= 70 ? "⏳ Operando perto do cansaço" : "✨ Fluxo limpo e desimpedido"}
                      </span>
                      <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                        {utilpct >= 90 
                          ? "Fila infinita se forma aqui. Adicione pessoas ou automatize para desafogar o posto."
                          : utilpct >= 70
                          ? "Trabalho cansativo. Se um funcionário faltar ou parar, haverá acúmulos rápidos."
                          : "Tempo de espera nulo. Equipe descansada operando com folga confortável."
                        }
                      </span>
                    </div>

                    <div className="col-span-1 text-left md:text-center">
                      <span className="md:hidden text-[9px] uppercase font-mono font-bold text-slate-400 block pb-0.5 font-bold">Saúde:</span>
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 font-mono font-bold text-[10px] rounded-full border ${badgeStyle}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${dot}`}></span>
                        {badge}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* DIAGNOSTIC 360 INTEGRATOR CARD */}
          <MapeadorDiagnostico360 charter={charter} setCharter={setCharter} />

        </div>
      )}

      {/* ========================================================= */}
      {/* 🗺️ TAB 2: MAPEADOR DE FLUXO SIMPLIFICADO */}
      {/* ========================================================= */}
      {activeTab === "map" && (
        <div className="space-y-6 animate-fadeIn" id="view-map">
          
          <div className="border border-slate-950 p-5 bg-white rounded-none shadow-[2px_2px_0px_rgba(0,0,0,1)] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5">
                <Map className="w-4 h-4 text-amber-500" />
                Mapeamento Sem Complicação: Monte seu Fluxo de Trabalho
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-lg leading-relaxed">
                Adicione as etapas de ponta a ponta. Ordene suas atividades principais, atribua quantas pessoas atuam nelas, defina a média de tempo gasta por tarefa e o índice aproximado de falhas. Nós cuidamos de recalcular toda a produtividade automágicamente!
              </p>
            </div>
            {!isAddingStep && (
              <button
                onClick={() => setIsAddingStep(true)}
                className="px-4 py-2 bg-slate-900 text-white font-bold hover:bg-slate-850 rounded-none text-xs transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto uppercase tracking-wide shadow-[2px_2px_0px_rgb(217,119,6)]"
              >
                <Plus className="w-4 h-4 text-amber-400" />
                Novo Posto / Etapa 🌱
              </button>
            )}
          </div>

          {/* ADD NEW STEP COLLAPSIBLE FORM */}
          {isAddingStep && (
            <div className="p-5 border-2 border-slate-900 bg-slate-50 rounded-none animate-fadeIn space-y-4 text-left">
              <h4 className="text-xs font-mono font-black text-slate-900 uppercase tracking-widest border-b pb-2">
                🌱 Cadastrar Nova Atividade Operacional
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Nome Simples da Etapa:</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Revisar Relatório Financeiro, Embalar Caixa"
                    value={newStepName}
                    onChange={(e) => setNewStepName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-slate-350 focus:outline-none focus:border-indigo-500"
                  />
                  <span className="text-[10px] text-slate-400">Dica: Use um verbo de ação literal para indicar o trabalho.</span>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Quem faz / Setor Responsável:</label>
                  <input
                    type="text"
                    placeholder="Ex: Recepcionista, Operador, Caixa"
                    value={newStepResource}
                    onChange={(e) => setNewStepResource(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-slate-350 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Tempo médio que gasta por item (minutos):</label>
                  <input
                    type="number"
                    min="1"
                    max="1000"
                    placeholder="Ex: 10"
                    value={newStepProcessingTime}
                    onChange={(e) => setNewStepProcessingTime(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-slate-350 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Número de colaboradores neste posto:</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={newStepResourceCount}
                    onChange={(e) => setNewStepResourceCount(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-slate-350 focus:outline-none focus:border-indigo-500"
                  />
                  <span className="text-[10px] text-slate-400">Quantas pessoas fazem isso de forma paralela simultaneamente.</span>
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-650 block">Como está o índice de erros/retrabalhos nesta fase?</label>
                  <select
                    value={newStepFailureRate}
                    onChange={(e) => setNewStepFailureRate(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-slate-355 focus:outline-none focus:border-indigo-500"
                  >
                    <option value={0.0}>🌟 Excelente: Sempre acertam (0% de retrabalho / Erro Zero)</option>
                    <option value={0.03}>😀 Muito Bom: Quase nunca erram (máximo de 3% de desvios)</option>
                    <option value={0.05}>👌 Bom: Raramente necessita conserto (5% de retrabalho)</option>
                    <option value={0.10}>⏳ Regular: Erros acontecem às vezes (10% de retrabalho)</option>
                    <option value={0.20}>⚠ Atenção: Retrabalhos frequentes (20% de refações necessárias)</option>
                    <option value={0.40}>🔥 Crítico: Muitas coisas faturam errado e pedem recomeço (40% de falhas)</option>
                  </select>
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-650 block">O que é feito aqui (Opcional):</label>
                  <textarea
                    placeholder="Descrição simples de rotina ou material usado"
                    rows={2}
                    value={newStepDescription}
                    onChange={(e) => setNewStepDescription(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-slate-350 focus:outline-none focus:border-indigo-500"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  onClick={() => setIsAddingStep(false)}
                  className="px-4 py-2 border font-bold text-xs rounded-none hover:bg-slate-100 transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleAddNewStep}
                  className="px-4 py-2 bg-emerald-600 font-extrabold text-[#fff] hover:bg-emerald-700 rounded-none text-xs transition-all flex items-center gap-1 cursor-pointer uppercase shadow-[2px_2px_0px_rgba(0,0,0,0.15)]"
                >
                  <Check className="w-4 h-4" />
                  Inserir no Processo 🌱
                </button>
              </div>
            </div>
          )}

          {/* EDIT STEP DRAWER PANEL */}
          {editingStepId && (
            <div className="p-5 border-2 border-amber-500 bg-amber-50/20 rounded-none animate-fadeIn space-y-4 text-left">
              <h4 className="text-xs font-mono font-black text-[#A17105] uppercase tracking-widest border-b border-amber-300 pb-2">
                ✍️ Editar Etapa Mapeada
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Nome da Etapa:</label>
                  <input
                    type="text"
                    value={editStepName}
                    onChange={(e) => setEditStepName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-amber-300 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Responsável / Cargo:</label>
                  <input
                    type="text"
                    value={editStepResource}
                    onChange={(e) => setEditStepResource(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-amber-300 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Tempo médio de realização (minutos):</label>
                  <input
                    type="number"
                    min="1"
                    value={editStepProcessingTime}
                    onChange={(e) => setEditStepProcessingTime(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-amber-300 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-650 block">Mão de obra contratada neste posto:</label>
                  <input
                    type="number"
                    min="1"
                    value={editStepResourceCount}
                    onChange={(e) => setEditStepResourceCount(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-amber-300 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-650 block">Taxa de falhas observada:</label>
                  <select
                    value={editStepFailureRate}
                    onChange={(e) => setEditStepFailureRate(Number(e.target.value))}
                    className="w-full text-xs p-2.5 bg-white border border-amber-305 focus:outline-none focus:border-amber-500"
                  >
                    <option value={0.0}>🌟 Excelente: Sempre acertam (0% de retrabalho / Erro Zero)</option>
                    <option value={0.03}>😀 Muito Bom: Quase nunca erram (máximo de 3% de desvios)</option>
                    <option value={0.05}>👌 Bom: Raramente necessita conserto (5% de retrabalho)</option>
                    <option value={0.10}>⏳ Regular: Erros acontecem às vezes (10% de retrabalho)</option>
                    <option value={0.20}>⚠️ Atenção: Retrabalhos frequentes (20% de refações necessárias)</option>
                    <option value={0.40}>🔥 Crítico: Muitas coisas faturam errado e pedem recomeço (40% de falhas)</option>
                  </select>
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-650 block">Sobre o posto:</label>
                  <textarea
                    rows={2}
                    value={editStepDescription}
                    onChange={(e) => setEditStepDescription(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white border border-amber-300 focus:outline-none focus:border-amber-500"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-200">
                <button
                  onClick={() => setEditingStepId(null)}
                  className="px-4 py-2 border font-bold text-xs rounded-none hover:bg-slate-100 transition-all cursor-pointer text-slate-900 bg-white"
                >
                  Cancelar Edição
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="px-4 py-2 bg-amber-500 font-extrabold text-slate-950 hover:bg-amber-600 rounded-none text-xs transition-all flex items-center gap-1 cursor-pointer uppercase"
                >
                  <Check className="w-4 h-4" />
                  Salvar Alterações
                </button>
              </div>
            </div>
          )}

          {/* LIST OF CURRENT MAP FLOW STEPS WITH Renders */}
          <div className="space-y-4">
            <h4 className="text-xs font-mono font-black text-slate-900 uppercase tracking-widest">
              🗺️ Fluxo Desenhado ({steps.length} Etapas em ordem de execução)
            </h4>

            <div className="space-y-3">
              {steps.map((s, idx) => {
                const stepFailPct = Math.round((1 - s.yieldRate) * 100);
                return (
                  <div 
                    key={s.id}
                    className="bg-white border-2 border-slate-900 p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-slate-800 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.05)]"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-900 text-amber-400 font-mono text-xs font-black flex items-center justify-center shrink-0 mt-0.5 select-none">
                        {idx + 1}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-sm font-serif font-extrabold text-slate-900 leading-none">{s.name}</h4>
                          <span className="text-[9px] bg-slate-100 border border-slate-200 px-2 py-0.5 font-mono uppercase font-bold text-slate-600">
                            👤 {s.resource}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          {s.description || "O fluxo de trabalho desta fase não tem desvios cadastrados."}
                        </p>

                        <div className="flex items-center gap-4 text-[11px] text-slate-650 font-mono pt-1">
                          <span>⏱️ Duração: <strong>{s.processingTime} min</strong></span>
                          <span>👥 Equipe unida: <strong>{s.resourceCount} colaboradores</strong></span>
                          <span>❌ Erros comuns: <strong className={stepFailPct > 10 ? "text-rose-600" : "text-emerald-600"}>{stepFailPct}% dos casos</strong></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end md:self-auto shrink-0 pt-2 md:pt-0">
                      <button
                        onClick={() => handleStartEdit(s)}
                        className="p-2 border border-slate-350 hover:border-amber-500 rounded-none text-slate-700 hover:text-amber-600 transition-all cursor-pointer bg-white"
                        title="Editar Etapa"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      
                      <button
                        onClick={() => handleDeleteStep(s.id)}
                        className="p-2 border border-slate-350 hover:border-rose-450 rounded-none text-slate-500 hover:text-rose-600 transition-all cursor-pointer bg-white"
                        title="Remover Etapa"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* ⚡ TAB 3: IDEIAS DE ALÍVIO (MELHORIA) */}
      {/* ========================================================= */}
      {activeTab === "improve" && (
        <div className="space-y-8 animate-fadeIn" id="view-improve">
          
          {/* QUICK SIMULATED SOLUTIONS (KAIZEN 1-CLICK) */}
          <div className="border border-slate-900 bg-white p-5 rounded-none shadow-[2px_2px_0px_rgba(0,0,0,1)] space-y-4">
            <div>
              <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4.5 h-4.5 text-[#C49746]" />
                Soluções Inteligentes Kaizen de 1-Clique: Desafie os Semáforos Vermelhos!
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                Nossa engenharia LSS integrou abaixo botões de melhoria direta aplicados ao seu processo. Clique em qualquer um para aplicar a mudança simulada e verifique imediatamente os impactos no Diagnóstico Simples!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              
              <div className="bg-slate-50 border border-slate-200 p-4 flex flex-col justify-between space-y-3 rounded-none">
                <div>
                  <span className="text-[8.5px] uppercase font-mono tracking-widest text-[#B45309] font-bold block pb-1">Kaizen 👥 Remanejo</span>
                  <h4 className="text-xs font-bold text-slate-800">Mais Pessoas no Gargalo</h4>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                    Ajuda a dobrar a velocidade do setor mais lento do seu fluxo de trabalho (<strong>{stats.bottleneckStepName}</strong>) ao colocar um funcionário extra treinado.
                  </p>
                </div>
                <button
                  onClick={() => applyImprovementAction("bottleneck_staff")}
                  className="w-full text-center py-2 bg-slate-900 text-white font-extrabold rounded-none text-[11px] uppercase transition-all hover:bg-amber-500 hover:text-slate-950 cursor-pointer"
                >
                  👥 Reforçar {stats.bottleneckStepName}
                </button>
              </div>

              <div className="bg-slate-50 border border-slate-200 p-4 flex flex-col justify-between space-y-3 rounded-none">
                <div>
                  <span className="text-[8.5px] uppercase font-mono tracking-widest text-indigo-600 font-bold block pb-1">Kaizen 🤖 Automação</span>
                  <h4 className="text-xs font-bold text-slate-800">Parceria de Software</h4>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                    Insere uma automação básica no gargalo reduzindo em 50% o tempo para concluir cada tarefa ali dentro, acelerando a entrega ao consumidor.
                  </p>
                </div>
                <button
                  onClick={() => applyImprovementAction("bottleneck_speed")}
                  className="w-full text-center py-2 bg-slate-900 text-white font-extrabold rounded-none text-[11px] uppercase transition-all hover:bg-amber-500 hover:text-slate-950 cursor-pointer"
                >
                  🤖 Automatizar Gargalo
                </button>
              </div>

              <div className="bg-slate-50 border border-slate-200 p-4 flex flex-col justify-between space-y-3 rounded-none">
                <div>
                  <span className="text-[8.5px] uppercase font-mono tracking-widest text-emerald-600 font-bold block pb-1">Kaizen 🎓 Blindagem</span>
                  <h4 className="text-xs font-bold text-slate-800">PokaYoke: Erros Zero</h4>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                    Identifica a etapa de trabalho campeã de faturamento com falhas humanas e implanta checklists visuais inteligentes, eliminando o retrabalho.
                  </p>
                </div>
                <button
                  onClick={() => applyImprovementAction("quality_zero")}
                  className="w-full text-center py-2 bg-slate-900 text-white font-extrabold rounded-none text-[11px] uppercase transition-all hover:bg-amber-500 hover:text-slate-950 cursor-pointer"
                >
                  🎓 Eliminar Erros Comuns
                </button>
              </div>

            </div>
          </div>

          {/* 🤖 GEMINI AI PROCESS OPTIMIZER */}
          <div className="border border-slate-900 bg-linear-to-br from-indigo-50/50 to-amber-50/30 p-6 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,1)] space-y-5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-indigo-100 pb-4">
              <div>
                <span className="text-[9px] uppercase font-mono tracking-wider font-extrabold px-1.5 py-0.5 bg-amber-100 border border-amber-200 text-amber-800 rounded-sm">
                  INTELIGÊNCIA ARTIFICIAL GEMINI
                </span>
                <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-2 mt-1.5">
                  🔮 Consultoria Lean Express com Inteligência Artificial
                </h3>
                <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                  Consulte nossa IA avançada para receber diagnósticos, sugestões personalizadas de melhoria livre de jargões técnicos difíceis, e uma analogia ilustrativa para entender seu gargalo.
                </p>
              </div>
              <button
                disabled={isAiLoading}
                onClick={handleRequestAiImprovement}
                className={`py-2 px-5 font-mono text-xs font-black uppercase rounded-none transition-all flex items-center gap-2 border select-none cursor-pointer tracking-wider shrink-0 ${
                  isAiLoading
                    ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                    : "bg-indigo-950 text-white border-indigo-950 hover:bg-amber-500 hover:text-indigo-950 hover:border-amber-500 shadow-[2px_2px_0px_rgba(15,23,42,1)] active:translate-x-0.5 active:translate-y-0.5 animate-pulse"
                }`}
              >
                {isAiLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                    Gerando Melhorias...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Analisar Processo com IA
                  </>
                )}
              </button>
            </div>

            {aiError && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-none font-medium">
                ⚠️ {aiError}
              </div>
            )}

            {!aiDiagnostic && !isAiLoading && (
              <div className="py-6 text-center text-slate-400 text-xs font-mono max-w-md mx-auto">
                Clique no botão acima para acionar o motor de IA e gerar conselhos estratégicos exclusivos para seu negócio 💡
              </div>
            )}

            {isAiLoading && (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-500 text-xs font-mono">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-950" />
                <span>O Gemini está analisando suas {steps.length} etapas e desenhando soluções simples...</span>
              </div>
            )}

            {aiDiagnostic && !isAiLoading && (
              <div className="space-y-6 animate-fadeIn">
                {/* Diagnóstico Simples */}
                <div className="bg-white border border-slate-350 p-5 rounded-none space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-950 uppercase tracking-wider">
                    <CheckCircle2 className="w-4.5 h-4.5 text-indigo-700 font-black" />
                    Diagnóstico Descomplicado do Fluxo
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {aiDiagnostic}
                  </p>
                </div>

                {/* Analogia Divertida */}
                {aiAnalogy && (
                  <div className="bg-amber-50 border border-amber-200 p-5 rounded-none space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800 uppercase tracking-wider">
                      <span className="text-sm">🍔</span>
                      Entendendo o Gargalo de Forma Prática:
                    </div>
                    <p className="text-xs text-amber-900 leading-relaxed font-serif italic">
                      {aiAnalogy}
                    </p>
                  </div>
                )}

                {/* Recomendações Práticas */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono font-black uppercase text-indigo-900 tracking-wider flex items-center gap-1">
                    <Zap className="w-4 h-4 text-amber-500" />
                    Melhorias Simples Recomendadas (Selecione para aplicar):
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {aiRecommendations.map((rec, idx) => (
                      <div 
                        key={idx}
                        className="bg-white border border-slate-200 p-4 shrink-0 flex flex-col justify-between space-y-4 rounded-none shadow-xs hover:border-indigo-400 transition-all"
                      >
                        <div className="space-y-2">
                          <span className="text-[9px] uppercase font-mono tracking-wider font-extrabold px-1.5 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700">
                            Ideia #{idx + 1}
                          </span>
                          <h5 className="text-xs font-black text-slate-900 leading-snug">{rec.title}</h5>
                          <p className="text-[11px] text-slate-600 leading-relaxed">{rec.description}</p>
                          <div className="text-[10px] text-emerald-750 bg-emerald-50 border border-emerald-100 p-1.5 rounded-none">
                            <strong>Por que fazer doará:</strong> {rec.expectedBenefit}
                          </div>
                        </div>
                        <button
                          onClick={() => handleAddAiRecommendationToTasks(rec.title, rec.description)}
                          className="w-full text-center py-2 bg-indigo-50 border border-indigo-200 text-indigo-950 font-extrabold rounded-none text-[10px] uppercase transition-all hover:bg-indigo-950 hover:text-white cursor-pointer"
                        >
                          ➕ Salvar no Plano Kaizen
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* PLANO DE AÇÕES / KAIZEN TASKS CHECKS */}
          <div className="border border-slate-300 bg-slate-50/50 p-6 rounded-none space-y-4">
            <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5 border-b pb-2">
              <CheckSquare className="w-4.5 h-4.5 text-slate-700" />
              Minhas Atividades de Melhoria (Kaizen Operacional)
            </h3>
            <p className="text-xs text-slate-550 max-w-2xl mt-1 leading-relaxed">
              Use este micro-quadro simples para registrar e verificar ações reais que você pode fazer hoje na sua empresa para acelerar as vendas e evitar falhas de execução.
            </p>

            <div className="flex gap-2 max-w-2xl py-1">
              <input
                type="text"
                placeholder="Ex: Criar roteiro impresso de qualidade, Marcar prateleiras"
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
                onKeyPress={handleSubAddTaskKeyPress}
                className="flex-1 text-xs p-2 bg-white border border-slate-300 focus:outline-none focus:border-slate-800 rounded-none"
              />
              <button
                onClick={handleAddImprovementTask}
                className="px-4 py-2 bg-slate-950 text-white font-bold text-xs hover:bg-slate-800 rounded-none transition-all cursor-pointer uppercase font-mono"
              >
                Adicionar
              </button>
            </div>

            <div className="max-w-2xl divide-y divide-slate-200 border border-slate-200 bg-white shadow-2xs">
              {improvementTasks.map(t => (
                <div 
                  key={t.id}
                  className="p-3 bg-white flex items-center justify-between hover:bg-slate-50 transition-all"
                >
                  <div 
                    onClick={() => handleToggleTask(t.id, t.done)}
                    className="flex items-center gap-3 cursor-pointer flex-1"
                  >
                    {t.done ? (
                      <CheckSquare className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
                    ) : (
                      <Square className="w-4.5 h-4.5 text-slate-400 shrink-0" />
                    )}
                    <span className={`text-xs ${t.done ? "line-through text-slate-400 font-medium" : "text-slate-800 font-semibold"}`}>
                      {t.text}
                    </span>
                  </div>
                  <button 
                    onClick={() => handleDeleteTask(t.id)}
                    className="text-slate-400 hover:text-rose-600 p-1.5 rounded transition-all cursor-pointer"
                    title="Remover Tarefa"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}

              {improvementTasks.length === 0 && (
                <div className="p-4 text-center text-xs text-slate-400 font-mono">
                  Lista limpa. Registre uma nova atividade acima 🌱
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* 🧭 TAB: MAPEAMENTO INICIAL DE PROCESSOS */}
      {/* ========================================================= */}
      {activeTab === "mapeamento" && (
        <div className="space-y-8 animate-fadeIn" id="view-mapeamento">
          {renderActiveProjectBadge()}
          {!activeWorkspaceProjectId && renderProjectStructuralSelector()}
          <MapeadorInicialProcessos />
        </div>
      )}

      {/* ========================================================= */}
      {/* 📞 TAB 4: SOLICITAÇÃO DE APOIO DE ESPECIALISTA */}
      {/* ========================================================= */}
      {activeTab === "specialist" && (
        <div className="space-y-8 animate-fadeIn" id="view-specialist">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* INSTRUCTIONS GUIDE PANEL */}
            <div className="lg:col-span-4 bg-slate-900 text-white p-6 rounded-none space-y-4 border-2 border-slate-900 shadow-[2px_2px_0px_rgba(245,158,11,1)]">
              <span className="text-[9px] font-mono tracking-widest font-extrabold text-[#C49746] block uppercase">ASSISTÊNCIA LEAN</span>
              <h3 className="text-base font-serif font-black tracking-tight leading-snug">
                Ficou travado com as contas operacionais?
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Se você encontrou dificuldades em mensurar os fluxos ou sente que seu processo precisa de um diagnóstico avançado, não se preocupe!
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                Nossos consultores parceiras, certificados em certificações <strong>Black Belts e Master Black Belts (Lean Six Sigma)</strong>, estão disponíveis para traduzir o seu problema real, criar mapas complexos e conduzir mentorias dedicadas.
              </p>

              <div className="border-t border-slate-850 pt-4 text-[11px] text-slate-400 font-mono space-y-2">
                <p className="flex items-center gap-1.5">
                  <span className="text-amber-500 font-extrabold">✓</span> Resposta prioritária via e-mail.
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="text-amber-500 font-extrabold">✓</span> Análise do seu processo mapeado.
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="text-amber-500 font-extrabold">✓</span> Protocolo seguro de rastreamento.
                </p>
              </div>
            </div>

            {/* FORM SOLICITATION */}
            <div className="lg:col-span-8 space-y-6">
              
              <div className="border-2 border-slate-950 p-6 bg-white rounded-none shadow-[2px_2px_0px_rgba(0,0,0,1)] text-left">
                <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider border-b pb-3 flex items-center gap-2">
                  <Send className="w-4 h-4 text-[#C49746]" />
                  Enviar Solicitação de Apoio Operacional
                </h3>

                <form onSubmit={handleSubmitSpecialist} className="space-y-4 pt-4">
                  {submitSuccess && (
                    <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-none leading-relaxed animate-fadeIn">
                      🎉 <strong>Solicitação enviada com sucesso!</strong> Seu ticket número <strong className="font-mono text-sm underline">{submitSuccess}</strong> já foi gravado em nosso sistema com total redundância. Um especialista LSS analisará o caso em poucas horas e entrará em contato!
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700 block">Qual processo ou assunto deseja melhorar?</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Demora no setor de expedição comercial"
                        value={specialistSubject}
                        onChange={(e) => setSpecialistSubject(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-none focus:outline-none focus:border-slate-900 bg-white"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700 block">Nível de Urgência Operacional:</label>
                      <select
                        value={specialistUrgency}
                        onChange={(e: any) => setSpecialistUrgency(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-none focus:outline-none focus:border-slate-900 bg-white"
                      >
                        <option value="Baixa">🟢 Baixa: Apenas para aprender melhor (Rotina)</option>
                        <option value="Média">🟡 Média: Gargalo atrapalhando as metas (Melhoramento)</option>
                        <option value="Alta">🔴 Alta: Filas imensas e clientes irritados (Alívio Imediato)</option>
                      </select>
                    </div>

                    <div className="space-y-1 md:col-span-2">
                      <label className="text-[11px] font-bold text-slate-700 block">WhatsApp ou E-mail para retorno ágil:</label>
                      <input
                        type="text"
                        placeholder="Ex: (11) 99999-9999 ou seunome@empresa.com"
                        value={specialistContact}
                        onChange={(e) => setSpecialistContact(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-none focus:outline-none focus:border-slate-900 bg-white"
                      />
                    </div>

                    <div className="space-y-1 md:col-span-2">
                      <label className="text-[11px] font-bold text-slate-700 block">Descreva seu fluxo atual e sua principal dúvida operacional:</label>
                      <textarea
                        required
                        rows={4}
                        placeholder="Escreva brevemente o que sua equipe faz nessa atividade e em qual momento você sente que o fluxo fica arrastado ou com retrabalho."
                        value={specialistProblem}
                        onChange={(e) => setSpecialistProblem(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-none focus:outline-none focus:border-slate-900 bg-white"
                      ></textarea>
                    </div>
                  </div>

                  <div className="pt-2 border-t flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmittingSpecialist}
                      className="px-6 py-2.5 bg-[#C49746] text-slate-950 font-black text-xs uppercase hover:bg-[#b08436] disabled:bg-slate-300 disabled:text-slate-500 rounded-none transition-all flex items-center gap-1.5 cursor-pointer shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                    >
                      {isSubmittingSpecialist ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Processando...
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          Enviar Solicitação 🌱
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>

              {/* LIST OF PREVIOUS REQUESTS */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono font-black text-slate-900 uppercase tracking-widest pl-1">
                  📋 Suas Solicitações Solicitadas ({submittedRequests.length})
                </h4>

                <div className="space-y-2">
                  {submittedRequests.map((req) => {
                    let badgeColor = "bg-amber-100 text-amber-800 border-amber-300";
                    if (req.status === "Concluído") {
                      badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-300";
                    } else if (req.status === "Em Análise") {
                      badgeColor = "bg-indigo-100 text-indigo-800 border-indigo-300";
                    }

                    let urgBadge = "bg-gray-100 text-gray-700";
                    if (req.urgency === "Alta") urgBadge = "bg-red-100 text-red-800";
                    else if (req.urgency === "Média") urgBadge = "bg-orange-100 text-orange-850";

                    return (
                      <div 
                        key={req.id}
                        className="p-4 bg-white border border-slate-200 hover:border-slate-300 transition-all rounded-none text-left flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap text-xs">
                            <span className="font-mono font-black text-slate-900">{req.id}</span>
                            <span className="text-slate-400">•</span>
                            <span className="text-slate-500">Enviado em {req.createdAt.toLocaleDateString("pt-BR")}</span>
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-none ${urgBadge}`}>
                              Prioridade: {req.urgency}
                            </span>
                          </div>
                          
                          <h4 className="text-sm font-serif font-extrabold text-slate-900">{req.processName}</h4>
                          <p className="text-xs text-slate-500 line-clamp-2">
                            {req.description}
                          </p>
                        </div>

                        <div className="shrink-0 flex items-center gap-2 self-end md:self-auto">
                          <span className={`px-3 py-1 font-mono hover:scale-105 text-[10px] font-extrabold border rounded-full capitalize ${badgeColor}`}>
                            ● {req.status}
                          </span>
                        </div>
                      </div>
                    );
                  })}

                  {submittedRequests.length === 0 && (
                    <div className="p-6 text-center border-2 border-dashed border-slate-200 text-slate-400 text-xs font-mono rounded-none bg-white">
                      Você ainda não fez nenhuma solicitação de mentoria ou suporte avançado.
                    </div>
                  )}
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

            </div>
          </div>
        </div>

        {/* 📚 ANOTAÇÕES EXPLICATIVAS: COLUNA DIREITA (MOCKUP COMENTÁRIOS 4, 5, 6) */}
        {showAnnotations && (
          <div className="xl:w-[220px] flex flex-col justify-start space-y-16 shrink-0 py-16 hidden xl:flex text-left font-sans">
            
            {/* Anotação 4 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-colors hover:bg-amber-100/80">
              <div className="absolute top-1/2 -left-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -left-8 transform -translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">4.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Agrupar funções avançadas</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Funções técnicas secundárias organizadas dentro do menu suspenso "Mais opções" para não poluírem a área de trabalho.
                  </p>
                </div>
              </div>
            </div>

            {/* Anotação 5 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-colors hover:bg-amber-100/80">
              <div className="absolute top-1/2 -left-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -left-8 transform -translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">5.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Destacar progresso da jornada</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Gráfico dinâmico radial em formato de rosquinha e checklists objetivos de progressão para acompanhamento rápido.
                  </p>
                </div>
              </div>
            </div>

            {/* Anotação 6 */}
            <div className="relative p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-sm shadow-xs transition-colors hover:bg-amber-100/80">
              <div className="absolute top-1/2 -left-8 h-0.5 w-8 bg-amber-400"></div>
              <div className="absolute top-1/2 -left-8 transform -translate-x-1.5 -translate-y-1.5 w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="flex items-start gap-1.5">
                <span className="font-mono font-black text-amber-800 text-xs mt-0.5">6.</span>
                <div className="space-y-1">
                  <span className="text-[11px] font-black text-amber-950 uppercase tracking-tight block">Unificar ajuda e copiloto</span>
                  <p className="text-[10px] text-amber-900 leading-snug">
                    Painel unificado de glossário de termos traduzidos e chat copiloto inteligente para suporte por etapa.
                  </p>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* FOOTER */}
      <div className="border-t border-slate-200 pt-5 text-center flex flex-col md:flex-row justify-between text-[11px] text-slate-400 font-mono gap-2 pb-6">
        <span>OptimaFlow Easy Mode • Mapeador Kaizen Geral</span>
        <span>Apoio Certificado por Green &amp; Black Belts de Suporte</span>
      </div>

    </div>
  );
}
