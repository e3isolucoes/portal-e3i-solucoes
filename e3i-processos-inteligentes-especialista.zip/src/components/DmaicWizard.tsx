import React, { useState, useEffect } from "react";
import { 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  Activity, 
  TrendingUp, 
  Sliders, 
  Play,
  Check,
  AlertTriangle,
  HelpCircle,
  BarChart,
  Grid,
  Zap,
  Info
} from "lucide-react";
import { ProcessStep, ControlPlan, DmaicPhaseType } from "../types";
import { useToast } from "../shared/ui/Toast";
import DmaicCycleTimeHistogram from "./DmaicCycleTimeHistogram";

interface DmaicWizardProps {
  selectedStep: ProcessStep;
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  arrivalRate: number;
  activePhase: DmaicPhaseType;
  setActivePhase: (phase: DmaicPhaseType) => void;
}

export default function DmaicWizard({ selectedStep, steps, setSteps, arrivalRate, activePhase, setActivePhase }: DmaicWizardProps) {
  const { success } = useToast();
  const handleNavigatePhase = (direction: "PREV" | "NEXT") => {
    const phases: DmaicPhaseType[] = ["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"];
    const currentIndex = phases.indexOf(activePhase);
    if (direction === "PREV") {
      const prevIndex = (currentIndex - 1 + phases.length) % phases.length;
      setActivePhase(phases[prevIndex]);
    } else {
      const nextIndex = (currentIndex + 1) % phases.length;
      setActivePhase(phases[nextIndex]);
    }
  };

  // Helper to save DMAIC state back to global steps array
  const saveDmaicState = (updates: Partial<ProcessStep>) => {
    setSteps((prev) =>
      prev.map((s) => (s.id === selectedStep.id ? { ...s, ...updates } : s))
    );
  };

  // DEFINE states
  const [problemScope, setProblemScope] = useState<string>(
    selectedStep.dmaicProblemScope ||
      `O gargalo identificado na etapa "${selectedStep.name}" está limitando a vazão do sistema e expandindo o lead time. No momento, esta etapa opera com utilização elevada de % UTIL, gerando filas e retrabalho.`
  );
  const [projectGoal, setProjectGoal] = useState<string>(
    selectedStep.dmaicProjectGoal ||
      `Garantir que o tempo de fila neste posto caia abaixo de 2.0 minutos, aumentar o yield rate para acima de 98% de conformidade, e eliminar o risco de gargalo.`
  );
  const [targetMetric, setTargetMetric] = useState<number>(
    selectedStep.dmaicTargetMetric ??
      (selectedStep ? Math.round(selectedStep.processingTime * 0.8 * 10) / 10 : 3.0)
  );

  // MEASURE states - Simulated list of 10 recent sample measurements around selected step
  const [measurements, setMeasurements] = useState<number[]>(selectedStep.dmaicMeasurements || []);
  useEffect(() => {
    if (selectedStep) {
      // Seed samples based on step processingTime and standardDeviation
      const mean = selectedStep.processingTime;
      const sd = selectedStep.standardDeviation;
      
      const samples = selectedStep.dmaicMeasurements || Array.from({ length: 10 }, () => {
        // Simple normal distribution simulation (Box-Muller transform)
        const u1 = Math.random() || 0.0001;
        const u2 = Math.random() || 0.0001;
        const randStd = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
        return Math.max(0.1, Math.round((mean + randStd * sd) * 10) / 10);
      });
      setMeasurements(samples);
      
      const defaultTarget = Math.round(mean * 0.8 * 10) / 10;
      setTargetMetric(selectedStep.dmaicTargetMetric ?? defaultTarget);
      
      const defaultProblem = `O gargalo identificado na etapa "${selectedStep.name}" está limitando a vazão total do sistema de produção e expandindo o lead-time complessivo. No momento, o posto de trabalho opera à beira de sua saturação técnica, gerando longas filas acumuladas.`;
      setProblemScope(selectedStep.dmaicProblemScope ?? defaultProblem);
      
      const defaultGoal = `Reduzir o tempo de ciclo local para abaixo de ${defaultTarget} min, aumentar o yield de primeira passagem para acima de 98% e eliminar a instabilidade operacional.`;
      setProjectGoal(selectedStep.dmaicProjectGoal ?? defaultGoal);

      if (selectedStep.dmaicIshikawaCauses) {
        setIshikawaCauses(selectedStep.dmaicIshikawaCauses);
      } else {
        setIshikawaCauses({
          metodo: ["Fluxo de trabalho empurrado sem controle cambial Lean (Kanban)", "Procedimentos operacionais com pouca padronização escritural"],
          maquina: ["Microparadas intermitentes no ferramental primário", "Falta de manutenção preditiva regular nos bicos de soldagem"],
          maoDeObra: ["Falta de reciclagem em tempos de ciclo balanceados", "Fadiga física e estresse devido a posições não ergonômicas"],
          material: ["Insumos secundários com variação de dimensionalidade física", "Lotes de alimentação de componentes com umidade excessiva"],
          medida: ["Calibração inexata de sensores ópticos de validação", "Ausência de controle estatístico por gráficos Shewhart"],
          meioAmbiente: ["Iluminação inconstante afetando o tempo visual do operador", "Excesso de ruído industrial desconcentrando a operação"],
        });
      }

      setEnablePokaYoke(selectedStep.dmaicEnablePokaYoke ?? false);
      setEnableSMED(selectedStep.dmaicEnableSMED ?? false);
      setEnableBalancing(selectedStep.dmaicEnableBalancing ?? false);
      setLcl(selectedStep.dmaicLcl ?? 0.8);
      setUcl(selectedStep.dmaicUcl ?? 5.8);
      setCtrlResponsible(selectedStep.dmaicCtrlResponsible ?? "Controlador de Qualidade");
      setCtrlReaction(selectedStep.dmaicCtrlReaction ?? "Interromper a alimentação de componentes, revisar sensores e calibrar os bicos mecânicos.");
    }
  }, [selectedStep]);

  // ANALYZE states - Interactive Ishikawa 6M root causes
  const [ishikawaCauses, setIshikawaCauses] = useState<{
    metodo: string[];
    maquina: string[];
    maoDeObra: string[];
    material: string[];
    medida: string[];
    meioAmbiente: string[];
  }>({
    metodo: ["Fluxo de trabalho empurrado sem controle cambial Lean (Kanban)", "Procedimentos operacionais com pouca padronização escritural"],
    maquina: ["Microparadas intermitentes no ferramental primário", "Falta de manutenção preditiva regular nos bicos de soldagem"],
    maoDeObra: ["Falta de reciclagem em tempos de ciclo balanceados", "Fadiga física e estresse devido a posições não ergonômicas"],
    material: ["Insumos secundários com variação de dimensionalidade física", "Lotes de alimentação de componentes com umidade excessiva"],
    medida: ["Calibração inexata de sensores ópticos de validação", "Ausência de controle estatístico por gráficos Shewhart"],
    meioAmbiente: ["Iluminação inconstante afetando o tempo visual do operador", "Excesso de ruído industrial desconcentrando a operação"],
  });

  const [newCauseText, setNewCauseText] = useState("");
  const [selectedM, setSelectedM] = useState<keyof typeof ishikawaCauses>("metodo");

  const handleAddIshikawaCause = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCauseText.trim()) return;
    const updatedCauses = {
      ...ishikawaCauses,
      [selectedM]: [...ishikawaCauses[selectedM], newCauseText.trim()],
    };
    setIshikawaCauses(updatedCauses);
    saveDmaicState({ dmaicIshikawaCauses: updatedCauses });
    setNewCauseText("");
  };

  // IMPROVE states - Simulated improvements
  const [enablePokaYoke, setEnablePokaYoke] = useState(false);
  const [enableSMED, setEnableSMED] = useState(false);
  const [enableBalancing, setEnableBalancing] = useState(false);

  // CONTROL states - Control limits
  const [lcl, setLcl] = useState(0.8);
  const [ucl, setUcl] = useState(5.8);
  const [ctrlResponsible, setCtrlResponsible] = useState("Controlador de Qualidade");
  const [ctrlReaction, setCtrlReaction] = useState("Interromper a alimentação de componentes, revisar sensores e calibrar os bicos mecânicos.");

  // Apply improvements to steps globally and simulate
  const handleApplyImprovementToggle = () => {
    setSteps((prev) => 
      prev.map((step) => {
        if (step.id === selectedStep.id) {
          let updated = { 
            ...step,
            dmaicEnablePokaYoke: enablePokaYoke,
            dmaicEnableSMED: enableSMED,
            dmaicEnableBalancing: enableBalancing
          };
          if (enablePokaYoke) {
            updated.yieldRate = 0.99; // Error proofing elevates quality to world-class
            updated.standardDeviation = Math.round(step.standardDeviation * 0.4 * 100) / 100; // lowers variability
          }
          if (enableSMED) {
            updated.setupTime = Math.max(0, Math.round(step.setupTime * 0.1)); // reduces setup by 90%
          }
          if (enableBalancing) {
            updated.resourceCount = step.resourceCount + 1; // adds a parallel resource for balancing
            updated.processingTime = Math.round(step.processingTime * 0.9 * 10) / 10; // minor speed improvement
          }
          return updated;
        }
        return step;
      })
    );
    success("Melhorias simuladas aplicada ao processo global com Sucesso! Examine o impacto dos novos limites estocásticos na barra de KPIs superiores.");
  };

  return (
    <div className="bg-[#FDFCFB] border border-[#1A1A1A]/10 rounded-none shadow-sm flex flex-col overflow-hidden" id="dmaic-wizard-viewport">
      
      {/* Wizard Header displaying selected step and phase info without repeating tab buttons */}
      <div className="bg-[#F5F2ED] border-b border-[#1A1A1A]/10 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#C49746] text-white font-mono text-[10px] uppercase font-bold tracking-wider rounded-none">
            Etapa Ativa: {selectedStep.id.toUpperCase()}
          </div>
          <div>
            <h4 className="font-serif font-black text-sm text-[#1A1A1A]">
              Otimização DMAIC de &ldquo;{selectedStep.name}&rdquo;
            </h4>
            <div className="flex items-center gap-2 mt-0.5" id="dmaic-header">
              <span className="text-[9px] font-sans text-[#1A1A1A]/50 bg-white/60 px-1.5 py-0.5 border border-[#1A1A1A]/10 font-medium">
                Tempo de Ciclo Atual: {selectedStep.processingTime} min / posto
              </span>
              <span className="text-[9px] font-mono font-bold text-[#C49746] uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C49746] inline-block animate-pulse"></span>
                Fase do Ciclo: {activePhase === "DEFINE" ? "DEFINIR" : activePhase === "MEASURE" ? "MEDIR" : activePhase === "ANALYZE" ? "ANALISAR" : activePhase === "IMPROVE" ? "MELHORAR" : "CONTROLAR"}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleNavigatePhase("PREV")}
            className="p-1 px-2.5 bg-white border border-[#1A1A1A]/20 text-[10px] font-mono text-gray-700 hover:border-gray-900 hover:bg-gray-50 transition flex items-center gap-1 rounded-sm cursor-pointer"
          >
            <ChevronLeft size={11} /> Fase Anterior
          </button>
          <button
            onClick={() => handleNavigatePhase("NEXT")}
            className="p-1 px-2.5 bg-white border border-[#1A1A1A]/20 text-[10px] font-mono text-gray-700 hover:border-gray-900 hover:bg-gray-50 transition flex items-center gap-1 rounded-sm cursor-pointer"
          >
            Próxima Fase <ChevronRight size={11} />
          </button>
        </div>
      </div>

      {/* Main Wizard Content Area */}
      <div className="p-6 md:p-8 flex-grow">
        
        {/* ==================== DEFINE PHASE ==================== */}
        {activePhase === "DEFINE" && (
          <div className="space-y-6 animate-fade-in">
            <div className="border-b border-gray-100 pb-3">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Passo 1: Define</span>
              <h3 className="text-xl font-serif text-[#1A1A1A] italic">Declaração do Escopo de Otimização</h3>
              <p className="text-xs text-gray-500 mt-1">Determine as fronteiras do problema em torno do gargalo selecionado.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-[9px] uppercase font-bold text-gray-500 mb-1">Delimitação do Problema Operacional</label>
                  <textarea
                    rows={4}
                    value={problemScope}
                    onChange={(e) => {
                      const val = e.target.value;
                      setProblemScope(val);
                      saveDmaicState({ dmaicProblemScope: val });
                    }}
                    className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-2 focus:border-[#C49746] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[9px] uppercase font-bold text-gray-500 mb-1">Impacto Financeiro / Produtivo Indireto</label>
                  <p className="text-[11px] text-gray-600 bg-[#F5F2ED] p-3 border-l-2 border-[#C49746]">
                    Devido à instabilidade na etapa <strong>{selectedStep.name}</strong>, a linha sofre com acúmulos de WIP e flutuações de prazo de entrega. Ao focar nesse posto, estimamos uma melhoria potencial de <strong>{((1 - selectedStep.yieldRate) * 100).toFixed(0)}%</strong> de descarte evitado.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-[9px] uppercase font-bold text-gray-500 mb-1">Meta Declarada (KPI Alvo)</label>
                  <textarea
                    rows={3}
                    value={projectGoal}
                    onChange={(e) => {
                      const val = e.target.value;
                      setProjectGoal(val);
                      saveDmaicState({ dmaicProjectGoal: val });
                    }}
                    className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-2 focus:border-[#C49746] focus:outline-none"
                  />
                </div>

                <div className="p-4 border border-[#1A1A1A]/10 bg-white space-y-2">
                  <div className="text-[9px] font-bold uppercase tracking-wider text-[#C49746]">Definição de Métricas do Projeto:</div>
                  <div className="flex justify-between items-center text-xs">
                    <span>Métrica local (CTm):</span>
                    <span className="font-mono font-bold text-gray-900">{selectedStep.processingTime} min</span>
                  </div>
                  <div className="flex justify-between items-center text-xs pt-1 border-t border-gray-100">
                    <span>Limiar Alvo (Target):</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="0.1"
                        value={targetMetric}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value) || 2.0;
                          setTargetMetric(val);
                          saveDmaicState({ dmaicTargetMetric: val });
                        }}
                        className="w-14 bg-transparent border-b border-[#1A1A1A]/20 p-0 text-right font-mono font-bold text-gray-900 focus:outline-none"
                      />
                      <span>min</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-gray-100">
              <button
                onClick={() => setActivePhase("MEASURE")}
                className="bg-[#1A1A1A] text-white py-2 px-6 text-xs uppercase font-bold hover:opacity-90 flex items-center gap-1.5 transition"
              >
                Medir Estabilidade (MEASURE) <ChevronRight size={13} />
              </button>
            </div>
          </div>
        )}

        {/* ==================== MEASURE PHASE ==================== */}
        {activePhase === "MEASURE" && (
          <div className="space-y-6 animate-fade-in">
            <div className="border-b border-gray-100 pb-3">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Passo 2: Measure</span>
              <h3 className="text-xl font-serif text-[#1A1A1A] italic">Coleta de Amostragem de Capabilidade</h3>
              <p className="text-xs text-gray-500 mt-1">Evidências matemáticas coletadas sobre os tempos reais de execução do gargalo.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              
              {/* Simulated measurement values list */}
              <div className="md:col-span-4 space-y-3">
                <span className="block text-[9px] uppercase font-bold text-gray-500">Últimas 10 Amostras Coletadas (Filas + Toque):</span>
                <div className="bg-white border select-none divide-y divide-gray-100 max-h-56 overflow-y-auto font-mono text-xs">
                  {measurements.map((val, mIdx) => (
                    <div key={mIdx} className="p-2 flex justify-between items-center hover:bg-[#F5F2ED]/50">
                      <span className="text-gray-400">#A-00{mIdx + 1}</span>
                      <strong className={val > selectedStep.processingTime + selectedStep.standardDeviation ? "text-red-600" : "text-gray-800"}>
                        {val.toFixed(1)} minutos
                      </strong>
                    </div>
                  ))}
                </div>
              </div>

              {/* Graphical distribution mockup */}
              <div className="md:col-span-8 border border-gray-100 p-4 bg-white space-y-4">
                <div>
                  <span className="block text-[9px] uppercase font-bold text-gray-500 mb-1">Distribuição Normal Estocástica dos Tempos</span>
                  <p className="text-[10px] text-gray-400">Visualização de variabilidade (Capacidade Cp/Cpk representativa do desvio σ).</p>
                </div>

                {/* SVG representing a normal bell curve */}
                <div className="relative h-32 w-full pt-4">
                  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    {/* Normal Distribution Bell Curve Path */}
                    <path
                      d="M 10 95 Q 30 95 40 50 T 50 15 T 60 50 T 70 95 T 90 95"
                      fill="none"
                      stroke="#1A1A1A"
                      strokeWidth="2.5"
                    />
                    {/* Standard deviation band background */}
                    <path
                      d="M 40 95 L 40 50 Q 50 15 50 15 Q 50 15 60 50 L 60 95 Z"
                      fill="#C49746"
                      fillOpacity="0.1"
                    />
                    {/* Average/Mean Marker line */}
                    <line x1="50" y1="15" x2="50" y2="95" stroke="#C49746" strokeDasharray="2,2" strokeWidth="1.5" />
                  </svg>
                  
                  {/* Floating Average labels */}
                  <div className="absolute top-[8%] left-[51%] text-[8px] font-bold text-[#C49746] bg-white px-1 font-serif">
                    Média ({selectedStep.processingTime}m)
                  </div>
                  <div className="absolute top-[85%] left-[30%] text-[7.5px] font-mono text-gray-400">
                    -3σ ({Math.max(0.1, selectedStep.processingTime - 3 * selectedStep.standardDeviation).toFixed(1)}m)
                  </div>
                  <div className="absolute top-[85%] left-[64%] text-[7.5px] font-mono text-gray-400">
                    +3σ ({(selectedStep.processingTime + 3 * selectedStep.standardDeviation).toFixed(1)}m)
                  </div>
                </div>

                <div className="bg-[#F5F2ED] p-3 text-[10.5px] leading-relaxed text-gray-700 space-y-1">
                  <div>• <strong>Desvio Padrão Real (σ):</strong> {selectedStep.standardDeviation} min</div>
                  <div>• <strong>Fator de Variação (CV):</strong> {(selectedStep.standardDeviation / selectedStep.processingTime).toFixed(2)} [Alto se &gt; 0.3]</div>
                  <div>• <strong>Capabilidade Estimada do Processo (Cp):</strong> {(selectedStep.processingTime / (6 * selectedStep.standardDeviation || 1)).toFixed(2)}</div>
                </div>
              </div>

            </div>

            {/* Interactive Histogram for cycle time distribution of each step */}
            <DmaicCycleTimeHistogram steps={steps} selectedStep={selectedStep} />

            <div className="flex justify-between pt-4 border-t border-gray-100">
              <button
                onClick={() => setActivePhase("DEFINE")}
                className="border border-[#1A1A1A]/10 hover:border-gray-900 py-2 px-6 text-xs font-bold transition flex items-center gap-1"
              >
                <ChevronLeft size={13} /> Voltar
              </button>
              <button
                onClick={() => setActivePhase("ANALYZE")}
                className="bg-[#1A1A1A] text-white py-2 px-6 text-xs uppercase font-bold hover:opacity-90 flex items-center gap-1.5 transition"
              >
                Análise Causa Raiz (ANALYZE) <ChevronRight size={13} />
              </button>
            </div>
          </div>
        )}

        {/* ==================== ANALYZE PHASE ==================== */}
        {activePhase === "ANALYZE" && (
          <div className="space-y-6 animate-fade-in">
            <div className="border-b border-gray-100 pb-3">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Passo 3: Analyze</span>
              <h3 className="text-xl font-serif text-[#1A1A1A] italic">Espinha de Peixe Ishikawa (Causa e Efeito)</h3>
              <p className="text-xs text-gray-500 mt-1">Explore os fatores subjacentes das perdas de produtividade sob a metodologia 6M.</p>
            </div>

            {/* INTERACTIVE ISHIKAWA REGISTER */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Interactive Ishikawa Diagram Draw */}
              <div className="lg:col-span-8 border border-gray-100 p-4 bg-white relative overflow-hidden">
                <span className="block text-[8px] uppercase tracking-widest font-bold text-gray-400 mb-3">Diagrama Espinha de Peixe (6M) - Interativo</span>
                
                {/* SVG drawing an editorial elegant Herringbone layout */}
                <div className="relative h-64 w-full bg-[#FDFCFB]">
                  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 600 240">
                    
                    {/* Spine Backbone */}
                    <line x1="20" y1="120" x2="520" y2="120" stroke="#1A1A1A" strokeWidth="3" />
                    {/* Head Arrow */}
                    <polygon points="520,114 532,120 520,126" fill="#1A1A1A" />

                    {/* Left Diagonal bones (top) */}
                    <line x1="120" y1="120" x2="180" y2="40" stroke="#1A1A1A" strokeWidth="1.5" />
                    <line x1="260" y1="120" x2="320" y2="40" stroke="#1A1A1A" strokeWidth="1.5" />
                    <line x1="400" y1="120" x2="460" y2="40" stroke="#1A1A1A" strokeWidth="1.5" />

                    {/* Right Diagonal bones (bottom) */}
                    <line x1="120" y1="120" x2="180" y2="200" stroke="#1A1A1A" strokeWidth="1.5" />
                    <line x1="260" y1="120" x2="320" y2="200" stroke="#1A1A1A" strokeWidth="1.5" />
                    <line x1="400" y1="120" x2="460" y2="200" stroke="#1A1A1A" strokeWidth="1.5" />

                    {/* Nodes titles text positioning */}
                    <text x="180" y="32" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">1. MÉTODO</text>
                    <text x="320" y="32" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">2. MÁQUINA</text>
                    <text x="460" y="32" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">3. MÃO DE OBRA</text>

                    <text x="180" y="215" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">4. MATERIAL</text>
                    <text x="320" y="215" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">5. MEDIDA</text>
                    <text x="460" y="215" fontSize="9" fontWeight="bold" textAnchor="middle" fill="#C49746">6. MEIO AMBIENTE</text>

                    {/* Main Effect Block */}
                    <rect x="532" y="90" width="60" height="60" fill="#C49746" />
                    <text x="562" y="116" fontSize="8" fontWeight="bold" textAnchor="middle" fill="white">GARGALO</text>
                    <text x="562" y="130" fontSize="7" textAnchor="middle" fill="white" fillOpacity="0.8">EFICIÊNCIA</text>

                    {/* Render mini markers representing causes on the bones */}
                    <circle cx="150" cy="80" r="3" fill="#1A1A1A" />
                    <circle cx="290" cy="80" r="3" fill="#1A1A1A" />
                    <circle cx="430" cy="80" r="3" fill="#1A1A1A" />
                    <circle cx="150" cy="160" r="3" fill="#1A1A1A" />
                    <circle cx="290" cy="160" r="3" fill="#1A1A1A" />
                    <circle cx="430" cy="160" r="3" fill="#1A1A1A" />
                  </svg>

                  {/* HTML Overlay badges indicating cause counts */}
                  <div className="absolute top-[48px] left-[134px] text-[7.5px] font-mono text-gray-500 font-bold max-w-[80px] break-words">
                    {ishikawaCauses.metodo[0]}
                  </div>
                  <div className="absolute top-[48px] left-[274px] text-[7.5px] font-mono text-gray-500 font-bold max-w-[80px] break-words">
                    {ishikawaCauses.maquina[0]}
                  </div>
                  <div className="absolute top-[48px] left-[414px] text-[7.5px] font-mono text-gray-500 font-bold max-w-[80px] break-words">
                    {ishikawaCauses.maoDeObra[0]}
                  </div>
                </div>
              </div>

              {/* Interactive add panel */}
              <div className="lg:col-span-4 bg-[#F5F2ED] border border-gray-200 p-4 space-y-4 rounded-sm">
                <span className="block text-[9px] uppercase tracking-wider font-bold text-gray-900">
                  Cadastrar Novas Causas Raízes
                </span>

                <form onSubmit={handleAddIshikawaCause} className="space-y-3">
                  <div>
                    <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Selecionar categoria (6M)</label>
                    <select
                      value={selectedM}
                      onChange={(e: any) => setSelectedM(e.target.value)}
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs py-1 px-1.5 focus:outline-none"
                    >
                      <option value="metodo">1. Método</option>
                      <option value="maquina">2. Máquina</option>
                      <option value="maoDeObra">3. Mão de Obra</option>
                      <option value="material">4. Material</option>
                      <option value="medida">5. Medida</option>
                      <option value="meioAmbiente">6. Meio Ambiente</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Causa Diagnosticada</label>
                    <textarea
                      rows={2}
                      value={newCauseText}
                      onChange={(e) => setNewCauseText(e.target.value)}
                      placeholder="Ex: Fadiga muscular no turno noturno."
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 focus:border-[#C49746] focus:outline-none resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-widest font-bold py-2 mt-2"
                  >
                    + Adicionar na Espinha
                  </button>
                </form>

                {/* List registered causes */}
                <div className="border-t border-gray-200 pt-3 space-y-2">
                  <span className="block text-[8px] uppercase text-gray-500 font-bold">Causas da Categoria Selecionada:</span>
                  <div className="space-y-1.5">
                    {ishikawaCauses[selectedM].map((c, i) => (
                      <div key={i} className="text-[10px] bg-white border border-gray-100 p-1.5 rounded-xs leading-snug">
                        {i + 1}. {c}
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>

            <div className="flex justify-between pt-4 border-t border-gray-100">
              <button
                onClick={() => setActivePhase("MEASURE")}
                className="border border-[#1A1A1A]/10 hover:border-gray-900 py-2 px-6 text-xs font-bold transition flex items-center gap-1"
              >
                <ChevronLeft size={13} /> Voltar
              </button>
              <button
                onClick={() => setActivePhase("IMPROVE")}
                className="bg-[#1A1A1A] text-white py-2 px-6 text-xs uppercase font-bold hover:opacity-90 flex items-center gap-1.5 transition"
              >
                Simular Soluções (IMPROVE) <ChevronRight size={13} />
              </button>
            </div>
          </div>
        )}

        {/* ==================== IMPROVE PHASE ==================== */}
        {activePhase === "IMPROVE" && (
          <div className="space-y-6 animate-fade-in">
            <div className="border-b border-gray-100 pb-3">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Passo 4: Improve</span>
              <h3 className="text-xl font-serif text-[#1A1A1A] italic">Simulação de Soluções Lean Six Sigma</h3>
              <p className="text-xs text-gray-500 mt-1">Habilite melhorias estruturadas no posto para observar a eliminação de avarias em tempo real.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Toggles improvement tools */}
              <div className="lg:col-span-6 space-y-4">
                <span className="block text-[9px] uppercase font-bold text-gray-500">Selecione Contra-medidas Lean:</span>
                
                <div className="space-y-3">
                  <label className="flex items-start gap-3 p-3 bg-white border border-gray-100 cursor-pointer select-none hover:border-[#C49746]/40 transition rounded-sm">
                    <input
                      type="checkbox"
                      checked={enablePokaYoke}
                      onChange={(e) => setEnablePokaYoke(e.target.checked)}
                      className="mt-1 accent-[#C49746]"
                    />
                    <div>
                      <strong className="text-xs text-gray-900 block font-serif">Dispositivo Poka-Yoke (Rendimento 99%)</strong>
                      <p className="text-[10px] text-gray-500 leading-snug mt-0.5">
                        Mecanismo físico/digital anti-erros que zera retrabalhos e descarrila variações. Estabiliza o desvio padrão operacional.
                      </p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-3 bg-white border border-gray-100 cursor-pointer select-none hover:border-[#C49746]/40 transition rounded-sm">
                    <input
                      type="checkbox"
                      checked={enableSMED}
                      onChange={(e) => setEnableSMED(e.target.checked)}
                      className="mt-1 accent-[#C49746]"
                    />
                    <div>
                      <strong className="text-xs text-gray-900 block font-serif">Troca Rápida de Setup - SMED (Redução de 90%)</strong>
                      <p className="text-[10px] text-gray-500 leading-snug mt-0.5">
                        Extirpa gargalos causados por preparação de maquinário. Reduz tempos ociosos de lote para frações de segundos.
                      </p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-3 bg-white border border-gray-100 cursor-pointer select-none hover:border-[#C49746]/40 transition rounded-sm">
                    <input
                      type="checkbox"
                      checked={enableBalancing}
                      onChange={(e) => setEnableBalancing(e.target.checked)}
                      className="mt-1 accent-[#C49746]"
                    />
                    <div>
                      <strong className="text-xs text-gray-900 block font-serif">Balanceamento de Staff (+1 Operador / Servidor paralelo)</strong>
                      <p className="text-[10px] text-gray-500 leading-snug mt-0.5">
                        Adiciona recurso humano ou maquinário espelhado para diluir a saturação e triplicar a capacidade operacional local.
                      </p>
                    </div>
                  </label>
                </div>

                <button
                  onClick={handleApplyImprovementToggle}
                  className="w-full bg-[#C49746] hover:bg-[#C49746]/90 text-white text-[10px] uppercase tracking-widest font-bold py-3 flex items-center justify-center gap-1.5 transition-all shadow-sm rounded-none"
                >
                  <Zap size={11} className="fill-white" />
                  Simular Soluções Ativas no Processo
                </button>
              </div>

              {/* Dynamic comparison table */}
              <div className="lg:col-span-6 border border-gray-100 bg-[#F5F2ED] p-5 space-y-4 rounded-sm">
                <div>
                  <span className="block text-[9px] uppercase tracking-widest font-bold text-gray-400 mb-0.5">Análise de Simulação Estocástica</span>
                  <h4 className="text-sm font-serif font-bold italic text-gray-900">Estado Atual vs Estado Futuro LSS</h4>
                </div>

                <div className="space-y-3 font-mono text-xs">
                  <div className="grid grid-cols-3 border-b border-gray-200 pb-2 text-[9px] font-bold uppercase text-gray-400">
                    <div>Métrica</div>
                    <div className="text-right">Baseline</div>
                    <div className="text-right">Projetado</div>
                  </div>

                  <div className="grid grid-cols-3 py-1 items-center">
                    <span className="text-gray-800 font-sans">Capacidade Local:</span>
                    <span className="text-right text-gray-900">{(60 / selectedStep.processingTime * selectedStep.resourceCount).toFixed(1)} u/h</span>
                    <span className="text-right font-bold text-emerald-700">
                      {(60 / (enableBalancing ? selectedStep.processingTime*0.9 : selectedStep.processingTime) * (enableBalancing ? selectedStep.resourceCount+1 : selectedStep.resourceCount)).toFixed(1)} u/h
                    </span>
                  </div>

                  <div className="grid grid-cols-3 py-1 items-center border-t border-gray-100">
                    <span className="text-gray-800 font-sans">Qualidade (Yield):</span>
                    <span className="text-right text-gray-900">{(selectedStep.yieldRate * 100).toFixed(0)}%</span>
                    <span className="text-right font-bold text-emerald-700">
                      {enablePokaYoke ? "99%" : `${(selectedStep.yieldRate * 100).toFixed(0)}%`}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 py-1 items-center border-t border-gray-100">
                    <span className="text-gray-800 font-sans">Desvio Padrão (σ):</span>
                    <span className="text-right text-gray-900">± {selectedStep.standardDeviation} min</span>
                    <span className="text-right font-bold text-emerald-700">
                      ± {enablePokaYoke ? (selectedStep.standardDeviation * 0.4).toFixed(1) : selectedStep.standardDeviation} min
                    </span>
                  </div>

                  <div className="grid grid-cols-3 py-1 items-center border-t border-gray-100">
                    <span className="text-gray-800 font-sans">Tempo de Setup:</span>
                    <span className="text-right text-gray-900">{selectedStep.setupTime} min</span>
                    <span className="text-right font-bold text-emerald-700">
                      {enableSMED ? Math.max(0, Math.round(selectedStep.setupTime * 0.1)) : selectedStep.setupTime} min
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white border border-gray-100 text-[10px] leading-relaxed text-gray-500">
                  <p>
                    <strong>Nota Lean:</strong> O balanceamento e o Poka-yoke eliminam filas estocásticas acumulativas de tal sorte que o lead time total projetado despenca estritamente, elevando o nível Sigma geral do processo.
                  </p>
                </div>
              </div>

            </div>

            <div className="flex justify-between pt-4 border-t border-gray-100">
              <button
                onClick={() => setActivePhase("ANALYZE")}
                className="border border-[#1A1A1A]/10 hover:border-gray-900 py-2 px-6 text-xs font-bold transition flex items-center gap-1"
              >
                <ChevronLeft size={13} /> Voltar
              </button>
              <button
                onClick={() => setActivePhase("CONTROL")}
                className="bg-[#1A1A1A] text-white py-2 px-6 text-xs uppercase font-bold hover:opacity-90 flex items-center gap-1.5 transition"
              >
                Gerar Plano de Controle (CONTROL) <ChevronRight size={13} />
              </button>
            </div>
          </div>
        )}

        {/* ==================== CONTROL PHASE ==================== */}
        {activePhase === "CONTROL" && (
          <div className="space-y-6 animate-fade-in">
            <div className="border-b border-gray-100 pb-3">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Passo 5: Control</span>
              <h3 className="text-xl font-serif text-[#1A1A1A] italic">Cartas de Controle SPC &amp; Monitoramento</h3>
              <p className="text-xs text-gray-500 mt-1">Padronize os ganhos, estipule limites estatísticos e reações do supervisor.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Plan parameters inputs */}
              <div className="lg:col-span-6 bg-white border border-gray-100 p-5 space-y-4">
                <span className="block text-[9px] uppercase font-bold text-[#C49746] border-b border-gray-100 pb-1">
                  Matriz do Plano de Reação LSS
                </span>

                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Limite Inferior (LIC/LCL)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={lcl}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value) || 0;
                          setLcl(val);
                          saveDmaicState({ dmaicLcl: val });
                        }}
                        className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 font-mono focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Limite Superior (LSC/UCL)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={ucl}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value) || 0;
                          setUcl(val);
                          saveDmaicState({ dmaicUcl: val });
                        }}
                        className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 font-mono focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Responsável pela Medição Diária</label>
                    <input
                      type="text"
                      value={ctrlResponsible}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCtrlResponsible(val);
                        saveDmaicState({ dmaicCtrlResponsible: val });
                      }}
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[8px] uppercase text-gray-500 font-bold mb-1">Plano de Reação Operacional</label>
                    <textarea
                      rows={3}
                      value={ctrlReaction}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCtrlReaction(val);
                        saveDmaicState({ dmaicCtrlReaction: val });
                      }}
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 focus:border-[#C49746] focus:outline-none resize-none text-[#C49746]"
                    />
                  </div>
                </div>
              </div>

              {/* Graphical control guide */}
              <div className="lg:col-span-6 bg-[#F5F2ED] border border-gray-100 p-5 space-y-4 rounded-sm">
                <div>
                  <span className="block text-[9px] uppercase tracking-widest font-bold text-gray-400">Garantia de Manutenibilidade Lean</span>
                  <h4 className="text-sm font-serif font-bold italic text-gray-900">Monitoramento Contínuo CEP</h4>
                </div>

                {/* Simulated stable CEP curve */}
                <div className="bg-white border p-3">
                  <div className="relative h-28 w-full">
                    {/* Limits lines */}
                    <div className="absolute top-[18%] inset-x-0 border-t border-dashed border-red-500/60 text-[7px] text-red-600 font-bold px-1 pointer-events-none uppercase">
                      LSC / UCL ({ucl} min)
                    </div>
                    <div className="absolute top-[50%] inset-x-0 border-t border-emerald-600 text-[7px] text-emerald-800 font-bold px-1 pointer-events-none uppercase">
                      Alvo / Target ({selectedStep.processingTime} min)
                    </div>
                    <div className="absolute top-[82%] inset-x-0 border-t border-dashed border-red-500/60 text-[7px] text-red-600 font-bold px-1 pointer-events-none uppercase">
                      LIC / LCL ({lcl} min)
                    </div>

                    {/* SVG Curve for stabilized system */}
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <path
                        d="M 0 52 L 15 48 L 30 54 L 45 46 L 60 51 L 75 49 L 90 53 L 100 50"
                        fill="none"
                        stroke="#1A1A1A"
                        strokeWidth="1.5"
                      />
                      {/* Dots */}
                      <circle cx="15" cy="48" r="2" fill="#C49746" />
                      <circle cx="30" cy="54" r="2" fill="#C49746" />
                      <circle cx="45" cy="46" r="2" fill="#C49746" />
                      <circle cx="60" cy="51" r="2" fill="#C49746" />
                      <circle cx="75" cy="49" r="2" fill="#C49746" />
                      <circle cx="90" cy="53" r="2" fill="#C49746" />
                    </svg>
                  </div>
                  <div className="text-[7.5px] font-mono text-gray-400 text-center mt-2 uppercase tracking-wide">
                    Leituras Diárias do Operador (Processo sob Controle Estatístico)
                  </div>
                </div>

                <p className="text-[10.5px] leading-relaxed text-gray-600">
                  Ao documentar e auditar esses limites, garantimos que qualquer <strong>Causa Especial</strong> de desvio seja contida em minutos, bloqueando a recorrência de gargalos.
                </p>
              </div>

            </div>

            <div className="flex justify-between pt-4 border-t border-gray-100">
              <button
                onClick={() => setActivePhase("IMPROVE")}
                className="border border-[#1A1A1A]/10 hover:border-gray-900 py-2 px-6 text-xs font-bold transition flex items-center gap-1"
              >
                <ChevronLeft size={13} /> Voltar
              </button>
              
              <button
                onClick={() => {
                  success(`O plano de controle do posto de trabalho "${selectedStep.name}" foi catalogado com sucesso no sistema e assinado digitalmente por ${ctrlResponsible}.`);
                  setActivePhase("DEFINE");
                }}
                className="bg-emerald-700 hover:bg-emerald-800 text-white py-2 px-6 text-xs uppercase font-bold transition-all"
              >
                Salvar e Homologar Ciclo DMAIC
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
