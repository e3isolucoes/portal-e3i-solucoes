import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  ClipboardCheck, 
  HelpCircle, 
  Zap, 
  ChevronRight, 
  ArrowRight,
  RotateCcw, 
  Sliders, 
  BarChart, 
  CheckCircle, 
  Sparkles,
  Info,
  ShieldCheck,
  Compass,
  Camera,
  FileSpreadsheet,
  Cpu,
  AlertCircle,
  Trash,
  Plus,
  Database,
  Upload,
  Check
} from "lucide-react";
import { ProjectCharter, ProcessStep, Sipoc } from "../types";
import { BUSINESS_TERMS, BusinessType } from "../App";
import EmptyState from "./EmptyState";
import { PROCESS_TEMPLATES } from "../presets";
import { useDiagnosticSync } from "../hooks/useDiagnosticSync";

interface DiagnosticWizardProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  charter: ProjectCharter;
  setCharter: (charter: ProjectCharter) => void;
  sipoc: Sipoc;
  setSipoc: (sipoc: Sipoc) => void;
  setView: (view: "DIAGNOSTIC" | "MAP" | "DMAIC" | "BPM" | "OR_HUB" | "REPORT" | "KANBAN" | "ENTERPRISE_STUDIO") => void;
  businessType?: BusinessType;
  openTemplatesHub?: () => void;
  
  // New process alignment properties
  activeProjectName?: string;
  activeProjectObjective?: string;
  projectDetails?: any;
  setProjectDetails?: (details: any) => void;
  setBusinessType?: (type: BusinessType) => void;
}

interface Question {
  id: number;
  text: string;
  category: string;
  options: {
    label: string;
    value: string;
    points: {
      lean: number;
      sixSigma: number;
      pdca: number;
      tech: number;
    };
    advice: string;
  }[];
}

export function getDynamicQuestions(businessType: BusinessType, activeProjectName?: string): Question[] {
  const terms = BUSINESS_TERMS[businessType] || BUSINESS_TERMS.INDUSTRIAL;
  const projectName = activeProjectName || terms.title;

  // Cognitive Heuristics Engine to customize options precisely based on the specific process name
  const lowerName = projectName.toLowerCase();
  
  const isSMT = lowerName.includes("solda") || lowerName.includes("placa") || lowerName.includes("pcb") || lowerName.includes("smt") || lowerName.includes("circuito") || lowerName.includes("eletrôn") || lowerName.includes("fábrica") || lowerName.includes("máquina");
  const isServices = lowerName.includes("atendimento") || lowerName.includes("chamado") || lowerName.includes("sac") || lowerName.includes("ouvidoria") || lowerName.includes("suporte") || lowerName.includes("ticket") || lowerName.includes("cliente");
  const isFinance = lowerName.includes("fatura") || lowerName.includes("financeiro") || lowerName.includes("fiscal") || lowerName.includes("pagamento") || lowerName.includes("contab") || lowerName.includes("conciliação") || lowerName.includes("crédito");
  const isLogistics = lowerName.includes("carga") || lowerName.includes("despacho") || lowerName.includes("logíst") || lowerName.includes("transp") || lowerName.includes("estoque") || lowerName.includes("doca") || lowerName.includes("separação") || lowerName.includes("picking") || lowerName.includes("armazém");
  const isTech = lowerName.includes("software") || lowerName.includes("dev") || lowerName.includes("squad") || lowerName.includes("deploy") || lowerName.includes("release") || lowerName.includes("bug") || lowerName.includes("pull request") || lowerName.includes("código") || lowerName.includes("desenvolvimento");
  const isHealthcare = lowerName.includes("médic") || lowerName.includes("saúd") || lowerName.includes("hospital") || lowerName.includes("clínic") || lowerName.includes("paciente") || lowerName.includes("triagem") || lowerName.includes("pronto");

  let s1_sixSigma_desc = "Excesso de erros humanos, defeitos de qualidade física ou retrabalho de montagem nos postos.";
  let s1_lean_desc = "Acúmulo de pilhas de materiais (WIP), longos tempos de espera em filas e desperdícios de movimentação física.";
  let s1_pdca_desc = "Fluxo desorganizado, ausência total de procedimentos padrões (SOP) de trabalho e falta de rotina de fábrica.";
  let s1_lss_desc = "Precisamos de velocidade no fluxo produtivo combinado com eliminação minuciosa de falhas estatísticas graves de qualidade.";

  let s2_noMap_desc = "O fluxo operacional reside puramente no conhecimento tácito individual da equipe.";
  let s2_staticMap_desc = "Documentado de forma tradicional (As-Is), mas sem tempos de ciclos medidos com desvios padrão.";
  let s2_stochastic_desc = "Mapeado e medido formalmente, mas os gargalos teóricos mudam constantemente de lugar sem explicação.";

  let s3_throughput_desc = "Aumentar a vazão por hora (Throughput) para atender à demanda oscilante de clientes sem injetar mais custos.";
  let s3_yield_desc = "Elevar o Yield de primeira passagem (First Pass Yield) rumo ao patamar de Classe Mundial de zero defeitos.";
  let s3_leadTime_desc = "Reduzir drasticamente o Lead Time de ponta a ponta retirando gargalos e agilizando aprovações e transições.";

  let s4_basic_desc = "Decisões manuais rápidas em quadro de gestão visual física no chão de fábrica.";
  let s4_digital_desc = "Monitoramento estatístico com alarmes digitais parametrizados e acompanhamento de cartas Shewhart de controle (UCL/LCL).";
  let s4_advanced_desc = "Simulação de Pesquisa Operacional e otimização automatizada orientada à inteligência artificial de fábrica digital.";

  if (isSMT) {
    s1_sixSigma_desc = `Variação extrema nos parâmetros de qualidade do processo "${projectName}", placas montadas com defeitos de soldagem ou alto refugo de componentes SMD.`;
    s1_lean_desc = `Acúmulo crônico de materiais e placas intermediárias (WIP) nas esteiras de "${projectName}", travando a transição entre o Pick & Place e os fornos.`;
    s1_pdca_desc = `Ausência de Instruções de Trabalho Padronizadas (SOP) para troca de stencils e falta de controle do 5S operacional em "${projectName}".`;
    s1_lss_desc = `Sincronizar a velocidade de tempo de batida do ciclo SMT com a redução estatística rigorosa (nível Sigma) de falhas físicas e retrabalhos.`;

    s2_noMap_desc = `Não possuímos desenhos de fluxo do processo "${projectName}" e os tempos das máquinas residem puramente no conhecimento tácito da equipe.`;
    s2_staticMap_desc = `Mapeamento estático do layout de "${projectName}" existente, porém desprovido de cronoanálises com desvio padrão (variabilidade).`;
    s2_stochastic_desc = `Postos medidos com médias de ciclo, mas microparadas intermitentes e flutuações de lote em "${projectName}" deslocam o gargalo de forma caótica.`;

    s3_throughput_desc = `Elevar o Throughput de placas processadas por hora (Vazão) no processo "${projectName}" para atender ao plano de demanda sem injetar novas linhas.`;
    s3_yield_desc = `Maximizar o First Pass Yield (FPY) das placas montadas em "${projectName}" acima de 99.2%, mitigando retrabalhos térmicos caros.`;
    s3_leadTime_desc = `Encurtar sensivelmente o tempo de atravessamento de ponta a ponta em "${projectName}", eliminando gargalos e reduzindo tempos de setup de modelo.`;

    s4_basic_desc = `Quadro Kanban físico básico para rastreamento de lotes e checklist de setup manual em "${projectName}".`;
    s4_digital_desc = `Acompanhamento por Cartas de Controle Estatístico Shewhart (UCL/LCL) e controle automatizado de deposição de pasta de solda em "${projectName}".`;
    s4_advanced_desc = `Balanceamento matemático avançado de cabeças SMT por IA, com simulação dinâmica de fluxo de esteiras em tempo real.`;
  } else if (isServices) {
    s1_sixSigma_desc = `Alto percentual de furos de SLA, erros de triagem e informações incorretas no atendimento de "${projectName}", exigindo reaberturas constantes.`;
    s1_lean_desc = `Acúmulo de chamados e solicitações em fila (Backlog), analistas sobrecarregados e lentidão extrema na passagem de bastão em "${projectName}".`;
    s1_pdca_desc = `Inexistência de roteiros ou scripts de atendimento padronizados (SOP), cada atendente resolve as demandas de "${projectName}" do seu próprio jeito.`;
    s1_lss_desc = `Obter um fluxo extremamente rápido de resolução de chamados em "${projectName}" assegurando conformidade de SLA e satisfação impecável.`;

    s2_noMap_desc = `Sem representação formal da jornada dos chamados e dos canais de entrada de "${projectName}" até o encerramento do ticket.`;
    s2_staticMap_desc = `Fluxograma estático desenhado, porém sem parâmetros reais de tempo de ciclo por analista ou desvios estatísticos de variação.`;
    s2_stochastic_desc = `Processo mapeado, mas a imprevisibilidade de complexidade dos chamados de "${projectName}" gera gargalos dinâmicos e filas intermitentes.`;

    s3_throughput_desc = `Acelerar a Vazão de Atendimento de "${projectName}" (chamados encerrados/hora) para responder a picos sazonais sem novas contratações.`;
    s3_yield_desc = `Minimizar o retrabalho em chamados de "${projectName}", focando no índice de resolução em primeiro contato (First Contact Resolution).`;
    s3_leadTime_desc = `Reduzir drasticamente o tempo médio de atendimento (TMA) desde o recebimento até a resposta resolutiva em "${projectName}".`;

    s4_basic_desc = `Quadro Kanban visual clássico com cartões digitais simplificados de backlog e transição de nível em "${projectName}".`;
    s4_digital_desc = `Painel integrado com alertas em tempo real sobre violações de SLA e controle de limites estatísticos superiores (UCL) de execução.`;
    s4_advanced_desc = `Roteamento preditivo automatizado de chamados por IA baseado em complexidade e simulação de teoria de filas estocásticas.`;
  } else if (isFinance) {
    s1_sixSigma_desc = `Divergências recorrentes na conciliação, erros de digitação em faturas de "${projectName}", pagamentos em duplicidade ou faturamentos incorretos.`;
    s1_lean_desc = `Lotes de faturamento retidos aguardando assinaturas, aprovações redundantes de diretores e atraso na consolidação de "${projectName}".`;
    s1_pdca_desc = `Falta de rotina ou checklist para encerramento de lote, cada analista faz o fechamento de "${projectName}" de forma descentralizada e informal.`;
    s1_lss_desc = `Combinar um ciclo de processamento contábil e fiscal acelerado com margem zero de divergência tributária e de compliance.`;

    s2_noMap_desc = `Sem mapeamento ou SIPOC desenhado para as faturas de "${projectName}", operando em regime puramente emergencial e reativo.`;
    s2_staticMap_desc = `Manual de instruções em PDF, mas desprovido de tempos empíricos de execução e desvio padrão para fechamento por analista.`;
    s2_stochastic_desc = `Processo desenhado, mas a instabilidade estocástica no volume de faturas de fornecedores recebidas em "${projectName}" gera picos de estrangulamento.`;

    s3_throughput_desc = `Elevar a vazão de documentos contábeis processados por dia (Throughput) para consolidar o faturamento de "${projectName}".`;
    s3_yield_desc = `Alcançar conciliação contábil com margem de divergência inferior a 0.1% em "${projectName}", reduzindo retrabalhos de auditoria.`;
    s3_leadTime_desc = `Minimizar o Lead Time do ciclo de faturamento e pagamentos em "${projectName}" para otimizar o fluxo de caixa corporativo.`;

    s4_basic_desc = `Lista manual de pendências financeiras e reuniões operacionais semanais de alinhamento em "${projectName}".`;
    s4_digital_desc = `Controle integrado ERP com monitoramento estatístico de prazos e notificações automáticas de risco de desvio em "${projectName}".`;
    s4_advanced_desc = `Machine Learning para reconciliação inteligente automática de faturas de "${projectName}" e simulação de capacidade financeira.`;
  } else if (isLogistics) {
    s1_sixSigma_desc = `Flutuação excessiva nos horários de embarque de "${projectName}", avarias frequentes na cubagem e erros na separação de pedidos (picking).`;
    s1_lean_desc = `Carretas paradas no pátio esperando liberação, excesso de movimentação ociosa e docas congestionadas no fluxo de "${projectName}".`;
    s1_pdca_desc = `Ausência de roteiros formais de expedição e triagem de mercadorias, sem rotina de checklist para a frente de carga em "${projectName}".`;
    s1_lss_desc = `Assegurar despacho logístico rápido de alta densidade no processo "${projectName}", com avaria zero e estrita pontualidade.`;

    s2_noMap_desc = `As etapas de recebimento, triagem, picking e expedição de "${projectName}" não possuem mapeamentos ou SIPOCs documentados.`;
    s2_staticMap_desc = `Layout do armazém mapeado, mas sem cronoanálise de tempos de ciclo e desvios padrão para carregamento em "${projectName}".`;
    s2_stochastic_desc = `Fluxo documentado, mas atrasos aleatórios e tráfego desordenado de transportadoras em "${projectName}" anulam a previsibilidade.`;

    s3_throughput_desc = `Maximizar a quantidade de paletes ou pedidos expedidos por hora (Throughput) no fluxo de "${projectName}" sem expandir a área física.`;
    s3_yield_desc = `Zerar inconformidades de carga, avarias físicas de paletes e erros de separação no picking em "${projectName}".`;
    s3_leadTime_desc = `Reduzir drasticamente o tempo total do ciclo logístico completo (Order-to-Deliver) do fluxo de "${projectName}".`;

    s4_basic_desc = `Quadro Kanban magnético físico na doca de "${projectName}" e uso informal de rádios portáteis para acionamento de operadores.`;
    s4_digital_desc = `Sistema WMS monitorando digitalmente o tempo de trânsito dos veículos e enviando alertas de estouro de limites estatísticos (UCL).`;
    s4_advanced_desc = `Pesquisa operacional com IA calculando alocação dinâmica de frotas e simulação em tempo real de filas nas docas de "${projectName}".`;
  } else if (isTech) {
    s1_sixSigma_desc = `Vazamento frequente de bugs críticos para ambiente de produção, regressões constantes e incidentes de instabilidade pós-release em "${projectName}".`;
    s1_lean_desc = `Múltiplos Pull Requests travados aguardando code review, cards acumulados em progresso (WIP) e constante mudança de foco em "${projectName}".`;
    s1_pdca_desc = `Falta de coerência de design, padrões de codificação tácitos sem documentação de guias e ritos de deploy sem checklist formal em "${projectName}".`;
    s1_lss_desc = `Garantir uma esteira de Continuous Delivery extremamente rápida e contínua em "${projectName}" mantendo estabilidade impecável e código limpo.`;

    s2_noMap_desc = `Não possuímos desenhos do pipeline de CI/CD ou das raias do fluxo de trabalho das histórias de usuário no board de "${projectName}".`;
    s2_staticMap_desc = `Utilizamos quadros ágeis, mas sem análise estatística de dispersão de Cycle Time de entrega de código em "${projectName}".`;
    s2_stochastic_desc = `Temos métricas básicas, mas a instabilidade no tempo dos testes automatizados e aprovações em "${projectName}" cria gargalos imprevisíveis.`;

    s3_throughput_desc = `Elevar a vazão de deploys (Histórias/Sprint) de novas funcionalidades no fluxo de "${projectName}" para acelerar lançamentos.`;
    s3_yield_desc = `Assegurar deploys limpos à primeira passagem, eliminando bugs pré-produção e garantindo conformidade nos testes automáticos de "${projectName}".`;
    s3_leadTime_desc = `Abreviar o cycle time de desenvolvimento de código desde a escrita inicial até a entrega real em ambiente produtivo em "${projectName}".`;

    s4_basic_desc = `Quadro Kanban digital passivo sem limites estritos de trabalho em progresso (WIP) ou alarmes de pendências em "${projectName}".`;
    s4_digital_desc = `Gráficos de Fluxo Cumulativo (CFD) integrados controlando estatisticamente as etapas de code review e testes em "${projectName}".`;
    s4_advanced_desc = `Modelagem probabilística de Monte Carlo integrando dados históricos para prever lead times de entrega de releases em "${projectName}".`;
  } else if (isHealthcare) {
    s1_sixSigma_desc = `Inconsistências em prontuários, triagens clínicas imprecisas e desvios de protocolo nos postos clínicos de "${projectName}".`;
    s1_lean_desc = `Pacientes acumulados em longas filas de espera de acolhimento de "${projectName}", leitos bloqueados ou médicos com ociosidade.`;
    s1_pdca_desc = `Falta de uniformidade no acolhimento de triagem de "${projectName}", rituais de passagem de plantão confusos e falta de protocolo formal.`;
    s1_lss_desc = `Acelerar o pronto-atendimento mantendo segurança clínica impecável e sem erros no diagnóstico ou triagem de "${projectName}".`;

    s2_noMap_desc = `A jornada física do paciente pelo fluxo de "${projectName}" não tem fluxogramas, raias ou SIPOCs documentados.`;
    s2_staticMap_desc = `Jornada desenhada em manual interno, porém desprovida de medições empíricas e desvios estatísticos de triagem em "${projectName}".`;
    s2_stochastic_desc = `Fluxo medido, mas a chegada de emergências flutuantes e randômicas em "${projectName}" satura os postos de atendimento de forma caótica.`;

    s3_throughput_desc = `Elevar o Throughput de acolhimentos humanizados realizados por hora no fluxo de "${projectName}" para mitigar picos de demanda.`;
    s3_yield_desc = `Garantir acerto absoluto de 100% na classificação de risco de triagem Manchester no processo "${projectName}", zerando intercorrências.`;
    s3_leadTime_desc = `Reduzir radicalmente o tempo total de permanência do paciente (Length of Stay) no fluxo de "${projectName}".`;

    s4_basic_desc = `Identificação visual das prioridades Manchester por pulseiras coloridas e gestão informal de fila em "${projectName}".`;
    s4_digital_desc = `Monitores e timers digitais emitindo alertas de estouro de SLA estatístico por prioridade clínica de risco em "${projectName}".`;
    s4_advanced_desc = `Simulação estocástica de teoria das filas em saúde e IA prevendo picos de demanda de pacientes para otimizar escalas de "${projectName}".`;
  } else {
    // Overrides for standard INDUSTRIAL / Default with dynamic projectName replacement
    s1_sixSigma_desc = `Erros humanos recorrentes, retrabalhos constantes e desvios estatísticos de qualidade no processo de "${projectName}".`;
    s1_lean_desc = `Falta de fluidez e acúmulo de trabalho em processo (WIP) e longas esperas em filas operacionais em "${projectName}".`;
    s1_pdca_desc = `Processo de "${projectName}" sem documentação de padrões formais (SOP) e dependente do conhecimento individual.`;
    s1_lss_desc = `Combinação de aceleração drástica do tempo de execução de "${projectName}" com controle estrito de desvios e erros de qualidade.`;

    s2_noMap_desc = `Não possuímos desenhos de fluxo do processo "${projectName}" e as tarefas diárias operam em regime informal.`;
    s2_staticMap_desc = `Mapeamento básico desenhado, mas desprovido de cronoanálises de tempos de ciclo e desvios padrão em "${projectName}".`;
    s2_stochastic_desc = `Postos medidos com médias, mas flutuações e variabilidade em "${projectName}" criam gargalos que mudam imprevisivelmente de lugar.`;

    s3_throughput_desc = `Aumentar o Throughput (Vazão por hora) de "${projectName}" para atender à demanda de mercado sem aumentar custos operacionais.`;
    s3_yield_desc = `Minimizar perdas e elevar a taxa de conformidade (Yield de Primeira Passagem) em "${projectName}" para patamares de excelência.`;
    s3_leadTime_desc = `Reduzir drasticamente o tempo total do ciclo operacional de "${projectName}" eliminando atividades sem valor agregado.`;

    s4_basic_desc = `Acompanhamento manual por quadros físicos de gestão visual e reuniões curtas diárias em "${projectName}".`;
    s4_digital_desc = `Controle integrado digital com limites superiores e inferiores Shewhart de variação de tempos em "${projectName}".`;
    s4_advanced_desc = `Suite de IA otimizando e prevendo a capacidade do processo "${projectName}" com modelagem analítica avançada em tempo real.`;
  }

  return [
    {
      id: 1,
      text: `Qual é o principal desafio ou sintoma de dor mais evidente no processo de "${projectName}" hoje?`,
      category: "Sintoma Base",
      options: [
        {
          label: s1_sixSigma_desc,
          value: "six_sigma",
          points: { lean: 1, sixSigma: 4, pdca: 2, tech: 1 },
          advice: `Foque rigorosamente nas fases Medir e Controlar da metodologia DMAIC para mapear a capabilidade real e criar cartas estatísticas Shewhart (UCL/LCL) nos seus principais ${terms.stepPlural.toLowerCase()}.`
        },
        {
          label: s1_lean_desc,
          value: "lean",
          points: { lean: 4, sixSigma: 1, pdca: 2, tech: 1 },
          advice: `O Kanban e a Teoria das Filas serão as chaves para balancear seus ${terms.stepPlural.toLowerCase()}. Tente reduzir o ${terms.wip} estipulando limites rígidos de cartões.`
        },
        {
          label: s1_pdca_desc,
          value: "pdca",
          points: { lean: 2, sixSigma: 1, pdca: 4, tech: 1 },
          advice: `Iniciar com o PDCA e as práticas Lean de 5S ajudará a estabilizar o ${terms.step.toLowerCase()} básico antes de aplicar algoritmos estatísticos complexos.`
        },
        {
          label: s1_lss_desc,
          value: "lean_six_sigma",
          points: { lean: 4, sixSigma: 4, pdca: 3, tech: 2 },
          advice: `Use o roteiro híbrido Lean Six Sigma completo! Cruze a redução do tempo de ciclo (${terms.cycleTime}) com a eliminação estocástica de defeitos.`
        }
      ]
    },
    {
      id: 2,
      text: `Como está estruturada a documentação e o mapeamento atual das atividades de "${projectName}"?`,
      category: "Mapeamento",
      options: [
        {
          label: s2_noMap_desc,
          value: "no_map",
          points: { lean: 1, sixSigma: 1, pdca: 3, tech: 0 },
          advice: `Sugestão imediata: Complete o Diagrama SIPOC e use o Mapeador de ${terms.stepPlural} para estabelecer um fluxo transparente e compartilhado do processo (As-Is).`
        },
        {
          label: s2_staticMap_desc,
          value: "static_map",
          points: { lean: 2, sixSigma: 3, pdca: 3, tech: 2 },
          advice: `Você precisa medir! Utilize estudos de tempo de ciclo estocásticos nos ${terms.stepPlural.toLowerCase()} para alimentar o simulador com médias e variabilidades realistas.`
        },
        {
          label: s2_stochastic_desc,
          value: "stochastic_bottleneck",
          points: { lean: 3, sixSigma: 4, pdca: 2, tech: 4 },
          advice: `Recomendamos usar análises refinadas de Teoria de Filas (G/G/1) para rastrear o impacto da variabilidade do tempo de chegada no ${terms.bottleneckDesc.toLowerCase()} do sistema.`
        }
      ]
    },
    {
      id: 3,
      text: `Qual é o principal objetivo de negócio estipulado para os próximos meses para "${projectName}"?`,
      category: "Metas",
      options: [
        {
          label: s3_throughput_desc,
          value: "throughput",
          points: { lean: 4, sixSigma: 2, pdca: 2, tech: 3 },
          advice: `A Meta prioritária do Project Charter deve ser Vazão (${terms.throughput}). Adicione recursos paralelos nas etapas gargalo para balancear suas atividades.`
        },
        {
          label: s3_yield_desc,
          value: "yield",
          points: { lean: 2, sixSigma: 4, pdca: 3, tech: 2 },
          advice: "A Meta prioritária sugerida é Minimização de Defeitos (Yield). Implemente Poka-Yokes a prova de erros operacionais nas etapas mais críticas."
        },
        {
          label: s3_leadTime_desc,
          value: "lead_time",
          points: { lean: 4, sixSigma: 3, pdca: 3, tech: 2 },
          advice: `A Meta prioritária recomendada é Lead Time. Aplique técnicas de eliminação de perdas para reduzir tempos de ${terms.setup} e transição.`
        }
      ]
    },
    {
      id: 4,
      text: `Qual é o nível de integridade tecnológica e controle estatístico que sua organização possui para gerenciar os postos de "${projectName}"?`,
      category: "Tecnologia",
      options: [
        {
          label: s4_basic_desc,
          value: "basic_visual",
          points: { lean: 3, sixSigma: 1, pdca: 4, tech: 1 },
          advice: `Trabalhe no Módulo de Quadro Kanban para orquestrar limites de ${terms.wip} de forma imediata e simplificada para a equipe.`
        },
        {
          label: s4_digital_desc,
          value: "spc_digital",
          points: { lean: 2, sixSigma: 4, pdca: 2, tech: 3 },
          advice: "Excelente! Configure Planos de Controle detalhados com regras de reação para desvios estatísticos fora do padrão."
        },
        {
          label: s4_advanced_desc,
          value: "advanced_or",
          points: { lean: 3, sixSigma: 4, pdca: 1, tech: 4 },
          advice: "Use amplamente a nossa Suite de Otimização Cognitiva AI e simulação avançada de teoria das filas em tempo real para obter de imediato dezenas de modelagens ótimas."
        }
      ]
    }
  ];
}

export default function DiagnosticWizard({ 
  steps, 
  setSteps, 
  charter, 
  setCharter, 
  sipoc,
  setSipoc,
  setView,
  businessType = "INDUSTRIAL",
  openTemplatesHub,
  activeProjectName,
  activeProjectObjective,
  projectDetails,
  setProjectDetails,
  setBusinessType
}: DiagnosticWizardProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [activeResultTab, setActiveResultTab] = useState<"DIAGNOSTIC" | "CHARTER" | "SIPOC" | "MAPEADOR_360">("DIAGNOSTIC");

  // Mapeador 360 state variables
  const [selectedMapperStepId, setSelectedMapperStepId] = useState<string>("");
  const [hasAligned, setHasAligned] = useState(false);
  const [evidencePhoto, setEvidencePhoto] = useState<string | null>(null);
  const [evidenceRawData, setEvidenceRawData] = useState<string>("");
  const [evidenceError, setEvidenceError] = useState<string | null>(null);
  const [processingEvidence, setProcessingEvidence] = useState(false);
  const [evidenceFeedbackLog, setEvidenceFeedbackLog] = useState<string[]>([]);
  const [fedDmaicCount, setFedDmaicCount] = useState<number>(0);
  const [mapperNotification, setMapperNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const [isEditingProcess, setIsEditingProcess] = useState(false);
  const [tempName, setTempName] = useState("");
  const [tempObjective, setTempObjective] = useState("");
  const [tempType, setTempType] = useState<BusinessType>("INDUSTRIAL");

  const activeBizType = businessType || "INDUSTRIAL";
  const TERMS = BUSINESS_TERMS[activeBizType] || BUSINESS_TERMS.INDUSTRIAL;

  const { validateAndSync, validationErrors } = useDiagnosticSync({ setCharter });

  React.useEffect(() => {
    if (activeProjectName) setTempName(activeProjectName);
    else if (projectDetails?.processName) setTempName(projectDetails.processName);
    else setTempName(TERMS.title);
  }, [activeProjectName, projectDetails, TERMS.title]);

  React.useEffect(() => {
    if (activeProjectObjective) setTempObjective(activeProjectObjective);
    else if (projectDetails?.expectedImpact) setTempObjective(projectDetails.expectedImpact);
    else setTempObjective("Melhoria de vazão, qualidade e redução de gargalos.");
  }, [activeProjectObjective, projectDetails]);

  React.useEffect(() => {
    if (businessType) setTempType(businessType);
  }, [businessType]);

  const [localCharter, setLocalCharter] = useState<ProjectCharter>({
    title: charter.title || (activeProjectName ? `Iniciativa de Melhoria LSS em ${activeProjectName}` : ""),
    problemStatement: charter.problemStatement || "",
    goal: charter.goal || (activeProjectObjective || ""),
    metric: charter.metric || "cycle_time",
    targetValue: charter.targetValue || 0
  });

  React.useEffect(() => {
    setLocalCharter({
      title: charter.title || (activeProjectName ? `Iniciativa de Melhoria LSS em ${activeProjectName}` : ""),
      problemStatement: charter.problemStatement || "",
      goal: charter.goal || (activeProjectObjective || ""),
      metric: charter.metric || "cycle_time",
      targetValue: charter.targetValue || 0
    });
  }, [charter, activeProjectName, activeProjectObjective]);

  const [localSipoc, setLocalSipoc] = useState<Sipoc>({
    suppliers: sipoc.suppliers || "",
    inputs: sipoc.inputs || "",
    processDescription: sipoc.processDescription || (activeProjectName ? `Fluxo de ponta a ponta do processo de ${activeProjectName}` : ""),
    outputs: sipoc.outputs || "",
    customers: sipoc.customers || ""
  });

  React.useEffect(() => {
    setLocalSipoc({
      suppliers: sipoc.suppliers || "",
      inputs: sipoc.inputs || "",
      processDescription: sipoc.processDescription || (activeProjectName ? `Fluxo de ponta a ponta do processo de ${activeProjectName}` : ""),
      outputs: sipoc.outputs || "",
      customers: sipoc.customers || ""
    });
  }, [sipoc, activeProjectName]);

  const handleSaveProcessDetails = () => {
    // 1. Determine matching template for the selected sector
    let firstTplId = "manufacturing-pcb";
    if (tempType === "SERVICES") firstTplId = "financial-ap";
    else if (tempType === "RETAIL") firstTplId = "retail-checkout";
    else if (tempType === "LOGISTICS") firstTplId = "logistics-fulfillment";
    else if (tempType === "TECHNOLOGY") firstTplId = "saas-software-delivery";
    else if (tempType === "HEALTHCARE") firstTplId = "healthcare-patient-flow";
    else if (tempType === "FINANCE") firstTplId = "accounting-close";
    else if (tempType === "HUMAN_RESOURCES") firstTplId = "hr-recruitment-funnel";

    const template = PROCESS_TEMPLATES.find((t) => t.id === firstTplId) || PROCESS_TEMPLATES[0];

    const originalName = template.name;
    const processName = tempName || originalName;
    const processObjective = tempObjective || "Melhoria contínua de eficiência e capabilidade de processo.";

    // 2. Customize steps based on the template and custom name
    const customizedSteps = template.steps.map((step) => {
      const s = { ...step };
      if (tempName && tempName.toLowerCase() !== originalName.toLowerCase()) {
        s.description = s.description.replace(/placa|fatura|faturamento|cliente|pedido|software|paciente|vaga/gi, tempName);
        s.requiredInputs = s.requiredInputs.map(input => 
          input.replace(/placa|fatura|faturamento|cliente|pedido|software|paciente|vaga/gi, tempName)
        );
        s.stepInstructions = s.stepInstructions.map(instr => 
          instr.replace(/placa|fatura|faturamento|cliente|pedido|software|paciente|vaga/gi, tempName)
        );
      }
      return s;
    });

    // 3. Customize SIPOC
    const customizedSipoc = {
      suppliers: template.sipoc.suppliers,
      inputs: template.sipoc.inputs,
      processDescription: template.sipoc.processDescription,
      outputs: template.sipoc.outputs,
      customers: template.sipoc.customers
    };

    if (tempName && tempName.toLowerCase() !== originalName.toLowerCase()) {
      customizedSipoc.processDescription = `Mapeamento SIPOC do processo de ${processName}: ${template.sipoc.processDescription}`;
      customizedSipoc.suppliers = customizedSipoc.suppliers.replace(/fornecedor de pcb|analistas|médicos|equipe contábil|atendentes/gi, `Fornecedores de ${tempName}`);
      customizedSipoc.inputs = customizedSipoc.inputs.replace(/placas|faturas|pedidos|chamados|clientes|pacientes|vagas/gi, `Dados e insumos de ${tempName}`);
      customizedSipoc.outputs = customizedSipoc.outputs.replace(/placas soldadas|chamado solucionado|compras faturadas|veículos faturados|recursos de software|paciente estabilizado|balanço faturado/gi, `Resultados de ${tempName} concluídos`);
      customizedSipoc.customers = customizedSipoc.customers.replace(/clientes licenciados|consumidores|frotistas|diretoria/gi, `Partes interessadas de ${tempName}`);
    }

    // 4. Customize Project Charter
    const customizedCharter = {
      title: `Iniciativa de Melhoria LSS em ${processName}`,
      problemStatement: template.charter.problemStatement.replace(/linha de montagem|fluxo pcb|processo de contas a pagar|fechamento contábil|checkout varejo|expedição logística|entrega de software|fluxo de paciente|funil de recrutamento/gi, processName),
      goal: processObjective,
      metric: template.charter.metric,
      targetValue: template.charter.targetValue
    };

    // 5. Update states
    if (setProjectDetails && projectDetails) {
      setProjectDetails({
        ...projectDetails,
        processName: processName,
        expectedImpact: processObjective,
        lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR")
      });
    }

    if (setSteps) {
      setSteps(customizedSteps);
    }
    if (setSipoc) {
      setSipoc(customizedSipoc);
    }
    if (setCharter) {
      setCharter(customizedCharter);
    }

    setLocalCharter(customizedCharter);
    setLocalSipoc(customizedSipoc);

    if (setBusinessType) {
      setBusinessType(tempType);
    }

    setIsEditingProcess(false);
  };

  const [isAiGeneratingSipoc, setIsAiGeneratingSipoc] = useState(false);
  const [aiSipocSuccess, setAiSipocSuccess] = useState(false);
  const [charterSuccess, setCharterSuccess] = useState(false);

  const QUESTIONS = getDynamicQuestions(activeBizType, tempName);

  const currentQuestion = QUESTIONS[currentQuestionIndex];

  const handleSelectOption = (optionIndex: number) => {
    const updatedAnswers = [...answers];
    updatedAnswers[currentQuestionIndex] = optionIndex;
    setAnswers(updatedAnswers);

    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowResults(true);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleResetDiagnostic = () => {
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setShowResults(false);
    setHasStarted(false);
  };

  // Calculate scores and recommended methodology
  const calculateAnalysis = () => {
    let leanScore = 0;
    let sixSigmaScore = 0;
    let pdcaScore = 0;
    let techScore = 0;

    answers.forEach((optionIdx, qIdx) => {
      const q = QUESTIONS[qIdx];
      const opt = q.options[optionIdx];
      if (opt) {
        leanScore += opt.points.lean;
        sixSigmaScore += opt.points.sixSigma;
        pdcaScore += opt.points.pdca;
        techScore += opt.points.tech;
      }
    });

    const total = leanScore + sixSigmaScore + pdcaScore;
    const leanPct = Math.round((leanScore / 15) * 100);
    const sixSigmaPct = Math.round((sixSigmaScore / 13) * 100);
    const pdcaPct = Math.round((pdcaScore / 11) * 100);
    const techLevel = Math.round((techScore / 10) * 100);

    let recommendedMethodology = "Lean Six Sigma";
    let description = "Uma combinação sinérgica focada em eliminação rápida de perdas e rigorosa estabilização estatística de qualidade.";
    let iconColor = "text-[#C49746]";

    if (leanScore > sixSigmaScore && leanScore > pdcaScore) {
      recommendedMethodology = "Lean Manufacturing (Manufatura Enxuta)";
      description = "Seu foco primordial está na eliminação de tempo morto, balanceamento operacional dos postos e organização tátil do fluxo de valor.";
      iconColor = "text-amber-600";
    } else if (sixSigmaScore > leanScore && sixSigmaScore > pdcaScore) {
      recommendedMethodology = "Six Sigma Clássico (DMAIC)";
      description = "Prioriza a estabilização estatística total, diminuição drástica do desvio padrão e garantia do nível de qualidade industrial.";
      iconColor = "text-indigo-600";
    } else if (pdcaScore > leanScore && pdcaScore > sixSigmaScore) {
      recommendedMethodology = "Padronização PDCA & Práticas 5S";
      description = "Ideal para estabelecer o controle de rotina inicial, definir termos operacionais padrões e consolidar a governança de processos.";
      iconColor = "text-emerald-600";
    }

    // Capture dynamic advices based on selections
    const activeAdvices: string[] = [];
    answers.forEach((optIdx, qIdx) => {
      const opt = QUESTIONS[qIdx].options[optIdx];
      if (opt) activeAdvices.push(opt.advice);
    });

    return {
      leanPct: Math.min(100, leanPct),
      sixSigmaPct: Math.min(100, sixSigmaPct),
      pdcaPct: Math.min(100, pdcaPct),
      techLevel: Math.min(100, techLevel),
      recommendedMethodology,
      description,
      iconColor,
      activeAdvices
    };
  };

  const analysis = calculateAnalysis();

  const SIPOC_PRESETS: Record<BusinessType, Sipoc> = {
    INDUSTRIAL: {
      suppliers: "Almoxarifado central de matérias-primas, Fornecedores terceirizados de PCBs e componentes elétricos, Matrizaria de injeção plástica",
      inputs: "Flocos de polímero, Placas de fibra montadas, Microcontroladores calibrados, Cabos flat, parafusos, fita plástica, embalagens",
      processDescription: "Abastecimento físico -> Configuração térmica do forno (Refluxo SMT) -> Inspeção Automatizada (AOI) -> Integração Mecânica -> Teste de Gabarito de Estresse Físico",
      outputs: "Equipamentos eletrônicos montados com selo de aprovação da qualidade, logs de auditoria de testes funcionais, carcaças rejeitadas para refugo",
      customers: "Distribuidoras regionais, Clientes corporativos B2B globais, canais diretos de e-commerce e frotistas homologados",
    },
    SERVICES: {
      suppliers: "Equipe de triagem omnicanal, Portal CRM integrador de leads externos, Central telefônica e chats automatizados",
      inputs: "Chamados de suporte abertos, tíquetes estruturados de TI, solicitações de migração de dados de clientes, formulários de adesência operacionais",
      processDescription: "Filtro inicial automatizado -> Análise de gravidade nível 1 -> Encaminhamento automático ao especialista nível 2 -> Laboratório de resolução -> Validação de sucesso com o cliente",
      outputs: "Chamado solucionado com SLA cumprido, Nota de satisfação (CSAT), Artigo de correção publicado no banco de dados interno",
      customers: "Clientes licenciados ativos SaaS, equipe interna de atendimento avançado, diretoria de operações digitais",
    },
    RETAIL: {
      suppliers: "Centro de Distribuição Integrado (CD), Fornecedores de bens de consumo de rotatividade rápida, Gestores de reposição física",
      inputs: "Pedidos gerados via aplicativo, Notas fiscais emitidas, Lista de produtos em estoque secundário, dados de preço de gôndola",
      processDescription: "Abertura diária da estação (caixa) -> Leitura óptica das compras -> Verificação física dos lacres -> Recebimento financeiro automático -> Emissão de comprovante fiscal e empacotamento",
      outputs: "Compras faturadas sacoladas, atualizações instantâneas de SKU e estoque, Relatório diário de conciliação de meio de pagamento",
      customers: "Consumidores físicos locais finais, equipe corporativa de auditoria fiscal, prevenção de perdas e contabilidade",
    },
    LOGISTICS: {
      suppliers: "Parceiros em barcadores, Gestores de agendamento de pátio e docas, Fabricantes terceirizados de paletes estruturados",
      inputs: "Notas fiscais de remessa de mercadoria, ordens de coleta (Picking orders), caminhões frotistas alinhados, checklists obrigatórios de embarque",
      processDescription: "Triagem física de recebimento -> Processamento e separação avançada (Picking) -> Paletização e estiramento automático -> Armazenamento em Staging de expedição -> Carregamento de caixas logísticas",
      outputs: "Veículos pesados faturados e lacrados para saída, Manifestos de transporte assinados, relatórios de anomalias de pátio",
      customers: "Depósitos e centros de distribuição regionais de destino, varejistas integrados de grande porte, clientes e-commerce",
    },
    TECHNOLOGY: {
      suppliers: "Gerentes de Produto (Product Managers), Equipes de UX/UI, Provedor de Cloud Serverless (GCP/AWS)",
      inputs: "Histórias de usuário priorizadas (Jira), Mockups de telas aprovados, Repositórios de código, Pipelines de Integração Contínua (CI)",
      processDescription: "Refinamento das tarefas -> Escrita de testes e código -> Revisão estrita de Pares (Pull Request) -> Automação de builds no pipeline -> Deploy estocástico em produção controlada",
      outputs: "Recursos de software e APIs disponíveis, logs estáveis de sistema em produção, métricas de testes unitários SonarQube",
      customers: "Usuários finais ativos do marketplace, Engenheiros especialistas em Suporte ao Cliente, Product Stakeholders",
    },
    HEALTHCARE: {
      suppliers: "Distribuidoras farmacêuticas credenciadas, Recepção e central de acolhimento emergencial, Laboratório de patologia e exames",
      inputs: "Ficha simplificada de triagem ambulatorial, receitas pendentes, Prontuário médico digital de histórico de crises, frascos de ensaio",
      processDescription: "Acolhimento humanitário básico -> Classificação Clínica de Manchester -> Consulta clínica investigativa -> Exames de triagem -> Aplicação de medicamentos endovenosos -> Alta médica assistida",
      outputs: "Paciente estatisticamente estabilizado, termo de consentimento livre esclarecido preenchido, prontuários encaminhados ao faturamento",
      customers: "Pacientes atendidos e familiares diretos, operadoras credenciadas de saúde pública ou privada, auditoria hospitalar",
    },
    FINANCE: {
      suppliers: "Equipes contábeis auxiliares, Sistemas de ERP corporativos, Emissores de notas fiscais terceirizados, Bancos parceiros",
      inputs: "Notas fiscais recebidas, Extratos de conciliação bancária, Relatórios de reembolso de despesas, Guias de recolhimento tributário",
      processDescription: "Recebimento e triagem de faturas -> Validação de conformidade fiscal -> Lançamento no ERP -> Fluxo de aprovação gerencial -> Agendamento e execução de pagamento",
      outputs: "Balanço faturado liquidado, Lançamentos em conta patrimonial auditáveis, Comprovantes de transações bancárias homologados",
      customers: "Diretoria e acionistas corporativos, Auditores externos, Fornecedores e credores parceiros",
    },
    HUMAN_RESOURCES: {
      suppliers: "Agências recrutadoras terceirizadas, Portais e plataformas de cadastro (LinkedIn, ATS), Gestores de áreas solicitantes",
      inputs: "Requisição de contratação formalizada (Briefing), Banco de talentos e currículos filtrados, Escopos e descrições das vagas de trabalho",
      processDescription: "Atração e recebimento de currículos -> Triagem e mapeamento técnico -> Dinâmica estruturada de fit cultural -> Avaliação prática de competências -> Negociação de proposta e oferta",
      outputs: "Candidato aprovado contratado, Contrato de trabalho integrado formalizado, Relatório estatístico de admissão consolidada",
      customers: "Novos colaboradores integrados ao time, Equipes internas solicitantes em fase de expansão, Diretoria de talentos e cultura",
    }
  };

  const handleFillCharterFromAnswers = () => {
    const sanitizedAnswers = [...answers];
    while (sanitizedAnswers.length < 4) {
      sanitizedAnswers.push(0);
    }

    const syncResult = validateAndSync({
      answers: sanitizedAnswers,
      businessType: activeBizType,
      processName: tempName || TERMS.title,
      processObjective: tempObjective || undefined
    });

    if (syncResult.success && syncResult.data) {
      setLocalCharter(syncResult.data);
      setCharterSuccess(true);
      setActiveResultTab("CHARTER");
    } else {
      console.warn("Zod validation or sync failed for Diagnostic 360", syncResult.errors);
      
      // Fallback in case of unexpected validation error to ensure standard LSS flow continuity
      const selectedMainConcernIdx = answers[0] ?? 0;
      const selectedGoalIdx = answers[2] ?? 0;
      const pName = tempName || TERMS.title;

      let prefilledTitle = `Iniciativa de Melhoria LSS em ${pName}`;
      let prefilledProblem = `Instabilidade estatística no fluxo de ${pName}, provocando níveis altos de WIP e gargalos randômicos de vazão no ${TERMS.bottleneckDesc.toLowerCase()} principal.`;
      let prefilledGoal = tempObjective || `Garantir o fluxo contínuo balanceado de ${pName}, estabilizando as taxas médias e reduzindo perdas e tempos de espera.`;
      let metricVal: "cycle_time" | "defect_rate" | "throughput" = "cycle_time";
      let targetVal = 12.0;

      if (selectedMainConcernIdx === 0) {
        prefilledTitle = `Projeto DMAIC - Redução de Variabilidade em ${pName}`;
        prefilledProblem = `Variação de qualidade excessiva e retrabalho recorrente nos postos de trabalho de ${pName}, reduzindo o rendimento de primeira passagem e aumentando os defeitos estatísticos.`;
      } else if (selectedMainConcernIdx === 1) {
        prefilledTitle = `Iniciativa Lean - Otimização de ${TERMS.wip.split(" ")[0]} e Fluxo Contínuo de ${pName}`;
        prefilledProblem = `Gargalos persistentes acumulando ${TERMS.wip.toLowerCase().split(" (")[0]} em nível crítico no fluxo de ${pName}, resultando em tempos de ciclo elevados e ociosidade.`;
      }

      if (selectedGoalIdx === 0) {
        metricVal = "throughput";
        prefilledGoal = tempObjective || `Elevar a vazão média do sistema (${TERMS.throughput}) em pelo menos 20% com o balanceamento ótimo de postos de trabalho em "${pName}".`;
        targetVal = activeBizType === "INDUSTRIAL" ? 35.0 : activeBizType === "TECHNOLOGY" ? 15.0 : 25.0;
      } else if (selectedGoalIdx === 1) {
        metricVal = "defect_rate";
        prefilledGoal = tempObjective || `Maximizar o rendimento operacional de "${pName}", reduzindo a taxa de não-conformidade física dos postos e visando yield superior a 98.5%.`;
        targetVal = 0.015;
      } else if (selectedGoalIdx === 2) {
        metricVal = "cycle_time";
        prefilledGoal = tempObjective || `Diminuir drasticamente o lead time de ponta a ponta (${TERMS.cycleTime}) do processo de "${pName}" removendo tempos ociosos.`;
        targetVal = 8.5;
      }

      const fallbackCharter = {
        title: prefilledTitle,
        problemStatement: prefilledProblem,
        goal: prefilledGoal,
        metric: metricVal,
        targetValue: targetVal
      };

      setLocalCharter(fallbackCharter);
      setCharter(fallbackCharter);
      setCharterSuccess(true);
      setActiveResultTab("CHARTER");
    }
  };

  const handleTriggerAiSipoc = () => {
    setIsAiGeneratingSipoc(true);
    setAiSipocSuccess(false);

    setTimeout(() => {
      const preset = SIPOC_PRESETS[activeBizType] || SIPOC_PRESETS.INDUSTRIAL;
      setLocalSipoc({ ...preset });
      setSipoc({ ...preset });
      setIsAiGeneratingSipoc(false);
      setAiSipocSuccess(true);
    }, 1200);
  };

  const handleFinalizeSetup = () => {
    setCharter(localCharter);
    setSipoc(localSipoc);
    setView("MAP");
  };

  const renderResults = () => {
    return (
      <div className="space-y-6 animate-fade-in text-left">
        
        {/* Tabs Navigation */}
        <div className="flex border-b border-gray-200 mb-6 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveResultTab("DIAGNOSTIC")}
            className={`py-3 px-4 border-b-2 font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
              activeResultTab === "DIAGNOSTIC"
                ? "border-[#C49746] text-[#C49746]"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            📊 1. Desempenho &amp; Laudo
          </button>
          <button
            type="button"
            onClick={() => {
              if (!charterSuccess) {
                handleFillCharterFromAnswers();
              }
              setActiveResultTab("CHARTER");
            }}
            className={`py-3 px-4 border-b-2 font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
              activeResultTab === "CHARTER"
                ? "border-[#C49746] text-[#C49746]"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            📋 2. Termo de Abertura (Charter)
          </button>
          <button
            type="button"
            onClick={() => {
              if (!charterSuccess) {
                handleFillCharterFromAnswers();
              }
              setActiveResultTab("SIPOC");
            }}
            className={`py-3 px-4 border-b-2 font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
              activeResultTab === "SIPOC"
                ? "border-[#C49746] text-[#C49746]"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            📦 3. Diagrama SIPOC
          </button>
          <button
            type="button"
            onClick={() => {
              // Pre-select the first step in steps if none selected
              if (!selectedMapperStepId && steps && steps.length > 0) {
                setSelectedMapperStepId(steps[0].id);
              }
              setActiveResultTab("MAPEADOR_360");
            }}
            className={`py-3 px-4 border-b-2 font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
              activeResultTab === "MAPEADOR_360"
                ? "border-[#C49746] text-[#C49746]"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            📸 4. Mapeador 360° (Evidências &amp; DMAIC)
          </button>
        </div>

        {/* TAB 1: DIAGNOSTIC LAUDO */}
        {activeResultTab === "DIAGNOSTIC" && (
          <div className="space-y-8 animate-fade-in">
            {/* Complete banner details */}
            <div className="bg-emerald-50/50 p-5 border-l-4 border-emerald-500 rounded-xs flex items-start gap-4">
              <div className="bg-emerald-500 text-white rounded-full p-1.5 shrink-0">
                <CheckCircle size={18} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-emerald-950 uppercase tracking-wide">Diagnóstico Concluído com Alta Consistência</h4>
                <p className="text-[11.5px] text-emerald-800 leading-relaxed mt-1">
                  Com base em suas respostas estocásticas, nosso motor analítico ponderou a dispersão de variáveis do seu fluxo e projetou o roteiro ideal de suporte técnico.
                </p>
              </div>
            </div>

            {/* Calculated recommendations detail */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-2">
              {/* Visual Radar Pct parameters */}
              <div className="space-y-4">
                <h5 className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Métricas de Maturidade Calculadas</h5>
                
                <div className="space-y-3.5">
                  {/* Lean Indicator */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Foco em Fluxo &amp; Velocidade (Lean)</span>
                      <span className="font-mono font-bold text-amber-700">{analysis.leanPct}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full" style={{ width: `${analysis.leanPct}%` }}></div>
                    </div>
                  </div>

                  {/* Six Sigma Indicator */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Necessidade Estatística (Six Sigma)</span>
                      <span className="font-mono font-bold text-indigo-700">{analysis.sixSigmaPct}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-indigo-600 h-full" style={{ width: `${analysis.sixSigmaPct}%` }}></div>
                    </div>
                  </div>

                  {/* PDCA Indicator */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Padrão Operacional &amp; Rotina (PDCA)</span>
                      <span className="font-mono font-bold text-emerald-700">{analysis.pdcaPct}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-600 h-full" style={{ width: `${analysis.pdcaPct}%` }}></div>
                    </div>
                  </div>

                  {/* Tech simulation requirement index */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-sans">
                      <span className="font-bold text-gray-750">Fração Tecnológica &amp; Apoio Especializado</span>
                      <span className="font-mono font-bold text-purple-700">{analysis.techLevel}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-600 h-full" style={{ width: `${analysis.techLevel}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Highly structured recommended framework layout */}
              <div className="border border-[#1A1A1A]/10 p-5 bg-[#FAF8F5] relative overflow-hidden flex flex-col justify-between">
                <div className="absolute top-0 right-0 p-1.5 bg-[#C49746]/10 text-[#C49746] text-[8px] font-bold uppercase tracking-widest leading-none">
                  Método Altamente Sinergético
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Sparkles size={16} className="text-[#C49746]" />
                    <h4 className="text-base font-serif font-bold text-[#1A1A1A] leading-tight">
                      {analysis.recommendedMethodology}
                    </h4>
                  </div>
                  <p className="text-[11px] text-gray-600 leading-relaxed">
                    {analysis.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-200 mt-4 text-[10.5px] leading-relaxed text-[#1A1A1A]/80">
                  <strong>Sugestão Prática:</strong> Ao habilitar essa decisão, a ferramenta herda este setup calculando desvios correspondentes nas simulações Monte Carlo dinâmicas.
                </div>
              </div>
            </div>

            {/* DOCUMENTAÇÃO DE DIAGNÓSTICO ESTRUTURADO PARA LEIGOS */}
            <div className="border border-[#1A1A1A] bg-[#FAF9F6] p-5 space-y-6 mt-6">
              <div className="border-b border-gray-300 pb-2.5">
                <span className="text-[8px] font-mono font-bold bg-[#1A1A1A] text-white px-2 py-0.5 uppercase tracking-widest">
                  Relatório Executivo Certificado LSS
                </span>
                <h4 className="text-xl font-serif text-gray-955 mt-1 leading-tight">
                  Laudo Técnico de Maturidade &amp; Gargalos Operacionais
                </h4>
                <p className="text-[10px] text-gray-500 font-sans mt-0.5">
                  Entenda de forma descomplicada as dores do seu fluxo de valor e veja a rota científica para mitigá-las.
                </p>
              </div>

              {/* 1. ESTATÍSTICAS E ANÁLISE QUANTITATIVA PARA LEIGOS */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-white p-3 border border-gray-250 flex flex-col justify-between">
                  <div>
                    <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block">Indicador de Qualidade</span>
                    <strong className="text-lg font-serif text-[#C49746] block mt-1">96.4% Rolled Yield</strong>
                  </div>
                  <p className="text-[9px] text-gray-550 leading-tight mt-1 font-sans">
                    Significa que de cada 100 {TERMS.units.toLowerCase().split(" / ")[1] || "demandas"} iniciadas, ~96 chegam ao fim sem retrabalho primário.
                  </p>
                </div>

                <div className="bg-white p-3 border border-gray-250 flex flex-col justify-between">
                  <div>
                    <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block">Volume de Desperdício</span>
                    <strong className="text-lg font-serif text-amber-700 block mt-1">3.4 Sigma Global</strong>
                  </div>
                  <p className="text-[9px] text-gray-550 leading-tight mt-1 font-sans">
                    Representa a taxa de falha estocástica atual. Distante do nível classe mundial de zero defeitos.
                  </p>
                </div>

                <div className="bg-white p-3 border border-gray-250 flex flex-col justify-between">
                  <div>
                    <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block">Fator de Vazão Estimada</span>
                    <strong className="text-lg font-serif text-indigo-700 block mt-1">~12.5 {TERMS.units.split(" / ")[0] || "un"} / h</strong>
                  </div>
                  <p className="text-[9px] text-gray-550 leading-tight mt-1 font-sans">
                    Sua velocidade máxima total hoje está limitada pelo tempo do seu {TERMS.step.toLowerCase()} gargalo principal.
                  </p>
                </div>

                <div className="bg-white p-3 border border-gray-250 flex flex-col justify-between">
                  <div>
                    <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block">Oportunidade Financeira</span>
                    <strong className="text-lg font-serif text-emerald-700 block mt-1">Até 32% Ganho</strong>
                  </div>
                  <p className="text-[9px] text-gray-550 leading-tight mt-1 font-sans">
                    Ganho estimado de custos ocultos recuperados através do balanceamento e remoção do tempo de {TERMS.setup.toLowerCase()}.
                  </p>
                </div>
              </div>

              {/* 2. IMAGENS/DIAGRAMAS - FLUXO AS-IS VS TO-BE */}
              <div className="space-y-2.5">
                <span className="text-[10px] uppercase font-bold text-gray-700 tracking-wider block font-mono">
                  🎨 Visão Ilustrada do Fluxo: As-Is (Com Gargalo) vs To-Be (Balanceado)
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* AS IS */}
                  <div className="bg-white p-3.5 border border-red-200 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[9.5px] font-bold text-red-650 uppercase font-mono">
                        ❌ Fluxo Atual (Desequilibrado)
                      </span>
                      <span className="text-[8.5px] text-red-650 bg-red-50 px-1.5 py-0.2 rounded font-bold">Acúmulo Crítico</span>
                    </div>
                    
                    {/* Diagram representation SVG */}
                    <svg viewBox="0 0 320 100" className="w-full h-24 bg-red-50/15 border border-dashed border-red-105">
                      {/* Box 1: Entrada */}
                      <rect x="10" y="30" width="55" height="40" rx="3" fill="#EAEAEA" stroke="#999" strokeWidth="1" />
                      <text x="37" y="55" fill="#333" fontSize="9" textAnchor="middle" fontFamily="sans-serif">Entrada</text>
                      
                      {/* Connector 1 */}
                      <line x1="65" y1="50" x2="100" y2="50" stroke="#999" strokeWidth="1" strokeDasharray="3,3" />
                      <polygon points="100,50 95,47 95,53" fill="#999" />
                      
                      {/* Box 2: Posto Gargalo */}
                      <rect x="100" y="20" width="75" height="60" rx="4" fill="#FEE2E2" stroke="#EF4444" strokeWidth="1.5" />
                      <text x="137" y="45" fill="#991B1B" fontSize="9" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">{TERMS.step} Solo</text>
                      <text x="137" y="58" fill="#EF4444" fontSize="8" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">GARGALO (100%)</text>
                      <text x="137" y="70" fill="#991B1B" fontSize="8" textAnchor="middle" fontFamily="sans-serif">Fila / Espera</text>
                      
                      {/* Connector 2 */}
                      <line x1="175" y1="50" x2="230" y2="50" stroke="#999" strokeWidth="1" />
                      <polygon points="230,50 225,47 225,53" fill="#999" />
                      
                      {/* Box 3: Saída */}
                      <rect x="230" y="30" width="80" height="40" rx="3" fill="#EAEAEA" stroke="#999" strokeWidth="1" />
                      <text x="270" y="55" fill="#333" fontSize="9" textAnchor="middle" fontFamily="sans-serif">Fim do Fluxo</text>
                      
                      {/* WIP Inventory Indicator */}
                      <circle cx="85" cy="35" r="7" fill="#EF4444" />
                      <text x="85" y="38" fill="white" fontSize="8" fontWeight="bold" textAnchor="middle">8</text>
                      <text x="85" y="23" fill="#EF4444" fontSize="7" fontWeight="bold" textAnchor="middle">{TERMS.wip.split(" ")[0]} Alto</text>
                    </svg>
                    
                    <p className="text-[9.5px] text-gray-550 leading-tight">
                      <strong>Explicação do Desenho:</strong> O {TERMS.step.toLowerCase()} intermediário solo processa devagar demais. O {TERMS.wip.toLowerCase().split(" (")[0]} acumula na entrada dele (representado pelo indicador vermelho), limitando severamente a velocidade de vazão final.
                    </p>
                  </div>

                  {/* TO BE */}
                  <div className="bg-white p-3.5 border border-emerald-200 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[9.5px] font-bold text-emerald-700 uppercase font-mono">
                        🌱 Fluxo Balanceado (Sugerido)
                      </span>
                      <span className="text-[8.5px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold font-mono">Contínuo</span>
                    </div>
                    
                    {/* Diagram representation SVG for Balanced Flow */}
                    <svg viewBox="0 0 320 100" className="w-full h-24 bg-emerald-50/15 border border-dashed border-emerald-105">
                      {/* Box 1: Entrada */}
                      <rect x="10" y="30" width="55" height="40" rx="3" fill="#EAEAEA" stroke="#999" strokeWidth="1" />
                      <text x="37" y="55" fill="#333" fontSize="9" textAnchor="middle" fontFamily="sans-serif">Entrada</text>
                      
                      {/* Split Connector */}
                      <path d="M 65,50 L 90,30 L 105,30" fill="none" stroke="#10B981" strokeWidth="1" />
                      <polygon points="105,30 100,27 100,33" fill="#10B981" />
                      
                      <path d="M 65,50 L 90,70 L 105,70" fill="none" stroke="#10B981" strokeWidth="1" />
                      <polygon points="105,70 100,67 100,73" fill="#10B981" />
                      
                      {/* Box 2a: Operador Paralelo 1 */}
                      <rect x="105" y="10" width="85" height="35" rx="3" fill="#D1FAE5" stroke="#10B981" strokeWidth="1" />
                      <text x="147" y="25" fill="#065F46" fontSize="8.5" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">Equipe {TERMS.step} 1</text>
                      <text x="147" y="38" fill="#059669" fontSize="7.5" textAnchor="middle" fontFamily="sans-serif">Uti: 48% (Estável)</text>
                      
                      {/* Box 2b: Operador Paralelo 2 */}
                      <rect x="105" y="55" width="85" height="35" rx="3" fill="#D1FAE5" stroke="#10B981" strokeWidth="1" />
                      <text x="147" y="70" fill="#065F46" fontSize="8.5" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">Equipe {TERMS.step} 2</text>
                      <text x="147" y="83" fill="#059669" fontSize="7.5" textAnchor="middle" fontFamily="sans-serif">Uti: 48% (Estável)</text>
                      
                      {/* Merge Connectors */}
                      <path d="M 190,30 L 210,30 L 230,50" fill="none" stroke="#10B981" strokeWidth="1" />
                      <polygon points="230,50 226,45 224,51" fill="#10B981" />
                      
                      <path d="M 190,70 L 210,70 L 230,50" fill="none" stroke="#10B981" strokeWidth="1" />
                      
                      {/* Box 3: Saída */}
                      <rect x="230" y="30" width="80" height="40" rx="3" fill="#D1FAE5" stroke="#047857" strokeWidth="1.2" />
                      <text x="270" y="55" fill="#065F46" fontSize="9" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">Vazão Total</text>
                      
                      {/* WIP Indicator - balanced */}
                      <circle cx="85" cy="50" r="5" fill="#10B981" />
                      <text x="85" y="53" fill="white" fontSize="7" fontWeight="bold" textAnchor="middle">1</text>
                    </svg>
                    
                    <p className="text-[9.5px] text-gray-550 leading-tight">
                      <strong>Explicação do Desenho:</strong> Através do balanceamento do {TERMS.step.toLowerCase()} gargalo pelo modelo DMAIC/LSS, dividimos a carga de trabalho. O acúmulo de {TERMS.wip.toLowerCase().split(" (")[0]} sobressalente murcha e o {TERMS.cycleTime.toLowerCase()} geral cai substancialmente.
                    </p>
                  </div>
                </div>
              </div>

              {/* 3. PLANO DE MELHORIA KAIZEN SEMANAL - ORIENTAÇÕES PRÁTICAS */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold text-gray-700 tracking-wider block font-mono">
                  📋 Checklist de Implantação Kaizen (Roteiro dos Primeiros Passos)
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10.5px]">
                  <div className="bg-white p-2.5 border border-gray-200 rounded-none flex items-start gap-2">
                    <input type="checkbox" defaultChecked className="mt-1 h-3.5 w-3.5 cursor-not-allowed" disabled />
                    <div>
                      <strong className="text-gray-955 font-sans block font-semibold">Passo 1: Concluir esse Diagnóstico Inicial (Completo)</strong>
                      <span className="text-gray-500 text-[9.5px]">Identificar as perdas, dimensionar a prioridade tática e preparar o Termo de Abertura.</span>
                    </div>
                  </div>

                  <div className="bg-white p-2.5 border border-gray-200 rounded-none flex items-start gap-2">
                    <input type="checkbox" className="mt-1 h-3.5 w-3.5" />
                    <div>
                      <strong className="text-gray-955 font-sans block font-semibold">Passo 2: Mapear {TERMS.stepPlural} no Fluxograma "As-Is"</strong>
                      <span className="text-gray-500 text-[9.5px]">Desenhar o fluxo de encadeamento dos {TERMS.stepPlural.toLowerCase()} para carregar parâmetros estatísticos.</span>
                    </div>
                  </div>

                  <div className="bg-white p-2.5 border border-gray-200 rounded-none flex items-start gap-2">
                    <input type="checkbox" className="mt-1 h-3.5 w-3.5" />
                    <div>
                      <strong className="text-gray-955 font-sans block font-semibold">Passo 3: Rodar Simulação Monte Carlo Estocástica</strong>
                      <span className="text-gray-500 text-[9.5px]">Analisar os gargalos dinâmicos onde a variabilidade faz sua esteira acumular {TERMS.wip.toLowerCase().split(" (")[0]}.</span>
                    </div>
                  </div>

                  <div className="bg-white p-2.5 border border-gray-250 rounded-none flex items-start gap-2">
                    <input type="checkbox" className="mt-1 h-3.5 w-3.5" />
                    <div>
                      <strong className="text-gray-955 font-sans block font-semibold">Passo 4: Sincronizar Marcos de Auditoria no Google Calendar</strong>
                      <span className="text-gray-500 text-[9.5px]">Agendar revisões e reuniões de controle diretamente no painel gerencial.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. GUIA DE ORIENTAÇÃO DA TELA (O QUE, COMO , PORQUE FAZER) */}
              <div className="border-t border-gray-350 pt-3 grid grid-cols-1 md:grid-cols-3 gap-4 text-[10.5px] leading-relaxed text-gray-700">
                <div className="space-y-1 bg-white p-3 border border-gray-200">
                  <span className="text-[9px] uppercase font-bold text-[#C49746] block font-mono">🔍 O que fazer?</span>
                  <p className="font-bold text-gray-955 leading-tight">Análise Executiva Interativa de Maturidade.</p>
                  <p className="text-gray-500 text-[9.5px] leading-tight">Avalie o status atual, revise o radar de metodologia ideal calculada e avance para o Termo de Abertura.</p>
                </div>
                <div className="space-y-1 bg-white p-3 border border-gray-200">
                  <span className="text-[9px] uppercase font-bold text-amber-700 block font-mono">🛠️ Como fazer?</span>
                  <p className="font-bold text-gray-955 leading-tight">Configurar parâmetros descritivos.</p>
                  <p className="text-gray-500 text-[9.5px] leading-tight">Clique no botão "Preparar Project Charter" para herdar as configurações sugeridas de maneira estruturada.</p>
                </div>
                <div className="space-y-1 bg-white p-3 border border-gray-200">
                  <span className="text-[9px] uppercase font-bold text-emerald-700 block font-mono">💡 Por que fazer?</span>
                  <p className="font-bold text-gray-955 leading-tight">Assegurar o escopo acordado de LSS.</p>
                  <p className="text-gray-500 text-[9.5px] leading-tight font-sans">Um projeto sem um Termo de Abertura robusto falha por "scope creep" (aumento de escopo tácito).</p>
                </div>
              </div>

              {/* ADVICES ACCORDING TO SELECTIONS */}
              <div className="space-y-2 pb-1 border-t border-gray-200 pt-3">
                <h5 className="text-[9.5px] font-bold uppercase tracking-widest text-[#1A1A1A]/50">Recomendações Auxiliares do Copiloto AI</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {analysis.activeAdvices.slice(0, 4).map((adv, idx) => (
                    <div key={idx} className="bg-white p-2.5 border border-gray-200 text-[10px] leading-relaxed text-[#1A1A1A]/70 flex gap-2">
                      <Info size={12} className="text-blue-500 shrink-0 mt-0.5" />
                      <span>{adv}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* BOTTOM NAV BUTTON */}
            <div className="flex justify-end pt-4 mt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={handleFillCharterFromAnswers}
                className="px-6 py-2.5 bg-[#C49746] hover:opacity-90 text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-xs cursor-pointer"
              >
                Configurar Project Charter &amp; Avançar ➔
              </button>
            </div>
          </div>
        )}

          {/* TAB 2: PROJECT CHARTER FORM */}
          {activeResultTab === "CHARTER" && (
            <div className="space-y-6 animate-fade-in">
              {/* Info Banner */}
              <div className="bg-[#FAF9F5] border border-[#C49746]/20 p-4 flex items-start gap-3.5">
                <div className="bg-amber-100 text-[#C49746] rounded-full p-1.5 shrink-0 mt-0.5">
                  <ClipboardCheck size={16} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wide text-gray-900 col-span-1 border-b border-[#1A1A1A]/5 pb-0.5">Etapa 2 - Preenchimento Descritivo do Projeto e do Processo</h4>
                  <p className="text-[11.5px] text-gray-600 leading-relaxed mt-1">
                    Explicite os Sponsors (Patrocinadores), o escopo inicial e o problema em questão. A IA interpretou suas respostas de diagnóstico e estruturou este rascunho. Revise as declarações e customize-as livremente.
                  </p>
                </div>
              </div>

              {charterSuccess && (
                <div className="bg-emerald-50 text-emerald-800 border border-emerald-250 p-3 text-xs flex items-center gap-2">
                  <span className="text-emerald-650 font-bold font-mono">✓</span>
                  <span>Configurações derivadas das alternativas do diagnóstico aplicadas com sucesso no layout do termo!</span>
                </div>
              )}

              {/* Form Card Grid */}
              <div className="bg-white border-2 border-slate-900 p-6 md:p-8 space-y-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
                {/* Title */}
                <div className="flex items-center gap-2 border-b border-gray-150 pb-2 mb-2">
                  <span className="text-xs font-bold text-[#C49746] font-mono">[ 📋 PROJECT CHARTER ]</span>
                </div>

                <div className="space-y-4">
                  {/* Project Title Input */}
                  <div className="space-y-1">
                    <label className="block text-[10.5px] font-bold text-gray-700 uppercase tracking-wide">Título Corporativo do Projeto LSS</label>
                    <input
                      type="text"
                      value={localCharter.title}
                      onChange={(e) => setLocalCharter({ ...localCharter, title: e.target.value })}
                      className="w-full bg-[#FAF9F6] border-2 border-slate-900 px-3 py-2 text-xs font-bold focus:border-[#C49746] focus:outline-none"
                      placeholder="Ex: Projeto DMAIC - Redução de Variabilidade em Linha de Solda"
                    />
                  </div>

                  {/* Problem Statement Area */}
                  <div className="space-y-1">
                    <label className="block text-[10.5px] font-bold text-gray-700 uppercase tracking-wide">Descrição do Problema &amp; Dor Atual (As-Is)</label>
                    <textarea
                      rows={3}
                      value={localCharter.problemStatement}
                      onChange={(e) => setLocalCharter({ ...localCharter, problemStatement: e.target.value })}
                      className="w-full bg-[#FAF9F6] border-2 border-slate-900 px-3 py-2 text-xs leading-relaxed focus:border-[#C49746] focus:outline-none resize-none"
                      placeholder="Insira detalhes sobre os desperdícios e tempos de atraso vigentes..."
                    />
                    <span className="text-[9px] text-gray-400 block italic">Preencha de forma quantitativa onde e como os gargalos estocásticos geram perdas.</span>
                  </div>

                  {/* Goal Description Area */}
                  <div className="space-y-1">
                    <label className="block text-[10.5px] font-bold text-gray-700 uppercase tracking-wide">Objetivo Global &amp; Meta Alvo (To-Be)</label>
                    <textarea
                      rows={2}
                      value={localCharter.goal}
                      onChange={(e) => setLocalCharter({ ...localCharter, goal: e.target.value })}
                      className="w-full bg-[#FAF9F6] border-2 border-slate-900 px-3 py-2 text-xs leading-relaxed focus:border-[#C49746] focus:outline-none resize-none"
                      placeholder="Descreva as metas de atendimento e estabilização de fluxo..."
                    />
                  </div>

                  {/* Metric and Target Numeric Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="block text-[10.5px] font-bold text-gray-700 uppercase tracking-wide">Métrica de Auditoria Principal (Y)</label>
                      <select
                        value={localCharter.metric}
                        onChange={(e) => setLocalCharter({ ...localCharter, metric: e.target.value as any })}
                        className="w-full bg-[#FAF9F6] border-2 border-slate-900 px-3 py-2 text-xs focus:border-[#C49746] focus:outline-none cursor-pointer"
                      >
                        <option value="cycle_time">Lead Time / Tempo de Atendimento ({TERMS.cycleTime})</option>
                        <option value="throughput">Vazão Total de Operações ({TERMS.throughput})</option>
                        <option value="defect_rate">Minimização de Não-Conformidade (%)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10.5px] font-bold text-gray-700 uppercase tracking-wide">Valor Alvo Numérico Estimado</label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.01"
                          value={localCharter.targetValue}
                          onChange={(e) => setLocalCharter({ ...localCharter, targetValue: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-[#FAF9F6] border-2 border-slate-900 px-3 py-2 text-xs font-mono focus:border-[#C49746] focus:outline-none"
                        />
                        <span className="absolute right-3 top-2.5 text-[9px] uppercase font-bold text-gray-400 font-mono">
                          {localCharter.metric === "cycle_time" ? "minutos" : localCharter.metric === "throughput" ? "un / h" : "taxa r."}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ACTIONS */}
              <div className="flex justify-between items-center pt-4 border-t border-gray-150">
                <button
                  type="button"
                  onClick={() => setActiveResultTab("DIAGNOSTIC")}
                  className="px-4 py-2 border border-slate-300 text-xs font-bold uppercase transition-colors hover:bg-gray-100 cursor-pointer"
                >
                  Voltar ao Laudo
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCharter(localCharter);
                    setActiveResultTab("SIPOC");
                  }}
                  className="px-6 py-2.5 bg-[#C49746] hover:opacity-90 text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                >
                  Salvar Charter &amp; Prosseguir ao SIPOC ➔
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: DIAGRAMA SIPOC WITH AI GENERATOR */}
          {activeResultTab === "SIPOC" && (
            <div className="space-y-6 animate-fade-in">
              {/* Detailed Intro */}
              <div className="bg-[#FAF9F5] border border-blue-200/20 p-5 flex items-start gap-4">
                <div className="bg-blue-100 text-[#1D4ED8] rounded-full p-2 shrink-0">
                  <Compass size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wide text-gray-900 col-span-1 border-b border-[#1A1A1A]/5 pb-0.5">Etapa 3 - Mapeamento de Fronteiras SIPOC sugerido por IA</h4>
                  <p className="text-[11.5px] text-gray-650 leading-relaxed mt-1">
                    O diagrama <strong>SIPOC</strong> (Suppliers, Inputs, Process, Outputs, Customers) define de forma inequívoca o ciclo macro de valor antes do início dos ensaios de simulação e mapeamento de postos operacionais.
                  </p>
                </div>
              </div>

              {/* GOLDEN GLOWING AI GENERATOR CARD */}
              <div className="border border-amber-350 bg-amber-50/20 p-5 space-y-3 relative overflow-hidden shadow-xs">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                  <div>
                    <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 uppercase tracking-wider font-mono">
                      Motor Cognitivo de Fronteiras LSS
                    </span>
                    <h4 className="text-base font-serif font-bold text-[#1A1A1A] mt-1">
                      Sugerir Matriz SIPOC Completa via IA
                    </h4>
                    <p className="text-[11px] text-gray-550">
                      A IA preencherá automaticamente os fornecedores, insumos, fluxo macro, entregáveis e clientes com base no segmento ativo: <strong className="text-amber-800">{activeBizType}</strong>.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleTriggerAiSipoc}
                    disabled={isAiGeneratingSipoc}
                    className={`px-5 py-2.5 text-xs font-bold uppercase tracking-widest text-white flex items-center justify-center gap-2 cursor-pointer transition-all duration-300 shadow-[2px_2px_0px_0px_rgba(217,119,6,0.5)] ${
                      isAiGeneratingSipoc 
                        ? "bg-amber-700 opacity-60 cursor-not-allowed animate-pulse" 
                        : "bg-[#C49746] hover:bg-black"
                    }`}
                  >
                    <Sparkles size={14} className="text-amber-300 animate-spin-slow" />
                    {isAiGeneratingSipoc ? "Analisando..." : "Sugestão Inteligente IA"}
                  </button>
                </div>

                {isAiGeneratingSipoc && (
                  <div className="p-3 bg-white/70 border border-dashed border-amber-350 text-[10.5px] leading-relaxed text-amber-900 animate-pulse font-mono space-y-1">
                    <div>🤖 [COPILOTO-AI]: Iniciando modelagem para o setor {activeBizType}...</div>
                    <div>• Extraindo variáveis de qualidade (CTQ) herdeiras do Project Charter...</div>
                    <div>• Mapeando fronteiras de supply chain (Suppliers &amp; Inputs)...</div>
                    <div>• Estruturando o mapa de transição stocástica de valor...</div>
                  </div>
                )}

                {aiSipocSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-250 text-emerald-800 text-[11px] flex items-center gap-2">
                    <span className="text-emerald-700 font-bold">✓ Sucesso:</span>
                    <span>A IA do Copiloto LSS gerou as colunas SIPOC contextuais de {activeBizType} com máxima aderência industrial! Revise e ajuste abaixo.</span>
                  </div>
                )}
              </div>

              {/* THE INTERACTIVE TACTILE SIPOC BOARD */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                {/* Suppliers */}
                <div className="border border-slate-300 p-3.5 bg-white space-y-1.5 hover:border-[#C49746] transition-all">
                  <span className="text-[10px] font-bold text-slate-400 font-mono block">S _ Fornecedores</span>
                  <textarea
                    rows={6}
                    value={localSipoc.suppliers}
                    onChange={(e) => setLocalSipoc({ ...localSipoc, suppliers: e.target.value })}
                    placeholder="Ex: Almoxarifado central, Fornecedores terceirizados..."
                    className="w-full bg-transparent border-0 focus:ring-0 text-[11px] leading-relaxed focus:outline-none resize-none font-sans"
                  />
                </div>

                {/* Inputs */}
                <div className="border border-slate-300 p-3.5 bg-white space-y-1.5 hover:border-[#C49746] transition-all">
                  <span className="text-[10px] font-bold text-slate-400 font-mono block">I _ Entradas</span>
                  <textarea
                    rows={6}
                    value={localSipoc.inputs}
                    onChange={(e) => setLocalSipoc({ ...localSipoc, inputs: e.target.value })}
                    placeholder="Ex: Matérias-primas, requisições de serviço, chamados..."
                    className="w-full bg-transparent border-0 focus:ring-0 text-[11px] leading-relaxed focus:outline-none resize-none font-sans"
                  />
                </div>

                {/* Process */}
                <div className="border border-slate-300 p-3.5 bg-[#FAF9F5]/45 space-y-1.5 hover:border-[#C49746] transition-all">
                  <span className="text-[10px] font-bold text-[#C49746] font-mono block">P _ Processo Macro</span>
                  <textarea
                    rows={6}
                    value={localSipoc.processDescription}
                    onChange={(e) => setLocalSipoc({ ...localSipoc, processDescription: e.target.value })}
                    placeholder="Ex: Entrada -> Configuração -> Teste -> Saída..."
                    className="w-full bg-transparent border-0 focus:ring-0 text-[11px] leading-relaxed focus:outline-none resize-none font-sans font-bold"
                  />
                </div>

                {/* Outputs */}
                <div className="border border-slate-300 p-3.5 bg-white space-y-1.5 hover:border-[#C49746] transition-all">
                  <span className="text-[10px] font-bold text-slate-400 font-mono block">O _ Saídas</span>
                  <textarea
                    rows={6}
                    value={localSipoc.outputs}
                    onChange={(e) => setLocalSipoc({ ...localSipoc, outputs: e.target.value })}
                    placeholder="Ex: Bens manufaturados, relatórios assinados..."
                    className="w-full bg-transparent border-0 focus:ring-0 text-[11px] leading-relaxed focus:outline-none resize-none font-sans"
                  />
                </div>

                {/* Customers */}
                <div className="border border-slate-300 p-3.5 bg-white space-y-1.5 hover:border-[#C49746] transition-all">
                  <span className="text-[10px] font-bold text-slate-400 font-mono block">C _ Clientes</span>
                  <textarea
                    rows={6}
                    value={localSipoc.customers}
                    onChange={(e) => setLocalSipoc({ ...localSipoc, customers: e.target.value })}
                    placeholder="Ex: Clientes corporativos B2B, frotistas regionais..."
                    className="w-full bg-transparent border-0 focus:ring-0 text-[11px] leading-relaxed focus:outline-none resize-none font-sans"
                  />
                </div>
              </div>

              {/* SUMMARY NOTICE */}
              <div className="text-[10px] leading-relaxed text-gray-500 italic">
                💡 <strong>Conselho LSS:</strong> O SIPOC serve para delimitar perfeitamente o escopo que entra na modelagem. Para projetar fidedignamente seu layout e identificar filas estocásticas, passaremos em seguida para a construção espacial dos postos de trabalho.
              </div>

              {/* ACTIONS */}
              <div className="flex justify-between items-center pt-4 border-t border-gray-150">
                <button
                  type="button"
                  onClick={() => setActiveResultTab("CHARTER")}
                  className="px-4 py-2 border border-slate-300 text-xs font-bold uppercase transition-colors hover:bg-gray-100 cursor-pointer"
                >
                  Voltar ao Charter
                </button>
                <button
                  type="button"
                  onClick={handleFinalizeSetup}
                  className="px-8 py-3 bg-[#C49746] hover:opacity-95 text-white text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] cursor-pointer border border-[#1A1A1A]"
                >
                  Tudo Pronto! Avançar para Mapeamento de Layout (Fase Measure) 🗺️
                </button>
              </div>
            </div>
          )}

          {activeResultTab === "MAPEADOR_360" && (
            <div className="space-y-6 animate-fade-in text-left">
              {/* Detailed Intro */}
              <div className="bg-[#FAF9F5] border border-[#C49746]/20 p-5 flex items-start gap-4">
                <div className="bg-amber-100 text-[#C49746] rounded-full p-2 shrink-0">
                  <Camera size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wide text-gray-900 col-span-1 border-b border-[#1A1A1A]/5 pb-0.5">
                    Mapeador de Diagnóstico 360° &amp; Coleta de Evidências
                  </h4>
                  <p className="text-[11.5px] text-gray-650 leading-relaxed mt-1">
                    Esta estação de trabalho integra o <strong>diagnóstico técnico</strong> realizado aos dados operacionais do seu layout. Aqui, você pode associar evidências físicas (como fotos de campo ou registros brutos de tempos de ciclo) para atualizar automaticamente as etapas de simulação e os campos do projeto <strong>DMAIC</strong> correspondente.
                  </p>
                </div>
              </div>

              {/* Mapper Content Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                
                {/* Column 1: Step Association & Alignment */}
                <div className="space-y-5 bg-white border border-[#1A1A1A]/10 p-5 shadow-xs">
                  <div className="border-b border-gray-100 pb-2">
                    <span className="text-[9px] uppercase font-bold text-[#C49746] font-mono">Passo A</span>
                    <h4 className="text-sm font-bold text-gray-900">Selecionar e Sincronizar Posto de Trabalho</h4>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Selecione o Posto de Trabalho Ativo</label>
                      <select
                        value={selectedMapperStepId}
                        onChange={(e) => {
                          setSelectedMapperStepId(e.target.value);
                          setHasAligned(false);
                          setMapperNotification(null);
                        }}
                        className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-2 focus:border-[#C49746] focus:outline-none"
                      >
                        <option value="">-- Escolha um Posto --</option>
                        {steps.map((s) => (
                          <option key={s.id} value={s.id}>
                            [{s.id.toUpperCase()}] {s.name} ({s.resourceCount} recurso{s.resourceCount > 1 ? 's' : ''})
                          </option>
                        ))}
                      </select>
                    </div>

                    {selectedMapperStepId ? (() => {
                      const selectedStep = steps.find((s) => s.id === selectedMapperStepId);
                      if (!selectedStep) return null;
                      return (
                        <div className="space-y-4 animate-fade-in">
                          {/* Current Stats card */}
                          <div className="bg-[#FAF9F5] border-l-3 border-[#C49746] p-4 text-xs space-y-2">
                            <span className="text-[9px] uppercase font-bold text-[#C49746] tracking-wider">Ficha Técnica Operacional:</span>
                            <div className="grid grid-cols-2 gap-y-1 font-sans">
                              <span className="text-gray-500">Posto:</span>
                              <span className="font-bold text-gray-950">{selectedStep.name}</span>
                              <span className="text-gray-500">Recurso do Posto:</span>
                              <span className="font-mono text-gray-900">{selectedStep.resource}</span>
                              <span className="text-gray-500">Tempo de Ciclo (CTm):</span>
                              <span className="font-mono font-bold text-gray-900">{selectedStep.processingTime} min</span>
                              <span className="text-gray-500">Desvio Padrão (σ):</span>
                              <span className="font-mono text-gray-900">± {selectedStep.standardDeviation} min</span>
                              <span className="text-gray-500">Taxa de Yield:</span>
                              <span className="font-mono font-bold text-emerald-700">{(selectedStep.yieldRate * 100).toFixed(1)}%</span>
                            </div>
                          </div>

                          {/* Technical alignment suggestions */}
                          <div className="p-4 border border-blue-200/40 bg-blue-50/10 space-y-2 text-xs text-gray-600 leading-relaxed">
                            <span className="font-bold text-blue-955 block flex items-center gap-1.5 font-sans">
                              <Cpu size={13} className="text-blue-600 animate-pulse" /> Recomendações do Diagnóstico Técnico
                            </span>
                            <p>
                              O diagnóstico técnico indicou um nível de qualidade <strong>Six Sigma de {calculateAnalysis().sixSigmaPct}%</strong>. Para alinhar este posto à realidade prática observada:
                            </p>
                            <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-550">
                              <li>Gargalos em postos manuais sofrem flutuações de <strong>desvio padrão</strong> que desestabilizam o lead-time.</li>
                              <li>Garantir um Yield Rate de <strong>99.0%</strong> com dispositivos Poka-Yoke de validação instantânea.</li>
                            </ul>
                          </div>

                          {/* Sync Button */}
                          <button
                            type="button"
                            onClick={() => {
                              // Perform synchronization: adjust parameters based on diagnosis
                              setSteps(prev => prev.map(s => {
                                if (s.id === selectedStep.id) {
                                  return {
                                    ...s,
                                    yieldRate: Math.max(s.yieldRate, 0.985), // Align to high diagnostic suggestion
                                    standardDeviation: Math.round(s.processingTime * 0.15 * 100) / 100, // standard deviation adjusted to robust Lean standard (15% coefficient of variation)
                                    dmaicTargetMetric: Math.round(s.processingTime * 0.8 * 10) / 10,
                                    dmaicProblemScope: `[SINCRONIZAÇÃO DIAGNÓSTICA] O posto "${s.name}" opera com desvio estatístico de qualidade. O laudo técnico de maturidade de ${calculateAnalysis().sixSigmaPct}% apontou para perdas por variação, impactando o lead-time complessivo.`,
                                    dmaicProjectGoal: `Reduzir a variação para σ <= ${(s.processingTime * 0.15 * 0.7).toFixed(2)} min e blindar o rendimento em 99% via contramedidas visuais.`
                                  };
                                }
                                return s;
                              }));
                              setHasAligned(true);
                              setMapperNotification({
                                type: "success",
                                message: `Sincronização concluída! Os indicadores do posto "${selectedStep.name}" foram alinhados aos parâmetros recomendados do Diagnóstico Técnico.`
                              });
                            }}
                            className={`w-full py-2.5 px-4 font-bold text-xs uppercase tracking-wider transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                              hasAligned
                                ? "bg-emerald-50 border-emerald-300 text-emerald-800 font-bold"
                                : "bg-[#1A1A1A] text-white hover:opacity-90 border-[#1A1A1A]"
                            }`}
                          >
                            {hasAligned ? (
                              <>✓ Sincronizado com o Diagnóstico</>
                            ) : (
                              <><Sliders size={13} /> Sincronizar Diagnóstico Técnico com o Posto</>
                            )}
                          </button>
                        </div>
                      );
                    })() : (
                      <div className="p-8 border border-dashed border-gray-200 text-center text-xs text-gray-400">
                        Selecione um posto de trabalho acima para iniciar o alinhamento
                      </div>
                    )}
                  </div>
                </div>

                {/* Column 2: Digital Evidence Upload Station */}
                <div className="space-y-5 bg-white border border-[#1A1A1A]/10 p-5 shadow-xs">
                  <div className="border-b border-gray-100 pb-2 flex justify-between items-center">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-[#C49746] font-mono">Passo B</span>
                      <h4 className="text-sm font-bold text-gray-900">Estação de Evidências (Fotos &amp; Amostras)</h4>
                    </div>
                    {evidencePhoto && (
                      <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono">
                        FOTO ATIVA
                      </span>
                    )}
                  </div>

                  <div className="space-y-4">
                    {/* Visual Photo Upload Component */}
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">
                        1. Evidência Fotográfica do Posto (Layout/5S/Desperdício)
                      </label>
                      
                      {evidencePhoto ? (
                        <div className="border border-emerald-200 bg-emerald-50/25 p-3 flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <div className="bg-emerald-600 text-white p-1.5 rounded-sm">
                              <Camera size={14} />
                            </div>
                            <div>
                              <p className="text-xs font-bold text-gray-900 font-mono">{evidencePhoto}</p>
                              <p className="text-[10px] text-gray-500">Simulação de evidência fotográfica carregada</p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => setEvidencePhoto(null)}
                            className="p-1 text-gray-400 hover:text-red-500 transition-colors cursor-pointer"
                          >
                            <Trash size={13} />
                          </button>
                        </div>
                      ) : (
                        <div className="border border-dashed border-gray-300 p-6 flex flex-col items-center justify-center text-center bg-gray-50 hover:bg-gray-100/50 transition-all cursor-pointer relative">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                              if (e.target.files && e.target.files.length > 0) {
                                setEvidencePhoto(e.target.files[0].name);
                              }
                            }}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                          <Upload size={22} className="text-gray-400 mb-2" />
                          <p className="text-xs font-bold text-gray-800">Arraste uma foto ou clique para escolher</p>
                          <p className="text-[10px] text-gray-500 mt-1">Carregue fotos do posto real (gargalos, pilhas de WIP, desorganização)</p>
                          
                          <div className="mt-3 flex gap-2">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                setEvidencePhoto(`workstation_congestion_${selectedMapperStepId || 'post'}.jpg`);
                              }}
                              className="text-[9px] bg-white border border-[#1A1A1A]/10 text-gray-700 font-bold uppercase py-1 px-2.5 hover:bg-gray-50 transition"
                            >
                              📸 Simular Foto de Gargalo
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Raw Data Input */}
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1 flex justify-between items-center">
                        <span>2. Dados Brutos de Amostras (Copiados da Planilha / Sensores)</span>
                        <span className="text-[9px] text-gray-400 font-mono lowercase">Ex: 3.5, 4.1, 2.8...</span>
                      </label>
                      <textarea
                        rows={3}
                        value={evidenceRawData}
                        onChange={(e) => {
                          setEvidenceRawData(e.target.value);
                          setEvidenceError(null);
                        }}
                        placeholder="Cole aqui os tempos de ciclo brutos ou amostras de desvios separadas por vírgula ou quebra de linha. Ex: 4.2, 5.0, 3.9, 4.8, 6.2, 4.1"
                        className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-2.5 font-mono focus:border-[#C49746] focus:outline-none"
                      />
                      {evidenceError && (
                        <p className="text-[10px] text-red-600 mt-1 flex items-center gap-1 font-bold">
                          <AlertCircle size={11} /> {evidenceError}
                        </p>
                      )}
                      
                      <div className="mt-1.5 flex gap-2">
                        <button
                          type="button"
                          onClick={() => setEvidenceRawData("3.1, 4.5, 5.2, 2.9, 3.8, 4.2, 5.9, 3.4, 4.1, 4.8")}
                          className="text-[9px] bg-slate-50 border border-slate-200 text-slate-750 py-0.5 px-2 hover:bg-slate-100 transition cursor-pointer"
                        >
                          📋 Inserir 10 amostras estáveis
                        </button>
                        <button
                          type="button"
                          onClick={() => setEvidenceRawData("5.2, 8.4, 6.1, 10.5, 7.8, 9.2, 11.0, 5.4, 6.8, 8.5")}
                          className="text-[9px] bg-red-50 border border-red-200 text-red-750 py-0.5 px-2 hover:bg-red-100 transition cursor-pointer"
                        >
                          📋 Inserir 10 amostras com alta variabilidade
                        </button>
                      </div>
                    </div>

                    {/* Trigger Cognitive IA processing */}
                    <button
                      type="button"
                      disabled={!selectedMapperStepId || (!evidencePhoto && !evidenceRawData.trim()) || processingEvidence}
                      onClick={() => {
                        if (!selectedMapperStepId) return;
                        setProcessingEvidence(true);
                        setEvidenceFeedbackLog([]);
                        
                        // Sequence of simulated E3I analysis logs
                        const logs = [
                          "🔍 Iniciando escaneamento cognitivo de evidências E3I...",
                          "📑 Analisando contexto operacional do posto de trabalho...",
                        ];

                        if (evidencePhoto) {
                          logs.push("📸 Processando imagem de campo...");
                          logs.push("✓ Desorganização física e layout inadequado identificados!");
                          logs.push("✓ Extraindo causas raízes físicas (Ishikawa 6M)...");
                        }

                        if (evidenceRawData.trim()) {
                          logs.push("📊 Analisando dados brutos colados pelo usuário...");
                        }

                        let logIdx = 0;
                        const interval = setInterval(() => {
                          if (logIdx < logs.length) {
                            setEvidenceFeedbackLog(prev => [...prev, logs[logIdx]]);
                            logIdx++;
                          } else {
                            clearInterval(interval);
                            
                            // Let's perform the actual statistical and cognitive modifications!
                            const selectedStep = steps.find(s => s.id === selectedMapperStepId);
                            if (selectedStep) {
                              let updatedProcessingTime = selectedStep.processingTime;
                              let updatedStdDev = selectedStep.standardDeviation;
                              let parsedSamples: number[] = [];

                              if (evidenceRawData.trim()) {
                                // Parse samples
                                const rawVals = evidenceRawData.split(/[\s,;]+/).map(v => parseFloat(v)).filter(v => !isNaN(v));
                                if (rawVals.length > 0) {
                                  parsedSamples = rawVals;
                                  // Compute math mean
                                  const sum = rawVals.reduce((acc, v) => acc + v, 0);
                                  const mean = sum / rawVals.length;
                                  
                                  // Compute standard deviation
                                  const variance = rawVals.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / rawVals.length;
                                  const stdDev = Math.sqrt(variance);

                                  updatedProcessingTime = Math.round(mean * 10) / 10;
                                  updatedStdDev = Math.round(stdDev * 100) / 100;
                                }
                              }

                              // Pre-populate DMAIC Ishikawa causes
                              const originalCauses = selectedStep.dmaicIshikawaCauses || {
                                metodo: ["Fluxo de trabalho empurrado sem controle cambial Lean (Kanban)", "Procedimentos operacionais com pouca padronização escritural"],
                                maquina: ["Microparadas intermitentes no ferramental primário", "Falta de manutenção preditiva regular nos bicos de soldagem"],
                                maoDeObra: ["Falta de reciclagem em tempos de ciclo balanceados", "Fadiga física e estresse devido a posições não ergonômicas"],
                                material: ["Insumos secundários com variação de dimensionalidade física", "Lotes de alimentação de componentes com umidade excessiva"],
                                medida: ["Calibração inexata de sensores ópticos de validação", "Ausência de controle estatístico por gráficos Shewhart"],
                                meioAmbiente: ["Iluminação inconstante afetando o tempo visual do operador", "Excesso de ruído industrial desconcentrando a operação"],
                              };

                              let updatedCauses = { ...originalCauses };

                              if (evidencePhoto) {
                                updatedCauses.metodo = [
                                  "✓ [EVIDÊNCIA FOTO] Falta de padrão visual 5S e instruções de trabalho visíveis",
                                  ...updatedCauses.metodo
                                ];
                                updatedCauses.maquina = [
                                  "✓ [EVIDÊNCIA FOTO] Layout de ferramentas desorganizado aumentando tempo de ciclo",
                                  ...updatedCauses.maquina
                                ];
                                updatedCauses.maoDeObra = [
                                  "✓ [EVIDÊNCIA FOTO] Postura ergonômica desfavorável forçando interrupções frequentes",
                                  ...updatedCauses.maoDeObra
                                ];
                                updatedCauses.material = [
                                  "✓ [EVIDÊNCIA FOTO] Excesso de peças intermediárias (WIP) obstruindo o fluxo da célula",
                                  ...updatedCauses.material
                                ];
                              }

                              // Create evidence item
                              const newEvidenceItem = {
                                id: Math.random().toString(36).substring(2, 9),
                                name: evidencePhoto || "Amostra_Dados_Brutos.csv",
                                type: evidencePhoto ? "IMAGEM" : "DADOS_BRUTOS",
                                date: new Date().toLocaleDateString('pt-BR'),
                                valueCount: parsedSamples.length || undefined,
                                description: evidencePhoto 
                                  ? "Registro visual indicando gargalo e desorganização 5S."
                                  : `Série estatística contendo ${parsedSamples.length} amostras coletadas diretamente pelo operador.`
                              };

                              // Save everything to parent state!
                              setSteps(prev => prev.map(s => {
                                if (s.id === selectedStep.id) {
                                  return {
                                    ...s,
                                    processingTime: updatedProcessingTime,
                                    standardDeviation: updatedStdDev,
                                    dmaicMeasurements: parsedSamples.length > 0 ? parsedSamples : s.dmaicMeasurements,
                                    dmaicProblemScope: evidencePhoto 
                                      ? `[EVIDÊNCIA FOTO DETECTADA] Posto "${s.name}" exibe gargalos visíveis no layout. Acúmulo desordenado de materiais em processamento (WIP) e posturas não padronizadas foram registrados física e fotograficamente.`
                                      : `[EVIDÊNCIA DADOS BRUTOS] Dados amostrais reais carregados com tempo médio de ${updatedProcessingTime} min e dispersão σ de ±${updatedStdDev} min.`,
                                    dmaicProjectGoal: `Reduzir a média de ciclo para ${Math.round(updatedProcessingTime * 0.8 * 10) / 10} min e conter o desvio para abaixo de ±${Math.round(updatedStdDev * 0.5 * 100) / 100} min.`,
                                    dmaicTargetMetric: Math.round(updatedProcessingTime * 0.8 * 10) / 10,
                                    dmaicIshikawaCauses: updatedCauses,
                                    dmaicEvidences: [newEvidenceItem, ...(s.dmaicEvidences || [])]
                                  };
                                }
                                return s;
                              }));

                              setFedDmaicCount(4);
                              setProcessingEvidence(false);
                              setMapperNotification({
                                type: "success",
                                message: `Sucesso! Evidências processadas com sucesso. Foram extraídos parâmetros reais e injetados diretamente na jornada DMAIC do posto "${selectedStep.name}".`
                              });
                            }
                          }
                        }, 500);
                      }}
                      className="w-full bg-[#C49746] hover:bg-[#B38635] disabled:bg-gray-100 disabled:text-gray-400 text-white py-2.5 px-4 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] disabled:shadow-none border border-[#1A1A1A] disabled:border-gray-200 cursor-pointer"
                    >
                      {processingEvidence ? (
                        <div className="flex items-center gap-2">
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Processando via Inteligência LSS...
                        </div>
                      ) : (
                        <>
                          <Cpu size={13} />
                          Processar Evidências &amp; Alimentar DMAIC
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>

              {/* Cognitive Logging outputs when evidence is analyzed */}
              {evidenceFeedbackLog.length > 0 && (
                <div className="bg-[#FAF9F5] border border-gray-200 p-4 font-mono text-[10.5px] text-gray-700 space-y-1 rounded-sm animate-fade-in">
                  <span className="text-[8px] font-bold text-[#C49746] uppercase font-sans tracking-wider block mb-1">
                    Terminal Cognitivo E3I:
                  </span>
                  {evidenceFeedbackLog.map((log, idx) => (
                    <p key={idx} className="leading-relaxed">
                      {log}
                    </p>
                  ))}
                  {!processingEvidence && (
                    <p className="text-emerald-755 font-bold mt-1">
                      ✓ Sincronização completa de fotos e amostras estatísticas realizada!
                    </p>
                  )}
                </div>
              )}

              {/* Feedback Success Notification details */}
              {mapperNotification && (
                <div className={`p-4 border animate-fade-in flex items-start gap-3 rounded-none ${
                  mapperNotification.type === "success"
                    ? "bg-emerald-50/50 border-emerald-200 text-emerald-800"
                    : "bg-red-50 border-red-200 text-red-800"
                }`}>
                  <div className={`p-1 rounded-full shrink-0 ${
                    mapperNotification.type === "success" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"
                  }`}>
                    {mapperNotification.type === "success" ? <Check size={14} /> : <AlertCircle size={14} />}
                  </div>
                  <div className="flex-grow">
                    <p className="text-xs font-bold uppercase tracking-wider">Notificação do Mapeador</p>
                    <p className="text-[11px] leading-relaxed mt-0.5">{mapperNotification.message}</p>
                    
                    {mapperNotification.type === "success" && selectedMapperStepId && (
                      <div className="mt-3 flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            // Find selected step in parent and launch DMAIC View
                            setView("DMAIC");
                          }}
                          className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[10px] uppercase py-1 px-3 shadow-[1.5px_1.5px_0px_rgba(26,26,26,1)] border border-[#1A1A1A] transition-colors cursor-pointer"
                        >
                          🚀 Abrir Jornada DMAIC Deste Posto
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Navigation Actions */}
              <div className="flex justify-between items-center pt-4 border-t border-gray-150">
                <button
                  type="button"
                  onClick={() => setActiveResultTab("SIPOC")}
                  className="px-4 py-2 border border-slate-300 text-xs font-bold uppercase transition-colors hover:bg-gray-100 cursor-pointer"
                >
                  Voltar ao Diagrama SIPOC
                </button>
                <button
                  type="button"
                  onClick={handleFinalizeSetup}
                  className="px-8 py-3 bg-[#C49746] hover:opacity-95 text-white text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] cursor-pointer border border-[#1A1A1A]"
                >
                  Confirmar e Ir para Layout do Fluxo 🗺️
                </button>
              </div>
            </div>
          )}
        </div>
    );
  };

  return (
    <div className="bg-[#FDFCFB] border border-[#1A1A1A]/10 rounded-none shadow-sm flex flex-col overflow-hidden text-left" id="diagnostic-screen-viewport">
      
      {/* Editorial Screen Header */}
      <div className="bg-[#F5F2ED] border-b border-[#1A1A1A]/10 p-5 md:p-8 flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-widest uppercase text-[#C49746] bg-[#C49746]/5 px-2 py-0.5 rounded-xs">
              Mapeamento de Ciclo de Vida
            </span>
            <span className="text-[9px] text-[#1A1A1A]/40 font-mono font-bold">• MÓDULO INTELIGENTE DE SETUP</span>
          </div>
          <h2 className="text-3xl font-serif text-[#1A1A1A] tracking-tight">
            Diagnóstico Operacional Interativo
          </h2>
          <p className="text-xs text-[#1A1A1A]/70 max-w-2xl leading-relaxed">
            Responda as perguntas direcionadas abaixo para identificar se o seu processo requer práticas táticas <strong>PDCA / 5S</strong>, agilidade de <strong>Manufatura Lean</strong>, controle rigoroso <strong>Six Sigma (DMAIC)</strong> ou a unificação corporativa <strong>Lean Six Sigma</strong>.
          </p>
        </div>
        <ClipboardCheck size={28} className="text-[#1A1A1A]/30 hidden md:block" />
      </div>

      {/* SECTOR & PROCESS ALIGNMENT BANNER */}
      <div className="bg-[#FAF8F5] border-b border-[#1A1A1A]/10 p-5 md:px-8 py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {!isEditingProcess ? (
          <>
            <div className="flex items-start md:items-center gap-3.5">
              <div className="bg-[#C49746]/10 text-[#C49746] rounded-xs p-2 shrink-0">
                <span className="text-xl">🎯</span>
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[9px] font-bold tracking-widest uppercase text-[#C49746] bg-[#C49746]/5 px-2 py-0.5 rounded-xs">
                    Processo Identificado
                  </span>
                  <span className="text-[9px] font-bold tracking-widest uppercase text-slate-500 bg-slate-100 px-2 py-0.5 rounded-xs">
                    Setor: {TERMS.badge || businessType}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-[#1A1A1A] mt-1">
                  {tempName || "Processo de Melhoria"}
                </h4>
                <p className="text-xs text-[#1A1A1A]/60 font-sans mt-0.5">
                  <strong>Objetivo / Escopo:</strong> {tempObjective || "Melhoria contínua de eficiência e capabilidade de processo."}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsEditingProcess(true)}
                className="px-3.5 py-1.5 border border-[#1A1A1A]/20 hover:border-black rounded-xs text-[10.5px] font-bold uppercase tracking-wider text-gray-700 hover:text-black cursor-pointer transition-all flex items-center gap-1.5"
              >
                ✏️ Alterar Processo Alvo
              </button>
            </div>
          </>
        ) : (
          <div className="w-full space-y-4 py-1">
            <div className="flex items-center gap-2 border-b border-[#1A1A1A]/10 pb-2">
              <span className="text-xs font-mono font-bold text-[#C49746]">
                [ EDITANDO PROCESSO A SER ENTENDIDO E MELHORADO ]
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
              {/* Process Name */}
              <div className="md:col-span-5 space-y-1">
                <label className="text-[9.5px] font-bold uppercase tracking-wider text-gray-500 block">
                  Nome do Processo a ser entendido/melhorado
                </label>
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  placeholder="Ex: Contas a pagar, Linha de Soldagem Refluxo SMT"
                  className="w-full text-xs p-2.5 border border-[#1A1A1A]/25 focus:border-[#C49746] focus:ring-0 rounded-xs bg-white text-gray-900"
                />
              </div>

              {/* Goal / Objective */}
              <div className="md:col-span-4 space-y-1">
                <label className="text-[9.5px] font-bold uppercase tracking-wider text-gray-500 block">
                  Objetivo / Escopo de Melhoria
                </label>
                <input
                  type="text"
                  value={tempObjective}
                  onChange={(e) => setTempObjective(e.target.value)}
                  placeholder="Ex: Reduzir tempo de faturamento, eliminar desperdícios"
                  className="w-full text-xs p-2.5 border border-[#1A1A1A]/25 focus:border-[#C49746] focus:ring-0 rounded-xs bg-white text-gray-900"
                />
              </div>

              {/* Segment Toggle */}
              <div className="md:col-span-3 space-y-1">
                <label className="text-[9.5px] font-bold uppercase tracking-wider text-gray-500 block">
                  Segmento / Setor Operacional
                </label>
                <select
                  value={tempType}
                  onChange={(e) => setTempType(e.target.value as BusinessType)}
                  className="w-full text-xs p-2.5 border border-[#1A1A1A]/25 focus:border-[#C49746] focus:ring-0 rounded-xs bg-white text-gray-900"
                >
                  <option value="INDUSTRIAL">Indústria / Manufatura</option>
                  <option value="SERVICES">Serviços / Atendimento</option>
                  <option value="RETAIL">Comércio / Varejo</option>
                  <option value="LOGISTICS">Logística / Distribuição</option>
                  <option value="TECHNOLOGY">Tecnologia / Software</option>
                  <option value="HEALTHCARE">Saúde / Hospitalar</option>
                  <option value="FINANCE">Financeiro / Contábil</option>
                  <option value="HUMAN_RESOURCES">Recursos Humanos / RH</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setTempName(activeProjectName || projectDetails?.processName || TERMS.title);
                  setTempObjective(activeProjectObjective || projectDetails?.expectedImpact || "");
                  setTempType(businessType);
                  setIsEditingProcess(false);
                }}
                className="px-4 py-1.5 border border-gray-250 text-gray-600 hover:text-black rounded-xs text-[10.5px] font-bold uppercase tracking-wider cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveProcessDetails}
                className="px-5 py-1.5 bg-[#C49746] hover:opacity-90 text-white rounded-xs text-[10.5px] font-bold uppercase tracking-wider cursor-pointer"
              >
                Salvar &amp; Sincronizar
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 flex-grow">
        
        {/* Main interactive panel left side */}
        <div className="lg:col-span-8 p-6 md:p-10 border-b lg:border-b-0 lg:border-r border-[#1A1A1A]/10 flex flex-col justify-between min-h-[480px]">
          
          {!hasStarted ? (
            <div className="flex-grow flex items-center justify-center py-6">
              <EmptyState 
                type="no_diagnostic"
                primaryAction={{
                  label: "Iniciar Diagnóstico 360°",
                  onClick: () => setHasStarted(true)
                }}
                secondaryAction={{
                  label: "Usar exemplo demonstrativo",
                  onClick: () => {
                    const demoAnswers = QUESTIONS.map((_, idx) => idx % 3);
                    setAnswers(demoAnswers);
                    setShowResults(true);
                    setHasStarted(true);
                  }
                }}
                tertiaryAction={openTemplatesHub ? {
                  label: "Carregar Template de Segmento",
                  onClick: openTemplatesHub
                } : undefined}
              />
            </div>
          ) : (
            <>
              {!showResults ? (
                <div className="space-y-6">
                  
                  {/* Question progress and category label */}
                  <div className="flex justify-between items-center text-[10px] uppercase font-mono font-bold border-b border-[#1A1A1A]/5 pb-3">
                    <span className="text-amber-800 flex items-center gap-1">
                      <Compass size={11} /> Categoria: {currentQuestion.category}
                    </span>
                    <span className="text-[#1A1A1A]/40">
                      Pergunta {currentQuestionIndex + 1} de {QUESTIONS.length}
                    </span>
                  </div>

                  {/* Progress Bar indicator */}
                  <div className="w-full bg-gray-100 h-1 rounded-full overflow-hidden">
                    <div 
                      className="bg-[#C49746] h-full transition-all duration-300"
                      style={{ width: `${((currentQuestionIndex + 1) / QUESTIONS.length) * 100}%` }}
                    ></div>
                  </div>

                  {/* The Question Text in big classic font */}
                  <div className="space-y-2 py-2">
                    <h3 className="text-xl md:text-2xl font-serif text-[#1A1A1A] tracking-tight leading-snug">
                      {currentQuestion.text}
                    </h3>
                    <p className="text-[11px] text-gray-500 font-sans italic">
                      *Escolha a opção que melhor se aproxima do seu estado As-Is real para receber conselhos analíticos de preenchimento.
                    </p>
                  </div>

                  {/* Dynamic options container */}
                  <div className="space-y-3 pt-2">
                    {currentQuestion.options.map((option, idx) => {
                      const isSelected = answers[currentQuestionIndex] === idx;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleSelectOption(idx)}
                          className={`w-full text-left p-4 border transition-all duration-200 flex items-start gap-4 focus:outline-none relative ${
                            isSelected 
                              ? "border-[#C49746] bg-amber-50 text-amber-950 font-medium" 
                              : "border-gray-200 bg-white hover:border-gray-400 hover:bg-[#FDFCFB]/50"
                          }`}
                        >
                          <span className={`w-5 h-5 rounded-full border text-[10px] font-mono flex items-center justify-center font-bold shrink-0 mt-0.5 ${
                            isSelected 
                              ? "bg-[#C49746] text-white border-[#C49746]" 
                              : "bg-gray-50 border-gray-300 text-gray-600"
                          }`}>
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span className="text-[12px] leading-relaxed text-[#1A1A1A]">{option.label}</span>
                        </button>
                      );
                    })}
                  </div>

                </div>
              ) : (
                <>
                  {renderResults()}
                </>
              )}

              {/* Nav buttons footer */}
              <div className="flex items-center justify-between pt-6 border-t border-[#1A1A1A]/5 mt-8">
                <button
                  onClick={handlePrevQuestion}
                  disabled={currentQuestionIndex === 0 || showResults}
                  className="px-4 py-2 border border-gray-200 text-xs font-bold text-[#1A1A1A]/60 hover:text-black hover:border-black disabled:opacity-40 transition-colors cursor-pointer"
                >
                  Anterior
                </button>

                {showResults ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleResetDiagnostic}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-[#1A1A1A] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RotateCcw size={12} /> Refazer
                    </button>
                    <button
                      onClick={handleFinalizeSetup}
                      className="px-6 py-2 bg-[#C49746] hover:opacity-90 text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                    >
                      Configurar Processo &amp; Avançar <ArrowRight size={13} />
                    </button>
                  </div>
                ) : (
                  <span className="text-[10px] text-gray-400 font-mono">
                    Selecione uma opção acima para prosseguir
                  </span>
                )}
              </div>
            </>
          )}

        </div>

        {/* Informative, static editorial sidebar right side */}
        <div className="lg:col-span-4 bg-[#FAF8F5] p-6 md:p-10 space-y-6 flex flex-col justify-between">
          <div className="space-y-6">
            <h4 className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#1A1A1A]/80 border-b border-[#1A1A1A]/10 pb-2">
              Sinergia Metodológica
            </h4>

            {/* PDCA detail description */}
            <div className="space-y-1">
              <span className="text-[8px] font-mono border border-emerald-500 text-emerald-700 px-1.5 py-0.2 uppercase font-bold">
                Rotina Base
              </span>
              <h5 className="font-serif font-bold text-xs text-[#1A1A1A] mt-1">PDCA Clássico &amp; Padronização</h5>
              <p className="text-[10px] text-[#1A1A1A]/70 leading-relaxed">
                Foco no planejamento e padronização. Garante que os procedimentos de trabalho (SOP) existam e sejam seguidos à risca pela equipe de forma incremental.
              </p>
            </div>

            {/* Lean block details */}
            <div className="space-y-1">
              <span className="text-[8px] font-mono border border-amber-600 text-amber-700 px-1.5 py-0.2 uppercase font-bold">
                Eliminar Desperdício
              </span>
              <h5 className="font-serif font-bold text-xs text-[#1A1A1A] mt-1">Lean Manufacturing (Enxuto)</h5>
              <p className="text-[10px] text-[#1A1A1A]/70 leading-relaxed">
                Ideia principal de eliminar desperdícios operacionais (esperas, movimentação, WIP). Utiliza ferramentas estruturais como Kaizen diário, focado no fluxo contínuo.
              </p>
            </div>

            {/* Six Sigma block */}
            <div className="space-y-1">
              <span className="text-[8px] font-mono border border-indigo-600 text-indigo-700 px-1.5 py-0.2 uppercase font-bold">
                Reduzir Variabilidade
              </span>
              <h5 className="font-serif font-bold text-xs text-[#1A1A1A] mt-1">Metodologia Six Sigma</h5>
              <p className="text-[10px] text-[#1A1A1A]/70 leading-relaxed">
                Minimiza a variabilidade estatística e falhas físicas. Apoia-se estritamente no ciclo DMAIC (Definir, Medir, Analisar, Melhorar e Controlar) para garantir estabilidade.
              </p>
            </div>

            {/* LSS unified */}
            <div className="space-y-1 bg-[#1A1A1A] p-3 text-white">
              <span className="text-[8.5px] font-mono border border-amber-500 text-amber-500 px-1.5 py-0.2 uppercase font-bold">
                Máxima Sinergia
              </span>
              <h5 className="font-serif font-bold text-xs text-white mt-1">Lean Six Sigma (LSS)</h5>
              <p className="text-[10px] text-gray-300 leading-relaxed">
                Integra a velocidade de eliminação de desperdícios do Lean com o rigoroso poder analítico estatístico do Six Sigma. A melhor abordagem industrial moderna.
              </p>
            </div>
          </div>

          <div className="p-3.5 bg-white border border-gray-200 text-[10px] leading-relaxed text-[#1A1A1A]/60 italic font-serif">
            "Reunir-se é um começo, permanecer juntos é um progresso, trabalhar juntos é o sucesso corporativo."
            <span className="font-sans font-bold not-italic block text-right mt-1.5 text-gray-900">— Henry Ford</span>
          </div>
        </div>

      </div>

    </div>
  );
}
