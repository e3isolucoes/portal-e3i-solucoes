import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface FiveWhysAnalysis {
  id: string;
  title: string;
  problem: string;
  why1: string;
  why2: string;
  why3: string;
  why4: string;
  why5: string;
  rootCause: string;
  proposedAction: string;
  linkedObjectiveId: string;
  responsible: string;
  date: string;
  additionalWhys?: string[];
}

interface FiveWhysRootCauseModuleProps {
  customFiveWhys: FiveWhysAnalysis[];
  setCustomFiveWhys: React.Dispatch<React.SetStateAction<FiveWhysAnalysis[]>>;
  activeFiveWhysId: string;
  setActiveFiveWhysId: (id: string) => void;
  customObjectives: any[];
  handleConvertFiveWhysToChg: (analysis: FiveWhysAnalysis) => void;
  setNotification: (notif: { show: boolean; message: string; type: "SUCCESS" | "INFO" }) => void;
}

// Pre-populated templates to support Lean Six Sigma and Change Management operations
const EXPERT_TEMPLATES = [
  {
    title: "Erro de Setup na Calibração de Máquina SMT",
    problem: "A máquina de solda SMT apresentou elevado recalque térmico, paralisando a esteira por 35 minutos.",
    whys: [
      "Por que apresentou elevado recalque térmico? Porque os perfis térmicos das Zonas 3 e 4 saíram da tolerância CEP (Shewhart).",
      "Por que os perfis da Zona 3 e 4 saíram da tolerância? Porque os termopares internos registraram desvio cíclico de feedback elétrico.",
      "Por que registraram desvio elétrico cíclico? Porque houve mau contato por oxidação salina nos contatos da placa controladora.",
      "Por que houve oxidação salina na placa? Porque a vedação lateral do quadro elétrico traseiro ressecou, permitindo entrada de condensação.",
      "Por que a vedação traseira ressecou sem troca? Porque a calibração preventiva baseava-se em cronograma trimestral estático, desprezando o volume de produção do posto."
    ],
    rootCause: "Gatilho de manutenção programada ineficiente e desconectado dos dados de desgaste real por estresse do posto físico.",
    proposedAction: "Alterar no plano de controle (CEP) o gatilho de manutenção da vedação de 'trimestral' para 'a cada 50.000 placas executadas', integrando sensores telemétricos.",
    responsible: "Arthur Pendragon (Black Belt)",
    linkedObjectiveId: "obj-1"
  },
  {
    title: "Atraso no Escoamento de Lotes da Baia de Expedição",
    problem: "As ordens de expedição prontas acumulam na esteira final gerando gargalo estocástico crônico de 2 horas em média.",
    whys: [
      "Por que as ordens acumulam na esteira final? Porque o sistema central de etiquetas de código de barras parava de responder.",
      "Por que o sistema de etiquetas parava de responder? Porque o banco de dados do middleware de impressão sofria saturação de conexões simultâneas.",
      "Por que sofria saturação de conexões? Porque a rotina de envio de ordens requisitava checagem de estoque síncrona a cada batida de etiqueta.",
      "Por que requisitava checagem síncrona repetitiva? Porque o microsserviço de inventário não foi desenhado para processamento assíncrono em fila de mensagens.",
      "Por que não foi desenhado de forma assíncrona? Porque o Project Charter original de integração de sistemas priorizou velocidade de entrega sem realizar teste de estresse de carga industrial."
    ],
    rootCause: "Escopo de design de software incompleto e falta de validação técnica sob condições de fluxo estocástico de pico.",
    proposedAction: "Substituir a consulta síncrona por mensageria pub-sub resiliente para emissão assíncrona de etiquetas na esteira final.",
    responsible: "Clara Mendes (Green Belt)",
    linkedObjectiveId: "obj-2"
  },
  {
    title: "Variação na Concentração Química de Polímero",
    problem: "O banho galvânico apresentou variabilidade de densidade fora do limite nominal, forçando o refugo total do lote de gabinetes.",
    whys: [
      "Por que a densidade do banho desviou do limite? Porque o fluxo injetado do reagente catalisador foi 15% menor que o programado.",
      "Por que o fluxo de reagente foi menor? Porque a bomba peristáltica perdeu torque na rotação necessária para dosar o químico.",
      "Por que a bomba perdeu torque rotacional? Porque o rotor sofreu atrito abrasivo contra a carcaça de proteção por acúmulo de poeira ácida.",
      "Por que acumulou poeira ácida física? Porque o duto de exaustão e lavagem de gases do galpão operou com pressão negativa insuficiente por obstrução parcial.",
      "Por que o duto operou com obstrução sem inspeção? Porque a inspeção ambiental da cabine não estava listada no Checklist de Engenharia de Fábrica diário."
    ],
    rootCause: "Ausência de itens de proteção mecânica e exaustão física ambiental de banhos no Plano de Controle Shewhart do posto.",
    proposedAction: "Incluir auditoria preventiva diária de exaustão no roteiro Lean 5S e formalizar as variáveis químicas no painel de controle operacional do posto.",
    responsible: "Julio Nogueira (Master Black Belt)",
    linkedObjectiveId: "obj-3"
  }
];

export function FiveWhysRootCauseModule({
  customFiveWhys,
  setCustomFiveWhys,
  activeFiveWhysId,
  setActiveFiveWhysId,
  customObjectives,
  handleConvertFiveWhysToChg,
  setNotification
}: FiveWhysRootCauseModuleProps) {
  
  const [showNewWhyForm, setShowNewWhyForm] = useState<boolean>(false);
  
  // Create / Form States
  const [newWhyTitle, setNewWhyTitle] = useState("");
  const [newWhyProblem, setNewWhyProblem] = useState("");
  const [whysList, setWhysList] = useState<string[]>(["", "", "", "", ""]); // Starts with 5 whys
  const [newWhyRoot, setNewWhyRoot] = useState("");
  const [newWhyAction, setNewWhyAction] = useState("");
  const [newWhyOkr, setNewWhyOkr] = useState("");
  const [newWhyResp, setNewWhyResp] = useState("Especialista LSS");
  const [selectedTemplateIndex, setSelectedTemplateIndex] = useState<number | "">("");

  // Edit in-place individual states for the active study
  const activeStudy = customFiveWhys.find(w => w.id === activeFiveWhysId);
  
  // We reconstruct the list of Whys for the active study using its internal property why1-why5 + additionalWhys
  const getActiveStudyWhysList = (study: FiveWhysAnalysis): string[] => {
    const list = [study.why1, study.why2, study.why3, study.why4, study.why5].filter(x => x !== undefined);
    if (study.additionalWhys && Array.isArray(study.additionalWhys)) {
      return [...list, ...study.additionalWhys];
    }
    return list;
  };

  const handleUpdateActiveStudyField = (field: keyof FiveWhysAnalysis, value: any) => {
    if (!activeStudy) return;
    setCustomFiveWhys(prev => prev.map(w => {
      if (w.id === activeStudy.id) {
        return { ...w, [field]: value };
      }
      return w;
    }));
  };

  const handleUpdateActiveStudyWhyIndex = (index: number, text: string) => {
    if (!activeStudy) return;
    setCustomFiveWhys(prev => prev.map(w => {
      if (w.id === activeStudy.id) {
        // Find which property to update
        const updated = { ...w };
        if (index === 0) updated.why1 = text;
        else if (index === 1) updated.why2 = text;
        else if (index === 2) updated.why3 = text;
        else if (index === 3) updated.why4 = text;
        else if (index === 4) updated.why5 = text;
        else {
          const addList = [...(w.additionalWhys || [])];
          const addIndex = index - 5;
          addList[addIndex] = text;
          updated.additionalWhys = addList;
        }
        return updated;
      }
      return w;
    }));
  };

  const handleAddWhyToActiveStudy = () => {
    if (!activeStudy) return;
    setCustomFiveWhys(prev => prev.map(w => {
      if (w.id === activeStudy.id) {
        const updated = { ...w };
        const addList = [...(w.additionalWhys || [])];
        addList.push(""); // Add blank why box to be filled by user
        updated.additionalWhys = addList;
        return updated;
      }
      return w;
    }));
  };

  const handleRemoveWhyFromActiveStudy = (index: number) => {
    if (!activeStudy) return;
    
    // We can't have less than 1 why
    const currentList = getActiveStudyWhysList(activeStudy);
    if (currentList.length <= 1) return;

    setCustomFiveWhys(prev => prev.map(w => {
      if (w.id === activeStudy.id) {
        const updated = { ...w };
        const newList = currentList.filter((_, idx) => idx !== index);
        
        // Distribute back to why1-why5 and premium array
        updated.why1 = newList[0] || "";
        updated.why2 = newList[1] || "";
        updated.why3 = newList[2] || "";
        updated.why4 = newList[3] || "";
        updated.why5 = newList[4] || "";
        
        if (newList.length > 5) {
          updated.additionalWhys = newList.slice(5);
        } else {
          updated.additionalWhys = [];
        }
        return updated;
      }
      return w;
    }));
  };

  // Handle Form creator sub-elements
  const handleAddWhyToCreatorForm = () => {
    setWhysList(prev => [...prev, ""]);
  };

  const handleRemoveWhyFromCreatorForm = (index: number) => {
    if (whysList.length <= 1) return;
    setWhysList(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleCreatorWhyChange = (index: number, text: string) => {
    setWhysList(prev => {
      const copy = [...prev];
      copy[index] = text;
      return copy;
    });
  };

  const handleLoadTemplateToCreator = (index: number) => {
    const t = EXPERT_TEMPLATES[index];
    if (!t) return;
    setNewWhyTitle(t.title);
    setNewWhyProblem(t.problem);
    setWhysList([...t.whys]);
    setNewWhyRoot(t.rootCause);
    setNewWhyAction(t.proposedAction);
    setNewWhyResp(t.responsible);
    setNewWhyOkr(t.linkedObjectiveId);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fade-in text-slate-900 leading-normal">
      
      {/* LEFT COLUMN: LIST AND SWITCH VIEWPORT */}
      <div className="lg:col-span-4 border border-slate-200 bg-slate-50/50 p-4 relative shadow-sm">
        <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-200 gap-2">
          <div>
            <h4 className="text-xs font-mono font-bold uppercase text-slate-700 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span>
              Estudos de Causa Raiz (5 Porquês)
            </h4>
            <span className="text-[9px] text-slate-400 font-mono block mt-0.5">Analise e encadeie correlações de falhas</span>
          </div>
          <button
            id="btn-toggle-why-form"
            onClick={() => {
              setShowNewWhyForm(!showNewWhyForm);
              // reset creator keys
              setNewWhyTitle("");
              setNewWhyProblem("");
              setWhysList(["", "", "", "", ""]);
              setNewWhyRoot("");
              setNewWhyAction("");
              setNewWhyOkr(customObjectives[0]?.id || "obj-1");
              setNewWhyResp("Especialista LSS");
              setSelectedTemplateIndex("");
            }}
            className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-mono text-[9px] font-bold uppercase transition shadow-[1px_1px_0px_1px_rgba(0,0,0,1)] border border-slate-900 cursor-pointer flex items-center gap-1 shrink-0"
          >
            {showNewWhyForm ? "⚙ Ver Lista" : "➕ Nova Análise"}
          </button>
        </div>

        {!showNewWhyForm ? (
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {customFiveWhys.length === 0 ? (
              <div className="bg-white border border-dashed border-slate-200 p-6 text-center">
                <span className="text-xs italic text-slate-400 block mb-1">Nenhum estudo cadastrado.</span>
                <p className="text-[10px] text-slate-500">Clique em 'Nova Análise' para compilar uma causa raiz.</p>
              </div>
            ) : (
              customFiveWhys.map((why) => {
                const whysCount = getActiveStudyWhysList(why).length;
                return (
                  <div
                    key={why.id}
                    onClick={() => {
                      setActiveFiveWhysId(why.id);
                    }}
                    className={`p-3 border-2 transition text-left cursor-pointer relative ${
                      activeFiveWhysId === why.id
                        ? "bg-[#FFFDF3] border-[#C49746] shadow-[2.5px_2.5px_0px_0px_rgba(26,26,26,1)]"
                        : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-mono text-[#C49746] font-bold tracking-wider uppercase">ESTUDO: {why.id.toUpperCase()}</span>
                      <span className="text-[8px] bg-amber-100 text-amber-800 px-1 font-mono">{whysCount} Porquês</span>
                    </div>
                    <h5 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1">{why.title}</h5>
                    <p className="text-[10px] text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                      <strong>Falha principal:</strong> {why.problem}
                    </p>
                    
                    <div className="mt-3 pt-2 border-t border-dashed border-slate-105 flex justify-between items-center text-[8.5px] font-mono text-slate-400">
                      <span>👤 {why.responsible}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCustomFiveWhys(prev => {
                            const filtered = prev.filter(p => p.id !== why.id);
                            if (activeFiveWhysId === why.id && filtered.length > 0) {
                              setActiveFiveWhysId(filtered[0].id);
                            }
                            return filtered;
                          });
                          setNotification({
                            show: true,
                            message: `Estudo de caso '${why.title}' excluído.`,
                            type: "INFO"
                          });
                        }}
                        className="text-red-500 hover:text-red-800 font-bold uppercase hover:underline cursor-pointer"
                      >
                        Excluir
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          /* FORM TO CREATE DYNAMIC FIVE WHYS */
          <div className="space-y-4 text-left">
            
            {/* Quick Templates Dropdown */}
            <div className="bg-amber-50/50 border border-amber-200 p-2 text-left">
              <label className="block text-[8px] font-mono font-bold text-amber-800 uppercase mb-1">💡 Carregar Template de Referência:</label>
              <select
                value={selectedTemplateIndex}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === "") {
                    setSelectedTemplateIndex("");
                  } else {
                    const idx = Number(val);
                    setSelectedTemplateIndex(idx);
                    handleLoadTemplateToCreator(idx);
                  }
                }}
                className="w-full bg-white border border-amber-300 text-[10px] p-1 font-sans focus:outline-none focus:border-amber-600 rounded-none text-left"
              >
                <option value="">-- Escolha um Roteiro Lean Six Sigma --</option>
                {EXPERT_TEMPLATES.map((t, idx) => (
                  <option key={idx} value={idx}>{t.title}</option>
                ))}
              </select>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newWhyTitle.trim() || !newWhyProblem.trim() || whysList.filter(Boolean).length === 0) {
                  return;
                }

                // Compile whysList safely
                const cleanedList = whysList.map(w => w.trim()).filter(Boolean);
                
                // Construct standard why1 to why5 for backward compatibility, then push any extra into additionalWhys
                const newAnalysis: FiveWhysAnalysis = {
                  id: `why-${Date.now()}`,
                  title: newWhyTitle.trim(),
                  problem: newWhyProblem.trim(),
                  why1: cleanedList[0] || "Por que inconcludente.",
                  why2: cleanedList[1] || "N/A",
                  why3: cleanedList[2] || "N/A",
                  why4: cleanedList[3] || "N/A",
                  why5: cleanedList[4] || "N/A",
                  rootCause: newWhyRoot.trim() || "Causa raiz indeterminada sob ação local.",
                  proposedAction: newWhyAction.trim() || "Propor revisão técnica do procedimento do gargalo.",
                  linkedObjectiveId: newWhyOkr || (customObjectives[0]?.id || "obj-1"),
                  responsible: newWhyResp.trim() || "Especialista LSS",
                  date: new Date().toISOString().split("T")[0],
                  additionalWhys: cleanedList.length > 5 ? cleanedList.slice(5) : []
                };

                setCustomFiveWhys(prev => [newAnalysis, ...prev]);
                setActiveFiveWhysId(newAnalysis.id);
                setShowNewWhyForm(false);
                
                setNotification({
                  show: true,
                  message: `Estudo de Causa Raiz "${newAnalysis.title}" criado e ativo!`,
                  type: "SUCCESS"
                });
              }}
              className="space-y-3 bg-white p-3 border border-slate-200 shadow-sm"
            >
              <div>
                <label className="block text-[8.5px] font-mono font-black text-slate-400 mb-0.5 uppercase">Título Resumido *</label>
                <input
                  type="text"
                  required
                  value={newWhyTitle}
                  onChange={(e) => setNewWhyTitle(e.target.value)}
                  placeholder="Ex: Falha no Posto de Inspeção..."
                  className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                />
              </div>

              <div>
                <label className="block text-[8.5px] font-mono font-black text-slate-400 mb-0.5 uppercase">Definição do Problema (Fato Consumado) *</label>
                <textarea
                  required
                  value={newWhyProblem}
                  onChange={(e) => setNewWhyProblem(e.target.value)}
                  placeholder="Ex: Elevado índice de refugo no banho químico..."
                  rows={2}
                  className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans resize-none"
                />
              </div>

              <div className="space-y-2.5 border-t border-slate-100 pt-2.5">
                <div className="flex justify-between items-center">
                  <span className="text-[8.5px] font-mono uppercase bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 block w-max text-left">Encadeamento dos Porquês ({whysList.length})</span>
                  <button
                    type="button"
                    onClick={handleAddWhyToCreatorForm}
                    className="text-[8.5px] font-mono font-bold text-amber-700 hover:underline flex items-center gap-0.5"
                  >
                    ➕ Adicionar Elo
                  </button>
                </div>

                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-0.5">
                  {whysList.map((whyText, idx) => (
                    <div key={idx} className="bg-slate-50 p-2 border border-slate-200">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[8px] font-mono font-bold text-amber-800 uppercase">{idx + 1}º POR QUÊ ?</span>
                        {whysList.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveWhyFromCreatorForm(idx)}
                            className="text-[8px] text-red-500 font-mono hover:underline uppercase"
                          >
                            Remover
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        required
                        value={whyText}
                        onChange={(e) => handleCreatorWhyChange(idx, e.target.value)}
                        placeholder={`Descreva a causa do elo anterior...`}
                        className="w-full bg-white border border-slate-200 px-2 py-1 text-xs text-slate-900 focus:outline-none focus:border-[#C49746] rounded-none font-sans"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-2 space-y-2">
                <div>
                  <label className="block text-[8.5px] font-mono font-black text-slate-400 mb-0.5 uppercase">🎯 Causa Raiz Sintetizada *</label>
                  <input
                    type="text"
                    required
                    value={newWhyRoot}
                    onChange={(e) => setNewWhyRoot(e.target.value)}
                    placeholder="Determine o desvio sistêmico crucial final..."
                    className="w-full bg-amber-50 border border-[#C49746] px-2 py-1.5 text-xs text-slate-950 focus:outline-none focus:border-[#C49746] rounded-none font-sans font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[8.5px] font-mono font-black text-slate-400 mb-0.5 uppercase">⚡ Contramedida / Ação Solucionadora *</label>
                  <input
                    type="text"
                    required
                    value={newWhyAction}
                    onChange={(e) => setNewWhyAction(e.target.value)}
                    placeholder="Evite soluções paliativas. Descreva a mudança de barreira..."
                    className="w-full bg-emerald-50 border border-emerald-400 px-2 py-1.5 text-xs text-slate-950 focus:outline-none focus:border-emerald-600 rounded-none font-sans font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Vincular a OKR</label>
                    <select
                      value={newWhyOkr}
                      onChange={(e) => setNewWhyOkr(e.target.value)}
                      className="w-full bg-white border border-slate-300 px-1 py-1 text-[9px] text-slate-900 focus:outline-none rounded-none text-left"
                    >
                      {customObjectives.map(o => (
                        <option key={o.id} value={o.id}>
                          [{o.strategyType}] {o.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Responsável Auditor</label>
                    <input
                      type="text"
                      value={newWhyResp}
                      onChange={(e) => setNewWhyResp(e.target.value)}
                      className="w-full bg-white border border-slate-300 px-1.5 py-1 text-xs text-slate-900 focus:outline-none rounded-none font-sans"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#C49746] hover:bg-amber-700 text-white font-mono text-[9px] font-bold py-2.5 px-3 uppercase tracking-wider text-center cursor-pointer transition shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] border-2 border-slate-900 mt-2"
              >
                ✓ Gravar Estudo de Caso
              </button>
            </form>
          </div>
        )}
      </div>

      {/* RIGHT COLUMN: RECURSIVE VISUAL FLOW ESCALATOR TREE */}
      <div className="lg:col-span-8">
        {(() => {
          if (!activeStudy) {
            return (
              <div className="bg-slate-50 border border-dashed border-slate-300 p-12 text-center h-[520px] flex flex-col justify-center items-center">
                <span className="text-slate-400 block font-serif italic mb-1 text-sm">Nenhuma análise de causa raiz selecionada</span>
                <p className="text-[10.5px] text-slate-500">Selecione uma na lista lateral ou crie uma nova para visualizar e editar o encadeamento dinamicamente.</p>
              </div>
            );
          }

          const currentWhys = getActiveStudyWhysList(activeStudy);
          const linkedOkr = customObjectives.find(o => o.id === activeStudy.linkedObjectiveId);

          return (
            <div className="bg-[#FAF9F5]/30 border-2 border-slate-900 p-5 sm:p-7 text-left relative shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
              
              {/* Header inside the active study with convert or delete */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 pb-4 mb-6 gap-3">
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[8px] font-mono bg-amber-500 text-slate-900 border border-amber-600 px-2.5 py-0.5 font-bold uppercase tracking-wider">
                      Método dos 5 Porquês (Root Cause Map)
                    </span>
                    <span className="text-[8px] font-mono bg-emerald-100 text-emerald-800 border border-emerald-300 px-1.5 py-0.5 uppercase font-bold">
                      Cadeia Ativa: {currentWhys.length} Níveis
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <input 
                      type="text"
                      value={activeStudy.title}
                      onChange={(e) => handleUpdateActiveStudyField("title", e.target.value)}
                      className="text-sm sm:text-base font-sans font-black uppercase text-slate-900 bg-transparent border-b border-dashed border-transparent hover:border-slate-400 focus:border-slate-900 focus:bg-white px-1 py-0.5 select-all focus:outline-none w-full max-w-md"
                      title="Clique para editar o título rápido"
                    />
                  </div>
                </div>

                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={() => handleConvertFiveWhysToChg(activeStudy)}
                    className="bg-[#047857] hover:bg-[#065f46] text-white font-mono text-[9px] font-bold py-1.5 px-3 uppercase tracking-wider transition cursor-pointer shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] border-2 border-slate-900 flex items-center gap-1"
                    title="Alinha esta causa raiz a uma nova mudança acionável na fábrica ou sistema"
                  >
                    <span>⚡ Gerar Mudança (RFC)</span>
                  </button>
                </div>
              </div>

              {/* HIGHLY INTERACTIVE VERTICAL TREE ACCENT FLOW */}
              <div className="space-y-4 max-w-xl mx-auto py-2 relative">
                
                {/* 1. Problem Node Box (Problem Statement) */}
                <div className="bg-rose-55/10 border-2 border-rose-900 p-4 shadow-sm relative">
                  <span className="absolute -top-3 left-4 px-2 py-0.5 text-[8.5px] font-mono font-black bg-[#E11D48] text-white border-2 border-rose-950">
                    O PROBLEMA / EVENTO INDESEJADO
                  </span>
                  <div className="mt-1">
                    <textarea
                      value={activeStudy.problem}
                      onChange={(e) => handleUpdateActiveStudyField("problem", e.target.value)}
                      rows={2}
                      className="text-xs font-serif font-bold italic text-rose-950 w-full bg-transparent border border-transparent hover:border-rose-300 focus:border-rose-900 focus:bg-white p-1 focus:outline-none resize-none leading-relaxed"
                      placeholder="Descreva o problema ou gargalo operacional observado..."
                    />
                  </div>
                </div>

                {/* Vertical interactive Whys lists */}
                <AnimatePresence>
                  {currentWhys.map((whyText, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.25 }}
                      className="space-y-4"
                    >
                      {/* Flow Connector Arrow */}
                      <div className="flex justify-center select-none text-center">
                        <div className="flex flex-col items-center">
                          <div className="h-4 w-0.5 bg-slate-300 border-l border-dashed border-slate-400"></div>
                          <span className="bg-slate-100 border text-slate-500 font-mono text-[7.5px] font-bold px-1.5 py-0.5 uppercase tracking-tighter">
                            Por que ocorreu o nível seguinte?
                          </span>
                        </div>
                      </div>

                      {/* Why Answer Box */}
                      <div className="bg-white border-2 border-slate-900 hover:border-[#C49746] focus-within:border-[#C49746] p-3.5 shadow-[2px_2px_0px_rgba(0,0,0,1)] relative flex gap-3 pb-3">
                        
                        {/* Number Indicator badge */}
                        <div className="flex flex-col justify-start items-center shrink-0">
                          <span className="text-[10px] w-6 h-6 rounded-full bg-amber-500 text-slate-950 border border-slate-900 font-mono font-black flex items-center justify-center">
                            Y{index + 1}
                          </span>
                        </div>

                        {/* Text and controller */}
                        <div className="flex-grow text-left">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] font-mono text-slate-400 font-bold uppercase">
                              {index === 0 ? "Sintoma Físico Direto" : 
                               index === 1 ? "Causa Operacional Próxima" :
                               index === 2 ? "Desvio de Equipamento / Controle" :
                               index === 3 ? "Processo / Falha Humana / Método" :
                               index === 4 ? "Causa Organizacional Crônica" : 
                               `Nível ${index + 1} - Desdobramento do Elo`}
                            </span>
                            {currentWhys.length > 1 && (
                              <button
                                onClick={() => handleRemoveWhyFromActiveStudy(index)}
                                className="text-[8px] font-mono font-bold text-red-650 hover:text-red-800 hover:underline cursor-pointer uppercase"
                                title="Apaga este nível do encadeamento"
                              >
                                ✕ Excluir Elo
                              </button>
                            )}
                          </div>
                          
                          <input
                            type="text"
                            value={whyText}
                            onChange={(e) => handleUpdateActiveStudyWhyIndex(index, e.target.value)}
                            placeholder="Descreva a causa detalhada deste ponto..."
                            className="text-xs text-slate-800 leading-snug font-sans w-full bg-transparent border-b border-transparent focus:border-amber-500 px-1 py-0.5 focus:outline-none"
                          />
                        </div>

                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {/* Interactive Button to chain more whys dynamically! */}
                <div className="flex justify-center pt-3 select-none">
                  <button
                    onClick={handleAddWhyToActiveStudy}
                    className="px-3.5 py-1.5 bg-amber-50 hover:bg-amber-100 border-2 border-[#C49746] text-amber-900 text-[10px] font-mono font-bold uppercase transition flex items-center gap-1 shadow-[2px_2px_0px_rgba(196,151,70,0.3)] cursor-pointer"
                  >
                    <span>➕ Adicionar nível de Porquê (Encadear Y{currentWhys.length + 1})</span>
                  </button>
                </div>

                {/* Final Connection Bridge divider */}
                <div className="py-2 flex items-center justify-center select-none">
                  <div className="border-t-2 border-dashed border-slate-350 flex-grow"></div>
                  <span className="bg-amber-950 text-white font-mono font-black text-[8px] px-3 py-0.5 uppercase tracking-wider block border border-slate-900">
                    SÍNTESE DO DIAGNÓSTICO
                  </span>
                  <div className="border-t-2 border-dashed border-slate-350 flex-grow"></div>
                </div>

                {/* 2. ROOT CAUSE SUMMARY BLOCK */}
                <div className="bg-[#FFFDF3] border-3 border-[#C49746] p-4 shadow-[2px_2px_0px_rgba(0,0,0,1)] text-left relative">
                  <span className="absolute -top-3 left-4 px-2 py-0.5 text-[8.5px] font-mono font-black bg-[#C49746] text-white border-2 border-amber-800 uppercase">
                    🎯 Causa Raiz Mapeada (Intervenção Sistêmica)
                  </span>
                  <div className="mt-1">
                    <textarea
                      value={activeStudy.rootCause}
                      onChange={(e) => handleUpdateActiveStudyField("rootCause", e.target.value)}
                      rows={2}
                      className="text-xs font-bold font-sans text-slate-900 w-full bg-transparent border border-transparent hover:border-amber-300 focus:border-[#C49746] focus:bg-white p-1 focus:outline-none resize-none leading-relaxed"
                      placeholder="Determine qual a causa raiz sistêmica por trás de toda a cadeia..."
                    />
                  </div>
                </div>

                {/* 3. PROPOSED DEFINITIVE ACTION BLOCK */}
                <div className="bg-emerald-50 border-3 border-[#047857] p-4 shadow-[2px_2px_0px_rgba(0,0,0,1)] text-left relative mt-5">
                  <span className="absolute -top-3 left-4 px-2 py-0.5 text-[8.5px] font-mono font-black bg-[#047857] text-white border-2 border-emerald-800 uppercase">
                    ⚡ Contramedida proposed (Mudança Operacional)
                  </span>
                  <div className="mt-1">
                    <textarea
                      value={activeStudy.proposedAction}
                      onChange={(e) => handleUpdateActiveStudyField("proposedAction", e.target.value)}
                      rows={2}
                      className="text-xs font-black font-sans text-emerald-950 w-full bg-transparent border border-transparent hover:border-emerald-300 focus:border-emerald-600 focus:bg-white p-1 focus:outline-none resize-none leading-relaxed"
                      placeholder="Descreva o plano de ação técnico corretivo definitivo que evitará a reincidência..."
                    />
                  </div>

                  {/* Metadata linkings */}
                  <div className="mt-3.5 pt-3 border-t border-emerald-300/30 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[9.5px] font-mono text-slate-500">
                    <div>
                      <span className="block uppercase text-[7.5px] text-slate-400 font-bold">Vínculo com OKR Estratégico:</span>
                      <select
                        value={activeStudy.linkedObjectiveId}
                        onChange={(e) => handleUpdateActiveStudyField("linkedObjectiveId", e.target.value)}
                        className="bg-transparent border-b border-dashed border-slate-350 font-sans font-bold text-slate-900 focus:outline-none mt-0.5 text-[10px] w-full"
                      >
                        {customObjectives.map(o => (
                          <option key={o.id} value={o.id}>
                            [{o.strategyType}] {o.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <span className="block uppercase text-[7.5px] text-slate-400 font-bold">Líder do Estudo / Belt Responsável:</span>
                      <input
                        type="text"
                        value={activeStudy.responsible}
                        onChange={(e) => handleUpdateActiveStudyField("responsible", e.target.value)}
                        className="bg-transparent border-b border-dashed border-slate-350 font-sans font-bold text-slate-900 focus:outline-none mt-0.5 text-[10px] w-full"
                      />
                    </div>
                  </div>
                </div>

              </div>

            </div>
          );
        })()}
      </div>

    </div>
  );
}
