import React, { useState, useEffect } from "react";
import { UsabilityMode } from "../domain/usabilityMode";
import AdminPanel from "./AdminPanel";
import { 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  CheckCircle2, 
  Activity, 
  Zap, 
  Users, 
  Cpu, 
  FileText, 
  TrendingUp, 
  DollarSign,
  Layers,
  Lock,
  Settings,
  LogOut,
  MessageSquare,
  Building,
  Plus,
  Trash,
  CreditCard,
  Check,
  Search,
  Bell,
  Clock,
  Briefcase,
  AlertCircle,
  HelpCircle,
  TrendingDown,
  RefreshCw,
  Eye,
  CheckCircle,
  UserCheck
} from "lucide-react";
import MapeadorInicialProcessos from "./MapeadorInicialProcessos";

interface PublicSalesLandingProps {
  onStartTrial?: () => void;
  globalCompanies?: any[];
  setGlobalCompanies?: (companies: any[]) => void;
  globalProjects?: any[];
  setProjects?: (projects: any[]) => void;
  currentCargo?: string;
  setCurrentCargo?: (cargo: any) => void;
  setCurrentWorkspaceView?: (view: any) => void;
  onLoginSuccess?: (user: any, companyEnabledViews?: string[], companyInfo?: any) => void;
  activeUser?: any;
}

export default function PublicSalesLanding({ 
  onStartTrial, 
  globalCompanies = [], 
  setGlobalCompanies,
  globalProjects = [],
  setProjects,
  currentCargo = "Analista Júnior",
  setCurrentCargo,
  setCurrentWorkspaceView,
  onLoginSuccess,
  activeUser
}: PublicSalesLandingProps) {
  
  // Tab Routing inside the Landing Component Page
  // "LEADS" (Institutional/Sales/Form), "CLIENT_PORTAL" (Client Private Zone), "OWNER_PORTAL" (Tool Owner Private Zone)
  const [activeTab, setActiveTab] = useState<"LEADS" | "CLIENT_PORTAL" | "OWNER_PORTAL">("LEADS");

  // Visitor interactive states for value calculator (Leads tab)
  const [visitorSector, setVisitorSector] = useState("FINANCE");
  const [visitorVolume, setVisitorVolume] = useState<number>(2500); // Items processed monthly
  const [visitorDefectRatePercent, setVisitorDefectRatePercent] = useState<number>(8); // 8% error rate

  // New Audience Choice & Customized Diagnostics States
  const [selectedAudienceType, setSelectedAudienceType] = useState<"LEIGO" | "ESPECIALISTA">("LEIGO");
  const [laymanAnswers, setLaymanAnswers] = useState({
    pain: "gargalo",
    measurement: "sentimento",
    teamSize: "1-5"
  });
  const [specialistAnswers, setSpecialistAnswers] = useState({
    methodology: "nenhuma",
    stability: "alta_var",
    engineeringMeta: "lead_time"
  });
  // Advanced specialist/queue parameters
  const [serviceTime, setServiceTime] = useState<number>(15); // minutes per item
  const [serviceVariance, setServiceVariance] = useState<number>(5); // variance in minutes
  const [serversCount, setServersCount] = useState<number>(2); // number of operators/servers

  // Lead capture form state
  const [leadForm, setLeadForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    role: "Analista",
    interest: "DMAIC & Processos",
    message: ""
  });
  const [leadStatusMessage, setLeadStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Leads Database (stored in localStorage)
  const [leads, setLeads] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_leads");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "lead-1", name: "Carlos Henrique Souza", email: "carlos.souza@ambev.com.br", phone: "(11) 98122-3044", company: "Ambev Logistics", role: "Coordenador de Excelência", segment: "LOGISTICS", interest: "Teoria de Filas (G/G/c)", status: "Em Atendimento", date: "2026-06-07T10:30:00Z" },
      { id: "lead-2", name: "Beatriz Nogueira Prado", email: "beatriz.nogueira@itau.com.br", phone: "(11) 97321-4491", company: "Itaú Unibanco", role: "Gerente Operacional", segment: "FINANCE", interest: "Simplex / Alocação Ótima", status: "Proposta Enviada", date: "2026-06-08T08:15:00Z" },
      { id: "lead-3", name: "Marcio Roberto Dias", email: "marcio.dias@petrobras.com.br", phone: "(21) 99872-1102", company: "Petrobras S.A.", role: "Lead Engineer", segment: "MANUFACTURING", interest: "Mapeamento VSM / CEP", status: "Pendente", date: "2026-06-08T11:40:00Z" }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_leads", JSON.stringify(leads));
  }, [leads]);

  // Client Area simulation login and details
  const [selectedClientCompanyId, setSelectedClientCompanyId] = useState<string>("comp-itau");
  const [loggedClient, setLoggedClient] = useState<any | null>(null);
  const [clientSection, setClientSection] = useState<"DASHBOARD" | "MAPEAMENTO_INICIAL" | "COMPRAS" | "SUPORTE" | "AJUSTAR" | "DOCS">("DASHBOARD");

  // Dynamic client registration and adjust-form states
  const [clientPortalTab, setClientPortalTab] = useState<"LOGIN" | "CADASTRO">("LOGIN");
  const [cadastroType, setCadastroType] = useState<"NOVO" | "AJUSTE">("NOVO");
  const [selectedAjusteId, setSelectedAjusteId] = useState<string>("");
  
  const [formNomeUsuario, setFormNomeUsuario] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formNomeEmpresa, setFormNomeEmpresa] = useState("");
  const [formCNPJ, setFormCNPJ] = useState("");
  const [formPlan, setFormPlan] = useState("E3I Professional");
  const [formCargo, setFormCargo] = useState("Analista Júnior");
  const [formBelt, setFormBelt] = useState("Green Belt");
  const [formSelectedModules, setFormSelectedModules] = useState<string[]>(["DIAGNOSTIC", "MAP", "KANBAN", "REPORT", "BI_STUDIO", "SIGMA_TREND"]);

  const handleSelectAjusteCompany = (companyId: string) => {
    setSelectedAjusteId(companyId);
    if (!companyId) {
      setFormNomeEmpresa("");
      setFormCNPJ("");
      setFormPlan("E3I Professional");
      setFormSelectedModules(["DIAGNOSTIC", "MAP", "KANBAN", "REPORT"]);
      return;
    }
    const comp = predefinedCompanies.find(c => c.id === companyId);
    if (comp) {
      setFormNomeEmpresa(comp.name);
      setFormPlan(comp.currentPlan);
      setFormCNPJ(comp.cnpj || "91.833.102/0001-44");
      setFormSelectedModules(comp.enabledViews || ["DIAGNOSTIC", "MAP", "KANBAN"]);
      setFormNomeUsuario("Diretor " + comp.name.split(" ")[0]);
      setFormEmail("diretoria@sixsigma.com");
    }
  };

  // Simulated Client Purchases & SLA requests
  const [clientPurchases, setClientPurchases] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_client_purchases");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "p-1", companyId: "comp-itau", item: "Consultoria Master Belt Trimestral", price: 4500, date: "2026-06-05T14:00:00Z", paymentStatus: "Pago" },
      { id: "p-2", companyId: "comp-ambev", item: "Add-on Licença Black Belt Extra", price: 1500, date: "2026-06-06T11:20:00Z", paymentStatus: "Processado" }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_client_purchases", JSON.stringify(clientPurchases));
  }, [clientPurchases]);

  const [supportTickets, setSupportTickets] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_support_tickets");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "t-1", companyId: "comp-itau", subject: "Dúvida na modelagem stocástica", message: "Gostaria de entender se os dados de setup podem flutuar em sigma.", priority: "ALTA", status: "Respondido", response: "Sim, os setups podem simular desvios estatísticos informando a coluna setup na matriz.", date: "2026-06-06T15:00:00Z" }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_support_tickets", JSON.stringify(supportTickets));
  }, [supportTickets]);

  // Tool Owner Area simulation login
  const [ownerPassword, setOwnerPassword] = useState("");
  const [loggedOwner, setLoggedOwner] = useState<boolean>(false);
  const [ownerSection, setOwnerSection] = useState<"LEADS" | "LICENCAS" | "FINANCEIRO" | "LOGS">("LEADS");
  const [ownerSearchQuery, setOwnerSearchQuery] = useState("");

  // Simulated system logs for Security and audits
  const [systemLogs, setSystemLogs] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_system_logs");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "log-1", timestamp: "2026-06-08T09:00:00Z", ip: "177.34.120.10", user: "Beatriz Prado", action: "Login Cliente", details: "Painel Itaú Unibanco inicializado via OAuth virtual" },
      { id: "log-2", timestamp: "2026-06-08T10:15:00Z", ip: "189.44.20.15", user: "E3I Engine", action: "Auditoria SLA", details: "Monitoramento de integridade estocástica OK" },
      { id: "log-3", timestamp: "2026-06-08T11:40:00Z", ip: "172.16.0.4", user: "Marcio Dias (Lead)", action: "Envio de Lead", details: "Lead registrado na fila prioritária de CRM" },
      { id: "log-4", timestamp: "2026-06-08T12:00:00Z", ip: "200.18.250.32", user: "E3I Admin Team", action: "Acesso de Gestão", details: "Visualização do faturamento anualizado consolidado" }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_system_logs", JSON.stringify(systemLogs));
  }, [systemLogs]);

  // Local hook states specifically for supporting the AdminPanel's operations in Owner Portal
  const [adminEnabledViews, setAdminEnabledViews] = useState<string[]>(["DIAGNOSTIC", "MAP", "DMAIC", "BPM", "OR_HUB", "REPORT", "KANBAN", "ENTERPRISE_STUDIO", "CYBER_SECURITY"]);
  const [adminCharter, setAdminCharter] = useState<any>({
    projectName: "Otimização Estocástica de Processo",
    champion: "Diretoria S.A.",
    blackBelt: "E3I Admin",
    financialGoal: "Reduzir desperdício operacional de 8% para menos de 2%",
    dateStart: "2026-06-01",
    dateEnd: "2026-09-01"
  });
  const [adminSipoc, setAdminSipoc] = useState<any>({
    suppliers: "Fornecedor Materiais, Canal de Leads",
    inputs: "Ordens de Serviço, Pedidos de Cotação",
    process: "Triagem -> Análise -> Proposta -> Fechamento",
    outputs: "Capacidade Otimizada, ROI Maximizado",
    customers: "Clientes Finais Corporativos"
  });
  const [adminControlPlans, setAdminControlPlans] = useState<any[]>([]);
  const [adminArrivalRate, setAdminArrivalRate] = useState<number>(12);
  const [adminSteps, setAdminSteps] = useState<any[]>([]);
  const [adminUsabilityMode, setAdminUsabilityMode] = useState<UsabilityMode>("EXPERT");
  const [adminUsabilityLocked, setAdminUsabilityLocked] = useState<boolean>(false);

  // Value calculator calculations
  const estimatedAnnualWaste = (visitorVolume * (visitorDefectRatePercent / 100)) * 175 * 12; // BRL 175 reworked item average cost
  const estimatedSavingsAfterE3I = estimatedAnnualWaste * 0.75; // 75% savings target

  const sectorLabels: Record<string, string> = {
    MANUFACTURING: "Indústria & SMT",
    FINANCE: "Finanças & Contas PJ",
    TECHNOLOGY: "TI & Software SaaS",
    HEALTHCARE: "Saúde & Clínicas",
    LOGISTICS: "Logística / Transportes",
    RETAIL: "Varejo & E-commerce",
    SERVICES: "Serviços & Consultoria",
    CONSTRUCTION: "Construção & Infraestrutura",
    EDUCATION: "Educação & EdTech",
    ENERGY: "Energia & Utilities",
    AGRIBUSINESS: "Agronegócio & Agro",
    PUBLIC_SECTOR: "Setor Público & Governo"
  };

  // Persistent and modifiable client licenses database
  const [predefinedCompanies, setPredefinedCompanies] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_predefined_companies");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "comp-itau", name: "Itaú Unibanco S.A.", industry: "Setor Financeiro", logoLetter: "I", currentPlan: "E3I Professional", activeSla: "Professional - 8h SLA", enabledViews: ["DIAGNOSTIC", "MAP", "KANBAN", "REPORT", "BI_STUDIO", "SIGMA_TREND"] },
      { id: "comp-ambev", name: "Ambev Logística Global", industry: "Manufatura e Bebidas", logoLetter: "A", currentPlan: "E3I Enterprise Black-Belt", activeSla: "Enterprise - SLA Dedicado", enabledViews: ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "REPORT", "BI_STUDIO", "SIGMA_TREND", "ROI_DASHBOARD"] },
      { id: "comp-petrobras", name: "Petrobras Distribuição", industry: "Indústria & Energia", logoLetter: "P", currentPlan: "E3I Starter", activeSla: "Starter - 48h SLA", enabledViews: ["DIAGNOSTIC", "MAP", "KANBAN", "BI_STUDIO"] }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_predefined_companies", JSON.stringify(predefinedCompanies));
  }, [predefinedCompanies]);

  const mockPredefinedCompanies = predefinedCompanies;

  // Helper to append a system log safely
  const appendSystemLog = (action: string, user: string, details: string) => {
    const newLog = {
      id: "log-" + Date.now(),
      timestamp: new Date().toISOString(),
      ip: "189.33." + Math.floor(Math.random() * 255) + "." + Math.floor(Math.random() * 255),
      user,
      action,
      details
    };
    setSystemLogs(prev => [newLog, ...prev]);
  };

  // Handle lead submission
  const onSubmitLeadForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadForm.name || !leadForm.email || !leadForm.company) {
      setLeadStatusMessage({ type: "error", text: "Por favor preencha Nome, Email e Empresa." });
      return;
    }

    // Calculate dynamic diagnostic details for Layman
    const getLaymanDiagnostic = () => {
      let score = 95;
      let advice = "";
      if (laymanAnswers.pain === "gargalo") {
        score -= 15;
        advice = "Sua operação apresenta gargalos no fluxo de entrega. Recomendamos mapear as etapas de valor (VSM) e balancear as restrições operacionais.";
      } else if (laymanAnswers.pain === "qualidade") {
        score -= 20;
        advice = "O desperdício por erros e retrabalho é o principal ponto crítico. Sugerimos implantar checagens rápidas (poka-yoke) e gráficos de controle Shewhart.";
      } else {
        score -= 10;
        advice = "A falta de processos claros sobrecarrega o time. Comece estruturando os limites de trabalho (SIPOC) e automatizando a triagem de tarefas.";
      }

      if (laymanAnswers.measurement === "sentimento") {
        score -= 25;
        advice += " Medir por 'sentimento' impede melhorias consistentes; estabeleça indicadores chave (KPIs) numéricos imediatamente.";
      } else if (laymanAnswers.measurement === "excel") {
        score -= 10;
        advice += " Planilhas isoladas dificultam governança em tempo real. Mover os fluxos para uma central multi-tenant estruturada trará mais transparência.";
      }

      if (laymanAnswers.teamSize === "mais_20") {
        score -= 10;
      }

      return {
        score: Math.max(30, score),
        advice,
        answers: { ...laymanAnswers }
      };
    };

    // Calculate dynamic diagnostic details for Specialist
    const getSpecialistDiagnostic = () => {
      let score = 90;
      let advice = "";

      // Queue Utilization (rho = lambda / (c * mu))
      // 160 operating hours per month * 60 minutes = 9600 working minutes per month
      const lambda = visitorVolume / 9600; // arrivals per minute
      const mu = 1 / (serviceTime || 1); // processing rate per minute
      const c = serversCount || 1;
      const utilization = (lambda / (c * mu)) * 100;

      if (specialistAnswers.methodology === "nenhuma") {
        score -= 25;
        advice = "Falta de metodologia LSS padronizada. Iniciar estruturação de Projetos DMAIC trará estabilidade estatística imediata.";
      } else if (specialistAnswers.methodology === "kaizen") {
        score -= 10;
        advice = "Melhoria Kaizen reativa presente. Recomenda-se integrar modelagem de Teoria de Filas estruturada para mitigar causas comuns.";
      } else {
        advice = "Sua empresa já possui maturidade em DMAIC. Focar em controle linear dinâmico (Simplex) e simulação estocástica otimizará os custos.";
      }

      if (specialistAnswers.stability === "alta_var") {
        score -= 20;
        advice += " Alta variabilidade identificada. Aplicar cartas de controle de processo (CEP) nas etapas restritivas para remover causas especiais.";
      }

      if (utilization >= 90) {
        score -= 20;
        advice += ` Alerta Crítico: Ocupação do sistema calculada em ${utilization.toFixed(1)}%. Alto risco de gargalo estocástico infinito (Equação de Kingman).`;
      } else {
        advice += ` Ocupação do sistema calculada em um nível seguro de ${utilization.toFixed(1)}%.`;
      }

      return {
        score: Math.max(20, score),
        advice,
        answers: {
          ...specialistAnswers,
          serviceTime,
          serviceVariance,
          serversCount,
          utilizationPercent: Number(utilization.toFixed(1))
        }
      };
    };

    const diagnosticResult = selectedAudienceType === "LEIGO" ? getLaymanDiagnostic() : getSpecialistDiagnostic();

    const newLead = {
      id: "lead-" + Date.now().toString(36),
      name: leadForm.name,
      email: leadForm.email,
      phone: leadForm.phone || "(Sem Telefone)",
      company: leadForm.company,
      role: leadForm.role,
      segment: visitorSector,
      interest: leadForm.interest,
      status: "Pendente",
      date: new Date().toISOString(),
      diagnosticData: {
        audienceType: selectedAudienceType,
        sector: visitorSector,
        volume: visitorVolume,
        defectRatePercent: visitorDefectRatePercent,
        estimatedAnnualWaste,
        estimatedSavingsAfterE3I,
        score: diagnosticResult.score,
        advice: diagnosticResult.advice,
        answers: diagnosticResult.answers
      }
    };

    setLeads(prev => [newLead, ...prev]);
    appendSystemLog("Envio de Lead", leadForm.name, `Lead capturado com diagnóstico de ${selectedAudienceType} integrado. Desperdício: R$ ${Math.round(estimatedAnnualWaste).toLocaleString("pt-BR")}/ano.`);
    
    setLeadForm({
      name: "",
      email: "",
      phone: "",
      company: "",
      role: "Analista",
      interest: "DMAIC & Processos",
      message: ""
    });
    setLeadStatusMessage({ 
      type: "success", 
      text: "Seu contato e interesse foram registrados com sucesso! Nosso consultor Black Belt entrará em contato em até 4 horas." 
    });

    // Remove feedback alert after 6s
    setTimeout(() => {
      setLeadStatusMessage(null);
    }, 6000);
  };

  // Client simulated login
  const handleClientLogin = (comp: any) => {
    setLoggedClient(comp);
    setClientSection("DASHBOARD");
    appendSystemLog("Login Cliente", comp.name, "Acesso efetuado na Área Privada do Cliente");
  };

  const handleCadastroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cadastroType === "NOVO") {
      if (!formNomeUsuario || !formNomeEmpresa || !formCNPJ) {
        alert("Por favor, preencha o Nome, Empresa e CNPJ do contrato.");
        return;
      }
      const newId = "comp-" + Math.random().toString(36).substring(2, 7);
      const newCompany = {
        id: newId,
        name: formNomeEmpresa,
        industry: "Setor Corporativo",
        logoLetter: formNomeEmpresa.charAt(0).toUpperCase() || "C",
        currentPlan: formPlan,
        cnpj: formCNPJ,
        activeSla: formPlan.includes("Starter") ? "Starter - 48h SLA" : "Professional - 8h SLA",
        enabledViews: formSelectedModules
      };
      setPredefinedCompanies(prev => [...prev, newCompany]);
      setLoggedClient(newCompany);
      setClientSection("DASHBOARD");
      appendSystemLog("Contrato Criado", formNomeEmpresa, `Novo cadastro realizado por ${formNomeUsuario}`);
    } else {
      if (!selectedAjusteId) {
        alert("Por favor, selecione qual Contrato deseja ajustar.');");
        return;
      }
      if (!formNomeEmpresa || !formCNPJ) {
        alert("Nome da empresa e CNPJ são obrigatórios para atualizar.");
        return;
      }
      setPredefinedCompanies(prev => prev.map(c => {
        if (c.id === selectedAjusteId) {
          return {
            ...c,
            name: formNomeEmpresa,
            cnpj: formCNPJ,
            currentPlan: formPlan,
            enabledViews: formSelectedModules
          };
        }
        return c;
      }));
      const updatedCompany = {
        id: selectedAjusteId,
        name: formNomeEmpresa,
        logoLetter: formNomeEmpresa.charAt(0).toUpperCase() || "C",
        currentPlan: formPlan,
        cnpj: formCNPJ,
        activeSla: formPlan.includes("Starter") ? "Starter - 48h SLA" : "Professional - 8h SLA",
        enabledViews: formSelectedModules
      };
      setLoggedClient(updatedCompany);
      setClientSection("DASHBOARD");
      appendSystemLog("Contrato Ajustado", formNomeEmpresa, `Ajustes efetuados por ${formNomeUsuario}`);
    }
  };

  const handleClientAddUpgrade = (upgradeName: string, price: number) => {
    if (!loggedClient) return;

    const newPurchase = {
      id: "p-" + Math.random().toString(36).substring(2, 7),
      companyId: loggedClient.id,
      item: upgradeName,
      price: price,
      date: new Date().toISOString(),
      paymentStatus: "Pago"
    };

    setClientPurchases(prev => [newPurchase, ...prev]);
    appendSystemLog("Compra Cliente", loggedClient.name, `Adquiriu: ${upgradeName} (R$ ${price})`);
    alert(`Compra de "${upgradeName}" realizada com sucesso! Ativado instantaneamente e integrado na assinatura.`);
  };

  const handleCreateSupportTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedClient) return;
    const subjInput = (e.currentTarget.elements.namedItem("ticketSubject") as HTMLInputElement).value;
    const msgInput = (e.currentTarget.elements.namedItem("ticketMsg") as HTMLTextAreaElement).value;
    const priority = (e.currentTarget.elements.namedItem("ticketPriority") as HTMLSelectElement).value;

    if (!subjInput || !msgInput) {
      alert("Por favor preencha todos os campos do ticket");
      return;
    }

    const newTicket = {
      id: "t-" + Date.now(),
      companyId: loggedClient.id,
      subject: subjInput,
      message: msgInput,
      priority: priority,
      status: "Aberto",
      response: "",
      date: new Date().toISOString()
    };

    setSupportTickets(prev => [newTicket, ...prev]);
    appendSystemLog("Novo Ticket Suporte", loggedClient.name, `Chamado prioritário #${priority}: ${subjInput}`);
    alert("Ticket aberto com sucesso! Aguarde contato sob o nosso SLA contratual.");
    e.currentTarget.reset();
  };

  // Active client company's projects simulated list for display
  const getClientProjects = (compId: string) => {
    // Attempt to read from globalProjects or fallback to realistic mock Lean Six Sigma pipeline
    const list = globalProjects.filter(p => p.companyId === compId);
    if (list.length > 0) return list;

    // Fixed mock projects per simulated company
    if (compId === "comp-itau") {
      return [
        { id: "proj-it-1", name: "Otimização de Retenção e Faturamento de Contas", objective: "Reduzir o tempo de análise de faturas em 40% com ferramentas de PO", status: "Em Progresso", phase: "Analyze (Análise)" },
        { id: "proj-it-2", name: "Redução de Desperdício em setup de Cobrança", objective: "Diminuir erros de faturamento repetidos e automatizar fluxo de ordens", status: "Concluído", phase: "Control (Controles CEP)" }
      ];
    } else if (compId === "comp-ambev") {
      return [
        { id: "proj-am-1", name: "Minimização de Setup SMT na Linha Logística", objective: "Prevenir gargalos no despacho físico aplicando Teoria de Filas G/G/c", status: "Em Progresso", phase: "Improve (Melhoria ativa)" }
      ];
    } else {
      return [
        { id: "proj-fallback", name: "Diagnóstico de Processos da Franquia", objective: "Varredura preliminar para detectar processos de baixa eficiência", status: "Planejado", phase: "Define (Definição)" }
      ];
    }
  };

  // E3I host logging team authentications
  const handleOwnerLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ownerPassword === "E3I#BlackBelt&2026" || ownerPassword === "admin") {
      setLoggedOwner(true);
      setOwnerPassword("");
      appendSystemLog("Login Owner", "E3I Admin S.A.", "Entrada autorizada na Área Administrativa do Tool-Owner");
    } else {
      alert("Senha de Administrador incorreta! Use a credencial segura 'E3I#BlackBelt&2026' para homologar os acessos.");
    }
  };

  // Change lead status in CRM
  const handleUpdateLeadStatus = (leadId: string, newStatus: string) => {
    setLeads(prev => prev.map(l => l.id === leadId ? { ...l, status: newStatus } : l));
    const targetLead = leads.find(l => l.id === leadId);
    appendSystemLog("Atualização CRM", "E3I Admin S.A.", `Lead "${targetLead?.name}" alterado para status: ${newStatus}`);
  };

  const handleDeleteLead = (leadId: string) => {
    if (!confirm("Confirmar a remoção permanente deste Lead do CRM?")) return;
    setLeads(prev => prev.filter(l => l.id !== leadId));
    appendSystemLog("Remoção CRM", "E3I Admin S.A.", `Lead ID: ${leadId} excluído do cadastro`);
  };

  // Calculate simulated revenue from subscription price tiering + upgrades purchases
  const calculateTotalFaturamento = () => {
    let subscriptionBase = 12900; // Base baseline
    const upgradesTotal = clientPurchases.reduce((acc, curr) => acc + curr.price, 0);
    return subscriptionBase + upgradesTotal;
  };

  const filteredLeads = leads.filter(l => {
    if (!ownerSearchQuery) return true;
    return l.name.toLowerCase().includes(ownerSearchQuery.toLowerCase()) || 
           l.company.toLowerCase().includes(ownerSearchQuery.toLowerCase()) ||
           l.interest.toLowerCase().includes(ownerSearchQuery.toLowerCase());
  });

  const plans = [
    {
      name: "E3I Starter",
      price: "850",
      description: "Ideal para analistas que buscam mapear seus fluxos de valor de forma ágil e estruturar seus primeiros roteiros DMAIC básicos.",
      features: [
        "Mapeamento de Processos (VSM) Básicos",
        "Até 3 Projetos DMAIC Ativos",
        "Cadastro de 2 Empresas/Clientes",
        "Formulários SIPOC Estáticos",
        "Suporte por E-mail (SLA 48h)"
      ],
      cta: "Começar do Básico",
      isPopular: false
    },
    {
      name: "E3I Professional",
      price: "2.390",
      description: "O passaporte completo para Green Belts e equipes corporativas de excelência operacional que precisam de modelagens estatísticas de fila e relatórios.",
      features: [
        "Mapeamento VSM Avançado Ilimitado",
        "Simulação Estocástica de Teoria de Filas (G/G/c)",
        "Co-Piloto de IA para Geração de Planos",
        "Termos de Abertura (Project Charter) Integrados",
        "SLA de 8h Garantido"
      ],
      cta: "Ativar Modo Especialista",
      isPopular: true
    },
    {
      name: "E3I Enterprise Black-Belt",
      price: "Sob Consulta",
      description: "Alta densidade estatística e auditorias de cibersegurança completas para corporações globais com suporte dedicado por Master Black Belts.",
      features: [
        "Tudo do Plano Professional",
        "Alocação Linear de Mix Produtivo Ótimo (Simplex)",
        "Gráficos de Controle Estatístico CEP Shewhart",
        "Segurança com MFA e Suporte Consultivo Mensal",
        "SLA Dedicado de 1h em Tempo Real"
      ],
      cta: "Falar com Consultores",
      isPopular: false
    }
  ];

  return (
    <div className="bg-[#FAF9F6] text-[#1A1A1A] animate-fade-in text-left selection:bg-amber-100 min-h-screen font-sans flex flex-col justify-between">
      
      {/* GLOBAL HIGH-CONTRAST PORTAL HEADER */}
      <header className="border-b-2 border-[#1A1A1A] bg-[#FAF9F6] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 md:px-8 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2">
            <div className="bg-[#1A1A1A] text-white p-1 text-xs font-black tracking-widest rounded-none">E3I</div>
            <div className="flex flex-col">
              <span className="text-sm font-serif font-extrabold text-slate-900 leading-tight">E3I PROCESSOS INTELIGENTES</span>
              <span className="text-[9.5px] font-mono tracking-widest text-[#C49746] font-bold">SUÍTE CORPORATIVA</span>
            </div>
          </div>

          {/* SECURE VIEW NAVIGATION MENU */}
          <div className="flex flex-wrap items-center gap-2 bg-[#FAF8F5] border border-slate-300 p-1.5 rounded-none">
            <button
              onClick={() => { setActiveTab("LEADS"); }}
              className={`px-3 py-1.5 text-[10.5px] font-mono font-bold uppercase transition-all tracking-wider flex items-center gap-1.5 cursor-pointer ${
                activeTab === "LEADS" 
                  ? "bg-[#C49746] text-white" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
              }`}
            >
              <Sparkles size={11.5} />
              Home & Leads Page
            </button>

            <button
              onClick={() => { setActiveTab("CLIENT_PORTAL"); }}
              className={`px-3 py-1.5 text-[10.5px] font-mono font-bold uppercase transition-all tracking-wider flex items-center gap-1.5 cursor-pointer ${
                activeTab === "CLIENT_PORTAL" 
                  ? "bg-[#1A1A1A] text-white" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
              }`}
            >
              <Users size={11.5} />
              Área do Cliente <span className="bg-amber-100 text-amber-800 text-[8px] font-black tracking-normal px-1 rounded-sm ml-1">Privada</span>
            </button>

            <button
              onClick={() => { setActiveTab("OWNER_PORTAL"); }}
              className={`px-3 py-1.5 text-[10.5px] font-mono font-bold uppercase transition-all tracking-wider flex items-center gap-1.5 cursor-pointer ${
                activeTab === "OWNER_PORTAL" 
                  ? "bg-indigo-700 text-white" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
              }`}
            >
              <Settings size={11.5} />
              Área Tool-Owner <span className="bg-indigo-100 text-indigo-900 text-[8.5px] font-black tracking-normal px-1 rounded-sm ml-1">Auditoria</span>
            </button>
          </div>

          <div className="flex items-center gap-2.5">
            {onStartTrial && (
              <button
                onClick={onStartTrial}
                className="text-[10px] bg-[#1A1A1A] hover:bg-[#C49746] text-white px-3.5 py-1.5 font-mono font-bold uppercase tracking-widest cursor-pointer shadow-[3px_3px_0px_0px_rgba(196,151,70,1)] transition-all antialiased hover:translate-x-0.5 hover:translate-y-0.5"
              >
                Plataforma Analítica 🚀
              </button>
            )}
          </div>
        </div>
      </header>

      {/* RENDER VIEW ACCORDING TO SELECTED TAB */}
      <main className="grow">
        
        {/* ==================== 1. TELA DE LEADS & HOME INSTITUCIONAL ==================== */}
        {activeTab === "LEADS" && (
          <div className="animate-fade-in">
            {/* Hero Section */}
            <section className="py-16 md:py-24 px-6 md:px-12 bg-gradient-to-b from-[#FAF9F6] to-white border-b border-gray-200">
              <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                
                <div className="lg:col-span-7 space-y-6">
                  <div className="inline-flex items-center gap-2 bg-[#C49746]/10 text-[#C49746] px-3.5 py-1 text-xs font-bold uppercase tracking-widest border border-[#C49746]/20 rounded-full">
                    <Sparkles size={12} className="animate-pulse" />
                    CONVERSÃO LEAN SIX SIGMA &amp; INTELIGÊNCIA DE FATURAMENTO
                  </div>
                  
                  <h1 className="text-4xl md:text-6xl font-serif text-[#1A1A1A] leading-tight tracking-tight font-light">
                    Mapeamento operacional robusto e <span className="italic text-[#C49746] font-normal block sm:inline">redutores reais de despesa corporativa</span>
                  </h1>
                  
                  <p className="text-[#1A1A1A]/70 text-base md:text-lg leading-relaxed max-w-2xl font-sans">
                    A E3I é uma plataforma focada em excelência comercial que unifica a consagrada metodologia Lean Six Sigma (DMAIC), a precisão da Pesquisa Operacional e as recomendações ágeis do nosso Co-Piloto de IA Generativa.
                  </p>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                    <a
                      href="#leads-capture-form"
                      className="px-6 py-4 bg-[#C49746] hover:bg-[#a17830] text-white text-xs font-mono font-bold uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:translate-x-0.5 hover:translate-y-0.5 transition-all rounded-none"
                    >
                      Registrar Lead &amp; Demonstrar
                      <ArrowRight size={14} />
                    </a>
                    <button
                      onClick={() => {
                        const element = document.getElementById("roi-calculator-anchor");
                        if (element) element.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="px-6 py-4 border-2 border-slate-900 hover:bg-slate-50 text-slate-800 text-xs font-mono font-bold uppercase tracking-widest text-center cursor-pointer transition-all"
                    >
                      Calcular Vazamento Financeiro
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-6 pt-4 text-[11px] text-slate-500 border-t border-slate-200">
                    <span className="flex items-center gap-1.5"><ShieldCheck className="text-emerald-600" size={14} /> Sem instalação necessária</span>
                    <span className="flex items-center gap-1.5"><ShieldCheck className="text-emerald-600" size={14} /> Foco em PJs de Serviços e Engenharia de Produção</span>
                    <span className="flex items-center gap-1.5"><ShieldCheck className="text-emerald-600" size={14} /> Garantia de SLA em Contrato de Integração</span>
                  </div>
                </div>

                {/* Hero Right Visual */}
                <div className="lg:col-span-5 bg-white border-2 border-[#1A1A1A] p-6 shadow-[8px_8px_0px_0px_rgba(196,151,70,1)] rounded-none space-y-4">
                  <div className="border-b border-dashed border-slate-200 pb-3 flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-indigo-700">CONSOLE DE ENGENHARIA</span>
                    <span className="text-[9px] font-mono text-gray-400">STATUS: EM OPERAÇÃO</span>
                  </div>

                  <div className="space-y-3.5">
                    <div className="p-3 bg-slate-50 border border-slate-150 rounded-none">
                      <span className="text-[8px] font-mono text-slate-400 block">Posto Gargalo Principal (Saturação)</span>
                      <strong className="text-sm font-serif text-slate-900 block mt-0.5">Triagem de Notas de Faturamento</strong>
                      <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden">
                        <div className="bg-[#C49746] h-full w-[85%]" />
                      </div>
                      <span className="text-[9px] text-[#C49746] font-mono block mt-1">Ocupação do Posto: 85% de saturação</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 border border-slate-200 rounded-none">
                        <span className="text-[8px] font-mono text-slate-400 block font-bold">Nível Sigma</span>
                        <strong className="text-lg font-serif text-slate-900 block">4.12 σ</strong>
                        <span className="text-[9.5px] text-emerald-700 font-mono mt-0.5 block">Classe Mundial</span>
                      </div>
                      <div className="p-3 border border-slate-200 rounded-none">
                        <span className="text-[8px] font-mono text-slate-400 block font-bold">Eficiência PCE</span>
                        <strong className="text-lg font-serif text-slate-900 block">29.4%</strong>
                        <span className="text-[9.5px] text-emerald-700 font-mono mt-0.5 block">World-Class</span>
                      </div>
                    </div>

                    <div className="bg-[#FAF8F5] p-3 border border-dashed border-amber-900/15 rounded-none text-[11px] font-mono text-[#C49746]">
                      💡 <strong>Co-Piloto E3I AI:</strong> Com a contratação do nosso consultor dedicado na área do cliente, sugerimos calibrar as restrições lineares no solver.
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Testimonials and Trust Badges */}
            <section className="py-8 bg-slate-900 text-white/50 text-xs tracking-wider uppercase font-mono overflow-hidden border-b-2 border-slate-950">
              <div className="max-w-7xl mx-auto px-6 flex flex-wrap items-center justify-around gap-6 text-center">
                <span className="text-white font-extrabold flex items-center gap-1.5"><Building size={14}/> Petrobras Energia S.A.</span>
                <span className="text-white font-extrabold flex items-center gap-1.5"><CheckCircle size={14}/> Itaú Unibanco</span>
                <span className="text-white font-extrabold flex items-center gap-1.5"><Users size={14}/> Ambev Logística</span>
              </div>
            </section>

            {/* Micro-calculador de ROI segment */}
            <section id="roi-calculator-anchor" className="py-20 px-6 bg-[#FAF8F5] border-b border-gray-200">
              <div className="max-w-7xl mx-auto space-y-8">
                
                <div className="text-center max-w-3xl mx-auto space-y-3">
                  <span className="text-xs font-mono font-bold text-[#C49746] uppercase tracking-widest block">DIAGNÓSTICO &amp; CALCULADORA INTELIGENTE</span>
                  <h3 className="text-3xl md:text-4xl font-serif text-[#1A1A1A] leading-tight">Quantifique seu vazamento financeiro e planeje a melhoria</h3>
                  <p className="text-xs md:text-sm text-slate-500 font-sans leading-relaxed">
                    Selecione seu perfil de domínio técnico abaixo para obtermos métricas personalizadas e um diagnóstico guiado sob medida para seu cenário.
                  </p>
                </div>

                {/* Audience Selector Tabs */}
                <div className="flex justify-center">
                  <div className="bg-white border border-slate-300 p-1 flex gap-1 shadow-sm">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAudienceType("LEIGO");
                        appendSystemLog("Filtro Público", "Visitante", "Alterou visualizador para Pessoa Leiga");
                      }}
                      className={`px-4 sm:px-6 py-2.5 text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
                        selectedAudienceType === "LEIGO"
                          ? "bg-[#1A1A1A] text-white"
                          : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                      }`}
                    >
                      💡 Pessoa Leiga (Simples &amp; Guiado)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAudienceType("ESPECIALISTA");
                        appendSystemLog("Filtro Público", "Visitante", "Alterou visualizador para Especialista LSS");
                      }}
                      className={`px-4 sm:px-6 py-2.5 text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
                        selectedAudienceType === "ESPECIALISTA"
                          ? "bg-[#C49746] text-white"
                          : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                      }`}
                    >
                      🛡️ Especialista LSS (Avançado &amp; Testes)
                    </button>
                  </div>
                </div>

                {/* DUAL RENDER LAYOUT */}
                {selectedAudienceType === "LEIGO" ? (
                  /* =======================================================
                     1. LAYMAN VIEW: SIMPLE, INSTRUCTIONAL, STEP-BY-STEP
                     ======================================================= */
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in text-left">
                    {/* Left side: Friendly Sliders and Simple Survey */}
                    <div className="lg:col-span-6 bg-white border border-slate-300 p-6 md:p-8 space-y-6">
                      <div className="border-b border-gray-100 pb-3">
                        <h4 className="text-md font-serif font-bold text-[#1A1A1A] flex items-center gap-2">
                          🌱 Mapeamento Guiado Sem Complicações
                        </h4>
                        <p className="text-[11px] text-slate-400 font-sans mt-1">
                          Responda de forma simples para entender onde sua equipe está perdendo tempo e dinheiro.
                        </p>
                      </div>

                      {/* Sector selection */}
                      <div className="space-y-1.5">
                        <span className="block text-[9.5px] font-mono font-bold uppercase text-slate-500">Qual o seu ramo de atuação?</span>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.keys(sectorLabels).map((sect) => (
                            <button
                              key={sect}
                              type="button;button"
                              onClick={() => setVisitorSector(sect)}
                              className={`px-3 py-1 text-[10px] font-bold border rounded-none uppercase transition-all cursor-pointer ${
                                visitorSector === sect 
                                  ? "bg-[#1A1A1A] text-white border-transparent" 
                                  : "bg-white border-gray-200 text-slate-500 hover:border-gray-400"
                              }`}
                            >
                              {sectorLabels[sect]}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Simple Volume Slider */}
                      <div className="space-y-1.5">
                        <label className="flex justify-between text-[9.5px] font-mono font-bold uppercase text-slate-500">
                          <span>Quantas tarefas, pedidos ou entregas o time faz por mês?</span>
                          <span className="text-[#1A1A1A] font-bold font-sans">{visitorVolume.toLocaleString("pt-BR")} entregas</span>
                        </label>
                        <input
                          type="range"
                          min="100"
                          max="10000"
                          step="100"
                          value={visitorVolume}
                          onChange={(e) => setVisitorVolume(Number(e.target.value))}
                          className="w-full h-1 bg-gray-200 appearance-none cursor-pointer accent-[#1A1A1A] rounded-lg"
                        />
                      </div>

                      {/* Simplified Quality Buttons instead of raw Slider */}
                      <div className="space-y-2">
                        <span className="block text-[9.5px] font-mono font-bold uppercase text-slate-500">Frequência média de erros, atrasos ou retrabalhos:</span>
                        <div className="grid grid-cols-2 gap-2 text-[10.5px]">
                          {[
                            { label: "Raras Vezes (~1%)", desc: "Quase perfeito", value: 1 },
                            { label: "Algumas Vezes (~5%)", desc: "Erros semanais", value: 5 },
                            { label: "Muitas Vezes (~12%)", desc: "Falhas diárias", value: 12 },
                            { label: "Caos Geral (~20%)", desc: "Retrabalho constante", value: 20 },
                          ].map((opt) => (
                            <button
                              key={opt.value}
                              type="button"
                              onClick={() => setVisitorDefectRatePercent(opt.value)}
                              className={`p-2.5 text-left border rounded-none transition-all cursor-pointer flex flex-col justify-between ${
                                visitorDefectRatePercent === opt.value
                                  ? "border-amber-500 bg-amber-50/20 text-slate-900 shadow-2xs"
                                  : "border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50"
                              }`}
                            >
                              <strong className="font-bold block">{opt.label}</strong>
                              <span className="text-[9px] text-slate-400 mt-0.5">{opt.desc}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Three Simple Layman Diagnostic Questions */}
                      <div className="space-y-4 pt-4 border-t border-gray-100">
                        <h5 className="text-[10px] font-mono font-black uppercase text-[#C49746]">📋 Questionário de Triagem Rápida</h5>
                        
                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">1. Qual a principal dor que você deseja resolver?</label>
                          <select
                            value={laymanAnswers.pain}
                            onChange={(e) => setLaymanAnswers(prev => ({ ...prev, pain: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-slate-800"
                          >
                            <option value="gargalo">Demora para entregar tarefas ou pedidos (Gargalos)</option>
                            <option value="qualidade">Erros frequentes, correções ou reclamações de clientes (Qualidade)</option>
                            <option value="fluxo">Desorganização da equipe / Sem processos padronizados (Fluxo)</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">2. Como vocês medem a produtividade do time hoje?</label>
                          <select
                            value={laymanAnswers.measurement}
                            onChange={(e) => setLaymanAnswers(prev => ({ ...prev, measurement: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-slate-800"
                          >
                            <option value="sentimento">No sentimento / Olhômetro do gestor</option>
                            <option value="excel">Em planilhas de Excel simples atualizadas à mão</option>
                            <option value="nao_mede">Não medimos, cada um faz do seu jeito</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">3. Quantas pessoas trabalham diretamente na sua operação?</label>
                          <select
                            value={laymanAnswers.teamSize}
                            onChange={(e) => setLaymanAnswers(prev => ({ ...prev, teamSize: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-slate-800"
                          >
                            <option value="1-5">De 1 a 5 colaboradores</option>
                            <option value="6-20">De 6 a 20 colaboradores</option>
                            <option value="mais_20">Mais de 20 colaboradores operando</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Right side: Layman Visual Outcomes & Guidance */}
                    <div className="lg:col-span-6 space-y-6">
                      <div className="bg-white border-2 border-slate-950 p-6 md:p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-6">
                        <div>
                          <span className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider">RESULTADOS FINANCEIROS &amp; SAÚDE DA OPERAÇÃO</span>
                          <h4 className="text-lg font-serif font-bold text-slate-800 mt-1">Diagnóstico e Impacto Estimado</h4>
                        </div>

                        {/* Financial Cards */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="p-4 border border-dashed border-red-200 bg-red-50/40 rounded-none">
                            <span className="text-[8.5px] font-mono text-slate-500 uppercase block tracking-tight">O que você perde por ano (Desperdício):</span>
                            <strong className="text-2xl font-serif text-rose-950 block mt-1">R$ {Math.round(estimatedAnnualWaste).toLocaleString("pt-BR")}</strong>
                            <p className="text-[9.5px] text-rose-600 font-mono font-semibold mt-1">🔴 Recursos jogados no lixo</p>
                          </div>

                          <div className="p-4 border border-dashed border-emerald-300 bg-emerald-50 rounded-none">
                            <span className="text-[8.5px] font-mono text-emerald-800 uppercase block tracking-tight font-extrabold">Economia Potencial com E3I:</span>
                            <strong className="text-2xl font-serif text-emerald-950 block mt-1 font-black">R$ {Math.round(estimatedSavingsAfterE3I).toLocaleString("pt-BR")}</strong>
                            <p className="text-[9.5px] text-emerald-700 font-mono font-black mt-1">🟢 Otimização operacional líquida</p>
                          </div>
                        </div>

                        {/* Health Score Meter */}
                        <div className="p-4 bg-slate-50 border border-slate-200 space-y-3 rounded-none">
                          <div className="flex justify-between items-center text-xs font-mono">
                            <span className="font-bold text-slate-700">SCORE DE SAÚDE OPERACIONAL:</span>
                            <span className={`px-2 py-0.5 font-bold ${
                              visitorDefectRatePercent >= 12 ? 'text-red-700 bg-red-100' : 'text-amber-700 bg-amber-100'
                            }`}>
                              {visitorDefectRatePercent === 1 ? "92/100 (Excelente)" : visitorDefectRatePercent === 5 ? "78/100 (Bom)" : visitorDefectRatePercent === 12 ? "58/100 (Crítico)" : "36/100 (Urgente!)"}
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all duration-500 ${
                                visitorDefectRatePercent === 1 ? 'bg-emerald-500 w-[92%]' : visitorDefectRatePercent === 5 ? 'bg-amber-400 w-[78%]' : visitorDefectRatePercent === 12 ? 'bg-orange-500 w-[58%]' : 'bg-red-600 w-[36%]'
                              }`} 
                            />
                          </div>
                        </div>

                        {/* Custom "How to resolve" step-by-step guidance */}
                        <div className="p-4 bg-amber-50 border-l-4 border-[#C49746] space-y-3">
                          <h5 className="text-[11px] font-mono font-bold uppercase text-[#C49746] flex items-center gap-1.5">
                            💡 Roteiro Simples: Como Resolver Operacionalmente?
                          </h5>
                          
                          <div className="space-y-3.5 text-xs text-amber-950 font-sans leading-relaxed">
                            {laymanAnswers.pain === "gargalo" && (
                              <>
                                <p><strong>Passo 1 (Identificação):</strong> Mapeie o seu fluxo atual na aba <em>Mapeador de Processos (VSM)</em> identificando onde as tarefas ficam "paradas" aguardando ação.</p>
                                <p><strong>Passo 2 (Ajuste):</strong> Crie um <em>Quadro Kanban (WIP)</em> para limitar a quantidade de tarefas simultâneas, forçando o fluxo a andar mais rápido.</p>
                                <p><strong>Passo 3 (Sustentação):</strong> Registre seu contato no formulário abaixo para receber o Project Charter inicial formatado por nossa equipe.</p>
                              </>
                            )}
                            {laymanAnswers.pain === "qualidade" && (
                              <>
                                <p><strong>Passo 1 (Filtro de Erros):</strong> Defina regras claras de aceite de tarefas (SIPOC) para evitar que o time inicie trabalhos incompletos ou errados.</p>
                                <p><strong>Passo 2 (Controle):</strong> Crie verificações rápidas em cada posto de trabalho para impedir que um erro avance para o cliente final.</p>
                                <p><strong>Passo 3 (Sustentação):</strong> Preencha o cadastro abaixo. Nós ativaremos a licença profissional para você usar nossos Gráficos de Controle sem complicação.</p>
                              </>
                            )}
                            {laymanAnswers.pain === "fluxo" && (
                              <>
                                <p><strong>Passo 1 (Definição):</strong> Crie um mapeamento SIPOC (Fornecedores, Entradas, Processo, Saídas, Clientes) para que todos saibam exatamente o que fazer.</p>
                                <p><strong>Passo 2 (Padronização):</strong> Desenhe o fluxograma de forma visual para a equipe. Evite regras complexas guardadas apenas na cabeça das pessoas.</p>
                                <p><strong>Passo 3 (Sustentação):</strong> Inscreva-se comercialmente abaixo para obtermos uma mentoria personalizada gratuita.</p>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="pt-2 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              const target = document.getElementById("leads-capture-form");
                              if (target) {
                                setLeadForm(prev => ({
                                  ...prev,
                                  interest: laymanAnswers.pain === "gargalo" ? "Redução de Gargalos" : laymanAnswers.pain === "qualidade" ? "Controle de Erros" : "Padronização SIPOC",
                                  message: `Realizei a simulação como Pessoa Leiga. Score de Saúde: ${
                                    visitorDefectRatePercent === 1 ? "92" : visitorDefectRatePercent === 5 ? "78" : visitorDefectRatePercent === 12 ? "58" : "36"
                                  }/100. Dor principal selecionada: ${laymanAnswers.pain}.`
                                }));
                                target.scrollIntoView({ behavior: "smooth" });
                              }
                            }}
                            className="text-xs uppercase font-mono font-bold bg-[#1A1A1A] hover:bg-slate-800 text-white px-5 py-3 w-full transition-all cursor-pointer shadow-[3px_3px_0px_0px_rgba(196,151,70,1)] text-center block"
                          >
                            🎯 Salvar Diagnóstico no Lead Comercial &amp; Continuar
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* =======================================================
                     2. SPECIALIST VIEW: DETAILED PARAMETERS, TESTS & STOCHASTICS
                     ======================================================= */
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in text-left">
                    {/* Left: Advanced Inputs & Simulator Tests */}
                    <div className="lg:col-span-6 bg-white border border-slate-300 p-6 md:p-8 space-y-6">
                      <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
                        <div>
                          <h4 className="text-md font-serif font-bold text-[#1A1A1A] flex items-center gap-2">
                            🔬 Laboratório de Modelagem Estocástica (Fila G/G/c)
                          </h4>
                          <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                            Simule taxas de chegada e atendimento sob variabilidade técnica real para testar hipóteses.
                          </p>
                        </div>
                        <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 text-[8.5px] font-mono font-black uppercase px-2 py-0.5">
                          AVANÇADO
                        </span>
                      </div>

                      {/* Sector selection */}
                      <div className="space-y-1">
                        <span className="block text-[9.5px] font-mono font-bold uppercase text-slate-500">Ramo corporativo de Atuação:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.keys(sectorLabels).map((sect) => (
                            <button
                              key={sect}
                              type="button"
                              onClick={() => setVisitorSector(sect)}
                              className={`px-3 py-1 text-[10px] font-bold border rounded-none uppercase transition-all cursor-pointer ${
                                visitorSector === sect 
                                  ? "bg-[#C49746] text-white border-transparent" 
                                  : "bg-white border-gray-200 text-slate-500 hover:border-gray-400"
                              }`}
                            >
                              {sectorLabels[sect]}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Volume slider */}
                      <div className="space-y-1">
                        <label className="flex justify-between text-[9.5px] font-mono font-bold uppercase text-slate-500">
                          <span>Volume Mensal (Chegadas λ):</span>
                          <span className="text-[#1A1A1A] font-bold font-sans">{(visitorVolume).toLocaleString("pt-BR")} itens/mês</span>
                        </label>
                        <input
                          type="range"
                          min="500"
                          max="15000"
                          step="500"
                          value={visitorVolume}
                          onChange={(e) => setVisitorVolume(Number(e.target.value))}
                          className="w-full h-1 bg-gray-200 appearance-none cursor-pointer accent-[#C49746] rounded-lg mt-1"
                        />
                      </div>

                      {/* Defect Rate Slider */}
                      <div className="space-y-1">
                        <label className="flex justify-between text-[9.5px] font-mono font-bold uppercase text-slate-500">
                          <span>Taxa de Defeito (COPQ Refugos):</span>
                          <span className="text-[#C49746] font-bold font-sans">{visitorDefectRatePercent}%</span>
                        </label>
                        <input
                          type="range"
                          min="0.1"
                          max="25"
                          step="0.5"
                          value={visitorDefectRatePercent}
                          onChange={(e) => setVisitorDefectRatePercent(Number(e.target.value))}
                          className="w-full h-1 bg-gray-200 appearance-none cursor-pointer accent-[#C49746] rounded-lg mt-1"
                        />
                      </div>

                      {/* Specialist-Only Advanced Sliders */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-dashed border-gray-150">
                        
                        {/* Service Time Slider */}
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono font-bold uppercase text-slate-500 block">
                            Tempo Médio (T): <span className="text-[#1A1A1A]">{serviceTime}m</span>
                          </label>
                          <input
                            type="range"
                            min="2"
                            max="60"
                            step="1"
                            value={serviceTime}
                            onChange={(e) => setServiceTime(Number(e.target.value))}
                            className="w-full h-1 bg-gray-200 cursor-pointer accent-indigo-600"
                          />
                        </div>

                        {/* Variance Slider */}
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono font-bold uppercase text-slate-500 block">
                            Desvio Padrão (s): <span className="text-[#1A1A1A]">{serviceVariance}m</span>
                          </label>
                          <input
                            type="range"
                            min="1"
                            max={Math.max(2, serviceTime - 1)}
                            step="1"
                            value={serviceVariance}
                            onChange={(e) => setServiceVariance(Number(e.target.value))}
                            className="w-full h-1 bg-gray-200 cursor-pointer accent-indigo-600"
                          />
                        </div>

                        {/* Server count input */}
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono font-bold uppercase text-slate-500 block">
                            Canais / Analistas (c):
                          </label>
                          <input
                            type="number"
                            min="1"
                            max="10"
                            value={serversCount}
                            onChange={(e) => setServersCount(Math.max(1, Number(e.target.value)))}
                            className="w-full bg-slate-50 border border-slate-300 px-2 py-1 text-xs focus:outline-none focus:border-indigo-500 font-bold font-mono"
                          />
                        </div>
                      </div>

                      {/* --- BASIC TESTS / SIMULATION PRESETS --- */}
                      <div className="bg-slate-50 p-4 border border-slate-200 space-y-3">
                        <span className="text-[9.5px] font-mono font-bold text-indigo-700 block uppercase tracking-wide">
                          🧪 Testes Operacionais Básicos (Prescrições Rápidas LSS)
                        </span>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[10px] font-mono">
                          <button
                            type="button"
                            onClick={() => {
                              setVisitorDefectRatePercent(prev => Math.max(0.5, Number((prev * 0.5).toFixed(1))));
                              setServiceVariance(prev => Math.max(1, Math.round(prev * 0.7)));
                              appendSystemLog("Simulação LSS", "Especialista LSS", "Testou treinamento LSS (redução de refugo e variabilidade)");
                              alert("⚡ Teste de Redução Aplicado!\nO treinamento reduziu o refugo pela metade e a variabilidade do tempo em 30%!");
                            }}
                            className="p-2 border border-indigo-200 bg-white hover:bg-indigo-50 text-indigo-700 font-bold transition-all text-center cursor-pointer uppercase leading-tight"
                          >
                            👨‍🏫 Prescrever Treino DMAIC
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setServersCount(prev => prev + 1);
                              appendSystemLog("Simulação LSS", "Especialista LSS", "Testou escalonamento de operadores (c+1)");
                              alert("⚡ Canal Operacional Adicionado!\nA contratação temporária de mais 1 analista aumentou a capacidade estocástica.");
                            }}
                            className="p-2 border border-indigo-200 bg-white hover:bg-indigo-50 text-indigo-700 font-bold transition-all text-center cursor-pointer uppercase leading-tight"
                          >
                            ➕ Adicionar Operador (+1)
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setServiceTime(prev => Math.max(2, Math.round(prev * 0.6)));
                              appendSystemLog("Simulação LSS", "Especialista LSS", "Testou automação RPA de faturamento");
                              alert("⚡ RPA Implantado!\nA triagem automática acelerou o tempo médio de atendimento (T) em 40%!");
                            }}
                            className="p-2 border border-indigo-200 bg-white hover:bg-indigo-50 text-indigo-700 font-bold transition-all text-center cursor-pointer uppercase leading-tight"
                          >
                            🤖 Automatizar RPA (-40% Tempo)
                          </button>
                        </div>
                      </div>

                      {/* Advanced Survey Questions */}
                      <div className="space-y-4 pt-4 border-t border-gray-150">
                        <span className="text-[10px] font-mono font-black uppercase text-indigo-700 block">
                          📋 Diagnóstico Técnico de Maturidade Lean Six Sigma
                        </span>

                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">1. Qual framework de melhoria contínua é implementado atualmente?</label>
                          <select
                            value={specialistAnswers.methodology}
                            onChange={(e) => setSpecialistAnswers(prev => ({ ...prev, methodology: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-indigo-600"
                          >
                            <option value="nenhuma">Não temos framework estabelecido (Controle Ad-Hoc)</option>
                            <option value="kaizen">Apenas práticas Lean Kaizen / Gemba Walks esporádicos</option>
                            <option value="dmaic">DMAIC robusto com papéis LSS (Green Belts / Black Belts)</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">2. Como é controlada a estabilidade das etapas gargalo?</label>
                          <select
                            value={specialistAnswers.stability}
                            onChange={(e) => setSpecialistAnswers(prev => ({ ...prev, stability: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-indigo-600"
                          >
                            <option value="alta_var">Alta instabilidade (Causas especiais e quebras de SLA frequentes)</option>
                            <option value="moderada">Moderada (Controlada de forma reativa com cartas de controle manuais)</option>
                            <option value="estavel">Processo sob controle estatístico rígido (Capabilidade CPK &gt; 1.33)</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-sans font-bold text-slate-700 block">3. Principal meta de engenharia operacional para o próximo trimestre:</label>
                          <select
                            value={specialistAnswers.engineeringMeta}
                            onChange={(e) => setSpecialistAnswers(prev => ({ ...prev, engineeringMeta: e.target.value }))}
                            className="w-full bg-slate-50 border border-slate-300 p-2 text-xs focus:outline-none focus:border-indigo-600"
                          >
                            <option value="lead_time">Redução de Lead Time estocástico e acúmulo de WIP</option>
                            <option value="sigma_level">Redução de retrabalho / Elevação do nível Sigma</option>
                            <option value="simplex">Alocação de capacidade produtiva ótima (Mix de Recursos)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Right: Technical Results & Queue Stochastics */}
                    <div className="lg:col-span-6 space-y-6">
                      <div className="bg-white border-2 border-slate-950 p-6 md:p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-6 flex flex-col justify-between">
                        
                        <div className="space-y-1">
                          <span className="text-xs font-mono font-black uppercase text-indigo-700 tracking-wider">RESULTADOS DE MODELAGEM MATEMÁTICA</span>
                          <h4 className="text-lg font-serif font-bold text-slate-800">Custo do Desperdício &amp; Teoria de Filas</h4>
                        </div>

                        {/* Financial Cards */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="p-4 border border-dashed border-[#C49746]/30 bg-[#C49746]/5 rounded-none">
                            <span className="text-[8.5px] font-mono text-slate-500 uppercase block tracking-tight font-bold">Vazamento Financeiro Anualizado COPQ:</span>
                            <strong className="text-2xl font-serif text-slate-900 block mt-1">R$ {Math.round(estimatedAnnualWaste).toLocaleString("pt-BR")}</strong>
                            <p className="text-[9.5px] text-[#C49746] font-mono font-semibold mt-1">🔴 Custo de falta de qualidade</p>
                          </div>

                          <div className="p-4 border border-dashed border-emerald-300 bg-emerald-50 rounded-none">
                            <span className="text-[8.5px] font-mono text-emerald-800 uppercase block tracking-tight font-extrabold">Oportunidade E3I LSS Otimizada:</span>
                            <strong className="text-2xl font-serif text-emerald-950 block mt-1 font-black">R$ {Math.round(estimatedSavingsAfterE3I).toLocaleString("pt-BR")}</strong>
                            <p className="text-[9.5px] text-emerald-700 font-mono font-black mt-1">🟢 Economia operacional líquida</p>
                          </div>
                        </div>

                        {/* Stochastic Queue Stats Card */}
                        <div className="p-5 bg-slate-950 text-slate-200 border border-slate-800 space-y-4 rounded-none font-mono text-xs">
                          <span className="text-amber-400 font-extrabold text-[9px] block border-b border-slate-800 pb-1.5 uppercase">
                            🎛️ Métricas Teóricas do Sistema Estocástico
                          </span>

                          <div className="space-y-2.5">
                            {/* System Utilization (rho) */}
                            {(() => {
                              const lambda = visitorVolume / 9600; // items / minute (160h/month)
                              const mu = 1 / (serviceTime || 1);
                              const c = serversCount || 1;
                              const rho = lambda / (c * mu);
                              const isUnstable = rho >= 1;

                              // Process Sigma level continuous approximation
                              const defectRate = visitorDefectRatePercent / 100;
                              let sigma = 3.0;
                              if (defectRate >= 0.3) sigma = 2.0;
                              else if (defectRate >= 0.0668) sigma = 2.0 + (0.3 - defectRate) / (0.3 - 0.0668);
                              else if (defectRate >= 0.0062) sigma = 3.0 + (0.0668 - defectRate) / (0.0668 - 0.0062);
                              else if (defectRate >= 0.00023) sigma = 4.0 + (0.0062 - defectRate) / (0.0062 - 0.00023);
                              else if (defectRate >= 0.0000034) sigma = 5.0 + (0.00023 - defectRate) / (0.00023 - 0.0000034);
                              else sigma = 6.0;

                              // Kingman expected wait in queue (Wq)
                              const cv_a = 1.0; // arrival CoV
                              const cv_s = serviceVariance / serviceTime; // service CoV
                              const cv_term = (Math.pow(cv_a, 2) + Math.pow(cv_s, 2)) / 2;
                              const waitTimeInQueue = isUnstable 
                                ? "∞ (Saturação!)" 
                                : ((cv_term * (rho / (1 - rho)) * serviceTime) / c).toFixed(1) + " min";

                              return (
                                <>
                                  <div className="flex justify-between items-center text-[11px] border-b border-slate-900 pb-1.5">
                                    <span className="text-slate-400">Taxa de Ocupação (ρ):</span>
                                    <span className={`font-bold ${isUnstable ? 'text-red-500 font-extrabold animate-pulse' : rho >= 0.8 ? 'text-orange-400' : 'text-emerald-400'}`}>
                                      {isUnstable ? "🚨 Saturação! ≥ 100%" : `${(rho * 100).toFixed(1)}%`}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center text-[11px] border-b border-slate-900 pb-1.5">
                                    <span className="text-slate-400">Tempo de Espera Fila (Wq):</span>
                                    <span className={`font-bold ${isUnstable ? 'text-red-500' : 'text-slate-200'}`}>{waitTimeInQueue}</span>
                                  </div>
                                  <div className="flex justify-between items-center text-[11px] pb-1">
                                    <span className="text-slate-400">Qualidade Capabilidade:</span>
                                    <span className="text-indigo-400 font-bold">{sigma.toFixed(2)} σ (Sigma)</span>
                                  </div>
                                </>
                              );
                            })()}
                          </div>
                        </div>

                        {/* Specialist dynamic recommendation panel */}
                        <div className="p-4 bg-indigo-50 border-l-4 border-indigo-600 space-y-2 text-xs">
                          <strong className="text-indigo-950 font-mono text-[10.5px] uppercase block">
                            🔬 Diretrizes Operacionais (E3I Engine LSS):
                          </strong>
                          <p className="text-indigo-900 leading-relaxed font-sans">
                            {(() => {
                              const lambda = visitorVolume / 9600;
                              const mu = 1 / (serviceTime || 1);
                              const c = serversCount || 1;
                              const rho = lambda / (c * mu);

                              if (rho >= 0.9) {
                                return "⚠️ Risco Estocástico Crítico: Seu sistema apresenta alto percentual de saturação. Pequenas oscilações no tempo de ciclo causarão atrasos enormes no faturamento comercial. Recomenda-se adicionar analistas de triagem temporários ou automatizar a recepção de pedidos via RPA imediatamente para baixar T.";
                              }
                              if (visitorDefectRatePercent >= 10) {
                                return "🎯 Problema de Qualidade: Sua taxa de refugo comercial/retrabalho é de classe baixa. Sugerimos ativar no menu o mapeamento VSM Avançado acoplado à análise CEP (Cartas de Controle de Processo) para investigar causas comuns e eliminar retrabalho de Notas Fiscais.";
                              }
                              return "💡 Otimização de Mix: Sua operação apresenta boa estabilidade sob regimes de teoria das filas. O próximo passo de excelência operacional é modelar no Hub de Otimização Linear (Simplex) para maximizar o lucro operacional no faturamento com restrições de insumos.";
                            })()}
                          </p>
                        </div>

                        <div className="pt-2 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              const target = document.getElementById("leads-capture-form");
                              if (target) {
                                setLeadForm(prev => ({
                                  ...prev,
                                  interest: specialistAnswers.engineeringMeta === "lead_time" ? "Otimização de Lead Time" : specialistAnswers.engineeringMeta === "sigma_level" ? "Melhoria Nível Sigma" : "Alocação Linear Simplex",
                                  message: `Realizei simulações no Laboratório Estocástico. Parâmetros simulados: Tempo Médio = ${serviceTime}m, Variância = ${serviceVariance}m, Operadores = ${serversCount}.`
                                }));
                                target.scrollIntoView({ behavior: "smooth" });
                              }
                            }}
                            className="text-xs uppercase font-mono font-bold bg-[#C49746] hover:bg-[#a37b34] text-white px-5 py-3 w-full transition-all cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] text-center block"
                          >
                            🎯 Acoplar Variáveis ao Lead Comercial &amp; Triagem
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            </section>

            {/* === DETAILED NEW COMPREHENSIVE LEADS CAPTURE FORM === */}
            <section id="leads-capture-form" className="py-16 md:py-24 px-6 max-w-7xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                
                <div className="lg:col-span-5 space-y-5">
                  <span className="text-xs font-mono font-bold text-[#C49746] uppercase tracking-widest block">NEXUS DE CADASTRO COMERCIAL</span>
                  <h3 className="text-3xl font-serif text-slate-950">Gere um diagnóstico avançado gratuito</h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-sans">
                    Inscreva sua equipe corporativa ou seu projeto de pós-graduação/mestrado para receber uma demonstração privada dos analistas E3I. Nós providenciaremos um simulador de teoria de filas acoplado à sua operação em tempo recorde.
                  </p>
                  
                  <div className="space-y-4 pt-2">
                    <div className="flex items-start gap-3">
                      <span className="p-1 px-2.5 bg-indigo-50 border border-indigo-200 text-indigo-700 font-mono text-xs font-black">1</span>
                      <div>
                        <strong className="text-xs font-mono font-extrabold block text-slate-900 uppercase">Varredura Preliminar</strong>
                        <p className="text-[11px] text-slate-500">Analisamos sua taxa de refugo e setups para estimar o gargalo operacional.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <span className="p-1 px-2.5 bg-amber-50 border border-amber-200 text-amber-800 font-mono text-xs font-black">2</span>
                      <div>
                        <strong className="text-xs font-mono font-extrabold block text-slate-900 uppercase">Mapeamento Assistido por IA</strong>
                        <p className="text-[11px] text-slate-500">Desenvolvemos o Project Charter e a matriz SIPOC automatizada por e-mail.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <span className="p-1 px-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono text-xs font-black">3</span>
                      <div>
                        <strong className="text-xs font-mono font-extrabold block text-slate-900 uppercase">Homologação de Licenças</strong>
                        <p className="text-[11px] text-slate-500">Liberamos os acessos sob medida de acordo com o porte de faturamento da empresa.</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Secure Leads register form */}
                <div className="lg:col-span-7 bg-white border-2 border-[#1A1A1A] p-6 md:p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-4 mb-6">
                    <h4 className="text-sm font-mono font-black uppercase text-slate-900 flex items-center gap-1.5">
                      <FileText size={15} className="text-[#C49746]"/> Formulário de Leads PJ &amp; Diagnóstico
                    </h4>
                    <span className="bg-[#FAF9F6] border border-gray-300 text-slate-500 text-[8.5px] px-2.5 py-1 font-mono uppercase tracking-wider font-bold">
                      Canal de Atendimento de Alta Resolução
                    </span>
                  </div>

                  {leadStatusMessage && (
                    <div className={`p-4 rounded-none text-xs font-mono mb-6 border ${
                      leadStatusMessage.type === "success" 
                        ? "bg-emerald-50 border-emerald-400 text-emerald-950" 
                        : "bg-red-50 border-red-400 text-red-950"
                    }`}>
                      {leadStatusMessage.type === "success" ? "✓" : "⚠"} {leadStatusMessage.text}
                    </div>
                  )}

                  <form onSubmit={onSubmitLeadForm} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Seu Nome Completo *</label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: Carlos Henrique de Oliveira"
                          value={leadForm.name}
                          onChange={(e) => setLeadForm({ ...leadForm, name: e.target.value })}
                          className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-black uppercase text-slate-500 font-bold">E-mail Corporativo *</label>
                        <input
                          type="email"
                          required
                          placeholder="Ex: carlos@empresa.com.br"
                          value={leadForm.email}
                          onChange={(e) => setLeadForm({ ...leadForm, email: e.target.value })}
                          className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-black uppercase text-slate-500">WhatsApp / Celular</label>
                        <input
                          type="text"
                          placeholder="Ex: (11) 99122-3000"
                          value={leadForm.phone}
                          onChange={(e) => setLeadForm({ ...leadForm, phone: e.target.value })}
                          className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Nome da Empresa *</label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: Petrobras S.A."
                          value={leadForm.company}
                          onChange={(e) => setLeadForm({ ...leadForm, company: e.target.value })}
                          className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Seu Cargo de Atuação</label>
                        <select
                          value={leadForm.role}
                          onChange={(e) => setLeadForm({ ...leadForm, role: e.target.value })}
                          className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                        >
                          <option value="Analista">Analista / Supervisor</option>
                          <option value="Green Belt">Green Belt Certificado</option>
                          <option value="Black Belt">Black Belt / Champion</option>
                          <option value="Socio Diretor">Sócio Diretor / C-Level</option>
                          <option value="Estudante">Pesquisador / Estudante</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Módulo Científico de Maior Interesse</label>
                      <select
                        value={leadForm.interest}
                        onChange={(e) => setLeadForm({ ...leadForm, interest: e.target.value })}
                        className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none font-mono"
                      >
                        <option value="DMAIC & Processos">📋 Mapeamento de Faturamento e Fluxo DMAIC</option>
                        <option value="Teoria de Filas (G/G/c)">⚙️ Simulação Estocástica de Teoria de Filas</option>
                        <option value="Simplex / Alocação Ótima">🏆 Programação Linear / Solvers de Margem (Simplex)</option>
                        <option value="CEP / Shewhart">📊 CEP - Cartas Estatísticas de Controle de Shewhart</option>
                        <option value="Consultoria Master Belt">💎 Alocação Dedicada de Consultores (Upgrades Premium)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Descreva Abreviamente o Gargalo da sua Operação (Sua Mensagem)</label>
                      <textarea
                        rows={3}
                        placeholder="Ex: Temos falhas no setup de expedição que atrasam faturamento em 5 dias."
                        value={leadForm.message}
                        onChange={(e) => setLeadForm({ ...leadForm, message: e.target.value })}
                        className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] focus:border-[#1A1A1A] text-slate-900 focus:outline-none"
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full py-3 bg-[#1A1A1A] hover:bg-[#C49746] text-white font-mono text-[11px] font-bold uppercase tracking-widest cursor-pointer transition-all shadow-[4px_4px_0px_0px_rgba(196,151,70,1)] hover:translate-x-0.5 hover:translate-y-0.5"
                      >
                        Enviar Dados para Lead &amp; Homologar Diagnóstico ✓
                      </button>
                    </div>
                  </form>
                </div>

              </div>
            </section>

            {/* Pricing table */}
            <section className="py-20 px-6 bg-white border-t border-gray-200">
              <div className="max-w-7xl mx-auto">
                <div className="text-center max-w-2xl mx-auto space-y-3 mb-16">
                  <span className="text-xs font-mono font-bold text-[#C49746] uppercase tracking-widest block font-bold">TABELA DE LICENCIAMENTO TRANSPARENTE</span>
                  <h2 className="text-3xl font-serif text-slate-950 uppercase tracking-tight">Assinaturas modulares para maturidade corporativa</h2>
                  <p className="text-xs text-gray-400 font-sans max-w-lg mx-auto">
                    Simule seu plano e use nossa console de cibersegurança e suporte integrado 24/7.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {plans.map((pl, idx) => {
                    return (
                      <div 
                        key={idx}
                        className={`p-6 md:p-8 bg-white border-2 rounded-sm flex flex-col justify-between h-[450px] relative ${
                          pl.isPopular 
                            ? "border-amber-500 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] scale-[1.02]" 
                            : "border-slate-350 shadow-[4px_4px_0px_0px_rgba(220,220,220,1)]"
                        }`}
                      >
                        {pl.isPopular && (
                          <span className="absolute top-0 right-6 -translate-y-1/2 bg-amber-500 text-white text-[9px] font-mono font-bold uppercase tracking-widest px-3 py-1">
                            O Mais Escolhido
                          </span>
                        )}

                        <div className="space-y-4">
                          <div>
                            <h3 className="text-base font-serif font-bold text-slate-900">{pl.name}</h3>
                            <p className="text-[10px] text-slate-500 mt-1 font-sans leading-tight line-clamp-2 h-8">
                              {pl.description}
                            </p>
                          </div>

                          <div className="border-b border-dashed border-gray-200 pb-3">
                            {pl.price === "Sob Consulta" ? (
                              <strong className="text-2xl font-serif text-slate-950 block">{pl.price}</strong>
                            ) : (
                              <div className="flex items-baseline">
                                <span className="text-xs font-sans text-gray-500 mr-1">R$</span>
                                <strong className="text-3xl font-serif text-slate-950 font-black">{pl.price}</strong>
                                <span className="text-xs font-sans text-gray-400 ml-1">/mês</span>
                              </div>
                            )}
                          </div>

                          <ul className="space-y-2 text-xs">
                            {pl.features.map((ft, fIdx) => (
                              <li key={fIdx} className="flex items-center gap-2 text-slate-700 text-[11px]">
                                <CheckCircle2 size={12} className="text-[#C49746] shrink-0" />
                                <span className="truncate">{ft}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <a
                          href="#leads-capture-form"
                          className="w-full py-2 bg-[#1A1A1A] hover:bg-[#C49746] text-white text-[10px] font-mono font-bold uppercase tracking-widest text-center transition-all cursor-pointer block"
                        >
                          Falar com Consultores
                        </a>
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ==================== 2. ÁREA PRIVATIVA DO CLIENTE (CLIENT ZONE) ==================== */}
        {activeTab === "CLIENT_PORTAL" && (
          <div className="max-w-7xl mx-auto px-6 py-12 animate-fade-in">
            
            {/* IF NOT LOGGED IN: SHOW SIMULATED CLIENT LOGIN */}
            {!loggedClient ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left Column: Secure Credentials and Licensing Selector */}
                <div className="lg:col-span-5 bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-6">
                <div className="text-center space-y-2 border-b border-gray-200 pb-4">
                  <div className="inline-flex p-3 bg-slate-50 border border-slate-350 rounded-full text-slate-700 text-center mx-auto">
                    <Lock size={20} />
                  </div>
                  <h3 className="text-lg font-serif font-extrabold text-slate-900 uppercase">Área do Cliente E3I</h3>
                  <p className="text-[11px] text-gray-500 font-mono">
                    Acesso exclusivo à console de auditorias e faturamento
                  </p>
                </div>

                {/* Dual navigation tabs for CLIENT LOGIN vs CADASTRO */}
                <div className="flex border-b border-gray-200 gap-1">
                  <button
                    type="button"
                    onClick={() => setClientPortalTab("LOGIN")}
                    className={`flex-1 py-2 text-[10.5px] font-mono font-black uppercase border-b-2 text-center transition-all ${
                      clientPortalTab === "LOGIN"
                        ? "border-[#C49746] text-slate-900"
                        : "border-transparent text-gray-400 hover:text-slate-600"
                    }`}
                  >
                    Acessar Contrato (Login)
                  </button>
                  <button
                    type="button"
                    onClick={() => setClientPortalTab("CADASTRO")}
                    className={`flex-1 py-2 text-[10.5px] font-mono font-black uppercase border-b-2 text-center transition-all ${
                      clientPortalTab === "CADASTRO"
                        ? "border-[#C49746] text-slate-900"
                        : "border-transparent text-gray-400 hover:text-slate-600"
                    }`}
                  >
                    Contratar / Ajustar Cadastro
                  </button>
                </div>

                {clientPortalTab === "LOGIN" ? (
                  <div className="space-y-4">
                    <span className="block text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider text-center">
                      Acesso Instantâneo via Contratos Ativos:
                    </span>

                    <div className="space-y-2">
                      {mockPredefinedCompanies.map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => handleClientLogin(c)}
                          className="w-full p-2.5 border border-slate-250 hover:border-slate-950 hover:bg-slate-50 flex items-center justify-between text-left transition-all cursor-pointer rounded-none group"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-6 h-6 font-serif font-extrabold bg-[#1A1A1A] text-white flex items-center justify-center text-[10px] group-hover:bg-[#C49746]">
                              {c.logoLetter}
                            </span>
                            <div>
                              <strong className="text-xs text-slate-900 block font-sans">{c.name}</strong>
                              <span className="text-[9px] text-gray-400 block font-sans">{c.industry}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-[8.5px] font-mono font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded-none block">
                              {c.currentPlan.replace("E3I ", "")}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>

                    <div className="border-t border-dashed border-gray-250 pt-4">
                      <form onSubmit={(e) => {
                        e.preventDefault();
                        if (mockPredefinedCompanies.length > 0) {
                          handleClientLogin(mockPredefinedCompanies[0]);
                        }
                      }} className="space-y-3 text-left">
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">E-mail Corporativo</label>
                          <input type="email" required placeholder="contato@itau.com.br" className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none" />
                        </div>
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Senha de Acesso</label>
                          <input type="password" required defaultValue="123456" className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none" />
                        </div>
                        <button type="submit" className="w-full py-2 bg-slate-950 hover:bg-indigo-600 text-white text-[10px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5">
                          Autenticar e Entrar
                        </button>
                      </form>
                    </div>

                    <div className="bg-[#FAF8F5] p-3 border border-dashed border-[#C49746]/20 text-[10px] tracking-tight text-slate-500 font-mono leading-normal">
                      💡 Selecione um contrato corporativo ou digite seu e-mail para validar seus privilégios ativos.
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleCadastroSubmit} className="space-y-4 text-left">
                    <div className="space-y-2">
                      <span className="block text-[9.5px] font-mono font-extrabold uppercase text-slate-400">Tipo de Configuração:</span>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setCadastroType("NOVO");
                            setSelectedAjusteId("");
                            setFormNomeEmpresa("");
                            setFormCNPJ("");
                          }}
                          className={`py-1.5 text-[9.5px] font-mono font-bold uppercase text-center border ${
                            cadastroType === "NOVO"
                              ? "bg-slate-900 border-slate-900 text-white"
                              : "bg-white border-slate-200 text-slate-600"
                          }`}
                        >
                          Novo Contrato
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCadastroType("AJUSTE");
                            if (mockPredefinedCompanies.length > 0) {
                              handleSelectAjusteCompany(mockPredefinedCompanies[0].id);
                            }
                          }}
                          className={`py-1.5 text-[9.5px] font-mono font-bold uppercase text-center border ${
                            cadastroType === "AJUSTE"
                              ? "bg-slate-900 border-slate-900 text-white"
                              : "bg-white border-slate-200 text-slate-600"
                          }`}
                        >
                          Ajustar Existente
                        </button>
                      </div>
                    </div>

                    {cadastroType === "AJUSTE" && (
                      <div className="space-y-1">
                        <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500">Selecionar Licença Contratada:</label>
                        <select
                          value={selectedAjusteId}
                          onChange={(e) => handleSelectAjusteCompany(e.target.value)}
                          className="w-full text-xs font-sans p-2 border border-slate-300 bg-white font-bold text-slate-800 focus:outline-none"
                        >
                          <option value="">-- SELECIONE SEU CONTRATO --</option>
                          {mockPredefinedCompanies.map((c) => (
                            <option key={c.id} value={c.id}>{c.name} ({c.currentPlan})</option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Nome do Gestor / Representante</label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: Marco Antônio"
                          value={formNomeUsuario}
                          onChange={(e) => setFormNomeUsuario(e.target.value)}
                          className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Nome Razão da Empresa</label>
                          <input
                            type="text"
                            required
                            placeholder="Ex: Petrobras S.A."
                            value={formNomeEmpresa}
                            onChange={(e) => setFormNomeEmpresa(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">CNPJ Corporativo</label>
                          <input
                            type="text"
                            required
                            placeholder="Ex: 91.833.102/0001-44"
                            value={formCNPJ}
                            onChange={(e) => setFormCNPJ(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Plano SaaS Alocado</label>
                          <select
                            value={formPlan}
                            onChange={(e) => setFormPlan(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 bg-white font-semibold text-slate-800 focus:outline-none"
                          >
                            <option value="E3I Starter">E3I Starter</option>
                            <option value="E3I Professional">E3I Professional</option>
                            <option value="E3I Enterprise Black-Belt">E3I Enterprise Black-Belt</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Cargo Vinculante</label>
                          <select
                            value={formCargo}
                            onChange={(e) => setFormCargo(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 bg-white font-semibold text-slate-800 focus:outline-none"
                          >
                            <option value="Analista Júnior">Analista Júnior (Sem Setup)</option>
                            <option value="Black Belt">Black Belt (Estrategista)</option>
                            <option value="Admin">Administrador S.A.</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500">Módulos Contratados (Checklist de Acesso):</label>
                        <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                          {[
                            { id: "DIAGNOSTIC", label: "📋 Diagnóstico LSS" },
                            { id: "MAP", label: "🗺️ Modelagem BPM" },
                            { id: "DMAIC", label: "⚡ Suíte DMAIC" },
                            { id: "KANBAN", label: "🗂️ Kanban Operac." },
                            { id: "REPORT", label: "📊 Relatórios" },
                            { id: "ROI_DASHBOARD", label: "📈 Dashboard ROI" },
                            { id: "BI_STUDIO", label: "🔍 BI & Inteligência" },
                            { id: "SIGMA_TREND", label: "🎯 CEP Shewhart" }
                          ].map((v) => {
                            const isChecked = formSelectedModules.includes(v.id);
                            return (
                              <label key={v.id} className="flex items-center gap-1.5 cursor-pointer font-sans select-none border border-slate-200 p-1 bg-slate-50 hover:bg-slate-100 font-semibold text-slate-800">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => {
                                    if (isChecked) {
                                      setFormSelectedModules(prev => prev.filter(x => x !== v.id));
                                    } else {
                                      setFormSelectedModules(prev => [...prev, v.id]);
                                    }
                                  }}
                                  className="accent-[#C49746]"
                                />
                                <span className="truncate">{v.label}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <button type="submit" className="w-full py-2 bg-indigo-600 hover:bg-[#C49746] text-white text-[10px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer text-center">
                      {cadastroType === "NOVO" ? "✓ Registrar Nova Contratação" : "✓ Aplicar e Salvar Ajustes de Cadastro"}
                    </button>
                  </form>
                )}
              </div>

              {/* Right Column: Portfolio of Corporate Branches and Success Cases */}
              <div className="lg:col-span-7 bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-6 text-left">
                <div className="border-b border-gray-200 pb-3 space-y-1">
                  <span className="text-[10px] font-mono text-[#C49746] font-bold uppercase tracking-widest block">VITRINE DE PERFORMANCE E3I</span>
                  <h3 className="text-lg font-serif font-extrabold text-[#1A1A1A] uppercase tracking-tight">Ramos Corporativos & Cases de Sucesso</h3>
                  <p className="text-[11px] text-gray-500 leading-normal">
                    Mapeamento completo das verticais corporativas atendidas com sucesso pela Suíte Lean Six Sigma.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Case 1: Itaú */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 4.12σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">🏦 FINANÇAS & ATENDIMENTO PJ</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">Itaú Unibanco S.A.</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Redução de variabilidade de tempos de processamento em ordens complexas PJ.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Eficiência Global:</span>
                      <span className="text-emerald-700 font-black">79.2% → 94.5%</span>
                    </div>
                  </div>

                  {/* Case 2: DeltaTech */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 4.60σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">⚡ INDÚSTRIA & MONTAGEM SMT</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">DeltaTech Eletrônicos S.A.</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Otimização de gargalos na inspeção óptica e redução de setups AOI.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Gargalo / Lead Time:</span>
                      <span className="text-emerald-700 font-black">Queda de -40.5%</span>
                    </div>
                  </div>

                  {/* Case 3: Hospital Alpha */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 3.95σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">🏥 SAÚDE & CLÍNICAS MÉDICAS</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">Hospital Alpha PA</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Padronização de triagem de pronto atendimento e alta de pacientes.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Fila Média:</span>
                      <span className="text-emerald-700 font-black">45 min → 8.2 min</span>
                    </div>
                  </div>

                  {/* Case 4: ExpressLogística */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 4.35σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">📦 LOGÍSTICA & OMNICHANNEL</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">ExpressLogística Ltda.</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Aceleração do picking and packing sob o fluxo LSS enxuto.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Ciclo Total:</span>
                      <span className="text-emerald-700 font-black">Sincronizado</span>
                    </div>
                  </div>

                  {/* Case 5: Petrobras */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 4.54σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">🔥 QUÍMICA & ENERGIA</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">Petrobras Distribuidora</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Sintonização e controle de vazão volumétrica crítica por CEP em refinaria.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Variações Lote:</span>
                      <span className="text-emerald-700 font-black">Mapeado -88%</span>
                    </div>
                  </div>

                  {/* Case 6: Ambev */}
                  <div className="border border-slate-200 hover:border-slate-800 transition-all p-3.5 bg-slate-50 relative">
                    <div className="absolute top-2 right-2 text-emerald-600 bg-emerald-50 text-[8.5px] font-mono font-bold px-1.5 py-0.5 border border-emerald-200 uppercase">
                      Capacidade: 4.25σ
                    </div>
                    <span className="block text-[8px] font-mono font-extrabold text-[#C49746] uppercase mb-0.5">🍻 FMCG & VAREJO BEBIDAS</span>
                    <strong className="block text-xs text-slate-900 font-serif mb-1">Ambev Logística Global</strong>
                    <p className="text-[10px] text-slate-500 leading-normal mb-2.5">
                      Maximização de rendimento operacional em esteiras de distribuição rápida.
                    </p>
                    <div className="border-t border-dashed border-gray-200 pt-1.5 flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-500 font-medium">Total Yield:</span>
                      <span className="text-emerald-700 font-black">94.5% → 99.1%</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 border border-amber-250 text-[10px] text-slate-650 leading-relaxed font-mono">
                  💡 Selecione o seu contrato corporativo ao lado para homologar o seu acesso seguro e conferir a console ao vivo de auditoria e mapas.
                </div>
              </div>
            </div>
          ) : (
              
              /* USER CLIENT IS LOGGED IN */
              <div className="bg-white border-2 border-[#1A1A1A] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] rounded-none overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[500px]">
                
                {/* Client mini side bar */}
                <div className="lg:col-span-3 border-r-2 border-[#1A1A1A] bg-slate-50 p-4 space-y-6">
                  <div className="border-b border-gray-200 pb-4 text-center lg:text-left space-y-2">
                    <span className="w-10 h-10 bg-indigo-700 text-white font-serif font-black flex items-center justify-center text-sm rounded-none block mx-auto lg:mx-0">
                      {loggedClient.logoLetter}
                    </span>
                    <div>
                      <strong className="text-xs text-slate-900 block font-serif">{loggedClient.name}</strong>
                      <span className="text-[9.5px] font-mono text-indigo-700 block mt-0.5">{loggedClient.currentPlan}</span>
                    </div>
                  </div>

                  <nav className="space-y-1.5">
                    {/* Primary trigger to enter the LSS Application with company's restricted access */}
                    <button
                      type="button"
                      onClick={() => {
                        const assignedBelt = loggedClient.currentPlan.includes("Black-Belt") ? "Black Belt" : "Green Belt";
                        const assignedRole = loggedClient.currentPlan.includes("Black-Belt") ? "Black Belt" : "Analista Júnior";
                        const simulatedUser = {
                          fullName: formNomeUsuario || "Gestor corporativo de " + loggedClient.name.split(" ")[0],
                          email: formEmail || "gestao@" + loggedClient.id + ".com",
                          belt: assignedBelt,
                          role: assignedRole,
                          companyId: loggedClient.id
                        };
                        
                        localStorage.setItem("six_sigma_active_user", JSON.stringify(simulatedUser));
                        localStorage.setItem("lss_current_cargo", simulatedUser.role);
                        localStorage.setItem("lss_active_company_id", loggedClient.id);
                        
                        if (onLoginSuccess) {
                          onLoginSuccess(simulatedUser, loggedClient.enabledViews || ["DIAGNOSTIC", "MAP", "KANBAN", "REPORT"], loggedClient);
                        }
                      }}
                      className="w-full text-left px-3 py-3 text-[11px] font-sans font-black flex items-center justify-center gap-2 transition-all cursor-pointer uppercase bg-indigo-600 hover:bg-indigo-700 text-white rounded-none shadow-md mb-2.5 animate-pulse"
                    >
                      <Zap size={14} className="text-yellow-300 fill-yellow-300 shrink-0" />
                      ⚡ Entrar na Ferramenta
                    </button>

                    <button
                      onClick={() => setClientSection("DASHBOARD")}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "DASHBOARD" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <Activity size={12} />
                      Meu Dashboard LSS
                    </button>

                    <button
                      onClick={() => setClientSection("MAPEAMENTO_INICIAL")}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "MAPEAMENTO_INICIAL" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <Layers size={12} className="text-[#C49746]" />
                      Mapeamento de Processos
                    </button>

                    <button
                      onClick={() => setClientSection("COMPRAS")}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "COMPRAS" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <CreditCard size={12} />
                      Central de Compras
                    </button>

                    <button
                      onClick={() => setClientSection("SUPORTE")}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "SUPORTE" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <HelpCircle size={12} />
                      SLA & Chamados
                    </button>

                    <button
                      onClick={() => setClientSection("DOCS")}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "DOCS" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <FileText size={12} className="text-[#C49746]" />
                      📖 Guia de Uso &amp; Metodologia
                    </button>

                    <button
                      onClick={() => {
                        // Populate form context with logged client's values for immediate adjustment editing
                        setCadastroType("AJUSTE");
                        setSelectedAjusteId(loggedClient.id);
                        setFormNomeEmpresa(loggedClient.name);
                        setFormCNPJ(loggedClient.cnpj || "91.833.102/0001-44");
                        setFormPlan(loggedClient.currentPlan);
                        setFormSelectedModules(loggedClient.enabledViews || ["DIAGNOSTIC", "MAP", "KANBAN"]);
                        setClientSection("AJUSTAR");
                      }}
                      className={`w-full text-left px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer uppercase ${
                        clientSection === "AJUSTAR" 
                          ? "bg-[#1A1A1A] text-white" 
                          : "text-slate-650 hover:bg-slate-200"
                      }`}
                    >
                      <Settings size={12} />
                      📝 Ajustar Cadastro
                    </button>
                  </nav>

                  <div className="pt-8 border-t border-slate-200">
                    <button
                      onClick={() => setLoggedClient(null)}
                      className="w-full py-1.5 border border-red-300 text-red-700 hover:bg-red-50 text-[10px] font-mono font-black uppercase text-center cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <LogOut size={12} /> Sair do Painel
                    </button>
                  </div>
                </div>

                {/* Client Main Screen Content */}
                <div className="lg:col-span-9 p-6 space-y-6">
                  
                  {/* CLIENT SUB-VIEW 1: GENERAL PROJECTS KPI DASHBOARD */}
                  {clientSection === "DASHBOARD" && (
                    <div className="space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-4 gap-2">
                        <div>
                          <span className="text-[9px] font-mono uppercase bg-slate-100 text-slate-500 px-2 py-0.5 font-bold tracking-wider">ÁREA PRIVATIVA DO ASSINANTE</span>
                          <h4 className="text-lg font-serif font-bold text-slate-900 mt-1">Status de Projetos de Excelência Operacional</h4>
                        </div>
                        <span className="text-xs font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1 font-bold">
                          ● {loggedClient.activeSla}
                        </span>
                      </div>

                      {/* General pipeline visualization */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-4 border border-gray-200 bg-[#FAF9F6] rounded-none">
                          <span className="text-[8px] font-mono text-gray-400 block font-bold">PROJETOS EM CURSO</span>
                          <strong className="text-xl font-serif text-slate-900 mt-1 block">
                            {getClientProjects(loggedClient.id).length} Iniciativas
                          </strong>
                        </div>
                        <div className="p-4 border border-gray-200 bg-[#FAF9F6] rounded-none">
                          <span className="text-[8px] font-mono text-gray-400 block font-bold">EFICIÊNCIA GLOBAL DOS PROCESSOS</span>
                          <strong className="text-xl font-serif text-slate-900 mt-1 block">
                            {loggedClient.id === "comp-itau" ? "79.2%" : "84.5%"} PCE
                          </strong>
                        </div>
                        <div className="p-4 border border-gray-200 bg-[#FAF9F6] rounded-none">
                          <span className="text-[8px] font-mono text-gray-400 block font-bold">SIGMA MÉDIO EXECUTIVO</span>
                          <strong className="text-xl font-serif text-slate-900 mt-1 block">
                            {loggedClient.id === "comp-itau" ? "4.12 σ" : "4.35 σ"}
                          </strong>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <span className="block text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider">
                          Linhas e Ativos Monitorados pela Consultoria E3I:
                        </span>

                        <div className="space-y-3">
                          {getClientProjects(loggedClient.id).map((p: any, idx: number) => (
                            <div key={idx} className="p-4 border-2 border-[#1A1A1A] rounded-none space-y-2">
                              <div className="flex justify-between items-center bg-[#FAF9F6] p-2 border-b border-dashed border-gray-200">
                                <strong className="text-xs font-serif text-slate-950 uppercase">{p.name}</strong>
                                <span className="text-[9.5px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5">
                                  {p.phase}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 font-sans leading-relaxed">{p.objective}</p>
                              
                              {/* Visual tracker timeline */}
                              <div className="pt-2">
                                <span className="block text-[8px] font-mono uppercase text-slate-400 mb-1">Roteiro DMAIC:</span>
                                <div className="grid grid-cols-5 gap-1 text-[8.5px] font-mono text-center font-bold">
                                  <div className="p-1 bg-[#1A1A1A] text-white">D</div>
                                  <div className="p-1 bg-[#1A1A1A] text-white">M</div>
                                  <div className={`p-1 ${["Analyze (Análise)", "Improve (Melhoria ativa)", "Control (Controles CEP)"].includes(p.phase) ? "bg-[#1A1A1A] text-white" : "bg-slate-100 text-slate-400"}`}>A</div>
                                  <div className={`p-1 ${["Improve (Melhoria ativa)", "Control (Controles CEP)"].includes(p.phase) ? "bg-[#C49746] text-white" : "bg-slate-100 text-slate-400"}`}>I</div>
                                  <div className={`p-1 ${p.phase === "Control (Controles CEP)" ? "bg-[#C49746] text-white" : "bg-slate-100 text-slate-400"}`}>C</div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CLIENT SUB-VIEW: INITIAL PROCESS MAPPING */}
                  {clientSection === "MAPEAMENTO_INICIAL" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="border-b border-gray-200 pb-4">
                        <span className="text-[9px] font-mono uppercase bg-slate-100 text-slate-500 px-2 py-0.5 font-bold tracking-wider">MAPEAMENTO CORPORATIVO</span>
                        <h4 className="text-lg font-serif font-bold text-slate-900 mt-1">Mapeamento Inicial de Processos</h4>
                      </div>
                      
                      <div className="bg-white border border-slate-200 p-4 shadow-sm">
                        <MapeadorInicialProcessos />
                      </div>
                    </div>
                  )}

                  {/* CLIENT SUB-VIEW 2: PURCHASES / UPGRADES MARKETPLACE */}
                  {clientSection === "COMPRAS" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="border-b border-gray-200 pb-4">
                        <span className="text-[9px] font-mono uppercase bg-slate-100 text-indigo-700 px-2 py-0.5 font-bold tracking-wider">UPGRADES &amp; LICENCIAMENTO</span>
                        <h4 className="text-lg font-serif font-bold text-slate-900 mt-1">Central de Contratações e Ativos</h4>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        
                        <div className="p-5 border-2 border-slate-950 bg-white space-y-3 flex flex-col justify-between">
                          <div>
                            <strong className="text-xs font-mono font-bold block uppercase text-slate-900">Consultoria Belt Mensal</strong>
                            <p className="text-[11px] text-slate-500 mt-1">
                              Alocação dedicada de 1 Green Belt LSS para conduzir de ponta a ponta as rotudes e setups na sua empresa.
                            </p>
                          </div>
                          <div className="pt-3 border-t border-dashed border-gray-100 flex items-center justify-between">
                            <span className="text-xs font-mono font-extrabold text-indigo-950">R$ 1.500 /mês</span>
                            <button
                              onClick={() => handleClientAddUpgrade("Add-on Consultoria Belt Mensal", 1500)}
                              className="px-3 py-1 bg-[#1A1A1A] text-white hover:bg-[#C49746] font-mono text-[9.5px] font-bold uppercase transition-all rounded-none cursor-pointer"
                            >
                              Adicionar
                            </button>
                          </div>
                        </div>

                        <div className="p-5 border-2 border-slate-950 bg-white space-y-3 flex flex-col justify-between">
                          <div>
                            <strong className="text-xs font-mono font-bold block uppercase text-slate-900">Consultoria Master Belt Trimestral</strong>
                            <p className="text-[11px] text-slate-500 mt-1">
                              Sessões semanais com Master Black Belt habilitado e revisão estocástica dos gargalos críticos do faturamento.
                            </p>
                          </div>
                          <div className="pt-3 border-t border-dashed border-gray-100 flex items-center justify-between">
                            <span className="text-xs font-mono font-extrabold text-indigo-950">R$ 4.500 /único</span>
                            <button
                              onClick={() => handleClientAddUpgrade("Consultoria Master Belt Trimestral", 4500)}
                              className="px-3 py-1 bg-[#1A1A1A] text-white hover:bg-[#C49746] font-mono text-[9.5px] font-bold uppercase transition-all rounded-none cursor-pointer"
                            >
                              Contratar
                            </button>
                          </div>
                        </div>

                        <div className="p-5 border-2 border-slate-950 bg-white space-y-3 flex flex-col justify-between">
                          <div>
                            <strong className="text-xs font-mono font-bold block uppercase text-slate-900">Mapeador Automação OCR Faturas</strong>
                            <p className="text-[11px] text-slate-500 mt-1">
                              Elimina a fila de redutores de setup aplicando automações de leitura de faturamento corporativo por inteligência generativa.
                            </p>
                          </div>
                          <div className="pt-3 border-t border-dashed border-gray-100 flex items-center justify-between">
                            <span className="text-xs font-mono font-extrabold text-indigo-950">R$ 1.200 /mês</span>
                            <button
                              onClick={() => handleClientAddUpgrade("Mapeador Integração OCR Faturas", 1200)}
                              className="px-3 py-1 bg-[#1A1A1A] text-white hover:bg-[#C49746] font-mono text-[9.5px] font-bold uppercase transition-all rounded-none cursor-pointer"
                            >
                              Adicionar
                            </button>
                          </div>
                        </div>

                        <div className="p-5 border-2 border-slate-950 bg-white space-y-3 flex flex-col justify-between">
                          <div>
                            <strong className="text-xs font-mono font-bold block uppercase text-slate-900">Upgrade para SLA Crítico Ativo</strong>
                            <p className="text-[11px] text-slate-500 mt-1">
                              Encurta o atendimento prioritário para no máximo 1 hora ativa por monitoramento em canais dedicados no Slack / Teams.
                            </p>
                          </div>
                          <div className="pt-3 border-t border-dashed border-gray-100 flex items-center justify-between">
                            <span className="text-xs font-mono font-extrabold text-indigo-950">R$ 800 /mês</span>
                            <button
                              onClick={() => handleClientAddUpgrade("Upgrade SLA Crítico Ativo 1h", 800)}
                              className="px-3 py-1 bg-[#1A1A1A] text-white hover:bg-[#C49746] font-mono text-[9.5px] font-bold uppercase transition-all rounded-none cursor-pointer"
                            >
                              Contratar
                            </button>
                          </div>
                        </div>

                      </div>

                      {/* Invoices List */}
                      <div className="pt-4 space-y-3">
                        <span className="block text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider">
                          Dossiês de Cobrança / Invoices Ativos:
                        </span>

                        <div className="border border-slate-205 divide-y divide-slate-200 overflow-hidden font-mono text-xs">
                          {clientPurchases.filter(p => p.companyId === loggedClient.id).map((p) => (
                            <div key={p.id} className="p-3 bg-slate-50 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="bg-slate-200 text-slate-700 px-2 py-0.5 text-[9.5px]">ID: {p.id}</span>
                                <strong className="text-slate-800">{p.item}</strong>
                              </div>
                              <div className="flex items-center gap-4">
                                <span className="font-extrabold text-slate-900">R$ {p.price.toLocaleString("pt-BR")}</span>
                                <span className="bg-emerald-50 text-emerald-800 text-[10px] px-2.5 py-0.5 border border-emerald-200">
                                  {p.paymentStatus || "Pago"}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CLIENT SUB-VIEW 3: SUPPORT TICKETS & SLAs */}
                  {clientSection === "SUPORTE" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="border-b border-gray-200 pb-4">
                        <span className="text-[9px] font-mono uppercase bg-slate-100 text-slate-500 px-2 py-0.5 font-bold tracking-wider">SUPORTE E CONVERSÃO DE ACORDO DE SLA</span>
                        <h4 className="text-lg font-serif font-bold text-slate-900 mt-1">Chamados de Resolução Científica</h4>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        <div className="lg:col-span-4 bg-[#FAF9F6] p-4 border border-slate-300 space-y-3 font-sans text-xs">
                          <strong className="block font-mono text-[10px] uppercase text-[#1A1A1A]">Seu SLA Cadastrado:</strong>
                          <p className="text-slate-650 leading-relaxed font-sans">
                            Seu plano atual é regido por SLA profissional com tempo de resposta limite de até 8 horas úteis (Horário Comercial).
                          </p>
                          <div className="p-2 border border-dashed border-red-200 bg-red-50 text-red-950 font-mono text-[10.5px]">
                            ⚠ Precisa de resposta em 1h? Adquira o "Upgrade SLA Crítico Ativo" na aba Central de Compras.
                          </div>
                        </div>

                        <div className="lg:col-span-8 bg-white border border-slate-350 p-4 rounded-none space-y-4">
                          <strong className="block text-xs font-mono font-bold uppercase text-slate-900">Abrir Novo Chamado Técnico</strong>
                          
                          <form onSubmit={handleCreateSupportTicket} className="space-y-4 font-mono text-xs">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div className="md:col-span-2 space-y-1">
                                <label className="block text-[8.5px] uppercase font-bold text-slate-500">Assunto / Dúvida Operacional</label>
                                <input
                                  type="text"
                                  name="ticketSubject"
                                  required
                                  placeholder="Dúvida sobre balanceamento simplex"
                                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-none bg-slate-50"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="block text-[8.5px] uppercase font-bold text-slate-500">Gravidade</label>
                                <select name="ticketPriority" className="w-full px-2.5 py-1.5 border border-slate-300 rounded-none bg-slate-50">
                                  <option value="BAIXO">BAIXO (Dúvida Geral)</option>
                                  <option value="MEDIA">MÉDIA (Fiscl gargalo estagnado)</option>
                                  <option value="ALTA">CRÍTICA (Erro em Faturamento / SETUP)</option>
                                </select>
                              </div>
                            </div>

                            <div className="space-y-1">
                              <label className="block text-[8.5px] uppercase font-bold text-slate-500">Descrição Detalhada do Obstáculo</label>
                              <textarea
                                name="ticketMsg"
                                required
                                rows={2}
                                placeholder="Gostaríamos de que o simulador analisasse o setup da semana passada..."
                                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-none bg-slate-50 font-sans"
                              />
                            </div>

                            <button
                              type="submit"
                              className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#C49746] text-white font-mono font-bold uppercase transition-all cursor-pointer rounded-none"
                            >
                              Protocolar Chamado Prioritário ✓
                            </button>
                          </form>
                        </div>

                      </div>

                      {/* Active Tickets List */}
                      <div className="space-y-3 pt-2">
                        <span className="block text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider">
                          Seu histórico de chamados registrados:
                        </span>

                        <div className="space-y-2.5">
                          {supportTickets.filter(t => t.companyId === loggedClient.id).map((t, idx) => (
                            <div key={idx} className="p-4 border border-slate-200 bg-slate-50 rounded-none space-y-2">
                              <div className="flex justify-between items-center text-xs font-mono font-bold pb-2 border-b border-slate-200">
                                <strong className="text-slate-800 text-xs">#{t.id} - {t.subject}</strong>
                                <span className={`px-2.5 py-0.5 text-[8.5px] uppercase font-semibold ${
                                  t.status === "Respondido" 
                                    ? "bg-emerald-50 text-emerald-800 border border-emerald-200" 
                                    : "bg-amber-50 text-amber-800 border border-amber-200"
                                }`}>
                                  SLA: {t.status}
                                </span>
                              </div>
                              <p className="text-[11.5px] text-slate-600 font-sans leading-relaxed">
                                {t.message}
                              </p>
                              {t.response && (
                                <div className="bg-[#FAF8F5] p-3 border-l-2 border-[#C49746] mt-2 font-sans font-medium text-[11px] text-slate-700">
                                  <strong>Resposta do Master Belt E3I:</strong>
                                  <p className="mt-1 leading-relaxed font-sans">{t.response}</p>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {clientSection === "AJUSTAR" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="border-b border-gray-200 pb-4">
                        <span className="text-[9px] font-mono uppercase bg-amber-50 text-amber-800 px-2 py-0.5 font-bold tracking-wider">MODALIDADE DE ATUALIZAÇÃO CONTRATUAL</span>
                        <h4 className="text-lg font-serif font-bold text-slate-900 mt-1">Ajustar Cadastro Corporativo (Licença Ativa)</h4>
                        <p className="text-xs text-slate-500 font-sans mt-1">
                          Altere a Razão Social corporativa, CNPJ ou solicite módulos adicionais para os operadores.
                        </p>
                      </div>

                      <form onSubmit={(e) => {
                        e.preventDefault();
                        if (!formNomeEmpresa || !formCNPJ) {
                          alert("Razão Social e CNPJ são campos obrigatórios.");
                          return;
                        }
                        
                        setPredefinedCompanies(prev => prev.map(c => {
                          if (c.id === loggedClient.id) {
                            return {
                              ...c,
                              name: formNomeEmpresa,
                              cnpj: formCNPJ,
                              currentPlan: formPlan,
                              enabledViews: formSelectedModules
                            };
                          }
                          return c;
                        }));

                        const updated = {
                          ...loggedClient,
                          name: formNomeEmpresa,
                          cnpj: formCNPJ,
                          currentPlan: formPlan,
                          enabledViews: formSelectedModules
                        };
                        setLoggedClient(updated);
                        setClientSection("DASHBOARD");
                        alert("Cadastro ajustado com sucesso! Seus privilégios foram re-configurados e atualizados.");
                        appendSystemLog("Cadastro Ajustado PJ", formNomeEmpresa, "Alteração de atributos efetuada pelo próprio assinante.");
                      }} className="space-y-4 max-w-lg bg-[#FAF9F6] p-5 border border-slate-350">
                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Razão Social Atualizada</label>
                          <input
                            type="text"
                            required
                            value={formNomeEmpresa}
                            onChange={(e) => setFormNomeEmpresa(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">CNPJ Corporativo</label>
                          <input
                            type="text"
                            required
                            value={formCNPJ}
                            onChange={(e) => setFormCNPJ(e.target.value)}
                            className="w-full text-xs font-sans p-2 border border-slate-300 rounded-none bg-white font-semibold text-slate-800 focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500 mb-1">Escolher Plano Re-alocado</label>
                            <select
                              value={formPlan}
                              onChange={(e) => setFormPlan(e.target.value)}
                              className="w-full text-xs font-sans p-2 border border-slate-300 bg-white font-semibold text-slate-800 focus:outline-none"
                            >
                              <option value="E3I Starter">E3I Starter</option>
                              <option value="E3I Professional">E3I Professional</option>
                              <option value="E3I Enterprise Black-Belt">E3I Enterprise Black-Belt</option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-1.5 pb-2">
                          <label className="block text-[9px] font-mono font-extrabold uppercase text-slate-500">Módulos Solicitados (Checklist de Acesso):</label>
                          <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                            {[
                              { id: "DIAGNOSTIC", label: "📋 Diagnóstico LSS" },
                              { id: "MAP", label: "🗺️ Modelagem BPM" },
                              { id: "DMAIC", label: "⚡ Suíte DMAIC" },
                              { id: "KANBAN", label: "🗂️ Kanban Operac." },
                              { id: "REPORT", label: "📊 Relatórios" },
                              { id: "ROI_DASHBOARD", label: "📈 Dashboard ROI" },
                              { id: "BI_STUDIO", label: "🔍 BI & Inteligência" },
                              { id: "SIGMA_TREND", label: "🎯 CEP Shewhart" }
                            ].map((v) => {
                              const isChecked = formSelectedModules.includes(v.id);
                              return (
                                <label key={v.id} className="flex items-center gap-1.5 cursor-pointer font-sans select-none border border-slate-200 p-1 bg-white hover:bg-slate-100 font-semibold text-slate-800">
                                  <input
                                    type="checkbox"
                                    checked={isChecked}
                                    onChange={() => {
                                      if (isChecked) {
                                        setFormSelectedModules(prev => prev.filter(x => x !== v.id));
                                      } else {
                                        setFormSelectedModules(prev => [...prev, v.id]);
                                      }
                                    }}
                                    className="accent-[#C49746]"
                                  />
                                  <span className="truncate">{v.label}</span>
                                </label>
                              );
                            })}
                          </div>
                        </div>

                        <button type="submit" className="w-full py-2 bg-[#1A1A1A] hover:bg-emerald-700 text-white font-mono text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer">
                          ✓ Salvar e Aplicar Ajustes
                        </button>
                      </form>
                    </div>
                  )}

                  {clientSection === "DOCS" && (
                    <div className="space-y-6 animate-fade-in text-left">
                      {/* Header with methodology branding */}
                      <div className="border-b border-gray-200 pb-4 relative">
                        <div className="absolute top-0 right-0 bg-indigo-50 border border-indigo-200 text-indigo-800 text-[9px] font-mono font-bold px-2 py-0.5 uppercase tracking-wide">
                          Mapeado com Metodologias Ágeis
                        </div>
                        <span className="text-[9px] font-mono uppercase bg-amber-50 text-[#C49746] px-2 py-0.5 font-bold tracking-wider">GUIA DE IMPLEMENTAÇÃO E METODOLOGIA CONTÍNUA</span>
                        <h4 className="text-xl font-serif font-black text-slate-950 mt-1">Manual de Navegação &amp; Usabilidade LSS</h4>
                        <p className="text-xs text-slate-500 font-sans mt-0.5">
                          Domine as fundações estocásticas, simulação operacional e ferramentas da Suíte E3I Lean Six Sigma para maximizar a capabilidade da sua corporação.
                        </p>
                      </div>

                      {/* Local Interactive tabs for Documentation Chapters */}
                      <div className="bg-slate-50 border border-slate-300 p-2.5 flex flex-wrap gap-1">
                        {[
                          { id: "QUICK", label: "🚀 Guia Rápido" },
                          { id: "DMAIC", label: "⚡ Ciclo DMAIC" },
                          { id: "FILAS", label: "📊 Filas & Little" },
                          { id: "CEP", label: "🎯 Controle SPC (σ)" },
                          { id: "AI_ROI", label: "📈 Inteligência & ROI" }
                        ].map((chapter) => {
                          // We store chosen chapter in a simple custom attribute or state. To be robust, let's use a standard React hook on the component level.
                          return (
                            <button
                              key={chapter.id}
                              type="button"
                              onClick={() => {
                                // Dynamic local DOM injection of current view via active element classes
                                const buttons = document.querySelectorAll(".doc-chapter-btn");
                                buttons.forEach(b => {
                                  b.classList.remove("bg-[#1A1A1A]", "text-white");
                                  b.classList.add("text-slate-600", "hover:bg-slate-200/60");
                                });
                                const targetB = document.getElementById(`doc-btn-${chapter.id}`);
                                if (targetB) {
                                  targetB.classList.add("bg-[#1A1A1A]", "text-white");
                                  targetB.classList.remove("text-slate-600", "hover:bg-slate-200/60");
                                }
                                
                                // Hide all content elements and show the active one
                                const chapters = document.querySelectorAll(".doc-chapter-content");
                                chapters.forEach(c => c.classList.add("hidden"));
                                const targetC = document.getElementById(`doc-content-${chapter.id}`);
                                if (targetC) {
                                  targetC.classList.remove("hidden");
                                }
                              }}
                              id={`doc-btn-${chapter.id}`}
                              className={`doc-chapter-btn py-1.5 px-3 text-[10.5px] font-mono font-extrabold uppercase transition-all tracking-wider cursor-pointer border border-transparent ${
                                chapter.id === "QUICK"
                                  ? "bg-[#1A1A1A] text-white"
                                  : "text-slate-650 hover:bg-slate-200/60"
                              }`}
                            >
                              {chapter.label}
                            </button>
                          );
                        })}
                      </div>

                      {/* --- CHAPTER 1: QUICKSTART (DEFAULT SECTOR) --- */}
                      <div id="doc-content-QUICK" className="doc-chapter-content space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start mt-2">
                          <div className="md:col-span-4 bg-[#FAF9F6] border border-slate-350 p-4 space-y-3">
                            <span className="text-[8.5px] font-mono bg-indigo-100 text-indigo-900 px-2 py-0.5 font-bold uppercase rounded-sm block w-fit">ONBOARDING EM 4 ETAPAS</span>
                            <h5 className="font-serif font-black text-xs text-slate-900 border-b border-slate-200 pb-1.5">Passo-a-Passo de Sucesso</h5>
                            
                            <ol className="text-[11px] space-y-3.5 text-slate-700">
                              <li className="flex gap-2">
                                <span className="bg-slate-900 text-white rounded-full w-4 h-4 text-center text-[9.5px] leading-4 shrink-0 font-bold font-mono">1</span>
                                <div>
                                  <strong className="text-slate-900 block font-serif">Inicar o Ambiente</strong>
                                  Clique no botão azul destacado <strong>&quot;⚡ Entrar na Ferramenta&quot;</strong> para carregar o seu projeto.
                                </div>
                              </li>
                              <li className="flex gap-2">
                                <span className="bg-slate-900 text-white rounded-full w-4 h-4 text-center text-[9.5px] leading-4 shrink-0 font-bold font-mono">2</span>
                                <div>
                                  <strong className="text-slate-900 block font-serif">Abertura de Escopo</strong>
                                  Acesse o módulo <strong>📋 Diagnóstico / Charter</strong> e preencha as restrições financeiras do seu processo.
                                </div>
                              </li>
                              <li className="flex gap-2">
                                <span className="bg-slate-900 text-white rounded-full w-4 h-4 text-center text-[9.5px] leading-4 shrink-0 font-bold font-mono">3</span>
                                <div>
                                  <strong className="text-slate-900 block font-serif">Mapear Processo</strong>
                                  Desenhe cada etapa no <strong>Visual BPM</strong>, designando recursos e seus respectivos tempos de processamento médio.
                                </div>
                              </li>
                              <li className="flex gap-2">
                                <span className="bg-slate-900 text-white rounded-full w-4 h-4 text-center text-[9.5px] leading-4 shrink-0 font-bold font-mono">4</span>
                                <div>
                                  <strong className="text-slate-900 block font-serif">Interpretar &amp; Executar</strong>
                                  Verifique a taxa de saturação e estresse estocástico sugerida na Simulação e monte os cartões de Melhoria Contínua.
                                </div>
                              </li>
                            </ol>
                          </div>

                          <div className="md:col-span-8 bg-white border border-slate-300 p-5 space-y-4">
                            <span className="text-[8.5px] font-mono text-[#C49746] font-bold uppercase tracking-widest block">PILILARES DE SUCESSO COLETIVO</span>
                            <h4 className="text-base font-serif font-extrabold text-slate-900">Como aproveitar a ferramenta em tudo que ela oferece?</h4>
                            <p className="text-xs text-slate-650 leading-relaxed">
                              A Suíte Lean Six Sigma foi desenhada para integrar a gerência de alto nível (foco de resultados e ROI) com a engenharia tática de processos baseada em dados estatísticos. Não use de forma isolada! 
                            </p>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                              <div className="p-3 bg-indigo-50/50 border border-indigo-200">
                                <strong className="block text-xs font-serif text-indigo-950 mb-1">🧠 Simulação Estocástica de Processo</strong>
                                <p className="text-[10.5px] text-slate-650 leading-normal">
                                  Diferente de modelos puramente determinísticos de planilhas, nosso motor estocástico avalia o impacto real da variabilidade de tempos em gargalos ocultos. Reduzir a variabilidade geral é o verdadeiro segredo Six Sigma.
                                </p>
                              </div>

                              <div className="p-3 bg-amber-50/50 border border-amber-200">
                                <strong className="block text-xs font-serif text-amber-950 mb-1">🤖 Co-piloto Inteligente (E3I)</strong>
                                <p className="text-[10.5px] text-slate-650 leading-normal">
                                  Use a inteligência baseada na API do Gemini para estruturar e-mails que se transformam em demandas, criar fichas técnicas padronizadas e sugerir ajustes automáticos de equipe para balanceamento de recursos.
                                </p>
                              </div>
                            </div>

                            <p className="text-[11px] text-slate-500 font-serif italic pt-1.5">
                              &quot;Qualidade é conformidade com os requisitos. Defeitos não devem ser tolerados; devem ser impeditivos.&quot; — Philip Crosby, mestre do Zero Defeitos.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* --- CHAPTER 2: DMAIC --- */}
                      <div id="doc-content-DMAIC" className="doc-chapter-content hidden space-y-5 animate-fade-in">
                        <div className="bg-[#FAF9F6] border border-slate-350 p-6 space-y-4 font-sans text-xs">
                          <span className="text-[8px] font-mono uppercase bg-[#1A1A1A] text-white px-2 py-0.5 font-bold tracking-widest block w-fit">ENTREGA METODOLÓGICA PADRÃO</span>
                          <h4 className="text-lg font-serif font-extrabold text-[#1A1A1A] tracking-tight">O Fluxo DMAIC Integrado na Suíte E3I</h4>
                          <p className="text-slate-600 leading-relaxed">
                            O roteiro DMAIC (Define, Measure, Analyze, Improve, Control) é a espinha dorsal de qualquer projeto de eliminação de defeitos. A ferramenta guiará sua equipe por cada uma de suas etapas de forma intuitiva:
                          </p>

                          <div className="space-y-3 pt-2">
                            {/* D */}
                            <div className="flex gap-3 items-start border-l-2 border-indigo-600 pl-3">
                              <span className="text-sm font-black font-mono text-indigo-700 bg-indigo-50 px-2 py-0.5 border border-indigo-200 shrink-0">D</span>
                              <div>
                                <strong className="text-xs text-slate-900 block font-serif">DEFINE (Definir o Problema &amp; Projeto)</strong>
                                <p className="text-[11px] text-gray-550 leading-relaxed mt-0.5">
                                  Use o <strong>Project Charter</strong> integrado para registrar os objetivos comerciais, as fronteiras do escopo (In/Out) e as equipes responsáveis. Calcule o ROI alvo para que todos entendam a relevância do esforço contínuo.
                                </p>
                              </div>
                            </div>

                            {/* M */}
                            <div className="flex gap-3 items-start border-l-2 border-[#C49746] pl-3">
                              <span className="text-sm font-black font-mono text-[#C49746] bg-amber-50 px-2 py-0.5 border border-amber-200 shrink-0">M</span>
                              <div>
                                <strong className="text-xs text-slate-900 block font-serif">MEASURE (Medir o Processo Atual)</strong>
                                <p className="text-[11px] text-gray-550 leading-relaxed mt-0.5">
                                  Configure o fluxo de atividades no <strong>BPM Mapeador</strong>. Colete dados reais e alimente o desvio-padrão (SD) e tempo médio (Processing Time) para permitir que a matemática de filas calcule a ociosidade ou tempos excessivos de espera.
                                </p>
                              </div>
                            </div>

                            {/* A */}
                            <div className="flex gap-3 items-start border-l-2 border-slate-700 pl-3">
                              <span className="text-sm font-black font-mono text-slate-800 bg-slate-50 px-2 py-0.5 border border-slate-350 shrink-0">A</span>
                              <div>
                                <strong className="text-xs text-slate-900 block font-serif">ANALYZE (Analisar Causas-Raiz &amp; Capacidade)</strong>
                                <p className="text-[11px] text-gray-550 leading-relaxed mt-0.5">
                                  Utilize a matriz do <strong>SIPOC</strong> e o gráfico de capabilidade diagnóstica <strong>(Capacity &amp; Sigma Level)</strong>. Ao identificar qual etapa possui maior variabilidade estocástica, você localiza o verdadeiro gargalo funcional da sua operação.
                                </p>
                              </div>
                            </div>

                            {/* I */}
                            <div className="flex gap-3 items-start border-l-2 border-emerald-600 pl-3">
                              <span className="text-sm font-black font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 border border-emerald-250 shrink-0">I</span>
                              <div>
                                <strong className="text-xs text-slate-900 block font-serif">IMPROVE (Melhorar e Otimizar Fluxos)</strong>
                                <p className="text-[11px] text-gray-550 leading-relaxed mt-0.5">
                                  Acione o rebalanceamento de recursos sugerido pela IA ou aumente o número de canais de atendimento no BPM. Implemente práticas estruturadas de controle Kanbans de produção enxuta, reduzindo o Trabalho em Processo (WIP) e as longas esperas.
                                </p>
                              </div>
                            </div>

                            {/* C */}
                            <div className="flex gap-3 items-start border-l-2 border-red-600 pl-3">
                              <span className="text-sm font-black font-mono text-red-800 bg-red-50 px-2 py-0.5 border border-red-200 shrink-0">C</span>
                              <div>
                                <strong className="text-xs text-slate-900 block font-serif">CONTROL (Controlar e Padronizar Ganhos)</strong>
                                <p className="text-[11px] text-gray-550 leading-relaxed mt-0.5">
                                  Utilize o <strong>Gráfico Kanban do DMAIC</strong> e os cartões de padronização corporativos. Agende auditorias periódicas e use nosso sistema integrado para sincronizar cronogramas operacionais estratégicos diretamente ao Google Agenda, evitando o retrocesso do processo à variabilidade anterior.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* --- CHAPTER 3: FILAS --- */}
                      <div id="doc-content-FILAS" className="doc-chapter-content hidden space-y-5 animate-fade-in">
                        <div className="bg-white border border-slate-300 p-6 space-y-4">
                          <span className="text-[9px] font-mono text-[#C49746] font-bold uppercase tracking-widest block">TEORIA DAS FILAS &amp; ENGENHARIA ESTOCÁSTICA</span>
                          <h4 className="text-base font-serif font-extrabold text-slate-950">A Matemática por Trás do Dimensionamento de Processos</h4>
                          
                          <p className="text-xs text-slate-650 leading-relaxed">
                            A maioria dos gargalos operacionais ocorre porque gerentes estimam capacidades baseados apenas em médias determinísticas (ex: &quot;se o processo demora 10 minutos em média e chegam 6 clientes por hora, precisamos de apenas 1 funcionário&quot;). Essa dedução ignora os estresses aleatórios e picos de chegada.
                          </p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-1">
                            <div className="p-3 bg-amber-50 border border-amber-250 font-mono text-[10.5px] text-slate-900 space-y-2">
                              <span className="font-extrabold block text-slate-950 uppercase border-b border-amber-200 pb-1">📐 Lei de Little (Little&apos;s Law)</span>
                              <p className="text-[10px] leading-relaxed">
                                A Fórmula mais famosa da Engenharia de Produção:
                              </p>
                              <div className="bg-white text-center py-2.5 my-1 border border-amber-300 text-xs font-black text-[#C49746]">
                                WIP (Trabalho em Processo) = λ &times; Lead Time (LT)
                              </div>
                              <p className="text-[10px] text-slate-500 leading-tight">
                                Onde λ é a taxa média de chegada de demandas na unidade de tempo. Reduzindo o tempo de fila em cada etapa, você reduz diretamente o volume de arquivos parados acumulados no painel.
                              </p>
                            </div>

                            <div className="p-3 bg-indigo-50 border border-indigo-250 font-mono text-[10.5px] text-slate-900 space-y-2">
                              <span className="font-extrabold block text-slate-950 uppercase border-b border-indigo-200 pb-1">⚡ Saturação Tática e Estresse G/G/c</span>
                              <p className="text-[10px] leading-relaxed">
                                A aproximação de Kingman para o tempo médio em fila (W_q):
                              </p>
                              <div className="bg-white text-center py-2 text-xs font-serif text-slate-700 italic border border-indigo-300">
                                Espera em Fila ∝ (Saturação / (1 - Saturação)) &times; Variabilidade
                              </div>
                              <p className="text-[10px] text-slate-500 leading-tight">
                                Quando a saturação (Uso de Recursos) aproxima-se de 90%, qualquer desvio-padrão de tempo operacional empurra o tempo de espera para o infinito de forma exponencial. É por isso que balancear atividades com o simulador é vital!
                              </p>
                            </div>
                          </div>

                          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-none text-xs text-[#065F46] leading-relaxed">
                            💡 <strong>Recomendação de Uso:</strong> Sempre que configurar um projeto no editor, use a ferramenta de simulação na área de projeto para monitorar se a saturação ultrapassa os 85%. Se sim, a IA sugerirá adicionar mais um colaborador naquele gargalo para restabelecer a estabilidade.
                          </div>
                        </div>
                      </div>

                      {/* --- CHAPTER 4: CEP --- */}
                      <div id="doc-content-CEP" className="doc-chapter-content hidden space-y-5 animate-fade-in">
                        <div className="bg-white border border-slate-300 p-6 space-y-4">
                          <span className="text-[9px] font-mono text-indigo-700 font-bold uppercase tracking-widest block">PILAR DE CONTROLE E CAPABILIDADE</span>
                          <h4 className="text-base font-serif font-extrabold text-slate-950">CEP Shewhart, Nivel Sigma e Defeitos Amostrais</h4>
                          
                          <p className="text-xs text-slate-650 leading-relaxed">
                            O Controle Estatístico de Processos (CEP/SPC) é o diferencial que separa os líderes industriais focados em melhoria baseada em evidência de executores comuns. Ele permite classificar oscilações operacionais diárias:
                          </p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="p-3 bg-slate-50 border border-slate-300 font-mono text-[10.5px] space-y-2">
                              <strong className="block text-slate-900 font-serif text-xs">📉 Causas Comuns vs Causas Especiais</strong>
                              <p className="text-[10px] text-slate-650 leading-relaxed">
                                <strong>Causas Comuns:</strong> São intrínsecas ao design do processo atual. Mudá-las exige investimento em novas tecnologias ou reestruturação. São normais e previsíveis.
                              </p>
                              <p className="text-[10px] text-slate-650 leading-relaxed">
                                <strong>Causas Especiais:</strong> São anomalias pontuais (ex: falha de software, falta de energia na refinaria, profissional sem treinamento correto). O CEP ajuda a flagrar esses picos de variabilidade no gráfico em tempo real para tomada imediata de medidas.
                              </p>
                            </div>

                            <div className="p-3 bg-slate-50 border border-slate-300 font-mono text-[10.5px] space-y-2">
                              <strong className="block text-slate-900 font-serif text-xs">🎯 Limites de Controle Estatístico (UCL &amp; LCL)</strong>
                              <p className="text-[10px] text-slate-650 leading-relaxed">
                                Diferente dos limites especificados pelo cliente corporativo (que são estáticos e definidos em contrato comercial), os limites UCL (Upper Control Limit) e LCL (Lower Control Limit) são calculados sob a variação histórica real da operação:
                              </p>
                              <div className="bg-slate-100 border border-slate-300 text-center py-1.5 font-bold text-slate-800 text-[10px]">
                                Limites = Média Amostral &plusmn; 3 &times; Desvio Padrão (σ)
                              </div>
                              <p className="text-[10.5.px] text-slate-500 leading-tight">
                                Se uma amostra ultrapassar esse limite de três sigmas, o processo saiu do padrão de estabilidade natural.
                              </p>
                            </div>
                          </div>

                          <div className="p-3 bg-indigo-50 border border-indigo-250 text-indigo-950 font-mono text-[10px] leading-relaxed">
                            📌 <strong>Métrica do Nível Sigma (Cp e Cpk):</strong> O indicador Cp/Cpk exibe o quão centralizado seu processo está. Se o Cpk &gt; 1.33, sua equipe trabalha com alta capabilidade e segurança de margem operacional. Abaixo de 1.0, o risco de gerar atrasos e multas comerciais PJ aumenta severamente.
                          </div>
                        </div>
                      </div>

                      {/* --- CHAPTER 5: AI & ROI --- */}
                      <div id="doc-content-AI_ROI" className="doc-chapter-content hidden space-y-5 animate-fade-in">
                        <div className="bg-[#FAF9F6] border border-[#1A1A1A] p-6 space-y-4 text-xs font-sans">
                          <span className="text-[8px] font-mono uppercase bg-[#C49746] text-white px-2 py-0.5 font-bold tracking-widest block w-fit">CONVERSÃO CORPORATIVA FINANCEIRA</span>
                          <h4 className="text-base font-serif font-extrabold text-[#1A1A1A]">Como Justificar e Extrair Retorno Financeiro (ROI) de Forma Rápida</h4>
                          
                          <p className="text-slate-650 leading-relaxed">
                            Muitos gerentes de engenharia falham em aprovar orçamentos de melhoria contínua porque vendem apenas a redução estocástica ou a mudança de ferramentas sem conectá-las ao faturamento e balanço. Siga o guia matemático empregado pela Suíte LSS:
                          </p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="p-3 bg-white border border-slate-350 space-y-1">
                              <span className="text-[9px] font-mono text-[#C49746] font-bold">MONETIZAÇÃO DO LEAD TIME</span>
                              <strong className="block font-serif text-slate-900 border-b border-gray-150 pb-1 text-xs">Custo de Frustração &amp; Perda de Negócio</strong>
                              <p className="text-[10.5px] text-slate-500 leading-normal">
                                O sistema converte cada minuto desperdiçado de gargalo em custos variáveis de processamento (Mão de Obra ociosa) e em custo de oportunidade gerando gargalos. Reduzir 20 minutos médios de um processamento de propostas PJ pode destravar milhões em estoque de faturamento represado.
                              </p>
                            </div>

                            <div className="p-3 bg-white border border-slate-350 space-y-1">
                              <span className="text-[9px] font-mono text-indigo-700 font-bold">CUSTO DA MÁ QUALIDADE (COPQ)</span>
                              <strong className="block font-serif text-slate-900 border-b border-gray-150 pb-1 text-xs">Mitigação de Multas &amp; Defeitos de Processo</strong>
                              <p className="text-[10.5px] text-slate-500 leading-normal">
                                Itens retrabalhados, erros cadastrais ou descumprimento de SLA com o cliente custam caro. O COPQ ajuda a mapear os gastos ocultos de auditoria, correções e suporte prioritário. Aumentar o nível Sigma do seu processo corta essa torneira de desperdício em tempo real.
                              </p>
                            </div>
                          </div>

                          <div className="p-3.5 bg-amber-50 border border-amber-250 font-mono text-[10.5px] leading-relaxed text-slate-900">
                            🚀 <strong>O papel da IA E3I Black Belt:</strong> O nosso robô generativo emite sugestões completas de mitigação de capacidade para que seu negócio passe a se auto-balancear. Ao acatar a sugestão integrada da IA e re-analisar o modelo BPM, o painel recalcula instantaneamente os ganhos, atualizando o indicador de ROI no cabeçalho executivo para exportação no PowerPoint ou e-mail de diretoria.
                          </div>
                        </div>
                      </div>

                      <div className="p-3.5 bg-indigo-600 font-mono text-[10.5px] font-extrabold uppercase text-white flex items-center justify-between shadow-md">
                        <span>Aproveite ao máximo a suite lean six sigma de alta capabilidade</span>
                        <button
                          type="button"
                          onClick={() => setClientSection("DASHBOARD")}
                          className="px-3 py-1 bg-white hover:bg-slate-100 text-indigo-950 font-black cursor-pointer shadow-sm rounded-xs border border-transparent transition-all"
                        >
                          Ir para o Meu Dashboard ➡️
                        </button>
                      </div>
                    </div>
                  )}

                </div>

              </div>
            )}

          </div>
        )}

        {/* ==================== 3. ÁREA PRIVATIVA DA EMPRESA GESTORA (TOOL OWNER PRIVATE ZONE) ==================== */}
        {activeTab === "OWNER_PORTAL" && (
          <div className="max-w-7xl mx-auto px-6 py-12 animate-fade-in">
            
            {/* IF NOT LOGGED IN: SHOW SIMULATED ACCESS CONTROL INTERACTIVE FORM */}
            {!loggedOwner ? (
              <div className="max-w-md mx-auto bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-5">
                <div className="text-center space-y-2 border-b border-gray-200 pb-4">
                  <div className="inline-flex p-3 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-full mx-auto">
                    <Settings size={20} />
                  </div>
                  <h3 className="text-lg font-serif font-extrabold text-slate-900 uppercase">E3I Soluções - Owner Portal</h3>
                  <p className="text-[10px] text-gray-400 font-mono">
                    Área restrita de gestão de leads, faturamentos, licenças e logs de cibersegurança
                  </p>
                </div>

                <form onSubmit={handleOwnerLoginSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono font-black uppercase text-slate-500">Chave de Homologação Administrativa *</label>
                    <input
                      type="password"
                      required
                      placeholder="Senha do Administrador (E3I#BlackBelt&2026)"
                      value={ownerPassword}
                      onChange={(e) => setOwnerPassword(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-gray-300 rounded-none bg-[#FAF9F6] text-slate-900 focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-indigo-700 hover:bg-indigo-900 text-white font-mono text-xs font-black uppercase tracking-wider transition-all rounded-none cursor-pointer"
                  >
                    Entrar como Admin S.A. ✓
                  </button>
                </form>

                <div className="bg-indigo-50 p-3.5 border border-indigo-200 rounded-none text-[10.5px] text-indigo-950 font-mono">
                  💡 <strong>Portfólio de Gestão de Plataforma:</strong> Chave de acesso restrita atualizada para alta segurança (E3I#BlackBelt&2026). O proprietário pode auditar leads, alterar planos de faturamento corporativos de forma segura e depurar estatísticas do sistema integrado.
                </div>
              </div>
            ) : (
              /* CENTRALIZED HIGH-FIDELITY ADMIN WORKSPACE (PREVENTING ENTERING MAIN WORKSPACE AS ADMIN) */
              <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] rounded-none space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gray-200 pb-4 gap-4 select-none">
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 bg-indigo-950 text-white font-mono font-black flex items-center justify-center text-xs rounded-none">
                      SA
                    </span>
                    <div>
                      <h3 className="text-base font-serif font-extrabold text-slate-900 uppercase">E3I Soluções - Painel S.A.</h3>
                      <p className="text-[10px] text-gray-500 font-mono uppercase tracking-wider">
                        Console Central de Gestão, Triagem de Leads e Controles de Segurança Legislativa da Suíte
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 shrink-0">
                    {/* Launch Workbench as administrator for testing/debugging */}
                    <button
                      onClick={() => {
                        const administratorUser = {
                          fullName: "Dr. Marco Antônio Miranda",
                          email: "admin@sixsigma.com",
                          belt: "Master Black Belt",
                          role: "Admin",
                          companyId: "comp-sa"
                        };
                        localStorage.setItem("six_sigma_active_user", JSON.stringify(administratorUser));
                        localStorage.setItem("lss_current_cargo", "Admin");
                        if (onLoginSuccess) {
                          onLoginSuccess(administratorUser, ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "REPORT", "ENTERPRISE_STUDIO", "BI_STUDIO", "E3I_INTELLIGENCE", "SIGMA_TREND", "ROI_DASHBOARD", "ADMIN", "SUBSCRIPTION_MANAGEMENT"]);
                        }
                      }}
                      className="px-3.5 py-1.5 bg-indigo-700 hover:bg-slate-900 text-white hover:text-indigo-400 border border-black font-mono text-[9.5px] font-black uppercase tracking-wider text-center cursor-pointer flex items-center gap-1.5 transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                    >
                      🚀 Iniciar Workbench E3I
                    </button>

                    <button
                      onClick={() => setLoggedOwner(false)}
                      className="px-3.5 py-1.5 border border-red-350 bg-white text-red-700 hover:bg-red-50 text-[9.5px] font-mono font-black uppercase tracking-wider text-center cursor-pointer flex items-center gap-1.5"
                    >
                      <LogOut size={12} /> Sair do Painel
                    </button>
                  </div>
                </div>

                <div className="pt-2">
                  <AdminPanel
                    enabledViews={adminEnabledViews}
                    setEnabledViews={setAdminEnabledViews}
                    companies={globalCompanies}
                    setCompanies={setGlobalCompanies}
                    projects={globalProjects}
                    setProjects={setProjects}
                    charter={adminCharter}
                    setCharter={setAdminCharter}
                    sipoc={adminSipoc}
                    setSipoc={setAdminSipoc}
                    controlPlans={adminControlPlans}
                    setControlPlans={setAdminControlPlans}
                    arrivalRate={adminArrivalRate}
                    setArrivalRate={setAdminArrivalRate}
                    steps={adminSteps}
                    setSteps={setAdminSteps}
                    currentWorkspaceView="ADMIN"
                    setCurrentWorkspaceView={() => {}}
                    currentCargo="Admin"
                    setCurrentCargo={() => {}}
                    usabilityMode={adminUsabilityMode}
                    setUsabilityMode={setAdminUsabilityMode}
                    usabilityLocked={adminUsabilityLocked}
                    setUsabilityLocked={setAdminUsabilityLocked}
                    onTriggerSharePortal={() => {}}
                  />
                </div>
              </div>
            )}

          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="bg-[#1A1A1A] text-[#FAF9F6]/80 py-12 px-6 md:px-12 border-t-2 border-slate-950 text-xs">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between gap-6 border-b border-white/5 pb-8 mb-8 text-center md:text-left">
            <div className="space-y-2">
              <h4 className="font-serif text-white font-bold italic text-base">E3I Processos Inteligentes</h4>
              <p className="text-slate-400 max-w-sm font-sans leading-relaxed">
                Suíte analítica corporativa integradora de Lean Six Sigma, Teoria de Filas e co-piloto cognitivo de IA generativa.
              </p>
            </div>
            <div className="flex flex-col items-center md:items-end justify-center">
              <span className="text-slate-400 font-mono text-[10px]">Coded and Compiled under production standards 22.</span>
              <span className="text-slate-400 font-mono text-[10px] mt-1 text-[#C49746] font-bold">SLA ACTIVE SUBSCRIPTION SERVICES ENABLED.</span>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row sm:justify-between items-center gap-4 text-[10.5px] text-slate-500">
            <span>&copy; 2026 E3I Soluções S.A. Todos os direitos reservados.</span>
            <div className="flex gap-4">
              <span className="hover:underline cursor-pointer">Políticas de Privacidade</span>
              <span className="hover:underline cursor-pointer">Contrato de Serviço SLA</span>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
