import React, { useState } from "react";
import { ScheduledAudit } from "../types";
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  User, 
  Check, 
  Calendar as CalendarIcon, 
  ListTodo, 
  AlertCircle,
  CheckCircle2,
  CalendarDays,
  Filter
} from "lucide-react";

interface AuditCalendarProps {
  scheduledAudits: ScheduledAudit[];
  setScheduledAudits?: React.Dispatch<React.SetStateAction<ScheduledAudit[]>>;
  corpUsers?: any[];
}

export default function AuditCalendar({ 
  scheduledAudits, 
  setScheduledAudits,
  corpUsers = [] 
}: AuditCalendarProps) {
  const [view, setView] = useState<"MONTH" | "WEEK" | "DAY">("MONTH");
  const [pivotDate, setPivotDate] = useState<Date>(() => {
    // Default to the current date, but check if there are audits we should focus on
    return new Date();
  });
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    new Date().toISOString().split("T")[0]
  );
  const [statusFilter, setStatusFilter] = useState<"Todos" | "Pendente" | "Concluída" | "Atrasada">("Todos");

  // Helper arrays
  const monthNames = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];
  const dayNames = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

  // Normalize date helper
  const formatDateString = (date: Date): string => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  // Filter audits
  const getFilteredAudits = () => {
    return scheduledAudits.filter(audit => {
      if (statusFilter === "Todos") return true;
      return audit.status === statusFilter;
    });
  };

  const filteredAudits = getFilteredAudits();

  // Navigation handlers
  const handlePrev = () => {
    const newDate = new Date(pivotDate);
    if (view === "MONTH") {
      newDate.setMonth(newDate.getMonth() - 1);
    } else if (view === "WEEK") {
      newDate.setDate(newDate.getDate() - 7);
    } else {
      newDate.setDate(newDate.getDate() - 1);
    }
    setPivotDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(pivotDate);
    if (view === "MONTH") {
      newDate.setMonth(newDate.getMonth() + 1);
    } else if (view === "WEEK") {
      newDate.setDate(newDate.getDate() + 7);
    } else {
      newDate.setDate(newDate.getDate() + 1);
    }
    setPivotDate(newDate);
  };

  const handleToday = () => {
    const today = new Date();
    setPivotDate(today);
    setSelectedDateStr(formatDateString(today));
  };

  // Mark audit completed
  const handleToggleComplete = (auditId: string) => {
    if (setScheduledAudits) {
      setScheduledAudits(prev => prev.map(audit => {
        if (audit.id === auditId) {
          const nextStatus = audit.status === "Concluída" ? "Pendente" as const : "Concluída" as const;
          return { ...audit, status: nextStatus };
        }
        return audit;
      }));
    }
  };

  // --- MONTH VIEW GENERATION ---
  const getMonthDays = () => {
    const year = pivotDate.getFullYear();
    const month = pivotDate.getMonth();

    const firstDay = new Date(year, month, 1);
    const startDayOfWeek = firstDay.getDay(); // 0 (Sun) to 6 (Sat)
    const totalDays = new Date(year, month + 1, 0).getDate();
    const totalPrevDays = new Date(year, month, 0).getDate();

    const cells: { date: Date; isCurrentMonth: boolean; dateStr: string }[] = [];

    // Prev month padding
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      const prevDay = totalPrevDays - i;
      const d = new Date(year, month - 1, prevDay);
      cells.push({
        date: d,
        isCurrentMonth: false,
        dateStr: formatDateString(d)
      });
    }

    // Current month
    for (let i = 1; i <= totalDays; i++) {
      const d = new Date(year, month, i);
      cells.push({
        date: d,
        isCurrentMonth: true,
        dateStr: formatDateString(d)
      });
    }

    // Next month padding to fill grid of 42 cells (6 rows)
    const remaining = 42 - cells.length;
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(year, month + 1, i);
      cells.push({
        date: d,
        isCurrentMonth: false,
        dateStr: formatDateString(d)
      });
    }

    return cells;
  };

  // --- WEEK VIEW GENERATION ---
  const getWeekDays = () => {
    const startOfWeek = new Date(pivotDate);
    // Find the Sunday of the current week
    startOfWeek.setDate(pivotDate.getDate() - pivotDate.getDay());

    const days: { date: Date; dateStr: string }[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(startOfWeek);
      d.setDate(startOfWeek.getDate() + i);
      days.push({
        date: d,
        dateStr: formatDateString(d)
      });
    }
    return days;
  };

  // Get audits for a specific date string
  const getAuditsForDate = (dateStr: string) => {
    return filteredAudits.filter(audit => {
      // In some formats it might be YYYY-MM-DD
      return audit.startDate === dateStr;
    });
  };

  return (
    <div className="bg-white border border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4 text-left">
      {/* Header section with view toggle */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <CalendarIcon className="text-[#C49746] w-5 h-5 shrink-0" />
          <div>
            <h6 className="font-serif font-black text-slate-900 text-xs uppercase tracking-wider">
              📅 Calendário de Auditorias de Processo
            </h6>
            <p className="text-[11px] text-slate-500">
              Visualize de forma integrada e cronológica os compromissos de conformidade.
            </p>
          </div>
        </div>

        {/* Filters and View Toggles */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-1 border border-slate-200 rounded text-xs">
            <Filter size={11} className="text-slate-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-transparent border-none p-0 focus:outline-none text-[10.5px] font-mono font-bold uppercase text-slate-700"
            >
              <option value="Todos">Status: Todos</option>
              <option value="Pendente">Pendentes</option>
              <option value="Concluída">Concluídas</option>
              <option value="Atrasada">Atrasadas</option>
            </select>
          </div>

          {/* View Tab Buttons */}
          <div className="flex bg-slate-100 p-0.5 border border-slate-200 rounded">
            {(["MONTH", "WEEK", "DAY"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-3 py-1 text-[10px] font-mono font-extrabold uppercase transition-all rounded-xs cursor-pointer ${
                  view === v
                    ? "bg-slate-900 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-200/50"
                }`}
              >
                {v === "MONTH" ? "Mês" : v === "WEEK" ? "Semana" : "Dia"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between bg-slate-50 p-2.5 border border-slate-200">
        <div className="flex items-center gap-1">
          <button
            onClick={handlePrev}
            className="p-1 hover:bg-slate-200 rounded cursor-pointer transition-colors text-slate-700"
            title="Anterior"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={handleNext}
            className="p-1 hover:bg-slate-200 rounded cursor-pointer transition-colors text-slate-700"
            title="Próximo"
          >
            <ChevronRight size={16} />
          </button>
          <button
            onClick={handleToday}
            className="ml-2 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-300 rounded text-[10px] font-mono font-bold uppercase text-slate-700 tracking-wider transition-all"
          >
            Hoje
          </button>
        </div>

        <h5 className="font-mono font-black text-xs uppercase tracking-widest text-slate-800">
          {view === "MONTH" && (
            <>
              {monthNames[pivotDate.getMonth()]} {pivotDate.getFullYear()}
            </>
          )}
          {view === "WEEK" && (
            <>
              Semana de {getWeekDays()[0].date.getDate()} {monthNames[getWeekDays()[0].date.getMonth()]}
            </>
          )}
          {view === "DAY" && (
            <>
              {pivotDate.getDate()} de {monthNames[pivotDate.getMonth()]} de {pivotDate.getFullYear()} ({dayNames[pivotDate.getDay()]})
            </>
          )}
        </h5>

        <div className="text-[10px] font-mono font-bold text-slate-400">
          E3I Compliance
        </div>
      </div>

      {/* --- MONTH VIEW RENDER --- */}
      {view === "MONTH" && (
        <div className="space-y-1">
          {/* Day Headers */}
          <div className="grid grid-cols-7 gap-1 text-center font-mono text-[9px] uppercase font-bold text-slate-500 py-1 bg-slate-50 border-b border-slate-200">
            {dayNames.map(day => (
              <div key={day} className="p-1">{day}</div>
            ))}
          </div>

          {/* Month Days Grid */}
          <div className="grid grid-cols-7 gap-1">
            {getMonthDays().map(({ date, isCurrentMonth, dateStr }, index) => {
              const dayAudits = getAuditsForDate(dateStr);
              const isSelected = selectedDateStr === dateStr;
              const isToday = formatDateString(new Date()) === dateStr;

              return (
                <div
                  key={index}
                  onClick={() => {
                    setSelectedDateStr(dateStr);
                    setPivotDate(date);
                  }}
                  className={`min-h-[75px] p-1 border cursor-pointer flex flex-col justify-between transition-all group ${
                    isSelected 
                      ? "border-indigo-600 bg-indigo-50/20 shadow-inner" 
                      : isToday
                      ? "border-[#C49746] bg-[#C49746]/5"
                      : isCurrentMonth
                      ? "border-slate-200 bg-white hover:bg-slate-50/50"
                      : "border-slate-100 bg-slate-50/40 text-slate-400"
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className={`text-[10px] font-mono font-bold ${
                      isToday 
                        ? "bg-[#C49746] text-slate-950 px-1 py-0.5 rounded-sm" 
                        : isSelected
                        ? "text-indigo-700 underline font-extrabold"
                        : "text-slate-600"
                    }`}>
                      {date.getDate()}
                    </span>
                    {dayAudits.length > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                    )}
                  </div>

                  {/* Audit List Mini */}
                  <div className="space-y-1 overflow-hidden flex-1 flex flex-col justify-end">
                    {dayAudits.slice(0, 2).map((audit) => (
                      <div
                        key={audit.id}
                        className={`text-[8px] p-1 font-mono uppercase truncate leading-tight rounded-xs border ${
                          audit.status === "Concluída"
                            ? "bg-emerald-50 text-emerald-800 border-emerald-100 line-through"
                            : audit.status === "Atrasada"
                            ? "bg-rose-50 text-rose-800 border-rose-100"
                            : "bg-indigo-50 text-indigo-900 border-indigo-100"
                        }`}
                        title={`${audit.taskName} - Responsável: ${audit.responsibleName}`}
                      >
                        {audit.taskName}
                      </div>
                    ))}
                    {dayAudits.length > 2 && (
                      <div className="text-[7.5px] font-bold text-indigo-700 text-right pr-1">
                        +{dayAudits.length - 2} mais
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* --- WEEK VIEW RENDER --- */}
      {view === "WEEK" && (
        <div className="grid grid-cols-7 gap-2">
          {getWeekDays().map(({ date, dateStr }, index) => {
            const dayAudits = getAuditsForDate(dateStr);
            const isSelected = selectedDateStr === dateStr;
            const isToday = formatDateString(new Date()) === dateStr;

            return (
              <div
                key={index}
                onClick={() => {
                  setSelectedDateStr(dateStr);
                  setPivotDate(date);
                }}
                className={`min-h-[160px] p-2 border cursor-pointer flex flex-col justify-between transition-all ${
                  isSelected
                    ? "border-indigo-600 bg-indigo-50/25"
                    : isToday
                    ? "border-[#C49746] bg-[#C49746]/5"
                    : "border-slate-200 bg-white hover:bg-slate-50"
                }`}
              >
                {/* Day Header */}
                <div className="border-b border-slate-100 pb-1.5 mb-2 flex justify-between items-center">
                  <span className="font-mono text-[9px] uppercase font-bold text-slate-500">
                    {dayNames[date.getDay()]}
                  </span>
                  <span className={`text-[10.5px] font-mono font-bold px-1 rounded-xs ${
                    isToday ? "bg-[#C49746] text-slate-950" : "text-slate-800"
                  }`}>
                    {date.getDate()}
                  </span>
                </div>

                {/* Day Audits Container */}
                <div className="flex-1 space-y-1.5 overflow-y-auto max-h-[110px] pr-0.5">
                  {dayAudits.length === 0 ? (
                    <p className="text-[8.5px] text-slate-300 italic text-center py-4">Sem vistorias</p>
                  ) : (
                    dayAudits.map((audit) => (
                      <div
                        key={audit.id}
                        className={`text-[9px] p-1.5 font-sans rounded-xs border text-left flex flex-col gap-0.5 ${
                          audit.status === "Concluída"
                            ? "bg-emerald-50 text-emerald-800 border-emerald-150 line-through opacity-85"
                            : audit.status === "Atrasada"
                            ? "bg-rose-50 text-rose-800 border-rose-150"
                            : "bg-indigo-50 text-indigo-950 border-indigo-150"
                        }`}
                      >
                        <span className="font-bold truncate" title={audit.taskName}>{audit.taskName}</span>
                        <span className="text-[7.5px] font-mono text-slate-500 truncate flex items-center gap-0.5">
                          <User size={8} /> {audit.responsibleName.split(" ")[0]}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* --- DAY VIEW RENDER --- */}
      {view === "DAY" && (
        <div className="border border-slate-200 bg-white p-4 min-h-[180px]">
          <div className="flex justify-between items-center border-b border-slate-100 pb-2 mb-3">
            <span className="text-xs font-mono uppercase text-slate-400 tracking-wider">
              Dia Selecionado: {selectedDateStr}
            </span>
            <span className="text-[9.5px] font-mono font-bold bg-indigo-50 border border-indigo-100 text-indigo-700 px-2 py-0.5">
              {getAuditsForDate(selectedDateStr).length} Auditoria(s) agendada(s)
            </span>
          </div>

          {getAuditsForDate(selectedDateStr).length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center space-y-2">
              <CalendarDays className="text-slate-300 w-8 h-8" />
              <p className="text-xs text-slate-400">Nenhum compromisso de compliance agendado para este dia.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {getAuditsForDate(selectedDateStr).map((audit) => (
                <div
                  key={audit.id}
                  className={`p-3.5 border text-left flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-all ${
                    audit.status === "Concluída"
                      ? "bg-emerald-50/50 border-emerald-200"
                      : audit.status === "Atrasada"
                      ? "bg-rose-50/50 border-rose-200"
                      : "bg-indigo-50/30 border-indigo-200"
                  }`}
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <h6 className="font-bold text-xs text-slate-900">{audit.taskName}</h6>
                      <span className={`px-1.5 py-0.5 text-[8.5px] font-mono uppercase font-extrabold tracking-wide rounded border ${
                        audit.status === "Concluída"
                          ? "bg-emerald-100/60 text-emerald-800 border-emerald-300"
                          : audit.status === "Atrasada"
                          ? "bg-rose-100/60 text-rose-800 border-rose-300"
                          : "bg-amber-100/60 text-amber-800 border-amber-300 animate-pulse"
                      }`}>
                        {audit.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-slate-600 font-sans">
                      <div className="flex items-center gap-1">
                        <Clock size={11} className="text-slate-400" />
                        <span>Frequência: <strong>{audit.frequency}</strong></span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User size={11} className="text-slate-400" />
                        <span>Responsável: <strong>{audit.responsibleName} ({audit.responsibleEmail})</strong></span>
                      </div>
                      <div className="sm:col-span-2">
                        <span>Processo Operacional: <strong className="text-slate-800">{audit.processName}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Actions inside the calendar */}
                  {setScheduledAudits && (
                    <div className="flex gap-2 self-stretch sm:self-center justify-end shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleComplete(audit.id)}
                        className={`px-3 py-1.5 text-[10px] font-mono font-bold uppercase rounded-xs transition-colors flex items-center gap-1 cursor-pointer ${
                          audit.status === "Concluída"
                            ? "bg-slate-200 text-slate-700 hover:bg-slate-300"
                            : "bg-emerald-600 text-white hover:bg-emerald-700"
                        }`}
                      >
                        <Check size={11} />
                        {audit.status === "Concluída" ? "Desmarcar" : "✓ Concluir"}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Date detail selector footer */}
      <div className="bg-slate-50 p-3.5 border border-slate-200 rounded-none flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div className="text-xs text-slate-600">
          💡 Clique em qualquer dia no calendário para gerenciar ou consultar auditorias planejadas para aquela data específica.
        </div>
        <div className="text-[10px] font-mono bg-white border border-slate-300 text-slate-700 px-2.5 py-1 uppercase font-bold rounded">
          Data Ativa: {selectedDateStr}
        </div>
      </div>
    </div>
  );
}
