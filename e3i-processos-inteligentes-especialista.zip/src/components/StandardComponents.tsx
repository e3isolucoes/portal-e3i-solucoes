import React, { useState } from "react";
import { 
  Check, 
  AlertTriangle, 
  Info, 
  X, 
  UploadCloud, 
  ChevronRight, 
  ChevronLeft, 
  Paperclip,
  Clock,
  Eye,
  Trash2,
  Lock
} from "lucide-react";
import { DESIGN_SYSTEM, COLORS, ACCESSIBILITY } from "../utils/designSystem";

// ==========================================
// 1. BUTTON
// ==========================================
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "accent" | "danger" | "text";
  children: React.ReactNode;
}
export const Button: React.FC<ButtonProps> = ({ 
  variant = "primary", 
  children, 
  className = "", 
  ...props 
}) => {
  const baseClass = DESIGN_SYSTEM.button[variant];
  return (
    <button 
      className={`${baseClass} ${className} ${ACCESSIBILITY.focusRing}`} 
      {...props}
    >
      {children}
    </button>
  );
};

// ==========================================
// 2-6. FORM FIELDS (Input, Select, Textarea, Checkbox, Radio)
// ==========================================
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  id: string; // mandatory for accessibility and focus targeting
}
export const Input: React.FC<InputProps> = ({ label, error, className = "", id, ...props }) => {
  return (
    <div className="w-full text-left">
      {label && (
        <label htmlFor={id} className="block text-xs font-sans font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
          {label}
        </label>
      )}
      <input
        id={id}
        className={`${DESIGN_SYSTEM.input} ${error ? "border-rose-350 focus:border-rose-600 focus:ring-rose-500/20" : ""} ${className}`}
        aria-describedby={error ? `${id}-error` : undefined}
        aria-invalid={!!error}
        {...props}
      />
      {error && (
        <p id={`${id}-error`} className="text-xs text-rose-600 mt-1 font-sans font-medium" role="alert">
          {error}
        </p>
      )}
    </div>
  );
};

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  id: string;
  options: { value: string; label: string }[];
}
export const Select: React.FC<SelectProps> = ({ label, error, options, id, className = "", ...props }) => {
  return (
    <div className="w-full text-left">
      {label && (
        <label htmlFor={id} className="block text-xs font-sans font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
          {label}
        </label>
      )}
      <select
        id={id}
        className={`${DESIGN_SYSTEM.select} ${className}`}
        aria-describedby={error ? `${id}-error` : undefined}
        {...props}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      {error && (
        <p id={`${id}-error`} className="text-xs text-rose-600 mt-1 font-sans" role="alert">
          {error}
        </p>
      )}
    </div>
  );
};

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  id: string;
}
export const Textarea: React.FC<TextareaProps> = ({ label, error, id, className = "", ...props }) => {
  return (
    <div className="w-full text-left">
      {label && (
        <label htmlFor={id} className="block text-xs font-sans font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
          {label}
        </label>
      )}
      <textarea
        id={id}
        className={`${DESIGN_SYSTEM.textarea} ${className}`}
        aria-describedby={error ? `${id}-error` : undefined}
        {...props}
      />
      {error && (
        <p id={`${id}-error`} className="text-xs text-rose-600 mt-1 font-sans" role="alert">
          {error}
        </p>
      )}
    </div>
  );
};

interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}
export const Checkbox: React.FC<CheckboxProps> = ({ label, id, className = "", ...props }) => {
  return (
    <div className="flex items-center gap-2.5 text-left py-1">
      <input
        type="checkbox"
        id={id}
        className={`${DESIGN_SYSTEM.checkbox} ${className}`}
        {...props}
      />
      <label htmlFor={id} className="text-sm font-sans font-medium text-slate-700 select-none cursor-pointer">
        {label}
      </label>
    </div>
  );
};

interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}
export const Radio: React.FC<RadioProps> = ({ label, id, className = "", ...props }) => {
  return (
    <div className="flex items-center gap-2.5 text-left py-1">
      <input
        type="radio"
        id={id}
        className={`${DESIGN_SYSTEM.radio} ${className}`}
        {...props}
      />
      <label htmlFor={id} className="text-sm font-sans font-medium text-slate-700 select-none cursor-pointer">
        {label}
      </label>
    </div>
  );
};

// ==========================================
// 7. DATE PICKER
// ==========================================
interface DatePickerProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  id: string;
}
export const DatePicker: React.FC<DatePickerProps> = ({ label, id, className = "", ...props }) => {
  return (
    <div className="w-full text-left">
      {label && (
        <label htmlFor={id} className="block text-xs font-sans font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
          {label}
        </label>
      )}
      <div className="relative">
        <input
          type="date"
          id={id}
          className={`${DESIGN_SYSTEM.input} ${className}`}
          {...props}
        />
      </div>
    </div>
  );
};

// ==========================================
// 8. DIALOG / MODAL (Completely accessible, keyborad friendly)
// ==========================================
interface DialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}
export const Dialog: React.FC<DialogProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} />
      
      {/* Content wrapper */}
      <div 
        className="relative bg-white rounded-xl shadow-xl border border-slate-200/80 w-full max-w-lg overflow-hidden animate-zoom-in text-left focus:outline-none"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
      >
        <div className="bg-slate-50 border-b border-slate-100 px-5 py-4 flex items-center justify-between">
          <h3 id="dialog-title" className="text-sm font-sans font-extrabold uppercase tracking-wide text-slate-900">
            {title}
          </h3>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition-colors focus:ring-2 focus:ring-slate-200"
            aria-label="Fechar diálogo"
          >
            <X size={16} />
          </button>
        </div>
        <div className="p-5 overflow-y-auto max-h-[75vh]">
          {children}
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 9. DRAWER
// ==========================================
interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  position?: "left" | "right";
}
export const Drawer: React.FC<DrawerProps> = ({ 
  isOpen, 
  onClose, 
  title, 
  children,
  position = "right"
}) => {
  if (!isOpen) return null;
  const positionClass = position === "right" ? "right-0 animate-slide-in-right" : "left-0 animate-slide-in-left";
  return (
    <div className="fixed inset-0 z-50">
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-3xs" onClick={onClose} />
      <div className={`fixed top-0 bottom-0 w-80 max-w-full bg-white shadow-2xl flex flex-col justify-between border-l border-slate-200/85 z-55 ${positionClass} text-left`}>
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-sans font-extrabold uppercase tracking-wide text-slate-900">{title}</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer">
            <X size={16} />
          </button>
        </div>
        <div className="p-5 flex-1 overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 10. TOAST
// ==========================================
export interface ToastMessage {
  id: string;
  type: "success" | "warning" | "error" | "info";
  text: string;
}
export const Toast: React.FC<{ 
  message: ToastMessage; 
  onClose: () => void 
}> = ({ message, onClose }) => {
  const typeMap = {
    success: { bg: "bg-emerald-50 text-emerald-800 border-emerald-200", icon: <Check size={16} className="text-emerald-500" /> },
    warning: { bg: "bg-amber-50 text-amber-800 border-amber-200", icon: <AlertTriangle size={16} className="text-amber-500" /> },
    error: { bg: "bg-rose-50 text-rose-800 border-rose-200", icon: <X size={16} className="text-rose-600" /> },
    info: { bg: "bg-sky-50 text-sky-800 border-sky-200", icon: <Info size={16} className="text-sky-500" /> }
  };
  const config = typeMap[message.type] || typeMap.info;
  return (
    <div className={`flex items-center justify-between p-3.5 rounded-lg border shadow-md max-w-sm w-full animate-slide-in-right ${config.bg}`}>
      <div className="flex items-center gap-2.5">
        {config.icon}
        <span className="text-xs font-sans font-bold leading-tight">{message.text}</span>
      </div>
      <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer">
        <X size={14} />
      </button>
    </div>
  );
};

// ==========================================
// 11. ALERT
// ==========================================
interface AlertProps {
  type?: "success" | "warning" | "error" | "info" | "risk";
  title?: string;
  children: React.ReactNode;
}
export const Alert: React.FC<AlertProps> = ({ 
  type = "info", 
  title, 
  children 
}) => {
  const typeMap = {
    success: { bg: "bg-emerald-50/50 border-emerald-200 text-emerald-800", bar: "bg-emerald-500" },
    warning: { bg: "bg-amber-50/50 border-amber-200 text-amber-800", bar: "bg-amber-500" },
    error: { bg: "bg-rose-50/50 border-rose-250 text-rose-800", bar: "bg-rose-600" },
    risk: { bg: "bg-red-50/60 border-red-200 text-red-900", bar: "bg-red-700" },
    info: { bg: "bg-slate-50 border-slate-200 text-slate-800", bar: "bg-[#1E3A8A]" }
  };
  const config = typeMap[type];
  return (
    <div className={`p-4 border rounded-xl flex gap-3 text-left relative overflow-hidden ${config.bg}`}>
      <div className={`absolute top-0 bottom-0 left-0 w-1 ${config.bar}`} />
      <div className="flex-1 space-y-1">
        {title && <h5 className="font-sans font-extrabold text-xs uppercase tracking-wide text-slate-900">{title}</h5>}
        <div className="text-xs leading-relaxed font-sans mt-0.5">{children}</div>
      </div>
    </div>
  );
};

// ==========================================
// 12. EMPTY STATE
// ==========================================
interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: string;
}
export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionLabel,
  onAction,
  icon = "🔍"
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 md:p-12 text-center border border-dashed border-slate-200 bg-[#FAF9F5]/40 rounded-2xl">
      <div className="text-4xl mb-3.5 select-none">{icon}</div>
      <h4 className="text-sm font-sans font-extrabold uppercase tracking-wide text-slate-800 mb-1">{title}</h4>
      <p className="text-xs text-slate-500 max-w-sm mb-5 leading-relaxed font-sans">{description}</p>
      {actionLabel && onAction && (
        <Button variant="primary" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};

// ==========================================
// 13. SKELETON LOADER
// ==========================================
export const Skeleton: React.FC<{ className?: string }> = ({ className = "" }) => {
  return (
    <div className={`bg-gray-200/90 animate-pulse rounded ${className}`} />
  );
};

// ==========================================
// 14. CARD
// ==========================================
interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  id?: string;
}
export const Card: React.FC<CardProps> = ({ children, className = "", title, id }) => {
  return (
    <div id={id} className={`${DESIGN_SYSTEM.card} ${className}`}>
      {title && (
        <h4 className="border-b border-slate-100 pb-2.5 mb-4 text-xs font-sans font-extrabold uppercase tracking-wider text-slate-900">
          {title}
        </h4>
      )}
      {children}
    </div>
  );
};

// ==========================================
// 15. KPI CARD
// ==========================================
interface KpiCardProps {
  label: string;
  value: string | number;
  variation?: { text: string; dir: "up" | "down" | "flat" };
  id?: string;
}
export const KpiCard: React.FC<KpiCardProps> = ({ label, value, variation, id }) => {
  return (
    <div id={id} className={DESIGN_SYSTEM.kpiCard}>
      <span className="text-[10px] md:text-[10.5px] uppercase font-sans font-bold tracking-widest text-slate-505 leading-none">
        {label}
      </span>
      <div className="mt-3 flex items-baseline justify-between gap-2.5">
        <span className="text-2xl md:text-[27px] font-serif font-black text-slate-900 tracking-tight leading-none">
          {value}
        </span>
        {variation && (
          <span className={`text-[10px] font-mono font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md ${
            variation.dir === "up" ? "bg-emerald-50 text-emerald-800" :
            variation.dir === "down" ? "bg-rose-50 text-rose-800" :
            "bg-slate-100 text-slate-600"
          }`}>
            {variation.text}
          </span>
        )}
      </div>
    </div>
  );
};

// ==========================================
// 16. TABLE
// ==========================================
interface TableProps {
  headers: string[];
  children: React.ReactNode;
}
export const Table: React.FC<TableProps> = ({ headers, children }) => {
  return (
    <div className={DESIGN_SYSTEM.table.container}>
      <table className={DESIGN_SYSTEM.table.table}>
        <thead className={DESIGN_SYSTEM.table.thead}>
          <tr>
            {headers.map((h, i) => (
              <th key={i} className={DESIGN_SYSTEM.table.th}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className={DESIGN_SYSTEM.table.tbody}>
          {children}
        </tbody>
      </table>
    </div>
  );
};

// ==========================================
// 17. PAGINATION
// ==========================================
interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}
export const Pagination: React.FC<PaginationProps> = ({ 
  currentPage, 
  totalPages, 
  onPageChange 
}) => {
  return (
    <nav className="flex items-center justify-between border-t border-slate-150 px-4 py-3 sm:px-6 bg-white rounded-xl mt-4" aria-label="Negação de Páginas">
      <div className="flex-1 flex justify-between sm:hidden">
        <Button 
          variant="secondary" 
          disabled={currentPage === 1} 
          onClick={() => onPageChange(currentPage - 1)}
        >
          Anterior
        </Button>
        <Button 
          variant="secondary" 
          disabled={currentPage === totalPages} 
          onClick={() => onPageChange(currentPage + 1)}
        >
          Próxima
        </Button>
      </div>
      <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
        <div>
          <p className="text-xs text-slate-505 font-sans">
            Página <span className="font-bold text-slate-900">{currentPage}</span> de <span className="font-bold text-slate-900">{totalPages}</span>
          </p>
        </div>
        <div>
          <div className="inline-flex gap-1.5" aria-label="Pagination buttons">
            <button
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="px-2.5 py-1.5 border border-slate-205 rounded-md text-xs font-sans text-slate-500 hover:bg-slate-50 disabled:opacity-40"
              aria-label="Página anterior"
            >
              <ChevronLeft size={14} />
            </button>
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => onPageChange(i + 1)}
                className={`px-3 py-1.5 border rounded-md text-xs font-sans font-bold transition-all ${
                  currentPage === i + 1 
                    ? "bg-[#1E3A8A] text-white border-[#1E3A8A]" 
                    : "border-slate-205 text-slate-500 hover:bg-slate-50"
                }`}
                aria-label={`Ir para a página ${i + 1}`}
                aria-current={currentPage === i + 1 ? "page" : undefined}
              >
                {i + 1}
              </button>
            ))}
            <button
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1.5 border border-slate-205 rounded-md text-xs font-sans text-slate-500 hover:bg-slate-50 disabled:opacity-40"
              aria-label="Próxima página"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

// ==========================================
// 18. TABS
// ==========================================
interface TabsProps {
  tabs: { id: string; label: string }[];
  activeTab: string;
  onTabChange: (id: string) => void;
}
export const Tabs: React.FC<TabsProps> = ({ tabs, activeTab, onTabChange }) => {
  return (
    <div className={DESIGN_SYSTEM.tabs.list}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`${DESIGN_SYSTEM.tabs.tab} ${
              isActive ? DESIGN_SYSTEM.tabs.active : DESIGN_SYSTEM.tabs.inactive
            }`}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};

// ==========================================
// 19. BREADCRUMB
// ==========================================
interface BreadcrumbProps {
  items: { label: string; active?: boolean; onClick?: () => void }[];
}
export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <nav className="flex py-2 px-6 bg-slate-50 border-b border-slate-150" aria-label="Breadcrumb">
      <ol className="inline-flex items-center space-x-1 md:space-x-2">
        {items.map((item, i) => (
          <li key={i} className="inline-flex items-center">
            {i > 0 && <ChevronRight size={12} className="text-slate-400 mx-1 md:mx-1.5" />}
            {item.active ? (
              <span className="text-xs font-sans font-bold text-[#1E3A8A]" aria-current="page">
                {item.label}
              </span>
            ) : (
              <button 
                onClick={item.onClick}
                className="text-xs font-sans text-slate-400 hover:text-slate-800 hover:underline cursor-pointer"
              >
                {item.label}
              </button>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};

// ==========================================
// 20. STEPPER
// ==========================================
interface StepperProps {
  steps: { id: string; label: string; completed?: boolean }[];
  currentStepId: string;
}
export const Stepper: React.FC<StepperProps> = ({ steps, currentStepId }) => {
  const currentIdx = steps.findIndex((s) => s.id === currentStepId);
  return (
    <div className="flex items-center justify-between w-full max-w-xl mx-auto py-3">
      {steps.map((st, idx) => {
        const isCompleted = st.completed || idx < currentIdx;
        const isActive = st.id === currentStepId;
        return (
          <React.Fragment key={st.id}>
            {idx > 0 && (
              <div className={`flex-1 h-0.5 mx-2 ${
                idx <= currentIdx ? "bg-[#1E3A8A]" : "bg-slate-200"
              }`} />
            )}
            <div className="flex flex-col items-center">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center font-sans text-xs font-extrabold ${
                isActive ? "bg-[#C49746] text-white" :
                isCompleted ? "bg-[#1E3A8A] text-white" :
                "bg-slate-100 text-slate-400 border border-slate-250"
              }`}>
                {isCompleted ? <Check size={12} /> : idx + 1}
              </div>
              <span className="text-[9.5px] font-sans font-extrabold text-slate-700 mt-1 uppercase tracking-wider hidden md:block">
                {st.label}
              </span>
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
};

// ==========================================
// 21. BADGE
// ==========================================
interface BadgeProps {
  children: React.ReactNode;
  type?: "neutral" | "success" | "warning" | "error" | "info";
}
export const Badge: React.FC<BadgeProps> = ({ children, type = "neutral" }) => {
  return (
    <span className={DESIGN_SYSTEM.badge[type]}>
      {children}
    </span>
  );
};

// ==========================================
// 22. TOOLTIP
// ==========================================
interface TooltipProps {
  text: string;
  children: React.ReactNode;
}
export const Tooltip: React.FC<TooltipProps> = ({ text, children }) => {
  const [visible, setVisible] = useState(false);
  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {children}
      {visible && (
        <div className="absolute z-60 w-44 p-2 bg-[#0F172A] text-white text-[10px] font-sans rounded-md shadow-lg bottom-full left-1/2 -translate-x-1/2 mb-1.5 leading-snug">
          {text}
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-[#0F172A]" />
        </div>
      )}
    </div>
  );
};

// ==========================================
// 23-26. BRAND-SPECIFIC COMPONENTS
// (Context Selector, Approval Status, Evidence, Activity Timeline)
// ==========================================

export const ContextSelector: React.FC<{ 
  label: string; 
  value: string; 
  onClick: () => void 
}> = ({ label, value, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="flex flex-col items-start px-4 py-2 border border-slate-205 rounded-xl bg-white hover:bg-slate-50 shadow-3xs cursor-pointer text-left transition-all"
    >
      <span className="text-[8.5px] font-mono font-bold tracking-widest text-[#C49746] uppercase">{label}</span>
      <span className="text-xs font-sans font-bold text-slate-800 truncate max-w-[120px] mt-0.5">{value}</span>
    </button>
  );
};

export const ApprovalStatus: React.FC<{ 
  status: "APPROVED" | "REJECTED" | "PENDING"; 
  notes?: string; 
  reviewer?: string 
}> = ({ status, notes, reviewer }) => {
  const map = {
    APPROVED: { label: "Aprovado", style: DESIGN_SYSTEM.badge.success, icon: <Check size={10} /> },
    REJECTED: { label: "Rejeitado", style: DESIGN_SYSTEM.badge.error, icon: <X size={10} /> },
    PENDING: { label: "Pendente", style: DESIGN_SYSTEM.badge.warning, icon: <Clock size={10} /> }
  };
  const config = map[status];
  return (
    <div className="flex items-start gap-2 border border-slate-100 bg-slate-50/50 p-3 rounded-lg text-left">
      <div className="space-y-1 flex-1">
        <div className="flex items-center gap-1.5">
          <span className={config.style}>
            {config.icon}
            {config.label}
          </span>
          {reviewer && <span className="text-[10px] font-sans font-bold text-slate-505">por {reviewer}</span>}
        </div>
        {notes && <p className="text-[11px] text-slate-600 font-sans leading-snug italic mt-1 bg-white p-2 border rounded-md">"{notes}"</p>}
      </div>
    </div>
  );
};

export const EvidenceAttachment: React.FC<{ 
  onUpload: (name: string, size?: string) => void;
  filesList: { id: string; name: string; size?: string }[];
  onDelete?: (id: string) => void;
}> = ({ onUpload, filesList, onDelete }) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const sizeStr = (file.size / 1024).toFixed(1) + " KB";
      onUpload(file.name, sizeStr);
    }
  };

  const handleManualUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const sizeStr = (file.size / 1024).toFixed(1) + " KB";
      onUpload(file.name, sizeStr);
    }
  };

  return (
    <div className="space-y-3 text-left w-full">
      <label className="block text-xs font-sans font-bold text-slate-700 uppercase tracking-wide">
        Evidências e Documentação Complementar
      </label>
      
      {/* Drag Zone */}
      <div 
        onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-5 text-center transition-all cursor-pointer ${
          isDragOver 
            ? "border-[#1E3A8A] bg-slate-50" 
            : "border-slate-205 bg-[#FAF9F5]/35 hover:bg-slate-50/50"
        }`}
      >
        <input 
          type="file" 
          id="evidence-file-input" 
          className="hidden" 
          onChange={handleManualUpload} 
        />
        <label htmlFor="evidence-file-input" className="cursor-pointer">
          <UploadCloud className="mx-auto h-8 w-8 text-slate-400 mb-2 hover:text-[#1E3A8A] transition-colors" />
          <p className="text-xs font-sans font-bold text-slate-700">Arrastar arquivos &amp; documentos ou <span className="text-[#1E3A8A] underline">Procurar</span></p>
          <p className="text-[10px] text-slate-400 font-sans mt-1">SOPs, Fotos, Relatórios Executivos, Planilhas LSS (Max 10MB)</p>
        </label>
      </div>

      {/* Files List */}
      {filesList.length > 0 && (
        <div className="divide-y divide-slate-100 bg-white border border-slate-200 rounded-lg p-2.5 space-y-1.5 transition-all">
          {filesList.map((file) => (
            <div key={file.id} className="flex items-center justify-between text-xs py-1.5 pl-2 pr-1 font-sans">
              <div className="flex items-center gap-2">
                <Paperclip size={13} className="text-slate-400" />
                <span className="font-bold text-slate-800 hover:underline truncate max-w-[180px]">{file.name}</span>
                {file.size && <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-slate-50 px-1 rounded">({file.size})</span>}
              </div>
              {onDelete && (
                <button 
                  onClick={() => onDelete(file.id)}
                  className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                  aria-label={`Excluir evidência ${file.name}`}
                >
                  <Trash2 size={13} />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

interface TimelineItem {
  id: string;
  title: string;
  date: string;
  actor: string;
  badge?: { type: "info" | "success" | "warning"; text: string };
  description?: string;
}
export const ActivityTimeline: React.FC<{ items: TimelineItem[] }> = ({ items }) => {
  return (
    <div className="w-full text-left font-sans py-2">
      <div className="relative border-l-2 border-slate-200 ml-3.5 space-y-5">
        {items.map((item) => (
          <div key={item.id} className="relative pl-6">
            {/* Timeline dot */}
            <span className="absolute -left-[7.5px] top-1 w-3.5 h-3.5 rounded-full bg-white border-2 border-[#1E3A8A] flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-[#1E3A8A]" />
            </span>
            
            <div className="space-y-0.5">
              <span className="text-[9.5px] font-mono font-black text-slate-400 tracking-wider uppercase block">{item.date}</span>
              <div className="flex items-center gap-1.5">
                <h5 className="text-xs font-sans font-black text-slate-900 uppercase tracking-wide">{item.title}</h5>
                {item.badge && <Badge type={item.badge.type}>{item.badge.text}</Badge>}
              </div>
              <span className="text-[10px] text-[#C49746] font-extrabold uppercase tracking-widest block font-sans">Ator: {item.actor}</span>
              {item.description && <p className="text-[11px] text-slate-600 leading-snug max-w-lg font-sans mt-1 bg-slate-50/55 p-2 rounded border border-slate-150">{item.description}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
