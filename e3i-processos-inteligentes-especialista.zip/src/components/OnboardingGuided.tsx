import React, { useState } from "react";
import { 
  Sparkles, 
  HelpCircle, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Check, 
  TrendingUp, 
  Cpu, 
  FileText, 
  Layout, 
  Gauge 
} from "lucide-react";

interface OnboardingGuidedProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectView: (view: string) => void;
  onSelectTemplate: (templateId: string) => void;
}

export default function OnboardingGuided({ 
  isOpen, 
  onClose,
  onSelectView,
  onSelectTemplate
}: OnboardingGuidedProps) {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      title: "Boas-vindas à E3I Soluções",
      subtitle: "A revolução da Excelência Operacional automatizada por IA",
      description: "A E3I unifica Lean Six Sigma, Pesquisa Operacional e Inteligência Artificial para analisar, otimizar e monitorar seus processos de negócios. Este onboarding rápido guiará você pelas principais ferramentas.",
      icon: <Sparkles className="w-12 h-12 text-[#C49746] animate-pulse" />,
      actionLabel: "Iniciar Tour Guiado",
      onClickAction: () => {}
    },
    {
      title: "Navegação por Perfil de Negócio & Área",
      subtitle: "Templates exclusivos para TI, Contabilidade, Finanças, RH, Direito e Operações",
      description: "Oferecemos presets setoriais automatizados que configuram instantaneamente taxas de entrada, tempos de processamento e diagramas SIPOC baseados nas melhores práticas internacionais de mercado.",
      icon: <Layout className="w-12 h-12 text-indigo-600" />,
      actionLabel: "Visualizar Templates de Áreas",
      onClickAction: () => {
        onSelectView("CLIENT_PROJECTS");
      }
    },
    {
      title: "Co-Piloto de IA & Simulação de Monte Carlo",
      subtitle: "Descubra e cure gargalos industriais e operacionais",
      description: "Nossa IA Generativa analisa os tempos de ciclo e sugere melhorias estruturais, enquanto o simulador de fila estocástica (G/G/c) calcula as restrições da operação com precisão matemática.",
      icon: <Cpu className="w-12 h-12 text-purple-600" />,
      actionLabel: "Ir para Co-Piloto",
      onClickAction: () => {
        onSelectView("E3I_INTELLIGENCE");
      }
    },
    {
      title: "Dashboard de ROI & Rentabilidade",
      subtitle: "Acompanhe e configure o impacto financeiro de cada otimização",
      description: "Calcule a redução do Custo de Má Qualidade (COPQ), o retorno do capital investido (ROI) e o Payback em meses conforme sua linha de produção ou esteira de serviços ganha eficiência e nível Sigma.",
      icon: <TrendingUp className="w-12 h-12 text-emerald-600" />,
      actionLabel: "Ver Painel de ROI",
      onClickAction: () => {
        onSelectView("ROI_DASHBOARD");
      }
    },
    {
      title: "Relatórios Executivos em PDF & Impressão",
      subtitle: "Apresente resultados consistentes para sua diretoria",
      description: "Gere em um único clique apresentações de slides dinâmicas ajustadas aos seus dados atuais, ou baixe dossiês técnicos completos prontos para exportar ou imprimir como PDF fidedigno.",
      icon: <FileText className="w-12 h-12 text-amber-900" />,
      actionLabel: "Ver Central de Exportações",
      onClickAction: () => {
        onSelectView("REPORT");
      }
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const curStepData = steps[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white border-2 border-slate-950 w-full max-w-lg p-6 md:p-8 flex flex-col relative shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] rounded-sm animate-fade-in text-left">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-950 transition-colors p-1"
          aria-label="Minimizar onboarding"
        >
          <X size={18} />
        </button>

        {/* Header Indicator */}
        <div className="flex items-center gap-1.5 mb-6">
          <span className="text-[10px] font-mono font-bold tracking-widest text-[#C49746] uppercase bg-[#C49746]/5 px-2.5 py-0.5 rounded-sm flex items-center gap-1.5 border border-[#C49746]/20">
            <Gauge size={10} /> Onboarding Interativo
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            {currentStep + 1} de {steps.length}
          </span>
        </div>

        {/* Step Icon & Main Text */}
        <div className="space-y-4 flex-1">
          <div className="p-3 bg-slate-50 border border-slate-100 w-fit rounded-sm shadow-xs">
            {curStepData.icon}
          </div>
          <div>
            <h3 className="text-xl font-serif font-black text-slate-950 leading-tight">
              {curStepData.title}
            </h3>
            <p className="text-xs font-mono font-semibold text-[#C49746] uppercase tracking-wide mt-1">
              {curStepData.subtitle}
            </p>
          </div>
          <p className="text-xs text-slate-650 leading-relaxed font-sans pt-1">
            {curStepData.description}
          </p>
        </div>

        {/* Quick Action Button for Step */}
        {currentStep > 0 && (
          <div className="mt-5 p-2.5 bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 text-xs rounded-sm">
            <span className="text-[11px] text-slate-500 font-sans italic">
              Deseja explorar este módulo agora com dados reais?
            </span>
            <button
              onClick={() => {
                curStepData.onClickAction();
                onClose();
              }}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold border border-indigo-200 text-[10.5px] uppercase font-mono tracking-tight cursor-pointer transition-all rounded-xs"
            >
              Acessar Módulo
            </button>
          </div>
        )}

        {/* Navigation Indicator dots */}
        <div className="flex items-center justify-between border-t border-slate-100 pt-5 mt-6">
          <div className="flex items-center gap-1.5">
            {steps.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentStep(idx)}
                className={`w-2.5 h-2.5 rounded-full border transition-all ${
                  currentStep === idx 
                    ? "bg-[#C49746] border-[#C49746] scale-110" 
                    : "bg-slate-150 border-slate-300 hover:bg-slate-300"
                }`}
                title={`Ir para etapa ${idx + 1}`}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <button
                onClick={handlePrev}
                className="py-1.5 px-3 border border-slate-300 hover:border-slate-850 hover:bg-slate-55 flex items-center gap-1 text-[11px] font-bold text-slate-700 uppercase tracking-tight cursor-pointer rounded-xs transition-all"
              >
                <ChevronLeft size={12} />
                Anterior
              </button>
            )}

            <button
              onClick={handleNext}
              className="py-2 px-4 bg-slate-950 hover:bg-slate-850 text-white flex items-center gap-1 text-[11px] font-bold uppercase tracking-widest cursor-pointer shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:translate-x-0.5 hover:translate-y-0.5 transition-all rounded-xs"
            >
              {currentStep === steps.length - 1 ? (
                <>
                  <Check size={12} className="text-[#C49746]" />
                  Finalizar
                </>
              ) : (
                <>
                  Avançar
                  <ChevronRight size={12} />
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
