import React, { useState, useEffect } from "react";
import { 
  ProcessStep, 
  Sipoc 
} from "../types";
import { 
  AreaId, 
  CORPORATE_AREAS 
} from "../utils/areaPresets";
import { BUSINESS_TERMS, BusinessType } from "../App";
import { 
  ShieldAlert, 
  Sparkles, 
  ArrowRight, 
  Layers, 
  Cpu, 
  FileText, 
  ChevronRight, 
  CheckCircle2, 
  Settings2, 
  HelpCircle, 
  Info, 
  RefreshCw, 
  Plus, 
  Trash2,
  ListTodo,
  Play,
  ArrowLeft,
  Building,
  Activity,
  User,
  ExternalLink,
  BookOpen
} from "lucide-react";

interface ProcessDesignRoomProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  activeAreaId: AreaId;
  onSwitchArea: (id: AreaId) => void;
  businessType: BusinessType;
  onOpenStepDetail: (stepId: string) => void;
}

export default function ProcessDesignRoom({
  steps,
  setSteps,
  activeAreaId,
  onSwitchArea,
  businessType,
  onOpenStepDetail
}: ProcessDesignRoomProps) {
  // Navigation level: "SIPOC_COVER" (Capa com SIPOC) | "ACTIVITIES_DETAIL" (Sequência detalhada de atividades) | "TASKS_DEEP" (Dossiê de tarefas & check-lists)
  const [drillLevel, setDrillLevel] = useState<"SIPOC_COVER" | "ACTIVITIES_DETAIL" | "TASKS_DEEP">("SIPOC_COVER");
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);

  // States for SIPOC interactive values
  const [localSipoc, setLocalSipoc] = useState({
    suppliers: [] as string[],
    inputs: [] as string[],
    outputs: [] as string[],
    customers: [] as string[]
  });

  const [newSipocItem, setNewSipocItem] = useState("");
  const [activeSipocColumn, setActiveSipocColumn] = useState<"S" | "I" | "O" | "C">("S");

  // Inline editing state for individual SIPOC elements
  const [editingSipoc, setEditingSipoc] = useState<{
    column: "S" | "I" | "O" | "C";
    index: number;
    value: string;
  } | null>(null);
  const [sipocValidationError, setSipocValidationError] = useState<string | null>(null);

  // Inline editing state for process steps (Column P)
  const [editingStepId, setEditingStepId] = useState<string | null>(null);
  const [editingStepName, setEditingStepName] = useState("");
  const [editingStepTime, setEditingStepTime] = useState("");
  const [stepValidationError, setStepValidationError] = useState<string | null>(null);

  // Bottom form validation
  const [bottomFormValidationError, setBottomFormValidationError] = useState<string | null>(null);

  // Helper to persist SIPOC arrays directly to the first step so that the simulator stays in sync!
  const persistSipocToSteps = (updatedSipoc: typeof localSipoc) => {
    if (steps.length > 0) {
      const firstStep = { ...steps[0] };
      firstStep.suppliers = updatedSipoc.suppliers;
      firstStep.requiredInputs = updatedSipoc.inputs;
      firstStep.outputs = updatedSipoc.outputs;
      firstStep.customers = updatedSipoc.customers;

      setSteps(prev => prev.map(s => s.id === firstStep.id ? firstStep : s));
    }
  };

  // Load custom values based on activeAreaId and steps
  useEffect(() => {
    // Fallbacks tailored per area
    let defSuppliers = ["Parceiros de Cadeia", "Sistemas ERP", "Fornecedores de Insumo"];
    let defInputs = ["Matéria-prima", "Faturas e Arquivos XML", "Briefing Técnico"];
    let defOutputs = ["Produto Acabado", "Relatório e Balanço", "Deploy Próxima Squad"];
    let defCustomers = ["Cliente Final", "Diretoria", "Financeiro & Fiscal"];

    if (activeAreaId === "finance") {
      defSuppliers = ["Contabilidade", "Bancos Credenciados", "Faturamento Comercial"];
      defInputs = ["Provisões", "Planilhas de Reembolso", "Notas Fiscais de Entrada"];
      defOutputs = ["Balanço Conciliado", "DRE de Área", "Borderôs Liberados"];
      defCustomers = ["CFO / Tesouraria", "Conselho Fiscal", "Gerentes de Unidade"];
    } else if (activeAreaId === "it_governance") {
      defSuppliers = ["DevOps Squads", "Infra de Nuvem", "Segurança da Informação"];
      defInputs = ["Logs de Uptime", "Requisições de Segurança", "Alertas de Vazamento"];
      defOutputs = ["Patches Homologados", "API Endpoint Ativa", "Cluster Kubernetes Escalado"];
      defCustomers = ["Sistemas Core", "End-Users Corporativos", "Auditoria Geral de TI"];
    } else if (activeAreaId === "hr") {
      defSuppliers = ["Portais de Emprego", "Consultorias de Hunting", "Universidades"];
      defInputs = ["Currículos Triados", "Aprovações de Headcount", "Perfis de Vagas"];
      defOutputs = ["Candidato Contratado", "Onboarding Concluído", "PDI Homologado"];
      defCustomers = ["Gestor de Departamento", "Time Legal / CLT", "Depto Financeiro"];
    } else if (activeAreaId === "data_ai") {
      defSuppliers = ["Bancos Transacionais", "Data Lake", "Analistas de Negócio"];
      defInputs = ["Métricas de Produção", "Feedback Loops", "Query SQL Estocástica"];
      defOutputs = ["Modelos Preditivos de IA", "Insights Automatizados", "Simulações de Monte Carlo"];
      defCustomers = ["Board de Decisão", "Operações e Processos", "Times de Engenharia"];
    } else if (activeAreaId === "legal_risk") {
      defSuppliers = ["Diretrizes Regulatórias", "Advocacia Geral", "Compliance Officers"];
      defInputs = ["Mudanças na Legislação", "Contratos de Fornecedores", "Análise de Riscos"];
      defOutputs = ["Parecer Legal Homologado", "Filtro de Controles LSS", "Mitigações Ativas"];
      defCustomers = ["Sócios Diretores", "Operações Básicas", "Relações com Investidores"];
    } else if (activeAreaId === "core_inbound") {
      defSuppliers = ["Almoxarifado Geral", "Transportadoras de Carga", "Planejamento PCP"];
      defInputs = ["Cargas em Docas", "NFs de Insumo", "Prazos de Setup"];
      defOutputs = ["Placas em Estoque FIFO", "Insumo Homologado", "Nivelamento de Buffer"];
      defCustomers = ["Produção SMT Core", "Operador de Linha", "Planejamento de Vendas"];
    } else if (activeAreaId === "core_outbound") {
      defSuppliers = ["Linha de Fabricação SMT", "Posto de Teste AOI", "Setor de Embalagem"];
      defInputs = ["Lote de Produto Acabado", "Paletes de Despacho", "Guia de Postagem"];
      defOutputs = ["Mercadoria Postada", "Rastreio Ativado", "SLA Macroscópico Batido"];
      defCustomers = ["Clientes Consumidores", "Logística Direta", "Canal de Vendas (CS)"];
    } else if (activeAreaId === "core_sales") {
      defSuppliers = ["Marketing e Leads", "Sucesso do Cliente", "CRM e SDRs"];
      defInputs = ["Pipeline de Negociação", "Briefing de Escopo", "Demandas Customizadas"];
      defOutputs = ["Contrato Assinado", "SLA Comercial Alinhado", "Boas-vindas Enviado"];
      defCustomers = ["PCP / Operações", "Controladoria Operacional", "Cliente do Projeto"];
    }

    // Adapt to steps if customized (we check steps[0] so that deletions and edits are not overwritten)
    const firstStep = steps[0];
    const stepSuppliers = firstStep?.suppliers;
    const stepInputs = firstStep?.requiredInputs;
    const stepOutputs = firstStep?.outputs;
    const stepCustomers = firstStep?.customers;

    setLocalSipoc({
      suppliers: stepSuppliers !== undefined ? stepSuppliers : defSuppliers,
      inputs: stepInputs !== undefined ? stepInputs : defInputs,
      outputs: stepOutputs !== undefined ? stepOutputs : defOutputs,
      customers: stepCustomers !== undefined ? stepCustomers : defCustomers
    });

    // Reset editing and validation upon switching area
    setEditingSipoc(null);
    setSipocValidationError(null);
    setEditingStepId(null);
    setStepValidationError(null);
    setBottomFormValidationError(null);
  }, [activeAreaId]);

  const addSipocItem = (e: React.FormEvent) => {
    e.preventDefault();
    const val = newSipocItem.trim();
    if (!val) {
      setBottomFormValidationError("O item não pode ser vazio.");
      return;
    }
    if (val.length < 3) {
      setBottomFormValidationError("O item deve ter pelo menos 3 caracteres.");
      return;
    }
    if (val.length > 120) {
      setBottomFormValidationError("O item não pode ultrapassar 120 caracteres.");
      return;
    }
    if (/[<>]/.test(val)) {
      setBottomFormValidationError("Caracteres especiais inválidos (<, >).");
      return;
    }

    setBottomFormValidationError(null);

    let colKey: "suppliers" | "inputs" | "outputs" | "customers" = "suppliers";
    if (activeSipocColumn === "S") colKey = "suppliers";
    else if (activeSipocColumn === "I") colKey = "inputs";
    else if (activeSipocColumn === "O") colKey = "outputs";
    else if (activeSipocColumn === "C") colKey = "customers";

    const updatedCol = [...localSipoc[colKey], val];
    const updatedSipoc = {
      ...localSipoc,
      [colKey]: updatedCol
    };

    setLocalSipoc(updatedSipoc);
    persistSipocToSteps(updatedSipoc);
    setNewSipocItem("");
  };

  const handleSaveSipocItem = () => {
    if (!editingSipoc) return;
    const { column, index, value } = editingSipoc;
    
    // Data Validation
    const trimmed = value.trim();
    if (!trimmed) {
      setSipocValidationError("O valor não pode ser vazio.");
      return;
    }
    if (trimmed.length < 3) {
      setSipocValidationError("Mínimo de 3 caracteres.");
      return;
    }
    if (trimmed.length > 120) {
      setSipocValidationError("Máximo de 120 caracteres.");
      return;
    }
    if (/[<>]/.test(trimmed)) {
      setSipocValidationError("Caracteres inválidos contidos.");
      return;
    }

    let colKey: "suppliers" | "inputs" | "outputs" | "customers" = "suppliers";
    if (column === "S") colKey = "suppliers";
    else if (column === "I") colKey = "inputs";
    else if (column === "O") colKey = "outputs";
    else if (column === "C") colKey = "customers";

    const updatedCol = [...localSipoc[colKey]];
    updatedCol[index] = trimmed;

    const updatedSipoc = {
      ...localSipoc,
      [colKey]: updatedCol
    };

    setLocalSipoc(updatedSipoc);
    persistSipocToSteps(updatedSipoc);
    setEditingSipoc(null);
    setSipocValidationError(null);
  };

  const removeSipocItem = (column: "S" | "I" | "O" | "C", index: number) => {
    let colKey: "suppliers" | "inputs" | "outputs" | "customers" = "suppliers";
    if (column === "S") colKey = "suppliers";
    else if (column === "I") colKey = "inputs";
    else if (column === "O") colKey = "outputs";
    else if (column === "C") colKey = "customers";

    const updatedCol = localSipoc[colKey].filter((_, i) => i !== index);
    const updatedSipoc = {
      ...localSipoc,
      [colKey]: updatedCol
    };

    setLocalSipoc(updatedSipoc);
    persistSipocToSteps(updatedSipoc);

    if (editingSipoc?.column === column && editingSipoc?.index === index) {
      setEditingSipoc(null);
      setSipocValidationError(null);
    }
  };

  const handleSaveStep = (stepId: string) => {
    const trimmedName = editingStepName.trim();
    if (!trimmedName) {
      setStepValidationError("O nome da atividade não pode ser vazio.");
      return;
    }
    if (trimmedName.length < 3) {
      setStepValidationError("Mínimo de 3 caracteres.");
      return;
    }
    if (trimmedName.length > 80) {
      setStepValidationError("Máximo de 80 caracteres.");
      return;
    }
    if (/[<>]/.test(trimmedName)) {
      setStepValidationError("Remova caracteres como < ou >.");
      return;
    }

    const parsedTime = parseFloat(editingStepTime);
    if (isNaN(parsedTime) || parsedTime <= 0) {
      setStepValidationError("Duração em minutos precisa ser positiva.");
      return;
    }
    if (parsedTime > 1000) {
      setStepValidationError("Tempo máximo permitido é 1000m.");
      return;
    }

    setSteps(prev => prev.map(s => {
      if (s.id === stepId) {
        return {
          ...s,
          name: trimmedName,
          processingTime: parsedTime
        };
      }
      return s;
    }));

    setEditingStepId(null);
    setStepValidationError(null);
  };

  const activeAreaObj = CORPORATE_AREAS.find(a => a.id === activeAreaId) || CORPORATE_AREAS[0];

  // Language customization depending on Selected Business Type!
  const terms = BUSINESS_TERMS[businessType] || BUSINESS_TERMS.INDUSTRIAL;

  return (
    <div id="process-design-studio-room" className="bg-white border-4 border-[#1A1A1A] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden">
      
      {/* Top Banner Navigation Dashboard */}
      <div className="bg-[#1A1A1A] p-4 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-4 border-[#1A1A1A] select-none">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-600 text-white font-mono text-[11px] font-black rounded-xs flex items-center gap-1">
            <Layers size={14} className="stroke-2 animate-pulse" />
            STUDIO
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[9px] uppercase font-mono tracking-widest text-[#C49746]">BPM Process Designer</span>
              <span className="text-[8px] bg-[#FAF8F5]/10 text-white/80 px-1.5 py-0.2 rounded-xs border border-white/10 font-mono">UX Engine</span>
            </div>
            <h4 className="font-serif text-lg leading-tight font-black">
              Sala Crítica de Design &amp; Modelagem Estocástica de Processo
            </h4>
          </div>
        </div>

        {/* Tactical Drill-Down Controller Navigation Cards */}
        <div className="flex bg-white/5 border border-white/15 p-1 rounded-sm items-center self-start md:self-auto">
          <button
            type="button"
            onClick={() => setDrillLevel("SIPOC_COVER")}
            className={`p-1.5 px-3 rounded-xs font-mono text-[9px] font-extrabold flex items-center gap-1 transition-all ${
              drillLevel === "SIPOC_COVER" 
                ? "bg-indigo-600 text-white shadow-3xs" 
                : "text-white/60 hover:text-white bg-transparent"
            }`}
          >
            <span className="opacity-70">Lvl 1:</span> SIPOC Capa
          </button>
          
          <ChevronRight size={10} className="text-white/30 hidden md:block mx-0.5" />

          <button
            type="button"
            onClick={() => setDrillLevel("ACTIVITIES_DETAIL")}
            className={`p-1.5 px-3 rounded-xs font-mono text-[9px] font-extrabold flex items-center gap-1 transition-all ${
              drillLevel === "ACTIVITIES_DETAIL" 
                ? "bg-amber-600 text-white shadow-3xs" 
                : "text-white/60 hover:text-white bg-transparent"
            }`}
          >
            <span className="opacity-70">Lvl 2:</span> Atividades
          </button>

          <ChevronRight size={10} className="text-white/30 hidden md:block mx-0.5" />

          <button
            type="button"
            onClick={() => {
              if (steps.length > 0) {
                setDrillLevel("TASKS_DEEP");
                if (!selectedStepId) setSelectedStepId(steps[0].id);
              }
            }}
            className={`p-1.5 px-3 rounded-xs font-mono text-[9px] font-extrabold flex items-center gap-1 transition-all ${
              drillLevel === "TASKS_DEEP" 
                ? "bg-emerald-600 text-white shadow-3xs" 
                : "text-white/60 hover:text-white bg-transparent"
            }`}
          >
            <span className="opacity-70">Lvl 3:</span> Tarefas Operacionais
          </button>
        </div>
      </div>

      {/* Area selection bar with customizable terms */}
      <div className="p-4 bg-gray-50 border-b border-gray-200">
        <div className="flex flex-col gap-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-mono font-black text-gray-400 uppercase text-[9px] tracking-wider">Linguagem / Semântica Ativa:</span>
              <span className="px-2 py-0.5 bg-amber-50 border border-amber-300 text-amber-900 font-bold uppercase rounded-xs text-[9px] font-mono">
                {activeAreaObj.icon} {activeAreaObj.name.split(",")[0]}
              </span>
              <span className="text-[10px] text-gray-500 font-sans italic hidden sm:inline">
                (Personalizado para o modelo: <strong>{terms.title}</strong>)
              </span>
            </div>
            <div className="flex items-center gap-3 text-[9px] font-mono text-gray-400">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 block shrink-0"></span> Processos de Suporte
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-600 block shrink-0"></span> Processos Primários (Core)
              </span>
            </div>
          </div>
          
          {/* Visual Sector Selector Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-9 gap-1.5 pt-1">
            {CORPORATE_AREAS.map(area => {
              const isCurrent = area.id === activeAreaId;
              const isSupport = area.type === "SUPPORT";
              return (
                <button
                  key={area.id}
                  onClick={() => onSwitchArea(area.id)}
                  className={`p-2 rounded-xs text-[9.5px] font-bold border transition-all duration-200 flex flex-col items-center justify-center gap-1 text-center min-h-[58px] cursor-pointer ${
                    isCurrent 
                      ? isSupport 
                        ? "bg-indigo-50/80 border-indigo-600 text-indigo-900 shadow-sm scale-[1.02] ring-1 ring-indigo-600/20" 
                        : "bg-amber-50/80 border-amber-600 text-amber-900 shadow-sm scale-[1.02] ring-1 ring-amber-600/20" 
                      : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300"
                  }`}
                  title={area.name}
                >
                  <span className="text-sm leading-none">{area.icon}</span>
                  <span className="font-sans font-semibold leading-tight tracking-tight max-w-full truncate">{area.name.split(",")[0]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* RENDER DYNAMIC LEVEL BODY VIEW */}
      <div className="p-5 md:p-8 space-y-6 bg-[#FCFBF9]">

        {/* ----------------- LEVEL 1: SIPOC COVER ----------------- */}
        {drillLevel === "SIPOC_COVER" && (
          <div className="space-y-6 animate-fade-in text-left">
            {/* Introductory Cover Page Banner */}
            <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2 text-left max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className={`text-[8.5px] font-mono font-black uppercase px-2 py-0.5 rounded-xs tracking-wider text-white ${
                    activeAreaObj.type === "SUPPORT" ? "bg-indigo-700" : "bg-amber-750"
                  }`}>
                    {activeAreaObj.type === "SUPPORT" ? "Processo de Suporte" : "Processo Primário (Core)"}
                  </span>
                  <span className="text-[9px] font-mono font-bold text-gray-400 uppercase bg-gray-100 border border-gray-200 px-2 py-0.5">
                    ISO 9001 / SIX SIGMA FRONT SHEET
                  </span>
                </div>
                <h3 className="font-serif text-2xl font-black text-gray-950">
                  Capa do Processo: {activeAreaObj.name}
                </h3>
                <p className="text-[11.5px] text-gray-600 leading-relaxed font-sans">
                  {activeAreaObj.shortDesc} O mapeamento de fronteiras **SIPOC** (Suppliers, Inputs, Process, Outputs, Customers) define de forma inequívoca o ciclo de valor de **{activeAreaObj.name.split(",")[0]}** antes do início dos ensaios de simulações estocásticas.
                </p>
                <div className="flex gap-2.5 pt-1 flex-wrap">
                  {activeAreaObj.frameworks.map((fw, idx) => (
                    <span key={idx} className="text-[9px] font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200 px-20 px-2 py-0.5 rounded-xs">
                      {fw}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-2 shrink-0 md:text-right w-full md:w-auto">
                <button
                  type="button"
                  onClick={() => setDrillLevel("ACTIVITIES_DETAIL")}
                  className="bg-[#1A1A1A] hover:bg-gray-800 text-white p-3 px-5 text-xs font-mono font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-[3px_3px_0px_0px_rgba(180,83,9,1)] border border-[#1A1A1A] select-none transition-transform active:translate-y-0.5 cursor-pointer"
                >
                  Acessar Fluxograma Visual ➔
                </button>
                <span className="text-[9px] text-right text-gray-400 font-mono hidden md:block">
                  Drill-Down para calibração estocástica &gt;&gt;
                </span>
              </div>
            </div>

            {/* THE INTERACTIVE TACTILE SIPOC BOARD */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              
              {/* S - SUPPLIERS */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4.5 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(79,70,229,1)] transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                    <span className="text-2xl font-serif font-black text-indigo-600">S</span>
                    <span className="text-[8px] font-mono font-black text-gray-400 uppercase tracking-widest">Suppliers</span>
                  </div>
                  <h5 className="font-serif text-[10.5px] uppercase tracking-wide text-gray-950 font-black">Fornecedores</h5>
                  <p className="text-[9.5px] text-gray-500 leading-normal font-sans">Fontes de entrada (sistemas, equipes ou terceiros) que alimentam o processo.</p>
                  
                  <div className="space-y-1.5 pt-1.5 font-sans">
                    {localSipoc.suppliers.map((item, index) => {
                      const isEditing = editingSipoc?.column === "S" && editingSipoc?.index === index;
                      return (
                        <div key={index} className="transition-all">
                          {isEditing ? (
                            <div className="flex flex-col gap-1 p-1 bg-white border border-[#4F46E5] rounded-sm">
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  value={editingSipoc.value}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditingSipoc(prev => prev ? { ...prev, value: val } : null);
                                    if (sipocValidationError) setSipocValidationError(null);
                                  }}
                                  autoFocus
                                  className="flex-grow text-[10px] p-1 bg-gray-50 border border-gray-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded-xs font-semibold text-gray-905"
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") handleSaveSipocItem();
                                    if (e.key === "Escape") setEditingSipoc(null);
                                  }}
                                />
                                <button 
                                  onClick={handleSaveSipocItem}
                                  className="text-emerald-600 hover:text-emerald-800 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Salvar (Enter)"
                                >
                                  ✓
                                </button>
                                <button 
                                  onClick={() => setEditingSipoc(null)}
                                  className="text-gray-400 hover:text-gray-650 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Cancelar (Esc)"
                                >
                                  ×
                                </button>
                              </div>
                              {sipocValidationError && (
                                <span className="text-[8px] text-red-500 font-mono font-bold leading-none">{sipocValidationError}</span>
                              )}
                            </div>
                          ) : (
                            <div 
                              onClick={() => {
                                setEditingSipoc({ column: "S", index, value: item });
                                setSipocValidationError(null);
                              }}
                              className="flex items-center justify-between text-left text-[10px] p-2 bg-indigo-50/40 border border-indigo-200/30 hover:border-indigo-400 hover:bg-[#FAF8F5]/80 text-[#1A1A1A] group select-none cursor-pointer rounded-xs transition-colors relative"
                              title="Clique para editar este fornecedor"
                            >
                              <span className="truncate max-w-[130px] font-semibold" title={item}>{item}</span>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="text-[8.5px] text-indigo-750 font-mono">✏️</span>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeSipocItem("S", index);
                                  }} 
                                  className="text-gray-400 hover:text-red-650 font-bold px-1"
                                  title="Excluir"
                                >
                                  ×
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {localSipoc.suppliers.length === 0 && (
                      <span className="text-[9px] text-red-400 italic font-mono block">Sem fornecedores.</span>
                    )}
                  </div>
                </div>

                <button 
                  onClick={() => { 
                    setActiveSipocColumn("S"); 
                    setBottomFormValidationError(null);
                  }}
                  className="mt-4 text-[9px] font-mono font-black text-indigo-700 text-left hover:underline flex items-center justify-between cursor-pointer border-none bg-transparent"
                >
                  <span>+ ADD FORNECEDOR</span>
                  <Plus size={10} />
                </button>
              </div>

              {/* I - INPUTS */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4.5 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(79,70,229,1)] transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                    <span className="text-2xl font-serif font-black text-indigo-600">I</span>
                    <span className="text-[8px] font-mono font-black text-gray-400 uppercase tracking-widest">Inputs</span>
                  </div>
                  <h5 className="font-serif text-[10.5px] uppercase tracking-wide text-gray-950 font-black">Insumos (Entradas)</h5>
                  <p className="text-[9.5px] text-gray-500 leading-normal font-sans">Ativadores de fluxo: requisições, dados estruturados ou materiais brutos.</p>
                  
                  <div className="space-y-1.5 pt-1.5 font-sans">
                    {localSipoc.inputs.map((item, index) => {
                      const isEditing = editingSipoc?.column === "I" && editingSipoc?.index === index;
                      return (
                        <div key={index} className="transition-all">
                          {isEditing ? (
                            <div className="flex flex-col gap-1 p-1 bg-white border border-[#4F46E5] rounded-sm">
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  value={editingSipoc.value}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditingSipoc(prev => prev ? { ...prev, value: val } : null);
                                    if (sipocValidationError) setSipocValidationError(null);
                                  }}
                                  autoFocus
                                  className="flex-grow text-[10px] p-1 bg-gray-50 border border-gray-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded-xs font-semibold text-gray-950"
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") handleSaveSipocItem();
                                    if (e.key === "Escape") setEditingSipoc(null);
                                  }}
                                />
                                <button 
                                  onClick={handleSaveSipocItem}
                                  className="text-emerald-600 hover:text-emerald-800 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Salvar (Enter)"
                                >
                                  ✓
                                </button>
                                <button 
                                  onClick={() => setEditingSipoc(null)}
                                  className="text-gray-400 hover:text-gray-650 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Cancelar (Esc)"
                                >
                                  ×
                                </button>
                              </div>
                              {sipocValidationError && (
                                <span className="text-[8px] text-red-500 font-mono font-bold leading-none">{sipocValidationError}</span>
                              )}
                            </div>
                          ) : (
                            <div 
                              onClick={() => {
                                setEditingSipoc({ column: "I", index, value: item });
                                setSipocValidationError(null);
                              }}
                              className="flex items-center justify-between text-left text-[10px] p-2 bg-indigo-50/40 border border-indigo-200/30 hover:border-indigo-400 hover:bg-[#FAF8F5]/80 text-[#1A1A1A] group select-none cursor-pointer rounded-xs transition-colors relative"
                              title="Clique para editar este insumo"
                            >
                              <span className="truncate max-w-[130px] font-semibold" title={item}>{item}</span>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="text-[8.5px] text-indigo-750 font-mono">✏️</span>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeSipocItem("I", index);
                                  }} 
                                  className="text-gray-400 hover:text-red-650 font-bold px-1"
                                  title="Excluir"
                                >
                                  ×
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {localSipoc.inputs.length === 0 && (
                      <span className="text-[9px] text-red-400 italic font-mono block">Sem insumos.</span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => { 
                    setActiveSipocColumn("I"); 
                    setBottomFormValidationError(null);
                  }}
                  className="mt-4 text-[9px] font-mono font-black text-indigo-700 text-left hover:underline flex items-center justify-between cursor-pointer border-none bg-transparent"
                >
                  <span>+ ADD INSUMO</span>
                  <Plus size={10} />
                </button>
              </div>

              {/* P - PROCESS (CLICK TO DRILL-DOWN OR EDIT INLINE!) */}
              <div className="bg-[#FAF9F5] border-2 border-[#1A1A1A] p-4.5 flex flex-col justify-between shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:shadow-[4px_4px_0px_0px_rgba(235,142,6,1)] transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2 border-gray-200">
                    <span className="text-2xl font-serif font-black text-[#C49746]">P</span>
                    <span className="text-[8px] font-mono font-black text-gray-400 uppercase tracking-widest">Process</span>
                  </div>
                  <h5 className="font-serif text-[10.5px] uppercase tracking-wide text-gray-950 font-black">Processo Macro</h5>
                  <p className="text-[9.5px] text-gray-500 leading-normal font-sans">Processamento de atividades ({steps.length} etapas no fluxo corporativo).</p>
                  
                  <div className="space-y-2 pt-1.5 font-sans">
                    {steps.map((st, index) => {
                      const isEditingStep = editingStepId === st.id;
                      return (
                        <div key={st.id} className="transition-all">
                          {isEditingStep ? (
                            <div className="p-2 border border-amber-400 bg-amber-50/35 rounded-xs space-y-2">
                              <div className="space-y-1 text-left">
                                <label className="text-[8px] font-mono font-bold text-amber-900 uppercase tracking-widest">Atividade:</label>
                                <input
                                  type="text"
                                  value={editingStepName}
                                  onChange={(e) => setEditingStepName(e.target.value)}
                                  className="w-full text-[10px] p-1 bg-white border border-[#1A1A1A]/35 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-xs font-semibold text-gray-950"
                                  placeholder="Nome"
                                />
                              </div>
                              
                              <div className="grid grid-cols-2 gap-1.5">
                                <div className="space-y-0.5 text-left">
                                  <label className="text-[7.5px] font-mono font-bold text-amber-900 uppercase tracking-widest">Tempo (min):</label>
                                  <input
                                    type="number"
                                    step="0.1"
                                    value={editingStepTime}
                                    onChange={(e) => setEditingStepTime(e.target.value)}
                                    className="w-full text-[10px] p-0.5 bg-white border border-[#1A1A1A]/30 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-xs font-mono font-bold text-gray-950"
                                  />
                                </div>
                                <div className="flex items-end justify-end gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleSaveStep(st.id)}
                                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-[9.5px] font-black p-1 px-1.5 rounded-xs cursor-pointer"
                                    title="Gravar"
                                  >
                                    ✓
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingStepId(null);
                                      setStepValidationError(null);
                                    }}
                                    className="bg-gray-500 hover:bg-gray-655 text-white text-[9.5px] font-black p-1 px-1.5 rounded-xs cursor-pointer"
                                    title="Cancelar"
                                  >
                                    ×
                                  </button>
                                </div>
                              </div>
                              {stepValidationError && (
                                <span className="text-[8.5px] font-mono leading-none text-red-650 font-bold block">{stepValidationError}</span>
                              )}
                            </div>
                          ) : (
                            <div 
                              className="p-1.5 border border-amber-200 bg-white hover:bg-amber-100 flex items-center justify-between gap-1.5 group select-none rounded-3xs cursor-pointer transition-all duration-150"
                              onClick={() => {
                                setSelectedStepId(st.id);
                                setDrillLevel("ACTIVITIES_DETAIL");
                              }}
                              title="Clique duplo para focar ou ✏️ para editar"
                            >
                              <div className="flex items-center gap-1.5 min-w-0 flex-grow">
                                <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${st.completed ? 'bg-emerald-600' : 'bg-[#C49746]'}`}></span>
                                <span className={`font-sans font-bold text-[10px] text-gray-900 truncate ${st.completed ? 'line-through text-gray-400' : ''}`} title={st.name}>
                                  {st.name}
                                </span>
                                <span className="text-[8px] font-mono text-[#C49746] shrink-0">({st.processingTime.toFixed(1)}m)</span>
                              </div>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingStepId(st.id);
                                    setEditingStepName(st.name);
                                    setEditingStepTime(st.processingTime.toString());
                                    setStepValidationError(null);
                                  }}
                                  className="p-0.5 hover:bg-amber-200 text-amber-955 rounded-xs font-bold text-[9px] cursor-pointer"
                                  title="Editar Atividade"
                                >
                                  ✏️
                                </button>
                                <ChevronRight size={10} className="text-[#C49746]" />
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 mt-2 border-t border-dashed border-gray-200">
                  <button
                    type="button"
                    onClick={() => setDrillLevel("ACTIVITIES_DETAIL")}
                    className="w-full bg-[#C49746] hover:bg-[#D97706] text-white p-1.5 font-mono text-[9px] font-black text-center flex items-center justify-center gap-1 uppercase tracking-tight"
                  >
                    <span>EDITAR CAPACIDADES ➔</span>
                  </button>
                </div>
              </div>

              {/* O - OUTPUTS */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4.5 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(8,145,178,1)] transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                    <span className="text-2xl font-serif font-black text-teal-600">O</span>
                    <span className="text-[8px] font-mono font-black text-gray-400 uppercase tracking-widest">Outputs</span>
                  </div>
                  <h5 className="font-serif text-[10.5px] uppercase tracking-wide text-gray-950 font-black">Saídas (Entregáveis)</h5>
                  <p className="text-[9.5px] text-gray-500 leading-normal font-sans">Outputs de valor: relatórios consolidados, lotes aprovados ou serviços ativos.</p>
                  
                  <div className="space-y-1.5 pt-1.5 font-sans">
                    {localSipoc.outputs.map((item, index) => {
                      const isEditing = editingSipoc?.column === "O" && editingSipoc?.index === index;
                      return (
                        <div key={index} className="transition-all">
                          {isEditing ? (
                            <div className="flex flex-col gap-1 p-1 bg-white border border-teal-400 rounded-sm">
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  value={editingSipoc.value}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditingSipoc(prev => prev ? { ...prev, value: val } : null);
                                    if (sipocValidationError) setSipocValidationError(null);
                                  }}
                                  autoFocus
                                  className="flex-grow text-[10px] p-1 bg-gray-50 border border-gray-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-teal-500 rounded-xs font-semibold text-gray-950"
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") handleSaveSipocItem();
                                    if (e.key === "Escape") setEditingSipoc(null);
                                  }}
                                />
                                <button 
                                  onClick={handleSaveSipocItem}
                                  className="text-emerald-600 hover:text-emerald-800 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Salvar (Enter)"
                                >
                                  ✓
                                </button>
                                <button 
                                  onClick={() => setEditingSipoc(null)}
                                  className="text-gray-400 hover:text-gray-650 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Cancelar (Esc)"
                                >
                                  ×
                                </button>
                              </div>
                              {sipocValidationError && (
                                <span className="text-[8px] text-red-500 font-mono font-bold leading-none">{sipocValidationError}</span>
                              )}
                            </div>
                          ) : (
                            <div 
                              onClick={() => {
                                setEditingSipoc({ column: "O", index, value: item });
                                setSipocValidationError(null);
                              }}
                              className="flex items-center justify-between text-left text-[10px] p-2 bg-teal-50/40 border border-teal-200/30 hover:border-teal-400 hover:bg-slate-50 text-gray-900 group select-none cursor-pointer rounded-xs transition-colors relative"
                              title="Clique para editar este entregável"
                            >
                              <span className="truncate max-w-[130px] font-semibold" title={item}>{item}</span>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="text-[8.5px] text-teal-700 font-mono">✏️</span>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeSipocItem("O", index);
                                  }} 
                                  className="text-gray-400 hover:text-red-650 font-bold px-1"
                                  title="Excluir"
                                >
                                  ×
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {localSipoc.outputs.length === 0 && (
                      <span className="text-[9px] text-red-400 italic font-mono block">Sem entregas.</span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => { 
                    setActiveSipocColumn("O"); 
                    setBottomFormValidationError(null);
                  }}
                  className="mt-4 text-[9px] font-mono font-black text-teal-700 text-left hover:underline flex items-center justify-between cursor-pointer border-none bg-transparent"
                >
                  <span>+ ADD ENTREGÁVEL</span>
                  <Plus size={10} />
                </button>
              </div>

              {/* C - CUSTOMERS */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4.5 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(8,145,178,1)] transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                    <span className="text-2xl font-serif font-black text-teal-600">C</span>
                    <span className="text-[8px] font-mono font-black text-gray-400 uppercase tracking-widest">Customers</span>
                  </div>
                  <h5 className="font-serif text-[10.5px] uppercase tracking-wide text-gray-950 font-black">Receptores (Clientes)</h5>
                  <p className="text-[9.5px] text-gray-500 leading-normal font-sans">Quem consome a entrega e avalia as diretrizes de nível de serviço SLA da área.</p>
                  
                  <div className="space-y-1.5 pt-1.5 font-sans">
                    {localSipoc.customers.map((item, index) => {
                      const isEditing = editingSipoc?.column === "C" && editingSipoc?.index === index;
                      return (
                        <div key={index} className="transition-all">
                          {isEditing ? (
                            <div className="flex flex-col gap-1 p-1 bg-white border border-teal-400 rounded-sm">
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  value={editingSipoc.value}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditingSipoc(prev => prev ? { ...prev, value: val } : null);
                                    if (sipocValidationError) setSipocValidationError(null);
                                  }}
                                  autoFocus
                                  className="flex-grow text-[10px] p-1 bg-gray-50 border border-gray-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-teal-500 rounded-xs font-semibold text-gray-950"
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") handleSaveSipocItem();
                                    if (e.key === "Escape") setEditingSipoc(null);
                                  }}
                                />
                                <button 
                                  onClick={handleSaveSipocItem}
                                  className="text-emerald-600 hover:text-emerald-800 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Salvar (Enter)"
                                >
                                  ✓
                                </button>
                                <button 
                                  onClick={() => setEditingSipoc(null)}
                                  className="text-gray-400 hover:text-gray-650 font-bold p-0.5 cursor-pointer text-xs"
                                  title="Cancelar (Esc)"
                                >
                                  ×
                                </button>
                              </div>
                              {sipocValidationError && (
                                <span className="text-[8px] text-red-500 font-mono font-bold leading-none">{sipocValidationError}</span>
                              )}
                            </div>
                          ) : (
                            <div 
                              onClick={() => {
                                setEditingSipoc({ column: "C", index, value: item });
                                setSipocValidationError(null);
                              }}
                              className="flex items-center justify-between text-left text-[10px] p-2 bg-teal-50/40 border border-teal-200/30 hover:border-teal-400 hover:bg-slate-50 text-gray-900 group select-none cursor-pointer rounded-xs transition-colors relative"
                              title="Clique para editar este receptor"
                            >
                              <span className="truncate max-w-[130px] font-semibold" title={item}>{item}</span>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="text-[8.5px] text-teal-700 font-mono">✏️</span>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeSipocItem("C", index);
                                  }} 
                                  className="text-gray-400 hover:text-red-00 font-bold px-1"
                                  title="Excluir"
                                >
                                  ×
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {localSipoc.customers.length === 0 && (
                      <span className="text-[9px] text-red-400 italic font-mono block">Sem clientes.</span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => { 
                    setActiveSipocColumn("C"); 
                    setBottomFormValidationError(null);
                  }}
                  className="mt-4 text-[9px] font-mono font-black text-teal-700 text-left hover:underline flex items-center justify-between cursor-pointer border-none bg-transparent"
                >
                  <span>+ ADD RECEPTOR</span>
                  <Plus size={10} />
                </button>
              </div>

            </div>

            {/* Quick Interactive Tool to expand any SIPOC Column inline with Validation Output */}
            <div className="space-y-2">
              <form onSubmit={addSipocItem} className="bg-white border-2 border-[#1A1A1A] p-4 flex flex-col md:flex-row items-center gap-4 shadow-sm animate-fade-in text-left">
                <div className="flex items-center gap-2 text-xs shrink-0">
                  <span className="font-sans font-black text-gray-700 uppercase tracking-tight text-[10px]">✏️ Enriquecer Capa SIPOC:</span>
                  <select 
                    value={activeSipocColumn} 
                    onChange={(e: any) => {
                      setActiveSipocColumn(e.target.value);
                      setBottomFormValidationError(null);
                    }}
                    className="bg-gray-50 border border-[#1A1A1A]/20 font-bold text-[10.5px] p-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded-sm"
                  >
                    <option value="S">S - Fornecedores (Suppliers)</option>
                    <option value="I">I - Ingressos (Inputs)</option>
                    <option value="O">O - Entregas (Outputs)</option>
                    <option value="C">C - Receptores (Customers)</option>
                  </select>
                </div>

                <div className="flex-1 flex gap-2 w-full">
                  <input
                    type="text"
                    value={newSipocItem}
                    onChange={(e) => {
                      setNewSipocItem(e.target.value);
                      if (bottomFormValidationError) setBottomFormValidationError(null);
                    }}
                    placeholder="Ex: Controladoria, Planilhas de Caixa, Balancete Homologado, etc."
                    className={`flex-grow bg-gray-50 focus:bg-white border text-xs p-1.5 px-3 focus:outline-none rounded-sm ${
                      bottomFormValidationError ? "border-red-500 focus:ring-red-600" : "border-gray-300 focus:border-indigo-650"
                    }`}
                  />
                  <button
                    type="submit"
                    className="bg-[#1A1A1A] hover:bg-gray-800 text-white font-mono text-[10px] uppercase font-black p-1.5 px-5 border border-[#1A1A1A] cursor-pointer tracking-wider shrink-0"
                  >
                    Gravar Registro
                  </button>
                </div>
              </form>
              {bottomFormValidationError && (
                <div className="text-[10px] text-red-700 bg-red-50 border border-red-200 px-3 py-1.5 rounded-sm font-mono font-bold text-left animate-fade-in">
                  ⚠️ Erro de Validação: {bottomFormValidationError}
                </div>
              )}
            </div>

            {/* 📋 DRILL-DOWN: OPERATIONAL TASKS AND COMPLIANCE ROLLOUT PANEL */}
            <div className="bg-white border-2 border-[#1A1A1A] p-5 md:p-6 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-3 gap-3">
                <div className="flex items-center gap-2">
                  <ListTodo className="text-[#C49746] shrink-0" size={18} />
                  <div>
                    <h4 className="font-serif font-black text-base text-gray-950">
                      Plano de Rollout &amp; Checklist de Tarefas Operacionais ({activeAreaObj.name.split(",")[0]})
                    </h4>
                    <p className="text-[10.5px] text-gray-500 font-sans mt-0.5">
                      Clique em cada posto abaixo para alternar seu estado de execução e homologação Lean. Os dados persistem dinamicamente.
                    </p>
                  </div>
                </div>
                
                {/* Rollout Progress Meter */}
                {(() => {
                  const total = steps.length;
                  const completed = steps.filter(s => s.completed).length;
                  const percent = total ? Math.round((completed / total) * 100) : 0;
                  return (
                    <div className="flex flex-col items-end shrink-0 gap-1.5">
                      <span className="text-[10px] font-bold font-mono text-gray-850">
                        Rollout SIPOC: <strong className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-sm">{completed} de {total} Concluídas ({percent}%)</strong>
                      </span>
                      {/* Visual bar */}
                      <div className="w-[180px] bg-gray-150 h-2.5 rounded-full overflow-hidden border border-gray-300 relative">
                        <div 
                          className="bg-emerald-600 h-full rounded-full transition-all duration-500 ease-out"
                          style={{ width: `${percent}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Tasks Grid List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {steps.map((st, idx) => {
                  const isDone = !!st.completed;
                  return (
                    <div 
                      key={st.id} 
                      onClick={() => {
                        // Toggle step completion state directly
                        setSteps(prev => prev.map(s => s.id === st.id ? { ...s, completed: !s.completed } : s));
                      }}
                      className={`border p-4 flex items-start gap-3.5 cursor-pointer transition-all duration-150 rounded-sm ${
                        isDone 
                          ? "bg-emerald-50/20 border-emerald-500/40 hover:bg-emerald-50/45 shadow-2xs" 
                          : "bg-white border-gray-200/90 hover:border-gray-400 hover:bg-gray-50/10"
                      }`}
                    >
                      <input 
                        type="checkbox" 
                        checked={isDone}
                        onChange={() => {}} // handled by parent div onClick
                        className="mt-1 h-4.5 w-4.5 text-emerald-800 accent-emerald-600 shrink-0 cursor-pointer" 
                        onClick={(e) => e.stopPropagation()}
                      />
                      
                      <div className="flex-grow min-w-0 font-sans text-left">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className={`text-xs font-black leading-tight truncate ${isDone ? "text-emerald-950 line-through opacity-75" : "text-gray-950"}`}>
                            0{idx + 1}. {st.name}
                          </h4>
                          <span className={`text-[8px] font-mono font-black tracking-wide px-2 py-0.5 rounded-sm ${
                            isDone 
                              ? "bg-emerald-600 text-white" 
                              : "bg-amber-100 text-amber-800 border border-amber-200"
                          }`}>
                            {isDone ? "✓ CONCLUÍDO" : "⚙️ PENDENTE"}
                          </span>
                        </div>
                        
                        <p className="text-[10px] text-gray-500 mt-1 line-clamp-1 italic">
                          {st.description || "Nenhuma instrução cadastrada."}
                        </p>
                        
                        {/* Interactive metadata footer */}
                        <div className="flex flex-wrap items-center justify-between gap-1 mt-3 pt-2 border-t border-dashed border-gray-150 text-[9px] font-mono text-gray-400">
                          <div className="flex items-center gap-2">
                            <span>👤 {st.resource}</span>
                            <span>•</span>
                            <span>Tempo: <strong>{st.processingTime.toFixed(1)}m</strong></span>
                          </div>
                          
                          {/* CTA button to drill down specifically into this step */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedStepId(st.id);
                              setDrillLevel("ACTIVITIES_DETAIL");
                            }}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-mono text-[8px] font-bold p-1 px-2 border border-gray-350 cursor-pointer rounded-xs"
                          >
                            Calibrar Parâmetros ➔
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* General CTA block to help users */}
              <div className="border-t border-dashed border-gray-200 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <span className="text-[10px] text-gray-400 font-mono">
                  💡 Os dados atualizados acima alimentam simultaneamente o sistema estocástico, calibrando a simulação de processos.
                </span>
                <button
                  type="button"
                  onClick={() => setDrillLevel("ACTIVITIES_DETAIL")}
                  className="text-xs font-bold font-mono text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer border-none bg-transparent self-start sm:self-auto"
                >
                  Acessar Editor de Atividades Complexas &sigma; ➔
                </button>
              </div>
            </div>
          </div>
        )}


        {/* ----------------- LEVEL 2: DETAILED SEQUENTIAL ACTIVITIES ----------------- */}
        {drillLevel === "ACTIVITIES_DETAIL" && (
          <div className="space-y-6 animate-fade-in text-left">
            <div className="border-b-2 border-dashed border-gray-200 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest block mb-1">
                  Módulo de Atividades - Sequenciamento Estocástico
                </span>
                <h3 className="font-serif text-2xl font-black text-gray-950">
                  Sequenciamento do Processo: {activeAreaObj.name}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Estude e altere as variáveis de tempo, recursos, e desvios para simular de forma acurada o fluxo corporativo.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setDrillLevel("SIPOC_COVER")}
                className="text-[10px] font-mono font-bold text-gray-500 flex items-center gap-1 hover:text-indigo-600 hover:underline cursor-pointer bg-transparent border-none"
              >
                <ArrowLeft size={11} /> Voltar para a Capa SIPOC
              </button>
            </div>

            {/* List and properties of steps designed in this environment */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Detailed Flowchart Left Column list of steps */}
              <div className="lg:col-span-2 space-y-4">
                <span className="text-[9px] uppercase font-mono font-bold tracking-wider text-gray-400 block pb-1">Fluxograma de Atividades do Processo</span>
                
                <div className="space-y-3">
                  {steps.map((st, idx) => {
                    const isSelected = selectedStepId === st.id;
                    return (
                      <div 
                        key={st.id}
                        onClick={() => setSelectedStepId(st.id)}
                        className={`border-2 p-4 cursor-pointer relative transition-all duration-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 select-none ${
                          isSelected 
                            ? "bg-amber-50/40 border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]" 
                            : "bg-white border-[#1A1A1A]/10 hover:border-gray-500"
                        }`}
                      >
                        {/* Order tag */}
                        <div className="flex items-center gap-3">
                          <span className="text-xs bg-[#1A1A1A] text-white font-mono px-1.5 py-0.5 font-bold">
                            0{idx + 1}
                          </span>
                          <div>
                            <h5 className="font-sans font-extrabold text-sm text-gray-950 flex items-center gap-1.5">
                              {st.name}
                            </h5>
                            <p className="text-[10.5px] text-gray-500 italic font-mono mt-0.5">
                              Responsabilidade: <span className="font-sans font-bold text-gray-700">{st.resource}</span> ({st.resourceCount || 1} {st.resourceCount === 1 ? 'Servidor' : 'Servidores'})
                            </p>
                          </div>
                        </div>

                        {/* Quick stats grid */}
                        <div className="grid grid-cols-3 gap-3 text-center border-l border-gray-100 pl-4 shrink-0">
                          <div>
                            <span className="text-[8px] uppercase text-gray-400 block font-bold">Tempo Ciclo</span>
                            <span className="font-mono text-xs font-bold text-gray-900">{st.processingTime.toFixed(1)}m</span>
                          </div>
                          <div>
                            <span className="text-[8px] uppercase text-gray-400 block font-bold">Desvio &sigma;</span>
                            <span className="font-mono text-xs font-bold text-red-600">± {st.standardDeviation.toFixed(2)}m</span>
                          </div>
                          <div>
                            <span className="text-[8px] uppercase text-gray-400 block font-bold">Taxa Yield</span>
                            <span className="font-mono text-xs font-bold text-emerald-700">{(st.yieldRate * 100).toFixed(0)}%</span>
                          </div>
                        </div>

                        {/* Interactive Drill Down trigger card */}
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedStepId(st.id);
                              setDrillLevel("TASKS_DEEP");
                            }}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white font-mono text-[9px] font-bold p-1 px-2.5 border border-[#1A1A1A] cursor-pointer"
                          >
                            Tarefas &gt;&gt;
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick parameters configuration editor side panel */}
              <div className="bg-[#FAF9F5] border-2 border-[#1A1A1A] p-5 space-y-4">
                <span className="text-[9px] uppercase font-mono font-bold tracking-wider text-gray-400 block pb-1">
                  Calibrador de Atividade
                </span>
                
                {selectedStepId ? (() => {
                  const targetStep = steps.find(s => s.id === selectedStepId);
                  if (!targetStep) return <p className="text-xs italic text-gray-400">Selecione uma atividade para calibrar.</p>;

                  return (
                    <div className="space-y-4 text-left">
                      <div>
                        <span className="text-[10px] bg-[#1A1A1A] text-white px-2 py-0.5 font-mono">EDITANDO</span>
                        <h4 className="font-serif font-black text-sm text-gray-950 mt-1.5">{targetStep.name}</h4>
                        <p className="text-[10px] text-gray-500 font-sans mt-0.5">{targetStep.description || "Sem descrição cadastrada."}</p>
                      </div>

                      <div className="space-y-3 pt-2">
                        {/* Processing Time Slider */}
                        <div>
                          <div className="flex justify-between items-center text-[10.5px]">
                            <label className="font-bold text-gray-700">{terms.cycleTime}</label>
                            <span className="font-mono font-bold text-indigo-700">{targetStep.processingTime.toFixed(1)} minutos</span>
                          </div>
                          <input
                            type="range"
                            min="0.5"
                            max="60"
                            step="0.5"
                            value={targetStep.processingTime}
                            onChange={(e) => {
                              const v = Number(e.target.value);
                              setSteps(prev => prev.map(s => s.id === targetStep.id ? { ...s, processingTime: v } : s));
                            }}
                            className="w-full accent-indigo-600 mt-1"
                          />
                        </div>

                        {/* Standard Deviation Standard */}
                        <div>
                          <div className="flex justify-between items-center text-[10.5px]">
                            <label className="font-bold text-gray-700">Variabilidade (&sigma; Desvio Padrão)</label>
                            <span className="font-mono font-bold text-red-600">{targetStep.standardDeviation.toFixed(2)} minutos</span>
                          </div>
                          <input
                            type="range"
                            min="0.1"
                            max="20"
                            step="0.1"
                            value={targetStep.standardDeviation}
                            onChange={(e) => {
                              const v = Number(e.target.value);
                              setSteps(prev => prev.map(s => s.id === targetStep.id ? { ...s, standardDeviation: v } : s));
                            }}
                            className="w-full accent-red-600 mt-1"
                          />
                          {targetStep.standardDeviation > targetStep.processingTime && (
                            <div className="bg-red-50 border border-red-200 text-[8.5px] p-2 text-red-700 leading-snug mt-1 font-mono">
                              ⚠️ ALERTA DE FLUXO CAÓTICO: Coeficiente de Variação &gt; 1.0! A variabilidade no tempo de atendimento excede o tempo médio. Longas filas estocásticas ocorrerão de acordo com a Teoria de Filas de Kingman.
                            </div>
                          )}
                        </div>

                        {/* Setup Time Tool */}
                        <div>
                          <div className="flex justify-between items-center text-[10.5px]">
                            <label className="font-bold text-gray-700">{terms.setup}</label>
                            <span className="font-mono font-bold text-gray-900">{targetStep.setupTime || 0} minutos</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="120"
                            step="5"
                            value={targetStep.setupTime || 0}
                            onChange={(e) => {
                              const v = parseInt(e.target.value, 10);
                              setSteps(prev => prev.map(s => s.id === targetStep.id ? { ...s, setupTime: v } : s));
                            }}
                            className="w-full accent-gray-600 mt-1"
                          />
                        </div>

                        {/* Yield Rate Slider */}
                        <div>
                          <div className="flex justify-between items-center text-[10.5px]">
                            <label className="font-bold text-gray-700">Taxa de Rendimento Primário (Yield / FPP)</label>
                            <span className="font-mono font-bold text-emerald-700">{(targetStep.yieldRate * 100).toFixed(0)}%</span>
                          </div>
                          <input
                            type="range"
                            min="0.50"
                            max="1.00"
                            step="0.01"
                            value={targetStep.yieldRate}
                            onChange={(e) => {
                              const v = Number(e.target.value);
                              setSteps(prev => prev.map(s => s.id === targetStep.id ? { ...s, yieldRate: v } : s));
                            }}
                            className="w-full accent-emerald-600 mt-1"
                          />
                        </div>

                      </div>

                      <div className="pt-4 border-t border-gray-200 mt-2 flex justify-between items-center">
                        <button
                          type="button"
                          onClick={() => onOpenStepDetail(targetStep.id)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-mono text-[9px] font-bold p-2 px-3 flex items-center gap-1 w-full text-center justify-center border border-[#1A1A1A]"
                        >
                          <span>Ver Dossiê Operacional Completo</span>
                          <ExternalLink size={10} />
                        </button>
                      </div>
                    </div>
                  );
                })() : (
                  <p className="text-xs text-center text-gray-400 italic py-8">
                    Selecione uma atividade à esquerda clicando sobre o card para ajustar seus parâmetros estocásticos e simulação de gargalo.
                  </p>
                )}
              </div>

            </div>
          </div>
        )}


        {/* ----------------- LEVEL 3: OPERATIONAL TASKS AND DRILL DOWN ----------------- */}
        {drillLevel === "TASKS_DEEP" && (
          <div className="space-y-6 animate-fade-in text-left">
            <div className="border-b-2 border-dashed border-gray-200 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold text-[#2563EB] bg-[#2563EB]/5 px-2 py-0.5 uppercase tracking-widest inline-block mb-1">
                  Módulo de Tarefas - Nível Operacional Micro
                </span>
                <h3 className="font-serif text-2xl font-black text-gray-950">
                  Dossiê de Tarefas Detalhadas
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Visualize e edite as tarefas operacionais de checklist, manuais e controles preventivos para blindar a qualidade do posto.
                </p>
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setDrillLevel("ACTIVITIES_DETAIL")}
                  className="text-[10.5px] font-mono font-bold text-gray-500 flex items-center gap-1 hover:text-indigo-600 hover:underline cursor-pointer bg-transparent border-none"
                >
                  <ArrowLeft size={11} /> Voltar para Atividades
                </button>
              </div>
            </div>

            {/* Selector of steps directly inline */}
            <div className="flex border-b border-gray-100 overflow-x-auto gap-2 pb-2">
              {steps.map((st, idx) => {
                const isActive = selectedStepId === st.id;
                return (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStepId(st.id)}
                    className={`py-1.5 px-3 whitespace-nowrap text-[10px] font-mono font-bold border transition-all select-none ${
                      isActive 
                        ? "bg-indigo-600 border-indigo-700 text-white shadow-2xs" 
                        : "bg-white border-gray-300 text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    0{idx + 1}. {st.name.substring(0, 24)}{st.name.length > 24 ? "..." : ""}
                  </button>
                );
              })}
            </div>

            {selectedStepId ? (() => {
              const activeStepObj = steps.find(s => s.id === selectedStepId);
              if (!activeStepObj) return null;

              const instructions = activeStepObj.stepInstructions || [];
              const automations = activeStepObj.automations || [];
              const documents = activeStepObj.supportDocuments || [];

              return (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  
                  {/* Left checklist with interactive operational manual */}
                  <div className="md:col-span-8 space-y-4">
                    <div className="bg-white border-2 border-[#1A1A1A] p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-4">
                      <div className="border-b pb-2 border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <ListTodo className="text-[#C49746]" size={16} />
                          <h4 className="font-serif font-black text-sm text-gray-900">Checklist Operacional &amp; Instruções de Trabalho (POP)</h4>
                        </div>
                        <span className="text-[9px] font-mono font-bold text-gray-400">{instructions.length} etapas cadastradas</span>
                      </div>

                      <div className="space-y-2.5">
                        {instructions.map((ins, i) => (
                          <div key={i} className="flex items-start gap-2.5 bg-gray-50 p-3 border-l-4 border-indigo-500 text-xs">
                            <span className="font-mono font-extrabold text-[#C49746]">{i + 1}.</span>
                            <p className="font-sans text-gray-700 leading-relaxed leading-snug">{ins}</p>
                          </div>
                        ))}
                        {instructions.length === 0 && (
                          <div className="text-center py-6 text-gray-400 italic">
                            Nenhuma instrução operacional cadastrada para essa atividade. Adicione instruções usando o painel lateral de customização.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right support systems, digital integrations etc */}
                  <div className="md:col-span-4 space-y-4 text-left">
                    {/* Automations list */}
                    <div className="border-2 border-[#1A1A1A] bg-[#EEF2FF] p-4 space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-indigo-150 pb-1 w-full">
                        <Cpu className="text-indigo-600" size={14} />
                        <h5 className="font-serif font-bold text-xs text-gray-950 uppercase tracking-tight">Sistemas &amp; Automação Activa</h5>
                      </div>

                      <div className="space-y-2">
                        {automations.map((aut, i) => (
                          <div key={i} className="bg-white p-2.5 border border-indigo-150 relative">
                            <span className={`absolute right-1.5 top-1.5 text-[7px] font-mono font-bold px-1 rounded-sm ${aut.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                              {aut.status === 'active' ? 'ATIVO' : 'PROPOSTO'}
                            </span>
                            <h6 className="font-sans font-bold text-[10.5px] text-gray-900 leading-none">{aut.title}</h6>
                            <p className="text-[8.5px] text-gray-400 font-mono mt-0.5">Tecnologia: {aut.type}</p>
                            <p className="text-[9.5px] text-gray-600 leading-tight mt-1">{aut.description}</p>
                          </div>
                        ))}
                        {automations.length === 0 && (
                          <p className="text-[9px] text-gray-500 italic py-2 text-center">Nenhuma automação vinculada.</p>
                        )}
                      </div>
                    </div>

                    {/* Official SOP compliance documents */}
                    <div className="border-2 border-[#1A1A1A] bg-[#FAFAF9] p-4 space-y-3">
                      <div className="flex items-center gap-1.5 border-b pb-1">
                        <BookOpen className="text-gray-600" size={14} />
                        <h5 className="font-serif font-bold text-xs text-gray-950 uppercase tracking-tight">Procedimentos Documentados</h5>
                      </div>

                      <div className="space-y-2">
                        {documents.map((doc, i) => (
                          <div key={i} className="bg-white p-2 border border-gray-200 flex items-center justify-between text-[10px]">
                            <div>
                              <p className="font-sans font-bold text-gray-800 truncate max-w-[130px]" title={doc.name}>{doc.name}</p>
                              <p className="text-[8px] font-mono text-gray-400">Cod: {doc.code} | Rev {doc.rev}</p>
                            </div>
                            <span className="text-[7.5px] bg-indigo-50 text-indigo-700 font-mono font-bold border border-indigo-100 px-1">{doc.type}</span>
                          </div>
                        ))}
                        {documents.length === 0 && (
                          <p className="text-[9px] text-gray-500 italic py-2 text-center">Nenhum documento anexado.</p>
                        )}
                      </div>
                    </div>
                  </div>

                </div>
              );
            })() : (
              <p className="text-xs text-center text-gray-400 italic py-8">Carregando dados da etapa operacional...</p>
            )}
          </div>
        )}

      </div>

    </div>
  );
}
