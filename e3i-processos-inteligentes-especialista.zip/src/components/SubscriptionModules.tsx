import React, { useState, useMemo } from "react";
import { 
  CreditCard, 
  ShieldCheck, 
  DollarSign, 
  Check, 
  HelpCircle, 
  Zap, 
  RefreshCcw, 
  Layers, 
  Users, 
  Award, 
  AlertCircle 
} from "lucide-react";
import { useToast } from "../shared/ui/Toast";

interface ModuleLicense {
  id: string;
  name: string;
  codename: string;
  description: string;
  priceMonthly: number;
  icon: string;
  activeByDefault: boolean;
  technicalMetric: string;
}

export default function SubscriptionModules() {
  const { warning, success, error } = useToast();
  const currentCargo = localStorage.getItem("lss_current_cargo") || "Analista Júnior";
  const isAdmin = currentCargo === "Admin";

  // We model 6 enterprise modules with rates
  const initialModulesList: ModuleLicense[] = [
    {
      id: "mod-vsm",
      name: "Gestão de Processos & VSM",
      codename: "BPM_CORE",
      description: "Mapeamento completo de fluxo de valor (VSM) com cálculo automático de Touch Time, Lead Time e gargalos em tempo real.",
      priceMonthly: 850,
      icon: "📋",
      activeByDefault: true,
      technicalMetric: "Até 100 fluxos mapeados"
    },
    {
      id: "mod-dmaic",
      name: "Roteiros de Melhoria DMAIC",
      codename: "DMAIC_SUITE",
      description: "Documentos estruturados para as fases Definir, Medir, Analisar, Melhorar e Controlar com monitoramento de metas.",
      priceMonthly: 1150,
      icon: "🚀",
      activeByDefault: true,
      technicalMetric: "Projetos LSS ilimitados"
    },
    {
      id: "mod-stochastic",
      name: "Estúdio de BI & Simulação Estocástica",
      codename: "STOCHASTIC_SIM",
      description: "Simulador estatístico do tempo de fila baseado na teoria de filas G/G/c de Kingman e Monte Carlo para estresse operacional.",
      priceMonthly: 1350,
      icon: "⚙️",
      activeByDefault: true,
      technicalMetric: "Até 50.000 simulações/mês"
    },
    {
      id: "mod-ai",
      name: "Antigravity AI Process Assistant",
      codename: "E3I_COGNITIVE_AI",
      description: "Geração de ideias de melhorias, estruturação de SIPOC por segmentação setorial automática e sugestões automatizadas de automação baseadas em IA.",
      priceMonthly: 1800,
      icon: "💡",
      activeByDefault: true,
      technicalMetric: "Consultas cognitivas ilimitadas"
    },
    {
      id: "mod-spc",
      name: "Controle CEP (Shewhart)",
      codename: "SPC_STATISTICS",
      description: "Gráficos de controle estatístico de processoShewhart com cálculo em tempo real de limites superior e inferior (UCL/LCL).",
      priceMonthly: 950,
      icon: "📊",
      activeByDefault: false,
      technicalMetric: "Monitoramento de até 25 CEPs simultâneos"
    },
    {
      id: "mod-enterprise-roi",
      name: "Arquitetura Corporativa & ROI",
      codename: "ROI_PLANNER",
      description: "Configuração de balanço patrimonial operacional, alocação de mix linear por Simplex de programação linear e rastreador de ROI.",
      priceMonthly: 1450,
      icon: "🏆",
      activeByDefault: false,
      technicalMetric: "Cálculos e relatórios financeiros ilimitados"
    }
  ];

  // Selected state
  const [activeModuleIds, setActiveModuleIds] = useState<string[]>(
    initialModulesList.filter(m => m.activeByDefault).map(m => m.id)
  );

  const [paymentMethod, setPaymentMethod] = useState<"PIX" | "CREDIT_CARD" | "BOLETO">("PIX");
  const [subscriptionTerm, setSubscriptionTerm] = useState<"MONTHLY" | "ANNUAL">("MONTHLY");
  const [licenseKeyInput, setLicenseKeyInput] = useState<string>("");
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [updateSuccess, setUpdateSuccess] = useState<boolean>(false);

  // Toggle selection
  const handleToggleModule = (id: string) => {
    if (activeModuleIds.includes(id)) {
      // Avoid disabling everything - keep at least one
      if (activeModuleIds.length <= 1) return;
      setActiveModuleIds(prev => prev.filter(mid => mid !== id));
    } else {
      setActiveModuleIds(prev => [...prev, id]);
    }
  };

  // Pricing calculations
  const rawSubtotal = useMemo(() => {
    return initialModulesList
      .filter(m => activeModuleIds.includes(m.id))
      .reduce((sum, m) => sum + m.priceMonthly, 0);
  }, [activeModuleIds]);

  // Discounts
  // 1. Multiple modules discount (4+ modules active = 15% discount)
  const quantityDiscountPercent = useMemo(() => {
    return activeModuleIds.length >= 4 ? 15 : 0;
  }, [activeModuleIds]);

  // 2. Annual commitment discount (Annual = 20% discount on total)
  const termDiscountPercent = useMemo(() => {
    return subscriptionTerm === "ANNUAL" ? 20 : 0;
  }, [subscriptionTerm]);

  const finalTotalMonthly = useMemo(() => {
    let total = rawSubtotal;
    // Apply multi-module discount
    if (quantityDiscountPercent > 0) {
      total = total * (1 - quantityDiscountPercent / 100);
    }
    // Apply annual discount if selected
    if (termDiscountPercent > 0) {
      total = total * (1 - termDiscountPercent / 100);
    }
    return total;
  }, [rawSubtotal, quantityDiscountPercent, termDiscountPercent]);

  const finalTotalAnnualized = useMemo(() => {
    return finalTotalMonthly * 12;
  }, [finalTotalMonthly]);

  // Handle contract update process
  const handleUpdateContract = () => {
    setIsUpdating(true);
    setUpdateSuccess(false);
    setTimeout(() => {
      setIsUpdating(false);
      setUpdateSuccess(true);
      setTimeout(() => setUpdateSuccess(false), 3500);
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* Header element */}
      <div className="border-b border-gray-200 pb-5">
        <span className="text-[10px] font-bold text-indigo-700 bg-indigo-75/5 px-2.5 py-0.5 rounded-sm uppercase tracking-widest inline-block mb-1 border border-indigo-200">
          ⚙️ Modulação de Licenciamento SaaS
        </span>
        <h2 className="text-3xl font-serif text-gray-950 uppercase tracking-tight">
          Gestão de Assinatura por Módulos E3I
        </h2>
        <p className="text-xs text-gray-600 max-w-4xl mt-1 leading-relaxed">
          Ative, configure e personalize os módulos contratados no sistema da sua organização. Pague apenas pelo que utilizar, escalando conforme a maturidade de excelência operacional da equipe.
        </p>
      </div>

      {!isAdmin && (
        <div className="bg-amber-50 border-2 border-amber-500/20 p-4 rounded-sm flex items-start gap-3 text-xs text-amber-900 font-sans shadow-3xs">
          <AlertCircle className="text-amber-600 w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <strong className="text-amber-950 font-bold block">🔒 Modo de Consulta de Contrato Ativo (Apenas Leitura)</strong>
            <p className="mt-1 text-amber-900/90 leading-relaxed">
              Como operador sob o cargo de <strong>{currentCargo}</strong>, você possui permissões limitadas. Ajustes de faturamento ou ativação/revogação de licenças adicionais são restritos ao administrador da conta contratante. Contacte sua diretoria de infraestrutura para requisições de expansão.
            </p>
          </div>
        </div>
      )}

      {/* Subscription Active Panel summary */}
      <div className="bg-white border-2 border-slate-950 p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] rounded-sm grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div className="space-y-1">
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wide block">Cliente Licenciado</span>
          <strong className="text-base font-serif text-slate-900 block leading-tight">Marco Antônio Miranda</strong>
          <span className="text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full inline-block mt-1 font-mono font-bold">
            MASTER BLACK BELT LICENSE
          </span>
        </div>

        <div className="space-y-1 md:border-l md:border-gray-200 md:pl-6">
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wide block">Módulos Logicamente Ativos</span>
          <strong className="text-2xl font-serif text-slate-900 block font-black leading-none mt-1">
            0{activeModuleIds.length} <span className="text-xs font-sans text-gray-500 font-normal">de {initialModulesList.length}</span>
          </strong>
          <span className="text-[9.5px] text-emerald-700 font-semibold font-sans block">SLA de 99.98% ativo</span>
        </div>

        <div className="space-y-1 md:border-l md:border-gray-200 md:pl-6 flex flex-col justify-between h-full">
          <div>
            <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wide block">Faturamento Atual</span>
            <strong className="text-xl font-serif text-slate-950 block leading-tight mt-1">
              R$ {Math.round(finalTotalMonthly).toLocaleString("pt-BR")} <span className="text-[10px] font-sans text-slate-500">/mês</span>
            </strong>
          </div>
          {termDiscountPercent > 0 && (
            <span className="text-[9.5px] text-pink-600 font-mono font-bold uppercase tracking-tight block">
              🔥 20% desconto de Fidelidade Anual
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left column: Module selector catalog */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-xs font-mono font-extrabold uppercase text-slate-800 tracking-wider">
            Catálogo de Módulos Operacionais Contratáveis
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {initialModulesList.map((mod) => {
              const isSelected = activeModuleIds.includes(mod.id);
              return (
                <button
                  key={mod.id}
                  onClick={() => {
                    if (isAdmin) {
                      handleToggleModule(mod.id);
                    } else {
                      warning("Como operador (" + currentCargo + "), você não possui autorização para habilitar ou revogar módulos sistêmicos.");
                    }
                  }}
                  type="button"
                  id={`btn-license-mod-${mod.id}`}
                  className={`p-4 border-2 rounded-sm text-left transition-all duration-200 flex flex-col justify-between h-56 ${
                    !isAdmin ? "opacity-85 cursor-not-allowed" : "cursor-pointer"
                  } ${
                    isSelected
                      ? "border-indigo-600 bg-indigo-50/15 shadow-[4px_4px_0px_0px_rgba(79,70,229,1)] scale-[1.01]"
                      : "border-gray-200 bg-white hover:bg-gray-50 text-gray-600"
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-2xl">{mod.icon}</span>
                      <span className={`text-[8.5px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        isSelected 
                          ? "bg-indigo-600 text-white" 
                          : "bg-slate-100 text-slate-500"
                      }`}>
                        {isSelected ? "HABILITADO" : "DESATIVADO"}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-mono font-bold uppercase text-slate-900 tracking-tight">
                        {mod.name}
                      </h4>
                      <span className="text-[9px] text-[#1A1A1A]/40 font-mono font-semibold block uppercase">
                        Codename: {mod.codename}
                      </span>
                    </div>

                    <p className="text-[10px] text-slate-500 leading-normal font-sans line-clamp-3">
                      {mod.description}
                    </p>
                  </div>

                  <div className="border-t border-dashed border-gray-200 pt-3 flex justify-between items-end">
                    <div>
                      <span className="text-[8px] font-mono text-gray-400 uppercase tracking-tight block">Cota Técnica</span>
                      <span className="text-[9.5px] font-mono font-bold text-indigo-950 block">{mod.technicalMetric}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[8px] font-mono text-gray-400 uppercase tracking-tight block">Preço de Tabela</span>
                      <strong className="text-xs font-mono text-slate-900">R$ {mod.priceMonthly} /mês</strong>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right column: Billing Configurator */}
        <div className="bg-[#FAF8F5] border border-gray-300 p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] rounded-sm space-y-6 lg:col-span-1">
          <div>
            <h3 className="text-xs font-mono font-extrabold uppercase text-slate-900 tracking-wider flex items-center gap-1.5 border-b border-gray-250 pb-2">
              <CreditCard size={14} className="text-indigo-600" />
              Configuração de Faturamento
            </h3>
          </div>

          {/* Subscription payment terms */}
          <div className="space-y-2">
            <label className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
              Periodicidade da Cobrança:
            </label>
            <div className="grid grid-cols-2 gap-2 p-0.5 bg-white border border-slate-250 rounded-sm">
              <button
                type="button"
                onClick={() => {
                  if (isAdmin) {
                    setSubscriptionTerm("MONTHLY");
                  } else {
                    warning("Apenas administradores podem ajustar as condições contratuais de faturamento.");
                  }
                }}
                className={`py-1.5 text-[10.5px] font-bold uppercase tracking-tight rounded-xs transition-all ${
                  !isAdmin ? "cursor-not-allowed text-slate-400" : "cursor-pointer"
                } ${
                  subscriptionTerm === "MONTHLY"
                    ? "bg-[#1A1A1A] text-white"
                    : "text-slate-500 hover:text-[#1A1A1A]"
                }`}
              >
                Mensal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (isAdmin) {
                    setSubscriptionTerm("ANNUAL");
                  } else {
                    warning("Apenas administradores podem ajustar as condições contratuais de faturamento.");
                  }
                }}
                className={`py-1.5 text-[10.5px] font-bold uppercase tracking-tight rounded-xs transition-all ${
                  !isAdmin ? "cursor-not-allowed text-slate-400" : "cursor-pointer"
                } ${
                  subscriptionTerm === "ANNUAL"
                    ? "bg-[#1A1A1A] text-white"
                    : "text-slate-500 hover:text-[#1A1A1A]"
                }`}
              >
                Anual (-20%)
              </button>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2">
            <span className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
              Meio de Pagamento Corporativo:
            </span>
            <div className="grid grid-cols-3 gap-1.5 text-[10.5px]">
              {([
                { key: "PIX", label: "PIX" },
                { key: "CREDIT_CARD", label: "Cartão PJ" },
                { key: "BOLETO", label: "Boleto Faturado" }
              ] as const).map((method) => {
                const isActive = paymentMethod === method.key;
                return (
                  <button
                    key={method.key}
                    type="button"
                    onClick={() => {
                      if (isAdmin) {
                        setPaymentMethod(method.key);
                      } else {
                        warning("Não é permitido alterar meios de pagamento corporativos sob o cargo " + currentCargo);
                      }
                    }}
                    className={`py-2 px-1 text-center font-bold font-sans uppercase border transition-all rounded-xs ${
                      !isAdmin ? "cursor-not-allowed opacity-75" : "cursor-pointer"
                    } ${
                      isActive
                        ? "border-indigo-600 bg-indigo-50 text-indigo-750 font-semibold"
                        : "border-gray-200 bg-white text-[#1A1A1A]/60 hover:border-gray-400"
                    }`}
                  >
                    {method.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Proportional pricing summary */}
          <div className="border-t border-dashed border-gray-250 pt-4 space-y-2.5">
            <h4 className="text-[10px] font-mono font-bold uppercase text-slate-400 tracking-widest">
              Fatura Demonstrativa
            </h4>
            <div className="space-y-1.5 text-xs text-sans">
              <div className="flex justify-between text-slate-500">
                <span>Contratação (Subtotal brut):</span>
                <span className="font-mono">R$ {rawSubtotal} /mês</span>
              </div>
              
              {quantityDiscountPercent > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Desconto Volumetria (4+ Módulos):</span>
                  <span className="font-mono">-{quantityDiscountPercent}%</span>
                </div>
              )}

              {termDiscountPercent > 0 && (
                <div className="flex justify-between text-pink-600 font-semibold">
                  <span>Desconto Fidelidade Anual:</span>
                  <span className="font-mono">-{termDiscountPercent}%</span>
                </div>
              )}

              <div className="border-t border-slate-200 pt-2 flex justify-between text-sm text-slate-900 font-bold">
                <span>Total Líquido Estimado:</span>
                <span className="font-mono text-indigo-600">R$ {Math.round(finalTotalMonthly).toLocaleString("pt-BR")} /mês</span>
              </div>

              {subscriptionTerm === "ANNUAL" && (
                <div className="text-[9.5px] italic text-[#1A1A1A]/50 text-right leading-none block">
                  Cobrança anualizada no total de R$ {Math.round(finalTotalAnnualized).toLocaleString("pt-BR")} faturados.
                </div>
              )}
            </div>
          </div>

          {/* Enter license key manually */}
          <div className="border-t border-gray-250 pt-4 space-y-1.5">
            <label htmlFor="custom-license-key" className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
              Inserir Chave de Licenciamento (Voucher):
            </label>
            <div className="flex gap-2">
              <input
                id="custom-license-key"
                type="text"
                disabled={!isAdmin}
                placeholder={isAdmin ? "E3I-XXXXX-XXXXX" : "ATIVADO POR CONTRATO"}
                value={licenseKeyInput}
                onChange={(e) => setLicenseKeyInput(e.target.value.toUpperCase())}
                className="w-full bg-white border border-gray-300 px-2.5 py-1.5 font-mono text-[10.5px] font-extrabold text-[#1A1A1A] placeholder-slate-300 rounded-xs uppercase disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed"
              />
              <button
                type="button"
                disabled={!isAdmin}
                onClick={() => {
                  if (licenseKeyInput === "E3I-FREE-TRIAL") {
                    success("Parabéns! Chave de demonstração vitalícia carregada. Todos os módulos estocásticos foram liberados sem restrição!");
                    setActiveModuleIds(initialModulesList.map(mod => mod.id));
                  } else {
                    error("Chave inválida ou já consumida por outra organização corporativa.");
                  }
                }}
                className="px-2.5 bg-slate-950 hover:bg-slate-850 text-white font-bold text-[10px] uppercase font-mono tracking-tighter transition-all rounded-xs disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                Ativar
              </button>
            </div>
            <span className="text-[8.5px] text-slate-450 block leading-tight">
              Dica: Digite <strong className="font-mono text-slate-700">E3I-FREE-TRIAL</strong> e clique em ativar para simular a validação com sucesso de uma licença corporativa completa.
            </span>
          </div>

          {/* Main Action trigger */}
          <button
            onClick={() => {
              if (isAdmin) {
                handleUpdateContract();
              } else {
                error("Operação bloqueada. Entre em contato com o gestor do contrato para ajustar a modulação.");
              }
            }}
            disabled={isUpdating || !isAdmin}
            type="button"
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:bg-gray-250 disabled:text-gray-450 disabled:cursor-not-allowed text-white font-mono text-xs font-black uppercase tracking-widest cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] hover:translate-x-0.5 hover:translate-y-0.5 transition-all text-center rounded-xs flex items-center justify-center gap-1.5"
          >
            {isUpdating ? (
              <>
                <RefreshCcw size={14} className="animate-spin text-white" />
                Sincronizando...
              </>
            ) : updateSuccess ? (
              "✓ CONTRATO ATUALIZADO!"
            ) : (
              "Sincronizar Assinatura PJ"
            )}
          </button>

          {updateSuccess && (
            <div className="p-2 bg-emerald-50 border border-emerald-300 text-[10.5px] text-emerald-850 font-sans leading-tight">
              🎉 <strong>Sucesso!</strong> Chaves de licenças foram emitidas e espelhadas em sua conta local.
            </div>
          )}

        </div>

      </div>

      <div className="bg-white border border-[#1A1A1A]/10 p-4 rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <ShieldCheck className="text-indigo-600 w-5 h-5 shrink-0" />
          <span>Contrato regido pelas leis de conformidade de processamento de dados e auditorias ISO/IEC 27001.</span>
        </div>
        <div className="text-[10px] text-gray-400 font-mono">
          Licença ID: E3I-MAM-88233372_PROD
        </div>
      </div>

    </div>
  );
}
