import React, { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from "recharts";
import { TrendingUp, Activity, Target } from "lucide-react";
import { ProcessMetrics } from "../types";

interface SigmaTrendDashboardProps {
  stats: ProcessMetrics;
  onNavigateHome: () => void;
}

export default function SigmaTrendDashboard({ stats, onNavigateHome }: SigmaTrendDashboardProps) {
  const [hoveredTrend, setHoveredTrend] = useState<{ value: number; label: string } | null>(null);
  // We'll simulate a 6-month historical trend leading up to the current Sigma Level
  // In a real app, this would be fetched from a backend or calculated from historical snapshots.
  const [data] = useState(() => {
    const history = [];
    const currentSigma = stats.sigmaLevel || 3.0;
    
    // Simulate improvement over the last 6 months
    const baseSigma = Math.max(1.5, currentSigma - 1.2);
    const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"];
    
    for (let i = 0; i < 6; i++) {
      let val = currentSigma;
      if (i < 5) {
        val = baseSigma + ((currentSigma - baseSigma) * (i / 5)) + (Math.random() * 0.4 - 0.2);
      }
      history.push({
        name: months[i],
        "Sigma Level": Math.min(6, Math.max(0, Math.round(val * 100) / 100))
      });
    }
    return history;
  });

  return (
    <div className="space-y-8 animate-fade-in text-left select-none">
      {/* Breadcrumbs UX */}
      <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-4 bg-[#FAF8F5] p-3 -mt-4">
        <div className="flex items-center gap-2 text-[10px] uppercase font-mono tracking-wider text-gray-400">
          <span className="hover:text-indigo-700 cursor-pointer flex items-center gap-1" onClick={onNavigateHome}>
            Página Inicial
          </span>
          <span>/</span>
          <span className="text-gray-900 font-bold flex items-center gap-1">
            <TrendingUp size={10} /> Trend Level (Sigma)
          </span>
        </div>
        <button 
          onClick={onNavigateHome}
          className="bg-white border text-[10px] uppercase font-mono font-bold tracking-tight px-3 py-1 cursor-pointer transition-colors hover:bg-gray-50 flex items-center gap-1.5"
        >
          ← Voltar
        </button>
      </div>

      <div className="bg-white border border-[#1A1A1A] p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 bg-indigo-600 text-white font-mono font-bold text-[8.5px] uppercase tracking-wider rounded-xs flex items-center gap-1">
              <Activity size={10} />
              LIDERANÇA
            </span>
          </div>
          <h2 className="text-2xl font-serif font-black text-gray-950 flex items-center gap-2">
            Evolução do Nível Sigma
          </h2>
          <p className="text-sm font-sans text-gray-500 mt-2 max-w-3xl">
            Acompanhe o nível de maturidade e estabilidade operacional das suas linhas de valor. O objetivo principal do framework DMAIC é evoluir a capabilidade sistêmica, saindo de estágios de alta variabilidade e defeitos para a Excelência Operacional rumo ao Seis Sigma.
          </p>
          {hoveredTrend && (
            <div className="mt-4 inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3 py-1.5 text-xs text-indigo-800 font-mono font-bold animate-fade-in shadow-xs rounded-sm">
              <span className="w-2 h-2 bg-indigo-600 rounded-full animate-ping"></span>
              Amostra Selecionada (Período): <strong className="text-gray-900">{hoveredTrend.label}</strong> ➜ <span className="text-indigo-900 font-black">{hoveredTrend.value.toFixed(2)}σ</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#FAF9F6] border border-gray-200 p-5 rounded-sm">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-widest block">Sigma Atual</span>
              <Target size={14} className="text-indigo-600" />
            </div>
            <strong className="text-3xl font-black text-gray-900 font-mono mt-2 block">{stats.sigmaLevel?.toFixed(2)}σ</strong>
            <span className="text-xs text-emerald-600 block mt-1 font-bold">Liderança do Setor Operacional</span>
          </div>
          
          <div className="bg-[#FAF9F6] border border-gray-200 p-5 rounded-sm">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-widest block">Desvios por Milhão</span>
              <Activity size={14} className="text-rose-600" />
            </div>
            <strong className="text-3xl font-black text-gray-900 font-mono mt-2 block">
              {(stats.dpmo || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
            </strong>
            <span className="text-xs text-rose-600 block mt-1">Defeitos (DPMO) Projetados</span>
          </div>
          
          <div className="bg-[#FAF9F6] border border-gray-200 p-5 rounded-sm">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-widest block">Estágio LSS</span>
              <Activity size={14} className="text-amber-500" />
            </div>
            <strong className="text-xl leading-8 font-black text-gray-900 font-sans mt-2 block">
              {stats.sigmaLevel! >= 6 ? "Classe Mundial" : stats.sigmaLevel! >= 5 ? "Excelência" : stats.sigmaLevel! >= 4 ? "Competitivo" : stats.sigmaLevel! >= 3 ? "Em Controle" : "Sob Risco"}
            </strong>
          </div>
        </div>

        <div className="h-[400px] w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              onMouseMove={(state: any) => {
                if (state && state.activePayload && state.activePayload.length) {
                  const val = state.activePayload[0].value;
                  const label = state.activeLabel || "";
                  setHoveredTrend({ value: typeof val === 'number' ? val : parseFloat(String(val)), label });
                } else {
                  setHoveredTrend(null);
                }
              }}
              onMouseLeave={() => {
                setHoveredTrend(null);
              }}
              data={data}
              margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="name" stroke="#4B5563" fontSize={11} fontStyle="italic" />
              <YAxis stroke="#4B5563" fontSize={11} domain={[0, 6.5]} ticks={[0, 1, 2, 3, 4, 5, 6]} />
              <Tooltip 
                contentStyle={{ fontSize: '11px', fontFamily: 'sans-serif', border: '1px solid #1A1A1A' }}
                formatter={(value: number) => [`${value}σ`, "Nível Sigma"]}
              />
              <Legend wrapperStyle={{ fontSize: '11px', marginTop: '10px' }} />
              <ReferenceLine y={6} label={{ position: 'top', value: 'Alvo: Seis Sigma', fill: '#059669', fontSize: 10, fontWeight: 'bold' }} stroke="#059669" strokeDasharray="3 3" />
              <ReferenceLine y={3} label={{ position: 'bottom', value: 'Baseline', fill: '#C49746', fontSize: 10 }} stroke="#C49746" strokeDasharray="3 3" />
              
              <Line 
                type="monotone" 
                dataKey="Sigma Level" 
                stroke="#4F46E5" 
                strokeWidth={3}
                activeDot={{ r: 6, fill: '#4F46E5', stroke: '#fff', strokeWidth: 2 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
