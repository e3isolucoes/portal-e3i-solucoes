import React, { useState, useEffect } from "react";
import { UsabilityMode, normalizeUsabilityMode } from "../domain/usabilityMode";
import { useToast } from "../shared/ui/Toast";
import StepDetailModal from "./StepDetailModal";
import { 
  Building2, 
  Target, 
  HelpCircle, 
  Bell, 
  User, 
  Settings, 
  ChevronRight, 
  Plus, 
  Download, 
  Upload, 
  BookOpen, 
  TrendingUp, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  History, 
  FileText, 
  Sparkles, 
  X, 
  CornerDownRight, 
  ShieldAlert, 
  Layout, 
  Eye, 
  ArrowRight,
  Info,
  Layers,
  Activity,
  Play,
  Menu,
  LogOut
} from "lucide-react";
import { UserRepository } from "../repositories/UserRepository";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart, 
  Bar, 
  Cell 
} from "recharts";
import { ProcessStep, Company, WorkspaceProject } from "../types";
import { calculateProcessMetrics } from "../utils";
import VisualProcessMapper from "./VisualProcessMapper";
import BpmDocumentSuite from "./BpmDocumentSuite";
import { buildAssistantResult } from "../utils/e3iIntelligence";
import DiagnosticWizard from "./DiagnosticWizard";
import OrQualityHub from "./OrQualityHub";
import ProcessArchitectureExplorer from "../features/process-architecture/ProcessArchitectureExplorer";

interface ProcessesPageProps {
  activeCompanyId: string | null;
  setActiveCompanyId: (id: string | null) => void;
  activeWorkspaceProjectId: string | null;
  setActiveWorkspaceProjectId: (id: string | null) => void;
  globalCompanies: Company[];
  globalProjects: WorkspaceProject[];
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  arrivalRate: number;
  setArrivalRate: (rate: number) => void;
  activeUser: any;
  currentCargo: string;
  setCurrentCargo: (cargo: string) => void;
  onOpenMobileMenu: () => void;
  charter?: any;
  setCharter?: any;
  sipoc?: any;
  setSipoc?: any;
  businessType?: any;
  setBusinessType?: any;
  setCurrentWorkspaceView?: (view: any) => void;
  onOpenAssistente?: () => void;
}

export default function ProcessesPage({
  activeCompanyId,
  setActiveCompanyId,
  activeWorkspaceProjectId,
  setActiveWorkspaceProjectId,
  globalCompanies,
  globalProjects,
  steps,
  setSteps,
  arrivalRate,
  setArrivalRate,
  activeUser,
  currentCargo,
  setCurrentCargo,
  onOpenMobileMenu,
  charter,
  setCharter,
  sipoc,
  setSipoc,
  businessType,
  setBusinessType,
  setCurrentWorkspaceView,
  onOpenAssistente
}: ProcessesPageProps) {
  const { info, success } = useToast();
  const [selectedStepForDetail, setSelectedStepForDetail] = useState<any>(null);
  
  // Tab control
  const [activeTab, setActiveTab] = useState<"overview" | "bpmn" | "kpis" | "improvements" | "documents" | "history" | "diagnostico" | "engenharia" | "arquitetura">("overview");

  // User preference: oriented (simple) vs specialist (expert) mode
  const [usabilityMode, setUsabilityMode] = useState<UsabilityMode>(() => {
    return normalizeUsabilityMode(localStorage.getItem("lss_usability_mode"));
  });

  // User preference: show/hide recommendation guidance card
  const [showGuidance, setShowGuidance] = useState<boolean>(() => {
    return localStorage.getItem("lss_show_guidance") !== "false";
  });

  // AI assistant drawer state
  const [showAiDrawer, setShowAiDrawer] = useState<boolean>(false);
  const [aiPrompt, setAiPrompt] = useState<string>("");
  const [aiConversation, setAiConversation] = useState<Array<{ sender: "user" | "ai"; text: string; timestamp: string }>>([
    {
      sender: "ai",
      text: "Olá! Sou o Assistente E3I. Posso explicar os indicadores do seu processo, destacar gargalos ocultos ou elaborar o seu relatório de melhoras instantaneamente em português. Como posso ajudar?",
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // General loading skeleton simulator
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [lastUpdate, setLastUpdate] = useState<string>(() => new Date().toLocaleTimeString());

  // User Dropdown toggles
  const [showNotifications, setShowNotifications] = useState<boolean>(false);
  const [showUserDropdown, setShowUserDropdown] = useState<boolean>(false);
  const [activeAreaId, setActiveAreaId] = useState<string>("DEFAULT_AREA");

  // Track manual changes/edits & validation
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newStepName, setNewStepName] = useState<string>("");
  const [newStepResource, setNewStepResource] = useState<string>("Analista");
  const [newStepTime, setNewStepTime] = useState<number>(10);
  const [newStepYield, setNewStepYield] = useState<number>(95);

  // Recalculate metrics based on current steps
  const stats = calculateProcessMetrics(steps, arrivalRate);

  // Persistence triggers
  const handleToggleUsabilityMode = (mode: UsabilityMode) => {
    setUsabilityMode(mode);
    localStorage.setItem("lss_usability_mode", mode);
  };

  const handleToggleGuidance = (show: boolean) => {
    setShowGuidance(show);
    localStorage.setItem("lss_show_guidance", show ? "true" : "false");
  };

  // Switch company helper - clears incompatible project
  const handleCompanyChange = (companyId: string | null) => {
    setIsLoading(true);
    setActiveCompanyId(companyId);
    setActiveWorkspaceProjectId(null); // Clean incompatible project
    setTimeout(() => {
      setIsLoading(false);
      setLastUpdate(new Date().toLocaleTimeString());
    }, 455);
  };

  // Switch project helper - reloads data
  const handleProjectChange = (projectId: string | null) => {
    setIsLoading(true);
    setActiveWorkspaceProjectId(projectId);
    setTimeout(() => {
      setIsLoading(false);
      setLastUpdate(new Date().toLocaleTimeString());
    }, 400);
  };

  // Safe permission logic
  const companyObj = globalCompanies.find(c => c.id === activeCompanyId);
  const projectObj = globalProjects.find(p => p.id === activeWorkspaceProjectId && p.companyId === activeCompanyId);

  // Simulation log data
  const [simulationLogs] = useState<Array<{ id: number; action: string; desc: string; user: string; time: string }>>([
    { id: 1, action: "Vínculo de Processo", desc: "Fluxograma estocástico de picking inicializado", user: "Marco Miranda (Black Belt)", time: "15/06/2026 14:22" },
    { id: 2, action: "Modelagem BPM", desc: "Ajuste na etapa de Expedição para aumentar capacidade", user: "E3I Automatizador", time: "15/06/2026 15:45" },
    { id: 3, action: "Simulação Monte Carlo", desc: "10.000 iterações realizadas na fila de triagem", user: "Calculador Estatístico", time: "16/06/2026 09:12" },
  ]);

  // AI Response generator
  const triggerAiAsk = (promptText: string) => {
    if (!promptText.trim()) return;
    setIsAiLoading(true);
    
    // Add user message
    const userMsg = {
      sender: "user" as const,
      text: promptText,
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
    };
    setAiConversation(prev => [...prev, userMsg]);
    setAiPrompt("");

    setTimeout(() => {
      let reply = "";
      const lowerPrompt = promptText.toLowerCase();

      // Smart dynamic replies based on real data
      if (lowerPrompt.includes("resumir") || lowerPrompt.includes("desempenho") || lowerPrompt.includes("indicadores")) {
        const sigmaText = stats.sigmaLevel ? stats.sigmaLevel.toFixed(2) : "6.0";
        const bottleneckText = stats.bottleneckStepName || "Nenhum gargalo identificado";
        reply = `=== RELATÓRIO DO PROCESSADOR E3I ===\n\nIdentifiquei que seu processo "${projectObj?.name || "Otimização"}" está rodando com um Nível Sigma acumulado de **${sigmaText}**. O principal gargalo operacional situa-se na etapa **"${bottleneckText}"**, limitando a capacidade global a **${stats.systemCapacity ? stats.systemCapacity.toFixed(1) : "N/A"} un/hora**. O tempo de ciclo médio estimado é de **${stats.leadTime ? stats.leadTime.toFixed(1) : "N/A"} min**, dos quais **${stats.processingTimeSum ? stats.processingTimeSum : "0"} min** representam tempo líquido de toque (VA) e o restante são tempos de espera e variabilidade (NVA).`;
      } else if (lowerPrompt.includes("gargalo") || lowerPrompt.includes("capacidade")) {
        const bottleneckText = stats.bottleneckStepName || "Nenhum gargalo identificado";
        reply = `O gargalo prioritário atual foi isolado na etapa **"${bottleneckText}"**. Esta barreira causa um represamento de demandas, gerando um WIP acumulado de aproximadamente **${stats.systemWip ? stats.systemWip.toFixed(1) : "0"} unidades**. Minha sugestão de melhoria é aumentar os recursos integrados nesta etapa ou implementar automações para reduzir em pelo menos 15% o tempo de processamento unitário.`;
      } else if (lowerPrompt.includes("melhoria") || lowerPrompt.includes("plano") || lowerPrompt.includes("ação")) {
        reply = `Recomendo as seguintes ações integradas de melhoria contínua:\n1. **Redesenho de Processo (BPMN):** Mapear interrupções na etapa de "${stats.bottleneckStepName || "despacho"}".\n2. **Capacitação:** Treinar operadores para balanceamento de linha e eliminação de desperdício clássico de espera.\n3. **Automação RPA:** Implementar triagem automatizada para reduzir o retrabalho histórico, que atualmente afeta a qualidade.`;
      } else {
        // Fallback robust template using e3i engine
        try {
          const mockInterview = `Nome do Processo: ${projectObj?.name || "Processo Geral"}.\nÁrea: Logística e Operações.\nGargalo: ${stats.bottleneckStepName || "Triagem"}.\nTempo Médio: ${stats.leadTime?.toFixed(1) || "12"} minutos.`;
          const aiRes = buildAssistantResult(mockInterview);
          reply = `Com base nas informações do processo de **${companyObj?.name || "Empresa"}** e suas configurações atuais, analisei a aba e recomendo:\n\n* **Foco Estratégico:** Priorizar a redução de filas no posto de trabalho "${stats.bottleneckStepName || "primário"}".\n* **Mapeamento BPMN:** ${aiRes.process.objective}\n* **Diretriz de Ganhos:** Reduzir desperdícios (${stats.dpmo ? stats.dpmo.toFixed(0) : "0"} DPMO) para elevar o rendimento do primeiro passe (atualmente em ${(stats.rolledFirstPassYield * 100).toFixed(1)}%).`;
        } catch (_) {
          reply = `Entendi sua dúvida sobre o projeto da empresa **${companyObj?.name || "Empresa"}**. Atualmente, a saúde geral do processo está classificada em termos de capabilidade. Recomendo validar o mapa BPMN interativo ou os Indicadores de Capacidade no menu acima para obter as fórmulas detalhadas de controle estatístico.`;
        }
      }

      setAiConversation(prev => [...prev, {
        sender: "ai",
        text: reply,
        timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
      }]);
      setIsAiLoading(false);
    }, 1100);
  };

  // Safe initial workflow trigger
  const handleVincularTemplate = () => {
    setIsLoading(true);
    setTimeout(() => {
      setSteps([
        { id: "step-1", name: "Triagem de Pedidos", resource: "Analista de Triagem", resourceCount: 1, processingTime: 5, standardDeviation: 1, yieldRate: 0.98, setupTime: 0, x: 100, y: 150, shapeType: "START" },
        { id: "step-2", name: "Operação de Picking", resource: "Operador de Picking", resourceCount: 2, processingTime: 12, standardDeviation: 3, yieldRate: 0.97, setupTime: 5, x: 280, y: 150, shapeType: "ACTIVITY" },
        { id: "step-3", name: "Inspeção de Qualidade", resource: "Inspetor de Qualidade", resourceCount: 1, processingTime: 4, standardDeviation: 0.8, yieldRate: 0.99, setupTime: 0, x: 460, y: 150, shapeType: "DECISION" },
        { id: "step-4", name: "Embalagem e Expedição", resource: "Operador Logístico", resourceCount: 1, processingTime: 15, standardDeviation: 4, yieldRate: 0.95, setupTime: 10, x: 640, y: 150, shapeType: "END" }
      ]);
      setArrivalRate(6); // Setup baseline arrival rate
      setIsLoading(false);
      setLastUpdate(new Date().toLocaleTimeString());
    }, 600);
  };

  const handleCreateStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStepName.trim()) return;

    const nextId = `step-${steps.length + 1}`;
    const newStep: ProcessStep = {
      id: nextId,
      name: newStepName,
      resource: newStepResource,
      resourceCount: 1,
      processingTime: Number(newStepTime) || 10,
      standardDeviation: (Number(newStepTime) || 10) * 0.25,
      yieldRate: (Number(newStepYield) || 95) / 100,
      setupTime: 0,
      x: 100 + steps.length * 150,
      y: 150,
      shapeType: "ACTIVITY"
    };

    setSteps(prev => [...prev, newStep]);
    setNewStepName("");
    setShowCreateModal(false);
    setLastUpdate(new Date().toLocaleTimeString());
  };

  // Clean layout context
  return (
    <div className="flex-grow flex flex-col bg-[#F7F8FA] text-[#172033]" id="processes-modular-layout">

      {/* RENDER MASTER STATE VALIDATION (FALTA SELECIONAR CONTEXTOS) */}
      {!activeCompanyId ? (
        <div className="flex-grow flex flex-col items-center justify-center p-12 bg-white text-center">
          <Building2 size={48} className="text-[#D4A547] mb-4 animate-bounce" />
          <h3 className="font-serif text-xl font-bold text-[#0F1728]">Empresa não selecionada</h3>
          <p className="text-sm text-[#667085] mt-2 max-w-sm">
            Selecione uma empresa para visualizar os processos de negócio mapeados.
          </p>
          <div className="mt-5 max-w-xs w-full">
            <select
              aria-label="Escolher empresa para carregar"
              onChange={(e) => handleCompanyChange(e.target.value || null)}
              className="w-full bg-[#F7F8FA] border border-[#E4E7EC] py-2 px-3 text-xs font-bold rounded-lg outline-none cursor-pointer"
            >
              <option value="">Selecione uma Empresa...</option>
              {globalCompanies.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>
      ) : !activeWorkspaceProjectId ? (
        <div className="flex-grow flex flex-col items-center justify-center p-12 bg-white text-center">
          <Target size={48} className="text-[#D4A547] mb-4 animate-pulse" />
          <h3 className="font-serif text-xl font-bold text-[#0F1728]">Projeto não selecionado</h3>
          <p className="text-sm text-[#667085] mt-2 max-w-sm">
            Selecione um projeto para visualizar os processos e indicadores relacionados a esta operação.
          </p>
          <div className="mt-5 max-w-xs w-full">
            <select
              aria-label="Escolher projeto para carregar"
              onChange={(e) => handleProjectChange(e.target.value || null)}
              className="w-full bg-[#F7F8FA] border border-[#E4E7EC] py-2 px-3 text-xs font-bold rounded-lg outline-none cursor-pointer"
            >
              <option value="">Selecione um Projeto...</option>
              {globalProjects
                .filter(p => p.companyId === activeCompanyId)
                .map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
            </select>
          </div>
        </div>
      ) : steps.length === 0 ? (
        <div className="flex-grow flex flex-col items-center justify-center p-12 bg-white text-center">
          <Layers size={48} className="text-rose-500 mb-4 animate-spin" />
          <h3 className="font-serif text-xl font-bold text-[#0F1728]">Nenhum processo vinculado</h3>
          <p className="text-sm text-[#667085] mt-2 max-w-sm">
            Nenhum processo foi vinculado a este projeto. Utilize nosso gerador rápido de fluxogramas.
          </p>
          <button
            onClick={handleVincularTemplate}
            className="mt-6 bg-[#D4A547] hover:bg-[#D4A547]/90 text-white font-semibold text-xs py-2.5 px-6 rounded-lg transition-transform active:scale-95 shadow-md flex items-center gap-2 cursor-pointer"
          >
            <Plus size={14} />
            Vincular processo padrão
          </button>
        </div>
      ) : (
        <div className="flex-grow flex flex-col p-6 space-y-6 max-w-7xl mx-auto w-full">

          {/* 6. CABEÇALHO DA PÁGINA - Compacted */}
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-[#E4E7EC] gap-3">
            <div>
              <h1 className="text-lg font-serif font-black text-[#0F1728] tracking-tight uppercase">Processos de Negócio</h1>
              <div className="flex flex-wrap items-center gap-2 mt-0.5">
                <p className="text-[10px] text-[#667085] leading-none mb-0.5">
                  Acompanhe o desempenho, os gargalos e as oportunidades de melhoria dos fluxos operacionais.
                </p>
                {/* Contextual help popover menu */}
                <div className="relative inline-block text-left select-none z-10">
                  <button
                    type="button"
                    onClick={() => handleToggleGuidance(!showGuidance)}
                    className="text-[#D4A547] hover:text-[#D4A547]/80 text-[9.5px] font-sans font-extrabold flex items-center gap-1 bg-amber-50 hover:bg-amber-100/60 border border-amber-200 px-2 py-0.5 rounded cursor-pointer transition-colors"
                  >
                    <span>💡 Orientação</span>
                    <span className="text-[8px] bg-[#D4A547] text-white px-1.5 rounded-full">1</span>
                  </button>
                  {showGuidance && (
                    <div className="absolute left-0 mt-1.5 w-72 bg-white border border-slate-200 shadow-xl rounded-lg p-3 z-40 text-xs text-slate-700 font-sans leading-relaxed">
                      <p className="font-bold text-[#D4A547] uppercase text-[9px] tracking-wide mb-1">Recomendação de Processo E3I</p>
                      <p className="text-gray-700">
                        Revise o gargalo atual (<strong className="text-red-700">{stats.bottleneckStepName || "Aguardando"}</strong>) e verifique se há capacidade suficiente na etapa de picking.
                      </p>
                      <div className="mt-3 pt-2 border-t flex justify-end gap-2 text-[10px] font-bold">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveTab("bpmn");
                          }}
                          className="text-[#D4A547] hover:underline cursor-pointer"
                        >
                          Ir para Gargalo ›
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleGuidance(false)}
                          className="text-slate-500 hover:text-slate-800 cursor-pointer"
                        >
                          Fechar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Ações únicas e prioritárias */}
            <div className="flex flex-wrap items-center gap-2">
              {onOpenAssistente && (
                <button
                  type="button"
                  onClick={onOpenAssistente}
                  className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-left cursor-pointer"
                  title="Abrir o Assistente Inteligente E3I"
                >
                  <Sparkles size={14} className="text-indigo-600 animate-pulse" />
                  <span>Assistente E3I</span>
                </button>
              )}

              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-[#D4A547] hover:bg-[#D4A547]/90 text-white font-bold text-xs py-2 px-4 shadow-sm rounded-lg flex items-center gap-1.5 transition-all cursor-pointer active:scale-98"
                title="Cadastrar nova etapa no fluxo operacional"
              >
                <Plus size={14} />
                Novo processo
              </button>
              
              <button
                onClick={() => info("Modelos prontos Lean recolhidos sob permissão profissional")}
                className="bg-[#F7F8FA] hover:bg-slate-100 text-[#172033] border border-[#E4E7EC] font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-left cursor-pointer"
              >
                Modelos
              </button>

              <button
                onClick={() => info("Importando logs do ServiceNow / Excel...")}
                className="bg-[#F7F8FA] hover:bg-slate-100 text-[#172033] border border-[#E4E7EC] font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-left cursor-pointer"
              >
                Importar dados
              </button>

              <button
                onClick={() => success("Exportação do mapa e KPIs concluída para Planilha")}
                className="bg-[#F7F8FA] hover:bg-slate-100 text-[#172033] border border-[#E4E7EC] font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-left cursor-pointer"
              >
                Exportar
              </button>
            </div>
          </div>

          {/* 7. NAVEGAÇÃO INTERNA DA PÁGINA (ABAS) */}
          <div 
            id="processes-page-tablist"
            role="tablist"
            aria-label="Abas de Navegação de Processo"
            className="flex border-b border-[#E4E7EC] overflow-x-auto gap-1 bg-white p-1 rounded-lg shadow-2xs select-none scroll-mt-4"
          >
            {[
              { id: "overview", label: "Visão Geral", icon: <Layout size={14} /> },
              { id: "arquitetura", label: "🏢 Arquitetura", icon: <Layers size={14} /> },
              { id: "diagnostico", label: "📋 Diagnóstico", icon: <FileText size={14} /> },
              { id: "bpmn", label: "🗺️ Modelagem BPM", icon: <Layers size={14} /> },
              { id: "engenharia", label: "🔬 Engenharia LSS", icon: <Activity size={14} /> },
              { id: "kpis", label: "Indicadores", icon: <TrendingUp size={14} /> },
              { id: "improvements", label: "Melhorias", icon: <CheckCircle2 size={14} /> },
              { id: "documents", label: "Documentos", icon: <FileText size={14} /> },
              { id: "history", label: "Histórico", icon: <History size={14} /> },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab-${tab.id}`}
                  role="tab"
                  aria-selected={isActive}
                  aria-controls={`panel-${tab.id}`}
                  tabIndex={isActive ? 0 : -1}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setTimeout(() => {
                      const element = document.getElementById("processes-page-tablist");
                      if (element) {
                        element.scrollIntoView({ behavior: "smooth", block: "start" });
                      }
                    }, 50);
                  }}
                  className={`py-2 px-4 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-[#D4A547] focus:ring-offset-1 ${
                    isActive
                      ? "bg-[#D4A547] text-white shadow-3xs"
                      : "text-[#667085] hover:text-[#0F1728] hover:bg-[#F7F8FA]"
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* SKELETON LOADER DURING VIEW SWAP OR DATABASE LOAD */}
          {isLoading ? (
            <div className="space-y-4" aria-busy="true">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="h-20 bg-slate-200 animate-pulse rounded-md"></div>
                ))}
              </div>
              <div className="h-64 bg-slate-150 animate-pulse rounded-lg"></div>
            </div>
          ) : (
            <>
              {/* === TAB 1: VISÃO GERAL === */}
              {activeTab === "overview" && (
                <div 
                  role="tabpanel" 
                  id="panel-overview" 
                  aria-labelledby="tab-overview" 
                  className="space-y-6"
                >
                  
                  {/* 11. INDICADORES PRINCIPAIS (KPI GRID) */}
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                    
                    {/* KPI 1: PERFORMANCE DO PROCESSO */}
                    <div className="bg-white border border-[#E4E7EC] p-4 rounded-xl shadow-3xs hover:border-[#D4A547]/50 transition-all text-left">
                      <p className="text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider mb-1">Performance</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-serif font-black text-[#0F1728]">
                          {stats.sigmaLevel > 4 ? "Excelente" : "Atenção"}
                        </span>
                      </div>
                      <p className="text-[10px] text-[#D4A547] font-bold mt-1 inline-flex items-center gap-1">
                        Nível Sigma: {stats.sigmaLevel ? stats.sigmaLevel.toFixed(2) : "6.0"}
                      </p>
                      {usabilityMode === "EXPERT" && (
                        <div className="mt-2 pt-2 border-t border-slate-100 text-[9.5px] font-mono text-[#667085] space-y-0.5">
                          <div>FPP Yield: {(stats.rolledFirstPassYield * 100).toFixed(1)}%</div>
                          <div>DPMO: {stats.dpmo ? stats.dpmo.toFixed(0) : "0"}</div>
                        </div>
                      )}
                    </div>

                    {/* KPI 2: GARGALO ATUAL */}
                    <div className="bg-white border border-[#E4E7EC] p-4 rounded-xl shadow-3xs hover:border-[#D4A547]/50 transition-all text-left">
                      <p className="text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider mb-1">Gargalo Crítico</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-base font-serif font-black text-[#B42318] truncate max-w-full">
                          {stats.bottleneckStepName || "Nenhum"}
                        </span>
                      </div>
                      <p className="text-[10px] text-[#B54708] font-bold mt-1 flex items-center gap-0.5">
                        <AlertTriangle size={10} />
                        Foco de Otimização
                      </p>
                    </div>

                    {/* KPI 3: QUALIDADE GLOBAL */}
                    <div className="bg-white border border-[#E4E7EC] p-4 rounded-xl shadow-3xs hover:border-[#D4A547]/50 transition-all text-left">
                      <p className="text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider mb-1">Qualidade (Yield)</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-serif font-black text-[#067647]">
                          {(stats.rolledFirstPassYield * 100).toFixed(1)}%
                        </span>
                      </div>
                      <p className="text-[10px] text-[#067647] font-semibold mt-1">
                        ↑ 0.8% em relação anterior
                      </p>
                    </div>

                    {/* KPI 4: TEMPO DE CICLO */}
                    <div className="bg-white border border-[#E4E7EC] p-4 rounded-xl shadow-3xs hover:border-[#D4A547]/50 transition-all text-left">
                      <p className="text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider mb-1">Tempo de Ciclo (Média)</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-serif font-black text-[#0F1728]">
                          {stats.leadTime ? stats.leadTime.toFixed(1) : "18.4"} min
                        </span>
                      </div>
                      <p className="text-[10px] text-[#667085] mt-1">
                        Meta esperada: 15.0 min
                      </p>
                    </div>

                    {/* KPI 5: PEDIDOS ACUMULADOS / WIP */}
                    <div className="bg-white border border-[#E4E7EC] p-4 rounded-xl shadow-3xs hover:border-[#D4A547]/50 transition-all text-left">
                      <p className="text-[10px] uppercase font-mono font-bold text-[#667085] tracking-wider mb-1">Pedidos em Espera (WIP)</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-serif font-black text-[#175CD3]">
                          {stats.systemWip ? stats.systemWip.toFixed(1) : "2"} un
                        </span>
                      </div>
                      <p className="text-[10px] text-[#175CD3] font-semibold mt-1">
                        Taxa de chegada: {arrivalRate} un/hora
                      </p>
                    </div>
                  </div>

                  {/* 12. CONTEÚDO ANALÍTICO (TWO COLUMNS ON DESKTOP) */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* COLUNA PRINCIPAL (Evolução, Volume, Qualidade) - ColSpan 7 */}
                    <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                      <h3 className="font-serif text-[#0F1728] font-bold text-base flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <span>📊 Performance e Tempo de Ciclo Unitário</span>
                          {/* Rich contextual help tooltip next to title to save valuable viewport space */}
                          <span className="group relative inline-block cursor-help text-[#667085] hover:text-[#0F1728]">
                            <Info size={14} className="text-[#D4A547] shrink-0" />
                            <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-slate-900 text-white text-[10px] font-sans font-normal p-2.5 rounded shadow-xl opacity-0 group-hover:opacity-100 transition-opacity z-50 leading-relaxed">
                              <strong>Ajuda Visual:</strong> A curva amarela representa o tempo necessário total para completar cada etapa do processo. A meta recomendada é de 15 minutos (linha pontilhada limite).
                            </span>
                          </span>
                        </span>
                        <span className="text-[9px] font-mono text-[#667085]">Escala Real (Minutos)</span>
                      </h3>

                      {/* Recharts area graph with steps processing times */}
                      <div className="h-56">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart 
                            data={steps.map((s, index) => ({
                              name: `Ep. ${index + 1}: ${s.name.split(" ")[0]}`,
                              Tempo: s.processingTime,
                              Capacidade: s.capacityPerHour ? parseFloat(s.capacityPerHour.toFixed(1)) : 10
                            }))}
                            margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
                          >
                            <defs>
                              <linearGradient id="colorTempo" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#D4A547" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#D4A547" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F2F4F7" />
                            <XAxis dataKey="name" stroke="#667085" fontSize={9.5} tickLine={false} />
                            <YAxis stroke="#667085" fontSize={9.5} tickLine={false} />
                            <Tooltip />
                            <Area type="monotone" dataKey="Tempo" stroke="#D4A547" fillOpacity={1} fill="url(#colorTempo)" strokeWidth={2} />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Detailed inspection grid */}
                      <div className="pt-2">
                        <h4 className="text-[11px] uppercase tracking-wider font-mono font-bold text-[#667085] mb-2">Visão Rápida dos Postos de Trabalho</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {steps.map(s => (
                            <div key={s.id} className="bg-[#F7F8FA] p-2.5 rounded text-[11px] border border-[#E4E7EC]">
                              <p className="font-bold text-[#0F1728] truncate">{s.name}</p>
                              <p className="text-[10px] text-[#667085] mt-0.5">{s.resource}</p>
                              <div className="flex justify-between items-center mt-2 pt-1 border-t border-slate-200 text-[10px]">
                                <span className="font-mono text-[#D4A547]">{s.processingTime} min</span>
                                <span className={`font-bold ${s.yieldRate < 0.96 ? "text-[#B42318]" : "text-[#067647]"}`}>
                                  {(s.yieldRate * 100).toFixed(0)}% Ql.
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* COLUNA SECUNDÁRIA (Gargalo Atual e Diagnóstico) - ColSpan 5 */}
                    <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                      <div className="border-b border-[#E4E7EC] pb-3">
                        <span className="text-[9px] bg-rose-50 text-[#B42318] border border-[#B42318]/20 font-bold px-2 py-0.5 rounded-full inline-block uppercase">Análise de Gargalo</span>
                        <h3 className="font-serif text-lg font-black text-[#0F1728] mt-1.5">Gargalo Isolado</h3>
                      </div>

                      <div className="space-y-3 text-xs">
                        <div className="flex justify-between pb-1 border-b border-[#F2F4F7]">
                          <span className="text-[#667085]">Etapa Gargalo:</span>
                          <span className="font-bold text-[#B42318]">{stats.bottleneckStepName || "Nenhum crítico"}</span>
                        </div>
                        <div className="flex justify-between pb-1 border-b border-[#F2F4F7]">
                          <span className="text-[#667085]">Causa Provável:</span>
                          <span className="font-semibold text-[#172033]">Capacidade unitária sobrecarregada / setups longos</span>
                        </div>
                        <div className="flex justify-between pb-1 border-b border-[#F2F4F7]">
                          <span className="text-[#667085]">Impacto em Fila:</span>
                          <span className="font-bold text-[#B54708]">+{stats.systemWip ? (stats.systemWip * 4.3).toFixed(1) : "12"} min de atraso</span>
                        </div>
                        <div className="flex justify-between pb-1 border-b border-[#F2F4F7]">
                          <span className="text-[#667085]">Responsável:</span>
                          <span className="font-semibold text-[#172033]">{steps.find(s => s.name === stats.bottleneckStepName)?.resource || "Coordenador Logístico"}</span>
                        </div>
                        <div className="flex justify-between pb-1 border-b border-[#F2F4F7]">
                          <span className="text-[#667085]">Prazo de Resolução:</span>
                          <span className="font-semibold text-indigo-700">Imediato (Dentro 48h)</span>
                        </div>
                        <div className="flex justify-between pb-1">
                          <span className="text-[#667085]">Status de Monitoramento:</span>
                          <span className="text-[#B54750] bg-[#B54708]/10 px-1.5 py-0.2 rounded font-bold text-[10px]">Atenção Crítica</span>
                        </div>
                      </div>

                      <div className="bg-red-50/50 p-3 rounded-lg border border-red-100 space-y-1.5 text-xs text-[#B42318] leading-normal">
                        <p className="font-bold">Recomendação Especialista:</p>
                        <p className="text-[11px] text-gray-700">
                          Reduza o tempo de setup utilizando técnicas Lean SMED ou adicione 1 recurso paralelo na etapa de **{stats.bottleneckStepName || "Expedição"}** para balancear a linha produtiva contra gargalos sazonais.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* SEGUNDA SEÇÃO (PLANO DE AÇÕES & EXCEÇÕES) */}
                  <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                    <div className="border-b border-[#E4E7EC] pb-3">
                      <h4 className="font-serif text-[#0F1728] font-bold text-base">📋 Plano de Ação de Melhorias em Andamento (Lean Kaizen)</h4>
                      <p className="text-xs text-[#667085] mt-1">Acompanhe as ações ativas de transformação, mitigação de riscos e comprovação de evidências auditadas.</p>
                    </div>

                    <div className="overflow-x-auto select-none">
                      <table className="w-full text-xs text-left border-collapse" role="table">
                        <thead>
                          <tr className="border-b border-[#E4E7EC] text-[#667085] font-mono uppercase text-[9.5px]">
                            <th className="py-2.5 font-bold">Iniciativa / Ação</th>
                            <th className="py-2.5 font-bold">Tipo</th>
                            <th className="py-2.5 font-bold">Risco Mitigado</th>
                            <th className="py-2.5 font-bold">Etapa Destino</th>
                            <th className="py-2.5 font-bold">Responsável</th>
                            <th className="py-2.5 font-bold text-right">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#F2F4F7]">
                          <tr>
                            <td className="py-3 font-semibold text-[#172033]">SMED na troca de lotes</td>
                            <td className="py-3 text-indigo-700 bg-indigo-50/45 px-1.5 rounded text-[10px] inline-block font-mono mt-1">Lean Six Sigma</td>
                            <td className="py-3 text-[#667085]">Atraso por desbalanceamento</td>
                            <td className="py-3 font-semibold text-[#D4A547]">{stats.bottleneckStepName || "Picking"}</td>
                            <td className="py-3 text-[#172033]">M. Miranda</td>
                            <td className="py-3 text-right">
                              <span className="bg-[#B54708]/10 text-[#B54708] font-bold text-[9.5px] px-2 py-0.5 rounded-full">Aguardando</span>
                            </td>
                          </tr>
                          <tr>
                            <td className="py-3 font-semibold text-[#172033]">Automação Kanban de Fila</td>
                            <td className="py-3 text-[#067647] bg-emerald-50 px-1.5 rounded text-[10px] inline-block font-mono mt-1">RPA / IA</td>
                            <td className="py-3 text-[#667085]">Perda de rastreabilidade</td>
                            <td className="py-3 font-semibold text-[#D4A547]">Triagem de Pedidos</td>
                            <td className="py-3 text-[#172033]">Sofia G.</td>
                            <td className="py-3 text-right">
                              <span className="bg-emerald-50 text-[#067647] font-bold text-[9.5px] px-2 py-0.5 rounded-full">Em Execução</span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* === TAB 1.25: ARQUITETURA === */}
              {activeTab === "arquitetura" && (
                <ProcessArchitectureExplorer
                  steps={steps}
                  setSteps={setSteps}
                  arrivalRate={arrivalRate}
                  setArrivalRate={setArrivalRate}
                  mode={usabilityMode}
                />
              )}

              {/* === TAB 1.5: DIAGNÓSTICO === */}
              {activeTab === "diagnostico" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left">
                  <DiagnosticWizard
                    steps={steps}
                    setSteps={setSteps}
                    charter={charter}
                    setCharter={setCharter}
                    sipoc={sipoc}
                    setSipoc={setSipoc}
                    setView={setCurrentWorkspaceView || (() => {})}
                    businessType={businessType || "SERVICES"}
                    setBusinessType={setBusinessType}
                  />
                </div>
              )}

              {/* === TAB 2: MAPEAMENTO BPMN === */}
              {activeTab === "bpmn" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                  <div className="border-b border-[#E4E7EC] pb-3 flex justify-between items-center flex-wrap gap-2">
                    <div>
                      <h3 className="font-serif text-[#0F1728] font-bold text-base">🗺️ Modelador de Fluxograma BPMN Operacional</h3>
                      <p className="text-xs text-[#667085] mt-1">Adicione decisões, rearranje postos, altere tempos de processamento e veja a simulação estocástica se atualizar em tempo de execução.</p>
                    </div>
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="bg-[#D4A547] hover:bg-[#D4A547]/95 text-white font-bold text-xs py-1.5 px-3 rounded shadow-3xs flex items-center gap-1 cursor-pointer"
                    >
                      <Plus size={12} />
                      Nova Etapa
                    </button>
                  </div>

                  <div className="border border-[#E4E7EC] rounded-xl overflow-hidden bg-slate-50 relative min-h-[360px]">
                    <VisualProcessMapper
                      steps={steps}
                      setSteps={setSteps}
                      bottleneckStepName={stats.bottleneckStepName}
                      onOpenDetails={(stepId) => {
                        const targetStep = steps.find(s => s.id === stepId);
                        if (targetStep) {
                          setSelectedStepForDetail(targetStep);
                        } else {
                          info(`Detalhes da etapa ${stepId} indisponíveis.`);
                        }
                      }}
                      activeAreaId={activeAreaId}
                      onSwitchArea={(areaId) => setActiveAreaId(areaId)}
                      usabilityMode={usabilityMode}
                      businessType="Logistics"
                    />
                  </div>
                </div>
              )}

              {/* === TAB 2.5: ENGENHARIA LSS === */}
              {activeTab === "engenharia" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left">
                  <OrQualityHub
                    steps={steps}
                    setSteps={setSteps}
                    stats={stats}
                    arrivalRate={arrivalRate}
                  />
                </div>
              )}

              {/* === TAB 3: INDICADORES === */}
              {activeTab === "kpis" && (
                <div className="space-y-6">
                  <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                    <h3 className="font-serif text-[#0F1728] font-bold text-base">📈 Detalhamento Técnico de Capabilidade de Linha</h3>
                    <p className="text-xs text-[#667085]">Visualize as fórmulas constitutivas baseadas no CBOK e monitoramento estatístico de Shewhart.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-[#F7F8FA] p-4 rounded-lg border border-[#E4E7EC]">
                        <h4 className="text-xs font-mono uppercase font-bold text-[#667085]">Nível Sigma de Processo</h4>
                        <p className="text-2xl font-serif font-black text-[#0F1728] mt-2">{stats.sigmaLevel?.toFixed(2) || "4.50"} σ</p>
                        <p className="text-[10.5px] text-[#667085] mt-1">Nível de dispersão contra os limites de especificação especificados.</p>
                      </div>

                      <div className="bg-[#F7F8FA] p-4 rounded-lg border border-[#E4E7EC]">
                        <h4 className="text-xs font-mono uppercase font-bold text-[#667085]">Defeitos (DPMO)</h4>
                        <p className="text-2xl font-serif font-black text-[#B42318] mt-2">{stats.dpmo ? stats.dpmo.toFixed(0) : "0"}</p>
                        <p className="text-[10.5px] text-[#667085] mt-1">O número estimado de falhas ocorrendo por um milhão de oportunidades.</p>
                      </div>

                      <div className="bg-[#F7F8FA] p-4 rounded-lg border border-[#E4E7EC]">
                        <h4 className="text-xs font-mono uppercase font-bold text-[#667085]">Eficiência de Ciclo (PCE)</h4>
                        <p className="text-2xl font-serif font-black text-emerald-800 mt-2">
                          {stats.leadTime ? ((stats.processingTimeSum / stats.leadTime) * 100).toFixed(1) : "80"}%
                        </p>
                        <p className="text-[10.5px] text-[#667085] mt-1">Percentual correspondente a Tempo Líquido (VA) / Lead Time Total.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* === TAB 4: MELHORIAS === */}
              {activeTab === "improvements" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                  <h3 className="font-serif text-[#0F1728] font-bold text-base">🚀 Kaizen &amp; Matriz de Otimizações Recomendadas</h3>
                  <p className="text-xs text-[#667085]">Iniciativas para eliminação do desperdício de estocagem, processamento extra ou retrabalhos.</p>
                  
                  <div className="space-y-3">
                    <div className="p-3.5 bg-[#FAF9F5] border border-amber-200 rounded-lg flex items-start gap-3">
                      <span className="text-sm">⚡</span>
                      <div>
                        <p className="font-bold text-[#0F1728] text-xs">Eliminar setup ocioso na Expedição</p>
                        <p className="text-[11px] text-[#667085] mt-1">Impacto esperado: Redução de 10 minutos no Lead Time total do primeiro passe.</p>
                      </div>
                    </div>
                    <div className="p-3.5 bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg flex items-start gap-3">
                      <span className="text-sm">🌐</span>
                      <div>
                        <p className="font-bold text-[#0F1728] text-xs">Acelerar Triagem Automatizada</p>
                        <p className="text-[11px] text-[#667085] mt-1">Impacto esperado: Redução em 2% na taxa de falha (DPMO) por verificação robusta de dados de entrada.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* === TAB 5: DOCUMENTOS === */}
              {activeTab === "documents" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                  <h3 className="font-serif text-[#0F1728] font-bold text-base">📘 Manuais Operacionais e Biblioteca de SOPs</h3>
                  <p className="text-xs text-[#667085]">Governança documental de apoio e instruções detalhadas de passo a passo de fabricação.</p>
                  
                  <BpmDocumentSuite
                    steps={steps}
                    stats={stats}
                    activeAreaId={activeAreaId}
                    onNavigateToMap={() => setActiveTab("bpmn")}
                  />
                </div>
              )}

              {/* === TAB 6: HISTÓRICO === */}
              {activeTab === "history" && (
                <div className="bg-white p-5 rounded-xl border border-[#E4E7EC] shadow-3xs text-left space-y-4">
                  <h3 className="font-serif text-[#0F1728] font-bold text-base">🕒 Histórico de Atualizações do Processo (Audit Trail)</h3>
                  <p className="text-xs text-[#667085]">Todas as simulações, alterações e aprovações eletrônicas homologadas na trilha de auditoria.</p>
                  
                  <div className="space-y-3 pt-2">
                    {simulationLogs.map(log => (
                      <div key={log.id} className="p-3 bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg text-xs leading-none flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <span className="bg-[#D4A547]/10 text-[#D4A547] font-bold py-1 px-2.5 rounded font-mono text-[9.5px]">
                            {log.action}
                          </span>
                          <span className="text-[#172033] font-semibold">{log.desc}</span>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-[10.5px] text-[#667085]">{log.user}</p>
                          <p className="text-[9.5px] text-gray-400 mt-0.5">{log.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </>
          )}

          {/* MODAL PARA ADICIONAR ETAPA */}
          {showCreateModal && (
            <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl border border-[#E4E7EC] w-full max-w-md p-6 relative">
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="absolute top-4 right-4 text-gray-400 hover:text-gray-950 p-1"
                >
                  <X size={16} />
                </button>
                
                <h3 className="font-serif text-lg font-bold text-[#0F1728] mb-4">Cadastrar Nova Etapa Operacional</h3>
                
                <form onSubmit={handleCreateStep} className="space-y-4 text-left text-xs">
                  <div>
                    <label className="block font-bold text-gray-700 mb-1">Nome da Etapa:</label>
                    <input
                      required
                      type="text"
                      placeholder="Ex: Armazenamento e Conferência"
                      value={newStepName}
                      onChange={(e) => setNewStepName(e.target.value)}
                      className="w-full bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg p-2.5 outline-none focus:ring-1 focus:ring-[#D4A547]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-gray-700 mb-1">Tempo de Toque (VA min):</label>
                      <input
                        type="number"
                        min={1}
                        value={newStepTime}
                        onChange={(e) => setNewStepTime(Number(e.target.value))}
                        className="w-full bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg p-2.5 outline-none focus:ring-1 focus:ring-[#D4A547]"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-gray-700 mb-1">Taxa de Qualidade (%):</label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={newStepYield}
                        onChange={(e) => setNewStepYield(Number(e.target.value))}
                        className="w-full bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg p-2.5 outline-none focus:ring-1 focus:ring-[#D4A547]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-gray-700 mb-1">Responsável / Posto:</label>
                    <input
                      type="text"
                      placeholder="Ex: Conferente Logístico N2"
                      value={newStepResource}
                      onChange={(e) => setNewStepResource(e.target.value)}
                      className="w-full bg-[#F7F8FA] border border-[#E4E7EC] rounded-lg p-2.5 outline-none focus:ring-1 focus:ring-[#D4A547]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#D4A547] hover:bg-[#D4A547]/95 text-white font-bold py-2 px-4 shadow rounded-lg pointer cursor-pointer"
                  >
                    Confirmar Cadastro
                  </button>
                </form>
              </div>
            </div>
          )}

        </div>
      )}

      {selectedStepForDetail && (
        <StepDetailModal
          step={selectedStepForDetail}
          onClose={() => setSelectedStepForDetail(null)}
          onUpdateStep={(updatedStep) => {
            setSteps((prev) => prev.map((s) => (s.id === updatedStep.id ? updatedStep : s)));
            setSelectedStepForDetail(updatedStep);
            success("Etapa operacional atualizada com sucesso!");
          }}
        />
      )}

    </div>
  );
}
