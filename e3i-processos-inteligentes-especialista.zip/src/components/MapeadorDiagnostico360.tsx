import React, { useState, useEffect } from "react";
import { useBusinessContext } from "../contexts/BusinessContext";
import { useDiagnosticSync, DiagnosticAnswersSchema } from "../hooks/useDiagnosticSync";
import { ProjectCharter } from "../types";
import { z } from "zod";
import { 
  ClipboardCheck, 
  HelpCircle, 
  Zap, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  ArrowRight, 
  RotateCcw, 
  FileText, 
  Sliders, 
  X, 
  Save, 
  BarChart4, 
  Check 
} from "lucide-react";

interface Toast {
  id: string;
  type: "success" | "error" | "loading";
  message: string;
}

interface MapeadorDiagnostico360Props {
  charter?: ProjectCharter;
  setCharter?: (charter: ProjectCharter) => void;
  onSaveSuccess?: (mappedCharter: ProjectCharter) => void;
}

// Fixed UI Questions linked to the diagnostic options
interface DiagnosticQuestion {
  id: number;
  label: string;
  description: string;
  options: {
    value: number;
    text: string;
    description: string;
  }[];
}

const DIAG_QUESTIONS: DiagnosticQuestion[] = [
  {
    id: 0,
    label: "Sintoma Crítico Principal",
    description: "Identifique o maior gargalo ou ponto de dor atual que motivou este diagnóstico.",
    options: [
      { value: 0, text: "Variação e Erros de Qualidade", description: "Ocorrência constante de retrabalho, inconsistências e desperdício de insumos." },
      { value: 1, text: "Acúmulo de WIP e Gargalos", description: "Filas de tarefas paradas, colaboradores sobrecarregados e lentidão crônica." },
      { value: 2, text: "Ausência de Padronização", description: "Falta de procedimentos formais de trabalho (SOP) ou desorganização." },
      { value: 3, text: "Dificuldade de Visibilidade", description: "Falta de indicadores e relatórios históricos para entender a performance." }
    ]
  },
  {
    id: 1,
    label: "Maturidade de Mapeamento",
    description: "Como o fluxo atual de tarefas está formalizado e documentado hoje?",
    options: [
      { value: 0, text: "Nenhum Mapeamento", description: "O processo é tácito e reside apenas no hábito diário de cada colaborador." },
      { value: 1, text: "Fluxograma Estático", description: "Possuímos desenhos de fluxo em PDF ou imagem, mas estão defasados." },
      { value: 2, text: "Medição Estocástica", description: "Mapeado formalmente com tempos médios medidos, mas gargalos mudam sozinhos." },
      { value: 3, text: "Processo Otimizado", description: "Fluxos integrados em sistemas com medições automatizadas em tempo real." }
    ]
  },
  {
    id: 2,
    label: "Objetivo de Impacto Prioritário",
    description: "Qual é o principal ganho técnico esperado com a conclusão deste projeto?",
    options: [
      { value: 0, text: "Elevar Vazão (Throughput)", description: "Aumentar a quantidade de entregas ou faturamentos concluídos por hora." },
      { value: 1, text: "Garantir Qualidade (Yield)", description: "Reduzir o índice de não-conformidade físico/digital para menos de 1.5%." },
      { value: 2, text: "Reduzir Lead Time", description: "Acelerar o ciclo total de ponta a ponta, removendo esperas desnecessárias." },
      { value: 3, text: "Otimização Geral", description: "Equilibrar postos de trabalho visando mitigar custos operacionais agregados." }
    ]
  },
  {
    id: 3,
    label: "Monitoramento e Controle",
    description: "Como os desvios de metas e capabilidade são identificados hoje?",
    options: [
      { value: 0, text: "Checklists Manuais", description: "Reuniões semanais e planilhas locais preenchidas pelo próprio operador." },
      { value: 1, text: "Painéis Digitais", description: "Indicadores em BI ou ERP, porém sem limites superiores/inferiores de controle." },
      { value: 2, text: "CEP (Shewhart)", description: "Acompanhamento formal por cartas de controle estatístico (limites 3-Sigma)." },
      { value: 3, text: "Simulação por IA", description: "Sistemas integrados de inteligência artificial com disparo preditivo de alarmes." }
    ]
  }
];

export default function MapeadorDiagnostico360({ 
  charter: propCharter, 
  setCharter: propSetCharter,
  onSaveSuccess 
}: MapeadorDiagnostico360Props) {
  const { companyId, segmentConfig } = useBusinessContext();
  
  // Local active charter state for standalone fallback rendering
  const [localCharter, setLocalCharter] = useState<ProjectCharter>({
    title: "",
    problemStatement: "",
    goal: "",
    metric: "cycle_time",
    targetValue: 0
  });

  const activeCharter = propCharter || localCharter;

  const handleUpdateCharter = (newCharter: ProjectCharter) => {
    setLocalCharter(newCharter);
    if (propSetCharter) {
      propSetCharter(newCharter);
    }
  };

  // Form input states
  const [processName, setProcessName] = useState("");
  const [processObjective, setProcessObjective] = useState("");
  const [businessType, setBusinessType] = useState<
    "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "FINANCE" | "HUMAN_RESOURCES"
  >("INDUSTRIAL");
  const [answers, setAnswers] = useState<number[]>([0, 0, 0, 0]);

  // Validation feedback states
  const [touched, setTouched] = useState<{
    processName?: boolean;
    processObjective?: boolean;
    businessType?: boolean;
    answers?: boolean;
  }>({});

  const [validationErrors, setValidationErrors] = useState<{
    processName?: string;
    processObjective?: string;
    businessType?: string;
    answers?: string;
  }>({});

  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasMapped, setHasMapped] = useState(false);

  // Hook from useDiagnosticSync
  const { validateAndSync } = useDiagnosticSync({
    setCharter: handleUpdateCharter
  });

  // Highlight transition states for Project Charter preview fields when updated
  const [highlightTitle, setHighlightTitle] = useState(false);
  const [highlightProblem, setHighlightProblem] = useState(false);
  const [highlightGoal, setHighlightGoal] = useState(false);
  const [highlightMetric, setHighlightMetric] = useState(false);
  const [highlightTarget, setHighlightTarget] = useState(false);

  useEffect(() => {
    if (activeCharter.title) {
      setHighlightTitle(true);
      const timer = setTimeout(() => setHighlightTitle(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCharter.title]);

  useEffect(() => {
    if (activeCharter.problemStatement) {
      setHighlightProblem(true);
      const timer = setTimeout(() => setHighlightProblem(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCharter.problemStatement]);

  useEffect(() => {
    if (activeCharter.goal) {
      setHighlightGoal(true);
      const timer = setTimeout(() => setHighlightGoal(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCharter.goal]);

  useEffect(() => {
    if (activeCharter.metric) {
      setHighlightMetric(true);
      const timer = setTimeout(() => setHighlightMetric(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCharter.metric]);

  useEffect(() => {
    if (activeCharter.targetValue) {
      setHighlightTarget(true);
      const timer = setTimeout(() => setHighlightTarget(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCharter.targetValue]);

  // Automatically sync businessType with segmentConfig if available
  useEffect(() => {
    if (segmentConfig?.segment) {
      const seg = segmentConfig.segment;
      if (seg === "manufatura") setBusinessType("INDUSTRIAL");
      else if (seg === "servicos") setBusinessType("SERVICES");
      else if (seg === "comercio") setBusinessType("RETAIL");
      else if (seg === "logistica") setBusinessType("LOGISTICS");
      else if (seg === "tecnologia") setBusinessType("TECHNOLOGY");
      else if (seg === "saude") setBusinessType("HEALTHCARE");
      else if (seg === "financeiro" || seg === "contabil" || seg === "fiscal") setBusinessType("FINANCE");
      else if (seg === "rh") setBusinessType("HUMAN_RESOURCES");
    }
  }, [segmentConfig]);

  // Pre-populate process name based on segment configuration
  useEffect(() => {
    if (segmentConfig?.templates && segmentConfig.templates.length > 0) {
      setProcessName(`Fluxo de ${segmentConfig.templates[0]}`);
    } else {
      setProcessName("Processo de Atendimento B2B");
    }
  }, [segmentConfig]);

  // Real-time Zod Validation effect
  useEffect(() => {
    const payload = {
      answers,
      businessType,
      processName,
      processObjective: processObjective.trim() || undefined
    };

    const parsed = DiagnosticAnswersSchema.safeParse(payload);

    if (parsed.success) {
      setValidationErrors({});
    } else {
      const errs: typeof validationErrors = {};
      parsed.error.issues.forEach((issue) => {
        const fieldName = issue.path[0] as keyof typeof validationErrors;
        if (fieldName) {
          errs[fieldName] = issue.message;
        }
      });
      setValidationErrors(errs);
    }
  }, [answers, businessType, processName, processObjective]);

  // Toast notifications helpers
  const addToast = (type: "success" | "error" | "loading", message: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, message }]);
    if (type !== "loading") {
      setTimeout(() => {
        removeToast(id);
      }, 4000);
    }
    return id;
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const updateToast = (id: string, type: "success" | "error", message: string) => {
    setToasts(prev => prev.map(t => t.id === id ? { ...t, type, message } : t));
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const handleBlur = (field: keyof typeof touched) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  const handleOptionSelect = (qIndex: number, optValue: number) => {
    const updatedAnswers = [...answers];
    updatedAnswers[qIndex] = optValue;
    setAnswers(updatedAnswers);
    setTouched(prev => ({ ...prev, answers: true }));
  };

  const handleDiagnose = (e: React.FormEvent) => {
    e.preventDefault();

    // Mark fields as touched
    setTouched({
      processName: true,
      processObjective: true,
      businessType: true,
      answers: true
    });

    const payload = {
      answers,
      businessType,
      processName,
      processObjective: processObjective.trim() || undefined
    };

    const parsed = DiagnosticAnswersSchema.safeParse(payload);

    if (!parsed.success) {
      addToast("error", "Validação Zod mal-sucedida! Corrija os parâmetros destacados em vermelho.");
      return;
    }

    setIsSubmitting(true);
    const toastId = addToast("loading", "Sincronizando evidências com as regras do Project Charter...");

    setTimeout(() => {
      // Trigger the hook synchronization
      const result = validateAndSync(payload);

      setIsSubmitting(false);
      if (result.success && result.data) {
        setHasMapped(true);
        updateToast(toastId, "success", "Diagnóstico 360 mapeado com sucesso para o Project Charter!");
        if (onSaveSuccess) {
          onSaveSuccess(result.data);
        }
      } else {
        updateToast(toastId, "error", "Falha técnica ao mapear respostas.");
      }
    }, 900);
  };

  const handleReset = () => {
    setAnswers([0, 0, 0, 0]);
    setProcessObjective("");
    setTouched({});
    setHasMapped(false);
    addToast("success", "Configurações de diagnóstico reiniciadas.");
  };

  const getFieldStyle = (field: keyof typeof touched) => {
    const isTouched = touched[field];
    const hasError = !!validationErrors[field];

    const base = "w-full text-xs p-2.5 border rounded-none transition-all duration-200 outline-none ";
    if (!isTouched) {
      return base + "border-slate-300 focus:border-slate-900";
    }
    if (hasError) {
      return base + "border-rose-500 bg-rose-50/20 focus:border-rose-600";
    }
    return base + "border-emerald-500 bg-emerald-50/10 focus:border-emerald-600";
  };

  return (
    <div className="space-y-8" id="mapeador-diagnostico-360-container">
      {/* HEADER BAR */}
      <div className="bg-slate-900 text-white p-6 border-2 border-slate-900 shadow-[4px_4px_0px_rgba(209,161,66,1)] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-[10px] font-mono tracking-widest font-extrabold text-[#D1A142] block uppercase">
            Módulo Avançado de Diagnóstico
          </span>
          <h2 className="text-lg font-serif font-black tracking-tight flex items-center gap-2">
            <ClipboardCheck className="w-5.5 h-5.5 text-[#D1A142]" />
            Mapeador de Diagnóstico 360° (Project Charter Sync)
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            Colete evidências sobre seus processos através de perguntas estruturadas. Nossa inteligência
            integrada baseada em esquemas Zod valida as respostas e gera um Project Charter de alta consistência técnica.
          </p>
        </div>
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold font-mono text-[11px] uppercase border border-slate-700 hover:border-slate-500 transition-all flex items-center gap-1.5 self-start md:self-auto cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reiniciar Diagnóstico
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: DIAGNOSTIC FORM */}
        <form onSubmit={handleDiagnose} className="lg:col-span-7 space-y-6">
          {/* META FIELDS SECTION */}
          <div className="bg-white border-2 border-slate-950 p-6 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="text-xs font-mono font-black uppercase text-slate-900 tracking-widest border-b pb-2.5 flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-[#D1A142]" />
              Configuração do Escopo Operacional
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* PROCESS NAME */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Nome do Processo Analisado <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={processName}
                  onChange={(e) => {
                    setProcessName(e.target.value);
                    setTouched(prev => ({ ...prev, processName: true }));
                  }}
                  onBlur={() => handleBlur("processName")}
                  placeholder="Ex: Faturamento Fiscal"
                  className={getFieldStyle("processName")}
                  required
                />
                {touched.processName && validationErrors.processName ? (
                  <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {validationErrors.processName}
                  </p>
                ) : touched.processName ? (
                  <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> Nome do processo válido
                  </p>
                ) : null}
              </div>

              {/* SECTOR TYPE */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Setor Operacional (BusinessType) <span className="text-rose-500">*</span>
                </label>
                <select
                  value={businessType}
                  onChange={(e) => {
                    setBusinessType(e.target.value as any);
                    setTouched(prev => ({ ...prev, businessType: true }));
                  }}
                  onBlur={() => handleBlur("businessType")}
                  className={getFieldStyle("businessType")}
                >
                  <option value="INDUSTRIAL">INDUSTRIAL (Indústria/Manufatura)</option>
                  <option value="SERVICES">SERVICES (Serviços e Atendimento)</option>
                  <option value="RETAIL">RETAIL (Varejo e Comércio)</option>
                  <option value="LOGISTICS">LOGISTICS (Transporte/Estoque)</option>
                  <option value="TECHNOLOGY">TECHNOLOGY (Software e TI)</option>
                  <option value="HEALTHCARE">HEALTHCARE (Saúde e Clínicas)</option>
                  <option value="FINANCE">FINANCE (Financeiro e Controladoria)</option>
                  <option value="HUMAN_RESOURCES">HUMAN_RESOURCES (Gestão de Pessoas)</option>
                </select>
                {touched.businessType && validationErrors.businessType ? (
                  <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {validationErrors.businessType}
                  </p>
                ) : touched.businessType ? (
                  <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> Setor validado
                  </p>
                ) : null}
              </div>
            </div>

            {/* PROCESS OBJECTIVE */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Objetivo Esperado / Impacto do Projeto <span className="text-slate-400 text-[10px]">(Opcional)</span>
                </label>
                <span className={`text-[9px] font-mono ${processObjective.length > 300 ? "text-rose-500 font-bold" : "text-slate-400"}`}>
                  {processObjective.length}/300 caracteres
                </span>
              </div>
              <textarea
                value={processObjective}
                onChange={(e) => {
                  setProcessObjective(e.target.value.slice(0, 300));
                  setTouched(prev => ({ ...prev, processObjective: true }));
                }}
                onBlur={() => handleBlur("processObjective")}
                rows={2}
                placeholder="Ex: Eliminar em 25% o tempo de faturamento no encerramento de lote."
                className="w-full text-xs p-2.5 border border-slate-300 focus:border-slate-900 rounded-none bg-white leading-relaxed resize-none transition-all outline-none"
              ></textarea>
              {touched.processObjective && validationErrors.processObjective && (
                <p className="text-[10px] text-rose-600 font-medium flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {validationErrors.processObjective}
                </p>
              )}
            </div>
          </div>

          {/* QUESTIONS LIST SECTION */}
          <div className="bg-white border-2 border-slate-950 p-6 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,1)] space-y-6">
            <h3 className="text-xs font-mono font-black uppercase text-slate-900 tracking-widest border-b pb-2.5 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-[#D1A142]" />
              Evidências e Sintomas Operacionais (Diagnóstico)
            </h3>

            <div className="space-y-6">
              {DIAG_QUESTIONS.map((question, qIdx) => {
                const currentVal = answers[qIdx] ?? 0;
                return (
                  <div key={question.id} className="space-y-2 pb-4 border-b border-dashed border-slate-200 last:border-b-0 last:pb-0">
                    <div className="flex items-start gap-2">
                      <span className="text-xs font-mono font-black text-slate-900 bg-amber-100 border border-amber-300 w-5 h-5 flex items-center justify-center shrink-0">
                        {qIdx + 1}
                      </span>
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-black text-slate-900">{question.label}</h4>
                        <p className="text-[11px] text-slate-500">{question.description}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1.5">
                      {question.options.map((opt) => {
                        const isSelected = currentVal === opt.value;
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => handleOptionSelect(qIdx, opt.value)}
                            className={`p-3 text-left border-2 rounded-none transition-all duration-150 flex flex-col justify-between h-full cursor-pointer hover:border-slate-900 ${
                              isSelected
                                ? "bg-slate-900 border-slate-900 text-white shadow-[2px_2px_0px_rgba(209,161,66,1)]"
                                : "bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100"
                            }`}
                          >
                            <span className="text-xs font-black tracking-tight">{opt.text}</span>
                            <span className={`text-[10px] mt-1 leading-normal ${isSelected ? "text-slate-300" : "text-slate-500"}`}>
                              {opt.description}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* ERROR DISPLAY */}
            {validationErrors.answers && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-medium flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                {validationErrors.answers}
              </div>
            )}

            {/* TRIGGER SUBMISSION BUTTON */}
            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-6 py-3 bg-[#D1A142] text-slate-950 hover:bg-[#b88c34] transition-all font-black text-xs uppercase rounded-none flex items-center justify-center gap-2 cursor-pointer shadow-[2px_2px_0px_rgba(0,0,0,1)] disabled:bg-slate-200 disabled:text-slate-500 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Mapeando Diagnóstico...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 text-slate-950" />
                    Sincronizar e Mapear Charter 🚀
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* RIGHT COLUMN: PROJECT CHARTER LIVE MAP PREVIEW */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border-2 border-slate-950 p-6 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,1)] space-y-6 text-left">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-xs font-mono font-black uppercase text-slate-900 tracking-widest flex items-center gap-1.5">
                <FileText className="w-4.5 h-4.5 text-[#D1A142]" />
                Visualizador do Project Charter
              </h3>
              <span className={`px-2 py-0.5 text-[9px] font-mono uppercase font-black ${hasMapped ? "bg-emerald-100 text-emerald-800 border border-emerald-300" : "bg-amber-100 text-amber-800 border border-amber-300"}`}>
                {hasMapped ? "● Consistente" : "● Pendente Sync"}
              </span>
            </div>

            {/* MAIN DATA PREVIEW */}
            <div className="space-y-4">
              {/* PROJECT TITLE */}
              <div className={`space-y-1 p-3.5 border transition-all duration-700 ease-out ${
                highlightTitle 
                  ? "bg-amber-100/90 border-amber-400 ring-2 ring-amber-400/30 scale-[1.01] shadow-sm" 
                  : "bg-slate-50 border-slate-200"
              }`}>
                <span className="text-[9px] font-mono tracking-widest text-slate-400 block uppercase font-bold">
                  Título do Projeto DMAIC
                </span>
                <p className="text-xs font-serif font-black text-slate-900 leading-snug">
                  {activeCharter.title || "Aguardando sincronização do diagnóstico..."}
                </p>
              </div>

              {/* PROBLEM STATEMENT */}
              <div className={`space-y-1 p-3.5 border transition-all duration-700 ease-out ${
                highlightProblem 
                  ? "bg-amber-100/90 border-amber-400 ring-2 ring-amber-400/30 scale-[1.01] shadow-sm" 
                  : "bg-slate-50 border-slate-200"
              }`}>
                <span className="text-[9px] font-mono tracking-widest text-slate-400 block uppercase font-bold">
                  Declaração de Problema (Sintoma Técnico)
                </span>
                <p className="text-xs text-slate-700 leading-relaxed font-sans">
                  {activeCharter.problemStatement || "Aguardando o mapeamento de sintomas operacionais..."}
                </p>
              </div>

              {/* GOAL (META PRINCIPAL) */}
              <div className={`space-y-1 p-3.5 border transition-all duration-700 ease-out ${
                highlightGoal 
                  ? "bg-amber-100/90 border-amber-400 ring-2 ring-amber-400/30 scale-[1.01] shadow-sm" 
                  : "bg-slate-50 border-slate-200"
              }`}>
                <span className="text-[9px] font-mono tracking-widest text-slate-400 block uppercase font-bold">
                  Objetivo Prático (Goal)
                </span>
                <p className="text-xs text-slate-700 leading-relaxed font-sans font-medium">
                  {activeCharter.goal || "Aguardando definição de foco estratégico..."}
                </p>
              </div>

              {/* METRIC & TARGET */}
              <div className="grid grid-cols-2 gap-3">
                <div className={`space-y-1 p-3 border transition-all duration-700 ease-out ${
                  highlightMetric 
                    ? "bg-amber-100/90 border-amber-400 ring-2 ring-amber-400/30 scale-[1.01] shadow-sm" 
                    : "bg-slate-50 border-slate-200"
                }`}>
                  <span className="text-[9px] font-mono tracking-widest text-slate-400 block uppercase font-bold">
                    Métrica Chave
                  </span>
                  <p className="text-xs font-mono font-bold uppercase text-slate-900 mt-1">
                    {activeCharter.metric === "cycle_time" ? "⏱️ Tempo de Ciclo" : activeCharter.metric === "defect_rate" ? "❌ Taxa de Defeitos" : "📈 Throughput (Vazão)"}
                  </p>
                </div>
                <div className={`space-y-1 p-3 border transition-all duration-700 ease-out ${
                  highlightTarget 
                    ? "bg-amber-100/90 border-amber-400 ring-2 ring-amber-400/30 scale-[1.01] shadow-sm" 
                    : "bg-slate-50 border-slate-200"
                }`}>
                  <span className="text-[9px] font-mono tracking-widest text-slate-400 block uppercase font-bold">
                    Alvo Estatístico (Target)
                  </span>
                  <p className="text-xs font-mono font-black text-[#D1A142] text-sm mt-1">
                    {activeCharter.targetValue ? (
                      activeCharter.metric === "defect_rate" 
                        ? `${(activeCharter.targetValue * 100).toFixed(1)}%` 
                        : `${activeCharter.targetValue} ${activeCharter.metric === "cycle_time" ? "min" : "unidades/hora"}`
                    ) : "0.00"}
                  </p>
                </div>
              </div>
            </div>

            {/* ADVISORY BOX ABOUT TECHNICAL CONSISTENCY */}
            <div className="p-4 bg-amber-50/70 border border-amber-200 text-slate-800 text-xs rounded-none space-y-2 leading-relaxed">
              <span className="text-[10px] font-mono font-bold text-amber-800 uppercase block tracking-wider">
                💡 Consistência Metodológica DMAIC:
              </span>
              <p className="text-[11px] text-slate-700">
                Ao selecionar o <strong>Sintoma Principal</strong> e a <strong>Métrica de Impacto</strong> no diagnóstico, o Project Charter alinha as métricas correspondentes à filosofia Lean Six Sigma:
              </p>
              <ul className="list-disc list-inside space-y-1 text-[10px] text-slate-600 font-sans pl-1">
                <li>O principal sintoma de variabilidade altera o foco do charter para projetos DMAIC estruturados de controle.</li>
                <li>Métricas de Vazão (Throughput) adaptam-se de acordo com o segmento da empresa para gerar benchmarks adequados.</li>
                <li>Tempos de Ciclo reduzem o desperdício de Lead Time de ponta a ponta.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* 🔔 FLOATING TOAST FEEDBACK NOTIFICATIONS */}
      {toasts.length > 0 && (
        <div className="fixed bottom-5 right-5 z-[9999] flex flex-col gap-3 max-w-sm w-full" id="diag-toasts-container">
          {toasts.map((toast) => {
            let bgColor = "bg-white border-slate-900 text-slate-900";
            let icon = <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />;

            if (toast.type === "success") {
              bgColor = "bg-emerald-50 border-emerald-950 text-emerald-950";
              icon = <CheckCircle2 className="w-5.5 h-5.5 text-emerald-600 shrink-0" />;
            } else if (toast.type === "error") {
              bgColor = "bg-rose-50 border-rose-950 text-rose-950";
              icon = <AlertCircle className="w-5.5 h-5.5 text-rose-600 shrink-0" />;
            } else if (toast.type === "loading") {
              bgColor = "bg-slate-900 border-slate-950 text-white";
              icon = <Loader2 className="w-5.5 h-5.5 text-[#D1A142] animate-spin shrink-0" />;
            }

            return (
              <div
                key={toast.id}
                className={`flex items-start gap-3 p-4 border-2 shadow-[4px_4px_0px_rgba(0,0,0,1)] rounded-none animate-fadeIn ${bgColor}`}
                role="alert"
              >
                {icon}
                <div className="flex-1 text-xs font-bold leading-relaxed">
                  {toast.message}
                </div>
                <button
                  onClick={() => removeToast(toast.id)}
                  className="text-slate-400 hover:text-slate-900 shrink-0 transition-all p-0.5 cursor-pointer"
                  title="Fechar"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
