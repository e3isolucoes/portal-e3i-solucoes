import React from "react";
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface ParetoControleProps {
  alertEvents: any[];
  activeStepName: string;
  onAddSimulatedEvent: () => void;
  onClearEvents: () => void;
  triggerFlash?: (msg: string) => void;
}

export default function ParetoControle({
  alertEvents,
  activeStepName,
  onAddSimulatedEvent,
  onClearEvents,
  triggerFlash
}: ParetoControleProps) {

  const getParetoDataFromHistory = () => {
    const causeExplanations: Record<string, string> = {
      "Descalibração de Sensores": "Sensores eletromecânicos ou ópticos de medição dessincronizados",
      "Matéria-Prima Inadequada": "Variação na densidade, pureza ou liga química do lote de insumos",
      "Desgaste de Ferramental": "Fresas, moldes físicos ou bicos de extrusão desgastados por atrito",
      "Erro Operacional de Setup": "Operador configurou parâmetros de velocidade ou de temperatura errados",
      "Flutuação de Pressão/Ar": "Compressor pneumático falhando em manter o vácuo ou pressão nominal",
      "Histerese Térmica Ativa": "Demora no tempo de resposta do aquecedor acarretando variação de calor",
      "Acúmulo de Resíduos": "Sujeira ou cavacos físicos obstruindo passagens mecânicas"
    };

    const causeCounts: Record<string, { count: number; explanation: string }> = {};

    // Initialize known causes to 0 to provide standard structure
    Object.keys(causeExplanations).forEach(cause => {
      causeCounts[cause] = { count: 0, explanation: causeExplanations[cause] };
    });

    // Aggregate counts from active alert events log
    (alertEvents || []).forEach(evt => {
      const causeName = evt.cause;
      if (causeName) {
        if (causeCounts[causeName]) {
          causeCounts[causeName].count += 1;
        } else {
          causeCounts[causeName] = { count: 1, explanation: evt.explanation || "Causalidade identificada em tempo real." };
        }
      }
    });

    // Convert to array and sort descending
    const sortedList = Object.entries(causeCounts)
      .map(([cause, info]) => ({
        cause,
        count: info.count,
        explanation: info.explanation
      }))
      .sort((a, b) => b.count - a.count);

    // Filter to non-zero count, but fallback to show top causes if all are zero
    let filteredList = sortedList.filter(item => item.count > 0);
    if (filteredList.length === 0) {
      filteredList = sortedList.slice(0, 5);
    }

    const total = filteredList.reduce((sum, item) => sum + item.count, 0);

    let cum = 0;
    const chartData = filteredList.map(item => {
      cum += item.count;
      const percentage = total > 0 ? (cum / total) * 100 : 0;
      return {
        cause: item.cause,
        count: item.count,
        explanation: item.explanation,
        percentage: parseFloat(percentage.toFixed(1))
      };
    });

    return {
      chartData,
      totalCount: total
    };
  };

  const { chartData: paretoChartData, totalCount: totalParetoCount } = getParetoDataFromHistory();
  const topCause = paretoChartData[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch pt-3 border-t border-slate-200/50" id="pareto-controle-component">
      {/* Educational Panel & Primary Cause Indicator */}
      <div className="lg:col-span-4 bg-[#FAF9F6] p-4 border border-amber-500/15 rounded-sm flex flex-col justify-between text-xs space-y-3 font-sans">
        <div className="space-y-1.5">
          <div>
            <span className="text-[8px] uppercase font-black tracking-widest text-[#C49746] block">Ferramenta Lean Six Sigma</span>
            <strong className="text-slate-900 font-serif text-[12px] block">Análise de Pareto de Desvios (Causas Vitais)</strong>
          </div>
          <p className="text-[10.5px] text-slate-600 leading-relaxed">
            Este gráfico de Pareto classifica as causas dos desvios observados no limite crítico de <strong>{activeStepName}</strong>. Pela regra de Pareto (80/20), resolver as principais falhas (<strong className="text-amber-800 font-bold">Causas Vitais</strong>) remove a grande maioria das interrupções de processo.
          </p>
        </div>

        <div className="bg-amber-50/50 p-2.5 border border-[#C49746]/15 rounded-xs space-y-1">
          <span className="text-[8.5px] uppercase font-bold tracking-wider text-[#C49746] block">🔥 Oposto Vital Principal (Causa 1):</span>
          <div>
            <strong className="text-[11px] font-sans text-[#78350F] block">{topCause?.count > 0 ? topCause.cause : "Sistema Estável"}</strong>
            <p className="text-[10px] text-slate-600 leading-normal mt-0.5">
              {topCause?.count > 0 ? `"${topCause.explanation}"` : "Nenhum desvio crítico registrado na sessão atual."}
            </p>
          </div>
          {topCause?.count > 0 && (
            <div className="text-[9px] text-slate-700 bg-white/80 px-1.5 py-1 border border-slate-200 rounded-2xs flex justify-between mt-1.5 font-mono">
              <span>Representatividade:</span>
              <span className="font-bold text-indigo-950">
                {totalParetoCount > 0 ? ((topCause.count / totalParetoCount) * 100).toFixed(1) : 0}% ({topCause.count} Amostras)
              </span>
            </div>
          )}
        </div>

        <div className="space-y-1.5 pt-1">
          <button
            type="button"
            onClick={onAddSimulatedEvent}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white text-[8.5px] uppercase font-bold tracking-wider py-1.5 rounded-xs cursor-pointer text-center select-none shadow-3xs transition-all active:scale-95"
          >
            🚨 Injetar Causa Aleatória (Simular)
          </button>
          <button
            type="button"
            onClick={onClearEvents}
            className="w-full bg-white hover:bg-slate-50 text-slate-500 text-[8px] uppercase font-bold border border-slate-200 py-1 rounded-xs cursor-pointer text-center select-none shadow-3xs transition-all active:scale-95"
          >
            Definir Linha Base (Limpar Log)
          </button>
        </div>
      </div>

      {/* Composed Pareto Chart Element (Bars + Cumulative Curve Line) */}
      <div className="lg:col-span-8 bg-white p-3 border border-slate-150 rounded-sm h-[220px] flex flex-col justify-between">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] uppercase font-bold text-slate-700 font-mono flex items-center gap-1.5">
            📊 Gráfico de Pareto de Causas-Raiz (Shewhart Telecom)
          </span>
          <span className="bg-[#C49746]/10 text-[#C49746] text-[7.5px] font-mono font-black tracking-wider px-2 py-0.5 rounded-sm">
            Frequência Acumulada: {totalParetoCount} Ocorrências
          </span>
        </div>
        
        <div className="w-full h-[175px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={paretoChartData} margin={{ top: 10, right: 10, bottom: -5, left: -25 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis 
                dataKey="cause" 
                tick={{ fontSize: 7, fill: "#475569", fontWeight: "bold" }}
                axisLine={{ stroke: "#E2E8F0" }}
                tickLine={false}
              />
              {/* Left Y-axis for raw counts / frequencies */}
              <YAxis 
                yAxisId="left"
                orientation="left"
                stroke="#C49746"
                tick={{ fontSize: 8, fill: "#C49746" }}
                axisLine={{ stroke: "#E2E8F0" }}
                tickLine={false}
                label={{ value: 'Ocorrências', angle: -90, position: 'insideLeft', offset: 15, fontSize: 8, fill: '#C49746', fontWeight: 'bold' }}
              />
              {/* Right Y-axis for Cumulative percentage */}
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#EF4444"
                domain={[0, 100]}
                tick={{ fontSize: 8, fill: "#EF4444" }}
                axisLine={{ stroke: "#E2E8F0" }}
                tickLine={false}
                label={{ value: 'Percentual Cumpl (%)', angle: 90, position: 'insideRight', offset: 15, fontSize: 8, fill: '#EF4444', fontWeight: 'bold' }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-[#1A1A1A] text-white p-2.5 text-[9.5px] font-mono space-y-1 rounded-sm border-none shadow-md max-w-[210px] text-left">
                        <p className="font-bold border-b border-white/20 pb-0.5">{d.cause}</p>
                        <p className="text-slate-300 leading-normal text-[8.5px] italic">"{d.explanation}"</p>
                        <div className="flex justify-between pt-1 border-t border-dashed border-white/10">
                          <span className="text-[#F59E0B] font-bold">Frequência:</span>
                          <span className="font-black text-amber-300">{d.count} vezes</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-red-400 font-bold">Percentual Acumulado:</span>
                          <span className="font-black text-red-300">{d.percentage}%</span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar 
                yAxisId="left" 
                dataKey="count" 
                fill="#C49746" 
                fillOpacity={0.8} 
                barSize={28} 
                radius={[2, 2, 0, 0]} 
              />
              <Line 
                yAxisId="right" 
                type="monotone" 
                dataKey="percentage" 
                stroke="#EF4444" 
                strokeWidth={2} 
                dot={{ r: 3, stroke: '#991B1B', strokeWidth: 1.5, fill: '#EF4444' }} 
                activeDot={{ r: 5 }} 
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
