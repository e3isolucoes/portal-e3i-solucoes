import React, { useState } from "react";
import { Sparkles, Shield, User, Star, Key, Mail, Award, Landmark, Chrome, CheckCircle2, Ticket, CreditCard, Building2, HelpCircle } from "lucide-react";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider 
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../firebase";
import E3ILogo from "./E3ILogo";
import { MFAAuth } from "../utils/mfaManager";

export interface LoggedUser {
  fullName: string;
  email: string;
  role: string;
  belt: 'Yellow Belt' | 'Green Belt' | 'Black Belt' | 'Master Black Belt';
  planHired?: string;
  mfaConfigured?: boolean;
}

interface AuthCoverProps {
  onLoginSuccess: (user: LoggedUser) => void;
}

const PLAN_SUITES = [
  {
    id: "lss-green",
    name: "Plano Green Belt Corporativo",
    price: "R$ 297/mês",
    color: "#10B981",
    belt: "Green Belt",
    features: [
      "Mapeador BPMN com tempos de ciclo estocásticos",
      "Diagramas Sipoc, FMEA e Árvores de falhas ilimitados",
      "Simulações de Teoria de Filas G/G/c em tempo real",
      "Armazenamento em Nuvem no Firebase para até 3 projetos"
    ]
  },
  {
    id: "lss-black",
    name: "Plano Black Belt Enterprise",
    price: "R$ 547/mês",
    color: "#1A1A1A",
    belt: "Black Belt",
    highlight: true,
    features: [
      "Tudo do plano Green Belt",
      "Modelos preditivos CEP (Shewhart, Western Electric)",
      "IA E3I Intelligence Avançada (Gemini 3.5 Flash)",
      "Projetos Corporativos ilimitados",
      "Portal do Cliente customizável para compartilhar com diretoria"
    ]
  },
  {
    id: "lss-master",
    name: "Plano Master Black Belt Strategic",
    price: "R$ 980/mês",
    color: "#C49746",
    belt: "Master Black Belt",
    features: [
      "Tudo do plano Black Belt",
      "Apoio para auditoria de maturidade Lean 5S corporativa",
      "Suporte prioritário 24/7 de Especialistas LSS recomendados",
      "Isolamento completo multi-tenant sob criptografia NIST"
    ]
  }
];

export default function AuthCover({ onLoginSuccess }: AuthCoverProps) {
  const [authMode, setAuthMode] = useState<"login" | "signup" | "hire" | "restore">("login");
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [fullName, setFullName] = useState<string>("");
  const [role, setRole] = useState<string>("Engenheiro de Processos");
  const [belt, setBelt] = useState<'Yellow Belt' | 'Green Belt' | 'Black Belt' | 'Master Black Belt'>("Green Belt");
  const [cnpj, setCnpj] = useState<string>("");
  const [companyName, setCompanyName] = useState<string>("");
  const [selectedPlan, setSelectedPlan] = useState<string>("lss-black");
  const [licenseKey, setLicenseKey] = useState<string>("");
  
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // MFA Challenge State
  const [mfaChallengeUser, setMfaChallengeUser] = useState<LoggedUser | null>(null);
  const [mfaTokenInput, setMfaTokenInput] = useState<string>("");
  const [mfaError, setMfaError] = useState<string | null>(null);

  const requestLoginOrMfa = (profile: LoggedUser) => {
    const isMfaActive = MFAAuth.getUserConfig(profile.email).enabled;
    if (isMfaActive) {
      setMfaChallengeUser(profile);
      setMfaTokenInput("");
      setMfaError(null);
    } else {
      localStorage.setItem("six_sigma_active_user", JSON.stringify(profile));
      onLoginSuccess(profile);
    }
  };

  const fetchOrCreateProfile = async (uid: string, userEmail: string, userDisplayName?: string | null): Promise<LoggedUser> => {
    try {
      const userDocRef = doc(db, "users", uid);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        return userDoc.data() as LoggedUser;
      } else {
        const nameVal = userDisplayName || userEmail.split("@")[0];
        const newProfile = {
          fullName: nameVal,
          email: userEmail,
          role: "Consultor Lean Six Sigma",
          belt: "Green Belt",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        await setDoc(userDocRef, newProfile).catch((e) => console.warn("[AuthCover] setDoc user profile cached locally (offline):", e));
        return {
          fullName: newProfile.fullName,
          email: newProfile.email,
          role: newProfile.role,
          belt: newProfile.belt as any
        };
      }
    } catch (e) {
      console.warn("[AuthCover] Failed to fetch or create profile from Firestore (offline fallback active):", e);
      const nameVal = userDisplayName || userEmail.split("@")[0];
      return {
        fullName: nameVal,
        email: userEmail,
        role: "Consultor Lean Six Sigma",
        belt: "Green Belt"
      };
    }
  };

  const handleGoogleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;
      if (!user || !user.email) {
        throw new Error("Não foi possível coletar dados de e-mail do Google.");
      }
      const profile = await fetchOrCreateProfile(user.uid, user.email, user.displayName);
      requestLoginOrMfa(profile);
    } catch (err: any) {
      if (err && err.code === "auth/popup-closed-by-user") {
        console.warn("Sign in popup closed by user (cancelled).");
        setError("O login com Google foi fechado pelo usuário.");
      } else if (err && err.code === "auth/operation-not-allowed") {
        setError(
          "O provedor 'Google' não está habilitado no Console do Firebase do seu projeto. " +
          "Para corrigir: 1. Vá ao Console do Firebase; 2. Acesse 'Authentication' > 'Sign-in method'; 3. Ative o provedor 'Google'. " +
          "Ou use o botão 'Modo Demo' na lateral esquerda para acessar localmente."
        );
      } else {
        console.error(err);
        setError("Erro ao autenticar com Google: " + (err.message || err));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLocalFallback = () => {
    const defaultUser: LoggedUser = {
      fullName: "Marco Antônio Miranda",
      email: "admin@sixsigma.com",
      role: "Especialista Master Black Belt",
      belt: "Master Black Belt",
      planHired: "Licença Premium Black Belt"
    };
    requestLoginOrMfa(defaultUser);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!email || !password) {
      setError("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    if (authMode === "signup" && !fullName) {
      setError("Por favor, preencha o seu nome completo.");
      return;
    }

    setLoading(true);

    try {
      if (authMode === "login") {
        // Firebase Auth Login
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        const profile = await fetchOrCreateProfile(user.uid, email);
        requestLoginOrMfa(profile);
      } else if (authMode === "signup") {
        // Firebase Auth Signup
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;
        
        const newProfile = {
          fullName,
          email,
          role,
          belt,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        
        await setDoc(doc(db, "users", uid), newProfile);
        
        const userObj: LoggedUser = {
          fullName,
          email,
          role,
          belt
        };
        requestLoginOrMfa(userObj);
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === "auth/email-already-in-use") {
        setError("Este e-mail corporativo já está registrado no sistema.");
      } else if (err.code === "auth/invalid-credential" || err.code === "auth/wrong-password" || err.code === "auth/user-not-found" || err.code === "auth/invalid-email") {
        setError("Credenciais inválidas. Verifique seu e-mail e senha.");
      } else if (err.code === "auth/weak-password") {
        setError("A senha deve possuir pelo menos 6 caracteres.");
      } else if (err.code === "auth/operation-not-allowed") {
        setError(
          "O método de autenticação 'E-mail/Senha' não está habilitado no seu Console do Firebase. " +
          "Para ativar: 1. Vá ao Console do Firebase; 2. Acesse 'Authentication' > 'Sign-in method'; 3. Habilite o provedor 'E-mail/Senha'. " +
          "Ou use o botão 'Modo Demo' na lateral esquerda para continuar sem login em nuvem."
        );
      } else {
        setError("Falha na autenticação: " + (err.message || err));
      }
    } finally {
      setLoading(false);
    }
  };

  // MOCK PLANS PURCHASE SIMULATION (HIRE THE SERVICE)
  const handleHireSimulation = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!email || !password || !fullName || !companyName) {
      setError("Por favor, preencha o nome completo, dados da empresa, e-mail e senha.");
      return;
    }

    setLoading(true);
    
    // 1. Try to register through firebase first so they get real credentials
    try {
      const selectedPlanObj = PLAN_SUITES.find(p => p.id === selectedPlan) || PLAN_SUITES[1];
      const selectedBelt = selectedPlanObj.belt as any;

      let uid = "local_" + Date.now();
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        uid = userCredential.user.uid;
        
        const newProfile = {
          fullName,
          email,
          role: "Diretor • " + companyName,
          belt: selectedBelt,
          cnpj: cnpj || "Isento",
          planHired: selectedPlanObj.name,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        await setDoc(doc(db, "users", uid), newProfile);
      } catch (authErr: any) {
        // Fallback or handle active email already in use
        if (authErr.code === "auth/email-already-in-use") {
          setError("O e-mail digitado já possui licença ativa. Tente fazer login ou recuperar acesso.");
          setLoading(false);
          return;
        }
        if (authErr.code === "auth/operation-not-allowed") {
          setError(
            "O método de autenticação 'E-mail/Senha' não está habilitado no Console do Firebase do seu projeto. " +
            "Para ativar: 1. Vá ao Console do Firebase; 2. Acesse 'Authentication' > 'Sign-in method'; 3. Habilite o provedor 'E-mail/Senha'."
          );
          setLoading(false);
          return;
        }
        console.warn("Firebase signup inactive, using corporate fallback profile token.", authErr);
      }

      setSuccessMessage(`✨ CONTRATAÇÃO HOMOLOGADA! O Plano "${selectedPlanObj.name}" foi ativado com sucesso para a empresa ${companyName}.`);
      
      const userObj: LoggedUser = {
        fullName,
        email,
        role: "Diretor • " + companyName,
        belt: selectedBelt,
        planHired: selectedPlanObj.name
      };

      setTimeout(() => {
        requestLoginOrMfa(userObj);
      }, 1800);

    } catch (err: any) {
      setError("Erro ao processar ativação de licença: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  // LICENSE RESTORE SIMULATION
  const handleRestoreSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!email) {
      setError("Por favor, preencha o seu e-mail corporativo cadastrado.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      
      // Auto-validate license key or general email patterns for instant relief
      const isTestAdmin = email === "admin@sixsigma.com" || email.includes("e3i");
      
      const restoredUser: LoggedUser = {
        fullName: isTestAdmin ? "Marco Antônio Miranda" : email.split("@")[0].toUpperCase(),
        email: email,
        role: "Consultor Homologado",
        belt: isTestAdmin ? "Master Black Belt" : "Black Belt",
        planHired: "Licença Corporativa Ativada"
      };

      setSuccessMessage("🔑 Licença corporativa localizada e liberada com sucesso!");
      
      setTimeout(() => {
        requestLoginOrMfa(restoredUser);
      }, 1200);

    }, 800);
  };

  const loadDefaultCredential = () => {
    setEmail("admin@sixsigma.com");
    setPassword("admin123");
    setAuthMode("login");
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#0E2C54]/5 text-[#1A1A1A] font-sans flex items-center justify-center p-4 sm:p-6 antialiased select-none">
      <div className="w-full max-w-5xl bg-white border border-slate-300 shadow-[8px_8px_0px_0px_rgba(14,44,84,0.15)] grid grid-cols-1 md:grid-cols-12 overflow-hidden rounded-md">
        
        {/* Left Side: Editorial Banner reflecting the logo exact styling */}
        <div className="md:col-span-12 lg:col-span-5 bg-[#0E2C54] text-white p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-200 relative">
          <div className="absolute inset-0 bg-[radial-gradient(#C49746_1.2px,transparent_1.2px)] [background-size:20px_20px] opacity-10 pointer-events-none"></div>
          <div className="absolute top-0 left-0 w-full h-1.5 bg-[#C49746]"></div>
          
          <div className="space-y-6 relative z-10">
            <div className="flex items-center gap-2">
              <span className="p-1 px-1.5 bg-[#C49746]/15 text-[#C49746] rounded-xs text-[10px] uppercase tracking-wider font-mono border border-[#C49746]/30">
                LSS • BPM CBOK PLATFORM
              </span>
            </div>

            {/* Central White Frame Logo wrapper */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10 flex flex-col items-center shadow-lg">
              <E3ILogo width={230} height={120} variant="dark" />
            </div>

            <p className="text-xs text-slate-3 w-normal leading-relaxed font-sans">
              A <strong>E3I Soluções</strong> desenvolveu um ecossistema definitivo para mapeamento de processos, simulações estatísticas de filas, controle CEP Shewhart e soluções fundamentadas em inteligência artificial.
            </p>

            <div className="space-y-3.5 pt-4 border-t border-blue-900/50 text-xs">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 size={14} className="text-[#C49746] shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-200">
                  <strong className="text-white block font-semibold leading-tight">Mapeamento Avançado do Lote</strong>
                  Detecção instantânea de gargalos, setup de máquinas elevados e análises de valor agregado.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 size={14} className="text-[#C49746] shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-200">
                  <strong className="text-white block font-semibold leading-tight">Simulação Científica</strong>
                  Estabilidade de processos por Shewhart e alarmes automáticos baseados no WECO.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 size={14} className="text-[#C49746] shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-200">
                  <strong className="text-white block font-semibold leading-tight">Inteligência Lean Autônoma</strong>
                  Algoritmos inteligentes sugerindo planos de ação focados em zerar o custo da não-qualidade.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-6 relative z-10">
            <div className="p-3 bg-white/5 border border-white/10 rounded-sm space-y-1.5">
              <div className="text-[8.5px] font-mono font-bold uppercase tracking-wider text-[#C49746] flex items-center gap-1">
                <Star size={10} className="fill-[#C49746] text-[#C49746]" /> Acesso rápido de testes
              </div>
              <div className="text-[10px] text-slate-300 flex flex-col gap-0.5 font-sans">
                <p>E-mail: <strong className="font-mono text-white text-[10.5px]">admin@sixsigma.com</strong></p>
                <p>Senha: <strong className="font-mono text-white text-[10.5px]">admin123</strong></p>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <button
                  type="button"
                  onClick={loadDefaultCredential}
                  className="py-1 text-center bg-white/10 hover:bg-white/15 text-[#C49746] text-[9px] font-bold font-mono border border-[#C49746]/40 rounded-xs uppercase tracking-wide transition-all cursor-pointer"
                >
                  Preencher
                </button>
                <button
                  type="button"
                  onClick={handleLocalFallback}
                  className="py-1 text-center bg-[#C49746] hover:bg-amber-600 text-white text-[9px] font-bold font-mono rounded-xs uppercase tracking-wide transition-all cursor-pointer"
                >
                  Modo Demo
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Tabbed authentication & hiring interface */}
        <div className="md:col-span-12 lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center bg-white">
          {mfaChallengeUser ? (
            <div className="max-w-md mx-auto w-full space-y-6 text-left">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-md flex items-center gap-3">
                <Shield className="text-[#0E2C54] animate-pulse shrink-0" size={24} />
                <div>
                  <h3 className="text-xs font-bold text-[#0E2C54] uppercase tracking-wider">Verificação de Duplo Fator (MFA)</h3>
                  <p className="text-[10px] text-blue-700 leading-tight">Este perfil de acesso possui privilégios que requerem autenticação em conformidade com as regras corporativas da E3I.</p>
                </div>
              </div>

              <div className="space-y-2">
                <h2 className="text-lg font-serif font-black uppercase text-slate-800 tracking-tight">Inserir código MFA</h2>
                <p className="text-xs text-slate-500">Forneça o token de 6 dígitos gerado pelo seu Authenticator App (TOTP) ou digite um código de recuperação descartável.</p>
              </div>

              {mfaError && (
                <div role="alert" className="p-3 bg-red-50 border-l-4 border-red-500 text-red-900 text-[11px] leading-relaxed">
                  <strong className="font-black">Erro de Acesso:</strong> {mfaError}
                </div>
              )}

              <form onSubmit={(e) => {
                e.preventDefault();
                setMfaError(null);
                const res = MFAAuth.verifyCode(mfaChallengeUser.email, mfaTokenInput);
                if (res.success) {
                  localStorage.setItem("six_sigma_active_user", JSON.stringify(mfaChallengeUser));
                  onLoginSuccess(mfaChallengeUser);
                } else {
                  setMfaError(res.error || "Código inválido.");
                }
              }} className="space-y-4">
                <div>
                  <label htmlFor="mfaTokenInput" className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    Código de Segurança de 6 Dígitos ou de Recuperação
                  </label>
                  <input
                    id="mfaTokenInput"
                    required
                    type="text"
                    value={mfaTokenInput}
                    onChange={(e) => setMfaTokenInput(e.target.value)}
                    placeholder="Ex: 123456 ou E3I-XXXXXX"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 text-center font-mono font-bold tracking-widest focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                    autoFocus
                  />
                  <div className="mt-2 text-[10px] text-slate-400 bg-slate-50 p-2 rounded border border-slate-100 flex flex-col gap-1 font-mono">
                    <p className="font-bold text-slate-600">Simulador de Credenciais:</p>
                    <p>• Token Padrão de Teste: <strong className="text-[#C49746]">123456</strong></p>
                    <p>• Lockout: Qualquer 6 dígitos diferente de 123456 simula erro.</p>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMfaChallengeUser(null)}
                    className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono font-extrabold text-[10px] uppercase py-2.5 rounded-xs transition-colors cursor-pointer text-center"
                  >
                    Voltar
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 bg-[#0E2C54] hover:bg-[#081E3B] text-white font-mono font-extrabold text-[10px] uppercase tracking-wider py-2.5 rounded-xs transition-colors cursor-pointer text-center"
                  >
                    Confirmar Código
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="max-w-md mx-auto w-full space-y-6">
            
            {/* Nav Switch Tabs */}
            <div className="flex border-b border-slate-100 pb-2 gap-1.5 overflow-x-auto">
              <button
                type="button"
                onClick={() => { setAuthMode("login"); setError(null); setSuccessMessage(null); }}
                className={`px-3 py-1.5 text-[10.5px] font-mono font-extrabold uppercase tracking-widest shrink-0 border-b-2 transition-all ${
                  authMode === "login"
                    ? "border-[#0E2C54] text-[#0E2C54]"
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                Logar
              </button>
              <button
                type="button"
                onClick={() => { setAuthMode("signup"); setError(null); setSuccessMessage(null); }}
                className={`px-3 py-1.5 text-[10.5px] font-mono font-extrabold uppercase tracking-widest shrink-0 border-b-2 transition-all ${
                  authMode === "signup"
                    ? "border-[#0E2C54] text-[#0E2C54]"
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                Cadastrar
              </button>
              <button
                type="button"
                onClick={() => { setAuthMode("hire"); setError(null); setSuccessMessage(null); }}
                className={`px-3 py-1.5 text-[10.5px] font-mono font-extrabold uppercase tracking-widest shrink-0 border-b-2 transition-all ${
                  authMode === "hire"
                    ? "border-[#C49746] text-[#C49746] font-black"
                    : "border-transparent text-amber-600/70 hover:text-amber-800"
                }`}
              >
                ✨ Contratar Serviço
              </button>
              <button
                type="button"
                onClick={() => { setAuthMode("restore"); setError(null); setSuccessMessage(null); }}
                className={`px-3 py-1.5 text-[10.5px] font-mono font-extrabold uppercase tracking-widest shrink-0 border-b-2 transition-all ${
                  authMode === "restore"
                    ? "border-amber-600 text-amber-700"
                    : "border-transparent text-slate-450 hover:text-slate-600"
                }`}
              >
                Obter Acesso
              </button>
            </div>

            <div className="space-y-1 text-left">
              <h2 className="text-lg font-serif font-black uppercase text-slate-800 tracking-tight flex items-center gap-1.5">
                {authMode === "login" && "Login Corporativo"}
                {authMode === "signup" && "Cadastrar Novo Analista"}
                {authMode === "hire" && "Contratar Planos E3I Soluções"}
                {authMode === "restore" && "Validar e Obter Meu Acesso"}
              </h2>
              <p className="text-xs text-slate-500 leading-normal">
                {authMode === "login" && "Insira suas credenciais abaixo para carregar seu ambiente corporativo."}
                {authMode === "signup" && "Crie um perfil corporativo no Firebase de sua organização para gerir processos."}
                {authMode === "hire" && "Caso ainda não possua acesso, contrate um plano corporativo abaixo e comece no mesmo instante!"}
                {authMode === "restore" && "Obtenha ou recupere o seu licenciamento corporativo via validação rápida de e-mail."}
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border-l-4 border-red-500 text-red-900 text-[11px] text-left leading-relaxed">
                <strong className="font-black">Erro:</strong> {error}
              </div>
            )}

            {successMessage && (
              <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-900 text-xs text-left leading-relaxed font-bold animate-pulse">
                {successMessage}
              </div>
            )}

            {/* VIEW: LOGIN FORM */}
            {authMode === "login" && (
              <form onSubmit={handleAuth} className="space-y-4 text-left">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    E-mail Corporativo
                  </label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@e3isolucoes.com.br"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    Senha de Entrada
                  </label>
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Sua senha corporativa de 6 dígitos"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#0E2C54] hover:bg-[#081E3B] text-white font-sans font-extrabold text-[11px] uppercase tracking-widest py-3 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm rounded-xs"
                  >
                    {loading ? "Carregando ambiente..." : "Entrar e Carregar Projetos"}
                  </button>
                </div>
              </form>
            )}

            {/* VIEW: SIGNUP FORM */}
            {authMode === "signup" && (
              <form onSubmit={handleAuth} className="space-y-4 text-left">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    Nome Completo
                  </label>
                  <input
                    required
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Seu nome"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                      Cargo Corporativo
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-2.5 py-1.8 focus:border-[#C49746] focus:outline-none focus:bg-white"
                    >
                      <option value="Engenheiro de Processos">Engenheiro de Processos</option>
                      <option value="Gestor de Qualidade">Analista de Qualidade</option>
                      <option value="Gerente Industrial">Gerente Industrial</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                      Maturidade Belt
                    </label>
                    <select
                      value={belt}
                      onChange={(e: any) => setBelt(e.target.value)}
                      className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-2.5 py-1.8 text-[#C49746] font-bold focus:border-[#C49746] focus:outline-none focus:bg-white"
                    >
                      <option value="Green Belt">💚 Green Belt</option>
                      <option value="Black Belt">🖤 Black Belt</option>
                      <option value="Master Black Belt">⚡ Master Black Belt</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    E-mail de Cadastro
                  </label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu.nome@empresa.com"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    Senha de Segurança
                  </label>
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#0E2C54] hover:bg-[#081E3B] text-white font-sans font-extrabold text-[11px] uppercase tracking-widest py-3 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm rounded-xs"
                  >
                    {loading ? "Criando conta..." : "Registrar Analista no Firebase"}
                  </button>
                </div>
              </form>
            )}

            {/* VIEW: HIRE THE SERVICE (PLANS SELECTION) */}
            {authMode === "hire" && (
              <form onSubmit={handleHireSimulation} className="space-y-4 text-left">
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-[#C49746] bg-[#C49746]/10 px-2 py-0.5 rounded-sm">
                  Selecione um plano corporativo E3I:
                </span>

                <div className="grid grid-cols-1 gap-2">
                  {PLAN_SUITES.map((plan) => (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => setSelectedPlan(plan.id)}
                      className={`text-left p-2.5 border rounded-sm transition-all cursor-pointer ${
                        selectedPlan === plan.id
                          ? "border-[#C49746] bg-amber-50/45 ring-1 ring-[#C49746]"
                          : "border-slate-200 hover:border-slate-300 bg-slate-50/30"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold uppercase font-sans text-[#0E2C54]">
                          {plan.name}
                        </span>
                        <span className="text-[10px] font-black text-amber-700 bg-amber-100/50 px-2 py-0.5 rounded-sm">
                          {plan.price}
                        </span>
                      </div>
                      <p className="text-[9px] text-slate-500 mt-1">
                        ✔️ {plan.features[0]} e mais {plan.features.length - 1} recursos exclusivos LSS.
                      </p>
                    </button>
                  ))}
                </div>

                <div className="p-3 bg-blue-50/50 border border-blue-900/10 space-y-3 rounded-xs">
                  <span className="text-[9px] font-black uppercase text-[#0E2C54] block">Ficha Cadastral para Ativação Instantânea:</span>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <input
                        required
                        type="text"
                        placeholder="Nome do Diretor"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full bg-white border border-slate-300 text-[11px] px-2 py-1.5 focus:outline-none"
                      />
                    </div>
                    <div>
                      <input
                        required
                        type="text"
                        placeholder="Nome da Empresa (Ex: Delta S.A.)"
                        value={companyName}
                        onChange={(e) => setCompanyName(e.target.value)}
                        className="w-full bg-white border border-slate-300 text-[11px] px-2 py-1.5 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <input
                        type="text"
                        placeholder="CNPJ (Opcional)"
                        value={cnpj}
                        onChange={(e) => setCnpj(e.target.value)}
                        className="w-full bg-white border border-slate-300 text-[11px] px-2 py-1.5 focus:outline-none"
                      />
                    </div>
                    <div>
                      <input
                        required
                        type="email"
                        placeholder="E-mail de acesso corporativo"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-white border border-slate-300 text-[11px] px-2 py-1.5 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <input
                      required
                      type="password"
                      placeholder="Crie sua Senha de Acesso (Mínimo 6 dígitos)"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-white border border-slate-300 text-[11px] px-2.5 py-1.5 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#C49746] hover:bg-amber-600 text-white font-mono font-extrabold text-[10px] uppercase tracking-widest py-3 flex items-center justify-center gap-2 cursor-pointer shadow-md rounded-xs"
                  >
                    <CreditCard size={12} className="text-white" />
                    {loading ? "Processando Ativação..." : "Contratar o Serviço & Ativar Acesso"}
                  </button>
                  <p className="text-[9px] text-[#0E2C54] mt-2 font-mono text-center">
                    🔒 Criptografia SSL integrada. Cobrança suspensa nos primeiros 14 dias de teste.
                  </p>
                </div>
              </form>
            )}

            {/* VIEW: OBTAIN ACCESS (RESTORE EXISTING CONTRACT) */}
            {authMode === "restore" && (
              <form onSubmit={handleRestoreSimulation} className="space-y-4 text-left">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    E-mail Corporativo Contratado
                  </label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@e3isolucoes.com.br"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs"
                  />
                  <p className="text-[9px] text-slate-500 mt-1">
                    O sistema buscará em nossa base de contratos ativos no Cloud Firestore para re-estabelecer o painel.
                  </p>
                </div>

                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-widest text-[#0E2C54]/80 mb-1">
                    Chave de Acesso / Token de Licença (Opcional)
                  </label>
                  <input
                    type="text"
                    value={licenseKey}
                    onChange={(e) => setLicenseKey(e.target.value)}
                    placeholder="EX: LSS-ATV-XXXX"
                    className="w-full bg-[#FAF8F5] border border-slate-300 text-xs px-3 py-2 focus:border-[#C49746] focus:bg-white focus:outline-none transition-all rounded-xs uppercase font-mono tracking-widest"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#0E2C54] hover:bg-[#081E3B] text-white font-mono font-extrabold text-[11px] uppercase tracking-widest py-3 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm rounded-xs"
                  >
                    {loading ? "Verificando assinatura..." : "Liberar Meu Acesso"}
                  </button>
                </div>
              </form>
            )}

            {/* Google authentication flow alternative */}
            {authMode === "login" && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-[9px] text-gray-400 uppercase tracking-widest font-mono">
                  <span className="h-[1px] bg-slate-200 w-[42%]"></span>
                  <span className="shrink-0">ou</span>
                  <span className="h-[1px] bg-slate-200 w-[42%]"></span>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={loading}
                  className="w-full bg-white hover:bg-slate-50 text-slate-800 font-sans font-bold text-[10.5px] uppercase tracking-wider py-2.5 border border-[#0E2C54]/30 rounded-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Chrome size={12} className="text-[#EA4335]" />
                  <span>Logar com conta homologada Google</span>
                </button>
              </div>
            )}
          </div>
          )}
        </div>

      </div>
    </div>
  );
}
