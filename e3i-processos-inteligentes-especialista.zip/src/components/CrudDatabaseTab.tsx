import React from "react";
import { Company, WorkspaceProject, ProcessStep, ControlPlan, ProjectCharter, Sipoc } from "../types";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";

interface CrudDatabaseTabProps {
  companies: Company[];
  projects: WorkspaceProject[];
  steps?: ProcessStep[];
  controlPlans?: ControlPlan[];
  charter?: ProjectCharter | null;
  sipoc?: Sipoc | null;
  eaObjectives: any[];
  eaProcesses: any[];
  eaResources: any[];
  eaRelationships: any[];
  crudEntityType: "COMPANIES" | "PROJECTS" | "STEPS" | "CONTROL_PLANS" | "EA_OBJECTIVES" | "EA_PROCESSES" | "EA_RESOURCES" | "EA_RELATIONSHIPS" | "CHARTER" | "SIPOC";
  setCrudEntityType: (type: any) => void;
  crudFormFields: any;
  setCrudFormFields: (fields: any) => void;
  crudEditingId: string | null;
  setCrudEditingId: (id: string | null) => void;
  crudFeedback: { type: "success" | "error"; text: string } | null;
  setCrudFeedback: (feedback: any) => void;
  handleStartCreateCrudItem: () => void;
  handleSelectCrudEditItem: (item: any) => void;
  handleSaveCrudItem: (e: React.FormEvent) => void;
  handleDeleteCrudItem: (id: string) => void;
}

export default function CrudDatabaseTab({
  companies,
  projects,
  steps = [],
  controlPlans = [],
  charter,
  sipoc,
  eaObjectives,
  eaProcesses,
  eaResources,
  eaRelationships,
  crudEntityType,
  setCrudEntityType,
  crudFormFields,
  setCrudFormFields,
  crudEditingId,
  setCrudEditingId,
  crudFeedback,
  setCrudFeedback,
  handleStartCreateCrudItem,
  handleSelectCrudEditItem,
  handleSaveCrudItem,
  handleDeleteCrudItem,
}: CrudDatabaseTabProps) {
  return (
    <div className="space-y-6 animate-fade-in text-left">
      <div className="bg-[#FAF9F6] border border-[#1A1A1A] p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] rounded-sm space-y-4">
        <div className="flex items-center gap-2">
          <span className="p-1 px-2.5 bg-indigo-700 text-white font-mono text-[9px] font-black uppercase tracking-wider">
            Console de Governança
          </span>
        </div>
        <h4 className="text-xl font-serif text-gray-950 font-bold flex items-center gap-2">
          🗄️ CRUD de Gestão de Dados Core &amp; EAM
        </h4>
        <p className="text-xs text-gray-600 leading-relaxed max-w-4xl">
          Efetue operações CRUD (Criação, Leitura, Atualização e Deleção) diretamente nas coleções de dados sincronizadas com o banco de dados principal. Toda alteração reflete imediatamente nas visões dos analistas em tempo real.
        </p>
      </div>

      {/* FEEDBACK NOTIFICATION */}
      {crudFeedback && (
        <div className={`p-4 border ${
          crudFeedback.type === "success"
            ? "bg-emerald-50 border-emerald-600/30 text-emerald-900 shadow-[3px_3px_0px_0px_rgba(16,185,129,1)]"
            : "bg-red-50 border-red-600/30 text-red-900 shadow-[3px_3px_0px_0px_rgba(220,38,38,1)]"
        } flex items-start gap-2.5 transition-all text-xs font-semibold font-sans`}>
          <span>{crudFeedback.type === "success" ? "✅" : "🚫"}</span>
          <div className="flex-grow">{crudFeedback.text}</div>
          <button
            type="button"
            onClick={() => setCrudFeedback(null)}
            className="text-[9.5px] uppercase font-bold hover:underline font-mono tracking-wider ml-2 shrink-0 cursor-pointer"
          >
            [Fechar]
          </button>
        </div>
      )}

      {/* COLLECTION SELECTOR BUTTONS */}
      <div className="space-y-2">
        <span className="text-[10.5px] font-mono font-bold uppercase text-slate-450 tracking-wider block">
          Selecione a Tabela / Coleção para Gestão Direta:
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 font-sans">
          {[
            { id: "COMPANIES", label: "🏢 Empresas PJ", desc: "Contratos & Clientes" },
            { id: "PROJECTS", label: "🚀 Projetos DMAIC", desc: "Ciclos de melhoria ativa" },
            { id: "STEPS", label: "⚙️ Etapas de Fluxo", desc: "Bancadas de processos" },
            { id: "CONTROL_PLANS", label: "📊 Planos de Controle", desc: "Variáveis CEP & UCL/LCL" },
            { id: "EA_OBJECTIVES", label: "📏 Métricas/Objetivos", desc: "Visão Geral BIZBOK" },
            { id: "EA_PROCESSES", label: "🌍 Processos EAM", desc: "TOGAF Fase B" },
            { id: "EA_RESOURCES", label: "🧱 Recursos/Infra", desc: "TOGAF Fase C/D" },
            { id: "EA_RELATIONSHIPS", label: "🔗 Matriz Relações", desc: "Rastreabilidade LSS" },
            { id: "CHARTER", label: "📋 Project Charter", desc: "Termos de Abertura" },
            { id: "SIPOC", label: "⚡ SIPOC Ativo", desc: "Escopo e Fronteiras" }
          ].map((entity) => {
            const isSelected = crudEntityType === entity.id;
            return (
              <button
                key={entity.id}
                type="button"
                onClick={() => {
                  setCrudEntityType(entity.id as any);
                  setCrudEditingId(null);
                  setCrudFeedback(null);
                }}
                className={`p-3 border text-left rounded-none transition-all cursor-pointer ${
                  isSelected
                    ? "bg-[#1A1A1A] border-[#1A1A1A] text-white shadow-[2px_2px_0px_0px_rgba(196,151,70,1)] font-extrabold"
                    : "bg-white border-gray-200 hover:border-[#1A1A1A] text-gray-700"
                }`}
              >
                <div className="text-[11px] font-bold tracking-tight">{entity.label}</div>
                <div className={`text-[8.5px] font-mono mt-0.5 ${isSelected ? "text-amber-300" : "text-gray-400"}`}>
                  {entity.desc}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* MAIN CONTAINER */}
      <div className="bg-white border border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] overflow-hidden font-sans">
        <div className="bg-[#1A1A1A] text-white px-4 py-3 font-mono text-[10px] font-bold uppercase tracking-wider flex justify-between items-center">
          <span>Tabela em Foco: {crudEntityType}</span>
          {crudEditingId === null && crudEntityType !== "CHARTER" && crudEntityType !== "SIPOC" && (
            <button
              type="button"
              onClick={handleStartCreateCrudItem}
              className="bg-[#C49746] hover:bg-amber-600 text-[#1A1A1A] px-3 py-1 text-[9.5px] uppercase font-bold tracking-wider rounded-xs transition-colors cursor-pointer"
            >
              + Criar Registro
            </button>
          )}
        </div>

        {crudEditingId !== null ? (
          /* FORM VIEW */
          <form onSubmit={handleSaveCrudItem} className="p-5 space-y-4 bg-[#FAF9F6]/30">
            <h5 className="font-serif text-xs font-bold uppercase border-b pb-1.5 tracking-wider text-gray-800">
              {crudEditingId === "new" ? "✨ Criar Novo Item de Banco de Dados" : `📝 Alterar Registro ID: ${crudEditingId}`}
            </h5>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {crudEntityType === "COMPANIES" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Razão Social / Nome Fantasia</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.name || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, name: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">CNPJ / Inscrição</label>
                    <input
                      type="text"
                      value={crudFormFields.cnpj || ""}
                      placeholder="Ex: 00.000.000/0500-11"
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, cnpj: e.target.value })}
                      className="w-full bg-white border border-gray-355 p-2 text-xs font-mono text-gray-950 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Setor de Atuação</label>
                    <select
                      value={crudFormFields.industry || "Varejo"}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, industry: e.target.value })}
                      className="w-full bg-white text-black border border-gray-350 p-2 text-xs font-bold"
                    >
                      <option value="Industrial &amp; Montagem SMT" className="text-black bg-white">Industrial &amp; Montagem SMT</option>
                      <option value="Industrial &amp; Manufatura" className="text-black bg-white">Industrial &amp; Manufatura</option>
                      <option value="Saúde &amp; Hospitais" className="text-black bg-white">Saúde &amp; Hospitais</option>
                      <option value="Varejo &amp; Serviços" className="text-black bg-white">Varejo &amp; Serviços</option>
                      <option value="Logística &amp; Distribuição" className="text-black bg-white">Logística &amp; Distribuição</option>
                    </select>
                  </div>
                </>
              )}

              {crudEntityType === "PROJECTS" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Nome do Projeto LSS</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.name || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, name: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Empresa Pertencente</label>
                    <select
                      required
                      value={crudFormFields.companyId || ""}
                      onFocus={async () => {
                        try {
                          await CompanyProjectRepository.fetchAllCompaniesImmediate();
                        } catch (err) {
                          console.warn("Failed to fetch all companies forced inside CrudDatabaseTab:", err);
                        }
                      }}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, companyId: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900 cursor-pointer"
                    >
                      <option value="">-- Escolha uma Organização --</option>
                      {(companies || []).map(c => (
                        <option key={c.id} value={c.id} className="text-gray-900 font-bold bg-white">{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Escopo do Objetivo Estratégico</label>
                    <textarea
                      rows={2}
                      value={crudFormFields.objective || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, objective: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs leading-relaxed text-gray-800 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Status de Maturidade</label>
                    <select
                      value={crudFormFields.status || "Planejado"}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, status: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900"
                    >
                      <option value="Planejado">Planejado</option>
                      <option value="Em Andamento">Em Andamento</option>
                      <option value="Concluído">Concluído</option>
                      <option value="Suspenso">Suspenso</option>
                    </select>
                  </div>
                </>
              )}

              {crudEntityType === "STEPS" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Nome da Etapa / Equipamento</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.name || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, name: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Operador / Recurso Responsável</label>
                    <input
                      type="text"
                      value={crudFormFields.resource || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, resource: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900 focus:outline-[#C49746]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Recursos Simultâneos (N de Servidores)</label>
                    <input
                      type="number"
                      min={1}
                      value={crudFormFields.resourceCount || 1}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, resourceCount: parseInt(e.target.value) || 1 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono font-bold text-gray-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Tempo de Serviço (Média Real / min)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={crudFormFields.processingTime || 10}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, processingTime: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono font-bold text-gray-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Erro de Escopo / Desvio Padrão (s)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={crudFormFields.standardDeviation || 2}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, standardDeviation: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono font-bold text-gray-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Yield Rate / Sem falha (0.01 a 1.00)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      max="1.00"
                      value={crudFormFields.yieldRate || 0.95}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, yieldRate: parseFloat(e.target.value) || 1 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono font-bold text-gray-900"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "CONTROL_PLANS" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Posto Vinculado</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.stepName || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, stepName: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Variável Crítica de Qualidade (CTQ)</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.metric || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, metric: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-905"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Central Target (Meta Nomina)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={crudFormFields.target || 5}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, target: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Limite UCL (+3 Sigma)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={crudFormFields.ucl || 8}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, ucl: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Limite LCL (-3 Sigma)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={crudFormFields.lcl || 2}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, lcl: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-[#1A1A1A]/20 p-2 text-xs font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">E-mail de Alerta Moderado (&gt; 2σ)</label>
                    <input
                      type="email"
                      placeholder="qualidade@empresa.com"
                      value={crudFormFields.warningEmail || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, warningEmail: e.target.value })}
                      className={`w-full bg-white border p-2 text-xs text-gray-900 ${
                        crudFormFields.warningEmail && crudFormFields.warningEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(crudFormFields.warningEmail.trim())
                          ? "border-red-500 focus:outline-red-500"
                          : "border-gray-350 focus:outline-[#C49746]"
                      }`}
                    />
                    {crudFormFields.warningEmail && crudFormFields.warningEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(crudFormFields.warningEmail.trim()) && (
                      <span className="block text-[8.5px] text-red-600 font-bold mt-0.5">⚠️ Formato de e-mail inválido</span>
                    )}
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">E-mail de Alerta Crítico (&gt; 3σ)</label>
                    <input
                      type="email"
                      placeholder="alerta.critico@empresa.com"
                      value={crudFormFields.criticalEmail || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, criticalEmail: e.target.value })}
                      className={`w-full bg-white border p-2 text-xs text-gray-900 ${
                        crudFormFields.criticalEmail && crudFormFields.criticalEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(crudFormFields.criticalEmail.trim())
                          ? "border-red-500 focus:outline-red-500"
                          : "border-gray-350 focus:outline-[#C49746]"
                      }`}
                    />
                    {crudFormFields.criticalEmail && crudFormFields.criticalEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(crudFormFields.criticalEmail.trim()) && (
                      <span className="block text-[8.5px] text-red-600 font-bold mt-0.5">⚠️ Formato de e-mail inválido</span>
                    )}
                  </div>
                </>
              )}

              {crudEntityType === "EA_OBJECTIVES" && (
                <>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Meta Estratégica EAM / BIZBOK</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.title || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, title: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Indicador Alvo KPI</label>
                    <input
                      type="text"
                      value={crudFormFields.metricTarget || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, metricTarget: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "EA_PROCESSES" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Nome do Processo Corporativo</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.name || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, name: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-905"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Dono do Processo (Owner)</label>
                    <input
                      type="text"
                      value={crudFormFields.owner || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, owner: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-semibold"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "EA_RESOURCES" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Nome do Sistema / Ativo Tecnológico</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.name || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, name: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold text-gray-905"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Capacidade Operacional</label>
                    <input
                      type="text"
                      value={crudFormFields.capacityInfo || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, capacityInfo: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "EA_RELATIONSHIPS" && (
                <>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Nota Rastreabilidade</label>
                    <input
                      type="text"
                      value={crudFormFields.integrationNote || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, integrationNote: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "CHARTER" && (
                <>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Título do Charter</label>
                    <input
                      type="text"
                      required
                      value={crudFormFields.title || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, title: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-bold"
                    />
                  </div>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">Problem Statement</label>
                    <textarea
                      rows={2}
                      value={crudFormFields.problemStatement || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, problemStatement: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-sans"
                    />
                  </div>
                </>
              )}

              {crudEntityType === "SIPOC" && (
                <>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">S (Suppliers)</label>
                    <textarea
                      rows={2}
                      value={crudFormFields.suppliers || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, suppliers: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-sans"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono font-bold uppercase text-gray-500 block">I (Inputs)</label>
                    <textarea
                      rows={2}
                      value={crudFormFields.inputs || ""}
                      onChange={(e) => setCrudFormFields({ ...crudFormFields, inputs: e.target.value })}
                      className="w-full bg-white border border-gray-350 p-2 text-xs font-sans"
                    />
                  </div>
                </>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t pt-4">
              <button
                type="button"
                onClick={() => {
                  setCrudEditingId(null);
                  setCrudFeedback(null);
                }}
                className="px-4 py-1.5 border border-[#1A1A1A] font-mono text-[10px] font-bold uppercase text-gray-900 bg-white hover:bg-gray-100 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-1.5 bg-[#C49746] hover:bg-amber-600 text-white font-mono text-[10px] font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
              >
                💾 Salvar Alterações
              </button>
            </div>
          </form>
        ) : (
          /* TABLE VIEW */
          <div className="overflow-x-auto">
            {crudEntityType === "COMPANIES" && (
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-gray-100 border-b border-gray-300 text-gray-700 font-mono text-[9.5px] uppercase">
                    <th className="py-2.5 px-3.5 font-bold">ID</th>
                    <th className="py-2.5 px-3.5 font-bold">Razão Social / Cadastro</th>
                    <th className="py-2.5 px-3.5 font-bold">CNPJ</th>
                    <th className="py-2.5 px-3.5 font-bold">Setor</th>
                    <th className="py-2.5 px-3.5 font-bold">Módulos</th>
                    <th className="py-2.5 px-3.5 text-right font-bold">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {(companies || []).map((c) => (
                    <tr key={c.id} className="hover:bg-gray-50">
                      <td className="py-2 px-3.5 font-mono text-[10px] text-gray-400">{c.id}</td>
                      <td className="py-2 px-3.5 font-bold text-gray-800">{c.name}</td>
                      <td className="py-2 px-3.5 font-mono">{c.cnpj || "-"}</td>
                      <td className="py-2 px-3.5">{c.industry || "-"}</td>
                      <td className="py-2 px-3.5">
                        <span className="bg-amber-100 text-[#C49746] px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase">
                          {c.enabledModules?.length || 0} Ativos
                        </span>
                      </td>
                      <td className="py-2 px-3.5 text-right space-x-1.5">
                        <button
                          type="button"
                          onClick={() => handleSelectCrudEditItem(c)}
                          className="text-indigo-650 hover:underline font-bold cursor-pointer"
                        >
                          [Editar]
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteCrudItem(c.id)}
                          className="text-red-600 hover:underline font-bold cursor-pointer"
                        >
                          [Excluir]
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {crudEntityType === "PROJECTS" && (
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-gray-100 border-b border-gray-300 text-gray-700 font-mono text-[9.5px] uppercase">
                    <th className="py-2.5 px-3.5 font-bold">ID Projeto</th>
                    <th className="py-2.5 px-3.5 font-bold">Nome do Projeto</th>
                    <th className="py-2.5 px-3.5 font-bold">Empresa PJ</th>
                    <th className="py-2.5 px-3.5 font-bold">Objetivo / Alvo</th>
                    <th className="py-2.5 px-3.5 font-bold">Status</th>
                    <th className="py-2.5 px-3.5 text-right font-bold">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {projects.map((p) => {
                    const bound = (companies || []).find(c => c.id === p.companyId);
                    return (
                      <tr key={p.id} className="hover:bg-gray-50">
                        <td className="py-2 px-3.5 font-mono text-[10px] text-gray-400">{p.id}</td>
                        <td className="py-2 px-3.5 font-bold text-gray-850">{p.name}</td>
                        <td className="py-2 px-3.5 text-gray-550 font-semibold">{bound?.name || p.companyId}</td>
                        <td className="py-2 px-3.5 max-w-[220px] truncate">{p.objective || "-"}</td>
                        <td className="py-2 px-3.5">
                          <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase rounded-sm ${
                            p.status === "Em Andamento"
                              ? "bg-green-150 text-green-800"
                              : "bg-gray-100 text-gray-600"
                          }`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="py-2 px-3.5 text-right space-x-1.5">
                          <button
                            type="button"
                            onClick={() => handleSelectCrudEditItem(p)}
                            className="text-indigo-650 hover:underline font-bold cursor-pointer"
                          >
                            [Editar]
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteCrudItem(p.id)}
                            className="text-red-700 hover:underline font-bold cursor-pointer"
                          >
                            [Excluir]
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}

            {crudEntityType === "STEPS" && (
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-gray-100 border-b border-gray-300 text-gray-700 font-mono text-[9.5px] uppercase">
                    <th className="py-2.5 px-3.5 font-bold">ID</th>
                    <th className="py-2.5 px-3.5 font-bold">Nome do Posto</th>
                    <th className="py-2.5 px-3.5 font-bold">Responsável</th>
                    <th className="py-2.5 px-3.5 font-bold text-center">Nº Recursos</th>
                    <th className="py-2.5 px-3.5 font-bold text-center">Tempo (min)</th>
                    <th className="py-2.5 px-3.5 font-bold text-center">Rendimento / Yield</th>
                    <th className="py-2.5 px-3.5 text-right font-bold">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {steps.map((s) => (
                    <tr key={s.id} className="hover:bg-gray-50">
                      <td className="py-2 px-3.5 font-mono text-[10px] text-gray-400">{s.id}</td>
                      <td className="py-2 px-3.5 font-bold text-gray-800">{s.name}</td>
                      <td className="py-2 px-3.5">{s.resource || "-"}</td>
                      <td className="py-2 px-3.5 text-center font-mono">{s.resourceCount || 1}</td>
                      <td className="py-2 px-3.5 text-center font-mono">{s.processingTime}</td>
                      <td className="py-2 px-3.5 text-center font-mono">{(s.yieldRate * 100).toFixed(0)}%</td>
                      <td className="py-2 px-3.5 text-right space-x-1.5">
                        <button
                          type="button"
                          onClick={() => handleSelectCrudEditItem(s)}
                          className="text-indigo-650 hover:underline font-bold"
                        >
                          [Editar]
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteCrudItem(s.id)}
                          className="text-red-700 hover:underline font-bold"
                        >
                          [Excluir]
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {crudEntityType === "CONTROL_PLANS" && (
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-gray-100 border-b border-gray-300 text-gray-700 font-mono text-[9.5px] uppercase">
                    <th className="py-2.5 px-3.5 font-bold">ID</th>
                    <th className="py-2.5 px-3.5 font-bold">Posto</th>
                    <th className="py-2.5 px-3.5 font-bold">Métrica CEP</th>
                    <th className="py-2.5 px-3.5 font-bold text-center">Target</th>
                    <th className="py-2.5 px-3.5 font-bold text-center">Limites UCL / LCL</th>
                    <th className="py-2.5 px-3.5 text-right font-bold font-mono">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {controlPlans.map((p) => (
                    <tr key={p.id} className="hover:bg-gray-50">
                      <td className="py-2 px-3.5 font-mono text-[10px] text-gray-400">{p.id}</td>
                      <td className="py-2 px-3.5 font-bold text-gray-800">{p.stepName}</td>
                      <td className="py-2 px-3.5 font-mono font-bold text-[#C49746]">{p.metric}</td>
                      <td className="py-2 px-3.5 text-center font-mono">{p.target}</td>
                      <td className="py-2 px-3.5 text-center font-mono text-gray-500">
                        UCL: {p.ucl} / LCL: {p.lcl}
                      </td>
                      <td className="py-2 px-3.5 text-right space-x-1.5">
                        <button
                          type="button"
                          onClick={() => handleSelectCrudEditItem(p)}
                          className="text-indigo-650 hover:underline font-bold"
                        >
                          [Editar]
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteCrudItem(p.id)}
                          className="text-red-700 hover:underline font-bold"
                        >
                          [Excluir]
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* FALLBACK FOR EAM OBJECTS AND OTHERS IN TABLES */}
            {["EA_OBJECTIVES", "EA_PROCESSES", "EA_RESOURCES", "EA_RELATIONSHIPS"].includes(crudEntityType) && (
              <div className="p-6 text-center italic text-gray-400 font-mono text-[11px] bg-slate-50/20">
                A Coleção {crudEntityType} possui {
                  crudEntityType === "EA_OBJECTIVES" ? eaObjectives.length :
                  crudEntityType === "EA_PROCESSES" ? eaProcesses.length :
                  crudEntityType === "EA_RESOURCES" ? eaResources.length :
                  crudEntityType === "EA_RELATIONSHIPS" ? eaRelationships.length : 0
                } itens carregados na governança patrimonial. Todos operam sob sincronia. Selecione um item na lista de edição para alterar ou clique em criar para inserir um novo nodo de arquitetura corporativa.
                
                <div className="flex flex-wrap gap-2 justify-center mt-4">
                  {(crudEntityType === "EA_OBJECTIVES" ? eaObjectives :
                    crudEntityType === "EA_PROCESSES" ? eaProcesses :
                    crudEntityType === "EA_RESOURCES" ? eaResources :
                    eaRelationships).map((item: any) => (
                      <div key={item.id} className="p-3 bg-white border border-[#1A1A1A]/10 text-left min-w-[180px] max-w-xs space-y-1 rounded-sm">
                        <div className="font-mono text-[9px] text-[#C49746] font-bold uppercase">{item.id}</div>
                        <div className="text-gray-950 font-bold text-xs truncate">{item.title || item.name || "Relação Rastreabilidade"}</div>
                        <div className="flex justify-end gap-1.5 pt-1.5 font-mono text-[9px]">
                          <button
                            type="button"
                            onClick={() => handleSelectCrudEditItem(item)}
                            className="text-indigo-750 hover:underline uppercase font-bold"
                          >
                            [Edit]
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteCrudItem(item.id)}
                            className="text-rose-750 hover:underline uppercase font-bold"
                          >
                            [Excl]
                          </button>
                        </div>
                      </div>
                  ))}
                </div>
              </div>
            )}

            {crudEntityType === "CHARTER" && (
              <div className="p-6 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setCrudFormFields(charter || { title: "", problemStatement: "", goal: "", metric: "cycle_time", targetValue: 100 });
                    setCrudEditingId("charter_direct");
                  }}
                  className="px-4 py-2 bg-[#C49746] text-white font-mono text-[10px] font-bold uppercase rounded-sm"
                >
                  🖊️ Editar Project Charter Único Ativo
                </button>
              </div>
            )}

            {crudEntityType === "SIPOC" && (
              <div className="p-6 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setCrudFormFields(sipoc || { suppliers: "", inputs: "", processDescription: "", outputs: "", customers: "" });
                    setCrudEditingId("sipoc_direct");
                  }}
                  className="px-4 py-2 bg-indigo-700 text-white font-mono text-[10px] font-bold uppercase rounded-sm"
                >
                  🖊️ Editar SIPOC Único Ativo
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
