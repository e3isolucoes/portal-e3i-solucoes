import React from "react";
import { ShieldAlert, ArrowLeft, Sliders, Lock, HelpCircle } from "lucide-react";

interface AccessDeniedBlockProps {
  moduleName: string;
  userRole: string;
  requiredRoles: string[];
  onNavigateToAdmin: () => void;
}

export default function AccessDeniedBlock({
  moduleName,
  userRole,
  requiredRoles,
  onNavigateToAdmin,
}: AccessDeniedBlockProps) {
  return (
    <div className="border border-red-200 bg-[#FAF9F6] p-8 md:p-12 space-y-8 max-w-2xl mx-auto my-12 animate-fade-in text-left shadow-[4px_4px_0px_0px_rgba(239,68,68,1)]" id="access-denied-view">
      
      {/* Upper Status Marker */}
      <div className="border-b border-red-200 pb-4">
        <span className="text-[9px] font-mono font-bold bg-red-600 text-white px-2.5 py-0.5 uppercase tracking-widest inline-block">
          🚫 Controle de Segurança Corporativa
        </span>
        <h4 className="text-2xl font-serif text-gray-950 mt-2 leading-tight flex items-center gap-2">
          <Lock className="text-red-650 shrink-0" size={24} />
          Módulo Bloqueado: {moduleName}
        </h4>
        <p className="text-xs text-red-700/80 font-sans mt-1">
          Seu cargo atual não possui permissão para visualizar e executar esta ferramenta.
        </p>
      </div>

      {/* Profile and Limitation Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        <div className="bg-white p-4 border border-gray-200 space-y-1">
          <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block">Sua Credencial Atual</span>
          <strong className="text-base font-serif text-red-600 block">
            👤 {userRole || "Visitante Leigo"}
          </strong>
          <p className="text-[10px] text-gray-500 leading-tight pt-1">
            Seu perfil está classificado sob regime de restrição padrão de auditoria.
          </p>
        </div>

        <div className="bg-white p-4 border border-gray-200 space-y-1">
          <span className="text-[8.5px] uppercase font-bold text-gray-400 font-mono block font-sans">Níveis de Acesso Autorizados</span>
          <strong className="text-base font-serif text-gray-950 block">
            🔑 {requiredRoles.join(" ou ")}
          </strong>
          <p className="text-[10px] text-gray-500 leading-tight pt-1">
            Requisição automática negada pelo sistema de governança patrimonial.
          </p>
        </div>

      </div>

      {/* Operational Explanation */}
      <div className="bg-amber-50/50 p-4 border border-amber-600/20 text-[11px] leading-relaxed text-gray-700 font-sans">
        <div className="flex gap-2 items-start">
          <HelpCircle size={15} className="text-amber-800 shrink-0 mt-0.5" />
          <div>
            <strong className="text-amber-900 block font-bold mb-0.5">Por que isso acontece?</strong>
            A metodologia de Governança LSS restringe recursos analíticos avançados para evitar execuções de otimização estocástica sem a devida acentuação de certificação Green/Black Belt ou controle de administrador. No entanto, você pode ajustar as regras de permissão ou simular cargos superiores no painel de administração!
          </div>
        </div>
      </div>

      {/* Dynamic CTA Row */}
      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <button
          onClick={onNavigateToAdmin}
          className="flex-1 bg-[#1A1A1A] hover:bg-black text-white py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider transition-all shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] border border-transparent flex items-center justify-center gap-2 cursor-pointer"
        >
          <Sliders size={13} className="text-white" />
          Acessar Admin do Contrato (Editar Regras)
        </button>
      </div>

    </div>
  );
}
