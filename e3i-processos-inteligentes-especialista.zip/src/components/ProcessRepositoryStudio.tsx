import React, { useState, useMemo } from "react";
import { 
  Search, 
  Database, 
  BookOpen, 
  ArrowRight, 
  ChevronRight, 
  Layers, 
  Settings, 
  Activity, 
  FileText, 
  CheckCircle2, 
  Plus, 
  Printer, 
  Download, 
  LayoutGrid, 
  ListFilter, 
  Briefcase, 
  Sparkles, 
  Check, 
  X,
  PlusCircle,
  FileCheck2,
  Bookmark
} from "lucide-react";
import { ProcessStep, Sipoc, ControlPlan } from "../types";
import { PROCESS_TEMPLATES, ProcessTemplate } from "../presets";
import VisualProcessMapper from "./VisualProcessMapper";
import { calculateProcessMetrics } from "../utils";
import WipKanbanBoard from "./WipKanbanBoard";

interface ProcessRepositoryStudioProps {
  activeTemplateId: string;
  onSelectTemplate: (templateId: string) => void;
  // Callback to add a newly created template to the application system
  onRegisterCustomTemplate?: (newTemplate: ProcessTemplate) => void;
  // The dynamically updated list of templates (fallback to presets)
  allTemplates?: ProcessTemplate[];
}

export default function ProcessRepositoryStudio({ 
  activeTemplateId, 
  onSelectTemplate,
  onRegisterCustomTemplate,
  allTemplates = PROCESS_TEMPLATES 
}: ProcessRepositoryStudioProps) {
  
  // States
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("TODOS");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(activeTemplateId);
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  
  const [workbenchView, setWorkbenchView] = useState<"BLUEPRINT" | "KANBAN">("BLUEPRINT");
  
  // State for creating a brand new process template dynamically
  const [newName, setNewName] = useState("");
  const [newCategory, setNewCategory] = useState<ProcessTemplate["category"]>("servicos");
  const [newArrivalRate, setNewArrivalRate] = useState<number>(12);
  const [newUnitLabel, setNewUnitLabel] = useState("transação");
  const [newUnitLabelPlural, setNewUnitLabelPlural] = useState("transações");
  
  // Starter steps for custom process
  const [newSteps, setNewSteps] = useState<{ name: string; resource: string; time: number; yield: number }[]>([
    { name: "Triagem e Recepção de Dados", resource: "Analista de Suporte", time: 5.0, yield: 0.98 },
    { name: "Processamento e Execução Principal", resource: "Analista Sênior", time: 10.0, yield: 0.95 },
    { name: "Homologação e Controle de Qualidade", resource: "Supervisor Técnico", time: 4.0, yield: 0.99 }
  ]);
  const [newStepName, setNewStepName] = useState("");
  const [newStepResource, setNewStepResource] = useState("");
  const [newStepTime, setNewStepTime] = useState(5);
  const [newStepYield, setNewStepYield] = useState(98);

  // SIPOC custom fields
  const [sipocSuppliers, setSipocSuppliers] = useState("Clientes, Bancos de Dados legados");
  const [sipocInputs, setSipocInputs] = useState("Formulários de Solicitação, Arquivos de Entrada ERP");
  const [sipocOutputs, setSipocOutputs] = useState("Processos liquidados, comprovantes emitidos");
  const [sipocCustomers, setSipocCustomers] = useState("Clientes finais, comitê de governança corporativa");

  // Get active selected template data
  const activeTemplate = useMemo(() => {
    return allTemplates.find(t => t.id === selectedTemplateId) || allTemplates[0];
  }, [allTemplates, selectedTemplateId]);

  // Categories lookup
  const categories = useMemo(() => {
    const cats = new Set<string>();
    allTemplates.forEach(t => {
      if (t.category) cats.add(t.category);
    });
    return ["TODOS", ...Array.from(cats)];
  }, [allTemplates]);

  // Filter templates list based on search and selected category
  const filteredTemplates = useMemo(() => {
    return allTemplates.filter(t => {
      const matchesCategory = selectedCategory === "TODOS" || t.category === selectedCategory;
      const matchesSearch = 
        t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.steps.some(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.resource.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (t.sipoc?.processDescription && t.sipoc.processDescription.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [allTemplates, selectedCategory, searchTerm]);

  // Global Metadata counters for index searching
  const repositoryStats = useMemo(() => {
    let totalStepsCount = 0;
    let totalSopsCount = 0;
    let uniqueRoles = new Set<string>();
    let totalAutomationsCount = 0;

    allTemplates.forEach(t => {
      t.steps.forEach(s => {
        totalStepsCount++;
        uniqueRoles.add(s.resource);
        if (s.supportDocuments) {
          totalSopsCount += s.supportDocuments.length;
        }
        if (s.automations) {
          totalAutomationsCount += s.automations.length;
        }
      });
    });

    return {
      totalTemplates: allTemplates.length,
      totalSteps: totalStepsCount,
      totalSops: totalSopsCount,
      uniqueRolesCount: uniqueRoles.size,
      totalAutomations: totalAutomationsCount
    };
  }, [allTemplates]);

  // Quick categories icon map
  const getCategoryEmoji = (cat: string) => {
    switch (cat.toLowerCase()) {
      case "manufatura": return "🏭";
      case "financeiro": return "💰";
      case "contabil": return "⚖️";
      case "fiscal": return "📑";
      case "servicos": return "👥";
      case "comercio": return "🛒";
      case "logistica": return "📦";
      case "tecnologia": return "💻";
      case "saude": return "🏥";
      case "rh": return "👤";
      default: return "📄";
    }
  };

  // Add a step inside the new process builder
  const handleAddStepToNew = () => {
    if (!newStepName || !newStepResource) {
      alert("Por favor, preencha o Nome da Etapa e o Recurso Responsável do Posto.");
      return;
    }
    setNewSteps(prev => [
      ...prev,
      {
        name: newStepName,
        resource: newStepResource,
        time: Number(newStepTime),
        yield: Number(newStepYield) / 100
      }
    ]);
    setNewStepName("");
    setNewStepResource("");
    setNewStepTime(5);
    setNewStepYield(98);
  };

  // Remove a step inside the new process builder
  const handleRemoveStepFromNew = (idx: number) => {
    setNewSteps(prev => prev.filter((_, i) => i !== idx));
  };

  // Submits the new template to the parent local state
  const handleSaveCustomProcess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      alert("Defina o nome de identificação principal do processo.");
      return;
    }
    if (newSteps.length === 0) {
      alert("Cadastre pelo menos 1 (uma) etapa operacional com tempos estocásticos calibrados.");
      return;
    }

    // Adapt steps structure
    const mappedSteps: ProcessStep[] = newSteps.map((s, i) => ({
      id: `step-${i + 1}-${Date.now()}`,
      name: s.name,
      resource: s.resource,
      resourceCount: 1,
      processingTime: s.time,
      standardDeviation: Number((s.time * 0.2).toFixed(2)), // 20% default deviation
      yieldRate: s.yield,
      setupTime: 0,
      description: `Operação estocástica do fluxo corporativo de ${newName}.`,
      requiredInputs: [sipocInputs],
      stepInstructions: [
        "Preparar workbench antiestático ou arquivo de dados de entrada.",
        "Seguir instrução técnica padronizada SOP-DEV.",
        "Executar checagem dupla dos indicadores de não-conformidade."
      ],
      supportDocuments: [
        { name: `SOP-${s.name.substring(0,3).toUpperCase()}-001`, code: `SOP-${s.name.substring(0,3).toUpperCase()}-001`, type: "SOP", rev: "1.0" }
      ],
      automations: [
        { title: "Verificador Rápido Sintático", type: "RPA Software", status: "proposed", description: "Otimização prevista para reduzir tempo de ciclo operacional." }
      ]
    }));

    // Generate charter
    const charter = {
      title: `Redução de Variabilidade e Lead Time: ${newName}`,
      problemStatement: `O processo de ${newName} necessita de estabilização contínua das atividades nos postos para mitigar gargalos operacionais acumulados na capabilidade diária.`,
      goal: `Reduzir o tempo de atravessamento médio, diminuindo falhas com foco na maximização do Nível Sigma e FPP.`,
      metric: "cycle_time" as const,
      targetValue: Number((mappedSteps.reduce((acc, curr) => acc + curr.processingTime, 0) * 0.7).toFixed(1))
    };

    // Generate control plans
    const controlPlans: ControlPlan[] = mappedSteps.map(s => ({
      id: `plan-${s.id}`,
      stepName: s.name,
      metric: "Tempo de Processamento",
      ucl: Number((s.processingTime * 1.5).toFixed(1)),
      lcl: Number((s.processingTime * 0.5).toFixed(1)),
      target: s.processingTime,
      frequency: "Por Lote",
      responsible: s.resource,
      reactionPlan: "Acionar supervisor Black Belt para balanceamento de gargalo."
    }));

    const newTemplate: ProcessTemplate = {
      id: `custom-tpl-${Date.now()}`,
      name: newName,
      category: newCategory,
      icon: getCategoryEmoji(newCategory),
      arrivalRate: Number(newArrivalRate),
      unitLabel: newUnitLabel,
      unitLabelPlural: newUnitLabelPlural,
      steps: mappedSteps,
      charter,
      sipoc: {
        suppliers: sipocSuppliers,
        inputs: sipocInputs,
        processDescription: mappedSteps.map(s => s.name).join(" -> "),
        outputs: sipocOutputs,
        customers: sipocCustomers
      },
      controlPlans
    };

    if (onRegisterCustomTemplate) {
      onRegisterCustomTemplate(newTemplate);
    }
    
    // Select the newly registered template
    setSelectedTemplateId(newTemplate.id);
    setIsAddingNew(false);
    
    // Clear states
    setNewName("");
    setNewSteps([
      { name: "Triagem e Recepção de Dados", resource: "Analista de Suporte", time: 5.0, yield: 0.98 },
      { name: "Processamento e Execução Principal", resource: "Analista Sênior", time: 10.0, yield: 0.95 },
      { name: "Homologação e Controle de Qualidade", resource: "Supervisor Técnico", time: 4.0, yield: 0.99 }
    ]);
  };

  return (
    <div id="process-repository-studio" className="bg-white border-4 border-[#1A1A1A] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden text-[#1A1A1A]">
      
      {/* Header section with Editorial look */}
      <div className="bg-[#1D4ED8] text-white p-5 border-b-4 border-[#1A1A1A] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#FAF8F5] text-[#1D4ED8] font-mono text-[10px] uppercase font-black rounded-xs flex items-center gap-1">
            <Database size={14} className="animate-pulse" />
            REPOSITÓRIO CENTRAL
          </div>
          <div>
            <span className="text-[10px] text-blue-200 uppercase font-mono tracking-widest block font-bold">Process Architecture &amp; Integration Hub</span>
            <h4 className="font-serif text-xl font-black mt-0.5">
              Base de Processos Integrada, Indexada &amp; Localizável
            </h4>
          </div>
        </div>
        <button
          onClick={() => setIsAddingNew(!isAddingNew)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[11px] font-bold tracking-wider py-2 px-4 border-2 border-white/20 shadow-xs flex items-center gap-1.5 transition-all text-center shrink-0"
        >
          {isAddingNew ? (
            <>Fechar Formulário ×</>
          ) : (
            <>
              <Plus size={14} /> Cadastrar Nova Estrutura
            </>
          )}
        </button>
      </div>

      {/* Index Metrics Dashboard Bar (Bússola de Processos) */}
      <div className="bg-[#FAF9F6] border-b-2 border-[#1A1A1A] p-4 text-xs font-mono grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
        <div className="border-r border-[#1A1A1A]/10 last:border-0 md:pr-2">
          <span className="text-gray-500 uppercase text-[9px] block">Modelos Disponíveis</span>
          <span className="text-lg font-serif italic text-[#1D4ED8] font-black">{repositoryStats.totalTemplates} de Negócio</span>
        </div>
        <div className="border-r border-[#1A1A1A]/10 last:border-0 md:pr-2">
          <span className="text-gray-500 uppercase text-[9px] block">Postos de Trabalho</span>
          <span className="text-lg font-serif italic text-amber-700 font-black">{repositoryStats.totalSteps} Etapas</span>
        </div>
        <div className="border-r border-[#1A1A1A]/10 last:border-0 md:pr-2">
          <span className="text-gray-500 uppercase text-[9px] block">Total SOPs / POPs</span>
          <span className="text-lg font-serif italic text-indigo-700 font-black">{repositoryStats.totalSops} Manuais</span>
        </div>
        <div className="border-r border-[#1A1A1A]/10 last:border-0 md:pr-2">
          <span className="text-gray-500 uppercase text-[9px] block">Papéis e Responsáveis Mapeados</span>
          <span className="text-lg font-serif italic text-emerald-700 font-black">{repositoryStats.uniqueRolesCount} Funções</span>
        </div>
        <div className="last:border-0">
          <span className="text-gray-500 uppercase text-[9px] block">Otimizações RPAs</span>
          <span className="text-lg font-serif italic text-purple-700 font-black">{repositoryStats.totalAutomations} Cadastradas</span>
        </div>
      </div>

      {isAddingNew ? (
        /* DYNAMIC FORM TO CREATE A BRAND NEW PROCESS OPERATIONAL TEMPLATE */
        <form onSubmit={handleSaveCustomProcess} className="p-5 md:p-6 bg-amber-50/10 border-b-2 border-dashed border-[#1A1A1A] text-left space-y-6 animate-fade-in">
          <div className="border-b border-gray-200 pb-3 flex justify-between items-center">
            <div>
              <h5 className="font-serif font-black text-sm text-[#1A1A1A] uppercase tracking-tight flex items-center gap-1">
                <PlusCircle size={16} className="text-emerald-600" />
                Modelador e Cadastro de Processo Customizado Estocástico
              </h5>
              <p className="text-[10.5px] text-gray-500">
                Monte fluxos operacionais com tempos estocásticos calibrados para simulação contínua na sua arquitetura governada.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="font-mono text-[9px] border-2 border-gray-400 px-2 py-0.5"
            >
              CANCELAR ×
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 space-y-1">
              <label className="text-[10px] font-mono font-bold uppercase text-gray-500">Nome Oficial do Processo <span className="text-red-500">*</span></label>
              <input
                type="text"
                required
                placeholder="Ex: Conciliação de Contas Integrada, Onboarding de Talentos..."
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold uppercase text-gray-500">Área de Atuação / Categoria</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              >
                <option value="manufatura">Manufatura Tradicional</option>
                <option value="financeiro">Finanças Corporativas</option>
                <option value="contabil">Contabilidade &amp; Conciliações</option>
                <option value="fiscal">Auditoria Fiscal</option>
                <option value="servicos">Serviços Executivos / Administrativos</option>
                <option value="comercio">Comércio e Vendas B2B/B2C</option>
                <option value="logistica">Logística &amp; Supply Chain</option>
                <option value="tecnologia">DevOps &amp; Infraestrutura Tecnológica</option>
                <option value="saude">Saúde &amp; Clinical Operations</option>
                <option value="rh">Recursos Humanos / D.P.</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold uppercase text-gray-500">Demanda de Chegada (unidades/hora)</label>
              <input
                type="number"
                min="0.5"
                step="0.1"
                required
                value={newArrivalRate}
                onChange={(e) => setNewArrivalRate(Number(e.target.value))}
                className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold uppercase text-gray-500">Sufixo Unitário (Singular)</label>
              <input
                type="text"
                placeholder="Ex: fatura, placa, dossiê, chamado"
                value={newUnitLabel}
                onChange={(e) => setNewUnitLabel(e.target.value)}
                className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold uppercase text-gray-500">Sufixo Unitário (Plural)</label>
              <input
                type="text"
                placeholder="Ex: faturas, placas, dossiês, chamados"
                value={newUnitLabelPlural}
                onChange={(e) => setNewUnitLabelPlural(e.target.value)}
                className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs focus:outline-none"
              />
            </div>
            <div className="space-y-1 bg-yellow-50 p-2.5 border border-yellow-250 text-[10px] leading-relaxed">
              <span className="font-bold text-amber-800 uppercase block mb-0.5">Nota de Mapeamento:</span>
              Mapeie idealmente os tempos em minutos decimais (Ex: 1.5 minutos equivalem a 1 min e 30 seg). O sistema calculará a variabilidade com base em Distribuição Normal Estocástica de forma estrita.
            </div>
          </div>

          <div className="border border-gray-250 bg-white p-4 space-y-4">
            <span className="text-[10px] font-mono font-extrabold text-[#1D4ED8] uppercase block">
              🔧 Grade Sequencial de Postos de Atividades ({newSteps.length} etapas calibradas)
            </span>

            {/* Steps Listing */}
            {newSteps.length > 0 ? (
              <div className="border border-gray-150 divide-y divide-gray-100 font-mono text-[11px]">
                {newSteps.map((step, idx) => (
                  <div key={idx} className="p-2.5 flex items-center justify-between hover:bg-gray-50">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-400 font-bold">0{idx + 1}.</span>
                      <strong className="text-gray-900">{step.name}</strong>
                      <span className="text-gray-500">| Executor: {step.resource}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs font-bold font-serif text-[#1D4ED8]">
                      <span>{step.time.toFixed(1)}m</span>
                      <span className="text-emerald-600">Rendimento: {(step.yield * 100).toFixed(0)}%</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveStepFromNew(idx)}
                        className="text-red-600 hover:text-red-800 font-mono text-[10px] border border-red-200 px-1.5 py-0.2 rounded hover:bg-red-50 cursor-pointer"
                      >
                        Remover ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-red-600 font-bold text-xs italic">Atenção! Nenhuma etapa operacional definida para este processo. Adicione atividades na gaveta de calibragem abaixo:</p>
            )}

            {/* Mini Add-Step Workspace */}
            <div className="bg-gray-50 p-3.5 border border-gray-200 grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-4 space-y-1">
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase block">Nome do Posto de Trabalho</span>
                <input
                  type="text"
                  placeholder="Ex: Auditoria de Assinatura, Conferência Fiscal..."
                  value={newStepName}
                  onChange={(e) => setNewStepName(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>

              <div className="md:col-span-3 space-y-1">
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase block">Recurso Dono (Função/Papel)</span>
                <input
                  type="text"
                  placeholder="Ex: Analista Fiscal, Robô RPA..."
                  value={newStepResource}
                  onChange={(e) => setNewStepResource(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>

              <div className="md:col-span-2 space-y-1">
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase block">Tempo Médio (min)</span>
                <input
                  type="number"
                  min="0.1"
                  step="0.1"
                  value={newStepTime}
                  onChange={(e) => setNewStepTime(Number(e.target.value))}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>

              <div className="md:col-span-1.5 space-y-1">
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase block">Qualidade (%)</span>
                <input
                  type="number"
                  min="50"
                  max="100"
                  value={newStepYield}
                  onChange={(e) => setNewStepYield(Number(e.target.value))}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>

              <div className="md:col-span-1.5">
                <button
                  type="button"
                  onClick={handleAddStepToNew}
                  className="w-full bg-[#1D4ED8] hover:bg-blue-850 text-white font-mono text-[9px] font-bold py-2 border border-blue-700 flex items-center justify-center gap-1 cursor-pointer transition"
                >
                  <Plus size={12} /> INSERIR
                </button>
              </div>
            </div>
          </div>

          {/* Model SIPOC variables linked directly */}
          <div className="p-4 bg-gray-50 border border-gray-200 space-y-3.5 text-xs">
            <span className="text-[#1D4ED8] font-mono font-bold uppercase text-[10px] tracking-wide block">🎯 Matriz SIPOC de Entrada &amp; Saída Coesiva</span>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-gray-500 uppercase">Fornecedores (S - Suppliers)</label>
                <input
                  type="text"
                  value={sipocSuppliers}
                  onChange={(e) => setSipocSuppliers(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-gray-500 uppercase">Insumos e Entradas (I - Inputs)</label>
                <input
                  type="text"
                  value={sipocInputs}
                  onChange={(e) => setSipocInputs(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-gray-500 uppercase">Entregáveis e Saídas (O - Outputs)</label>
                <input
                  type="text"
                  value={sipocOutputs}
                  onChange={(e) => setSipocOutputs(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-gray-500 uppercase">Clientes e Beneficiários (C - Customers)</label>
                <input
                  type="text"
                  value={sipocCustomers}
                  onChange={(e) => setSipocCustomers(e.target.value)}
                  className="w-full bg-white border border-gray-300 p-1.5 text-xs focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2.5 border-t border-gray-200 pt-4">
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="bg-gray-100 hover:bg-gray-200 border-2 border-[#1A1A1A] py-1.5 px-4 text-xs font-mono font-bold cursor-pointer"
            >
              Cancelar e Descartar
            </button>
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-xs font-bold py-1.5 px-6 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] transition cursor-pointer"
            >
              Confirmar &amp; Homologar no Repositório ✔️
            </button>
          </div>
        </form>
      ) : null}

      {/* Main Exploration Split Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[550px]" id="repository-workbench">
        
        {/* LEFT COLUMN: Search Index & Filtered Process List */}
        <div className="lg:col-span-5 border-r-2 border-[#1A1A1A] p-5 md:p-6 bg-[#FAF9F6] flex flex-col justify-between space-y-4">
          
          <div className="space-y-4">
            
            {/* Search Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-mono font-bold text-gray-700">
                <span className="flex items-center gap-1">🔍 Pesquisa de Termos &amp; Atividades</span>
                {searchTerm && (
                  <button 
                    onClick={() => setSearchTerm("")}
                    className="text-red-650 hover:underline cursor-pointer text-[9.5px]"
                  >
                    limpar ×
                  </button>
                )}
              </div>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3.5 text-[#1D4ED8]" />
                <input
                  type="text"
                  placeholder="Pesquise por palavra-chave (ex: triagem, caixa, solda, suporte)"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-white border-2 border-[#1A1A1A] p-2.5 pl-9 text-xs font-mono font-bold focus:ring-2 focus:ring-[#1D4ED8] focus:outline-none placeholder:text-gray-400 text-slate-800 shadow-[2px_2px_0px_rgba(26,26,26,1)] transition-all"
                />
              </div>
              <div className="flex flex-wrap gap-1 text-[9px] font-mono text-gray-500 mt-1">
                <span>Sugestões:</span>
                <button type="button" onClick={() => setSearchTerm("atendimento")} className="hover:underline text-[#1D4ED8] cursor-pointer">atendimento</button>
                <span>•</span>
                <button type="button" onClick={() => setSearchTerm("inspeção")} className="hover:underline text-[#1D4ED8] cursor-pointer">inspeção</button>
                <span>•</span>
                <button type="button" onClick={() => setSearchTerm("caixa")} className="hover:underline text-[#1D4ED8] cursor-pointer">caixa</button>
                <span>•</span>
                <button type="button" onClick={() => setSearchTerm("rpa")} className="hover:underline text-[#1D4ED8] cursor-pointer">rpa</button>
              </div>
            </div>

            {/* Structured Category Pills to facilitate quick location */}
            <div className="flex flex-wrap gap-1.5 pb-2" id="category-scroller">
              {categories.map((cat) => {
                const isActive = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`p-1.5 px-3 rounded-none font-mono text-[9px] uppercase font-bold tracking-wider transition-all border ${
                      isActive 
                        ? "bg-[#1D4ED8] text-white border-[#1D4ED8] shadow-[1px_1px_0px_0px_rgba(26,26,26,1)] font-extrabold" 
                        : "bg-white border-gray-200 text-gray-600 hover:border-gray-400 hover:text-gray-900"
                    }`}
                  >
                    {cat === "TODOS" ? "📁 " : getCategoryEmoji(cat)} {cat}
                  </button>
                );
              })}
            </div>

            {/* Index Checklist List of process cards */}
            <div className="space-y-2 max-h-[460px] overflow-y-auto pr-2" id="process-index-list">
              {filteredTemplates.length > 0 ? (
                filteredTemplates.map((tpl) => {
                  const isSelected = selectedTemplateId === tpl.id;
                  const isActiveOnSimulator = activeTemplateId === tpl.id;
                  
                  return (
                    <div
                      key={tpl.id}
                      onClick={() => setSelectedTemplateId(tpl.id)}
                      className={`border-2 p-3 transition-all cursor-pointer select-none text-left relative ${
                        isSelected 
                          ? "bg-white border-[#1D4ED8]" 
                          : "bg-white border-transparent hover:border-gray-300"
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#1D4ED8]"></div>
                      )}
                      
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[8px] bg-gray-100 text-gray-500 px-1 py-0.2 rounded-xs font-mono font-extrabold uppercase uppercase">
                              {getCategoryEmoji(tpl.category)} {tpl.category}
                            </span>
                            {isActiveOnSimulator && (
                              <span className="text-[7.5px] bg-emerald-500 text-white px-1.5 py-0.2 rounded font-black font-mono flex items-center gap-0.5">
                                <span className="w-1 h-1 bg-white rounded-full animate-ping"></span> ATIVO NA SIMULAÇÃO
                              </span>
                            )}
                          </div>
                          
                          <h6 className="font-sans font-black text-[12px] text-gray-950 flex items-center gap-1">
                            {tpl.name}
                          </h6>
                          <p className="text-[10px] text-gray-500 leading-tight">
                            Composto por <strong className="text-[#1D4ED8]">{tpl.steps.length} postos sequenciais</strong> de atravessamento.
                          </p>
                        </div>

                        <ChevronRight size={14} className="text-gray-400 shrink-0 self-center" />
                      </div>

                      {/* Brief parameters inside the card */}
                      <div className="mt-2.5 pt-2 border-t border-dashed border-gray-100 flex items-center justify-between text-[8px] font-mono text-gray-400">
                        <span>Chegada: P={tpl.arrivalRate}/h</span>
                        <span>Métrica: Lead Time {tpl.charter.targetValue || 20}m</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="bg-white border border-gray-200 p-8 text-center space-y-1.5">
                  <span className="text-lg block">🔍 无</span>
                  <p className="text-xs text-gray-500 font-bold font-sans">Nenhum processo corporativo indexado atende aos critérios de pesquisa informados.</p>
                </div>
              )}
            </div>

          </div>

          {/* Location Tips Info Block */}
          <div className="bg-blue-50/50 p-4 border border-blue-150 text-xs space-y-2">
            <h6 className="font-serif font-black text-xs text-blue-900 flex items-center gap-1 flex-wrap">
              <Sparkles size={13} className="text-blue-600 animate-pulse" />
              Como funciona o Repositório de Modelos?
            </h6>
            <div className="font-sans leading-relaxed text-blue-800 space-y-1.5 text-[11px]">
              <p>
                1. <strong>Localize</strong> a estrutura de processo de negócios correspondente ao seu setor na barra lateral filtrável.
              </p>
              <p>
                2. <strong>Estude</strong> o mapeamento técnico e procedimental de suas etapas, documentos SOP anexos, responsáveis corporativos e controles limite de variação.
              </p>
              <p>
                3. <strong>Clique</strong> no botão de vinculação operacional para carregar a modelagem como o motor ativo na bancada de simulações e rituais DMAIC de qualidade.
              </p>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Interactive Deep-Dive Explorer & Operational Blueprint View */}
        <div className="lg:col-span-7 p-5 md:p-6 space-y-6 flex flex-col justify-between">
          
          <div className="space-y-6 text-left">
            
            {/* Template Header Detail */}
            <div className="border-b-2 border-gray-150 pb-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#1D4ED8] bg-blue-50 px-2 py-0.5 border border-blue-200">
                    📂 Detalhador de Dossiê de Atividades
                  </span>
                  <span className="text-[9px] font-mono text-gray-400">ID: {activeTemplate.id}</span>
                </div>
                
                <h3 className="font-serif text-2xl font-black text-gray-950 flex items-center gap-2">
                  <span>{getCategoryEmoji(activeTemplate.category)}</span>
                  {activeTemplate.name}
                </h3>
              </div>

              {/* Action Linkage to Bench Workspace */}
              <button
                onClick={() => {
                  onSelectTemplate(activeTemplate.id);
                  alert(`Sucesso! O processo "${activeTemplate.name}" foi selecionado como foco operacional ativo. As etapas estão integradas na bancada e prontas para simulação e rituais de otimização.`);
                }}
                className={`py-2 px-4 text-xs font-mono font-bold uppercase tracking-wider border-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTemplateId === activeTemplate.id
                    ? "bg-emerald-50 text-emerald-800 border-emerald-500 cursor-not-allowed"
                    : "bg-[#1D4ED8] text-white border-[#1D4ED8] hover:bg-blue-800 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] hover:translate-x-[-1px] hover:translate-y-[-1px]"
                }`}
                disabled={activeTemplateId === activeTemplate.id}
              >
                {activeTemplateId === activeTemplate.id ? (
                  <>✓ Vinculado Operacionalmente</>
                ) : (
                  <>
                    <ArrowRight size={13} className="animate-pulse" /> Sincronizar com Bancada
                  </>
                )}
              </button>
            </div>

            <div className="flex border-b border-gray-200 gap-4 mt-2">
              <button 
                onClick={() => setWorkbenchView("BLUEPRINT")}
                className={`pb-2 text-[10px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${workbenchView === "BLUEPRINT" ? "border-b-2 border-[#1D4ED8] text-[#1D4ED8]" : "text-gray-500 hover:text-gray-900"}`}
              >
                Blueprint & SIPOC
              </button>
              <button 
                onClick={() => setWorkbenchView("KANBAN")}
                className={`pb-2 text-[10px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${workbenchView === "KANBAN" ? "border-b-2 border-indigo-600 text-indigo-700" : "text-gray-500 hover:text-gray-900"}`}
              >
                Kanban de Lotes (WIP)
              </button>
            </div>

            {workbenchView === "BLUEPRINT" ? (
              <>
                {/* Structured SIPOC Capa Section */}
                <div className="bg-[#FAF9F6] border border-gray-250 p-4 space-y-3">
              <span className="text-[9px] font-mono font-extrabold text-blue-800 uppercase tracking-widest block border-b border-gray-200 pb-1">
                📋 Visão Consolidada SIPOC (Design de Capa)
              </span>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center font-mono">
                <div className="bg-white p-2 border border-gray-150">
                  <span className="text-[8px] font-black text-amber-800 uppercase block">Suppliers</span>
                  <p className="text-[10.5px] leading-tight text-gray-700 mt-1 scroll-smooth max-h-[60px] overflow-y-auto">{activeTemplate.sipoc?.suppliers || "Almoxarifado, Fornecedores"}</p>
                </div>
                <div className="bg-white p-2 border border-gray-150">
                  <span className="text-[8px] font-black text-amber-800 uppercase block">Inputs</span>
                  <p className="text-[10.5px] leading-tight text-gray-700 mt-1 scroll-smooth max-h-[60px] overflow-y-auto">{activeTemplate.sipoc?.inputs || "Insumos, dados bruto, logs"}</p>
                </div>
                <div className="bg-white p-2 border border-gray-150">
                  <span className="text-[8px] font-black text-amber-800 uppercase block">Outputs</span>
                  <p className="text-[10.5px] leading-tight text-gray-700 mt-1 scroll-smooth max-h-[60px] overflow-y-auto">{activeTemplate.sipoc?.outputs || "Produtos finais, registros"}</p>
                </div>
                <div className="bg-white p-2 border border-gray-150">
                  <span className="text-[8px] font-black text-amber-800 uppercase block">Customers</span>
                  <p className="text-[10.5px] leading-tight text-gray-700 mt-1 scroll-smooth max-h-[60px] overflow-y-auto">{activeTemplate.sipoc?.customers || "Comitês, Clientes"}</p>
                </div>
              </div>
            </div>

            {/* Mapped Sequential Activity Chain (Process Map) */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono font-bold text-gray-500 uppercase tracking-wider">
                  Postos de Trabalho Encadeados ({activeTemplate.steps.length} atividades mapeadas)
                </span>
                <span className="text-[9.5px] font-mono text-gray-400">Rendimento de Qualidade Rolada FPP Média</span>
              </div>

              {/* Sequential Node Track List */}
              <div className="space-y-2 max-h-[290px] overflow-y-auto pr-2">
                {activeTemplate.steps.map((step, idx) => {
                  return (
                    <div 
                      key={step.id} 
                      className="border border-gray-200 bg-white p-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:border-blue-200 hover:bg-blue-50/5 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className="font-mono text-xs font-black bg-[#1D4ED8] text-white w-6 h-6 flex items-center justify-center rounded-none shrink-0">
                          {idx + 1}
                        </div>
                        <div>
                          <h6 className="font-sans font-bold text-gray-950 text-xs">{step.name}</h6>
                          <div className="flex items-center gap-2 mt-0.5 font-mono text-[9px] text-gray-500 flex-wrap">
                            <span className="bg-gray-100 text-gray-600 px-1 py-0.1 border border-gray-200">Resp: {step.resource}</span>
                            <span>•</span>
                            <span>Tempo de Processamento (Ts): <strong>{step.processingTime} min</strong></span>
                            <span>•</span>
                            <span>Estabilidade (σp): ±{step.standardDeviation}m</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end md:self-center font-mono text-[10px]">
                        <div className="text-right">
                          <span className="text-[8px] text-gray-400 block uppercase">Qualidade</span>
                          <span className="text-emerald-700 font-bold">{(step.yieldRate * 100).toFixed(0)}% FPP</span>
                        </div>
                        
                        {/* SOP Quick badge */}
                        {step.supportDocuments && step.supportDocuments.length > 0 && (
                          <div className="border border-indigo-200 bg-indigo-50 text-indigo-800 px-2 py-1 flex items-center gap-1 shrink-0" title="Contém norma SOP formalizada para auditoria">
                            <Bookmark size={9} />
                            <span className="text-[8.5px] font-extrabold uppercase">{step.supportDocuments[0].code}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>

            {/* Strategic Target Profile (Charter) */}
            <div className="border-t border-dashed border-gray-200 pt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
              <div className="bg-gray-50 p-3 flex flex-col justify-between">
                <div>
                  <span className="text-[8.5px] font-mono font-black text-gray-400 block uppercase">CONTEÚDO E MANUAL OPERACIONAL DE APOIO (SOP/POP)</span>
                  <p className="text-[10.5px] text-gray-600 leading-normal mt-1.5">
                    As atividades contidas no dossiê de <strong>{activeTemplate.name}</strong> contam com planos de treinamento unificados e checklists específicos de conformidade contra perdas na operação diária.
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9.5px] text-[#1D4ED8] font-bold flex items-center gap-1">
                  <FileText size={11} /> <strong>{activeTemplate.steps.reduce((acc,s)=>acc + (s.supportDocuments?.length || 0), 0)} documentações operacionais vinculadas.</strong>
                </div>
              </div>

              <div className="bg-blue-50/20 p-3 flex flex-col justify-between border border-blue-150">
                <div>
                  <span className="text-[8.5px] font-mono font-black text-blue-800 block uppercase">META DO PROJETO DE ESTABILIZAÇÃO (PROJECT CHARTER)</span>
                  <p className="text-[10.5px] text-gray-700 font-bold mt-1.5">
                    {activeTemplate.charter.problemStatement}
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9.5px] text-emerald-700 font-extrabold flex items-center gap-1 uppercase tracking-wider">
                  🎯 Meta de atravessamento: Reduzir para &lt; {activeTemplate.charter.targetValue || 25}minutos
                </div>
              </div>
            </div>
            </>
            ) : (
              <div className="bg-[#FAF9F6] border border-gray-250 p-2 overflow-x-hidden min-h-[400px]">
                <WipKanbanBoard
                  steps={activeTemplate.steps}
                  stats={calculateProcessMetrics(activeTemplate.steps, activeTemplate.arrivalRate)}
                  arrivalRate={activeTemplate.arrivalRate}
                />
              </div>
            )}

          </div>

          <div className="border-t border-gray-150 pt-4 flex justify-between items-center bg-gray-50/50 -mx-5 -mb-5 p-5">
            <span className="text-[10.5px] text-gray-500 font-bold font-mono">
              Integrado sob metodologia Shewhart, Pareto 80/20 e DMAIC.
            </span>
            <button
              onClick={() => window.print()}
              className="bg-gray-150 hover:bg-gray-200 font-mono text-[10px] font-extrabold text-[#1A1A1A] py-1.5 px-3 border border-gray-400 flex items-center gap-1 cursor-pointer transition"
            >
              <Printer size={11} /> Imprimir Manual de Procedimentos
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
