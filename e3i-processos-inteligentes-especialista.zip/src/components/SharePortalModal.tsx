import React, { useState, useEffect } from "react";
import { getAuth } from "firebase/auth";
import { db } from "../firebase";
import { doc, setDoc, onSnapshot, updateDoc } from "firebase/firestore";
import { 
  X, 
  Copy, 
  Check, 
  Lock, 
  Unlock, 
  ExternalLink, 
  Share2, 
  MessageSquare, 
  Mail, 
  ShieldCheck, 
  Info,
  Settings,
  HelpCircle,
  TrendingUp,
  RefreshCw,
  Shield
} from "lucide-react";

function humanizeProcessNameForClient(name: string): string {
  let cleaned = name;
  // If it starts with typical Project/Charter titles, simplify it
  cleaned = cleaned.replace(/Projeto de /ig, "");
  cleaned = cleaned.replace(/Estabilização e Capacidade do /ig, "");
  cleaned = cleaned.replace(/Elicitação e Mapeamento do /ig, "");
  cleaned = cleaned.replace(/Mapeamento e Diagnóstico da /ig, "");
  cleaned = cleaned.replace(/Mapeamento e Diagnóstico do /ig, "");
  cleaned = cleaned.replace(/Diagnóstico de /ig, "");
  cleaned = cleaned.replace(/Otimização do /ig, "");
  cleaned = cleaned.replace(/Otimização de /ig, "");
  
  // Custom substitution for Fluxo PCB -> Produção e Montagem de Placas
  if (cleaned.toLowerCase().includes("fluxo pcb")) {
    cleaned = cleaned.replace(/fluxo pcb/ig, "Produção e Montagem de Placas");
  }
  
  return cleaned.trim() || "Fluxo de Trabalho";
}

export function encodePasscode(passcode: string): string {
  try {
    // Encodes characters with character code shift to mask raw text in url
    const chars = passcode.toUpperCase().split("").map(c => String.fromCharCode(c.charCodeAt(0) ^ 42));
    return btoa(unescape(encodeURIComponent(chars.join(""))));
  } catch {
    return btoa(passcode.toUpperCase());
  }
}

export function generateSecureRandomPasscode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // clear readable alpha-numeric (no confusing O/0 or I/1)
  let part1 = "";
  let part2 = "";
  for (let i = 0; i < 4; i++) {
    part1 += chars.charAt(Math.floor(Math.random() * chars.length));
    part2 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `E3I-${part1}-${part2}`;
}

interface SharePortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProcessName?: string;
  onPreviewPortal: () => void;
}

export default function SharePortalModal({ 
  isOpen, 
  onClose, 
  currentProcessName = "Atividade Operacional",
  onPreviewPortal 
}: SharePortalModalProps) {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  
  // Custom configurations stored in localStorage
  const [passcodeEnabled, setPasscodeEnabled] = useState<boolean>(() => {
    return localStorage.getItem("lss_client_portal_passcode_enabled") === "true";
  });
  
  const [passcode, setPasscode] = useState<string>(() => {
    const existing = localStorage.getItem("lss_client_portal_passcode");
    if (existing && existing !== "LSS-2026") return existing;
    const generated = generateSecureRandomPasscode();
    localStorage.setItem("lss_client_portal_passcode", generated);
    return generated;
  });

  const [targetClient, setTargetClient] = useState<string>("");
  const [portalBlocked, setPortalBlocked] = useState<boolean>(() => {
    return localStorage.getItem("lss_client_portal_blocked") === "true";
  });
  const [customProcessName, setCustomProcessName] = useState(() => {
    return humanizeProcessNameForClient(currentProcessName);
  });
  const [selectedPresetMessage, setSelectedPresetMessage] = useState<"standard" | "formal" | "quick">("standard");

  // Keep customProcessName updated if currentProcessName changes
  useEffect(() => {
    setCustomProcessName(humanizeProcessNameForClient(currentProcessName));
  }, [currentProcessName]);

  const [secureServerToken, setSecureServerToken] = useState("");

  const [clientRequests, setClientRequests] = useState<any[]>([]);
  const [answeringReqId, setAnsweringReqId] = useState<string | null>(null);
  const [answerInputStr, setAnswerInputStr] = useState("");

  useEffect(() => {
    if (!secureServerToken) {
      setClientRequests([]);
      return;
    }
    const docId = secureServerToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
    console.log("[Modal Admin] Subscribing to client requests for doc:", docId);
    const unsubscribe = onSnapshot(doc(db, "shared_portals", docId), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setClientRequests(data.requests || []);
      }
    }, (err) => {
      console.error("[Modal Admin] Error listening to client requests:", err);
    });
    return () => unsubscribe();
  }, [secureServerToken]);

  const handleAnswerSubmit = async (reqId: string, status: string, answerText: string) => {
    if (!secureServerToken) return;
    const docId = secureServerToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
    
    try {
      const updatedRequests = clientRequests.map((r: any) => {
        if (r.id === reqId) {
          return {
            ...r,
            status,
            answer: answerText.trim() || r.answer || ""
          };
        }
        return r;
      });
      
      await updateDoc(doc(db, "shared_portals", docId), {
        requests: updatedRequests
      });
      console.log("[Modal Admin] Request answered and updated successfully!");
    } catch (e) {
      console.error("[Modal Admin] Error writing answer to Firestore:", e);
    }
  };

  // Sync state to localStorage on modification
  useEffect(() => {
    localStorage.setItem("lss_client_portal_passcode_enabled", passcodeEnabled.toString());
  }, [passcodeEnabled]);

  useEffect(() => {
    localStorage.setItem("lss_client_portal_passcode", passcode);
  }, [passcode]);

  useEffect(() => {
    localStorage.setItem("lss_client_portal_blocked", portalBlocked.toString());
  }, [portalBlocked]);

  // Secure debounced token generation from server
  useEffect(() => {
    if (!targetClient.trim() || !passcodeEnabled || !passcode.trim()) {
      setSecureServerToken("");
      return;
    }

    const delayDebounce = setTimeout(async () => {
      try {
        const authInstance = getAuth();
        const user = authInstance.currentUser;
        if (!user) {
          console.warn("[SharePortalModal] Usuário não autenticado no Firebase.");
          return;
        }

        const idToken = await user.getIdToken();
        const res = await fetch("/api/portal/generate-token", {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "Authorization": `Bearer ${idToken}`
          },
          body: JSON.stringify({
            companyName: targetClient.trim(),
            passcode: passcode.trim(),
            expirationDays: 7
          })
        });

        const data = await res.json();
        if (data.token) {
          setSecureServerToken(data.token);
          
          // Persist the full real SaaS portal snapshot on Firestore
          try {
            const docId = data.token.replace(/[^a-zA-Z0-9_\-]/g, "_");
            const userEmail = user.email || "";
            const uSuffix = userEmail ? `_${userEmail}` : "";
            
            const cosmosCompanies = JSON.parse(localStorage.getItem(`lss_companies${uSuffix}`) || "[]");
            const cosmosProjects = JSON.parse(localStorage.getItem(`lss_workspace_projects${uSuffix}`) || "[]");
            const cosmosStore = JSON.parse(localStorage.getItem(`lss_project_data_store${uSuffix}`) || "{}");
            
            const activeCompId = localStorage.getItem(`lss_active_company_id${uSuffix}`) || "";
            const activeProjId = localStorage.getItem(`lss_active_project_id${uSuffix}`) || "";
            
            const activeComp = cosmosCompanies.find((c: any) => c.id === activeCompId);
            const activeProj = cosmosProjects.find((p: any) => p.id === activeProjId);
            const activeProjData = cosmosStore[activeProjId] || {};
            
            await setDoc(doc(db, "shared_portals", docId), {
              token: data.token,
              company: activeComp || { id: activeCompId || "comp_unknown", name: targetClient.trim() },
              project: activeProj || { id: activeProjId || "proj_unknown", name: customProcessName, companyId: activeCompId || "comp_unknown", status: "Em Andamento" },
              projectData: activeProjData,
              passcode: passcode.trim(),
              expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
              createdAt: new Date().toISOString(),
              creatorUid: user.uid,
              comments: [],
              requests: []
            }, { merge: true });
            
            console.log("[Portal] Persistent SaaS Snapshot stored under doc ID:", docId);
          } catch (snapshotErr) {
            console.error("[Portal] Error saving persistent snapshot:", snapshotErr);
          }
        } else if (data.error) {
          console.warn("[SharePortalModal] Falha ao assinar token:", data.error);
        }
      } catch (err) {
        console.error("Erro de API ao assinar token seguro:", err);
      }
    }, 400); // 400ms debounce to avoid API spam when typing names

    return () => clearTimeout(delayDebounce);
  }, [targetClient, passcode, passcodeEnabled, customProcessName]);

  if (!isOpen) return null;

  // Build the absolute sharing link
  const origin = window.location.origin;
  const path = window.location.pathname;
  let shareUrl = `${origin}${path}?portal=client`;
  if (targetClient.trim()) {
    shareUrl += `&company=${encodeURIComponent(targetClient.trim())}`;
    if (passcodeEnabled && passcode.trim() && secureServerToken) {
      shareUrl += `&token=${encodeURIComponent(secureServerToken)}`;
    }
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Pre-configured elegant message templates utilizing natural business/operational language
  const messageTemplates = {
    standard: `Olá ${targetClient || "Prezado Cliente"},\n\nPara darmos início ao entendimento e melhoria do dia a dia da sua atividade de "${customProcessName}", preparamos um formulário super simples.\n\n🔗 Acesse aqui: ${shareUrl}\n${passcodeEnabled ? `🔑 Código de Entrada Exclusivo: ${passcode}\n` : ""}\nSua descrição das etapas diárias nos ajudará a simplificar a rotina, reduzir retrabalhos e organizar as tarefas do setor!`,
    formal: `Prezado(a) ${targetClient || "gestor(a)"},\n\nCom o objetivo de mapear e aumentar a eficiência operacional nas atividades de "${customProcessName}", disponibilizamos um canal direto seguro para envio de seu relato de processo.\n\nSolicitamos a gentileza de preencher o fluxo básico de etapas no endereço abaixo:\n🔗 Link de Acesso: ${shareUrl}\n${passcodeEnabled ? `Segurança do Canal - Código de Entrada: ${passcode}\n` : ""}\nAgradecemos profundamente vossa colaboração e parceria técnica.`,
    quick: `Oi! Segue o link rápido para preencher o passo a passo da sua rotina de "${customProcessName}":\n🔗 ${shareUrl}\n${passcodeEnabled ? `Senha de acesso: ${passcode}\n` : ""}É bem simples e rápido de relatar. Com isso, eu consigo planejar as melhorias do setor! Um abraço.`
  };

  const activeMessage = messageTemplates[selectedPresetMessage];

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(activeMessage);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(activeMessage);
    window.open(`https://api.whatsapp.com/send?text=${text}`, "_blank");
  };

  return (
    <div className="fixed inset-0 bg-[#1A1A1A]/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
      <div className="bg-[#F5F2ED] border-4 border-[#1A1A1A] w-full max-w-2xl shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header bar */}
        <div className="bg-[#1A1A1A] text-white p-4 flex justify-between items-center border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Share2 size={16} className="text-amber-500" />
            <span className="font-mono text-xs uppercase font-extrabold tracking-widest text-amber-500">
              Compartilhar Canal Seguro • White-Label
            </span>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 hover:bg-gray-800 transition-colors rounded-sm cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal content body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          <div className="bg-white border border-[#1A1A1A]/10 p-4 rounded-sm shadow-xs space-y-2">
            <h3 className="text-sm font-bold text-gray-950 flex items-center gap-1.5 font-serif">
              👁️ Isolamento do Cliente Garantido
            </h3>
            <p className="text-xs text-gray-650 leading-relaxed">
              O link gerado abre exclusivamente o portal simplificado de diagnóstico. O cliente 
              <strong> NÃO conseguirá ver seus roteiros, ferramentas de Gestão de Processos, painéis Kanban ou dados de outros clientes</strong>. Ele atuará apenas como solicitante, enviando relatos de processos de forma limpa, moderna e protegida.
            </p>
          </div>

          {/* Process Name customization field */}
          <div className="space-y-1 bg-amber-500/5 p-3.5 border border-dashed border-amber-500/20 rounded-xs">
            <label className="text-[10px] font-black uppercase tracking-wider text-amber-950 block">
              🏷️ Termo / Atividade Usada no Convite:
            </label>
            <input 
              type="text" 
              value={customProcessName}
              onChange={(e) => setCustomProcessName(e.target.value)}
              placeholder="Ex: Faturamento, Atendimento de Suporte, Montagem de Placas"
              className="w-full bg-white border border-[#1A1A1A]/20 p-2 text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none font-bold text-gray-800"
            />
            <span className="text-[9px] text-[#C49746] block leading-snug font-medium">
              💡 Automatizamos a remoção de termos técnicos e acadêmicos (como "Fluxo PCB", "DMAIC") para usar linguagem comercial de negócio e facilitar a compreensão do cliente. Sinta-se livre para ajustar como preferir!
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Input name target */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-wider text-gray-700 block">
                Nome ou Empresa do Cliente:
              </label>
              <input 
                type="text" 
                value={targetClient}
                onChange={(e) => setTargetClient(e.target.value)}
                placeholder="Ex: ACME Cop., Marcos Silva"
                className="w-full bg-white border border-[#1A1A1A]/20 p-2 text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none"
              />
              <span className="text-[9px] text-gray-400 block leading-tight">
                Opcional. Adiciona a empresa do cliente ao link gerado para personalização.
              </span>
            </div>

            {/* Passcode Protection configuration */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-wider text-gray-700 block flex justify-between items-center">
                <span>Proteção por Código de Entrada:</span>
                <span className={`text-[8.5px] px-1 font-mono rounded-xs font-bold ${passcodeEnabled ? 'bg-amber-100 text-amber-800' : 'bg-gray-100 text-gray-500'}`}>
                  {passcodeEnabled ? 'Senha Ativa' : 'Público'}
                </span>
              </label>
              
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPasscodeEnabled(!passcodeEnabled)}
                  className={`px-3 py-2 text-xs font-bold border flex items-center gap-1.5 transition-colors cursor-pointer rounded-xs ${
                    passcodeEnabled ? 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {passcodeEnabled ? <Lock size={12} className="text-amber-800" /> : <Unlock size={12} className="text-gray-400" />}
                  {passcodeEnabled ? "Desativar Senha" : "Ativar Senha"}
                </button>
                
                {passcodeEnabled && (
                  <div className="flex-1 flex gap-1 items-center">
                    <input 
                      type="text"
                      value={passcode}
                      onChange={(e) => setPasscode(e.target.value.toUpperCase())}
                      className="flex-1 min-w-0 bg-white border border-[#1A1A1A]/20 p-2 text-xs focus:outline-none font-mono text-center font-bold tracking-wider text-[#C49746]"
                      title="Defina o PIN ou senha que o cliente usará para entrar no portal"
                      maxLength={18}
                    />
                    <button
                      type="button"
                      onClick={() => setPasscode(generateSecureRandomPasscode())}
                      className="p-2 px-2.5 bg-amber-50 hover:bg-amber-100 border border-[#1A1A1A]/20 hover:border-amber-400 text-[#C49746] font-sans font-bold text-[10px] rounded-xs cursor-pointer flex items-center gap-1 shrink-0 active:scale-95 transition-all"
                      title="Gerar Novo Código Aleatório Seguro"
                    >
                      <RefreshCw size={11} className="text-[#C49746]" />
                      <span>Gerar Forte</span>
                    </button>
                  </div>
                )}
              </div>
              <span className="text-[9px] text-gray-400 block leading-tight">
                {passcodeEnabled ? "O cliente precisará digitar essa senha para visualizar o formulário." : "Qualquer pessoa com o link poderá preencher o questionário."}
              </span>
            </div>

            {/* Client Access Suspension Trigger (E3I Control) */}
            <div className="space-y-1 md:col-span-2 bg-red-50/25 border border-red-200/55 p-3 rounded-sm">
              <label className="text-[10px] font-black uppercase tracking-wider text-red-900 block flex justify-between items-center">
                <span>⚠️ Controle de Liberação da E3I (Revogação de link):</span>
                <span className={`text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold uppercase transition-colors ${
                  !portalBlocked ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-red-100 text-red-800 border border-red-300 animate-pulse'
                }`}>
                  {!portalBlocked ? '🟢 Canal Liberado para Cliente' : '🔴 Canal Bloqueado / Link Suspenso'}
                </span>
              </label>
              
              <div className="flex gap-2.5 items-center mt-1.5">
                <button
                  type="button"
                  onClick={() => setPortalBlocked(!portalBlocked)}
                  className={`px-3 py-1.5 text-xs font-bold font-mono tracking-wide border flex items-center gap-1.5 transition-all cursor-pointer rounded-xs active:scale-95 ${
                    !portalBlocked 
                      ? 'bg-rose-50 border-rose-300 text-rose-950 hover:bg-rose-100/80 font-bold' 
                      : 'bg-emerald-50 border-emerald-300 text-emerald-950 hover:bg-emerald-100/80 font-bold'
                  }`}
                >
                  <Shield size={12} className={!portalBlocked ? 'text-rose-700' : 'text-emerald-700'} />
                  {!portalBlocked ? "Bloquear/Suspender Canal" : "Liberar Canal Novo"}
                </button>
                <p className="text-[9px] text-gray-500 leading-snug flex-1">
                  {!portalBlocked 
                    ? "O cliente poderá relatar e simular processos normalmente." 
                    : "Acesso suspenso imediatamente. O cliente receberá um aviso solicitando contato com o Especialista em Processos."}
                </p>
              </div>
            </div>
          </div>

          {/* Shareable Link Box */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-700 block">
              🔗 Link Exclusivo do Portal do Cliente:
            </span>
            <div className="flex border-2 border-[#1A1A1A] bg-white rounded-xs overflow-hidden">
              <div className="flex-1 p-2 text-xs font-mono text-gray-600 bg-gray-50 overflow-x-auto whitespace-nowrap scrollbar-thin">
                {shareUrl}
              </div>
              <button
                type="button"
                onClick={handleCopyLink}
                className="bg-amber-50 hover:bg-[#C49746] text-amber-950 hover:text-white px-3 font-bold text-xs uppercase flex items-center gap-1 border-l border-[#1A1A1A] transition-colors cursor-pointer"
              >
                {copiedLink ? <Check size={13} /> : <Copy size={13} />}
                {copiedLink ? "Copiado!" : "Copiar"}
              </button>
            </div>
          </div>

          {/* Invitation Copy templates */}
          <div className="space-y-2 border-t border-[#1A1A1A]/10 pt-4">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black uppercase tracking-wider text-gray-700 block">
                ✉️ Mensagem Pronta de Convite:
              </span>
              <div className="flex gap-1.5 text-[9px] font-mono">
                <button
                  type="button"
                  onClick={() => setSelectedPresetMessage("standard")}
                  className={`px-2 py-0.5 rounded-xs font-bold border transition-colors ${selectedPresetMessage === "standard" ? "bg-[#1A1A1A] text-white border-black" : "bg-white text-gray-600 border-gray-300"}`}
                >
                  Padronizado
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPresetMessage("formal")}
                  className={`px-2 py-0.5 rounded-xs font-bold border transition-colors ${selectedPresetMessage === "formal" ? "bg-[#1A1A1A] text-white border-black" : "bg-white text-gray-600 border-gray-300"}`}
                >
                  Formal
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPresetMessage("quick")}
                  className={`px-2 py-0.5 rounded-xs font-bold border transition-colors ${selectedPresetMessage === "quick" ? "bg-[#1A1A1A] text-white border-black" : "bg-white text-gray-600 border-gray-300"}`}
                >
                  Rápido
                </button>
              </div>
            </div>

            <div className="relative">
              <textarea
                readOnly
                rows={5}
                value={activeMessage}
                className="w-full bg-white border border-[#1A1A1A]/10 p-3 text-[10.5px] leading-relaxed text-gray-700 font-sans focus:outline-none resize-none rounded-xs select-all"
              />
              <div className="absolute right-2 bottom-2 flex gap-1 bg-white/90 p-1 rounded-sm border shadow-xs">
                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="bg-amber-50 hover:bg-[#C49746] text-[#C49746] hover:text-white px-2 py-1 text-[10px] font-bold uppercase rounded-xs transition-colors flex items-center gap-1 cursor-pointer"
                >
                  {copiedText ? <Check size={11} /> : <Copy size={11} />}
                  <span>{copiedText ? "Copiado!" : "Copiar Texto"}</span>
                </button>
                
                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="bg-emerald-50 hover:bg-emerald-600 text-emerald-800 hover:text-white px-2 py-1 text-[10px] font-bold uppercase rounded-xs transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <MessageSquare size={11} />
                  <span>Configurar no WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* Real-time Client Requests Feed */}
          {secureServerToken && (
            <div className="space-y-3.5 border-t border-[#1A1A1A]/10 pt-5">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-950 block flex justify-between items-center">
                <span>📩 Solicitações do Cliente em Tempo Real ({clientRequests.length}):</span>
                <span className="text-[8.5px] px-1 bg-amber-100 text-amber-800 font-mono font-bold uppercase animate-pulse">Sincronizado</span>
              </span>
              
              {clientRequests.length === 0 ? (
                <div className="p-4 bg-gray-55/40 border border-dashed border-gray-350 text-center rounded-sm">
                  <p className="text-xs text-gray-550 italic font-sans">Nenhuma demanda preenchida ou solicitada pelo cliente ainda de fora.</p>
                  <p className="text-[9.5px] text-gray-400 mt-0.5 leading-relaxed font-sans">Quando o cliente acessar o link e registrar uma nova atividade operacional, o relato aparecerá aqui instantaneamente sem recarregar!</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                  {[...clientRequests].reverse().map((req: any) => (
                    <div key={req.id} className="p-3 bg-[#FAF8F5] border-2 border-[#1A1A1A]/10 hover:border-amber-500/35 transition-colors rounded-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-black text-gray-950">👤 {req.clientName}</span>
                        <div className="flex items-center gap-1.5 font-mono text-[9px]">
                          <select 
                            value={req.status} 
                            onChange={(e) => handleAnswerSubmit(req.id, e.target.value, req.answer || "")}
                            className="bg-white border text-gray-800 p-0.5 font-bold uppercase rounded-xs font-mono outline-none"
                          >
                            <option value="Em Análise">🔍 Em Análise</option>
                            <option value="Aprovada">🟢 Aprovada</option>
                            <option value="Recusada">🔴 Recusada</option>
                          </select>
                        </div>
                      </div>
                      <p className="text-xs text-gray-750 font-sans leading-relaxed break-words">{req.text}</p>
                      
                      {req.answer && (
                        <div className="p-2 bg-amber-500/5 border-l-2 border-amber-500 space-y-0.5 animate-fade-in">
                          <span className="text-[9px] font-bold font-mono text-amber-950 block">💬 Resposta enviada:</span>
                          <p className="text-[11px] text-gray-700 italic">{req.answer}</p>
                        </div>
                      )}
                      
                      {answeringReqId === req.id ? (
                        <div className="space-y-2 pt-1 border-t border-gray-200">
                          <textarea 
                            placeholder="Escreva sua orientação, justificativa ou resposta técnica..."
                            value={answerInputStr}
                            onChange={(e) => setAnswerInputStr(e.target.value)}
                            className="w-full bg-white border border-[#1A1A1A]/30 p-2 text-xs font-sans focus:outline-none rounded-xs h-16"
                          />
                          <div className="flex gap-2 justify-end">
                            <button 
                              type="button"
                              onClick={() => {
                                setAnsweringReqId(null);
                                setAnswerInputStr("");
                              }}
                              className="px-2 py-1 text-[10px] font-mono hover:bg-gray-100 uppercase rounded-xs border text-gray-650 cursor-pointer"
                            >
                              Cancelar
                            </button>
                            <button 
                              type="button"
                              onClick={async () => {
                                await handleAnswerSubmit(req.id, req.status, answerInputStr);
                                setAnsweringReqId(null);
                                setAnswerInputStr("");
                              }}
                              className="px-2.5 py-1 text-[10px] font-mono bg-[#1A1A1A] hover:bg-amber-600 text-white font-bold uppercase rounded-xs cursor-pointer"
                            >
                              Enviar Resposta
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex justify-between items-center text-[9px] font-mono text-gray-400 pt-1 border-t border-gray-100">
                          <span>🕒 {new Date(req.timestamp).toLocaleString("pt-BR")}</span>
                          <button
                            type="button"
                            onClick={() => {
                              setAnsweringReqId(req.id);
                              setAnswerInputStr(req.answer || "");
                            }}
                            className="text-[#C49746] hover:underline font-bold font-mono uppercase"
                          >
                            {req.answer ? "📝 Alterar Resposta" : "💬 Adicionar Resposta"}
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="bg-white px-6 py-4 border-t border-gray-200 flex flex-wrap gap-2 justify-between items-center">
          <div className="flex items-center gap-1 bg-amber-50 p-1 px-2.5 rounded-sm border border-amber-200 text-amber-950 font-sans text-xs">
            <ShieldCheck size={14} className="text-amber-800 animate-pulse" />
            <span>Focado em <strong>Experiência Segura de Marca</strong></span>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => {
                onClose();
                onPreviewPortal();
              }}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-mono font-bold uppercase text-[10px] tracking-wide border border-gray-300 flex items-center gap-1 cursor-pointer rounded-xs"
              title="Abre o portal do cliente seguro direto no seu navegador para testar a experiência"
            >
              <ExternalLink size={11} />
              <span>Testar Simulador Local</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2 bg-[#1A1A1A] hover:bg-[#C49746] text-white font-mono font-extrabold uppercase text-[10.5px] tracking-wide transition-colors cursor-pointer rounded-xs"
            >
              Concluir
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
