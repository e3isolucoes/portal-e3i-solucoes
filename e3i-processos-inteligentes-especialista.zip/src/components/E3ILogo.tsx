import React from "react";

interface Props {
  className?: string;
  width?: number | string;
  height?: number | string;
  variant?: "light" | "dark";
}

export default function E3ILogo({ className = "", width = 180, height = 96, variant = "light" }: Props) {
  // Brand colors:
  // Deep Blue is #0E2C54
  // Gold/Amber is #C49746
  
  const textColor = variant === "light" ? "text-[#0E2C54]" : "text-white";
  const subtextColor = variant === "light" ? "url(#e3i-gold-grad)" : "#FFFFFF";

  return (
    <div className={`inline-block select-none ${className}`} style={{ width, height }}>
      <svg
        viewBox="0 0 320 292"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          {/* Metallic Gold Gradient */}
          <linearGradient id="e3i-gold-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F9DF95" />
            <stop offset="35%" stopColor="#D4A756" />
            <stop offset="70%" stopColor="#C49746" />
            <stop offset="100%" stopColor="#9C7225" />
          </linearGradient>

          {/* Deep Navy Gradient */}
          <linearGradient id="e3i-blue-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#1B4273" />
            <stop offset="100%" stopColor="#0E2C54" />
          </linearGradient>

          {/* Premium Metallic Silver Column Gradient */}
          <linearGradient id="e3i-silver-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#E2E8F0" />
            <stop offset="25%" stopColor="#FFFFFF" />
            <stop offset="75%" stopColor="#CBD5E1" />
            <stop offset="100%" stopColor="#94A3B8" />
          </linearGradient>
          
          <filter id="logo-drop-shadow" x="-5%" y="-5%" width="120%" height="120%">
            <feDropShadow dx="1" dy="1.5" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.12" />
          </filter>
        </defs>

        <g filter="url(#logo-drop-shadow)">
          {/* Background subtle hexagon fill to give depth and solidness to the hexagon interior */}
          <polygon
            points="160,20 274,86 274,186 160,252 46,186 46,86"
            fill="#FFFFFF"
            fillOpacity="0.92"
          />

          {/* Outer Rounded-Vertex Hexagon Frame in Rich Gold */}
          <polygon
            points="160,20 274,86 274,186 160,252 46,186 46,86"
            stroke="url(#e3i-gold-grad)"
            strokeWidth="5"
            fill="none"
            strokeLinejoin="round"
          />

          {/* Inner Premium Hexagon Border Accent */}
          <polygon
            points="160,27 267,89 267,181 160,243 53,181 53,89"
            stroke="url(#e3i-gold-grad)"
            strokeWidth="1.5"
            fill="none"
            strokeLinejoin="round"
            opacity="0.8"
          />

          {/* Shifted Letters and Indicators centered inside the Hexagon (Y translation of +56 units) */}
          <g transform="translate(0, 56)">
            {/* Golden Upper Drumstick/Pointer */}
            {/* Stem */}
            <path
              d="M 28 32 L 126 15"
              stroke="#C49746"
              strokeWidth="4"
              strokeLinecap="round"
            />
            {/* Golden Orb */}
            <circle cx="126" cy="15" r="9" fill="url(#e3i-gold-grad)" stroke="#9C7225" strokeWidth="1" />

            {/* THE 'E' - Styled block letter */}
            <path
              d="M 38 40 H 120 V 58 H 60 V 71 H 110 V 89 H 60 V 102 H 120 V 120 H 38 Z"
              fill="url(#e3i-blue-grad)"
            />

            {/* THE '3' - Traditional robust, rounded counters with gold gradient */}
            <path
              d="M 140 40 
                 H 214 
                 V 58 
                 L 185 80 
                 C 214 82 230 94 230 110 
                 C 230 126 211 138 180 138 
                 C 156 138 140 128 140 120 
                 H 162 
                 C 162 123 169 128 180 128 
                 C 194 128 206 122 206 110 
                 C 206 98 194 92 174 92 
                 H 140 
                 V 76 
                 L 172 58 
                 H 140 Z"
              fill="url(#e3i-gold-grad)"
              stroke="#9C7225"
              strokeWidth="0.75"
            />

            {/* THE 'I' - Block letter styled now with Silver Chrome Gradient */}
            <path
              d="M 248 40 H 280 V 120 H 248 Z"
              fill="url(#e3i-silver-grad)"
            />

            {/* Blue Lower Drumstick/Pointer */}
            {/* Stem */}
            <path
              d="M 216 117 L 298 97"
              stroke="#0E2C54"
              strokeWidth="4"
              strokeLinecap="round"
            />
            {/* Blue Orb */}
            <circle cx="216" cy="117" r="9" fill="url(#e3i-blue-grad)" stroke="#0E2C54" strokeWidth="1" />
          </g>
        </g>

        {/* Brand Label "SOLUÇÕES" at the bottom wide spaced */}
        <text
          x="160"
          y="282"
          fill={subtextColor}
          fontSize="17.5"
          fontWeight="900"
          fontFamily="'Arial', 'Helvetica Neue', sans-serif"
          textAnchor="middle"
          letterSpacing="11"
          className="tracking-widest"
        >
          SOLUÇÕES
        </text>
      </svg>
    </div>
  );
}
