import React, { useState, useRef, useEffect, MouseEvent } from "react";
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize,
  RefreshCw, 
  Move, 
  Settings2, 
  User, 
  FileText, 
  Trash2, 
  Sparkles,
  Layers,
  HelpCircle,
  Plus,
  ArrowRight,
  GitCommit,
  Play,
  Square,
  Map,
  HelpCircle as DecisionIcon
} from "lucide-react";
import { ProcessStep } from "../types";
import { AreaId, CORPORATE_AREAS } from "../utils/areaPresets";
import { UsabilityMode } from "../domain/usabilityMode";
import EmptyState from "./EmptyState";
import { INITIAL_STEPS } from "../shared/utils/initialStates";
import { useToast } from "../shared/ui/Toast";
import DetailDrawer from "../shared/ui/DetailDrawer";

export const getSipocForStep = (step: ProcessStep, areaId: string) => {
  const customSuppliers = step.suppliers && step.suppliers.length > 0 ? step.suppliers[0] : null;
  const customInputs = step.requiredInputs && step.requiredInputs.length > 0 ? step.requiredInputs[0] : null;
  const customOutputs = step.outputs && step.outputs.length > 0 ? step.outputs[0] : null;
  const customCustomers = step.customers && step.customers.length > 0 ? step.customers[0] : null;

  switch (areaId) {
    case "finance":
      return {
        supplier: customSuppliers || "Bancos & ERP",
        input: customInputs || "Provisões e Notas",
        output: customOutputs || "Liberações e DRE",
        customer: customCustomers || "CFO / Controladoria"
      };
    case "it_governance":
      return {
        supplier: customSuppliers || "Rede / Servidores",
        input: customInputs || "Logs & Ingressos",
        output: customOutputs || "Uptime / Patch TI",
        customer: customCustomers || "Sistemas Core"
      };
    case "hr":
      return {
        supplier: customSuppliers || "Candidatos / Portais",
        input: customInputs || "Perfis & Vagas",
        output: customOutputs || "Belts Capacitados",
        customer: customCustomers || "Times de Suporte"
      };
    case "data_ai":
      return {
        supplier: customSuppliers || "Data Warehouse",
        input: customInputs || "Métricas Brutas",
        output: customOutputs || "API Preditiva / IA",
        customer: customCustomers || "BPM / Simuladores"
      };
    case "legal_risk":
      return {
        supplier: customSuppliers || "Regulatório / LEAN",
        input: customInputs || "Contratos & Riscos",
        output: customOutputs || "Parecer Homologado",
        customer: customCustomers || "Diretoria e Sócios"
      };
    case "core_inbound":
      return {
        supplier: customSuppliers || "Transportadoras",
        input: customInputs || "NFs XML e Cargas",
        output: customOutputs || "Insumos em Estoque",
        customer: customCustomers || "Produção Core"
      };
    case "core_outbound":
      return {
        supplier: customSuppliers || "Linha de Produção",
        input: customInputs || "Lote Acabado",
        output: customOutputs || "Mercadoria Despachada",
        customer: customCustomers || "Clientes VIP"
      };
    case "core_sales":
      return {
        supplier: customSuppliers || "Inbound Marketing",
        input: customInputs || "Mailing de Leads",
        output: customOutputs || "Contrato e SLA",
        customer: customCustomers || "Atendimento / CS"
      };
    case "core_ops":
    default:
      return {
        supplier: customSuppliers || "Almoxarifado Core",
        input: customInputs || "Insumo / Matéria-Prima",
        output: customOutputs || "Produto Acabado",
        customer: customCustomers || "Logística / Outbound"
      };
  }
};

interface AreaSipocData {
  supplier: string;
  input: string;
  processDesc: string;
  output: string;
  customer: string;
}

const REGIONAL_SIPOC_PRESETS: Record<AreaId, AreaSipocData> = {
  finance: {
    supplier: "Tesouraria, Gerentes de Projetos, Contabilidade & Bancos",
    input: "Notas fiscais recebidas, relatórios de OPEX/CAPEX, requisições de pagamentos e provisões de custos.",
    processDesc: "1. Registrar e aprovar provisões orçamentárias -> 2. Calcular Balanced Scorecard (BSC) e metas corporativas -> 3. Obter aprovação formal da Diretoria/CFO -> 4. Executar liquidação e pagamentos no ERP.",
    output: "Fluxo de caixa consolidado, DRE trimestral auditado, ordens de pagamento aprovadas e faturamento estruturado.",
    customer: "Diretoria Executiva, Investidores, Controladoria Geral e Auditoria Externa."
  },
  it_governance: {
    supplier: "Provedores Cloud (GCP/AWS), Desenvolvedores, NOC Interno e Fornecedores de Hardware",
    input: "Alertas de segurança e patches, logs brutos de redes, requisições de acesso e relatórios de vulnerabilidade de servidores.",
    processDesc: "1. Monitorar indisponibilidades e KPIs de uptime -> 2. Auditar logs críticos sob compliance NIST -> 3. Executar deploys de pacotes de segurança (ISO 27001) em ambiente controlado.",
    output: "Dashboard de uptime ativo, servidores atualizados, relatório certificado de compliance LGPD e regras de firewall ativas.",
    customer: "Departamentos Operacionais, CTO, Comitê de Governança de TI e Auditoria Interna."
  },
  hr: {
    supplier: "Portais de Vagas, Universidades Corporativas, Recrutadores Externos e Gestores Demandantes",
    input: "Candidatos em funil, matriz de habilidades, requisições de recrutamento para postos de trabalho e grade curricular LSS.",
    processDesc: "1. Mapear e recrutar candidatos em Kanban ágil -> 2. Promover treinamento de capacitação Green & Black Belts (ISO 10015) -> 3. Avaliar e certificar projetos Lean de alto impacto estatístico -> 4. Alocar squads.",
    output: "Profissionais certificados com excelência operacional (LSS), plano de integração e engajamento assinado, banco de talentos ativo.",
    customer: "Time Lean Six Sigma, Gestores de Operação Core, Diretoria de Negócios e Squads de Suporte."
  },
  data_ai: {
    supplier: "Databases Operacionais, Data Lakes, Engenheiros de Dados e Analistas de Negócio",
    input: "Métricas brutas de tempos de ciclo e filas, logs históricos de restrições de maquinário, dados de ERP e regras de negócio.",
    processDesc: "1. Explorar dados estatísticos operacionais -> 2. Treinar Redes Neurais multicamadas para estimar saturação de postos -> 3. Executar testes de validação A/B -> 4. Habilitar gatilho (API MLOps).",
    output: "API preditiva implantada, painéis de monitoramento analítico, logs estatísticos probabilísticos de tráfego de fila.",
    customer: "Líderes de Melhoria Contínua, Supervisores de Automação de Workflows e Engenharia de Processos."
  },
  legal_risk: {
    supplier: "Comitês de Ética, Órgãos Reguladores do Setor, Advogados de Contas e Gerentes Gerais",
    input: "Minutas contratuais brutas, novas atualizações de leis jurídicas, denúncias de conformidade e matriz corporativa de riscos.",
    processDesc: "1. Mapear riscos residuais e auditoria preventiva (ISO 31000) -> 2. Analisar impactos e revisar termos contratuais -> 3. Emitir parecer regulatório -> 4. Coletar assinaturas digitais finais.",
    output: "Pareceres homologados de compliance, termos de garantia executados, matriz geral de contingência em conformidade.",
    customer: "Sócios majoritários da empresa, Diretoria Jurídica, Auditores Fiscais e Área de Compliance Geral."
  },
  core_inbound: {
    supplier: "Fornecedores de Material, Transportadoras Terceirizadas e Compras Estratégicas",
    input: "Insumos físicos embalados, notas fiscais (XML) correspondentes e ordens de compra providas no sistema.",
    processDesc: "1. Realizar triagem documental e conferir XML na entrada -> 2. Executar auditoria física de avarias e quantidades -> 3. Armazenar e endereçar materiais via FIFO/Kanban.",
    output: "Insumos certificados e integrados ao armazém central, notificações de recebimento prontas e XMLs autorizados no ERP.",
    customer: "Líderes da Linha SMT/Operação, Planejamento de Produção (PCP) e Tesouraria (para faturamento)."
  },
  core_ops: {
    supplier: "Almoxarifado de Inbound, Engenheiros de Qualidade, Manutenção Preventiva e PCP",
    input: "Instruções técnicas das ordens de produção, matérias-primas auditadas prontas, ferramentais e matrizes de setup.",
    processDesc: "1. Preparar e ajustar maquinários críticos (Setup SMED) -> 2. Iniciar montagem estocástica na esteira -> 3. Processar itens nos postos sequenciais de trabalho.",
    output: "Lotes de produto acabado conforme metas LSS, laudos de qualidade fabril assinados e estatísticas de refugo calculadas.",
    customer: "Operadores de Expedição (Logística Outbound), Setor de Qualidade Fictício e Clientes de Consumo."
  },
  core_outbound: {
    supplier: "Execução Operacional Core (Fábrica), Setor Contábil, Transportadoras de Destino",
    input: "Produtos acabados vindos da linha, notas fiscais de saída faturadas e etiquetas logísticas parametrizadas.",
    processDesc: "1. Selecionar produtos e consolidar paletes (Picking FIFO) -> 2. Emitir notas fiscais mercantis faturadas -> 3. Fiscalizar integridade de lacres de segurança e cargas.",
    output: "Carga mercantil faturada despachada para estradas, comprovantes de entrega assinados (Proof of Delivery).",
    customer: "Clientes finais do portfólio, Centrais de Distribuição de terceiros e Monitoramento de Satisfação Comercial."
  },
  core_sales: {
    supplier: "Agência de Atração, Time de Marketing (Mailing de leads), SDRs e Canais de Indicação",
    input: "Dados brutos de leads, prospecções pré-qualificadas no CRM, solicitações formais de cotação de serviços.",
    processDesc: "1. Atender e classificar leads no funil comercial -> 2. Desenhar e orçar propostas comerciais -> 3. Negociar limites de SLA e ciclo -> 4. Monitorar saúde do cliente (anti-churn).",
    output: "Novos negócios fechados com contratos assinados digitalmente, acordo de nível de serviço (SLA) parametrizado.",
    customer: "Time Comercial de Integração, Gerência de Customer Success (CS) e Atendimento ao Cliente Geral."
  }
};

export function getSectorAdviceForStep(step: ProcessStep, sector: string, bottleneckName?: string) {
  const sec = sector || "INDUSTRIAL";
  const name = step.name.toLowerCase();
  
  let tip = "";
  let metricFocus = "";
  let actionTool = "";
  
  if (step.shapeType === "DECISION") {
    switch(sec) {
      case "INDUSTRIAL":
        tip = "Pontos de decisão industrial geram refugo se a taxa de rejeição for alta. Adote barreira à prova de erros (Poka-Yoke) para controle automatizado de tolerâncias e dimensões.";
        metricFocus = "Taxa de Refugo & Rendimento de Primeira Passagem";
        actionTool = "Dispositivo Poka-Yoke Autônomo";
        break;
      case "SERVICES":
        tip = "Filtros manuais e aprovações repetitivas afunilam o workflow. Use lógicas predefinidas no sistema com Short-Cut Logic no ERP para transações de baixo risco.";
        metricFocus = "Lead Time Documental & SLA";
        actionTool = "Business Rules Engine (BRE)";
        break;
      case "LOGISTICS":
        tip = "Decisões de classificação de rotas de carga atrasam despacho. Adote sistemas Pick-to-light ou cross-docking dinâmico integrados com tags RFID ou WMS.";
        metricFocus = "Tempo de Cross-Docking & Unitização";
        actionTool = "Automação RFID e Roteamento Dinâmico";
        break;
      case "HEALTHCARE":
        tip = "A triagem de pacientes em filas manuais aumenta severamente riscos ambulatoriais. Implemente e apoie a tomada de decisão via Protocolos inteligentes e digitais.";
        metricFocus = "Time-to-Care (SLA) & Tempo de Triagem";
        actionTool = "Manchester Protocol Digital";
        break;
      case "FINANCE":
        tip = "Múltiplas revisões de integridade de notas e auditorias fiscais manuais causam fila crônica. Implemente regras automáticas de reconciliação cruzada via conciliação baseada em IA.";
        metricFocus = "Taxa de Erros de Entrada & Velocidade";
        actionTool = "API Assistida de Inteligência Tributária";
        break;
      case "RETAIL":
        tip = "Decisão manual de requisição física de prateleiras atrasa reposição. Conecte o controle de níveis mínimos Kanban digitais diretamente ao estoque interno central.";
        metricFocus = "Taxa de Ruptura de Gôndola & Giro";
        actionTool = "Kanban de Autogestão de Inventário";
        break;
      case "TECHNOLOGY":
        tip = "Filtro manual de checagens manuais de código para deploy. Migre para validação via testes automáticos com regras rigorosas de pull request por qualidade pré-commit.";
        metricFocus = "Tempo de Lead de Correção & Freq. Deploy";
        actionTool = "Regras Estritas de CI/CD Integradas";
        break;
      case "HUMAN_RESOURCES":
        tip = "Análise demorada e subjetiva de currículos e perfis iniciais. Empregue algoritmos de mapeamento semântico automatizado de competências Lean baseadas em Belts.";
        metricFocus = "Tempo de Recrutamento (Time-to-Hire)";
        actionTool = "Screening Semântico Automatizado";
        break;
      default:
        tip = "Decisões estocásticas dependem de critério humano volátil. Documente e crie diretrizes operacionais estritas para aprovação imediata sem loopings de retrabalho.";
        metricFocus = "Loopings de Retrabalho & Taxa de Retorno";
        actionTool = "Matriz de Padronização de Decisão";
    }
  } else if (bottleneckName && step.name === bottleneckName) {
    switch(sec) {
      case "INDUSTRIAL":
        tip = "Este é o Gargalo Físico. Cada minuto perdido aqui reduz a receita faturada diária do negócio. Maximize a taxa OEE e organize as trocas rápidas de ferramentas (método SMED).";
        metricFocus = "Eficiência Global de Equipamentos (OEE) & Rendimento";
        actionTool = "TOC (Teoria das Restrições) / SMED Setup Rápido";
        break;
      case "SERVICES":
        tip = "Posto restritivo estocástico de processamento. Heurísticas recomendam balancear a carga ou delegar chamados recorrentes a bots RPA, liberando analistas.";
        metricFocus = "Taxa de Ocupação & SLA de Resolução";
        actionTool = "Process Leveling & Heurísticas de Recursos";
        break;
      case "LOGISTICS":
        tip = "Ponto de restrição de vazão nos portões ou pátio de expedição física. Otimize agendamento prévio com coletores de rádio frequência para que as docas não encavem.";
        metricFocus = "Dwell Time de Veículos & Throughput de Doca";
        actionTool = "YMS (Yard Management) / Planejamento Kanban";
        break;
      case "HEALTHCARE":
        tip = "Fase restritiva (gargalo clínico). Excesso de exames manuais consome tempo precioso. Aloque técnicos polivalentes ou aplique Lean Healthcare para reduzir a papelada.";
        metricFocus = "Tempo de Permanência Hospitalar (LOS)";
        actionTool = "Célula Ágil Assistencial (Fast Track)";
        break;
      case "FINANCE":
        tip = "Processamento que trava a liquidação financeira no ERP corporativo. Use paralelização sistêmica das validações ou crie tolerância tolerada baseada em score de risco.";
        metricFocus = "Ciclo de Liberação (Closing Latency)";
        actionTool = "Auditoria Randômica com Liberação Paralela";
        break;
      case "RETAIL":
        tip = "Gargalo no caixa físico ou finalização de checkout comercial. Ofereça faturamento expresso via totens ou simplifique o preenchimento de cupons de promoção no PDV.";
        metricFocus = "Tempo Médio de Atendimento & Abandono de Fila";
        actionTool = "Expansão de Checkout Expresso (Self)";
        break;
      case "TECHNOLOGY":
        tip = "Gargalo no fluxo de testes finais ou homologação de regras complexas. Remova testes exploratórios exaustivos de rotina e priorize regressivos totalmente automatizados.";
        metricFocus = "Cycle Time do Feature & Estabilidade";
        actionTool = "QA Automação Remota e Testes Paralelos";
        break;
      case "HUMAN_RESOURCES":
        tip = "Entrevistas demoradas e agendas conflitantes representam o maior gargalo. Utilize painéis de dinâmicas integrados para reduzir rodadas redundantes de triagem.";
        metricFocus = "Saturação de Entrevistadores & Lead Time";
        actionTool = "Auditoria de Calendário Sincronizada";
        break;
      default:
        tip = "Este posto limita o faturamento máximo sistêmico de todo o projeto Melhoria Contínua. Proteja esse posto contra quebras de manutenção e garanta abastecimento prioritário.";
        metricFocus = "Capacidade do Gargalo (Throughput)";
        actionTool = "Explorar o Gargalo Estocástico (TOC)";
    }
  } else if (step.yieldRate < 0.95) {
    switch(sec) {
      case "INDUSTRIAL":
        tip = "Rendimento inferior ao aceitável. O refugo físico incorrido desperdiça chapas, cabos e energia. Desenhe uma Matriz de Causa e Efeito com Belts operacionais.";
        metricFocus = "Rolled First Pass Yield (RFPY) & Retrabalho";
        actionTool = "Diagrama de Ishikawa & Folhas de Verificação";
        break;
      case "SERVICES":
        tip = "Refugo informacional elevado (taxa de acerto <95%). Erros de preenchimento ou dados truncados demandam correções custosas por e-mail. Introduza travas de campo obrigatórias.";
        metricFocus = "Taxa de Retrabalho Operacional & NPS";
        actionTool = "Pokayoke de Campo Digital (Máscaras Estritas)";
        break;
      case "LOGISTICS":
        tip = "Frequentes desvios de inventário ou erros de triagem de remessas físicas. A desconexão com o faturamento corrompe a qualidade. Implemente verificação cega por código.";
        metricFocus = "Acurácia de Inventário & Erros de Pick";
        actionTool = "Controle Cego de Double Check Operacional";
        break;
      case "HEALTHCARE":
        tip = "Desvios em protocolos e perda de informações clínicas em transição de turnos. Erros aqui são graves. Reforce o checklist de passagem de plantão estruturado.";
        metricFocus = "Conformidade e Segurança do Paciente";
        actionTool = "Metodologias SBAR & Checklists Ativos OS";
        break;
      default:
        tip = "Nível de variabilidade e rejeitos elevado. Realize mapeamento Kaizen focado em qualidade para rastrear de forma estatística os desvios crônicos e flutuações.";
        metricFocus = "DPMO / Nível Sigma de Capabilidade (Cp/Cpk)";
        actionTool = "Controle Estatístico de Processo (CEP)";
    }
  } else {
    // Stage name check fallback
    if (name.includes("alimentação") || name.includes("entrada") || name.includes("recebimento")) {
      switch(sec) {
        case "INDUSTRIAL":
          tip = "Triagem de entrada física de lotes SMT / cablagem. Mantenha buffers mínimos demarcados visualmente nas bancadas para monitorar a saturação do posto de abastecimento.";
          metricFocus = "Tempo de Setup de Alimentação";
          actionTool = "Sinalização Física de Buffer de Insumos";
          break;
        case "SERVICES":
          tip = "Processamento inicial de solicitações do cliente. Formulários descentralizados criam confusão de escopo. Crie um portal unificado para o primeiro input corporativo.";
          metricFocus = "Qualidade dos Dados Iniciais de Entrada";
          actionTool = "Padronização de Inputs de Triagem";
          break;
        default:
          tip = "Fase de entrada e ingestão inicial do fluxo. Evite gargalos estocásticos imediatos limpando burocracias de triagem e preenchimentos secundários.";
          metricFocus = "Lead Time Inicial do Lote";
          actionTool = "Inbound FIFO & Padronização de Postos";
      }
    } else if (name.includes("inspeção") || name.includes("qualidade") || name.includes("teste") || name.includes("auditoria")) {
      switch(sec) {
        case "INDUSTRIAL":
          tip = "Inspeções manuais lentas são desperdícios LSS de super-processamento. A meta Lean ideal é Jidoka: implementar detecção e parada de máquina integrados e automáticos.";
          metricFocus = "Taxa de Escapes de Qualidade";
          actionTool = "Jidoka (Automação de Controle de Qualidade)";
          break;
        case "SERVICES":
          tip = "Double-checks por supervisores geram retenção desnecessária e atrasam o SLA total. Capacite e autorize os analistas com regras parametrizadas transparentes.";
          metricFocus = "SLA de Aprovação Interna";
          actionTool = "Matriz de Autonomia Limitada Controlada";
          break;
        default:
          tip = "Garantia de conformidade. Não use auditorias complexas como muleta para processos desajustados na base. Foque na prevenção direta das etapas anteriores.";
          metricFocus = "Capabilidade Global de Processo (Cpk)";
          actionTool = "Auditoria de Camadas de Processo (LPA)";
      }
    } else {
      switch(sec) {
        case "INDUSTRIAL":
          tip = "Posto central produtivo. Estabeleça instruções de trabalho visuais fixas (Standard Operating Procedures - SOP) de modo que novos operadores atinjam o Takt time.";
          metricFocus = "Tempo de Ciclo vs Takt Time";
          actionTool = "Instrução de Trabalho SOP Visual";
          break;
        case "SERVICES":
          tip = "Atendimento core ou processamento informacional. Consolide ferramentas em tela unificada para evitar alternância infinita de sistemas e abas de navegador.";
          metricFocus = "Touch Time Ativo (Tempo Real Dedicado)";
          actionTool = "Console Unificado de Atendimento";
          break;
        case "RETAIL":
          tip = "Etapa de reposição de itens e interface com consumidor. Reduza atrito e burocracia promovendo auto-serviço e identificações visuais nas prateleiras.";
          metricFocus = "Taxa de Conversão & Rotatividade de Estoques";
          actionTool = "Visual Merchandising & Sinalização de Fluxos";
          break;
        case "LOGISTICS":
          tip = "Separação física de estoques e paletes. Implemente rotas integradas (Diagrama de Espaguete) para diminuir perdas por movimentação improdutiva de operadores.";
          metricFocus = "Distância Total Percorrida (Spaghetti Chart)";
          actionTool = "Análise Curva ABC & Planejamento FIFO";
          break;
        case "TECHNOLOGY":
          tip = "Posto de desenvolvimento / teste operacional de produtos digitais. Busque fracionar pacotes de entrega para revisões ágeis menores, reduzindo a fila de deploys.";
          metricFocus = "Tamanho Médio do Pull Request & Lead Time";
          actionTool = "Heurísticas Baseadas em Tronco Principal";
          break;
        case "HEALTHCARE":
          tip = "Jornada de assistência de exames ou consulta médica. Minimize burocracias de fichas físicas disponibilizando painéis digitais de acompanhamento de leitos/exames.";
          metricFocus = "Tempo de Fila Ativo & Satisfação (NPS)";
          actionTool = "Gestão à Vista Clínica Integrada";
          break;
        case "FINANCE":
          tip = "Geração de faturamento ou pagamento. Monitore inconsistências por reconciliação automática noturna para mitigar erros de liquidação e perdas de fluxo de caixa.";
          metricFocus = "Taxa de Inconsistências Fiscais";
          actionTool = "Scripts Inteligentes de Conciliação Bancária";
          break;
        case "HUMAN_RESOURCES":
          tip = "Etapa de treinamento ou avaliação de Belts. Estabeleça matriz de desenvolvimento transparente baseada nos currículos estruturados da ISO 13053.";
          metricFocus = "Acurácia de Alocação de Treinamento";
          actionTool = "Grade Curricular e Qualificação LSS Certificada";
          break;
        default:
          tip = "Fase operacional agregadora de valor. Capacite a equipe para monitorar desvios estocásticos e relatar anomalias diretamente ao analista Lean Master Black Belt.";
          metricFocus = "Tempo Médio de Ciclo (ACT)";
          actionTool = "Procedimento Operacional Padronizado (POP)";
      }
    }
  }

  return { tip, metricFocus, actionTool };
}

interface VisualProcessMapperProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  bottleneckStepName?: string;
  onOpenDetails?: (stepId: string) => void;
  activeAreaId?: AreaId;
  onSwitchArea?: (areaId: AreaId) => void;
  usabilityMode?: UsabilityMode;
  businessType?: string;
  openTemplatesHub?: () => void;
}

export default function VisualProcessMapper({ 
  steps, 
  setSteps, 
  bottleneckStepName, 
  onOpenDetails,
  activeAreaId = "core_ops",
  onSwitchArea,
  usabilityMode = "EXPERT",
  businessType = "INDUSTRIAL",
  openTemplatesHub
}: VisualProcessMapperProps) {
  const { warning } = useToast();
  const [isMarginDrawerOpen, setIsMarginDrawerOpen] = useState(false);
  // Navigation / Drill-down active level (CADEIA = Porter diagram, PROCESSO = traditional flowchart)
  const [viewLevel, setViewLevel] = useState<"CADEIA" | "PROCESSO">("CADEIA");
  const [activeCapaAreaId, setActiveCapaAreaId] = useState<AreaId | null>(null);
  const [hoveredAreaId, setHoveredAreaId] = useState<string | null>(null);
  const [showHelpTips, setShowHelpTips] = useState<boolean>(true);
  const [showSipocOverlay, setShowSipocOverlay] = useState<boolean>(true);
  const [showAreaLinks, setShowAreaLinks] = useState<boolean>(true);

  // States for sector technical advice tooltips
  const [hoveredTooltipStepId, setHoveredTooltipStepId] = useState<string | null>(null);

  const toggleStepCompletion = (stepId: string) => {
    setSteps(prevSteps => 
      prevSteps.map(step => 
        step.id === stepId 
          ? { ...step, completed: !step.completed } 
          : step
      )
    );
  };

  // Canvas viewport translation / zoom states
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Node interaction states
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Selected tool ("select" to interact/drag, "pan" to move canvas)
  const [activeTool, setActiveTool] = useState<"select" | "pan">("select");

  const canvasRef = useRef<SVGSVGElement | null>(null);

  // Maintain sync: if external area triggers switch, show the Process level
  useEffect(() => {
    // If customized area was selected externally, enter visual drill-down level automatically
    if (activeAreaId) {
      setViewLevel("PROCESSO");
    }
  }, [activeAreaId]);

  // Automatically fit processes into the viewport when view level changes to PROCESSO
  useEffect(() => {
    if (viewLevel === "PROCESSO") {
      const timer = setTimeout(() => {
        handleZoomToFit();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [viewLevel, activeAreaId]);

  // IA COPILOT INTERACTIVE SUGGESTIONS STATES & HELPERS
  const [approvedSuggestions, setApprovedSuggestions] = useState<Record<string, string[]>>({});
  const [dismissedSuggestions, setDismissedSuggestions] = useState<Record<string, string[]>>({});

  const getAiSuggestionsForStep = (step: ProcessStep) => {
    const key = step.id;
    const nameLower = step.name.toLowerCase();
    const approved = approvedSuggestions[key] || [];
    const dismissed = dismissedSuggestions[key] || [];
    
    const list: Array<{ id: string; title: string; type: "add_instruction" | "add_automation" | "add_link"; value: any; description: string; label: string }> = [];
    
    // Suggestion 1: Framework Connection
    if (!approved.includes("sug-framework") && !dismissed.includes("sug-framework")) {
      if (nameLower.includes("smt") || nameLower.includes("forno") || nameLower.includes("execução") || nameLower.includes("refluxo") || activeAreaId === "core_ops") {
        list.push({
          id: "sug-framework",
          title: "Sincronização com Kaizen & Lean Six Sigma",
          type: "add_instruction",
          label: "Kaizen",
          value: "Efetuar análise Kaizen 5S antes de acionar a máquina, verificando a disposição ergonômica.",
          description: "Vincular a instrução de melhoria contínua de segurança 5S para evitar desperdícios de setup."
        });
      } else if (activeAreaId === "finance") {
        list.push({
          id: "sug-framework",
          title: "Vínculo com Balanced Scorecard (Financeiro)",
          type: "add_instruction",
          label: "BSC",
          value: "Registrar metas do Balanced Scorecard para a perspectiva financeira do fluxo de caixa trimestral.",
          description: "Inserir o controle financeiro de caixa com foco nas metas estratégicas corporativas."
        });
      } else if (activeAreaId === "it_governance") {
        list.push({
          id: "sug-framework",
          title: "Auditoria na norma ISO/IEC 27001",
          type: "add_instruction",
          label: "ISO 27001",
          value: "Executar checagens de segurança cibernética adicionais sob conformidade na norma ISO/IEC 27001.",
          description: "Adicionar instrução técnica de auditoria com foco em integridade e não-repúdio."
        });
      } else if (activeAreaId === "data_ai") {
        list.push({
          id: "sug-framework",
          title: "Adequação ao Ciclo CRISP-DM / DAMA",
          type: "add_instruction",
          label: "CRISP-DM",
          value: "Verificar integridade do pipeline preditivo utilizando a metodologia CRISP-DM para auditoria de viés operacional.",
          description: "Modelar e validar o pipeline estatístico de dados seguindo regras robustas de governança."
        });
      } else if (activeAreaId === "legal_risk") {
        list.push({
          id: "sug-framework",
          title: "Gestão Integrada de Matriz ISO 31000",
          type: "add_instruction",
          label: "ISO 31000",
          value: "Analisar as cláusulas contratuais sob a metodologia de severidade de riscos e multas da ISO 31000.",
          description: "Mapear tolerância a risco baseada em modelo preditivo de perdas operacionais."
        });
      } else {
        list.push({
          id: "sug-framework",
          title: "Linkar com Framework OKR Corporativo",
          type: "add_instruction",
          label: "OKR",
          value: "Sincronizar a velocidade de processamento com a meta K.R. de tempo de entrega global do setor.",
          description: "Vincular a velocidade e yield (atualmente de primeira) com a meta de lead time corporativo."
        });
      }
    }

    // Suggestion 2: Automation or Process link
    if (!approved.includes("sug-automation") && !dismissed.includes("sug-automation")) {
      if (step.shapeType === "DECISION") {
        list.push({
          id: "sug-automation",
          title: "Automação de Decisão Assistida por IA",
          type: "add_automation",
          label: "Automação",
          value: {
            title: "Triagem Inteligente Cognitiva",
            type: "IA & Rede Neural Gen",
            status: "proposed",
            description: "Garante roteamento automatizado do fluxo baseado no histórico de yield, reduzindo a fadiga técnica."
          },
          description: "Vincular e sugerir um módulo preditivo de IA que aprova ou reprova de forma assistida."
        });
      } else if (activeAreaId === "core_ops" || activeAreaId === "core_inbound") {
        list.push({
          id: "sug-automation",
          title: "Vínculo com Processo de TI & Inteligência Artificial",
          type: "add_link",
          label: "Vínculo",
          value: "it_governance",
          description: "Sugerimos acoplar um link sistêmico com 'TI, Governança & Sistemas' para validar o lote no ERP de forma simultânea."
        });
      } else {
        list.push({
          id: "sug-automation",
          title: "Acoplar Robô RPA Automatizado",
          type: "add_automation",
          label: "Automação RPA",
          value: {
            title: "Assistente RPA de Dados",
            type: "Robótica de Processos",
            status: "proposed",
            description: "Robô automatizado que realiza o preenchimento de campos repetitivos de forma instantânea."
          },
          description: "Aplicar automação RPA que gera ganho de 20% em tempo de ciclo de processamento."
        });
      }
    }

    return list;
  };

  const handleApproveSuggestion = (sugId: string, type: 'add_instruction' | 'add_automation' | 'add_link', value: any) => {
    if (!selectedNodeId) return;
    
    setSteps(prev => prev.map(step => {
      if (step.id === selectedNodeId) {
        const u = { ...step };
        if (type === 'add_instruction') {
          const currentInstructions = u.stepInstructions ? [...u.stepInstructions] : [];
          u.stepInstructions = [...currentInstructions, value];
        } else if (type === 'add_automation') {
          const currentAutomations = u.automations ? [...u.automations] : [];
          u.automations = [...currentAutomations, value];
        } else if (type === 'add_link') {
          // Store custom linked area inside the description or metadata of the step
          u.resource = `${u.resource} (Vínculo: TI & Governança)`;
          u.description = `${u.description || ""} [Vínculo ativo com TI, Governança & Sistemas para integridade da cadeia de valor]`;
        }
        return u;
      }
      return step;
    }));

    setApprovedSuggestions(prev => {
      const existing = prev[selectedNodeId] || [];
      return { ...prev, [selectedNodeId]: [...existing, sugId] };
    });
  };

  const handleRejectSuggestion = (sugId: string) => {
    if (!selectedNodeId) return;
    setDismissedSuggestions(prev => {
      const existing = prev[selectedNodeId] || [];
      return { ...prev, [selectedNodeId]: [...existing, sugId] };
    });
  };

  // Initialize nodes coordinates on first render if they aren't set
  useEffect(() => {
    let changed = false;
    const initialized = steps.map((step, idx) => {
      const updated = { ...step };
      if (updated.x === undefined || updated.y === undefined) {
        updated.x = 100 + (idx % 3) * 240;
        updated.y = 80 + Math.floor(idx / 3) * 160;
        changed = true;
      }
      if (updated.shapeType === undefined) {
        if (idx === 0) {
          updated.shapeType = "START";
        } else if (idx === steps.length - 1) {
          updated.shapeType = "END";
        } else if (step.name.toLowerCase().includes("inspeção") || step.name.toLowerCase().includes("teste") || step.name.toLowerCase().includes("decidir")) {
          updated.shapeType = "DECISION";
        } else {
          updated.shapeType = "ACTIVITY";
        }
        changed = true;
      }
      if (updated.nextStepId === undefined && idx < steps.length - 1) {
        updated.nextStepId = steps[idx + 1].id;
        changed = true;
      }
      return updated;
    });

    if (changed) {
      setSteps(initialized);
    }
  }, []);

  // Set default coordinates for any new step added externally or locally
  const ensureNodeData = (step: ProcessStep, idx: number): ProcessStep => {
    return {
      ...step,
      x: step.x ?? (100 + (idx % 3) * 240),
      y: step.y ?? (80 + Math.floor(idx / 3) * 160),
      shapeType: step.shapeType ?? (idx === 0 ? "START" : "ACTIVITY"),
    };
  };

  // Canvas Handlers
  const handleCanvasMouseDown = (e: MouseEvent<SVGSVGElement>) => {
    if (activeTool === "pan" || e.button === 1 || e.target === canvasRef.current) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      e.preventDefault();
    }
  };

  const handleCanvasMouseMove = (e: MouseEvent<SVGSVGElement>) => {
    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
    } else if (draggingNodeId) {
      // Move Node
      if (!canvasRef.current) return;
      
      const rect = canvasRef.current.getBoundingClientRect();
      // Translate mouse coordinates accounting for zoom and pan
      const mouseXInSvg = (e.clientX - rect.left - pan.x) / zoom;
      const mouseYInSvg = (e.clientY - rect.top - pan.y) / zoom;

      setSteps((prev) =>
        prev.map((step) => {
          if (step.id === draggingNodeId) {
            return {
              ...step,
              x: Math.max(20, Math.min(2000, mouseXInSvg - dragOffset.x)),
              y: Math.max(20, Math.min(2000, mouseYInSvg - dragOffset.y)),
            };
          }
          return step;
        })
      );
    }
  };

  const handleCanvasMouseUp = () => {
    setIsPanning(false);
    setDraggingNodeId(null);
  };

  const handleZoom = (factor: number) => {
    if (factor === 0) {
      setZoom(1);
      setPan({ x: 0, y: 0 });
    } else {
      setZoom((prev) => Math.max(0.4, Math.min(2.5, prev * factor)));
    }
  };

  const handleZoomToFit = (customSteps?: ProcessStep[]) => {
    if (!canvasRef.current) return;
    const targetSteps = customSteps || steps;
    if (targetSteps.length === 0) return;

    // Get SVG bounding box dimensions
    const rect = canvasRef.current.getBoundingClientRect();
    const containerW = rect.width || 800;
    const containerH = rect.height || 500;

    // Filter steps that have positions
    const positionedSteps = targetSteps.filter(s => s.x !== undefined && s.y !== undefined);
    if (positionedSteps.length === 0) return;

    const xs = positionedSteps.map(s => s.x as number);
    const ys = positionedSteps.map(s => s.y as number);

    const pad = 60; // Padding around the extreme nodes/bounds for zoom buffer

    const minX = Math.min(...xs) - 65 - pad;
    const maxX = Math.max(...xs) + 65 + pad;
    const minY = Math.min(...ys) - 28 - pad;
    const maxY = Math.max(...ys) + 28 + pad;

    const contentW = maxX - minX;
    const contentH = maxY - minY;

    if (contentW <= 0 || contentH <= 0) return;

    // Determine the optimal zoom factor such that content fits inside container
    const zoomX = containerW / contentW;
    const zoomY = containerH / contentH;
    let newZoom = Math.min(zoomX, zoomY);

    // Bound the zoom factor inside reasonable limits
    newZoom = Math.max(0.45, Math.min(1.8, newZoom));

    // Calculate center of the bounding box of content
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    // We want the center of the content to align with the center of the viewport
    // pan = containerCenter - zoom * contentCenter
    const panX = containerW / 2 - newZoom * centerX;
    const panY = containerH / 2 - newZoom * centerY;

    setZoom(newZoom);
    setPan({ x: panX, y: panY });
  };

  // Node selection/dragging
  const handleNodeMouseDown = (e: MouseEvent, nodeId: string) => {
    e.stopPropagation();
    if (activeTool === "pan") return;

    const step = steps.find((s) => s.id === nodeId);
    if (!step || !canvasRef.current) return;

    setSelectedNodeId(nodeId);

    const rect = canvasRef.current.getBoundingClientRect();
    const mouseXInSvg = (e.clientX - rect.left - pan.x) / zoom;
    const mouseYInSvg = (e.clientY - rect.top - pan.y) / zoom;

    setDraggingNodeId(nodeId);
    setDragOffset({
      x: mouseXInSvg - (step.x || 0),
      y: mouseYInSvg - (step.y || 0)
    });
  };

  // Node creation
  const handleAddVisualNode = (type: 'START' | 'END' | 'ACTIVITY' | 'DECISION') => {
    // Determine random place in center of viewport
    const viewportCenterX = (-pan.x + 350) / zoom;
    const viewportCenterY = (-pan.y + 200) / zoom;

    const names = {
      START: "Início do Fluxo",
      END: "Fim do Processo",
      ACTIVITY: "Nova Atividade Operacional",
      DECISION: "Análise de Decisão / Qualidade"
    };

    const newStep: ProcessStep = {
      id: `step-${Date.now()}`,
      name: `${names[type]} #${steps.length + 1}`,
      resource: "Operador de Linha",
      resourceCount: 1,
      processingTime: 4.5,
      standardDeviation: 0.8,
      yieldRate: 0.98,
      setupTime: 0,
      description: "Nova etapa criada no mapeamento de processo operacional.",
      x: viewportCenterX,
      y: viewportCenterY,
      shapeType: type
    };

    // If there is a current selected node, automatically link it to this new one
    if (selectedNodeId) {
      setSteps((prev) => {
        return prev.map((s) => {
          if (s.id === selectedNodeId) {
            return { ...s, nextStepId: newStep.id };
          }
          return s;
        }).concat(newStep);
      });
    } else {
      // Auto-connect last node to new node if feasible
      setSteps((prev) => {
        if (prev.length > 0) {
          const updated = [...prev];
          const last = updated[updated.length - 1];
          if (!last.nextStepId && last.shapeType !== 'END') {
            last.nextStepId = newStep.id;
          }
          return updated.concat(newStep);
        }
        return prev.concat(newStep);
      });
    }

    setSelectedNodeId(newStep.id);
  };

  // Update properties of the active selected node
  const handleUpdateSelectedNode = (field: keyof ProcessStep, value: any) => {
    if (!selectedNodeId) return;
    setSteps((prev) =>
      prev.map((step) => (step.id === selectedNodeId ? { ...step, [field]: value } : step))
    );
  };

  // Keyboard shortcut listener to move selected nodes
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedNodeId) return;
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT") {
        return;
      }

      let dx = 0;
      let dy = 0;
      const stepSize = e.shiftKey ? 50 : 10;

      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") dx = -stepSize;
      else if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") dx = stepSize;
      else if (e.key === "ArrowUp" || e.key === "w" || e.key === "W") dy = -stepSize;
      else if (e.key === "ArrowDown" || e.key === "s" || e.key === "S") dy = stepSize;

      if (dx !== 0 || dy !== 0) {
        e.preventDefault();
        setSteps((prev) =>
          prev.map((step) =>
            step.id === selectedNodeId
              ? {
                  ...step,
                  x: Math.max(20, Math.min(2000, (step.x || 100) + dx)),
                  y: Math.max(20, Math.min(2000, (step.y || 100) + dy)),
                }
              : step
          )
        );
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedNodeId, setSteps]);

  // Duplicate node
  const handleDuplicateSelectedNode = () => {
    if (!selectedNodeId) return;
    const stepToDuplicate = steps.find((s) => s.id === selectedNodeId);
    if (!stepToDuplicate) return;

    const newStep: ProcessStep = {
      ...stepToDuplicate,
      id: `step-${Date.now()}`,
      name: `${stepToDuplicate.name} (Cópia)`,
      x: (stepToDuplicate.x || 100) + 40,
      y: (stepToDuplicate.y || 100) + 40,
    };

    setSteps((prev) => prev.concat(newStep));
    setSelectedNodeId(newStep.id);
  };

  // Auto Layout Organizer
  const handleAutoLayout = () => {
    const arranged = steps.map((step, idx) => ({
      ...step,
      x: 120 + (idx % 3) * 240,
      y: 100 + Math.floor(idx / 3) * 160,
    }));
    setSteps(arranged);
    setTimeout(() => {
      handleZoomToFit(arranged);
    }, 100);
  };

  // Delete node
  const handleDeleteSelectedNode = () => {
    if (!selectedNodeId) return;
    if (steps.length <= 1) {
      warning("O processo precisa conter pelo menos uma etapa para ser simulado!");
      return;
    }
    setSteps((prev) => {
      const filtered = prev.filter((s) => s.id !== selectedNodeId);
      // Clean up connections pointing to this deleted node
      return filtered.map((s) => {
        const u = { ...s };
        if (u.nextStepId === selectedNodeId) delete u.nextStepId;
        if (u.yesStepId === selectedNodeId) delete u.yesStepId;
        if (u.noStepId === selectedNodeId) delete u.noStepId;
        return u;
      });
    });
    setSelectedNodeId(null);
  };

  const selectedStep = steps.find((s) => s.id === selectedNodeId);

  return (
    <div className="border border-[#1A1A1A]/10 bg-white rounded-none shadow-sm flex flex-col h-[680px] relative overflow-hidden">
      
      {/* 📥 DECK DA CADEIA DE VALOR INTEGRADA (Navegação Direta) */}
      <div className="bg-[#FAF9F6] border-b border-[#1A1A1A]/10 px-4 py-2 flex flex-col gap-1.5 z-10 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[9px] font-black uppercase text-[#1A1A1A]/40 font-mono tracking-wider">
              Nível Ativo (Drill-down):
            </span>
            <button
              type="button"
              onClick={() => {
                setViewLevel("CADEIA");
                setActiveCapaAreaId(null);
                setSelectedNodeId(null);
              }}
              className={`text-[9px] font-mono font-black uppercase px-2.5 py-0.8 transition-all border cursor-pointer ${
                viewLevel === "CADEIA" && activeCapaAreaId === null
                  ? "bg-[#C49746] text-white border-transparent shadow-xs"
                  : "bg-white hover:bg-gray-100 border-gray-200 text-gray-700"
              }`}
              title="Voltar para a Visão Geral de Porter (Nível Corporativo 1)"
            >
              🌎 Cadeia de Valor Porter
            </button>
            
            <span className="text-gray-400 text-[10px] font-bold">➔</span>

            <button
              type="button"
              onClick={() => {
                setActiveCapaAreaId(activeAreaId);
              }}
              className={`text-[9px] font-mono font-black uppercase px-2.5 py-0.8 transition-all border cursor-pointer ${
                activeCapaAreaId !== null
                  ? "bg-purple-700 text-white border-transparent shadow-xs"
                  : "bg-white hover:bg-gray-100 border-gray-200 text-gray-700"
              }`}
              title="Exibir Capa do Processo (SIPOC e Tarefas Operacionais)"
            >
              📋 Capa do Processo ({CORPORATE_AREAS.find(a => a.id === activeAreaId)?.name.split(",")[0]})
            </button>
            
            <span className="text-gray-400 text-[10px] font-bold">➔</span>
            
            <button
              type="button"
              onClick={() => {
                setViewLevel("PROCESSO");
                setActiveCapaAreaId(null);
              }}
              className={`text-[9px] font-mono font-black uppercase px-2.5 py-0.8 transition-all border cursor-pointer ${
                viewLevel === "PROCESSO" && activeCapaAreaId === null
                  ? "bg-[#1A1A1A] text-white border-transparent shadow-xs"
                  : "bg-white hover:bg-gray-100 border-gray-200 text-gray-700"
              }`}
              title="Explodir nas atividades detalhadas da área ativa (Nível 2)"
            >
              ⚙️ Fluxo de Processo Operacional
            </button>

            {(viewLevel === "PROCESSO" || activeCapaAreaId !== null) && (
              <>
                <span className="text-gray-300 text-[10px] font-bold">➔</span>
                <span className="text-[9.5px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 border border-amber-100 rounded-sm font-sans flex items-center gap-1 animate-fade-in shrink-0">
                  <span>{CORPORATE_AREAS.find(a => a.id === (activeCapaAreaId || activeAreaId))?.icon}</span>
                  <span className="uppercase">{CORPORATE_AREAS.find(a => a.id === (activeCapaAreaId || activeAreaId))?.name.split(",")[0]}</span>
                </span>
              </>
            )}
          </div>
          <span className="text-[8.5px] font-mono text-gray-400 hidden lg:inline font-bold">
            💡 Dica: Clique duplo nas formas para drill-down fino de subprocessos e documentação
          </span>
        </div>
        
        <div className="grid grid-cols-3 md:grid-cols-9 gap-1.5">
          {CORPORATE_AREAS.map((area) => {
            const isSelected = activeAreaId === area.id;
            const isSupport = area.type === "SUPPORT";
            return (
              <button
                key={area.id}
                onClick={() => onSwitchArea?.(area.id)}
                className={`py-1.5 px-2 text-left rounded-sm transition-all duration-150 cursor-pointer border flex flex-col justify-between h-11 ${
                  isSelected
                    ? isSupport
                      ? "border-[#7C3AED] bg-indigo-50/70 text-indigo-950 shadow-[1px_1px_0px_0px_rgba(124,58,237,1)]"
                      : "border-[#C49746] bg-amber-50/70 text-amber-950 shadow-[1px_1px_0px_0px_rgba(180,83,9,1)]"
                    : "border-gray-200/65 bg-white text-gray-700 hover:bg-gray-50 hover:border-gray-300"
                }`}
                title={`Mapear e fiscalizar atividades de ${area.name}`}
              >
                <div className="flex items-center gap-1 overflow-hidden w-full">
                  <span className="text-xs shrink-0">{area.icon}</span>
                  <span className="text-[8.5px] font-extrabold uppercase font-mono tracking-tight truncate">
                    {area.name.replace("Finanças", "Fin").replace("Cultura", "RH").replace("Compliance", "Riscos").replace("Ciência", "IA / P&D").replace("Suprimentos", "Inbound").replace("Execução", "Core Ops").replace("Expedição", "Outbound").replace("Vendas", "Vendas/CRM").split(",")[0]}
                  </span>
                </div>
                <span className="text-[7.5px] font-bold text-gray-400 block tracking-wider uppercase font-mono leading-none">
                  {area.type === "SUPPORT" ? "💼 Suporte" : "⚙️ Core"}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      
      {/* Top Controls Toolbar */}
      <div className="bg-[#F5F2ED] border-b border-[#1A1A1A]/10 px-4 py-3 flex flex-wrap gap-4 items-center justify-between z-10">
        <div className="flex items-center gap-2">
          {viewLevel === "CADEIA" ? (
            <Map size={16} className="text-amber-800 animate-pulse" />
          ) : (
            <Layers size={16} className="text-[#C49746]" />
          )}
          <h3 className="text-xs font-black uppercase tracking-widest text-[#1A1A1A]">
            {viewLevel === "CADEIA" ? "Cadeia de Valor Corporativa Porter (Nível Macro 1)" : "Mapeador Visual de Atividades (Nível 2)"}
          </h3>
          <span className="text-[10px] text-[#1A1A1A]/50 hidden sm:inline">
            {viewLevel === "CADEIA" 
              ? "| Selecione qualquer setor para abrir as atividades operacionais internas" 
              : "| Arraste os postos de trabalho para organizar seu layout"}
          </span>
        </div>

        {/* Action Toolbar */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {viewLevel === "PROCESSO" && (
            /* Node insertions (only useful in Process Flowchart Design, hidden on Porter macro View) */
            <div className="flex items-center gap-1 bg-white/60 p-1 border border-[#1A1A1A]/10 rounded-sm">
              <span className="text-[8px] uppercase font-bold text-[#1A1A1A]/40 px-1 font-mono">Inserir Posto:</span>
              <button
                type="button"
                onClick={() => handleAddVisualNode("START")}
                className="px-2 py-0.5 text-[9px] font-bold uppercase bg-emerald-50 hover:bg-emerald-100 border border-emerald-600/30 text-emerald-800 rounded-sm cursor-pointer"
                title="Adicionar ponto inicial"
              >
                Início
              </button>
              <button
                type="button"
                onClick={() => handleAddVisualNode("ACTIVITY")}
                className="px-2 py-0.5 text-[9px] font-bold uppercase bg-blue-50 hover:bg-blue-100 border border-blue-600/30 text-blue-800 rounded-sm cursor-pointer"
                title="Adicionar Atividade operacional"
              >
                Atividade
              </button>
              <button
                type="button"
                onClick={() => handleAddVisualNode("DECISION")}
                className="px-2 py-0.5 text-[9px] font-bold uppercase bg-amber-50 hover:bg-amber-100 border border-amber-600/30 text-amber-800 rounded-sm cursor-pointer"
                title="Adicionar ponto de decisão"
              >
                Decisão
              </button>
              <button
                type="button"
                onClick={() => handleAddVisualNode("END")}
                className="px-2 py-0.5 text-[9px] font-bold uppercase bg-red-50 hover:bg-red-100 border border-red-600/30 text-red-800 rounded-sm cursor-pointer"
                title="Adicionar ponto terminal"
              >
                Fim
              </button>
            </div>
          )}

          {/* Interactive Tools selection */}
          <div className="flex rounded-sm border border-[#1A1A1A]/10 overflow-hidden bg-white">
            <button
              type="button"
              onClick={() => setActiveTool("select")}
              className={`p-1 px-2 text-[10px] uppercase font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                activeTool === "select" ? "bg-[#1A1A1A] text-white" : "hover:bg-gray-100 text-gray-700"
              }`}
              title="Mover e Selecionar Objetos"
            >
              Interagir
            </button>
            <button
              type="button"
              onClick={() => setActiveTool("pan")}
              className={`p-1 px-2 text-[10px] uppercase font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                activeTool === "pan" ? "bg-[#1A1A1A] text-white" : "hover:bg-gray-100 text-gray-700"
              }`}
              title="Arrastar Fundo do Canvas"
            >
              Fundo (Pan)
            </button>
          </div>

          {/* Zoom buttons */}
          <div className="flex bg-white border border-[#1A1A1A]/10 rounded-sm overflow-hidden">
            <button
              type="button"
              onClick={() => handleZoom(1.2)}
              className="p-1 px-2 hover:bg-gray-100 cursor-pointer"
              title="Aumentar Zoom (+)"
            >
              <ZoomIn size={12} />
            </button>
            <button
              onClick={() => handleZoom(0.8)}
              className="p-1 px-2 hover:bg-gray-100"
              title="Diminuir Zoom (-)"
            >
              <ZoomOut size={12} />
            </button>
            <button
              onClick={() => handleZoom(0)}
              className="p-1 px-2 hover:bg-gray-100 border-l border-[#1A1A1A]/5 text-[9px] uppercase font-bold"
              title="Redefinir para escala original (100%)"
            >
              100%
            </button>
            <button
              type="button"
              onClick={() => handleZoomToFit()}
              className="p-1 px-2 hover:bg-amber-50 border-l border-[#1A1A1A]/5 text-[9px] uppercase font-black text-[#C49746] flex items-center gap-0.5 cursor-pointer"
              title="Ajustar enquadramento e centralizar todo o fluxo (Zoom to Fit)"
            >
              <Maximize size={11} />
              <span>Ajustar</span>
            </button>
          </div>

          {/* Auto layout button */}
          <button
            onClick={handleAutoLayout}
            className="p-1 px-2 bg-white hover:bg-amber-50 border border-[#1A1A1A]/10 text-[9px] uppercase font-bold text-[#C49746] flex items-center gap-1.5 rounded-sm transition cursor-pointer shadow-2xs mr-1"
            title="Auto-organizar layout das etapas"
          >
            <RefreshCw size={11} />
            <span>Auto-Organizar</span>
          </button>

          {viewLevel === "PROCESSO" && (
            <>
              <button
                type="button"
                onClick={() => setShowSipocOverlay(prev => !prev)}
                className={`p-1 px-2 text-[9px] uppercase font-extrabold flex items-center gap-1 rounded-sm transition cursor-pointer border ${
                  showSipocOverlay 
                    ? "bg-indigo-50 border-indigo-600 text-indigo-700 shadow-2xs" 
                    : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                }`}
                title="Mostrar Fornecedores, Insumos, Entregas e Clientes de cada Etapa"
              >
                <span>📦 SIPOC Integrado: {showSipocOverlay ? "ON" : "OFF"}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAreaLinks(prev => !prev)}
                className={`p-1 px-2 text-[9px] uppercase font-extrabold flex items-center gap-1 rounded-sm transition cursor-pointer border ${
                  showAreaLinks 
                    ? "bg-purple-50 border-purple-600 text-purple-700 shadow-2xs" 
                    : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                }`}
                title="Mostrar conexões para outras áreas e departamentos"
              >
                <span>🏢 Vínculos de Áreas: {showAreaLinks ? "ON" : "OFF"}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Container: Split View (Canvas on default, Editing Side Drawer on select) */}
      <div className="flex-grow flex relative row">
        
        {steps.length === 0 ? (
          <div className="absolute inset-0 bg-[#FAF9F6] flex items-center justify-center z-30 p-4 overflow-y-auto">
            <EmptyState 
              type="no_process"
              primaryAction={{
                label: "Mapear processo",
                onClick: () => {
                  const firstStep: ProcessStep = {
                    id: "step-1",
                    name: "Início do Fluxo",
                    description: "Triagem inicial de demanda ou solicitações de clientes operacionais.",
                    resource: "Operador Líder",
                    resourceCount: 1,
                    processingTime: 5,
                    standardDeviation: 1,
                    yieldRate: 0.95,
                    setupTime: 0,
                    completed: false,
                    requiredInputs: ["Demanda do Cliente"],
                    suppliers: ["Clientes"],
                    outputs: ["Demanda Triada"],
                    customers: ["Planejamento"],
                    x: 100,
                    y: 200,
                    shapeType: "START"
                  };
                  setSteps([firstStep]);
                }
              }}
              secondaryAction={{
                label: "Usar modelo pronto",
                onClick: openTemplatesHub || (() => {
                  setSteps(INITIAL_STEPS);
                })
              }}
              tertiaryAction={{
                label: "Importar planilha",
                onClick: () => {
                  const importedSteps: ProcessStep[] = [
                    {
                      id: "imp-1",
                      name: "Carga de Dados Base",
                      description: "Importação e saneamento eletrônico de dados cadastrais.",
                      resource: "Assistente de Operações",
                      resourceCount: 1,
                      processingTime: 3.5,
                      standardDeviation: 0.5,
                      yieldRate: 0.98,
                      setupTime: 0,
                      completed: false,
                      requiredInputs: ["Formulário Inicial"],
                      suppliers: ["Parceiros Comerciais"],
                      outputs: ["Base Saneada"],
                      customers: ["Analista de Suporte"],
                      x: 80,
                      y: 150,
                      shapeType: "START",
                      nextStepId: "imp-2"
                    },
                    {
                      id: "imp-2",
                      name: "Operação Central LSS",
                      description: "Validação estocástica fina das restrições de gargalo de produção.",
                      resource: "Analista de Processos",
                      resourceCount: 1,
                      processingTime: 8,
                      standardDeviation: 2,
                      yieldRate: 0.92,
                      setupTime: 0,
                      completed: false,
                      requiredInputs: ["Base Saneada"],
                      suppliers: ["Assistente de Operações"],
                      outputs: ["Análise de Capacidade"],
                      customers: ["Diretor de Qualidade"],
                      x: 300,
                      y: 150,
                      shapeType: "ACTIVITY",
                      nextStepId: "imp-3"
                    },
                    {
                      id: "imp-3",
                      name: "Despacho Geral",
                      description: "Selagem do andamento das tarefas e notificação ao SLA de entrega.",
                      resource: "Operador de Expedição",
                      resourceCount: 1,
                      processingTime: 2.2,
                      standardDeviation: 0.2,
                      yieldRate: 0.99,
                      setupTime: 0,
                      completed: false,
                      requiredInputs: ["Análise de Capacidade"],
                      suppliers: ["Analista de Processos"],
                      outputs: ["Pedido Despachado"],
                      customers: ["Cliente Final"],
                      x: 520,
                      y: 150,
                      shapeType: "END"
                    }
                  ];
                  setSteps(importedSteps);
                }
              }}
            />
          </div>
        ) : null}
        
        {/* Floating Instruction Tips */}
        {showHelpTips ? (
          <div 
            className="absolute top-3 left-3 bg-white/95 border border-[#1A1A1A]/10 p-2.5 text-[9px] text-[#1A1A1A]/70 z-20 max-w-xs space-y-1 rounded-sm shadow-sm"
            onMouseDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="font-bold flex items-center justify-between gap-3 text-[#1A1A1A] border-b border-[#1A1A1A]/5 pb-1 mb-1">
              <div className="flex items-center gap-1">
                <HelpCircle size={10} className="text-[#C49746]" />
                <span>Atalhos rápidos do mapeador:</span>
              </div>
              <button 
                type="button"
                onClick={() => setShowHelpTips(false)}
                className="text-gray-400 hover:text-red-600 font-bold px-1 rounded-sm cursor-pointer hover:bg-gray-100 transition-colors"
                title="Esconder ajuda"
              >
                ✕
              </button>
            </div>
            <p>• Clique nas formas para editar propriedades e fluxos no painel.</p>
            <p>• Arraste as formas para reposicionar no espaço visual.</p>
            <p>• Escolha o modo <strong>'Fundo (Pan)'</strong> para arrastar a prancheta inteira.</p>
            <p>• Passe o mouse ou clique no ícone 💡 no topo de cada etapa para ver os <strong>Tooltips Inteligentes</strong> com diagnósticos Six Sigma e conselhos específicos do setor.</p>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowHelpTips(true)}
            className="absolute top-3 left-3 bg-white hover:bg-amber-50 text-gray-700 border border-[#1A1A1A]/15 p-1 px-1.5 text-[8.5px] font-bold uppercase flex items-center gap-1 z-20 rounded-sm shadow-xs cursor-pointer transition-colors"
            title="Dicas e atalhos rápidos"
            onMouseDown={(e) => e.stopPropagation()}
          >
            <HelpCircle size={10} className="text-[#C49746]" />
            <span>Ver Atalhos</span>
          </button>
        )}

        {/* Interactive SVG Canvas Area */}
        <div className="flex-grow bg-[#FDFCFB] h-full overflow-hidden relative" style={{ cursor: activeTool === "pan" ? "grab" : "default" }}>
          
          {/* 📋 CAPA DE PROCESSO INTERATIVA OVERLAY */}
          {activeCapaAreaId !== null && (
            <div className="absolute inset-0 bg-[#FAF9F6] z-30 overflow-y-auto p-5 md:p-6 flex flex-col gap-6 animate-fade-in font-sans text-left">
              
              {/* Navegação e botões rápidos */}
              <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-3">
                <button
                  type="button"
                  onClick={() => setActiveCapaAreaId(null)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold uppercase border border-[#1A1A1A]/20 bg-white hover:bg-gray-50 text-gray-700 cursor-pointer transition-colors font-sans"
                >
                  ← Voltar para a Cadeia
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    setViewLevel("PROCESSO");
                    if (activeCapaAreaId) {
                      onSwitchArea?.(activeCapaAreaId);
                    }
                    setActiveCapaAreaId(null);
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-black uppercase text-white bg-amber-800 hover:bg-amber-900 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] border border-[#1A1A1A] cursor-pointer transition-colors font-sans"
                  title="Acessar o fluxograma visual interativo de postos com cálculos estocásticos"
                >
                  Fazer Drill-Down (Focar Fluxograma) ➔
                </button>
              </div>

              {/* Ficha técnica da Capa de Processo */}
              {(() => {
                const areaObj = CORPORATE_AREAS.find(a => a.id === activeCapaAreaId);
                const sipocData = REGIONAL_SIPOC_PRESETS[activeCapaAreaId];
                if (!areaObj || !sipocData) return null;
                
                return (
                  <>
                    <div className="border border-[#1A1A1A] bg-white p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
                      <div className="flex items-start gap-4">
                        <span className="text-4xl p-2 bg-gray-50 border border-gray-200 leading-none shrink-0 rounded-sm">{areaObj.icon}</span>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-[8px] font-bold font-mono tracking-widest px-2 py-0.5 rounded-sm uppercase text-white ${
                              areaObj.type === "SUPPORT" ? "bg-indigo-700 animate-pulse" : "bg-amber-700 animate-pulse"
                            }`}>
                              {areaObj.type === "SUPPORT" ? "Processo de Suporte" : "Processo Primário (Core)"}
                            </span>
                            <span className="text-[8px] font-bold font-mono text-gray-400 bg-gray-150 px-1.5 py-0.5 rounded-sm">
                              ISO 9001 / SIX SIGMA FRAMEWORK
                            </span>
                          </div>
                          <h2 className="text-xl font-serif text-gray-950 mt-1.5 font-bold leading-tight">
                            Capa do Processo: {areaObj.name}
                          </h2>
                          <p className="text-xs text-gray-600 mt-1 leading-relaxed max-w-xl">
                            {areaObj.shortDesc}
                          </p>
                        </div>
                      </div>
                      
                      {/* Frameworks */}
                      <div className="md:text-right">
                        <span className="text-[8.5px] font-mono uppercase font-black tracking-widest block text-gray-400 mb-1.5">
                          Metodologias Ativas:
                        </span>
                        <div className="flex md:justify-end gap-1 flex-wrap">
                          {areaObj.frameworks.map((fw, idx) => (
                            <span key={idx} className="text-[8.5px] font-bold font-mono bg-[#FFFBEB] text-[#C49746] border border-amber-200 px-2 py-0.5 rounded-sm">
                              {fw}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* SIPOC Gabarito de Fronteiras */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-gray-800 font-mono">📦 MAPEAMENTO SIPOC RESUMIDO</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                        
                        {/* Suppliers */}
                        <div className="bg-white border border-[#1A1A1A]/15 p-4 flex flex-col justify-between hover:border-indigo-600/30 transition-colors">
                          <div>
                            <div className="flex items-center justify-between border-b border-gray-100 pb-1.5 mb-2.5">
                              <span className="text-xl font-bold text-indigo-700 font-serif">S</span>
                              <span className="text-[7.5px] font-bold font-mono uppercase text-gray-400">Suppliers</span>
                            </div>
                            <p className="text-xs text-gray-700 leading-relaxed">{sipocData.supplier}</p>
                          </div>
                          <span className="text-[8px] font-black text-indigo-500 font-mono mt-3 text-right block">ENTRADAS ➔</span>
                        </div>

                        {/* Inputs */}
                        <div className="bg-white border border-[#1A1A1A]/15 p-4 flex flex-col justify-between hover:border-indigo-600/30 transition-colors">
                          <div>
                            <div className="flex items-center justify-between border-b border-gray-100 pb-1.5 mb-2.5">
                              <span className="text-xl font-bold text-indigo-700 font-serif">I</span>
                              <span className="text-[7.5px] font-bold font-mono uppercase text-gray-400">Inputs</span>
                            </div>
                            <p className="text-xs text-gray-700 leading-relaxed">{sipocData.input}</p>
                          </div>
                          <span className="text-[8px] font-black text-indigo-500 font-mono mt-3 text-right block">PROCESSO ➔</span>
                        </div>

                        {/* Process */}
                        <div className="bg-amber-50/20 border-2 border-[#1A1A1A]/40 p-4 flex flex-col justify-between shadow-2xs hover:border-[#1A1A1A] transition-colors">
                          <div>
                            <div className="flex items-center justify-between border-b border-gray-200 pb-1.5 mb-2.5">
                              <span className="text-xl font-bold text-amber-900 font-serif">P</span>
                              <span className="text-[7.5px] font-bold font-mono uppercase text-[#C49746]">Process</span>
                            </div>
                            <p className="text-xs text-amber-950 font-serif leading-relaxed">{sipocData.processDesc}</p>
                          </div>
                          <span className="text-[8.5px] font-black text-[#C49746] font-mono mt-3 text-right block">SAÍDAS ➔</span>
                        </div>

                        {/* Outputs */}
                        <div className="bg-white border border-[#1A1A1A]/15 p-4 flex flex-col justify-between hover:border-teal-600/30 transition-colors">
                          <div>
                            <div className="flex items-center justify-between border-b border-gray-100 pb-1.5 mb-2.5">
                              <span className="text-xl font-bold text-teal-700 font-serif">O</span>
                              <span className="text-[7.5px] font-bold font-mono uppercase text-gray-400">Outputs</span>
                            </div>
                            <p className="text-xs text-gray-700 leading-relaxed">{sipocData.output}</p>
                          </div>
                          <span className="text-[8px] font-black text-teal-500 font-mono mt-3 text-right block">CLIENTES ➔</span>
                        </div>

                        {/* Customers */}
                        <div className="bg-white border border-[#1A1A1A]/15 p-4 flex flex-col justify-between hover:border-teal-600/30 transition-colors">
                          <div>
                            <div className="flex items-center justify-between border-b border-gray-100 pb-1.5 mb-2.5">
                              <span className="text-xl font-bold text-teal-700 font-serif">C</span>
                              <span className="text-[7.5px] font-bold font-mono uppercase text-gray-400">Customers</span>
                            </div>
                            <p className="text-xs text-gray-700 leading-relaxed">{sipocData.customer}</p>
                          </div>
                          <span className="text-[8px] font-black text-teal-600 font-mono mt-3 text-right block">VALOR AGREGADO ✓</span>
                        </div>

                      </div>
                    </div>

                    {/* Lista de tarefas operacionais com estados de conclusão */}
                    <div className="space-y-3 mt-2 font-sans">
                      <div className="flex items-center justify-between border-b border-gray-300 pb-1.5 flex-wrap gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-gray-800 font-mono">📋 TAREFAS OPERACIONAIS E CHECKLIST DE ROLLOUT</span>
                        <div className="flex items-center gap-2">
                          {steps.length > 0 && (
                            <button
                              onClick={() => setSteps([])}
                              className="text-[9px] font-mono font-bold text-red-650 hover:text-red-800 px-2.5 py-0.5 border border-red-200 hover:bg-red-50 rounded-sm shrink-0 cursor-pointer transition-all"
                            >
                              Limpar Fluxo
                            </button>
                          )}
                          <span className="text-[9.5px] text-gray-500 font-bold bg-white border border-gray-200 px-2 py-0.5 rounded-sm font-mono">
                            Progresso: {steps.filter(s => s.completed).length} de {steps.length} concluídas ({steps.length ? Math.round((steps.filter(s => s.completed).length / steps.length) * 100) : 0}%)
                          </span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {steps.map((step) => {
                          const isDone = !!step.completed;
                          return (
                            <div 
                              key={step.id} 
                              onClick={() => toggleStepCompletion(step.id)}
                              className={`border p-3.5 flex items-start gap-3 cursor-pointer transition-all rounded-sm ${
                                isDone 
                                  ? "bg-emerald-50/40 border-emerald-600/40 shadow-2xs hover:bg-emerald-50/65" 
                                  : "bg-white border-gray-200/90 hover:border-gray-400 hover:bg-gray-50/20"
                              }`}
                            >
                              <input 
                                type="checkbox" 
                                checked={isDone}
                                onChange={() => {}} // handled by parent div onClick
                                className="mt-1 h-4 w-4 text-emerald-800 accent-emerald-600 shrink-0 cursor-pointer" 
                                onClick={(e) => e.stopPropagation()}
                              />
                              
                              <div className="flex-grow min-w-0 font-sans">
                                <div className="flex items-start justify-between gap-2">
                                  <h4 className={`text-xs font-bold leading-tight truncate ${isDone ? "text-emerald-950 line-through opacity-75" : "text-gray-950"}`}>
                                    {step.name}
                                  </h4>
                                  <span className={`text-[8px] font-bold font-mono px-1.5 py-0.2 shrink-0 rounded-sm ${
                                    isDone 
                                      ? "bg-emerald-200 text-emerald-900" 
                                      : "bg-amber-100 text-[#C49746] border border-amber-200"
                                  }`}>
                                    {isDone ? "CONCLUÍDO" : "PENDENTE"}
                                  </span>
                                </div>
                                
                                <p className="text-[10px] text-gray-500 mt-1 line-clamp-1 italic">
                                  {step.description || "Sem descrição operacional cadastrada."}
                                </p>
                                
                                <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-dashed border-gray-100 text-[8.5px] font-mono text-gray-400">
                                  <span className="flex items-center gap-0.5">
                                    👤 {step.resource}
                                  </span>
                                  <span>•</span>
                                  <span>
                                    Ciclo: <strong>{step.processingTime.toFixed(1)}m</strong>
                                  </span>
                                  <span>•</span>
                                  <span>
                                    Acurácia: <strong>{(step.yieldRate * 100).toFixed(0)}%</strong>
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </>
                );
              })()}

            </div>
          )}

          <svg
            ref={canvasRef}
            className="w-full h-full select-none absolute inset-0"
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            onMouseLeave={handleCanvasMouseUp}
          >
            {/* Markers Definition inside defs for Arrow Pointers */}
            <defs>
              <marker
                id="arrow-std"
                viewBox="0 0 10 10"
                refX="23" // Offset so arrow fits node border edges smoothly
                refY="5"
                markerWidth="6"
                markerHeight="6"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#1A1A1A" />
              </marker>

              <marker
                id="arrow-std-bottleneck"
                viewBox="0 0 10 10"
                refX="23"
                refY="5"
                markerWidth="6"
                markerHeight="6"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#C49746" />
              </marker>

              <marker
                id="arrow-yes"
                viewBox="0 0 10 10"
                refX="23"
                refY="5"
                markerWidth="5"
                markerHeight="5"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#10B981" />
              </marker>

              <marker
                id="arrow-no"
                viewBox="0 0 10 10"
                refX="23"
                refY="5"
                markerWidth="5"
                markerHeight="5"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#EF4444" />
              </marker>
            </defs>

            {/* Grid Pattern Background */}
            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1A1A1A" strokeWidth="0.5" strokeOpacity="0.05" />
                </pattern>
              </defs>
              <rect width="3000" height="3000" fill="url(#grid)" x="-1500" y="-1500" />

              {/* GRID AND MAIN RENDER SELECTOR */}
              {viewLevel === "CADEIA" ? (
                // =============== CADEIA DE VALOR PORTER (NÍVEL 1) ===============
                <g transform="translate(0, 0)">
                  <defs>
                    <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FEF3C7" stopOpacity="0.9" />
                      <stop offset="100%" stopColor="#FDE68A" stopOpacity="0.95" />
                    </linearGradient>
                  </defs>

                  {/* SUPPORT PROCESSES DOTTED FRAME */}
                  <rect
                    x="50"
                    y="42"
                    width="668"
                    height="238"
                    fill="#FAF9F5"
                    stroke="#1A1A1A"
                    strokeWidth="0.8"
                    strokeDasharray="2,2"
                    opacity="0.4"
                    rx="6"
                  />
                  <text
                    x="60"
                    y="36"
                    fill="#1A1A1A"
                    opacity="0.5"
                    fontSize="7.5"
                    fontWeight="black"
                    fontFamily="monospace"
                    letterSpacing="1.2"
                  >
                    💼 PROCESSOS DE INFRAESTRUTURA E APOIO CORPORATIVO
                  </text>

                  {/* CORE PROCESSES DOTTED FRAME */}
                  <rect
                    x="50"
                    y="298"
                    width="668"
                    height="168"
                    fill="#FDFDFD"
                    stroke="#1A1A1A"
                    strokeWidth="0.8"
                    strokeDasharray="2,2"
                    opacity="0.4"
                    rx="6"
                  />
                  <text
                    x="60"
                    y="292"
                    fill="#1A1A1A"
                    opacity="0.5"
                    fontSize="7.5"
                    fontWeight="black"
                    fontFamily="monospace"
                    letterSpacing="1.2"
                  >
                    ⚙️ ATIVIDADES PRIMÁRIAS E FLUXOS DE VALOR CORE
                  </text>

                  {/* 1. SUPPORT PROCESSES (5 rows) */}
                  {CORPORATE_AREAS.filter(a => a.type === "SUPPORT").map((area, sIdx) => {
                    const x = 60;
                    const y = 48 + (sIdx * 45);
                    const w = 648;
                    const h = 40;
                    const isHovered = hoveredAreaId === area.id;
                    const isActive = activeAreaId === area.id;

                    return (
                      <g
                        key={area.id}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredAreaId(area.id)}
                        onMouseLeave={() => setHoveredAreaId(null)}
                        onClick={() => {
                          if (onSwitchArea) onSwitchArea(area.id);
                          setActiveCapaAreaId(area.id);
                          setSelectedNodeId(null);
                        }}
                      >
                        <rect
                          x={x}
                          y={y}
                          width={w}
                          height={h}
                          rx="4"
                          ry="4"
                          fill={isHovered ? "#F5F3FF" : isActive ? "#F5F3FF" : "#FFFFFF"}
                          stroke={isHovered ? "#6366F1" : isActive ? "#7C3AED" : "rgba(26,26,26,0.2)"}
                          strokeWidth={isHovered || isActive ? 2 : 1.2}
                          className="transition-all duration-200"
                        />
                        <foreignObject
                          x={x}
                          y={y}
                          width={w}
                          height={h}
                          className="pointer-events-none"
                        >
                          <div className="p-2 h-full flex items-center justify-between font-sans">
                            <div className="flex items-center gap-2 overflow-hidden">
                              <span className="text-sm shrink-0">{area.icon}</span>
                              <div className="text-left w-full overflow-hidden">
                                <h4 className="text-[10px] font-black text-gray-900 leading-none uppercase tracking-tight truncate">
                                  {area.name}
                                </h4>
                                <p className="text-[8px] text-gray-500 leading-none mt-1 truncate max-w-[320px] sm:max-w-[420px]">
                                  {area.shortDesc}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0 pr-1">
                              <span className="text-[7.5px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-1.5 py-0.2 rounded-sm font-mono">
                                SUPORTE
                              </span>
                              <span className="text-[8px] font-black text-[#7C3AED] uppercase tracking-wide flex items-center gap-0.5 font-mono">
                                EXPLODIR ➔
                              </span>
                            </div>
                          </div>
                        </foreignObject>
                      </g>
                    );
                  })}

                  {/* 2. CORE PROCESSES (4 columns horizontal block sequential) */}
                  {CORPORATE_AREAS.filter(a => a.type === "CORE").map((area, cIdx) => {
                    const x = 60 + (cIdx * 165);
                    const y = 304;
                    const w = 155;
                    const h = 154;
                    const isHovered = hoveredAreaId === area.id;
                    const isActive = activeAreaId === area.id;

                    return (
                      <g
                        key={area.id}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredAreaId(area.id)}
                        onMouseLeave={() => setHoveredAreaId(null)}
                        onClick={() => {
                          if (onSwitchArea) onSwitchArea(area.id);
                          setActiveCapaAreaId(area.id);
                          setSelectedNodeId(null);
                        }}
                      >
                        <rect
                          x={x}
                          y={y}
                          width={w}
                          height={h}
                          rx="4"
                          ry="4"
                          fill={isHovered ? "#FFFBEB" : isActive ? "#FFFBEB" : "#FFFFFF"}
                          stroke={isHovered ? "#D97706" : isActive ? "#C49746" : "rgba(26,26,26,0.2)"}
                          strokeWidth={isHovered || isActive ? 2 : 1.2}
                          className="transition-all duration-200"
                        />
                        <foreignObject
                          x={x}
                          y={y}
                          width={w}
                          height={h}
                          className="pointer-events-none"
                        >
                          <div className="p-3 h-full flex flex-col justify-between font-sans text-left">
                            <div className="space-y-1.5 overflow-hidden">
                              <div className="flex items-center justify-between">
                                <span className="text-lg shrink-0">{area.icon}</span>
                                <span className="text-[7px] font-black text-amber-700 bg-amber-50 border border-amber-100 px-1.5 py-0.2 rounded-sm font-mono">
                                  PRIMÁRIO
                                </span>
                              </div>
                              <h4 className="text-[10px] font-black text-gray-950 uppercase tracking-tight leading-tight pt-1">
                                {area.name.replace(" & Triagem de Entrada", "").replace(" & Logística de Saída", "").replace(", CRM & Pós-Venda", "")}
                              </h4>
                              <p className="text-[8px] text-gray-500 leading-snug">
                                {area.shortDesc}
                              </p>
                            </div>
                            <div className="border-t border-gray-100 pt-1.5 flex items-center justify-between text-[8px] font-mono shrink-0">
                              <span className="text-gray-400 font-bold uppercase">VALOR</span>
                              <span className="font-extrabold text-[#C49746] flex items-center gap-0.5">
                                EXPLODIR ➔
                              </span>
                            </div>
                          </div>
                        </foreignObject>
                      </g>
                    );
                  })}

                  {/* 3. PORTER MARGIN VALUE ARROW CHEVRON (MARGIN OF VALUE TO THE RIGHT) */}
                  <g
                    className="cursor-help transition-all"
                    onMouseEnter={() => setHoveredAreaId("margin")}
                    onMouseLeave={() => setHoveredAreaId(null)}
                    onClick={() => {
                      setIsMarginDrawerOpen(true);
                    }}
                  >
                    <polygon
                      points="715,48 765,48 818,228 765,458 715,458 750,228"
                      fill={hoveredAreaId === "margin" ? "#FEF3C7" : "url(#gold-gradient)"}
                      stroke={hoveredAreaId === "margin" ? "#C49746" : "#D97706"}
                      strokeWidth={hoveredAreaId === "margin" ? 2 : 1}
                      className="transition-all duration-200"
                    />
                    
                    <text
                      x="755"
                      y="228"
                      fill="#78350F"
                      fontSize="9.5"
                      fontWeight="900"
                      fontFamily="monospace"
                      textAnchor="middle"
                      transform="rotate(-90 755 228)"
                      letterSpacing="3"
                    >
                      🎯 MARGEM DE VALOR
                    </text>
                  </g>
                </g>
              ) : (
                // =============== FLUXO DO PROCESSO OPERACIONAL DETALHADO (NÍVEL 2) ===============
                <>
                  {/* DRAW FLOW CONNECTIONS / ARROWS */}
                  {steps.map((step) => {
                    const sX = step.x ?? 100;
                    const sY = step.y ?? 100;
                    const arrowsToDraw: { targetId?: string; color: string; label?: string; marker: string }[] = [];

                    if (step.shapeType === "DECISION") {
                      // Connection branches
                      if (step.yesStepId) arrowsToDraw.push({ targetId: step.yesStepId, color: "#10B981", label: "Sim", marker: "arrow-yes" });
                      if (step.noStepId) arrowsToDraw.push({ targetId: step.noStepId, color: "#EF4444", label: "Não", marker: "arrow-no" });
                    }
                    
                    // Generic standard link
                    if (step.nextStepId) {
                      const isMainBtl = step.name === bottleneckStepName;
                      arrowsToDraw.push({ 
                        targetId: step.nextStepId, 
                        color: isMainBtl ? "#C49746" : "#1A1A1A", 
                        label: "", 
                        marker: isMainBtl ? "arrow-std-bottleneck" : "arrow-std" 
                      });
                    }

                    return arrowsToDraw.map((arrow, aIdx) => {
                      const target = steps.find((t) => t.id === arrow.targetId);
                      if (!target) return null;

                      const tX = target.x ?? 200;
                      const tY = target.y ?? 200;

                      // Render path curve
                      const midX = (sX + tX) / 2;
                      const midY = (sY + tY) / 2;
                      
                      // Simple quadratic bezier control points for beautiful layout curves
                      const pathData = `M ${sX} ${sY} Q ${midX + (tY - sY)*0.1} ${midY + (sX - tX)*0.1} ${tX} ${tY}`;

                      return (
                        <g key={`arrow-${step.id}-${aIdx}`}>
                          <path
                            d={pathData}
                            fill="none"
                            stroke={arrow.color}
                            strokeWidth="1.5"
                            strokeDasharray={step.shapeType === "DECISION" ? "2,2" : "none"}
                            markerEnd={`url(#${arrow.marker})`}
                            className="transition-all duration-300"
                            opacity={selectedNodeId === step.id || selectedNodeId === target.id ? 1 : 0.6}
                          />
                          {arrow.label && (
                            <foreignObject
                              x={midX - 15}
                              y={midY - 10}
                              width="30"
                              height="20"
                              className="overflow-visible"
                            >
                              <div 
                                className="text-[8px] font-bold text-center px-1 py-0.5 rounded-sm shadow-sm"
                                style={{ 
                                  backgroundColor: "white", 
                                  color: arrow.color, 
                                  border: `1px solid ${arrow.color}40` 
                                }}
                              >
                                {arrow.label}
                              </div>
                            </foreignObject>
                          )}
                        </g>
                      );
                    });
                  })}

                  {/* RENDER DYNAMIC SHAPES */}
                  {steps.map((step, idx) => {
                    const nodeX = step.x ?? 100;
                    const nodeY = step.y ?? 100;
                    const isSelected = selectedNodeId === step.id;
                    const isBottleneck = step.name === bottleneckStepName;
                    const advice = getSectorAdviceForStep(step, businessType, bottleneckStepName);

                    // Configure geometric rendering specs based on flowchart symbols
                    let shapeElement = null;
                    const nodeWidth = 130;
                    const nodeHeight = 56;

                    if (step.shapeType === "START" || step.shapeType === "END") {
                      // Ellipses for terminal symbols
                      shapeElement = (
                        <rect
                          x={-nodeWidth / 2}
                          y={-nodeHeight / 2}
                          width={nodeWidth}
                          height={nodeHeight}
                          rx={nodeHeight / 2}
                          ry={nodeHeight / 2}
                          fill={step.shapeType === "START" ? "#E6F4EA" : "#FCE8E6"}
                          stroke={step.shapeType === "START" ? "#137333" : "#C5221F"}
                          strokeWidth={isSelected ? 3 : 1.5}
                          className="transition-all duration-300 shadow-sm"
                        />
                      );
                    } else if (step.shapeType === "DECISION") {
                      // Diamonds for logic/decisions
                      const side = 60;
                      const pts = `0,${-side} ${side},0 0,${side} ${-side},0`;
                      shapeElement = (
                        <polygon
                          points={pts}
                          fill="#FEF7E0"
                          stroke="#F0B400"
                          strokeWidth={isSelected ? 3 : 1.5}
                          className="transition-all duration-300 shadow-sm"
                        />
                      );
                    } else {
                      // Standard process actions: rounded rectangles
                      shapeElement = (
                        <rect
                          x={-nodeWidth / 2}
                          y={-nodeHeight / 2}
                          width={nodeWidth}
                          height={nodeHeight}
                          rx="8"
                          fill={isBottleneck ? "#FDF2E9" : "white"}
                          stroke={isBottleneck ? "#C49746" : isSelected ? "#1A1A1A" : "rgba(26,26,26,0.3)"}
                          strokeWidth={isSelected ? 3 : isBottleneck ? 2.5 : 1.5}
                          className="transition-all duration-300 shadow-sm"
                        />
                      );
                    }

                    return (
                      <g
                        key={step.id}
                        transform={`translate(${nodeX}, ${nodeY})`}
                        className="cursor-move group"
                        onMouseDown={(e) => handleNodeMouseDown(e, step.id)}
                        onDoubleClick={(e) => {
                          e.stopPropagation();
                          if (onOpenDetails) onOpenDetails(step.id);
                        }}
                        title="Dê duplo clique para acessar as instruções e documentos operacionais"
                      >
                        {showSipocOverlay && (
                          <g pointerEvents="none">
                            {/* Left SIPOC Card: Supplier (S) & Input (I) */}
                            <g transform="translate(-155, -22)" className="opacity-85 group-hover:opacity-100 transition-opacity">
                              <rect 
                                width="84" 
                                height="44" 
                                rx="4" 
                                fill="#FAF9F5" 
                                stroke="#4F46E5" 
                                strokeWidth="0.8" 
                                strokeDasharray="3,2"
                                className="shadow-2xs" 
                              />
                              <rect width="84" height="10" fill="#4F46E5" rx="2" />
                              <text x="42" y="7" textAnchor="middle" fill="#FFFFFF" fontSize="6.5" fontWeight="black" fontFamily="monospace">
                                S &gt;&gt; I (INPUT)
                              </text>
                              <text x="5" y="21" fill="#4B5563" fontSize="6.2" fontWeight="bold" fontFamily="sans-serif">
                                Forn: <tspan fontWeight="normal" fill="#1E293B">{getSipocForStep(step, activeAreaId).supplier.length > 11 ? getSipocForStep(step, activeAreaId).supplier.substring(0,10) + "..." : getSipocForStep(step, activeAreaId).supplier}</tspan>
                              </text>
                              <text x="5" y="34" fill="#4B5563" fontSize="6.2" fontWeight="bold" fontFamily="sans-serif">
                                Entr: <tspan fontWeight="normal" fill="#1E293B">{getSipocForStep(step, activeAreaId).input.length > 11 ? getSipocForStep(step, activeAreaId).input.substring(0,10) + "..." : getSipocForStep(step, activeAreaId).input}</tspan>
                              </text>
                              <line x1="84" y1="22" x2="90" y2="22" stroke="#4F46E5" strokeWidth="1" strokeDasharray="1,1" />
                              <circle cx="90" cy="22" r="1.5" fill="#4F46E5" />
                            </g>

                            {/* Right SIPOC Card: Output (O) & Customer (C) */}
                            <g transform="translate(71, -22)" className="opacity-85 group-hover:opacity-100 transition-opacity">
                              <rect 
                                width="84" 
                                height="44" 
                                rx="4" 
                                fill="#FAF9F5" 
                                stroke="#0891B2" 
                                strokeWidth="0.8" 
                                strokeDasharray="3,2"
                                className="shadow-2xs" 
                              />
                              <rect width="84" height="10" fill="#0891B2" rx="2" />
                              <text x="42" y="7" textAnchor="middle" fill="#FFFFFF" fontSize="6.5" fontWeight="black" fontFamily="monospace">
                                O &gt;&gt; C (OUTPUT)
                              </text>
                              <text x="5" y="21" fill="#4B5563" fontSize="6.2" fontWeight="bold" fontFamily="sans-serif">
                                Saíd: <tspan fontWeight="normal" fill="#1E293B">{getSipocForStep(step, activeAreaId).output.length > 11 ? getSipocForStep(step, activeAreaId).output.substring(0,10) + "..." : getSipocForStep(step, activeAreaId).output}</tspan>
                              </text>
                              <text x="5" y="34" fill="#4B5563" fontSize="6.2" fontWeight="bold" fontFamily="sans-serif">
                                Cli: <tspan fontWeight="normal" fill="#1E293B">{getSipocForStep(step, activeAreaId).customer.length > 11 ? getSipocForStep(step, activeAreaId).customer.substring(0,10) + "..." : getSipocForStep(step, activeAreaId).customer}</tspan>
                              </text>
                              <line x1="-6" y1="22" x2="0" y2="22" stroke="#0891B2" strokeWidth="1" strokeDasharray="1,1" />
                              <circle cx="-6" cy="22" r="1.5" fill="#0891B2" />
                            </g>
                          </g>
                        )}

                        {/* Shadow halo for active bottlenecks */}
                        {isBottleneck && (
                          <circle
                            r="38"
                            fill="none"
                            stroke="#C49746"
                            strokeWidth="5"
                            strokeOpacity="0.15"
                            className="animate-ping pointer-events-none"
                          />
                        )}

                        {/* Geometric Node Shape */}
                        {shapeElement}

                        {/* Hotspot anchor points for visual cue */}
                        {isSelected && (
                          <>
                            <g className="opacity-60">
                              <circle cx="0" cy={-nodeHeight/2} r="4" fill="#1A1A1A" />
                              <circle cx={nodeWidth/2} cy="0" r="4" fill="#1A1A1A" />
                              <circle cx="0" cy={nodeHeight/2} r="4" fill="#1A1A1A" />
                              <circle cx={-nodeWidth/2} cy="0" r="4" fill="#1A1A1A" />
                            </g>

                            {/* Interactive floating quick action bar above the selected shape */}
                            <g transform={`translate(0, ${-nodeHeight/2 - 14})`}>
                              <rect
                                x="-65"
                                y="-10"
                                width="130"
                                height="20"
                                rx="4"
                                fill="#1D1D1F"
                                className="shadow-md"
                              />
                              {/* 🔍 DRILL DOWN MINI BUTTON */}
                              <g 
                                className="cursor-pointer text-amber-400 hover:text-amber-300 transition-colors" 
                                transform="translate(-40, 0)"
                                onDoubleClick={(e) => {
                                  e.stopPropagation();
                                  if (onOpenDetails) onOpenDetails(selectedStep.id);
                                }}
                              >
                                <rect x="-10" y="-10" width="20" height="20" fill="transparent" />
                                <circle cx="-1" cy="-1" r="3" fill="none" stroke="currentColor" strokeWidth="1.2" />
                                <line x1="1.2" y1="1.2" x2="4.5" y2="4.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                                <title>Acessar Subprocessos / Drill Down</title>
                              </g>
                              {/* Divider 1 */}
                              <line x1="-20" y1="-6" x2="-20" y2="6" stroke="#FFFFFF20" />
                              {/* Duplicate mini button */}
                              <g 
                                className="cursor-pointer hover:opacity-80" 
                                transform="translate(0, 0)"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDuplicateSelectedNode();
                                }}
                              >
                                <rect x="-10" y="-10" width="20" height="20" fill="transparent" />
                                <path
                                  d="M -5,-3 L -1,-3 L -1,5 L -5,5 Z M -1,-5 L 3,-5 L 3,3 L -1,3"
                                  fill="none"
                                  stroke="white"
                                  strokeWidth="1.2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <title>Duplicar Etapa</title>
                                </path>
                              </g>
                              {/* Divider 2 */}
                              <line x1="20" y1="-6" x2="20" y2="6" stroke="#FFFFFF20" />
                              {/* Delete mini button */}
                              <g 
                                className="cursor-pointer text-red-400 hover:text-red-300 transition-colors" 
                                transform="translate(40, 0)"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteSelectedNode();
                                }}
                              >
                                <rect x="-10" y="-10" width="20" height="20" fill="transparent" />
                                <path
                                  d="M -5,-5 L 5,-5 M -4,-5 L -4,4 A 1,1 0 0 0 -3,5 L 3,5 A 1,1 0 0 0 4,4 L 4,-5 M -2,-5 L -2,-7 A 1,1 0 0 1 -1,-8 L 1,-8 A 1,1 0 0 1 2,-7 L 2,-5"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="1.2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                                <title>Excluir Etapa</title>
                              </g>
                            </g>
                          </>
                        )}

                        {/* Bottleneck alert badge */}
                        {isBottleneck && (
                          <g transform={`translate(${nodeWidth/2 - 12}, ${-nodeHeight/2 + 6})`}>
                            <circle r="7" fill="#C49746" />
                            <text
                              fill="white"
                              fontSize="7"
                              fontWeight="bold"
                              textAnchor="middle"
                              y="2"
                              fontFamily="monospace"
                            >
                              !
                            </text>
                          </g>
                        )}

                        {/* Subprocesses & Links badge indicators */}
                        {step.subProcesses && step.subProcesses.length > 0 && (
                          <g 
                            transform={`translate(${-nodeWidth/2 + 10}, ${-nodeHeight/2 + 2})`} 
                            className="cursor-pointer hover:scale-110 transition-transform"
                            onDoubleClick={(e) => {
                              e.stopPropagation();
                              if (onOpenDetails) onOpenDetails(step.id);
                            }}
                            title={`Esta atividade possui ${step.subProcesses.length} subprocessos. Clique para ver.`}
                          >
                            <circle r="6" fill="#FEF3C7" stroke="#D97706" strokeWidth="0.8" />
                            <text
                              fill="#C49746"
                              fontSize="6.5"
                              fontWeight="black"
                              textAnchor="middle"
                              y="2"
                              fontFamily="sans-serif"
                            >
                              S
                            </text>
                          </g>
                        )}

                        {step.linkedProcesses && step.linkedProcesses.length > 0 && (
                          <g 
                            transform={`translate(${-nodeWidth/2 + 24}, ${-nodeHeight/2 + 2})`} 
                            className="cursor-pointer hover:scale-110 transition-transform"
                            onDoubleClick={(e) => {
                              e.stopPropagation();
                              if (onOpenDetails) onOpenDetails(step.id);
                            }}
                            title={`Esta atividade possui ${step.linkedProcesses.length} vínculos inter-processos. Clique para ver.`}
                          >
                            <circle r="6" fill="#DBEAFE" stroke="#2563EB" strokeWidth="0.8" />
                            <text
                              fill="#1D4ED8"
                              fontSize="6.5"
                              fontWeight="black"
                              textAnchor="middle"
                              y="2"
                              fontFamily="sans-serif"
                            >
                              L
                            </text>
                          </g>
                        )}

                        {/* Node Text Label and Subtitles */}
                        <foreignObject
                          x={-nodeWidth / 2 + 8}
                          y={-nodeHeight / 2 + 6}
                          width={nodeWidth - 16}
                          height={nodeHeight - 12}
                          className="overflow-hidden pointer-events-none"
                        >
                          <div className="flex flex-col justify-center h-full text-center">
                            <div className="text-[10px] font-bold text-gray-900 leading-tight truncate">
                              {idx + 1}. {step.name}
                            </div>
                            <div className="text-[8px] text-gray-500 font-mono truncate mt-0.5">
                              {step.resource || "N/A"}
                            </div>
                            <div className="text-[7.5px] text-[#C49746]/90 font-bold mt-0.5 flex items-center justify-center gap-1">
                              <span>{step.processingTime} min | {(step.yieldRate * 100).toFixed(0)}% Yld</span>
                              {step.subProcesses && step.subProcesses.length > 0 && (
                                <span className="bg-amber-100/80 text-amber-900 border border-amber-300 rounded-[2px] px-0.8 py-0.1 text-[5.8px] scale-90 select-none shrink-0 font-sans font-extrabold">
                                  ⚙️ {step.subProcesses.length} Sub
                                </span>
                              )}
                            </div>
                          </div>
                        </foreignObject>

                        {/* Tooltip Inteligente Bulb & Advisory Popover */}
                        <g 
                          transform={`translate(${step.shapeType === "DECISION" ? 40 : nodeWidth/2 - 12}, ${step.shapeType === "DECISION" ? -40 : -nodeHeight/2 - 4})`}
                          className="cursor-pointer"
                          onMouseEnter={() => setHoveredTooltipStepId(step.id)}
                          onMouseLeave={() => setHoveredTooltipStepId(null)}
                          onClick={(e) => {
                            e.stopPropagation();
                            setHoveredTooltipStepId(prev => prev === step.id ? null : step.id);
                          }}
                          onMouseDown={(e) => e.stopPropagation()}
                        >
                          <circle
                            r="8.5"
                            fill={isBottleneck ? "#F59E0B" : "#8B5CF6"}
                            className="stroke-white stroke-1 hover:scale-125 transition-transform"
                            style={{ filter: "drop-shadow(0px 1px 2px rgba(0,0,0,0.15))" }}
                          />
                          <text
                            y="2.8"
                            textAnchor="middle"
                            fill="white"
                            fontSize="8"
                            fontWeight="bold"
                            fontFamily="sans-serif"
                            className="pointer-events-none select-none"
                          >
                            💡
                          </text>
                        </g>

                        {hoveredTooltipStepId === step.id && (
                          <foreignObject
                            x={step.shapeType === "DECISION" ? 52 : nodeWidth/2 + 2}
                            y={step.shapeType === "DECISION" ? -100 : -nodeHeight/2 - 60}
                            width="250"
                            height="170"
                            className="pointer-events-none select-none z-50 animate-fade-in"
                            onMouseDown={(e) => e.stopPropagation()}
                          >
                            <div className="bg-slate-900/95 border border-purple-500/40 text-white p-3 rounded-md shadow-xl text-left space-y-2 select-none pointer-events-none font-sans">
                              <div className="flex items-center justify-between border-b border-purple-500/20 pb-1 gap-1">
                                <span className="text-[9px] bg-purple-900/60 border border-purple-500/30 px-1.5 py-0.2 uppercase font-extrabold text-purple-300 rounded-sm leading-none font-mono tracking-wider">
                                  Conselho LSS
                                </span>
                                <span className="text-[8px] bg-slate-800 border border-slate-700 font-bold px-1 rounded-sm text-gray-300 uppercase shrink-0 font-sans tracking-wide">
                                  {businessType || "Industrial"}
                                </span>
                              </div>
                              <div className="space-y-1">
                                <h5 className="text-[10px] font-black text-amber-400 font-sans leading-tight uppercase flex items-center gap-1">
                                  ⚙️ {advice.actionTool}
                                </h5>
                                <p className="text-[9.5px]/relaxed text-gray-100 font-sans leading-relaxed">
                                  {advice.tip}
                                </p>
                              </div>
                              <div className="flex items-center gap-1.5 bg-purple-950/40 p-1 px-1.5 border border-purple-500/10 rounded-sm text-[8px] font-mono text-purple-200">
                                <span className="font-extrabold text-[#C49746] shrink-0 font-sans">📊 Foco LSS:</span>
                                <span className="truncate font-sans">{advice.metricFocus}</span>
                              </div>
                            </div>
                          </foreignObject>
                        )}
                      </g>
                    );
                  })}

                  {/* ORQUESTRADOR INTEGRADO DE DEPARTAMENTOS E REDE DE CONTROLE */}
                  {showAreaLinks && (
                    <g transform="translate(50, 310)">
                      {/* Background Panel Header */}
                      <rect 
                        width="760" 
                        height="92" 
                        fill="#FAF6F0" 
                        stroke="#B45308" 
                        strokeWidth="1.2" 
                        strokeDasharray="3,3"
                        rx="6" 
                        className="shadow-3xs" 
                      />
                      <text x="12" y="16" fill="#B45308" fontSize="8" fontWeight="black" fontFamily="monospace" letterSpacing="1">
                        🏢 ORQUESTRADOR INTEGRADO DE FLUXOS INTER-DEPARTAMENTAL
                      </text>
                      <text x="12" y="24" fill="#475569" fontSize="6.8" fontFamily="sans-serif">
                        Estes hubs representam os setores corporativos interconectados. Clique em algum hub para chavear e mapear a respectiva área.
                      </text>

                      {/* Render each corporate area as a bubble */}
                      {CORPORATE_AREAS.map((area, areaIdx) => {
                        const areaX = 40 + areaIdx * 85;
                        const areaY = 46;
                        const isCurrent = area.id === activeAreaId;

                        return (
                          <g 
                            key={area.id} 
                            className="cursor-pointer group"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (onSwitchArea) onSwitchArea(area.id);
                            }}
                            title={`Clique para navegar e mapear os processos da área de ${area.name}`}
                          >
                            {/* Animated pulsing halo for the current active area */}
                            {isCurrent && (
                              <circle cx={areaX} cy={areaY} r="18" fill="none" stroke="#7C3AED" strokeWidth="2" strokeOpacity="0.3" className="animate-ping" />
                            )}
                            
                            <circle 
                              cx={areaX} 
                              cy={areaY} 
                              r="15" 
                              fill={isCurrent ? "#EEF2FF" : "white"} 
                              stroke={isCurrent ? "#7C3AED" : "#94A3B8"} 
                              strokeWidth={isCurrent ? "2.5" : "1.2"} 
                              className="transition-colors group-hover:fill-purple-50"
                            />
                            <text x={areaX} y={areaY + 4} textAnchor="middle" fontSize="11">
                              {area.icon}
                            </text>
                            
                            {/* Name label - Wrapped inside foreignObject for robust auto-wrapping and no overflow */}
                            <foreignObject 
                              x={areaX - 40} 
                              y={areaY + 18} 
                              width="80" 
                              height="26"
                            >
                              <div 
                                xmlns="http://www.w3.org/1999/xhtml"
                                className="text-center font-sans font-bold leading-[1.1] select-none break-words text-[8px] flex justify-center items-start text-xs h-full" 
                                style={{ 
                                  color: isCurrent ? "#5B21B6" : "#475569"
                                }}
                              >
                                {area.name.split(",")[0]}
                              </div>
                            </foreignObject>
                          </g>
                        );
                      })}
                    </g>
                  )}

                  {/* CONNECTING FLOWS BETWEEN ACTIVE NODES AND CORPORATE DEPARTMENTS */}
                  {showAreaLinks && steps.map((step) => {
                    const sX = step.x ?? 100;
                    const sY = step.y ?? 100;

                    return CORPORATE_AREAS.map((area, areaIdx) => {
                      // Check if step is connected to this area
                      const isLinked = step.linkedProcesses?.some((lnk) => lnk.targetAreaId === area.id) ||
                        (activeAreaId === "core_ops" && area.id === "it_governance" && step.name.toLowerCase().includes("smt")) ||
                        (activeAreaId === "finance" && area.id === "legal_risk" && step.name.toLowerCase().includes("aprovação")) ||
                        (activeAreaId === "core_inbound" && area.id === "finance" && step.name.toLowerCase().includes("triagem"));

                      if (!isLinked) return null;

                      // Coordinate of the department bubble on the bottom panel
                      const deptX = 50 + 45 + areaIdx * 82;
                      const deptY = 310 + 46;

                      // Curve control point
                      const midX = (sX + deptX) / 2;
                      const midY = (sY + deptY) / 2;
                      const pathD = `M ${sX} ${sY} Q ${midX + 60} ${midY + 20} ${deptX} ${deptY}`;

                      const uniquePathKey = `link-path-${step.id}-${area.id}`;

                      return (
                        <g key={uniquePathKey} className="pointer-events-none opacity-80 animate-fade-in">
                          <path
                            d={pathD}
                            fill="none"
                            stroke="#7C3AED"
                            strokeWidth="1.5"
                            strokeDasharray="4,4"
                          />
                          {/* Animated circle flowing along the path */}
                          <circle r="4.5" fill="#7C3AED">
                            <animateMotion
                              dur="5s"
                              repeatCount="indefinite"
                              path={pathD}
                            />
                          </circle>
                          <circle r="2" fill="#F5F3FF">
                            <animateMotion
                              dur="5s"
                              repeatCount="indefinite"
                              path={pathD}
                            />
                          </circle>
                        </g>
                      );
                    });
                  })}
                </>
              )}
            </g>
          </svg>
        </div>

        {/* Selected Node Drawer/Side Panel controls (Slide out effect) */}
        {selectedStep && (
          <div className="w-80 min-w-[320px] bg-[#FDFCFB] border-l border-[#1A1A1A]/10 h-full overflow-y-auto p-4 z-20 shadow-lg space-y-4 animate-fade-in pb-28" id="selected-node-drawer-panel">
            <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-2">
              <div className="flex items-center gap-1">
                <Settings2 size={13} className="text-[#C49746]" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#1A1A1A]">Configurar Etapa</span>
              </div>
              <button
                onClick={() => setSelectedNodeId(null)}
                className="text-xs hover:text-gray-950 text-gray-400 font-bold"
              >
                ✕ Fechar
              </button>
            </div>

            {/* 📝 COORDENADOR DE IDENTIFICAÇÃO (EXTREMAMENTE ACESSÍVEL NO TOPO!) */}
            <div className="bg-amber-50/15 border-2 border-slate-900 p-3.5 rounded-sm space-y-3.5 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]">
              <span className="text-[9.5px] uppercase font-black tracking-widest text-[#C49746] block flex items-center gap-1">
                📝 Identificação do Posto
              </span>
              <div>
                <label className="block text-[8.5px] uppercase font-bold text-slate-700 mb-1">Nome da Etapa / Atividade</label>
                <input
                  type="text"
                  value={selectedStep.name}
                  onChange={(e) => handleUpdateSelectedNode("name", e.target.value)}
                  className="w-full bg-white border border-slate-300 text-xs p-1.5 focus:border-[#C49746] focus:outline-none font-bold text-slate-900 rounded-sm"
                  placeholder="Ex: Início do Fluxo, Triagem, etc."
                />
              </div>

              <div>
                <label className="block text-[8.5px] uppercase font-bold text-slate-700 mb-1">Responsável / Pool Executor</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2.5 text-gray-400">
                    <User size={11} />
                  </span>
                  <input
                    type="text"
                    value={selectedStep.resource}
                    onChange={(e) => handleUpdateSelectedNode("resource", e.target.value)}
                    className="w-full bg-white border border-slate-300 text-xs p-1.5 pl-7 focus:border-[#C49746] focus:outline-none select-all rounded-sm font-medium"
                    placeholder="Ex: Operador Logístico"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[8.5px] uppercase font-bold text-[#C49746] mb-1">Origem da Evidência (E3I Rastreabilidade)</label>
                <select
                  value={selectedStep.evidenceOrigin || "USER_DECLARATION"}
                  onChange={(e) => handleUpdateSelectedNode("evidenceOrigin", e.target.value)}
                  className="w-full bg-amber-50/50 border border-amber-200 text-xs p-1.5 focus:border-[#C49746] focus:outline-none rounded-sm font-semibold text-amber-900 cursor-pointer"
                >
                  <option value="SYSTEM">📶 Dado do Sistema (ERP / Log)</option>
                  <option value="USER_DECLARATION">🗣️ Declaração do Usuário (Entrevista)</option>
                  <option value="DOCUMENT">📄 Documento (SOP / PDF)</option>
                  <option value="INFERENCE">🔮 Inferência Analítica (Algoritmo)</option>
                  <option value="PREMISE">🧭 Premissa Operacional</option>
                  <option value="BENCHMARK">🏅 Benchmark Industrial/Setor</option>
                </select>
              </div>
            </div>

            {/* ⚙️ PARÂMETROS OPERACIONAIS DE CAPACIDADE */}
            <div className="bg-[#FAF9F6] p-3.5 border border-[#1A1A1A]/10 space-y-3 rounded-xs">
              <span className="text-[9px] uppercase font-black tracking-wider text-slate-800 block border-b border-[#1A1A1A]/5 pb-10/12 pb-1.5 flex items-center justify-between">
                <span>⚙️ Métricas &amp; Capacidade</span>
                <span className="text-[8px] font-mono bg-amber-100 text-[#C49746] px-1 py-0.2 rounded-2xs font-bold uppercase">Medição Estocástica</span>
              </span>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[8px] uppercase font-bold text-slate-500 mb-0.5">Operadores (Qtd)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={selectedStep.resourceCount}
                    onChange={(e) => handleUpdateSelectedNode("resourceCount", Number(e.target.value) || 1)}
                    className="w-full bg-white border border-slate-300 text-xs p-1 h-7 text-center font-mono font-bold focus:outline-none focus:border-[#C49746] rounded-sm"
                  />
                </div>
                <div>
                  <label className="block text-[8px] uppercase font-bold text-slate-500 mb-0.5">Ciclo Médio (min)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    value={selectedStep.processingTime}
                    onChange={(e) => handleUpdateSelectedNode("processingTime", parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-white border border-slate-300 text-xs p-1 h-7 text-center font-mono font-bold focus:outline-none focus:border-[#C49746] rounded-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[8px] uppercase font-bold text-slate-500 mb-0.5">Desvio σ (min)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.05"
                    value={selectedStep.standardDeviation}
                    onChange={(e) => handleUpdateSelectedNode("standardDeviation", parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-white border border-slate-300 text-xs p-1 h-7 text-center font-mono focus:outline-none focus:border-[#C49746] rounded-sm"
                  />
                </div>
                <div>
                  <label className="block text-[8px] uppercase font-bold text-slate-500 mb-0.5">Rendimento (Yield %)</label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={Math.round(selectedStep.yieldRate * 100)}
                    onChange={(e) => handleUpdateSelectedNode("yieldRate", (parseFloat(e.target.value) || 100) / 100)}
                    className="w-full bg-white border border-slate-300 text-xs p-1 h-7 text-center font-mono font-bold text-indigo-700 focus:outline-none focus:border-[#C49746] rounded-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[8.5px] uppercase font-bold text-slate-500 mb-0.5">Tempo de Setup (Preparo) min</label>
                <input
                  type="number"
                  min="0"
                  value={selectedStep.setupTime}
                  onChange={(e) => handleUpdateSelectedNode("setupTime", Number(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 text-xs p-1.5 font-mono focus:outline-none focus:border-[#C49746] rounded-sm"
                />
              </div>
            </div>

            {/* 📋 COLETA DE DADOS SIMPLIFICADA (PREENCHIMENTO RÁPIDO) */}
            <div className="bg-indigo-50/10 border border-indigo-600/10 p-3 space-y-1.5 rounded-sm">
              <span className="text-[9px] uppercase font-bold tracking-wider text-indigo-800 block border-b border-indigo-200/20 pb-1">
                ⏱️ Preenchimento Expresso (UX Assistida)
              </span>
              <p className="text-[9px] text-slate-500 leading-none">Preencher com base na complexidade do posto:</p>
              
              <div className="grid grid-cols-3 gap-1">
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateSelectedNode("resourceCount", 1);
                    handleUpdateSelectedNode("processingTime", 2.0);
                    handleUpdateSelectedNode("yieldRate", 0.99);
                  }}
                  className="py-1 text-[9px] uppercase font-bold bg-[#DCFCE7] hover:bg-[#BBF7D0] text-[#14532D] border border-[#22C55E]/10 transition-all cursor-pointer rounded-sm"
                  title="Ajuste rápido: 1 Operador, 2.0 min, 99% Rendimento"
                >
                  🟢 Fácil
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateSelectedNode("resourceCount", 1);
                    handleUpdateSelectedNode("processingTime", 6.0);
                    handleUpdateSelectedNode("yieldRate", 0.95);
                  }}
                  className="py-1 text-[9px] uppercase font-bold bg-[#FEF3C7] hover:bg-[#FDE68A] text-[#78350F] border border-[#F59E0B]/10 transition-all cursor-pointer rounded-sm"
                  title="Ajuste rápido: 1 Operador, 6.0 min, 95% Rendimento"
                >
                  🟡 Médio
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateSelectedNode("resourceCount", 2);
                    handleUpdateSelectedNode("processingTime", 15.0);
                    handleUpdateSelectedNode("yieldRate", 0.90);
                  }}
                  className="py-1 text-[9px] uppercase font-bold bg-[#FEE2E2] hover:bg-[#FCA5A5] text-[#7F1D1D] border border-[#EF4444]/10 transition-all cursor-pointer rounded-sm"
                  title="Ajuste rápido: 2 Operadores, 15.0 min, 90% Rendimento"
                >
                  🔴 Alto
                </button>
              </div>
            </div>

            {/* BUTTON TO VIEW ADVANCED OPERATIONAL MANUAL & SUBPROCESSES */}
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  if (onOpenDetails) onOpenDetails(selectedStep.id);
                }}
                className="w-full bg-[#C49746] hover:bg-[#854D0E] text-white text-[10px] font-sans font-bold uppercase tracking-widest py-3 px-3 border border-[#1A1A1A] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
              >
                <FileText size={13} className="text-amber-200" />
                <span>🔍 ABRIR FASE &amp; DRILL DOWN</span>
              </button>
              <p className="text-[8.5px] text-[#C49746] font-medium leading-tight text-center mt-1">
                Mapeie subprocessos, atividades granulares, POPs e checklists desta etapa.
              </p>
            </div>

            {/* Shape Category Selector */}
            <div>
              <label className="block text-[8px] uppercase tracking-wider text-gray-400 font-bold mb-1">Categoria de Forma</label>
              <div className="grid grid-cols-4 gap-1 p-1 bg-gray-100 rounded-sm">
                {(['START', 'ACTIVITY', 'DECISION', 'END'] as const).map((form) => (
                  <button
                    key={form}
                    onClick={() => handleUpdateSelectedNode('shapeType', form)}
                    className={`py-1 text-[8px] uppercase font-bold rounded-sm ${
                      selectedStep.shapeType === form 
                        ? "bg-white text-gray-900 shadow-xs" 
                        : "text-gray-500 hover:text-gray-900"
                    }`}
                  >
                    {form === 'START' ? 'Início' : form === 'ACTIVITY' ? 'Ação' : form === 'DECISION' ? 'Decisão' : 'Fim'}
                  </button>
                ))}
              </div>
            </div>

            {/* 💡 SUGESTÕES INTELIGENTES DO ADVISOR IA */}
            {(() => {
              const suggestions = getAiSuggestionsForStep(selectedStep);
              if (suggestions.length === 0) return null;
              
              return (
                <div className="border border-indigo-200 bg-indigo-50/50 p-3 rounded-xs space-y-2">
                  <div className="flex items-center gap-1.5">
                    <Sparkles size={13} className="text-indigo-600 animate-pulse" />
                    <span className="text-[9px] uppercase font-black tracking-widest text-[#1A1A1A]">
                      Sugestões do Advisor IA
                    </span>
                  </div>
                  <p className="text-[9px] text-gray-500 leading-snug">
                    A IA gerou melhorias de framework e de escopo para esta atividade. Clique para aprovar:
                  </p>
                  
                  <div className="space-y-2">
                    {suggestions.map((sug) => (
                      <div key={sug.id} className="bg-white border border-indigo-200 p-2.5 rounded-xs text-left relative shadow-2xs">
                        <span className="absolute top-1.5 right-1.5 text-[7px] font-mono font-bold bg-indigo-100 text-indigo-700 px-1 py-0.2 rounded-xs">
                          {sug.label}
                        </span>
                        <h6 className="text-[10px] font-bold text-gray-900 pr-10">{sug.title}</h6>
                        <p className="text-[9px] text-gray-600 mt-1 leading-snug">{sug.description}</p>
                        
                        <div className="mt-2 flex gap-1 justify-end">
                          <button
                            type="button"
                            onClick={() => handleRejectSuggestion(sug.id)}
                            className="px-2 py-0.5 text-[8.5px] uppercase font-bold text-gray-500 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 rounded-none transition-colors cursor-pointer border-none"
                          >
                            Rejeitar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleApproveSuggestion(sug.id, sug.type, sug.value)}
                            className="px-2 py-0.5 text-[8.5px] uppercase font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-none transition-colors cursor-pointer border-none"
                          >
                            Aprovar
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* Informational properties */}
            <div className="space-y-3">
              <div>
                <label className="block text-[8px] uppercase font-bold text-gray-500 mb-1">Descrição Comercial / Instrução de Trabalho</label>
                <textarea
                  rows={2}
                  value={selectedStep.description || ""}
                  onChange={(e) => handleUpdateSelectedNode("description", e.target.value)}
                  placeholder="Instruções detalhadas da atividade operacional"
                  className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1.5 focus:border-[#C49746] focus:outline-none resize-none rounded-sm"
                />
              </div>
            </div>

            {/* COORDENADAS DO MAPA VISUAL */}
            <div className="bg-[#F5F2ED]/60 p-3 border border-[#1A1A1A]/5 space-y-2">
              <span className="text-[9px] uppercase font-bold tracking-wider text-[#1A1A1A]/70 block border-b border-[#1A1A1A]/5 pb-1">
                Ajuste Geométrico (Mapa)
              </span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">X Relativo (px)</label>
                  <input
                    type="number"
                    min="20"
                    max="2000"
                    value={Math.round(selectedStep.x ?? 0)}
                    onChange={(e) => handleUpdateSelectedNode("x", parseInt(e.target.value) || 20)}
                    className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1 text-center font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">Y Relativo (px)</label>
                  <input
                    type="number"
                    min="20"
                    max="2000"
                    value={Math.round(selectedStep.y ?? 0)}
                    onChange={(e) => handleUpdateSelectedNode("y", parseInt(e.target.value) || 20)}
                    className="w-full bg-white border border-[#1A1A1A]/10 text-xs p-1 text-center font-mono focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* FLOW ROUTING LINKS */}
            <div className="space-y-3">
              <span className="text-[9px] uppercase font-bold tracking-wider text-gray-700 block border-b border-gray-100 pb-1">
                Conexões do Fluxograma
              </span>

              {selectedStep.shapeType === "DECISION" ? (
                <div className="space-y-2.5">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-[8px] uppercase font-bold text-emerald-800">Se 'SIM' (Caminho Verde)</label>
                      {selectedStep.yesStepId && (
                        <button 
                          onClick={() => handleUpdateSelectedNode("yesStepId", undefined)}
                          className="text-[8px] text-red-600 hover:text-red-700 hover:underline font-bold bg-transparent border-none cursor-pointer"
                        >
                          Excluir Linha
                        </button>
                      )}
                    </div>
                    <select
                      value={selectedStep.yesStepId || ""}
                      onChange={(e) => handleUpdateSelectedNode("yesStepId", e.target.value || undefined)}
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs py-1 px-2 focus:outline-none"
                    >
                      <option value="">-- Conectar a --</option>
                      {steps.filter((s) => s.id !== selectedStep.id).map((s) => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-[8px] uppercase font-bold text-red-800">Se 'NÃO' (Caminho Vermelho)</label>
                      {selectedStep.noStepId && (
                        <button 
                          onClick={() => handleUpdateSelectedNode("noStepId", undefined)}
                          className="text-[8px] text-red-600 hover:text-red-700 hover:underline font-bold bg-transparent border-none cursor-pointer"
                        >
                          Excluir Linha
                        </button>
                      )}
                    </div>
                    <select
                      value={selectedStep.noStepId || ""}
                      onChange={(e) => handleUpdateSelectedNode("noStepId", e.target.value || undefined)}
                      className="w-full bg-white border border-[#1A1A1A]/10 text-xs py-1 px-2 focus:outline-none"
                    >
                      <option value="">-- Conectar a --</option>
                      {steps.filter((s) => s.id !== selectedStep.id).map((s) => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-[8px] uppercase font-bold text-gray-500">Próxima Etapa Operacional</label>
                    {selectedStep.nextStepId && (
                      <button 
                        onClick={() => handleUpdateSelectedNode("nextStepId", undefined)}
                        className="text-[8px] text-red-600 hover:text-red-700 hover:underline font-bold bg-transparent border-none cursor-pointer"
                      >
                        Excluir Linha
                      </button>
                    )}
                  </div>
                  <select
                    value={selectedStep.nextStepId || ""}
                    onChange={(e) => handleUpdateSelectedNode("nextStepId", e.target.value || undefined)}
                    className="w-full bg-white border border-[#1A1A1A]/10 text-xs py-1 px-2 focus:outline-none"
                  >
                    <option value="">-- Fim do Fluxo --</option>
                    {steps.filter((s) => s.id !== selectedStep.id).map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* 📦 COMERCIAL: ELEMENTOS DE INTEGRAÇÃO SIPOC */}
            <div className="bg-[#EEF2FF] p-3 border border-indigo-200/60 space-y-3">
              <span className="text-[9px] uppercase font-bold tracking-wider text-indigo-700 block border-b border-indigo-200/60 pb-1">
                Integração SIPOC da Etapa
              </span>
              <p className="text-[8.5px] text-indigo-600 leading-snug">
                Defina o fluxo de entrada e saída para contextualizar esta atividade em qualquer ramo de negócio (Finanças, Serviços, TI ou Operações).
              </p>

              <div className="space-y-2">
                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">S / Fornecedores (Separados por vírgula)</label>
                  <input
                    type="text"
                    value={selectedStep.suppliers?.join(", ") || ""}
                    onChange={(e) => handleUpdateSelectedNode("suppliers", e.target.value.split(",").map(s => s.trim()))}
                    placeholder="Ex: Controladoria, Clientes VIP, APIs externas"
                    className="w-full bg-white border border-indigo-200 text-xs p-1 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">I / Insumos / Entradas (Separadas por vírgula)</label>
                  <input
                    type="text"
                    value={selectedStep.requiredInputs?.join(", ") || ""}
                    onChange={(e) => handleUpdateSelectedNode("requiredInputs", e.target.value.split(",").map(s => s.trim()))}
                    placeholder="Ex: Faturas, Relatórios PDF, Cargas de insumo"
                    className="w-full bg-white border border-indigo-200 text-xs p-1 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">O / Entregáveis / Saídas (Separados por vírgula)</label>
                  <input
                    type="text"
                    value={selectedStep.outputs?.join(", ") || ""}
                    onChange={(e) => handleUpdateSelectedNode("outputs", e.target.value.split(",").map(s => s.trim()))}
                    placeholder="Ex: Liberações ERP, Balanço consolidado"
                    className="w-full bg-white border border-indigo-200 text-xs p-1 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[8px] uppercase text-gray-500 font-bold mb-0.5">C / Clientes / Receptores (Separados por vírgula)</label>
                  <input
                    type="text"
                    value={selectedStep.customers?.join(", ") || ""}
                    onChange={(e) => handleUpdateSelectedNode("customers", e.target.value.split(",").map(s => s.trim()))}
                    placeholder="Ex: Board Executivo, Setor Fiscal, Cliente Final"
                    className="w-full bg-white border border-indigo-200 text-xs p-1 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 🏢 INTERLIGAÇÃO INTER-DEPARTAMENTAL */}
            <div className="bg-[#FAF5FF] p-3 border border-purple-200/60 space-y-3">
              <span className="text-[9px] uppercase font-bold tracking-wider text-purple-700 block border-b border-purple-200/60 pb-1">
                Interligações Inter-Departamentais
              </span>
              <p className="text-[8.5px] text-purple-600 leading-snug">
                Crie um canal de dados inter-processos com outros setores da empresa para traçar o fluxo de ponta a ponta.
              </p>

              <div className="space-y-1.5 max-h-[140px] overflow-y-auto border border-purple-100 p-1.5 bg-white rounded-xs">
                {CORPORATE_AREAS.map((area) => {
                  const isLinked = selectedStep.linkedProcesses?.some((l) => l.targetAreaId === area.id);
                  return (
                    <div key={area.id} className="flex items-center justify-between text-[10px] p-1 hover:bg-purple-50/50">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs">{area.icon}</span>
                        <span className="font-sans font-bold text-gray-700 truncate max-w-[130px]">{area.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const existing = selectedStep.linkedProcesses || [];
                          let updated;
                          if (isLinked) {
                            updated = existing.filter(l => l.targetAreaId !== area.id);
                          } else {
                            updated = [...existing, { targetAreaId: area.id, targetAreaName: area.name, description: `Integração de fluxo de informações de ${selectedStep.name} para ${area.name}.` }];
                          }
                          // Propagate to parent state
                          handleUpdateSelectedNode("linkedProcesses", updated);
                        }}
                        className={`px-1.5 py-0.5 rounded-sm font-mono text-[8px] font-extrabold cursor-pointer transition border ${
                          isLinked 
                            ? "bg-purple-600 border-purple-700 text-white" 
                            : "bg-transparent border-gray-300 text-gray-500 hover:bg-gray-100"
                        }`}
                      >
                        {isLinked ? "CONECTADO" : "CONECTAR"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Actions: Duplicate and Delete current selected node */}
            <div className="pt-3 border-t border-gray-100 flex gap-2">
              <button
                id="visual-duplicate-node-btn"
                onClick={handleDuplicateSelectedNode}
                className="flex-1 bg-amber-50 hover:bg-amber-100 text-[#C49746] border border-amber-600/20 text-[10px] uppercase tracking-wider font-bold py-2 rounded-sm flex items-center justify-center gap-1 transition-all cursor-pointer"
              >
                Duplicar
              </button>
              <button
                id="visual-delete-node-btn"
                onClick={handleDeleteSelectedNode}
                className="flex-1 bg-red-100 hover:bg-red-200 text-red-700 text-[10px] uppercase tracking-wider font-bold py-2 rounded-sm flex items-center justify-center gap-1 transition-all cursor-pointer"
              >
                <Trash2 size={12} /> Excluir
              </button>
            </div>

          </div>
        )}

      </div>

      <DetailDrawer
        isOpen={isMarginDrawerOpen}
        title="Margem Integrada"
        subTitle="Cadeia de Valor Porter & LSS"
        onClose={() => setIsMarginDrawerOpen(false)}
      >
        <div className="space-y-4 text-slate-800 font-sans text-xs">
          <p className="leading-relaxed">
            A <strong>Margem Integrada DMAIC</strong> representa o valor sinérgico que as atividades de Suporte e Core geram em conjunto.
          </p>
          <div className="p-3.5 bg-amber-50 border border-amber-100 rounded-lg">
            <h5 className="font-mono text-[10px] font-black uppercase text-[#C49746] tracking-wider mb-1">
              🎯 Modelagem Matemática LSS
            </h5>
            <p className="text-[#C49746] leading-normal font-medium">
              Reduz a variabilidade e as perdas de filas nos gargalos operacionais para ampliar a margem real de lucratividade da operação.
            </p>
          </div>
          <p className="leading-relaxed text-slate-500">
            Ao calibrar a transição entre as atividades de retaguarda (Suporte) e as de linha de frente (Core), o sistema elimina desperdícios invisíveis no fluxo de transição empresarial.
          </p>
        </div>
      </DetailDrawer>

    </div>
  );
}
