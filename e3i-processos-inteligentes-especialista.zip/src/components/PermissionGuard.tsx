import React from "react";
import { Permission } from "../types";
import { hasPermission, SECURITY_WARNING_NOTICE } from "../config/adminConfig";

type PermissionGuardProps = {
  permission: Permission;
  user: any;
  fallback?: React.ReactNode;
  children: React.ReactNode;
};

export function PermissionGuard({
  permission,
  user,
  fallback = null,
  children,
}: PermissionGuardProps) {
  const allowed = hasPermission(user, permission);

  if (!allowed) {
    if (fallback !== undefined) {
      return <>{fallback}</>;
    }
    // High-fidelity standard B2B fallback for unauthorized access
    return (
      <div 
        id={`permission-guard-fallback-${permission}`}
        className="p-8 border border-red-200 bg-red-50/50 rounded-xl space-y-3 max-w-xl mx-auto my-12 text-center shadow-xs"
      >
        <span className="text-2xl">⚠️</span>
        <h4 className="text-base font-serif font-bold text-red-900 leading-tight">Acesso Restrito por Governança</h4>
        <p className="text-xs text-red-700 leading-relaxed max-w-md mx-auto">
          Seu perfil ({user?.belt || user?.role || "Operador"}) não possui a permissão requerida: <code className="bg-red-100 px-1.5 py-0.5 rounded text-[10px] font-mono">{permission}</code>.
        </p>
        <div className="pt-2 text-[9px] font-mono text-stone-400">
          {SECURITY_WARNING_NOTICE}
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
