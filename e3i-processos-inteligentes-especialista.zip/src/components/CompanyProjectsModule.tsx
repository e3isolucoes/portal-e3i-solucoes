import React, { useState, useEffect, useMemo } from "react";
import { 
  Building2, 
  Briefcase, 
  Plus, 
  Search, 
  Map, 
  Trash2, 
  ArrowRight, 
  Edit3, 
  Shield, 
  Lock, 
  Terminal, 
  CheckCircle, 
  Target, 
  Compass, 
  TrendingUp, 
  CheckSquare, 
  Sparkles, 
  RefreshCw, 
  ArrowLeft, 
  ChevronRight, 
  Info,
  Sliders,
  HelpCircle
} from "lucide-react";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";
import { useToast } from "../shared/ui/Toast";
import { 
  Company, 
  WorkspaceProject, 
  StrategicPlanning, 
  StrategicFront, 
  StrategicObjective 
} from "../types";

interface Props {
  activeUser?: any;
  currentCargo?: string;
  activeCompanyId: string | null;
  setActiveCompanyId: (id: string | null) => void;
  activeProjectId: string | null;
  setActiveProjectId: (id: string | null) => void;
  onNavigateToMap: () => void;
}

export default function CompanyProjectsModule({ 
  activeUser,
  currentCargo,
  activeCompanyId, 
  setActiveCompanyId, 
  activeProjectId, 
  setActiveProjectId,
  onNavigateToMap
}: Props) {
  const { error: toastError, success: toastSuccess } = useToast();
  const userEmail = activeUser?.email || "anonymous";

  const canCreateCompany = () => {
    const role = currentCargo || activeUser?.role || "Colaborador";
    const normalized = role.toLowerCase();
    return (
      normalized === "admin" ||
      normalized === "administrador" ||
      normalized === "dono do processo" ||
      normalized.includes("dono") ||
      activeUser?.email === "admin@sixsigma.com"
    );
  };

  const [companies, setCompanies] = useState<Company[]>(() => CompanyProjectRepository.getCompanies(userEmail));
  const [projects, setProjects] = useState<WorkspaceProject[]>(() => CompanyProjectRepository.getProjects(userEmail));

  // Active view tab when company is selected: "projects" or "strategic"
  const [activeTab, setActiveTab] = useState<"projects" | "strategic">("projects");

  // Search filter for company selection screen
  const [companySearchQuery, setCompanySearchQuery] = useState("");

  // Dynamic audit logs state
  const [auditLogs, setAuditLogs] = useState<{ id: string; time: string; msg: string; type: "success" | "warn" | "info" }[]>(() => [
    { id: "1", time: new Date(Date.now() - 30000).toLocaleTimeString(), msg: `Firebase Admin SDK: Inicializando autenticação segura`, type: "info" },
    { id: "2", time: new Date(Date.now() - 20000).toLocaleTimeString(), msg: `Validação de ID Token concluída com sucesso`, type: "success" },
    { id: "3", time: new Date(Date.now() - 10000).toLocaleTimeString(), msg: `Acesso Concedido: Perfil verificado para '${activeUser?.email || "admin@sixsigma.com"}'`, type: "success" },
    { id: "4", time: new Date().toLocaleTimeString(), msg: `Isolamento Multi-Tenant: Banco de dados do usuário isolado no Firestore`, type: "info" }
  ]);

  // Sync with Firestore-backed real-time cache changes
  useEffect(() => {
    const unsubscribe = CompanyProjectRepository.addChangeListener(() => {
      const comps = CompanyProjectRepository.getCompanies(userEmail);
      setCompanies(prev => {
        if (JSON.stringify(prev) === JSON.stringify(comps)) return prev;
        return comps;
      });

      const projs = CompanyProjectRepository.getProjects(userEmail);
      setProjects(prev => {
        if (JSON.stringify(prev) === JSON.stringify(projs)) return prev;
        return projs;
      });
    });
    return unsubscribe;
  }, [userEmail]);

  // Dynamic log updates on Company selection
  useEffect(() => {
    if (activeCompanyId) {
      const comp = companies.find(c => c.id === activeCompanyId);
      if (comp) {
        const now = new Date().toLocaleTimeString();
        const baseLogs = [
          {
            id: `comp-log-${Date.now()}-1`,
            time: now,
            msg: `Tenant Ativo: Carregando dados isolados da organização '${comp.name}'`,
            type: "info" as const
          },
          {
            id: `comp-rbac-${Date.now()}-2`,
            time: now,
            msg: `Controle RBAC Admin: Acesso concedido ao recurso id '${comp.id}'`,
            type: "success" as const
          }
        ];

        if (comp.diagnosticData) {
          const diag = comp.diagnosticData;
          baseLogs.push(
            {
              id: `comp-diag-${Date.now()}-3`,
              time: now,
              msg: `Auditoria de Entrada: Localizado diagnóstico de lead comercial prévio (${diag.audienceType}) para '${comp.name}'`,
              type: "success" as const
            },
            {
              id: `comp-diag-stats-${Date.now()}-4`,
              time: now,
              msg: `Mapeador Comercial: Volume = ${diag.volume?.toLocaleString("pt-BR")} un | COPQ anual = R$ ${Math.round(diag.estimatedAnnualWaste || 0).toLocaleString("pt-BR")} | Score LSS = ${diag.score}/100`,
              type: "info" as const
            }
          );
        }

        setAuditLogs(prev => [
          ...baseLogs,
          ...prev
        ].slice(0, 40));
      }
    }
  }, [activeCompanyId, companies]);

  // Log update on Project selection
  useEffect(() => {
    if (activeProjectId) {
      const proj = projects.find(p => p.id === activeProjectId);
      if (proj) {
        setAuditLogs(prev => [
          {
            id: `proj-log-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            time: new Date().toLocaleTimeString(),
            msg: `Projeto Ativo: Focando no projeto operacional '${proj.name}'`,
            type: "info"
          },
          ...prev
        ].slice(0, 40));
      }
    }
  }, [activeProjectId, projects]);

  // Company creation / editing states
  const [newCompanyMode, setNewCompanyMode] = useState(false);
  const [newCompanyName, setNewCompanyName] = useState("");
  const [newCompanyCnpj, setNewCompanyCnpj] = useState("");
  const [newCompanyInd, setNewCompanyInd] = useState("");

  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  const [editingCompanyName, setEditingCompanyName] = useState("");
  const [editingCompanyCnpj, setEditingCompanyCnpj] = useState("");
  const [editingCompanyInd, setEditingCompanyInd] = useState("");

  // Project creation / editing states
  const [newProjectMode, setNewProjectMode] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");
  const [newProjectObj, setNewProjectObj] = useState("");
  const [newProjectFrontId, setNewProjectFrontId] = useState("");

  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [editingProjectName, setEditingProjectName] = useState("");
  const [editingProjectObj, setEditingProjectObj] = useState("");
  const [editingProjectStatus, setEditingProjectStatus] = useState<"Planejado" | "Em Andamento" | "Concluído">("Planejado");
  const [editingProjectFrontId, setEditingProjectFrontId] = useState("");
  const [projectFormError, setProjectFormError] = useState<string | null>(null);

  // Strategic Planning editing states
  const [isEditingPlanningDir, setIsEditingPlanningDir] = useState(false);
  const [planMission, setPlanMission] = useState("");
  const [planVision, setPlanVision] = useState("");
  const [planValues, setPlanValues] = useState("");

  // Strategic Objective creation form
  const [addingObjectiveFrontId, setAddingObjectiveFrontId] = useState<string | null>(null);
  const [newObjTitle, setNewObjTitle] = useState("");
  const [newObjIndicator, setNewObjIndicator] = useState("");
  const [newObjTarget, setNewObjTarget] = useState("");

  // Filter companies based on search
  const filteredCompanies = useMemo(() => {
    if (!companySearchQuery.trim()) return companies;
    const lower = companySearchQuery.toLowerCase();
    return companies.filter(c => 
      (c.name && c.name.toLowerCase().includes(lower)) || 
      (c.industry && c.industry.toLowerCase().includes(lower)) || 
      (c.cnpj && c.cnpj.includes(lower))
    );
  }, [companies, companySearchQuery]);

  // Standard preset strategic fronts
  const defaultFronts: StrategicFront[] = [
    {
      id: "financeiro",
      name: "Financeiro",
      description: "Maximização de margens, otimização de fluxo de caixa e redução de custos operacionais e desperdícios (COPQ).",
      objectives: [
        { id: "obj_fin_1", title: "Reduzir Custo de Má Qualidade (COPQ)", target: "Redução de 20% ao ano", indicator: "Desperdício medido em R$" },
        { id: "obj_fin_2", title: "Otimizar Custos de Contas a Pagar", target: "Reduzir tempo de ciclo de matching", indicator: "Tempo médio de aprovação" }
      ]
    },
    {
      id: "clientes",
      name: "Clientes & Comercial",
      description: "Melhoria de SLA de atendimento, satisfação do cliente (CSAT/NPS) e eficiência de conversão comercial.",
      objectives: [
        { id: "obj_cli_1", title: "Aumentar Nível de Serviço (SLA)", target: "SLA acima de 95%", indicator: "Percentual de chamados no prazo" },
        { id: "obj_cli_2", title: "Elevar Satisfação (NPS)", target: "NPS acima de 75 pontos", indicator: "Score de feedback pós-atendimento" }
      ]
    },
    {
      id: "processos",
      name: "Processos Internos / Operacional",
      description: "Redução de lead time, eliminação de gargalos produtivos e garantia de estabilidade estatística Six Sigma.",
      objectives: [
        { id: "obj_proc_1", title: "Eliminar Gargalos Críticos", target: "Capacidade do gargalo > demanda", indicator: "Percentual de utilização do gargalo" },
        { id: "obj_proc_2", title: "Garantir Padronização de POPs", target: "100% dos postos padronizados", indicator: "Taxa de desvio operacional" }
      ]
    },
    {
      id: "aprendizado",
      name: "Aprendizado, Crescimento & Pessoas",
      description: "Capacitação técnica das equipes em Lean Six Sigma, integração de automações inteligentes e cultura de inovação.",
      objectives: [
        { id: "obj_apr_1", title: "Certificação em LSS (Belts)", target: "Pelo menos 3 colaboradores certificados", indicator: "Total de Green/Black Belts na equipe" }
      ]
    }
  ];

  // Helper to fetch or initialize Strategic Planning for a company
  const activeCompany = useMemo(() => {
    return companies.find(c => c.id === activeCompanyId) || null;
  }, [activeCompanyId, companies]);

  const activePlanning = useMemo<StrategicPlanning>(() => {
    if (!activeCompany) {
      return { mission: "", vision: "", values: "", fronts: [] };
    }
    const saved = activeCompany.strategicPlanning;
    if (saved && saved.fronts && saved.fronts.length > 0) {
      return saved;
    }
    return {
      mission: saved?.mission || "Entregar excelência operacional e valor sustentável através da melhoria contínua.",
      vision: saved?.vision || "Ser referência de qualidade e eficiência em nosso setor de atuação até 2028.",
      values: saved?.values || "Foco no Cliente, Excelência, Inovação, Colaboração, Rigor Estatístico",
      fronts: defaultFronts
    };
  }, [activeCompany]);

  // Sync editing inputs when planning is opened or updated
  useEffect(() => {
    if (activeCompany) {
      setPlanMission(activePlanning.mission);
      setPlanVision(activePlanning.vision);
      setPlanValues(activePlanning.values);
    }
  }, [activeCompany, activePlanning]);

  // Save the complete strategic planning document
  const savePlanning = (updatedPlanning: StrategicPlanning) => {
    const updated = companies.map(c => c.id === activeCompanyId ? {
      ...c,
      strategicPlanning: updatedPlanning
    } : c);
    CompanyProjectRepository.saveCompanies(updated, userEmail);
    
    setAuditLogs(prev => [
      {
        id: `save-planning-${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        msg: `Planejamento Estratégico: Diretrizes corporativas atualizadas para '${activeCompany?.name}'`,
        type: "success"
      },
      ...prev
    ]);
  };

  const handleSaveGuidelines = () => {
    const updated: StrategicPlanning = {
      ...activePlanning,
      mission: planMission.trim() || activePlanning.mission,
      vision: planVision.trim() || activePlanning.vision,
      values: planValues.trim() || activePlanning.values,
    };
    savePlanning(updated);
    setIsEditingPlanningDir(false);
    toastSuccess("Diretrizes estratégicas atualizadas com sucesso!");
  };

  const handleAddObjective = (frontId: string) => {
    if (!newObjTitle.trim()) {
      toastError("Por favor, preencha a descrição do objetivo.");
      return;
    }
    
    const newObj: StrategicObjective = {
      id: "obj_" + Date.now().toString(),
      title: newObjTitle.trim(),
      indicator: newObjIndicator.trim() || "A definir",
      target: newObjTarget.trim() || "A definir"
    };

    const updatedFronts = activePlanning.fronts.map(f => {
      if (f.id === frontId) {
        return {
          ...f,
          objectives: [...f.objectives, newObj]
        };
      }
      return f;
    });

    savePlanning({
      ...activePlanning,
      fronts: updatedFronts
    });

    setNewObjTitle("");
    setNewObjIndicator("");
    setNewObjTarget("");
    setAddingObjectiveFrontId(null);
    toastSuccess("Objetivo estratégico adicionado com sucesso!");
  };

  const handleDeleteObjective = (frontId: string, objId: string) => {
    const updatedFronts = activePlanning.fronts.map(f => {
      if (f.id === frontId) {
        return {
          ...f,
          objectives: f.objectives.filter(o => o.id !== objId)
        };
      }
      return f;
    });

    savePlanning({
      ...activePlanning,
      fronts: updatedFronts
    });
    toastSuccess("Objetivo estratégico removido.");
  };

  const handleAddCompany = () => {
    if (!canCreateCompany()) {
      toastError("Apenas Administrador e Dono do Processo possuem permissão para cadastrar novas empresas.");
      return;
    }
    if (!newCompanyName.trim()) return;
    const newCompany: Company = {
      id: "comp_" + Date.now().toString(),
      name: newCompanyName.trim(),
      cnpj: newCompanyCnpj.trim(),
      industry: newCompanyInd.trim() || "Geral",
      createdAt: new Date().toISOString(),
      enabledModules: [],
      strategicPlanning: {
        mission: "Entregar excelência operacional e valor sustentável através da melhoria contínua.",
        vision: "Ser referência de qualidade e eficiência em nosso setor de atuação até 2028.",
        values: "Foco no Cliente, Excelência, Inovação, Colaboração, Rigor Estatístico",
        fronts: defaultFronts
      }
    };
    
    const updated = [...companies, newCompany];
    CompanyProjectRepository.saveCompanies(updated, userEmail);
    setActiveCompanyId(newCompany.id);
    setNewCompanyMode(false);
    setNewCompanyName("");
    setNewCompanyCnpj("");
    setNewCompanyInd("");

    setAuditLogs(prev => [
      {
        id: `add-comp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        time: new Date().toLocaleTimeString(),
        msg: `Cadastro: Nova organização de tenant criada '${newCompany.name}' com plano estratégico padrão`,
        type: "success"
      },
      ...prev
    ]);
  };

  const handleDeleteCompany = (id: string) => {
    const comp = companies.find(c => c.id === id);
    const updatedComps = companies.filter(c => c.id !== id);
    const updatedProjs = projects.filter(p => p.companyId !== id);
    CompanyProjectRepository.saveCompanies(updatedComps, userEmail);
    CompanyProjectRepository.saveProjects(updatedProjs, userEmail);
    if (activeCompanyId === id) {
      setActiveCompanyId(null);
      setActiveProjectId(null);
    }

    setAuditLogs(prev => [
      {
        id: `del-comp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        time: new Date().toLocaleTimeString(),
        msg: `Exclusão: Organização '${comp?.name || id}' removida com segurança`,
        type: "warn"
      },
      ...prev
    ]);
  };

  const handleSaveCompanyEdit = (id: string) => {
    if (!editingCompanyName.trim()) return;
    const updated = companies.map(c => c.id === id ? {
      ...c,
      name: editingCompanyName.trim(),
      cnpj: editingCompanyCnpj.trim(),
      industry: editingCompanyInd.trim()
    } : c);
    CompanyProjectRepository.saveCompanies(updated, userEmail);
    setEditingCompanyId(null);

    setAuditLogs(prev => [
      {
        id: `save-comp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        time: new Date().toLocaleTimeString(),
        msg: `Ajustes: Modificação nas propriedades jurídicas/cadastrais da empresa id '${id}'`,
        type: "info"
      },
      ...prev
    ]);
  };

  const handleAddProject = () => {
    setProjectFormError(null);
    if (!activeCompanyId) {
      setProjectFormError("Nenhuma empresa ativa selecionada.");
      return;
    }
    if (!newProjectName.trim()) {
      setProjectFormError("Por favor, preencha o Nome do Processo/Projeto.");
      return;
    }
    if (newProjectName.trim().length < 3) {
      setProjectFormError("O nome do processo deve ter no mínimo 3 caracteres.");
      return;
    }

    const newProj: WorkspaceProject = {
      id: "proj_" + Date.now().toString(),
      companyId: activeCompanyId,
      name: newProjectName.trim(),
      objective: newProjectObj.trim() || "Otimizar tempo de ciclo, capacidade operacional e estabilidade Six Sigma.",
      status: "Planejado",
      createdAt: new Date().toISOString(),
      strategicFrontId: newProjectFrontId || "processos" // defaults to operational internal processes
    };

    // Auto-provision initial standard process steps for immediate operational simulation
    const store = { ...CompanyProjectRepository.getProjectDataStore(userEmail) };
    store[newProj.id] = {
      companyId: activeCompanyId,
      steps: [
        {
          id: "step_ini_1",
          name: "Atendimento Inicial / Triagem",
          resource: "Atendente",
          resourceCount: 1,
          processingTime: 10,
          standardDeviation: 1.8,
          setupTime: 3,
          yieldRate: 0.98
        },
        {
          id: "step_ini_2",
          name: "Execução Principal",
          resource: "Analista",
          resourceCount: 1,
          processingTime: 12,
          standardDeviation: 2.2,
          setupTime: 5,
          yieldRate: 0.95
        }
      ],
      arrivalRate: 3,
      charter: {
        id: "char_" + newProj.id,
        title: newProj.name,
        businessCase: `Mapeamento e integração com as diretrizes do Planejamento Estratégico na Frente: ${activePlanning.fronts.find(f => f.id === newProj.strategicFrontId)?.name || 'Processos Internos'}.`,
        problemStatement: "Oscilações perceptíveis de tempo de entrega gerando filas e variabilidade.",
        goalStatement: "Garantir estabilidade estatística e alinhamento com os indicadores da diretoria.",
        scopeIn: "Processo operacional ponta-a-ponta.",
        scopeOut: "Sistemas de terceiros.",
        team: "Força-tarefa DMAIC: " + (activeUser?.fullName || "Especialista LSS"),
        targetValue: 200
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(store, userEmail);

    const updated = [...projects, newProj];
    CompanyProjectRepository.saveProjects(updated, userEmail);

    // Focus automatically on the newly created project for a fluid user journey
    setActiveProjectId(newProj.id);
    setNewProjectMode(false);
    setNewProjectName("");
    setNewProjectObj("");
    setNewProjectFrontId("");

    setAuditLogs(prev => [
      {
        id: `add-proj-${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        msg: `Cadastro: Novo processo '${newProj.name}' criado e vinculado à frente estratégica '${newProj.strategicFrontId}'`,
        type: "success"
      },
      ...prev
    ]);
  };

  const handleSaveProjectEdit = (id: string) => {
    if (!editingProjectName.trim()) return;
    const updated = projects.map(p => p.id === id ? {
      ...p,
      name: editingProjectName.trim(),
      objective: editingProjectObj.trim(),
      status: editingProjectStatus,
      strategicFrontId: editingProjectFrontId
    } : p);
    CompanyProjectRepository.saveProjects(updated, userEmail);
    setEditingProjectId(null);

    setAuditLogs(prev => [
      {
        id: `save-proj-${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        msg: `Ajustes: Atualização do processo id '${id}' - Vinculado à frente '${editingProjectFrontId}'`,
        type: "info"
      },
      ...prev
    ]);
  };

  const handleQuickLinkProject = (projectId: string, frontId: string) => {
    const updated = projects.map(p => p.id === projectId ? {
      ...p,
      strategicFrontId: frontId
    } : p);
    CompanyProjectRepository.saveProjects(updated, userEmail);
    
    const projName = projects.find(p => p.id === projectId)?.name;
    const frontName = activePlanning.fronts.find(f => f.id === frontId)?.name;

    toastSuccess(`Processo "${projName}" vinculado à frente "${frontName}"!`);
    setAuditLogs(prev => [
      {
        id: `quick-link-${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        msg: `Vínculo Estratégico: Processo '${projName}' acoplado à frente '${frontName}'`,
        type: "success"
      },
      ...prev
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Dynamic Header */}
      <div className="p-6 bg-white border border-slate-300 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center text-left gap-4">
        <div>
          <h2 className="text-2xl font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
            <Compass className="text-slate-950" size={24} />
            E3I GOVERNANÇA: ESTRATÉGIA &amp; PROCESSOS
          </h2>
          <p className="text-sm text-slate-500 font-sans mt-0.5">
            Ligue o Planejamento Estratégico Clássico à engenharia operacional e simulação DMAIC do chão de fábrica.
          </p>
        </div>
        {activeCompanyId && (
          <button
            onClick={() => {
              setActiveCompanyId(null);
              setActiveProjectId(null);
            }}
            className="flex items-center gap-1.5 px-3 py-2 border-2 border-slate-900 hover:bg-slate-50 text-xs font-sans font-bold uppercase transition-all tracking-wider cursor-pointer"
          >
            <ArrowLeft size={14} /> Trocar de Empresa
          </button>
        )}
      </div>

      {/* STEP 1: COMPANY SELECTION & CREATION SCREEN (IF NO ACTIVE COMPANY ID) */}
      {!activeCompanyId ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left">
          {/* Left panel: Company selection list */}
          <div className="lg:col-span-8 bg-white border border-slate-300 p-6 space-y-6">
            <div className="border-b pb-3 border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 className="font-serif font-black text-lg text-slate-900 uppercase flex items-center gap-2">
                  <Building2 size={20} className="text-slate-800" />
                  Selecione a Empresa / Cliente
                </h3>
                <p className="text-xs text-slate-500 font-sans">Escolha uma empresa para gerenciar frentes estratégicas e simular fluxos DMAIC.</p>
              </div>
              
              {/* Search bar */}
              <div className="relative w-full sm:w-64">
                <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Buscar empresa, setor, CNPJ..." 
                  value={companySearchQuery}
                  onChange={e => setCompanySearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 pl-8 pr-3 py-1.5 text-xs font-sans focus:outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>
            </div>

            {/* Grid of companies */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredCompanies.map(c => {
                const compPlanning = c.strategicPlanning || { mission: "", fronts: [] };
                const hasPlanning = compPlanning.fronts && compPlanning.fronts.length > 0;
                const compProjs = projects.filter(p => p.companyId === c.id);
                
                const isEditing = editingCompanyId === c.id;

                return (
                  <div 
                    key={c.id}
                    className="border-2 border-slate-200 hover:border-slate-400 transition-all bg-white p-4 flex flex-col justify-between group h-full"
                  >
                    {isEditing ? (
                      <div onClick={e => e.stopPropagation()} className="space-y-3">
                        <div>
                          <label className="text-[9px] font-mono tracking-wider text-slate-400 uppercase font-bold">Nome Fantasia</label>
                          <input 
                            type="text" 
                            value={editingCompanyName} 
                            onChange={e => setEditingCompanyName(e.target.value)} 
                            className="w-full bg-white border border-slate-300 p-2 text-xs font-bold" 
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono tracking-wider text-slate-400 uppercase font-bold">CNPJ</label>
                          <input 
                            type="text" 
                            value={editingCompanyCnpj} 
                            onChange={e => setEditingCompanyCnpj(e.target.value)} 
                            className="w-full bg-white border border-slate-300 p-2 text-xs" 
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono tracking-wider text-slate-400 uppercase font-bold">Setor de Atuação</label>
                          <input 
                            type="text" 
                            value={editingCompanyInd} 
                            onChange={e => setEditingCompanyInd(e.target.value)} 
                            className="w-full bg-white border border-slate-300 p-2 text-xs" 
                          />
                        </div>
                        <div className="flex gap-2 justify-end pt-1">
                          <button 
                            onClick={() => setEditingCompanyId(null)} 
                            className="text-[10px] uppercase font-bold bg-white border border-slate-300 px-3 py-1.5 hover:bg-slate-50 cursor-pointer"
                          >
                            Cancelar
                          </button>
                          <button 
                            onClick={() => handleSaveCompanyEdit(c.id)} 
                            className="text-[10px] uppercase font-bold bg-green-700 text-white px-3 py-1.5 hover:bg-green-800 cursor-pointer"
                          >
                            Salvar
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div>
                          <div className="flex justify-between items-start gap-2">
                            <span className="p-2 bg-slate-100 text-slate-700">
                              <Building2 size={18} />
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingCompanyId(c.id);
                                  setEditingCompanyName(c.name);
                                  setEditingCompanyCnpj(c.cnpj || "");
                                  setEditingCompanyInd(c.industry || "");
                                }}
                                className="text-slate-400 hover:text-slate-900 transition-colors p-1"
                                title="Editar cadastro"
                              >
                                <Edit3 size={13} />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteCompany(c.id);
                                }}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                                title="Excluir empresa"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>

                          <h4 className="font-serif font-black text-base text-slate-900 mt-3 leading-tight group-hover:text-indigo-900 transition-colors">
                            {c.name}
                          </h4>
                          <p className="text-[10px] text-slate-500 uppercase tracking-wider font-mono mt-1">Setor: {c.industry || "Geral"}</p>
                          {c.cnpj && <p className="text-[9.5px] font-mono text-slate-400 mt-0.5">CNPJ: {c.cnpj}</p>}

                          {/* Plan and process badges */}
                          <div className="mt-4 space-y-1.5 pt-3 border-t border-slate-100">
                            <div className="flex items-center gap-1.5 text-xs">
                              <Compass size={12} className={hasPlanning ? "text-emerald-500" : "text-slate-400"} />
                              <span className={`text-[10px] font-sans font-bold ${hasPlanning ? "text-emerald-700" : "text-slate-500"}`}>
                                {hasPlanning ? "✓ Plano Estratégico Estruturado" : "⚠ Sem Planejamento Estratégico"}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 text-xs">
                              <Briefcase size={12} className="text-indigo-500" />
                              <span className="text-[10px] font-sans text-slate-600">
                                {compProjs.length} {compProjs.length === 1 ? "Processo operacional" : "Processos operacionais"}
                              </span>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setActiveCompanyId(c.id)}
                          className="w-full mt-5 bg-slate-900 group-hover:bg-indigo-650 hover:bg-indigo-700 text-white text-xs uppercase font-bold tracking-wider py-2.5 flex items-center justify-center gap-2 cursor-pointer transition-all border-b-2 border-transparent hover:border-indigo-800"
                        >
                          Acessar Estratégia &amp; Processos
                          <ArrowRight size={13} />
                        </button>
                      </>
                    )}
                  </div>
                );
              })}
              {filteredCompanies.length === 0 && (
                <div className="col-span-2 text-center py-10 bg-slate-50 border border-slate-200">
                  <p className="text-sm text-slate-500 font-sans italic">Nenhuma empresa localizada com o filtro inserido.</p>
                </div>
              )}
            </div>
          </div>

          {/* Right panel: Create Company */}
          <div className="lg:col-span-4 bg-white border border-slate-300 p-5 space-y-4">
            <div className="border-b pb-2 border-slate-100">
              <h3 className="font-bold text-slate-900 flex items-center gap-2 uppercase tracking-wide">
                <Plus size={16} className="text-[#C49746]" /> Cadastrar Nova Empresa
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">
                  Nome da Empresa / Cliente <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text" 
                  placeholder="Ex: DeltaTech SMT Processors..." 
                  value={newCompanyName} 
                  onChange={e => setNewCompanyName(e.target.value)} 
                  className="w-full bg-slate-50 border border-slate-300 p-2.5 text-xs font-sans focus:outline-none focus:border-indigo-600 focus:bg-white" 
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">
                  CNPJ (Opcional)
                </label>
                <input 
                  type="text" 
                  placeholder="Ex: 00.000.000/0001-00..." 
                  value={newCompanyCnpj} 
                  onChange={e => setNewCompanyCnpj(e.target.value)} 
                  className="w-full bg-slate-50 border border-slate-300 p-2.5 text-xs font-sans focus:outline-none focus:border-indigo-600 focus:bg-white" 
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">
                  Setor / Indústria de Atuação
                </label>
                <input 
                  type="text" 
                  placeholder="Ex: Eletroeletrônica, Varejo, Tecnologia..." 
                  value={newCompanyInd} 
                  onChange={e => setNewCompanyInd(e.target.value)} 
                  className="w-full bg-slate-50 border border-slate-300 p-2.5 text-xs font-sans focus:outline-none focus:border-indigo-600 focus:bg-white" 
                />
              </div>

              {canCreateCompany() ? (
                <button 
                  onClick={handleAddCompany}
                  disabled={!newCompanyName.trim()}
                  className="w-full bg-green-700 hover:bg-green-800 text-white text-xs uppercase font-bold tracking-wider py-2.5 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Registrar Empresa &amp; Criar Plano
                </button>
              ) : (
                <div className="bg-slate-50 p-3 border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
                  <Lock size={14} className="text-slate-400 shrink-0" />
                  <span>Seu perfil de acesso atual não possui permissões para cadastrar novas empresas.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* STEP 2: SELECTED COMPANY WORKSPACE (WITH TABS) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left">
          {/* Main workspace section */}
          <div className="lg:col-span-9 bg-white border border-slate-300 space-y-6">
            
            {/* Active Company Header */}
            <div className="bg-slate-50 p-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <span className="text-[9px] font-mono tracking-widest text-indigo-700 uppercase font-black">Camada de Gestão da Empresa (Tenant Ativo)</span>
                <h3 className="font-serif font-black text-2xl text-slate-900 uppercase leading-none mt-1 flex items-center gap-2">
                  <Building2 size={22} className="text-[#C49746]" />
                  {activeCompany?.name}
                </h3>
                <p className="text-xs text-slate-500 font-sans mt-1">
                  Setor: <strong className="text-slate-700">{activeCompany?.industry || "Geral"}</strong>
                  {activeCompany?.cnpj && <span className="ml-3">CNPJ: <strong className="text-slate-700">{activeCompany.cnpj}</strong></span>}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs shrink-0">
                <span className="bg-emerald-100 text-emerald-800 border border-emerald-200 px-3 py-1 uppercase tracking-wider font-mono font-black text-[10px] rounded-xs flex items-center gap-1">
                  <CheckCircle size={12} className="text-emerald-600" /> Camada Ativa
                </span>
              </div>
            </div>

            {/* Painel de Métricas Gerais da Empresa */}
            {(() => {
              const companyProjs = projects.filter(p => p.companyId === activeCompanyId);
              const totalProjs = companyProjs.length;
              const inProgress = companyProjs.filter(p => p.status === "Em Andamento").length;
              const completed = companyProjs.filter(p => p.status === "Concluído").length;
              const planned = companyProjs.filter(p => p.status === "Planejado").length;
              const diagWaste = activeCompany?.diagnosticData?.estimatedAnnualWaste || 0;
              const score = activeCompany?.diagnosticData?.score || (totalProjs > 0 ? 88 : 75);

              return (
                <div className="px-6 pt-4">
                  <div className="p-4 bg-slate-900 text-white rounded-xs shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                      <div className="flex items-center gap-2">
                        <TrendingUp size={18} className="text-[#C49746]" />
                        <h4 className="font-serif font-black text-sm uppercase tracking-wider text-slate-100">
                          Métricas Gerais da Empresa
                        </h4>
                      </div>
                      <span className="text-[9.5px] font-mono text-slate-400 uppercase tracking-widest">
                        Consolidado Corporativo
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
                      <div className="bg-slate-850 p-3 border border-slate-800 rounded-xs">
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-400">Projetos Vinculados</p>
                        <p className="text-2xl font-serif font-black text-white mt-1">{totalProjs}</p>
                        <p className="text-[10px] text-slate-400 mt-1 font-sans">
                          <span className="text-amber-400 font-bold">{inProgress}</span> em andamento &bull; <span className="text-emerald-400 font-bold">{completed}</span> concluídos
                        </p>
                      </div>

                      <div className="bg-slate-850 p-3 border border-slate-800 rounded-xs">
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-400">Frentes Estratégicas</p>
                        <p className="text-2xl font-serif font-black text-[#C49746] mt-1">{activePlanning.fronts.length}</p>
                        <p className="text-[10px] text-slate-400 mt-1 font-sans">BSC: Fin, Cli, Proc, Pes</p>
                      </div>

                      <div className="bg-slate-850 p-3 border border-slate-800 rounded-xs">
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-400">Impacto / COPQ Estimado</p>
                        <p className="text-lg font-serif font-black text-emerald-400 mt-1 truncate">
                          {diagWaste > 0 ? `R$ ${Math.round(diagWaste).toLocaleString("pt-BR")}` : "R$ 150.000"}
                        </p>
                        <p className="text-[10px] text-slate-400 mt-1 font-sans">Potencial de economia anual</p>
                      </div>

                      <div className="bg-slate-850 p-3 border border-slate-800 rounded-xs">
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-400">Maturidade LSS</p>
                        <p className="text-2xl font-serif font-black text-indigo-300 mt-1">{score}/100</p>
                        <p className="text-[10px] text-emerald-400 mt-1 font-bold font-sans">Excelente Nível de Saúde</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Strategic & Operational Navigation Tabs */}
            <div className="flex border-b border-slate-200 bg-slate-50/50 mt-2">
              <button 
                onClick={() => setActiveTab("projects")}
                className={`flex items-center gap-2 px-6 py-4 font-sans font-black text-xs uppercase tracking-wider border-b-2 cursor-pointer transition-all ${activeTab === "projects" ? "border-indigo-600 text-indigo-900 bg-white font-black" : "border-transparent text-slate-500 hover:text-slate-800"}`}
              >
                <Briefcase size={15} className="text-[#C49746]" />
                1. Métricas &amp; Projetos Vinculados ({projects.filter(p => p.companyId === activeCompanyId).length})
              </button>
              <button 
                onClick={() => setActiveTab("strategic")}
                className={`flex items-center gap-2 px-6 py-4 font-sans font-black text-xs uppercase tracking-wider border-b-2 cursor-pointer transition-all ${activeTab === "strategic" ? "border-indigo-600 text-indigo-900 bg-white font-black" : "border-transparent text-slate-500 hover:text-slate-800"}`}
              >
                <Compass size={15} className="text-indigo-600" />
                2. Planejamento Estratégico &amp; BSC
              </button>
            </div>

            {/* TAB CONTENTS */}
            <div className="p-6 pt-2">
              
              {/* TAB 1: STRATEGIC PLANNING TAB */}
              {activeTab === "strategic" && (
                <div className="space-y-8 animate-fade-in">
                  
                  {/* Mission, Vision, Values section */}
                  <div className="border border-slate-200 p-5 bg-slate-50/40 relative">
                    <div className="flex justify-between items-center border-b pb-3 mb-4">
                      <h4 className="font-serif font-black text-sm uppercase text-slate-900 tracking-wide flex items-center gap-2">
                        <Compass size={16} className="text-[#C49746]" />
                        Diretrizes Estratégicas Corporativas
                      </h4>
                      {!isEditingPlanningDir ? (
                        <button 
                          onClick={() => setIsEditingPlanningDir(true)}
                          className="text-[10px] font-sans font-bold uppercase tracking-wider text-indigo-600 hover:text-indigo-800 underline cursor-pointer"
                        >
                          Editar Diretrizes
                        </button>
                      ) : (
                        <div className="flex gap-2">
                          <button 
                            onClick={() => setIsEditingPlanningDir(false)}
                            className="text-[10px] font-sans font-bold uppercase tracking-wider text-slate-500 hover:text-slate-800 border px-2 py-1 cursor-pointer bg-white"
                          >
                            Cancelar
                          </button>
                          <button 
                            onClick={handleSaveGuidelines}
                            className="text-[10px] font-sans font-bold uppercase tracking-wider bg-indigo-600 text-white px-2 py-1 cursor-pointer hover:bg-indigo-700"
                          >
                            Salvar Alterações
                          </button>
                        </div>
                      )}
                    </div>

                    {isEditingPlanningDir ? (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Missão</label>
                          <textarea 
                            value={planMission} 
                            onChange={e => setPlanMission(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2.5 text-xs h-24 font-sans resize-none text-slate-700"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Visão</label>
                          <textarea 
                            value={planVision} 
                            onChange={e => setPlanVision(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2.5 text-xs h-24 font-sans resize-none text-slate-700"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Valores (separados por vírgula)</label>
                          <textarea 
                            value={planValues} 
                            onChange={e => setPlanValues(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2.5 text-xs h-24 font-sans resize-none text-slate-700"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs font-sans text-slate-700">
                        <div className="border-r border-slate-200 pr-4 last:border-0">
                          <p className="font-bold text-slate-900 uppercase text-[9.5px] font-mono tracking-wider text-indigo-700">Missão</p>
                          <p className="mt-1.5 leading-relaxed text-slate-600 italic">&ldquo;{activePlanning.mission}&rdquo;</p>
                        </div>
                        <div className="border-r border-slate-200 pr-4 last:border-0">
                          <p className="font-bold text-slate-900 uppercase text-[9.5px] font-mono tracking-wider text-indigo-700">Visão de Futuro</p>
                          <p className="mt-1.5 leading-relaxed text-slate-600 italic">&ldquo;{activePlanning.vision}&rdquo;</p>
                        </div>
                        <div>
                          <p className="font-bold text-slate-900 uppercase text-[9.5px] font-mono tracking-wider text-indigo-700">Valores</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {activePlanning.values.split(",").map((v, i) => (
                              <span key={i} className="bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-medium px-2 py-0.5 font-sans">
                                {v.trim()}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Strategic Fronts & Objectives (BSC-inspired) */}
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif font-black text-slate-900 text-lg uppercase">
                        Frentes Estratégicas &amp; Desdobramento de Objetivos
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5 font-sans">
                        Gerencie os objetivos táticos para cada área e vincule os processos operacionais mapeados para monitoramento contínuo.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {activePlanning.fronts.map(front => {
                        // Filter processes linked to this strategic front
                        const linkedProjects = projects.filter(
                          p => p.companyId === activeCompanyId && p.strategicFrontId === front.id
                        );

                        // Layout configurations based on front ID for premium visual variety
                        let cardColor = "border-l-4 border-l-blue-600";
                        let bgHeader = "bg-blue-50/40 text-blue-900";
                        if (front.id === "clientes") {
                          cardColor = "border-l-4 border-l-amber-500";
                          bgHeader = "bg-amber-50/40 text-amber-900";
                        } else if (front.id === "processos") {
                          cardColor = "border-l-4 border-l-emerald-600";
                          bgHeader = "bg-emerald-50/40 text-emerald-900";
                        } else if (front.id === "aprendizado") {
                          cardColor = "border-l-4 border-l-indigo-600";
                          bgHeader = "bg-indigo-50/40 text-indigo-900";
                        }

                        return (
                          <div 
                            key={front.id}
                            className={`border border-slate-200 bg-white shadow-xs flex flex-col justify-between ${cardColor}`}
                          >
                            <div>
                              {/* Front header */}
                              <div className={`p-4 border-b border-slate-100 flex justify-between items-start ${bgHeader}`}>
                                <div className="text-left">
                                  <h5 className="font-serif font-black uppercase text-sm tracking-wide leading-tight flex items-center gap-1.5">
                                    <Target size={14} className="opacity-80" />
                                    Frente {front.name}
                                  </h5>
                                  <p className="text-[10px] opacity-80 mt-1 font-sans leading-relaxed">{front.description}</p>
                                </div>
                              </div>

                              {/* Objectives list */}
                              <div className="p-4 space-y-3">
                                <div className="flex justify-between items-center pb-1 border-b border-slate-100">
                                  <span className="text-[9.5px] font-mono uppercase font-bold text-slate-400">Objetivos Estratégicos</span>
                                  {addingObjectiveFrontId !== front.id && (
                                    <button 
                                      onClick={() => {
                                        setAddingObjectiveFrontId(front.id);
                                        setNewObjTitle("");
                                        setNewObjIndicator("");
                                        setNewObjTarget("");
                                      }}
                                      className="text-[9.5px] font-sans font-bold uppercase text-indigo-650 hover:text-indigo-850 flex items-center gap-0.5 cursor-pointer"
                                    >
                                      <Plus size={10} /> Add Objetivo
                                    </button>
                                  )}
                                </div>

                                {/* Objective creation form inline */}
                                {addingObjectiveFrontId === front.id && (
                                  <div className="bg-slate-50 p-3 border border-slate-200 space-y-2 text-left mb-3 animate-fade-in">
                                    <p className="text-[9px] font-mono uppercase font-bold text-indigo-800">Novo Objetivo</p>
                                    <input 
                                      type="text" 
                                      placeholder="Ex: Reduzir tempo de faturamento..." 
                                      value={newObjTitle}
                                      onChange={e => setNewObjTitle(e.target.value)}
                                      className="w-full bg-white border border-slate-300 p-1.5 text-xs font-sans focus:outline-none"
                                    />
                                    <div className="grid grid-cols-2 gap-2">
                                      <input 
                                        type="text" 
                                        placeholder="Indicador (Ex: Tempo médio)..." 
                                        value={newObjIndicator}
                                        onChange={e => setNewObjIndicator(e.target.value)}
                                        className="w-full bg-white border border-slate-300 p-1.5 text-xs font-sans focus:outline-none"
                                      />
                                      <input 
                                        type="text" 
                                        placeholder="Meta (Ex: < 2 horas)..." 
                                        value={newObjTarget}
                                        onChange={e => setNewObjTarget(e.target.value)}
                                        className="w-full bg-white border border-slate-300 p-1.5 text-xs font-sans focus:outline-none"
                                      />
                                    </div>
                                    <div className="flex gap-2 justify-end pt-1">
                                      <button 
                                        onClick={() => setAddingObjectiveFrontId(null)}
                                        className="text-[9px] uppercase px-2 py-1 bg-white border cursor-pointer hover:bg-slate-50 font-bold"
                                      >
                                        Cancelar
                                      </button>
                                      <button 
                                        onClick={() => handleAddObjective(front.id)}
                                        className="text-[9px] uppercase px-3 py-1 bg-green-700 hover:bg-green-800 text-white cursor-pointer font-bold"
                                      >
                                        Salvar
                                      </button>
                                    </div>
                                  </div>
                                )}

                                {/* List targets */}
                                <div className="space-y-2">
                                  {front.objectives.map(obj => (
                                    <div 
                                      key={obj.id}
                                      className="group/obj flex justify-between items-start bg-slate-50/50 p-2 border border-slate-150 rounded-xs"
                                    >
                                      <div className="text-left flex-grow">
                                        <p className="text-[11.5px] font-semibold text-slate-800">{obj.title}</p>
                                        <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-500 font-mono">
                                          <span>📊 Indicador: <strong className="text-slate-700">{obj.indicator}</strong></span>
                                          <span>🎯 Meta: <strong className="text-slate-700">{obj.target}</strong></span>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => handleDeleteObjective(front.id, obj.id)}
                                        className="text-slate-350 hover:text-red-500 transition-colors p-1 shrink-0 cursor-pointer md:opacity-0 group-hover/obj:opacity-100"
                                        title="Remover objetivo estratégico"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                    </div>
                                  ))}
                                  {front.objectives.length === 0 && (
                                    <p className="text-[11px] text-slate-400 italic py-1 text-center font-sans">Sem objetivos cadastrados nesta frente.</p>
                                  )}
                                </div>
                              </div>

                              {/* Linked Processes (RELATIONAL BINDING) */}
                              <div className="p-4 pt-0 border-t border-slate-100/60 mt-2 space-y-2.5">
                                <div className="flex items-center gap-1.5 text-[9.5px] font-mono uppercase font-bold text-slate-400">
                                  <CheckSquare size={11} className="text-slate-400" />
                                  <span>Processos Vinculados ({linkedProjects.length})</span>
                                </div>

                                <div className="space-y-1.5">
                                  {linkedProjects.map(proj => (
                                    <div 
                                      key={proj.id}
                                      onClick={() => {
                                        setActiveProjectId(proj.id);
                                        setActiveTab("projects");
                                      }}
                                      className="flex justify-between items-center p-2 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 transition-all cursor-pointer group/link"
                                    >
                                      <div className="text-left min-w-0">
                                        <span className="text-xs font-bold text-slate-800 block truncate group-hover/link:text-indigo-900 transition-colors">
                                          {proj.name}
                                        </span>
                                        <span className="text-[9px] text-slate-500 truncate block mt-0.5">
                                          Metas: {proj.objective}
                                        </span>
                                      </div>
                                      <span className="shrink-0 text-[9px] bg-white border border-slate-200 group-hover/link:border-indigo-200 group-hover/link:bg-indigo-600 group-hover/link:text-white px-2 py-0.5 font-bold uppercase transition-all flex items-center gap-0.5">
                                        Ver <ChevronRight size={10} />
                                      </span>
                                    </div>
                                  ))}
                                  {linkedProjects.length === 0 && (
                                    <div className="p-3 bg-slate-50/50 border border-dashed border-slate-200 text-center text-[10.5px] text-slate-400 italic">
                                      Nenhum processo vinculado. Vá para a aba "Processos &amp; Projetos" para vincular um fluxo aqui.
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PROCESSES & PROJECTS OPERATIONAL TAB */}
              {activeTab === "projects" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b pb-3 border-slate-100 gap-3">
                    <div>
                      <h4 className="font-serif font-black text-slate-900 text-lg uppercase flex items-center gap-2">
                        <Briefcase size={18} className="text-[#C49746]" />
                        Mapeamento de Processos Operacionais
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5 font-sans">
                        Crie e gerencie os fluxos, SIPOC, Project Charters e limites de variabilidade estatística de cada setor.
                      </p>
                    </div>
                    <button 
                      onClick={() => { 
                        setNewProjectMode(!newProjectMode); 
                        setProjectFormError(null); 
                      }} 
                      className="text-[10.5px] uppercase font-bold bg-indigo-600 hover:bg-indigo-750 transition-colors text-white px-3 py-2 flex items-center gap-1.5 cursor-pointer rounded-xs shrink-0"
                    >
                      <Plus size={12}/> Novo Processo
                    </button>
                  </div>

                  {/* Form Create */}
                  {newProjectMode && (
                    <div className="bg-indigo-50/30 p-4 border-2 border-indigo-100 space-y-4 animate-fade-in">
                      {projectFormError && (
                        <div className="bg-rose-50 border-l-4 border-rose-500 p-2.5 text-xs text-rose-800 font-sans font-medium">
                          ⚠️ {projectFormError}
                        </div>
                      )}
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] uppercase font-bold text-slate-600 mb-1 block">Nome do Processo / Projeto <span className="text-red-500">*</span></label>
                          <input 
                            type="text" 
                            placeholder="Ex: Processo de Contas a Pagar, Processo Comercial..." 
                            value={newProjectName} 
                            onChange={e => { setNewProjectName(e.target.value); setProjectFormError(null); }} 
                            className="w-full bg-white border border-slate-300 p-2.5 text-xs font-bold focus:outline-none focus:border-indigo-600" 
                          />
                        </div>

                        <div>
                          <label className="text-[10px] uppercase font-bold text-slate-600 mb-1 block">Vincular à Frente Estratégica</label>
                          <select
                            value={newProjectFrontId}
                            onChange={e => setNewProjectFrontId(e.target.value)}
                            className="bg-white border border-slate-300 text-xs p-2.5 w-full font-bold focus:outline-none focus:border-indigo-600 text-slate-800"
                          >
                            <option value="">Selecione uma frente...</option>
                            {activePlanning.fronts.map(f => (
                              <option key={f.id} value={f.id}>Frente {f.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-600 mb-1 block">Escopo / Objetivo Operacional</label>
                        <textarea 
                          placeholder="Ex: Otimizar o tempo de conciliação tributária para garantir os prazos operacionais definidos pela diretoria..." 
                          value={newProjectObj} 
                          onChange={e => { setNewProjectObj(e.target.value); setProjectFormError(null); }} 
                          className="w-full bg-white border border-slate-300 p-2.5 text-xs h-20 resize-none font-sans focus:outline-none focus:border-indigo-600 text-slate-700 leading-relaxed" 
                        />
                      </div>
                      
                      <div className="flex gap-2 justify-end pt-2 border-t border-indigo-100">
                        <button 
                          onClick={() => { 
                            setNewProjectMode(false); 
                            setProjectFormError(null); 
                          }} 
                          className="text-[10.5px] uppercase font-bold text-slate-500 hover:text-slate-800 px-3 cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button 
                          onClick={handleAddProject} 
                          className="text-[10.5px] uppercase font-bold tracking-wide bg-indigo-600 hover:bg-indigo-750 text-white px-5 py-2 cursor-pointer transition-colors"
                        >
                          Criar e Vincular Processo
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Projects List */}
                  <div className="space-y-4">
                    {projects.filter(p => p.companyId === activeCompanyId).map(p => {
                      const isEditingProject = editingProjectId === p.id;
                      const linkedFront = activePlanning.fronts.find(f => f.id === p.strategicFrontId);

                      // Colors for fronts
                      let badgeStyle = "bg-slate-100 text-slate-700 border-slate-200";
                      if (p.strategicFrontId === "financeiro") {
                        badgeStyle = "bg-blue-50 text-blue-700 border-blue-200";
                      } else if (p.strategicFrontId === "clientes") {
                        badgeStyle = "bg-amber-50 text-amber-700 border-amber-200";
                      } else if (p.strategicFrontId === "processos") {
                        badgeStyle = "bg-emerald-50 text-emerald-700 border-emerald-200";
                      } else if (p.strategicFrontId === "aprendizado") {
                        badgeStyle = "bg-indigo-50 text-indigo-700 border-indigo-200";
                      }

                      return (
                        <div 
                          key={p.id} 
                          className={`p-4 border-2 transition-all cursor-pointer bg-white group ${activeProjectId === p.id ? 'border-indigo-600 shadow-[4px_4px_0px_0px_rgba(79,70,229,0.15)] ring-1 ring-indigo-600' : 'border-slate-200 hover:border-indigo-300'}`} 
                          onClick={() => setActiveProjectId(p.id)}
                        >
                          {isEditingProject ? (
                            <div onClick={(e) => e.stopPropagation()} className="space-y-3 p-1 text-left">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Nome do Processo</label>
                                  <input 
                                    type="text" 
                                    value={editingProjectName} 
                                    onChange={e => setEditingProjectName(e.target.value)} 
                                    className="w-full bg-white border border-slate-300 p-2 text-xs font-bold font-sans focus:outline-none focus:border-indigo-600" 
                                  />
                                </div>
                                <div>
                                  <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Vincular à Frente Estratégica</label>
                                  <select
                                    value={editingProjectFrontId}
                                    onChange={e => setEditingProjectFrontId(e.target.value)}
                                    className="bg-white border border-slate-300 text-xs p-2.5 w-full font-bold focus:outline-none focus:border-indigo-600 text-slate-800"
                                  >
                                    <option value="">Nenhuma frente estratégica...</option>
                                    {activePlanning.fronts.map(f => (
                                      <option key={f.id} value={f.id}>Frente {f.name}</option>
                                    ))}
                                  </select>
                                </div>
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Objetivo / Escopo</label>
                                <textarea 
                                  value={editingProjectObj} 
                                  onChange={e => setEditingProjectObj(e.target.value)} 
                                  className="w-full bg-white border border-slate-300 p-2 text-xs h-20 resize-none font-sans focus:outline-none focus:border-indigo-600 text-slate-700" 
                                />
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-500 block mb-1">Fase / Status</label>
                                <select
                                  value={editingProjectStatus}
                                  onChange={e => setEditingProjectStatus(e.target.value as any)}
                                  className="bg-white border border-slate-300 text-xs p-2.5 w-full font-bold focus:outline-none"
                                >
                                  <option value="Planejado">Planejado</option>
                                  <option value="Em Andamento">Em Andamento</option>
                                  <option value="Concluído">Concluído</option>
                                </select>
                              </div>
                              <div className="flex gap-2 justify-end pt-2 border-t border-slate-100">
                                <button 
                                  onClick={() => setEditingProjectId(null)} 
                                  className="text-[10.5px] uppercase font-bold text-slate-500 hover:text-slate-800 px-3 cursor-pointer select-none"
                                >
                                  Cancelar
                                </button>
                                <button 
                                  onClick={() => handleSaveProjectEdit(p.id)} 
                                  className="text-[10.5px] uppercase font-bold bg-indigo-600 text-white px-4 py-2 hover:bg-indigo-750 cursor-pointer transition-colors"
                                >
                                  Salvar Ajustes
                                </button>
                              </div>
                            </div>
                          ) : (
                            <>
                              <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                                <div className="text-left">
                                  <div className="flex flex-wrap items-center gap-2 mb-2">
                                    <h4 className={`font-bold text-base leading-tight ${activeProjectId === p.id ? 'text-indigo-900' : 'text-slate-900 group-hover:text-indigo-700'}`}>
                                      {p.name}
                                    </h4>
                                    
                                    {/* Binding badge */}
                                    {linkedFront ? (
                                      <span className={`border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider ${badgeStyle} flex items-center gap-1`}>
                                        <Target size={10} /> Frente: {linkedFront.name}
                                      </span>
                                    ) : (
                                      <span className="bg-rose-50 text-rose-700 border border-rose-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1 animate-pulse">
                                        ⚠ Sem Vínculo Estratégico
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-slate-500 max-w-lg leading-relaxed line-clamp-2">{p.objective}</p>
                                </div>
                                <span className="bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider whitespace-nowrap">{p.status}</span>
                              </div>

                              {/* Binding action inline helper if missing linkage */}
                              {!p.strategicFrontId && (
                                <div onClick={e => e.stopPropagation()} className="mt-3 bg-rose-50/50 p-2.5 border border-rose-100 text-[10.5px] text-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                                  <span className="flex items-center gap-1 font-sans text-rose-800">
                                    <Info size={13} className="text-rose-500" />
                                    Deseja vincular este processo a qual frente do plano estratégico corporativo?
                                  </span>
                                  <div className="flex flex-wrap gap-1">
                                    {activePlanning.fronts.map(f => (
                                      <button
                                        key={f.id}
                                        onClick={() => handleQuickLinkProject(p.id, f.id)}
                                        className="bg-white border border-slate-300 hover:border-indigo-600 hover:bg-indigo-50 px-2 py-1 text-[9px] font-bold uppercase tracking-wider transition-all text-slate-700 hover:text-indigo-900 cursor-pointer"
                                      >
                                        Frente {f.name}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}

                              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fade-in" onClick={e => e.stopPropagation()}>
                                <span className="text-[9.5px] text-indigo-700 font-mono font-bold bg-indigo-50 border border-indigo-100 px-2 py-1 uppercase tracking-tight flex items-center gap-1">
                                  {activeProjectId === p.id ? "📁 Projeto Ativo Selecionado" : "📁 Projeto da Empresa"}
                                </span>
                                
                                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                                  <button 
                                    onClick={() => {
                                      setEditingProjectId(p.id);
                                      setEditingProjectName(p.name);
                                      setEditingProjectObj(p.objective);
                                      setEditingProjectStatus(p.status);
                                      setEditingProjectFrontId(p.strategicFrontId || "");
                                    }}
                                    className="text-xs text-slate-600 hover:text-slate-900 px-2.5 py-1.5 border border-slate-200 hover:bg-slate-50 font-bold transition-colors cursor-pointer rounded-xs"
                                  >
                                    Editar
                                  </button>
                                  <button 
                                    onClick={() => { 
                                      CompanyProjectRepository.saveProjects(projects.filter(pr => pr.id !== p.id), userEmail); 
                                      if (activeProjectId === p.id) setActiveProjectId(null); 
                                      toastSuccess("Processo removido com sucesso.");
                                    }} 
                                    className="text-xs text-rose-600 hover:text-rose-800 px-2.5 py-1.5 border border-rose-200 hover:bg-rose-50 font-bold transition-colors cursor-pointer rounded-xs"
                                  >
                                    Excluir
                                  </button>
                                  <button 
                                    onClick={() => {
                                      setActiveProjectId(p.id);
                                      onNavigateToMap();
                                    }} 
                                    className="w-full sm:w-auto bg-slate-900 hover:bg-slate-950 text-white text-[10.5px] uppercase font-bold tracking-wider px-4 py-2 flex items-center justify-center gap-2 cursor-pointer shadow-3xs transition-all rounded-xs"
                                  >
                                    <Map size={13} className="text-[#C49746]" /> 🚀 Acessar Projeto
                                  </button>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      );
                    })}
                    {projects.filter(p => p.companyId === activeCompanyId).length === 0 && !newProjectMode && (
                      <p className="text-xs text-slate-500 bg-slate-50 p-6 border border-slate-200 text-center font-medium font-sans">
                        Não há processos modelados para o cliente selecionado. Crie um novo acima para iniciar.
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Col: Firebase Admin Security Center & Compliance Logs */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Active Company stats card */}
            <div className="bg-slate-50 border border-slate-300 p-5 space-y-4 text-left">
              <div className="border-b border-slate-200 pb-2 flex items-center gap-1.5 text-slate-800">
                <Sliders size={15} className="text-[#C49746]" />
                <h4 className="text-xs font-mono font-black uppercase tracking-wider">Estatísticas do Cliente</h4>
              </div>

              <div className="space-y-3 font-sans text-xs text-slate-600">
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span>Processos Totais:</span>
                  <span className="font-bold text-slate-800">{projects.filter(p => p.companyId === activeCompanyId).length}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span>Frentes Ativas:</span>
                  <span className="font-bold text-slate-800">
                    {activePlanning.fronts.length}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span>Objetivos Cadastrados:</span>
                  <span className="font-bold text-slate-800">
                    {activePlanning.fronts.reduce((acc, curr) => acc + curr.objectives.length, 0)}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span>Processos Vinculados:</span>
                  <span className="font-bold text-emerald-600">
                    {projects.filter(p => p.companyId === activeCompanyId && !!p.strategicFrontId).length}
                  </span>
                </div>
              </div>
            </div>

            {/* Dynamic Diagnostic Data from CRM Lead */}
            {(() => {
              if (activeCompany?.diagnosticData) {
                const diag = activeCompany.diagnosticData;
                return (
                  <div className="bg-slate-50 border border-slate-300 p-4 space-y-3 rounded-none text-left">
                    <div className="flex justify-between items-center border-b border-slate-250 pb-1.5">
                      <span className="text-xs font-mono font-black text-indigo-950 flex items-center gap-1">
                        📋 DIAGNÓSTICO DO LEAD
                      </span>
                      <span className="text-[9.5px] font-mono bg-[#C49746] text-slate-950 px-2 py-0.5 uppercase font-bold">
                        Score: {diag.score}/100
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <p className="text-slate-500 font-sans text-[10.5px]">Público:</p>
                        <p className="font-bold text-slate-800">{diag.audienceType === "LEIGO" ? "💡 Pessoa Leiga" : "🛡️ Especialista LSS"}</p>
                      </div>
                      <div>
                        <p className="text-slate-500 font-sans text-[10.5px]">COPQ Estimado:</p>
                        <p className="font-bold text-slate-800">R$ {Math.round(diag.estimatedAnnualWaste || 0).toLocaleString("pt-BR")}/ano</p>
                      </div>
                      <div>
                        <p className="text-slate-500 font-sans text-[10.5px]">Volume Mensal:</p>
                        <p className="font-bold text-slate-800">{(diag.volume || 0).toLocaleString("pt-BR")} un</p>
                      </div>
                      <div>
                        <p className="text-slate-500 font-sans text-[10.5px]">Retorno Estimado:</p>
                        <p className="font-bold text-emerald-600">R$ {Math.round(diag.estimatedSavingsAfterE3I || 0).toLocaleString("pt-BR")}/ano</p>
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 p-2 text-[11px] text-slate-600 leading-normal font-sans italic">
                      &ldquo;{diag.advice}&rdquo;
                    </div>
                  </div>
                );
              }
              return null;
            })()}

            {/* Tenant Compliance Indicator block */}
            <div className="bg-slate-900 text-white p-5 space-y-4 border border-slate-900 rounded-none shadow-sm relative">
              <div className="absolute top-3 right-3 shrink-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[8px] font-mono font-bold tracking-widest uppercase px-1.5 py-0.5 rounded-sm">
                SEGURO
              </div>

              <div className="flex items-center gap-2 border-b border-white/10 pb-2.5">
                <Shield size={16} className="text-emerald-400 shrink-0" />
                <h4 className="text-xs uppercase tracking-wider font-mono font-black text-slate-100">Firebase Admin SDK</h4>
              </div>

              <div className="space-y-3 pt-1 text-xs">
                <div className="flex justify-between items-center text-[11px] border-b border-white/5 pb-1.5 text-slate-300">
                  <span>Verificação:</span>
                  <span className="font-mono font-bold text-emerald-400 flex items-center gap-0.5"><CheckCircle size={10} /> Central Ativa</span>
                </div>
                <div className="flex justify-between items-center text-[11px] border-b border-white/5 pb-1.5 text-slate-300">
                  <span>Role Autenticada:</span>
                  <span className="font-sans font-bold bg-[#C49746]/20 text-[#C49746] px-2 py-0.2 rounded-xs text-[10.5px]">
                    {activeUser?.role || "Admin"}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px] border-b border-white/5 pb-1.5 text-slate-300">
                  <span>Isolamento Multi-Tenant:</span>
                  <span className="font-mono text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.2 rounded-xs text-[10px]">Ativo</span>
                </div>
                <div className="pt-1.5 text-[10px] text-slate-400 leading-normal font-sans text-left">
                  A tecnologia <strong className="text-slate-200">Tenant Isolation</strong> no Firestore garante que nenhum registro cross-leak ocorra entre as organizações registradas.
                </div>
              </div>
            </div>

            {/* Audit Telemetry Console */}
            <div className="bg-slate-955 p-4 border border-slate-800 space-y-3 text-left">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10.5px] uppercase font-mono font-extrabold pb-2 border-b border-slate-900">
                <Terminal size={14} className="text-slate-400" />
                <span>LOGS DE AUDITORIA</span>
              </div>

              <div className="h-56 overflow-y-auto font-mono text-[9.5px] space-y-2.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                {auditLogs.map((log) => (
                  <div key={log.id} className="leading-normal flex items-start gap-1.5 hover:bg-white/5 p-1 transition-colors">
                    <span className="text-slate-600 shrink-0 select-none">[{log.time}]</span>
                    <span className={`break-words ${
                      log.type === "success" ? "text-emerald-400" :
                      log.type === "warn" ? "text-rose-500 font-semibold" :
                      "text-slate-350"
                    }`}>
                      {log.msg}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
