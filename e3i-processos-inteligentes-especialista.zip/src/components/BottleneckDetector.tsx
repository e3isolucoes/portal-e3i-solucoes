import React, { useState, useEffect } from "react";
import { 
  AlertTriangle, 
  TrendingUp, 
  Clock, 
  Sliders, 
  CheckCircle2, 
  HelpCircle,
  Sparkles,
  Search,
  Zap,
  Briefcase
} from "lucide-react";
import { ProcessStep } from "../types";

interface BottleneckDetectorProps {
  steps: ProcessStep[];
  arrivalRate: number;
  onInitiateDmaic: (step: ProcessStep) => void;
  selectedStepId?: string | null;
  onClearFilter?: () => void;
}

export default function BottleneckDetector({ 
  steps, 
  arrivalRate, 
  onInitiateDmaic,
  selectedStepId,
  onClearFilter
}: BottleneckDetectorProps) {
  const [selectedBottleneckId, setSelectedBottleneckId] = useState<string | null>(steps[0]?.id || null);

  // Sync selectedBottleneckId when steps change or selectedStepId changes
  useEffect(() => {
    if (selectedStepId && selectedStepId !== "ALL") {
      setSelectedBottleneckId(selectedStepId);
    } else if (steps.length > 0 && (!selectedBottleneckId || !steps.some(s => s.id === selectedBottleneckId))) {
      setSelectedBottleneckId(steps[0].id);
    }
  }, [selectedStepId, steps]);

  // Advanced scoring algorithm to rank bottleneck severity
  // Utilizes Queueing Theory factors + Six Sigma Quality constraints
  const analyzedSteps = steps.map((step) => {
    const localCapacityPerHour = (60 / step.processingTime) * step.resourceCount;
    const utilization = (arrivalRate / localCapacityPerHour) * 100;
    
    // Coeficient of Variation representing stochastic instability
    const cv = step.standardDeviation / step.processingTime;
    
    // Quality loss penalty
    const qualityLoss = (1 - step.yieldRate) * 100;

    // Rank Score weighting
    // Capacity Utilization (weight 1.5) + Quality rework penalty (weight 1.2) + Variability index (weight 40) + Setup inertia (weight 1.0)
    const priorityScore = (utilization * 1.5) + (qualityLoss * 1.2) + (cv * 40) + (step.setupTime * 0.5);

    return {
      ...step,
      utilization,
      capacityPerHour: localCapacityPerHour,
      cv,
      priorityScore,
      qualityLoss
    };
  });

  // Sort by priorityScore descending to rank bottlenecks
  const rankedBottlenecks = [...analyzedSteps].sort((a, b) => b.priorityScore - a.priorityScore);

  const selectedStep = rankedBottlenecks.find((s) => s.id === selectedBottleneckId) || rankedBottlenecks[0];

  // Root cause heuristics representing local data patterns
  const detectRootCauses = (step: typeof rankedBottlenecks[0]) => {
    const causes: { title: string; type: "CAPACITY" | "VARIABILITY" | "QUALITY" | "SETUP"; text: string; action: string }[] = [];

    if (step.utilization >= 90) {
      causes.push({
        title: "Saturação de Capacidade de Trabalho",
        type: "CAPACITY",
        text: `A utilização local de ${step.utilization.toFixed(1)}% está próxima ou ultrapassa o limite operacional saudável. A taxa de chegada de ordens (${arrivalRate} u/h) compete excessivamente pelos recursos disponíveis (${step.resourceCount} operador/es).`,
        action: "Balanceamento de Linha: Adicione recursos executores ou reagrupe atividades operacionais para elevar a vazão máxima local."
      });
    }

    if (step.cv >= 0.25) {
      causes.push({
        title: "Alta Variabilidade Estatística (Coeficiente de Variação)",
        type: "VARIABILITY",
        text: `O desvio padrão (${step.standardDeviation} min) representa ${(step.cv * 100).toFixed(0)}% do tempo de toque médio (${step.processingTime} min). Isso indica instabilidade crônica nos métodos de trabalho, fadiga no operador ou falta de padronização nas instruções.`,
        action: "Padronização Kaizen / 5S: Documente um Procedimento Operacional Padrão (POP) e execute treinamentos focados de capabilidade."
      });
    }

    if (step.yieldRate < 0.95) {
      causes.push({
        title: "Perda de Rendimento e Descarte de Qualidade",
        type: "QUALITY",
        text: `A taxa de rendimento de primeira passagem é de ${(step.yieldRate * 100).toFixed(0)}%. Isso significa que ${(100 - step.yieldRate * 100).toFixed(0)}% das unidades produzidas requerem retrabalho ou descarte manual, consumindo recursos secundários e provocando atrasos adicionais.`,
        action: "Dispositivos Poka-Yoke: Crie mecanismos físicos ou checagens automatizadas de proteção que impeçam o erro de qualidade de seguir adiante."
      });
    }

    if (step.setupTime >= 8) {
      causes.push({
        title: "Perda de Velocidade por Longo Setup de Linha",
        type: "SETUP",
        text: `O tempo de setup de ${step.setupTime} minutos interrompe o fluxo contínuo. Setups elevados restringem a flexibilidade da linha de produção e induzem os operadores a produzir em lotes elevados, criando estoques WIP indesejáveis.`,
        action: "Metodologia SMED (Troca Rápida de Ferramentas): Converta etapas de ajuste interno em tarefas externas realizadas com a máquina operando."
      });
    }

    // Default cause if everything else is clean
    if (causes.length === 0) {
      causes.push({
        title: "Gargalo Ocasional Flutuante",
        type: "CAPACITY",
        text: "Embora o desempenho atual esteja equilibrado, as flutuações randômicas diárias no lead time e no volume de vendas podem criar gargalos temporários que viajam de uma etapa a outra.",
        action: "Criação de buffers Kanban limitados para manter o ritmo operacional sem flutuações significativas."
      });
    }

    return causes;
  };

  const activeCauses = selectedStep ? detectRootCauses(selectedStep) : [];

  return (
    <div className="space-y-8 animate-fade-in" id="bottleneck-detector-viewport">
      
      {/* Intro Header */}
      <div className="border-t border-[#1A1A1A] pt-4">
        <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest mb-1">Algoritmo LSS de Inteligência</p>
        <h2 className="text-3xl font-serif tracking-tight text-[#1A1A1A]">Diagnósticos de Gargalos Baseados em Machine Learning</h2>
        <p className="text-xs text-[#1A1A1A]/70 leading-relaxed mt-1">
          Nossos modelos estatísticos correlacionam a taxa de chegada de trabalho com limites locais de capacidade e desvios de processo. Veja abaixo a lista priorizada de etapas restritivas na cadeia operacional.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Ranked List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#1A1A1A]/50">
              Fila Priorizada de Gargalos (Ordenado por Impacto)
            </h3>
            {selectedStepId && selectedStepId !== "ALL" && onClearFilter && (
              <button
                type="button"
                onClick={onClearFilter}
                className="text-[9.5px] uppercase font-bold text-red-600 hover:text-red-800 underline cursor-pointer"
              >
                Ver Todos
              </button>
            )}
          </div>

          <div className="space-y-3">
            {selectedStepId && selectedStepId !== "ALL" && (
              <div className="bg-[#FAF8F5] border-l-4 border-[#C49746] p-2 text-[10px] text-gray-700 font-sans">
                <span>Filtrado para a etapa selecionada no gráfico</span>
              </div>
            )}
            {rankedBottlenecks
              .map((step, idx) => ({ step, originalIndex: idx }))
              .filter(({ step }) => !selectedStepId || selectedStepId === "ALL" || step.id === selectedStepId)
              .map(({ step, originalIndex }) => {
                const isSelected = step.id === selectedStep.id;
                const isSaturated = step.utilization >= 100;
                const isWarning = step.utilization >= 80 && step.utilization < 100;

                // Color codes for priority level
                const scoreBadgeColor = originalIndex === 0 
                  ? "bg-red-100 text-red-800 border-red-200" 
                  : originalIndex === 1 
                  ? "bg-orange-100 text-orange-800 border-orange-200" 
                  : "bg-blue-50 text-blue-800 border-blue-100";

                return (
                  <button
                    key={step.id}
                    id={`btn-bottleneck-rank-${step.id}`}
                    onClick={() => setSelectedBottleneckId(step.id)}
                    className={`w-full text-left p-4 border transition-all ${
                      isSelected 
                        ? "border-[#C49746] bg-[#F5F2ED] shadow-xs" 
                        : "border-[#1A1A1A]/10 bg-white hover:border-[#1A1A1A]/40"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="max-w-[70%]">
                        <span className={`inline-block text-[8px] font-extrabold uppercase border px-1.5 py-0.5 rounded-sm mr-2 mb-1.5 ${scoreBadgeColor}`}>
                          PRIORIDADE #{originalIndex + 1}
                        </span>
                      <h4 className="font-serif font-bold text-sm text-[#1A1A1A] truncate">
                        {step.name}
                      </h4>
                      <p className="text-[9.5px] text-[#1A1A1A]/60 font-mono mt-1">
                        Responsável: <span className="font-sans text-gray-800 font-medium">{step.resource}</span>
                      </p>
                    </div>

                    <div className="text-right">
                      <div className={`font-mono text-sm font-bold ${isSaturated ? "text-red-700" : isWarning ? "text-[#C49746]" : "text-emerald-700"}`}>
                        {step.utilization.toFixed(0)}% Util.
                      </div>
                      <span className="text-[8px] uppercase tracking-widest font-bold text-gray-400">
                        Score: {step.priorityScore.toFixed(1)}
                      </span>
                    </div>
                  </div>

                  {/* Horizontal visual progress bars */}
                  <div className="w-full bg-[#1A1A1A]/10 h-1.5 rounded-none overflow-hidden mt-3 relative">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        isSaturated ? "bg-red-600" : isWarning ? "bg-[#C49746]" : "bg-emerald-600"
                      }`}
                      style={{ width: `${Math.min(100, step.utilization)}%` }}
                    ></div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right column: Deep-dive diagnostic explorer */}
        <div className="lg:col-span-7 bg-white border border-[#1A1A1A]/15 p-6 space-y-6">
          
          <div className="border-b border-gray-100 pb-4 flex flex-wrap justify-between items-start gap-4">
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#C49746]">Etapa Sob Análise</span>
              <h3 className="font-serif italic font-bold text-2xl text-[#1A1A1A]">
                {selectedStep.name}
              </h3>
              <p className="text-xs text-[#1A1A1A]/60 font-mono mt-1">
                Líder da Célula: <span className="underline font-sans text-gray-800 font-bold">{selectedStep.resource}</span>
              </p>
            </div>

            <button
              onClick={() => onInitiateDmaic(selectedStep)}
              className="bg-[#C49746] hover:bg-[#C49746]/90 text-white text-[10px] uppercase tracking-widest font-bold py-2.5 px-4 shadow-sm flex items-center gap-1 transition-all"
            >
              <Zap size={11} className="text-white fill-white" />
              Iniciar Projeto DMAIC Six Sigma
            </button>
          </div>

          {/* Quick Data Parameter Indicators Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#F5F2ED] p-4 text-center border border-[#1A1A1A]/5">
            <div>
              <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase">Ciclo Médio</div>
              <div className="text-lg font-serif italic text-gray-900 mt-0.5">{selectedStep.processingTime} min</div>
            </div>
            <div>
              <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase">Variabilidade (σ)</div>
              <div className="text-lg font-serif italic text-gray-900 mt-0.5">± {selectedStep.standardDeviation} min</div>
            </div>
            <div>
              <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase">Rendimento (Yield)</div>
              <div className="text-lg font-serif italic text-gray-900 mt-0.5">{(selectedStep.yieldRate * 100).toFixed(0)}%</div>
            </div>
            <div>
              <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase">Setup de Lote</div>
              <div className="text-lg font-serif italic text-gray-900 mt-0.5">{selectedStep.setupTime} min</div>
            </div>
          </div>

          {/* Root-cause Diagnostic Section */}
          <div className="space-y-4">
            <h4 className="text-[10px] uppercase tracking-widest font-bold text-gray-900 flex items-center gap-1">
              <Sparkles size={11} className="text-[#C49746]" />
              Fatores Causais de Atraso e Diagnósticos Estatísticos
            </h4>

            <p className="text-xs text-gray-600 leading-relaxed">
              O algoritmo analisou os padrões de variabilidade e o estresse de carga. Abaixo estão listadas as anomalias diagnosticadas inerentes a este posto:
            </p>

            <div className="space-y-4 divide-y divide-gray-100">
              {activeCauses.map((cause, cIdx) => (
                <div key={cIdx} className={`pt-4 ${cIdx === 0 ? "pt-0 border-t-0" : ""}`}>
                  <div className="flex items-start gap-2.5">
                    <span className="p-1.5 rounded-sm bg-[#C49746]/5 text-[#C49746] mt-0.5 shrink-0 border border-[#C49746]/10">
                      <AlertTriangle size={13} />
                    </span>
                    <div className="space-y-1.5">
                      <h5 className="font-bold text-xs text-gray-900 font-serif">
                        {cause.title}
                      </h5>
                      <p className="text-[11px] leading-relaxed text-gray-600">
                        {cause.text}
                      </p>
                      
                      {/* Lean Recommendation Block */}
                      <div className="bg-[#FEF7E0] border-l-2 border-[#F0B400] p-3 text-[10.5px] leading-relaxed text-gray-900">
                        <strong className="text-[8.5px] uppercase tracking-wider text-[#C49746] block mb-1">Contra-medida Lean Proposta:</strong>
                        {cause.action}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-100 pt-4 flex justify-between items-center text-[10px] text-gray-400 font-mono">
            <span>Diagnósticos Calculados Localmente</span>
            <span>Estudo Operacional v1.2</span>
          </div>

        </div>

      </div>

    </div>
  );
}
