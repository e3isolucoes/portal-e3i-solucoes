import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  BookOpen, 
  Compass, 
  HelpCircle, 
  Send, 
  X, 
  ChevronRight, 
  CheckCircle2, 
  AlertTriangle, 
  Activity, 
  TrendingUp, 
  ArrowRight,
  Info,
  Layers,
  BarChart2,
  FileCheck2,
  Cpu
} from "lucide-react";

interface Step {
  id: string;
  name: string;
  resource: string;
  resourceCount: number;
  processingTime: number;
  standardDeviation: number;
  yieldRate: number;
  setupTime: number;
}

interface AiMentorGuideProps {
  currentWorkspaceView: string;
  setCurrentWorkspaceView: (view: any) => void;
  activePhase: string;
  setActivePhase: (phase: any) => void;
  steps: Step[];
  arrivalRate: number;
  charter: any;
  sipoc: any;
  controlPlans: any[];
  activeAlarms?: any[];
}

interface ChatMessage {
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}

export default function AiMentorGuide({
  currentWorkspaceView,
  setCurrentWorkspaceView,
  activePhase,
  setActivePhase,
  steps = [],
  arrivalRate = 12,
  charter = {},
  sipoc = {},
  controlPlans = [],
  activeAlarms = []
}: AiMentorGuideProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"TOURS" | "MANUAL" | "AI_LOUNGE" | "GLOSSARY">("TOURS");
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  
  // AI Chat states
  const [chatInput, setChatInput] = useState("");
  const [chatLog, setChatLog] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom in chat
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatLog, isTyping]);

  // Initial welcome message
  useEffect(() => {
    if (chatLog.length === 0) {
      setChatLog([
        {
          sender: "ai",
          text: `Olá! Eu sou sua **Mentora de Excelência Operacional IA**. 🎓

Estou pronta para guiar você pela metodologia Lean Six Sigma e Pesquisa Operacional aplicados ao seu processo. 

Você pode navegar pelos **Guias Interativos Passo a Passo** na primeira aba para que eu leve você diretamente ao ponto exato da aplicação, ou explorar o **Manual de Referência LSS** na segunda aba. Se tiver alguma dúvida específica sobre gargalos, variabilidade, limites UCL/LCL Shewhart, ou o novo gráfico de Pareto de Causa-Raiz, é só perguntar aqui abaixo!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, []);

  // Handler for navigation through guided tour
  const handleNavigateTour = (view: any, phase?: any) => {
    setCurrentWorkspaceView(view);
    if (phase) {
      setActivePhase(phase);
    }
    
    // Add visual flash effect to focus attention
    const blockId = phase ? `${phase.toLowerCase()}-phase-viewport` : `${view.toLowerCase()}-workspace-viewport`;
    setTimeout(() => {
      const el = document.getElementById(blockId) || document.getElementById("control-alerts-panel");
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add("ring-4", "ring-amber-500/55", "transition-all", "duration-500");
        setTimeout(() => {
          el.classList.remove("ring-4", "ring-amber-500/55");
        }, 3000);
      }
    }, 400);
  };

  // Extract process stats for personalized consulting context
  const bottleneckStep = steps.find(s => {
    const serviceRate = (s.resourceCount * 60) / s.processingTime; // u/h
    return serviceRate < arrivalRate;
  });
  
  const rolledYield = steps.reduce((acc, curr) => acc * curr.yieldRate, 1) * 100;

  // Predefined queries handlers
  const handlePresetQuestion = (question: string, answerText: string) => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setChatLog(prev => [...prev, { sender: "user", text: question, timestamp }]);
    setIsTyping(true);

    setTimeout(() => {
      setChatLog(prev => [...prev, {
        sender: "ai",
        text: answerText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setIsTyping(false);
    }, 1200);
  };

  // Submits a custom prompt to the LSS IA Model
  const handleSendCustomMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setChatInput("");
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setChatLog(prev => [...prev, { sender: "user", text: userMsg, timestamp }]);
    setIsTyping(true);

    // Context analysis for dynamic AI response
    let aiResponse = "";
    const lower = userMsg.toLowerCase();

    // Custom generative rules reflecting real live state
    if (lower.includes("gargalo") || lower.includes("capacidade") || lower.includes("teoria das restrições")) {
      if (bottleneckStep) {
        aiResponse = `Ao inspecionar o seu fluxo atual, identifiquei que a etapa **"${bottleneckStep.name}"** atuando sob o recurso **${bottleneckStep.resource}** é um **gargalo saturo real**. 
        
A capacidade máxima de atendimento desta etapa é de **${((bottleneckStep.resourceCount * 60) / bottleneckStep.processingTime).toFixed(1)} u/h**, o que é inferior à sua taxa de chegada de demanda de **${arrivalRate} u/h** (Utilização de **${((arrivalRate / ((bottleneckStep.resourceCount * 60) / bottleneckStep.processingTime)) * 100).toFixed(1)}%**).

**Sua Ação Lean Recomendada:** 
1. Realoque operadores temporários para ampliar a capacidade.
2. Elimine tempos de setup aplicando a metodologia SMED (Single-Minute Exchange of Die).
3. Monitore o inventário em trânsito no **WIP Kanban Board (Kanban de Trabalho)** para evitar sobrecarga.`;
      } else {
        aiResponse = `O seu processo atualmente apresenta **estabilidade estocástica quanto ao limite de capacidade**. Nenhuma etapa isolada está saturando a taxa de demanda nominal de **${arrivalRate} u/h**. 
        
Mesmo assim, procure balancear a linha. A etapa com menor capacidade de entrega é **"${steps.reduce((min, s) => ((s.resourceCount * 60) / s.processingTime) < ((min.resourceCount * 60) / min.processingTime) ? s : min, steps[0])?.name}"**. Mantenha o monitoramento para evitar desvios durante picos de demanda estocástica.`;
      }
    } else if (lower.includes("pareto") || lower.includes("causa") || lower.includes("desvio") || lower.includes("recorrente")) {
      aiResponse = `O **Gráfico de Pareto de Causas-Raiz** (localizado no final da fase de **CONTROLE (SPC)**) foi calibrado para mostrar as 5 falhas mais dominantes observadas no limite crítico de processo para seu projeto.
      
A regra Lean preconiza que **80% das falhas são produzidas por apenas 20% das causas** (as causas vitais). 

Atualmente, se você concentrar ações corretivas imediatas na causa **"${steps.length > 0 ? 'Matéria-Prima com Desvio' : 'Sensor Desregulador'}"**, você removerá a maior parcela das ocorrências do sistema. 

**Como monitorar:** Vá para a aba **Controlar** no DMAIC, verifique se a carta de Shewhart indica pontos vermelhos fora dos limites normais, e siga o Plano de Reação parametrizado para estas causas vitais!`;
    } else if (lower.includes("cep") || lower.includes("shewhart") || lower.includes("ucl") || lower.includes("lcl") || lower.includes("controle") || lower.includes("limite")) {
      aiResponse = `As **Cartas de Controle de Shewhart (CEP)** utilizam os Limites Superior e Inferior de Controle (**UCL** e **LCL**) calculados a ±3 desvios padrão (Sigma) a partir da média móvel histórica.

No seu painel:
- **Pontos Verdes**: Processo estável operando dentro da variabilidade aleatória normal.
- **Pontos Amarelos (Alerta 2-Sigma)**: Desvio indicando aproximação crítica da zona de risco. Inspecione.
- **Pontos Vermelhos com Alarme Ativo**: Violação matemática ultrapassando os limites. Isto é uma causa especial que necessita de execução imediata do **Plano de Reação** estabelecido pelo gestor para conter a anomalia.`;
    } else if (lower.includes("qualidade") || lower.includes("yield") || lower.includes("sigma") || lower.includes("dpmo")) {
      aiResponse = `O seu processo possui um rendimento de primeira entrega total (Rolled First Pass Yield) de **${rolledYield.toFixed(2)}%**. Isso significa que a cada 100 peças que entram no sistema, cerca de **${rolledYield.toFixed(0)}** saem aprovadas sem necessitar de nenhum retrabalho.

Para elevar o seu nível Sigma do projeto (atualmente estimado com base no DPMO combinado):
1. Foque na melhoria de qualidade de passagens na etapa com menor taxa individual de Yield.
2. Implemente dispositivos **Poka-Yoke** (mecanismo à prova de erros) para zerar desvios operacionais.`;
    } else {
      // General contextual response
      aiResponse = `Perfeita colocação sobre a melhoria de processos, com foco em ${userMsg}. 

Considerando o Project Charter **"${charter.title || "Otimização de Linha"}"** que estabelece como alvo uma meta de **"${charter.targetValue || "estabilização"}"**, as melhores práticas indicam:

1. **Mapeamento Prévio (SIPOC) na Fase DEFINE**: Garante limite de fronteira.
2. **Coleta Rígida na Fase MEASURE**: Medição de lead times e perdas para estabelecer o baseline.
3. **Poka-Yoke e Controle Estatístico de Processo na Fase CONTROL**: Garanta que as melhorias implementadas persistam no tempo através do monitoramento SPC.

Deseja que eu te mostre como e onde realizar alguma dessas etapas no sistema agora mesmo? É só clicar em algum dos passos do roteiro!`;
    }

    setTimeout(() => {
      setChatLog(prev => [...prev, {
        sender: "ai",
        text: aiResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setIsTyping(false);
    }, 1200);
  };

  // Defined interactive guidebook steps
  const tours = [
    {
      id: "diag",
      title: "1. Setup & Diagnóstico LSS",
      icon: <Layers className="w-4 h-4 text-emerald-600 animate-pulse" />,
      desc: "Avalie o nível de maturidade e configure o segmento operacional da sua empresa (Serviços, Varejo, Industrial, etc).",
      why: "Determina as premissas e o framework conceitual de fórmulas que o simulador estocástico aplicará ao seu cenário.",
      view: "DIAGNOSTIC",
      phase: null,
      label: "Ir para Diagnóstico ✔"
    },
    {
      id: "charter",
      title: "2. Definição do Escopo (SIPOC)",
      icon: <FileCheck2 className="w-4 h-4 text-[#C49746]" />,
      desc: "Defina o Project Charter (Sponsors, metas e alvo do indicador Y) e preencha o SIPOC.",
      why: "Garante o controle de fronteira de projeto e previne o avanço desmensurado do escopo (Scope Creep).",
      view: "DMAIC",
      phase: "DEFINE",
      label: "Ir para SIPOC e Charter 🧭"
    },
    {
      id: "vsm",
      title: "3. Layout Estocástico (Fluxograma)",
      icon: <Activity className="w-4 h-4 text-blue-600" />,
      desc: "Mapeie visualmente os postos de trabalho e configure tempos de ciclo, desvios e recursos para simulação estatística.",
      why: "Torna as perdas físicas, esperas e gargalos visíveis a todos os envolvidos do projeto Lean.",
      view: "MAP",
      phase: null,
      label: "Ir para o Mapeador de Layout 🗺"
    },
    {
      id: "dpmo",
      title: "4. Análise de Métricas & Sigma (Measure)",
      icon: <TrendingUp className="w-4 h-4 text-indigo-600" />,
      desc: "Inspecione tempos médios de espera em filas e o cálculo automático do nível Sigma e DPMO do processo.",
      why: "Estipula o baseline quantitativo de partida para provar estatisticamente a eficácia futura das melhorias.",
      view: "DMAIC",
      phase: "MEASURE",
      label: "Visualizar Métricas & DPMO 📊"
    },
    {
      id: "bottlenecks",
      title: "5. Gargalos & Teoria das Filas (Analyze)",
      icon: <Cpu className="w-4 h-4 text-purple-600" />,
      desc: "Identifique qual etapa satura e trava o processo através de análises matemáticas estocásticas de utilização.",
      why: "Pela Teoria das Restrições, uma hora perdida no gargalo é uma hora perdida em todo o sistema produtivo.",
      view: "DMAIC",
      phase: "ANALYZE",
      label: "Inspecionar Gargalos ⚠️"
    },
    {
      id: "wip",
      title: "6. Kanban de Resolução e WIP (Improve)",
      icon: <Compass className="w-4 h-4 text-amber-600" />,
      desc: "Gerencie cartões Kanban resolvendo impedimentos operacionais, limitando o WIP (Work in Progress).",
      why: "Controlar o WIP reduz drasticamente o Lead Time operacional baseado na Lei de Little (WIP = Throughput x Lead Time).",
      view: "KANBAN",
      phase: null,
      label: "Visualizar Kanban de WIP 🗃"
    },
    {
      id: "spc",
      title: "7. Cartas de Controle CEP & Pareto (Control)",
      icon: <BarChart2 className="w-4 h-4 text-red-600" />,
      desc: "Monitore cartas de Shewhart UCL/LCL de desvio de qualidade e analise os principais culpados utilizando o diagrama de Pareto das 5 causas.",
      why: "Evita que as melhorias implementadas retrocedam no tempo, garantindo estabilidade estatística a longo prazo.",
      view: "DMAIC",
      phase: "CONTROL",
      label: "Monitorar CEP & Gráfico de Pareto 📉"
    },
    {
      id: "ppt",
      title: "8. Dossiê de Apresentação Final (Report)",
      icon: <Sparkles className="w-4 h-4 text-indigo-700" />,
      desc: "Gere slides dinâmicos de resultados DMAIC para apresentar ao Board Executivo e Sponsors de Projeto.",
      why: "A comunicação executiva de savings, ganho de Sigma e melhorias Lean sela a aprovação formal do encerramento do ciclo.",
      view: "REPORT",
      phase: null,
      label: "Acessar Central de Relatórios 📁"
    }
  ];

  // LEAN SIX SIGMA DOCUMENTATION TEXTS FOR TAB "MANUAL"
  const handbookArticles = [
    {
      id: "art_dmaic",
      title: "O Ciclo LSS DMAIC",
      summary: "Estrutura fundamental de solução de problemas complexos de variabilidade.",
      content: `O método **DMAIC** é a espinha dorsal de melhoria contínua do Six Sigma. Divide-se em 5 macro-etapas rígidas:

1. **D (Define - Definir)**: Busca delimitar o escopo e problema em questão. Usa-se o **Project Charter** para formalizar patrocinadores (Sponsors), limites e métricas primárias e o **SIPOC** para o fluxo macro de valor.
2. **M (Measure - Medir)**: Cria o plano de coleta e mede o estado atual para gerar um baseline. É onde computamos o **DPMO** (Defeitos por Milhão de Oportunidades) e o **Nível Sigma** correspondente.
3. **A (Analyze - Analisar)**: Identifica causas-raiz da variabilidade e os gargalos de recursos. Utiliza conceitos de **Pesquisa Operacional** (Teoria das Filas) e **Estatística Descritiva**.
4. **I (Improve - Melhorar)**: Desenvolve, testa e implementa soluções para mitigar perdas. Utiliza-se **SMED** para tempos de setup, **Poka-Yoke** contra falhas humanas e **Kanban/Lei de Little** para equilibrar estoques em trânsito (WIP).
5. **C (Control - Controlar)**: Mantém os ganhos ocorridos por meio de padronizações e **Controle Estatístico de Processos (CEP)** com cartas Shewhart.`
    },
    {
      id: "art_spc",
      title: "Controle Estatístico de Processo (CEP)",
      summary: "Identificação imediata de causas comuns vs. causas especiais de desvio.",
      content: `O **CEP (ou SPC)** é a aplicação prática da estatística descritiva no controle diário de variáveis críticas (Y's). 

Ele utiliza as **Cartas de Controle de Shewhart** com base na distribuição normal:
- **Limite Superior de Controle (UCL)**: Estabelecido a +3 Desvios Padrão (Sigma) acima da Média de Processo.
- **Limite Inferior de Controle (LCL)**: Estabelecido a -3 Desvios Padrão (Sigma) abaixo da Média do Processo.
- **Linha Central (Média/Target)**: O estado meta ou representação histórica nominal de centralização.

**Regras de Alarme (Sinal de Violação):**
- Quando 1 ponto ultrapassa o UCL ou LCL, considera-se uma **causa especial instável**, exigindo investigação imediata via Plano de Reação.
- Padrões atípicos (como 9 pontos seguidos do mesmo lado da média ou saltos frequentes na zona de alerta 2-Sigma) sinalizam perda iminente de capabilidade.`
    },
    {
      id: "art_pareto",
      title: "A Regra de Pareto (80/20)",
      summary: "Maximize o retorno direcionando ações corretivas nos poucos problemas vitais.",
      content: `O Princípio de Pareto afirma que, para muitos eventos, aproximadamente **80% dos efeitos provêm de 20% das causas**.

Em projetos Lean Six Sigma, aplicar este princípio é crucial para otimizar o tempo e os recursos da equipe de engenharia:
- **Causas Vitais**: Os 20% de incidentes operacionais que provocam a esmagadora maioria dos desvios na linha. Geralmente envolvem insumos de fornecedores desregulados, erros no setup da máquina ou sensores desalinhados.
- **Causas Triviais**: Os outros 80% de pequenas ocorrências isoladas que, mesmo se resolvidas, reduzem muito pouco o indicador de perdas gerais.

**Como ler o Gráfico de Pareto no Sistema:**
- As barras amarelas representam a frequência bruta de incidentes de cada causa de forma decrescente (eixo esquerdo).
- A linha vermelha representa o percentual acumulado linear do desvio (eixo direito).
- Foque prioritariamente em mitigar as duas primeiras causas vitais até que a linha vermelha cruze a marca de **80%**!`
    },
    {
      id: "art_queues",
      title: "Teoria das Filas & Little na Prática",
      summary: "Diferença conceitual entre taxa de serviço e taxa de chegada de demanda.",
      content: `A **Pesquisa Operacional (PO)** analisa matematicamente o equilíbrio estocástico da sua fábrica ou serviço.

**1. Saturação por Capacidade Insuficiente:**
Sempre que a Taxa de Chegada de Demanda (Lambda) ultrapassa a Taxa de Serviço de uma etapa (fórmula: Recursos x 60 / Tempo de Ciclo), a taxa de utilização desta etapa supera 100%. Uma fila física crescerá indefinidamente gerando atraso crítico no Lead Time. Essa etapa é o **Gargalo Principal**.

**2. A Lei de Little:**
Estipula a seguinte correspondência direta:
$$WIP = Vazão (Throughput) \\times Lead Time$$

Se você deseja acelerar a entrega do seu projeto e encurtar o Lead Time percebido pelo cliente, você tem uma forma matemática garantida: **limite o WIP (trabalho em andamento)** através de sinalizações de Kanban na linha.`
    }
  ];

  return (
    <>
      {/* FLOATING ACCESS BADGE - MOVED TO BOTTOM-LEFT TO PREVENT OVERLAP WITH CO-PILOTO LSS */}
      <div className="fixed bottom-6 left-6 z-40">
        <button
          id="btn-ai-mentor-trigger"
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-[#1A1A1A] to-indigo-950 hover:from-slate-900 hover:to-indigo-900 text-white rounded-full px-4 py-3 shadow-[4px_4px_0px_0px_rgba(245,158,11,1)] flex items-center gap-2 border-2 border-slate-950 text-xs font-bold font-sans hover:scale-105 transition-all duration-300 animate-bounce active:scale-95 cursor-pointer"
          style={{ animationDuration: '3.5s' }}
        >
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>PORTAL DE IA: MENTORIA &amp; GUIA</span>
          {activeAlarms.length > 0 && (
            <span className="bg-red-500 text-white w-2 h-2 rounded-full absolute -top-0.5 -right-0.5 animate-ping"></span>
          )}
        </button>
      </div>

      {/* SIDEBAR OVERLAY BACKGROUND */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-slate-900/60 z-40 backdrop-blur-2xs"
            />

            {/* SIDE PANEL WRAPPER */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-[440px] bg-[#FAF9F6] border-l-[6px] border-[#1A1A1A] z-50 flex flex-col shadow-2xl overflow-hidden text-left"
              id="ai-mentor-sidebar-drawer"
            >
              {/* TOP BRAND HEADER */}
              <div className="bg-[#1A1A1A] text-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="bg-amber-600 p-1.5 rounded-full">
                    <Sparkles className="w-5 h-5 text-white animate-pulse" />
                  </div>
                  <div>
                    <h3 className="font-serif text-[15px] font-bold tracking-tight text-white">Central de IA Lean Six Sigma</h3>
                    <span className="text-[9px] uppercase font-mono tracking-widest text-amber-400 block font-bold">Guia de Certificado Lean</span>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* TAB BAR SELECTORS */}
              <div className="bg-[#FAF9F6] border-b border-[#1A1A1A]/10 flex items-center font-mono text-[9px] uppercase font-black tracking-wider text-slate-600">
                <button
                  onClick={() => { setActiveTab("TOURS"); setSelectedTopic(null); }}
                  className={`flex-1 py-3 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    activeTab === "TOURS" 
                      ? "border-[#C49746] text-[#C49746] bg-white font-black" 
                      : "border-transparent hover:text-slate-900"
                  }`}
                >
                  <Compass className="w-3 h-3" />
                  Roteiro Prático
                </button>
                <button
                  onClick={() => { setActiveTab("MANUAL"); setSelectedTopic(null); }}
                  className={`flex-1 py-3 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    activeTab === "MANUAL" 
                      ? "border-[#C49746] text-[#C49746] bg-white font-black" 
                      : "border-transparent hover:text-slate-900"
                  }`}
                >
                  <BookOpen className="w-3 h-3" />
                  Manual LSS
                </button>
                <button
                  onClick={() => { setActiveTab("AI_LOUNGE"); setSelectedTopic(null); }}
                  className={`flex-1 py-3 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    activeTab === "AI_LOUNGE" 
                      ? "border-[#C49746] text-[#C49746] bg-white font-black" 
                      : "border-transparent hover:text-slate-900"
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  Mentora IA
                </button>
                <button
                  onClick={() => { setActiveTab("GLOSSARY"); setSelectedTopic(null); }}
                  className={`flex-1 py-3 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    activeTab === "GLOSSARY" 
                      ? "border-[#C49746] text-[#C49746] bg-white font-black" 
                      : "border-transparent hover:text-slate-900"
                  }`}
                  title="Traduzir termos complexos LSS para leigos"
                >
                  <HelpCircle className="w-3 h-3 text-[#C49746]" />
                  Dúvidas Leigo
                </button>
              </div>

              {/* SCROLLABLE INTERACTIVE BODY AREA */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">

                {/* 1. GUIDED TOURS TAB */}
                {activeTab === "TOURS" && (
                  <div className="space-y-3.5">
                    <div className="bg-amber-50/75 border border-[#C49746]/15 p-3 rounded-sm space-y-1">
                      <h4 className="text-[11px] font-bold text-[#78350F] uppercase flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-[#C49746] shrink-0" />
                        Guia de Navegação Operacional
                      </h4>
                      <p className="text-[10.5px] leading-relaxed text-slate-700">
                        Clique em qualquer um dos marcos regulatórios abaixo para que eu mude a tela da sua aplicação de forma automática e explique exatamente **o que fazer** e o **porquê fazer** do ponto de vista do ciclo DMAIC.
                      </p>
                    </div>

                    <div className="space-y-3 pt-1">
                      {tours.map((t, idx) => {
                        const isCurrentlyOnThis = currentWorkspaceView === t.view && (!t.phase || activePhase === t.phase);
                        return (
                          <div 
                            key={t.id} 
                            className={`border rounded-sm p-3.5 transition-all text-xs space-y-2.5 relative ${
                              isCurrentlyOnThis 
                                ? "bg-white border-[#C49746] shadow-md border-l-4 border-l-[#C49746]" 
                                : "bg-white/60 hover:bg-white border-slate-200/80 hover:border-slate-300"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <span className={`p-1 bg-slate-100 rounded-sm ${isCurrentlyOnThis ? 'bg-amber-100 text-amber-900 border border-amber-200' : ''}`}>
                                  {t.icon}
                                </span>
                                <h5 className="font-serif text-[12px] font-black text-slate-900">{t.title}</h5>
                              </div>
                              {isCurrentlyOnThis && (
                                <span className="bg-[#C49746]/10 text-[#C49746] text-[8px] font-mono tracking-wider font-extrabold px-1.5 py-0.5 rounded-sm">
                                  VOCÊ ESTÁ AQUI
                                </span>
                              )}
                            </div>

                            <p className="text-[11px] text-slate-650 leading-relaxed font-sans">{t.desc}</p>
                            
                            <div className="bg-[#FAF9F6] p-2 border-l-2 border-indigo-400 text-[10px] text-slate-600 font-sans leading-relaxed">
                              <strong>Por que fazer isso:</strong> {t.why}
                            </div>

                            <button
                              onClick={() => {
                                handleNavigateTour(t.view, t.phase);
                                // Set feedback to user that it is opening and scroll
                              }}
                              className={`w-full py-1.5 px-3 text-[10px] font-mono font-bold uppercase tracking-wider rounded-sm flex items-center justify-center gap-1 transition-all ${
                                isCurrentlyOnThis 
                                  ? "bg-[#1A1A1A] text-white hover:bg-[#333333]" 
                                  : "bg-amber-600/10 hover:bg-amber-600 text-amber-800 hover:text-white border border-amber-600/20"
                              }`}
                            >
                              <span>{t.label}</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 2. LEAN SIX SIGMA MANUAL TAB */}
                {activeTab === "MANUAL" && (
                  <div className="space-y-4">
                    {!selectedTopic ? (
                      <>
                        <div className="bg-slate-100/80 p-3 rounded-sm border border-slate-200 text-xs">
                          <p className="text-slate-600 leading-relaxed">
                            Selecione um tópico do nosso **Manual de Referência Técnica Lean Six Sigma** para uma explicação detalhada com equações matemáticas e orientações de contenção recomendadas:
                          </p>
                        </div>
                        
                        <div className="space-y-2.5">
                          {handbookArticles.map((art) => (
                            <button
                              key={art.id}
                              onClick={() => setSelectedTopic(art.id)}
                              className="w-full text-left bg-white border border-slate-200 hover:border-slate-300 p-3 rounded-sm space-y-1 block transition-all shadow-2xs hover:shadow-xs group"
                            >
                              <div className="flex items-center justify-between">
                                <h5 className="font-serif text-[12px] font-bold text-slate-900 group-hover:text-amber-800">{art.title}</h5>
                                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 transition" />
                              </div>
                              <p className="text-[10.5px] text-slate-500 leading-normal line-clamp-1">{art.summary}</p>
                            </button>
                          ))}
                        </div>
                      </>
                    ) : (
                      <div className="space-y-3 bg-white border border-slate-150 p-4 rounded-sm">
                        <button
                          onClick={() => setSelectedTopic(null)}
                          className="text-[9px] uppercase font-mono font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 mb-2"
                        >
                          ← Voltar para a lista do manual
                        </button>
                        
                        {(() => {
                          const art = handbookArticles.find(a => a.id === selectedTopic);
                          if (!art) return null;
                          return (
                            <div className="space-y-3">
                              <h4 className="font-serif text-[15px] font-black text-slate-900 border-b pb-1.5 border-slate-200">{art.title}</h4>
                              <p className="text-[10.5px] font-mono text-[#C49746] mt-0.5 font-bold italic">Resumo: {art.summary}</p>
                              
                              <div className="text-[11.5px] text-slate-700 leading-relaxed font-sans whitespace-pre-wrap pt-2 space-y-2">
                                {art.content}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    )}
                  </div>
                )}

                {/* 3. AI CHAT LOUNGE TAB */}
                {activeTab === "AI_LOUNGE" && (
                  <div className="flex flex-col h-[520px] bg-white border border-slate-200 rounded-sm">
                    {/* Active Warnings Widget inside Lounge */}
                    {activeAlarms.length > 0 && (
                      <div className="bg-red-50 p-2.5 border-b border-red-100 flex items-center justify-between text-[10px] shrink-0">
                        <div className="flex items-center gap-1.5 font-sans">
                          <AlertTriangle className="w-3.5 h-3.5 text-red-650 shrink-0" />
                          <span className="text-red-900 font-bold">Identifiquei {activeAlarms.length} desvios sob CEP!</span>
                        </div>
                        <button 
                          onClick={() => handleNavigateTour("DMAIC", "CONTROL")}
                          className="bg-red-600 text-white font-mono uppercase font-black text-[8px] px-2 py-0.5 rounded-sm hover:bg-red-700 transition"
                        >
                          Tratar falhas ⚠️
                        </button>
                      </div>
                    )}

                    {/* Chat Log History */}
                    <div 
                      ref={scrollRef}
                      className="flex-grow overflow-y-auto p-3 space-y-3 bg-[#FAF9F6]/30 text-xs"
                    >
                      {chatLog.map((msg, idx) => (
                        <div 
                          key={idx} 
                          className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div 
                            className={`p-3 rounded-sm leading-relaxed max-w-[85%] whitespace-pre-wrap ${
                              msg.sender === "user" 
                                ? "bg-indigo-950 text-white font-sans rounded-br-none" 
                                : "bg-white border border-slate-150 text-slate-800 font-sans rounded-bl-none shadow-2xs"
                            }`}
                          >
                            {msg.text}
                            <span className={`block text-[8px] mt-1 text-right min-w-[30px] font-mono ${msg.sender === "user" ? "text-slate-300" : "text-slate-400"}`}>
                              {msg.timestamp}
                            </span>
                          </div>
                        </div>
                      ))}

                      {/* Typing indicator */}
                      {isTyping && (
                        <div className="flex justify-start">
                          <div className="bg-white border border-slate-150 p-3 rounded-sm text-[10px] text-slate-500 font-mono flex items-center gap-2">
                            <span className="relative flex h-1.5 w-1.5">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-amber-500"></span>
                            </span>
                            Mentora IA está interpretando processo...
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Quick Smart Inquiries */}
                    <div className="p-2 border-t border-slate-200/50 bg-[#FAF9F6]/50 space-y-1.5 shrink-0">
                      <span className="text-[8px] uppercase tracking-wider text-slate-500 font-extrabold font-mono block pl-1">Consulte rápida orientação de IA:</span>
                      <div className="flex overflow-x-auto gap-1 pb-1 pr-1 scrollbar-thin">
                        <button
                          onClick={() => handlePresetQuestion(
                            "O que o novo mapa de Pareto nos indica sobre os desvios?",
                            `O **Diagrama de Pareto de Causas-Raiz** organiza falhas críticas por frequência decrescente combinando com a linha acumulada.
                            
Ele mostra que combater as 2 primeiras causas irá cessar a robusta maioria de todos os alarmes que disparam hoje sob as cartas de Shewhart. Isto maximiza o retorno financeiro (ROI) de engenharia de forma rápida!`
                          )}
                          className="bg-white border border-slate-200/80 hover:border-[#C49746] text-slate-700 hover:text-[#C49746] text-[9.5px] px-2.5 py-1 whitespace-nowrap rounded-sm transition font-sans shrink-0 hover:shadow-2xs"
                        >
                          Como ler o gráfico de Pareto? 📊
                        </button>

                        <button
                          onClick={() => handlePresetQuestion(
                            "Como tirar a minha operação do gargalo?",
                            `Para zerar gargalos sob uso de Pesquisa Operacional:
1. Revise se o setup da máquina pode ser atenuado (SMED).
2. Tente balancear a distribuição de operadores remanejando equipes de outras etapas.
3. Diminua a variabilidade estocástica no tempo de ciclo para mitigar os picos de fila.`
                          )}
                          className="bg-white border border-slate-200/80 hover:border-[#C49746] text-slate-700 hover:text-[#C49746] text-[9.5px] px-2.5 py-1 whitespace-nowrap rounded-sm transition font-sans shrink-0 hover:shadow-2xs"
                        >
                          Como tirar gargalos? ⚠️
                        </button>

                        <button
                          onClick={() => handlePresetQuestion(
                            "Qual a importância do Lean Six Sigma no projeto?",
                            `O Lean foca em eliminar mude (desperdícios) de tempo, material e estoque em trânsito (WIP). O Six Sigma foca em diminuir a variabilidade geral (estabilidade estocástica).
                            
Combinados, eles tornam o Project Charter estável, elevando e salvaguardando a rentabilidade corporativa.`
                          )}
                          className="bg-white border border-slate-200/80 hover:border-[#C49746] text-slate-700 hover:text-[#C49746] text-[9.5px] px-2.5 py-1 whitespace-nowrap rounded-sm transition font-sans shrink-0 hover:shadow-2xs"
                        >
                          Para que serve o LSS? 🎓
                        </button>
                      </div>
                    </div>

                    {/* Chat Form Input */}
                    <form 
                      onSubmit={handleSendCustomMessage}
                      className="border-t border-slate-200 p-2 flex items-center gap-1.5 shrink-0 bg-white"
                    >
                      <input
                        type="text"
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Pergunte ao mentor de IA do Six Sigma..."
                        className="flex-grow px-3 py-1.5 border border-slate-200 rounded-sm text-xs focus:ring-1 focus:ring-amber-500 focus:border-amber-500 outline-none placeholder-slate-400"
                        disabled={isTyping}
                      />
                      <button
                        type="submit"
                        disabled={isTyping || !chatInput.trim()}
                        className="bg-[#1A1A1A] hover:bg-[#333333] text-white p-2 rounded-sm shrink-0 transition disabled:opacity-50"
                        title="Enviar dúvida"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  </div>
                )}

                {activeTab === "GLOSSARY" && (
                  <div className="space-y-4 animate-fade-in font-sans">
                    <div className="bg-amber-50/70 border border-[#C49746]/15 p-3 rounded-sm">
                      <h4 className="text-xs font-bold text-amber-900 uppercase flex items-center gap-1.5 mb-1">
                        🌱 Tradutor Lean Six Sigma (Para Iniciantes)
                      </h4>
                      <p className="text-[10.5px] leading-relaxed text-slate-700">
                        Não domina a matemática pesada ou as siglas em inglês? Sem problemas! Aqui está a tradução simples daquilo que você precisa resolver no seu negócio:
                      </p>
                    </div>

                    <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                      {[
                        {
                          term: "Gargalo (Bottleneck)",
                          desc: "A etapa mais lenta de todo o seu processo. Ela dita a velocidade máxima que a sua empresa consegue entregar valor. Se você colocar mais computadores, robôs ou pessoas em outra fase, as tarefas apenas vão se acumular em uma fila maior antes do gargalo. Foco total em aliviar o gargalo!",
                          tip: "🌟 Para resolver: adicione equipe lá ou reduza o tempo de setup."
                        },
                        {
                          term: "Desvio Padrão (Nível de Instabilidade σ)",
                          desc: "É a variação do tempo de entrega. Se você atende clientes em média em 10 minutos, mas hoje alguns esperaram 2 minutos e outros esperaram 60 minutos, sua instabilidade é alta. Compras e entregas amam previsibilidade e consistência!",
                          tip: "🌟 Para resolver: padronize as atividades e use mecanismos anti-erro (Poka-Yoke)."
                        },
                        {
                          term: "DMAIC (O Roteiro da Qualidade)",
                          desc: "Um roteiro científico em 5 passos para melhorar qualquer setor: D (Definir o escopo), M (Medir o estado atual), A (Analisar onde estão as perdas), I (Implementar melhorias) e C (Controlar estatisticamente para que o problema não retorne).",
                          tip: "🌟 Para resolver: siga nossa barra superior etapa por etapa."
                        },
                        {
                          term: "SIPOC (Mapa Aéreo de Fronteira)",
                          desc: "Mostra: Fornecedores (Suppliers), Entradas (Inputs), Processo Principal (Process), Entregas (Outputs) e Clientes (Customers). É um resumo de 1 página para colocar todos em sintonia sem ler manuais gigantescos.",
                          tip: "🌟 No menu: Vá em dmaic -> DEFINIR para montar o seu."
                        },
                        {
                          term: "FMEA & FTA (Gestão de Riscos)",
                          desc: "FMEA avalia os modos de falha (o que pode quebrar/falhar, gravidade e detecção). FTA constrói a árvore de erros lógico-matemática. Úteis para desenhar planos de contenção prévios antes de ir a público.",
                          tip: "🌟 No menu: Acesse o hub de Pesquisa Operacional para simular falhas."
                        },
                        {
                          term: "Gráfico de Pareto (Regra 80/20)",
                          desc: "Mostra quais causas concentram a maioria esmagadora de todas as suas dores. Corrigindo as 2 primeiras colunas do gráfico, você elimina até 80% das falhas gerais de todo o negócio economizando dinheiro e tempo.",
                          tip: "🌟 No menu: Consulte este gráfico no rodapé da aba CONTROLAR."
                        },
                        {
                          term: "Carta de Controle (CEP / Shewhart)",
                          desc: "Gráfico de acompanhamento diário com limites matemáticos superior (UCL) e inferior (LCL). Se a linha sair dessas margens (pontinho vermelho), é sinal inequívoco de que algo incomum aconteceu na operação e requer ação rápida.",
                          tip: "🌟 No menu: Configure e-mails de alerta imediatos no menu de controle."
                        }
                      ].map((item, idx) => (
                        <div key={idx} className="bg-white border text-left border-slate-200/80 p-3 shadow-3xs hover:border-[#C49746] transition-all rounded-xs">
                          <strong className="text-xs text-slate-900 block font-mono border-b border-dashed border-slate-100 pb-1 flex items-center justify-between">
                            <span>{idx + 1}. {item.term}</span>
                            <span className="text-[9px] text-[#C49746] font-bold">🌿 Simplificado</span>
                          </strong>
                          <p className="text-[11px] text-slate-600 leading-relaxed mt-1.5">{item.desc}</p>
                          <span className="block text-[10px] mt-2 text-indigo-950 font-bold bg-[#F4F4F9]/60 px-2 py-0.5 rounded-sm">{item.tip}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-[#FAF9F5] p-3 border border-slate-200 rounded-sm space-y-1">
                      <strong className="text-[10px] uppercase font-mono text-[#C49746] block tracking-wide">💡 Dica de Ouro de Sobrevivência</strong>
                      <p className="text-[10.5px] leading-relaxed text-slate-600">
                        Comece arrastando e soltando etapas na tela do <strong>Mapeador de Processos</strong>. Coloque seus dados aproximados de tempo e veja o robô encontrar e alertar o gargalo na hora. O resto do sistema vai se preencher automaticamente!
                      </p>
                    </div>
                  </div>
                )}

              </div>

              {/* FOOTER METRICS AND CREDITS */}
              <div className="p-4 bg-slate-100 border-t border-slate-200 text-[8.5px] font-mono text-slate-500 flex justify-between items-center shrink-0">
                <span>ESTADO DO PROCESSO: {steps.length} ETAPAS</span>
                <span className="font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  MOTOR LSS CONECTADO
                </span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
