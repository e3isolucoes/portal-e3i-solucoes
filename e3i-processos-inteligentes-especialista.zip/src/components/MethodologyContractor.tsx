import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Award, 
  Zap, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Briefcase, 
  Settings, 
  TrendingUp, 
  Sparkles, 
  Building, 
  BookOpen, 
  Users, 
  Check, 
  X, 
  Info,
  ChevronDown,
  ChevronRight,
  Printer,
  FileCheck
} from "lucide-react";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";

export interface MethodologyItem {
  id: string;
  name: string;
  purpose: string;
  type: "efificiencia" | "eficacia" | "ambos";
  category: string;
  weightEf: number; // weight in efficiency (0 to 10)
  weightEc: number; // weight in effectiveness (0 to 10)
}

// All methodologies from the user prompt mapped into 14 distinct categories!
export const ALL_METHODOLOGIES: MethodologyItem[] = [
  // 1. Estratégia e Direção Empresarial
  { id: "pe", name: "Planejamento Estratégico", purpose: "Define visão, missão, objetivos, metas e prioridades.", type: "eficacia", category: "Estratégia e Direção", weightEf: 2, weightEc: 10 },
  { id: "swot", name: "Análise SWOT / FOFA", purpose: "Avalia forças, fraquezas, oportunidades e ameaças.", type: "eficacia", category: "Estratégia e Direção", weightEf: 1, weightEc: 8 },
  { id: "okr", name: "OKR — Objectives and Key Results", purpose: "Conecta objetivos estratégicos a resultados mensuráveis.", type: "eficacia", category: "Estratégia e Direção", weightEf: 4, weightEc: 10 },
  { id: "bsc", name: "BSC — Balanced Scorecard", purpose: "Traduz estratégia em indicadores financeiros, clientes, processos e aprendizado.", type: "eficacia", category: "Estratégia e Direção", weightEf: 3, weightEc: 9 },
  { id: "porter", name: "5 Forças de Porter", purpose: "Analisa competitividade do mercado.", type: "eficacia", category: "Estratégia e Direção", weightEf: 1, weightEc: 7 },
  { id: "bcg", name: "Matriz BCG", purpose: "Avalia portfólio de produtos/serviços.", type: "eficacia", category: "Estratégia e Direção", weightEf: 1, weightEc: 7 },
  { id: "pestel", name: "Análise PESTEL", purpose: "Avalia fatores políticos, econômicos, sociais, tecnológicos, ambientais e legais.", type: "eficacia", category: "Estratégia e Direção", weightEf: 1, weightEc: 6 },
  { id: "canvas", name: "Canvas de Modelo de Negócio", purpose: "Estrutura como a empresa cria, entrega e captura valor.", type: "eficacia", category: "Estratégia e Direção", weightEf: 2, weightEc: 8 },
  { id: "vp_canvas", name: "Proposta de Valor Canvas", purpose: "Ajuda a entender dores, ganhos e necessidades dos clientes.", type: "eficacia", category: "Estratégia e Direção", weightEf: 1, weightEc: 9 },

  // 2. Gestão por Processos
  { id: "bpm", name: "BPM — Business Process Management", purpose: "Gerencia processos ponta a ponta.", type: "efificiencia", category: "Gestão por Processos", weightEf: 10, weightEc: 4 },
  { id: "bpmn", name: "BPMN", purpose: "Desenha processos de forma visual e padronizada.", type: "efificiencia", category: "Gestão por Processos", weightEf: 9, weightEc: 3 },
  { id: "sipoc_met", name: "SIPOC", purpose: "Mapeia fornecedor, entrada, processo, saída e cliente.", type: "efificiencia", category: "Gestão por Processos", weightEf: 8, weightEc: 4 },
  { id: "vsm", name: "VSM — Value Stream Mapping", purpose: "Identifica desperdícios no fluxo de valor.", type: "efificiencia", category: "Gestão por Processos", weightEf: 9, weightEc: 5 },
  { id: "padr", name: "Padronização de Processos", purpose: "Garante execução consistente.", type: "efificiencia", category: "Gestão por Processos", weightEf: 10, weightEc: 2 },
  { id: "pop", name: "Procedimentos Operacionais Padrão (POPs)", purpose: "Documenta como executar atividades críticas.", type: "efificiencia", category: "Gestão por Processos", weightEf: 10, weightEc: 2 },
  { id: "raci", name: "RACI Matrix", purpose: "Define responsáveis, aprovadores, consultados e informados.", type: "efificiencia", category: "Gestão por Processos", weightEf: 8, weightEc: 4 },
  { id: "g_gargalos", name: "Gestão de Gargalos", purpose: "Identifica onde o fluxo trava.", type: "efificiencia", category: "Gestão por Processos", weightEf: 9, weightEc: 5 },
  { id: "aut", name: "Automação de Processos", purpose: "Reduz trabalho manual e erros repetitivos.", type: "efificiencia", category: "Gestão por Processos", weightEf: 10, weightEc: 6 },

  // 3. Qualidade e Melhoria Contínua
  { id: "pdca", name: "PDCA", purpose: "Planejar, executar, verificar e agir corretivamente.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 9, weightEc: 5 },
  { id: "kaizen", name: "Kaizen", purpose: "Melhoria contínua em pequenos ciclos.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 6 },
  { id: "lean", name: "Lean Management", purpose: "Elimina desperdícios e aumenta fluidez operacional.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 10, weightEc: 5 },
  { id: "sixsigma", name: "Six Sigma", purpose: "Reduz variações e defeitos com base estatística.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 9, weightEc: 4 },
  { id: "dmaic_met", name: "DMAIC", purpose: "Define, mede, analisa, melhora e controla problemas.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 4 },
  { id: "fives", name: "5S", purpose: "Organização, limpeza, padronização e disciplina.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 1 },
  { id: "gemba", name: "Gemba Walk", purpose: "Observação direta do trabalho real.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 7, weightEc: 3 },
  { id: "ishikawa", name: "Diagrama de Ishikawa", purpose: "Identifica causas-raiz.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 3 },
  { id: "five_w", name: "5 Porquês", purpose: "Aprofunda a investigação de problemas.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 2 },
  { id: "pareto", name: "Pareto 80/20", purpose: "Prioriza causas que geram maior impacto.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 8, weightEc: 5 },
  { id: "fmea", name: "FMEA", purpose: "Analisa modos de falha e riscos preventivamente.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 9, weightEc: 4 },
  { id: "cep", name: "CEP — Controle Estatístico de Processos", purpose: "Monitora estabilidade e variação de processos.", type: "efificiencia", category: "Qualidade e Melhoria", weightEf: 10, weightEc: 2 },

  // 4. Governança Corporativa e Gestão Organizacional
  { id: "gov", name: "Governança Corporativa", purpose: "Define papéis, responsabilidades e regras de decisão.", type: "eficacia", category: "Governança e Riscos", weightEf: 4, weightEc: 8 },
  { id: "alcadas", name: "Modelo de Alçadas", purpose: "Define quem pode aprovar o quê.", type: "efificiencia", category: "Governança e Riscos", weightEf: 7, weightEc: 5 },
  { id: "comites", name: "Comitês de Gestão", purpose: "Estruturam decisões estratégicas, financeiras e operacionais.", type: "eficacia", category: "Governança e Riscos", weightEf: 3, weightEc: 8 },
  { id: "politicas", name: "Políticas Internas", purpose: "Padronizam condutas e regras.", type: "efificiencia", category: "Governança e Riscos", weightEf: 6, weightEc: 5 },
  { id: "auditorias", name: "Auditorias Internas", purpose: "Verificam conformidade e riscos.", type: "efificiencia", category: "Governança e Riscos", weightEf: 8, weightEc: 6 },
  { id: "controles", name: "Gestão de Controles Internos", purpose: "Evita fraudes, erros e perdas.", type: "efificiencia", category: "Governança e Riscos", weightEf: 9, weightEc: 5 },
  { id: "compliance", name: "Compliance", purpose: "Garante aderência a normas, leis e políticas.", type: "eficacia", category: "Governança e Riscos", weightEf: 5, weightEc: 8 },
  { id: "coso", name: "COSO", purpose: "Estrutura controles internos e gestão de riscos.", type: "eficacia", category: "Governança e Riscos", weightEf: 6, weightEc: 7 },
  { id: "tres_linhas", name: "Três Linhas de Defesa", purpose: "Organiza responsabilidades de operação, risco e auditoria.", type: "eficacia", category: "Governança e Riscos", weightEf: 5, weightEc: 7 },

  // 5. Gestão de Indicadores e Performance
  { id: "kpis", name: "KPIs — Key Performance Indicators", purpose: "Mede desempenho dos processos e áreas.", type: "eficacia", category: "Indicadores e Performance", weightEf: 7, weightEc: 9 },
  { id: "kris", name: "KRIs — Key Risk Indicators", purpose: "Mede exposição a riscos.", type: "eficacia", category: "Indicadores e Performance", weightEf: 5, weightEc: 8 },
  { id: "slas", name: "SLAs", purpose: "Define prazos e níveis de serviço.", type: "efificiencia", category: "Indicadores e Performance", weightEf: 9, weightEc: 7 },
  { id: "dashboards", name: "Dashboards Executivos", purpose: "Mostram visão consolidada para decisão.", type: "eficacia", category: "Indicadores e Performance", weightEf: 6, weightEc: 9 },
  { id: "gestao_vista", name: "Gestão à Vista", purpose: "Expõe indicadores para acompanhamento contínuo.", type: "efificiencia", category: "Indicadores e Performance", weightEf: 8, weightEc: 6 },
  { id: "reuniao_perf", name: "Reuniões de Performance", purpose: "Cria cadência de acompanhamento dos resultados.", type: "eficacia", category: "Indicadores e Performance", weightEf: 5, weightEc: 10 },
  { id: "smart", name: "Metas SMART", purpose: "Define metas específicas, mensuráveis, alcançáveis, relevantes e temporais.", type: "eficacia", category: "Indicadores e Performance", weightEf: 4, weightEc: 9 },
  { id: "bench", name: "Benchmarking", purpose: "Compara desempenho com mercado ou referências internas.", type: "eficacia", category: "Indicadores e Performance", weightEf: 5, weightEc: 8 },

  // 6. Gestão Financeira e Econômica
  { id: "orcamento", name: "Orçamento Empresarial", purpose: "Planeja receitas, custos e investimentos.", type: "eficacia", category: "Gestão Financeira", weightEf: 6, weightEc: 9 },
  { id: "forecast", name: "Forecast", purpose: "Atualiza projeções conforme a realidade muda.", type: "eficacia", category: "Gestão Financeira", weightEf: 5, weightEc: 8 },
  { id: "fluxo_caixa", name: "Fluxo de Caixa", purpose: "Controla entradas e saídas de dinheiro.", type: "efificiencia", category: "Gestão Financeira", weightEf: 9, weightEc: 8 },
  { id: "dre", name: "DRE Gerencial", purpose: "Mostra resultado econômico por período.", type: "eficacia", category: "Gestão Financeira", weightEf: 6, weightEc: 9 },
  { id: "analise_margem", name: "Análise de Margem", purpose: "Avalia rentabilidade de produtos, clientes e canais.", type: "eficacia", category: "Gestão Financeira", weightEf: 7, weightEc: 10 },
  { id: "centro_custos", name: "Centro de Custos", purpose: "Organiza custos por área ou unidade.", type: "efificiencia", category: "Gestão Financeira", weightEf: 8, weightEc: 6 },
  { id: "abc_costing", name: "ABC Costing", purpose: "Calcula custo baseado em atividades.", type: "efificiencia", category: "Gestão Financeira", weightEf: 10, weightEc: 5 },
  { id: "roi", name: "ROI", purpose: "Mede retorno sobre investimento.", type: "eficacia", category: "Gestão Financeira", weightEf: 5, weightEc: 9 },
  { id: "payback", name: "Payback", purpose: "Mede tempo para recuperar investimento.", type: "eficacia", category: "Gestão Financeira", weightEf: 4, weightEc: 8 },
  { id: "viabilidade", name: "Análise de Viabilidade", purpose: "Avalia se um projeto deve ser executado.", type: "eficacia", category: "Gestão Financeira", weightEf: 4, weightEc: 9 },
  { id: "orc_matricial", name: "Gestão Orçamentária Matricial", purpose: "Cruza responsabilidades por contas e áreas.", type: "efificiencia", category: "Gestão Financeira", weightEf: 8, weightEc: 7 },

  // 7. Gestão Comercial, Marketing e Clientes
  { id: "crm", name: "CRM — Customer Relationship", purpose: "Organiza relacionamento e histórico completo com clientes.", type: "eficacia", category: "Comercial e Clientes", weightEf: 6, weightEc: 9 },
  { id: "funil", name: "Funil de Vendas", purpose: "Acompanha etapas progressivas da venda.", type: "eficacia", category: "Comercial e Clientes", weightEf: 5, weightEc: 8 },
  { id: "jornada", name: "Jornada do Cliente", purpose: "Entende a experiência e sentimentos ponta a ponta.", type: "eficacia", category: "Comercial e Clientes", weightEf: 4, weightEc: 10 },
  { id: "persona", name: "Persona", purpose: "Define o perfil ideal do cliente da organização.", type: "eficacia", category: "Comercial e Clientes", weightEf: 1, weightEc: 8 },
  { id: "nps", name: "NPS — Net Promoter Score", purpose: "Mede recomendação, lealdade e satisfação.", type: "eficacia", category: "Comercial e Clientes", weightEf: 3, weightEc: 10 },
  { id: "customer_success", name: "Customer Success", purpose: "Garante que o cliente de fato obtenha o resultado desejado.", type: "eficacia", category: "Comercial e Clientes", weightEf: 4, weightEc: 10 },

  // 8. Gestão de Pessoas e Cultura
  { id: "competencias", name: "Gestão por Competências", purpose: "Alinha habilidades individuais às necessidades do negócio.", type: "efificiencia", category: "Pessoas e Cultura", weightEf: 8, weightEc: 7 },
  { id: "cargos_salarios", name: "Plano de Cargos e Salários", purpose: "Dá clareza e transparência sobre crescimento e remuneração.", type: "eficacia", category: "Pessoas e Cultura", weightEf: 5, weightEc: 8 },
  { id: "feedback_cont", name: "Feedback Contínuo", purpose: "Corrige rota, reduz atritos e desenvolve pessoas rapidamente.", type: "efificiencia", category: "Pessoas e Cultura", weightEf: 9, weightEc: 7 },
  { id: "pdi_met", name: "PDI — Plano de Desenvolvimento", purpose: "Estrutura a evolução profissional alinhada aos gaps futuros.", type: "eficacia", category: "Pessoas e Cultura", weightEf: 4, weightEc: 9 },
  { id: "9box", name: "Matriz 9 Box", purpose: "Avalia o cruzamento exato de desempenho e potencial futuro.", type: "eficacia", category: "Pessoas e Cultura", weightEf: 4, weightEc: 9 },

  // 9. Gestão de Projetos e Portfólio
  { id: "pmbok_met", name: "PMBOK", purpose: "Melhores práticas clássicas globais de gestão de projetos.", type: "efificiencia", category: "Gestão de Projetos", weightEf: 8, weightEc: 6 },
  { id: "scrum_met", name: "Scrum / Agile", purpose: "Gestão ágil para entregas iterativas rápidas e flexíveis.", type: "eficacia", category: "Gestão de Projetos", weightEf: 7, weightEc: 9 },
  { id: "kanban_met", name: "Kanban", purpose: "Gestão e controle visual de fluxo de trabalho diário.", type: "efificiencia", category: "Gestão de Projetos", weightEf: 10, weightEc: 5 },
  { id: "roadmap_met", name: "Roadmap Geral", purpose: "Organiza entregas táticas previstas ao longo do tempo.", type: "eficacia", category: "Gestão de Projetos", weightEf: 5, weightEc: 9 },

  // 10. Gestão de Riscos
  { id: "iso31000", name: "ISO 31000 — Gestão de Riscos", purpose: "Estrutura as políticas e identificação crítica de riscos.", type: "eficacia", category: "Gestão de Riscos", weightEf: 6, weightEc: 8 },
  { id: "matriz_riscos", name: "Matriz de Probabilidade x Impacto", purpose: "Classifica e prioriza os perigos preventivamente.", type: "eficacia", category: "Gestão de Riscos", weightEf: 5, weightEc: 9 },
  { id: "plano_mitigacao", name: "Plano de Mitigação & Contingência", purpose: "Define ações em caso de risco iminente ou ocorrido.", type: "efificiencia", category: "Gestão de Riscos", weightEf: 8, weightEc: 8 },

  // 11. Tecnologia, Dados e Transformação Digital
  { id: "gov_dados", name: "Governança de Dados", purpose: "Define qualidade, segurança e conformidade dos dados.", type: "eficacia", category: "Tecnologia e Dados", weightEf: 7, weightEc: 9 },
  { id: "bi_tool", name: "BI — Business Intelligence", purpose: "Transmuta dados brutos em inteligência gerencial ágil.", type: "eficacia", category: "Tecnologia e Dados", weightEf: 6, weightEc: 10 },
  { id: "rpa_tool", name: "Automação com RPA (Robots)", purpose: "Automatiza tarefas estritamente repetitivas operacionais.", type: "efificiencia", category: "Tecnologia e Dados", weightEf: 10, weightEc: 4 },
  { id: "devops_met", name: "DevOps / SRE practices", purpose: "Sincroniza desenvolvimento com estabilidade operacional.", type: "efificiencia", category: "Tecnologia e Dados", weightEf: 9, weightEc: 6 },

  // 12. Operações e Produtividade
  { id: "gestao_rotina", name: "Gestão da Rotina diária", purpose: "Garante cadência no acompanhamento das metas diárias.", type: "efificiencia", category: "Operações e Produtividade", weightEf: 10, weightEc: 5 },
  { id: "daily_meet", name: "Daily Meeting (15m)", purpose: "Alinha e descongestiona prioridades das equipes diariamente.", type: "efificiencia", category: "Operações e Produtividade", weightEf: 9, weightEc: 5 },
  { id: "restricoes", name: "TOC — Teoria das Restrições", purpose: "Foca em melhorar unicamente o gargalo principal do fluxo.", type: "efificiencia", category: "Operações e Produtividade", weightEf: 10, weightEc: 7 },
  { id: "gut_matrix", name: "Matriz GUT", purpose: "Garante priorização lógica por Gravidade, Urgência e Tendência.", type: "efificiencia", category: "Operações e Produtividade", weightEf: 8, weightEc: 6 },
  { id: "five_w_two_h", name: "Plano de Ação 5W2H", purpose: "Determina responsabilidade clara com cronograma de projeto.", type: "efificiencia", category: "Operações e Produtividade", weightEf: 9, weightEc: 5 },

  // 13. Inovação e Novos Negócios
  { id: "design_thinking", name: "Design Thinking", purpose: "Resolve desafios sob a perspectiva sensível do usuário.", type: "eficacia", category: "Inovação", weightEf: 3, weightEc: 10 },
  { id: "lean_startup", name: "Lean Startup", purpose: "Testa ideias ao menor custo e ajusta de forma iterativa.", type: "eficacia", category: "Inovação", weightEf: 7, weightEc: 9 },
  { id: "mvp", name: "MVP — Mínimo Produto Viável", purpose: "Valida rapidamente hipóteses de mercado antes do aporte.", type: "eficacia", category: "Inovação", weightEf: 6, weightEc: 10 },

  // 14. Sustentabilidade e ESG
  { id: "esg", name: "Práticas ESG integradas", purpose: "Mapeamento ecológico, social e de governança rígido.", type: "eficacia", category: "Sustentabilidade", weightEf: 4, weightEc: 8 }
];

const MATURITY_RECOMMENDATIONS = {
  INITIAL: ["pe", "swot", "smart", "fluxo_caixa", "crm", "sipoc_met", "kpis", "five_w_two_h", "pdca", "gestao_rotina"],
  GROWTH: ["okr", "bpm", "lean", "pmbok_met", "bi_tool", "competencias", "orcamento", "gov_dados", "matriz_riscos", "aut"],
  MATURE: ["bsc", "gov", "roadmap_met", "sixsigma", "compliance", "auditorias", "9box", "devops_met", "esg", "restricoes"]
};

const PILLARS_QUESTIONS = [
  { id: 1, pilar: "Estratégia", label: "Sabemos com precisão científica para onde estamos indo nos próximos anos?" },
  { id: 2, pilar: "Processos", label: "Sabemos e documentamos fielmente como o trabalho operacional deve ser feito?" },
  { id: 3, pilar: "Pessoas", label: "Possuímos as competências adequadas e alinhadas aos gargalos corporativos?" },
  { id: 4, pilar: "Tecnologia", label: "Utilizamos ferramentas integradas para blindar os fluxos contra erros humanos?" },
  { id: 5, pilar: "Dados", label: "Decidimos novos rumos com base em fatos observáveis e medições geradas?" },
  { id: 6, pilar: "Cliente", label: "Entregamos valor real observável e mitigamos perdas de insatisfação (churn)?" },
  { id: 7, pilar: "Finanças", label: "Nossos outputs geram receitas previsíveis e margem de contribuição saudável?" },
  { id: 8, pilar: "Governança", label: "Temos papéis cristalinos e alçadas de decisão seguras para mitigar fraudes?" },
  { id: 9, pilar: "Inovação", label: "Estamos evoluindo ativamente ou lanchando lucros de modelos jurássicos?" },
  { id: 10, pilar: "Cultura", label: "Todos agem perante os valores em comum de forma autônoma e disciplinada?" }
];

interface MethodologyContractorProps {
  currentCargo?: string;
  activeCompanyId?: string | null;
  globalCompanies?: any[];
  setGlobalCompanies?: (companies: any[]) => void;
}

export default function MethodologyContractor({
  currentCargo = "Admin",
  activeCompanyId = null,
  globalCompanies = [],
  setGlobalCompanies
}: MethodologyContractorProps) {
  const [selectedMaturity, setSelectedMaturity] = useState<"ALL" | "INITIAL" | "GROWTH" | "MATURE">("INITIAL");
  const [enabledIds, setEnabledIds] = useState<string[]>(MATURITY_RECOMMENDATIONS.INITIAL);
  const [clientContractName, setClientContractName] = useState<string>("Indústrias Marco S/A - Contrato de Eficiência");
  const [isContractPrinted, setIsContractPrinted] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [answers, setAnswers] = useState<Record<number, boolean>>({
    1: true, 2: false, 3: true, 4: false, 5: false, 6: true, 7: true, 8: false, 9: false, 10: true
  });

  const [activeToolId, setActiveToolId] = useState<string | null>(null);

  // SWOT State
  const [swotStrengths, setSwotStrengths] = useState<string[]>([
    "Processo operacional flexível",
    "Time qualificado e engajado"
  ]);
  const [swotWeaknesses, setSwotWeaknesses] = useState<string[]>([
    "Sobrecarga de trabalho no posto de revisão",
    "Falta de automação em fatiamento de lotes"
  ]);
  const [swotOpportunities, setSwotOpportunities] = useState<string[]>([
    "Implementar inteligência artificial para apoio",
    "Digitalizar POPs de inspeção"
  ]);
  const [swotThreats, setSwotThreats] = useState<string[]>([
    "Sufocamento de fluxo por desligamentos",
    "Aumento no tempo de resposta do SLA"
  ]);
  const [newSwotText, setNewSwotText] = useState<string>("");

  // OKRs State
  const [okrs, setOkrs] = useState([
    { id: 1, text: "Garantir eficácia operacional do backlog", kr: "Reduzir tempo médio de ciclo em 20%", progress: 60 },
    { id: 2, text: "Implantar padronização corporativa", kr: "Documentar 15 POPs revisados e instruir equipes", progress: 40 },
    { id: 3, text: "Otimizar custos de processamento", kr: "Alcançar economia de R$ 50 mil e ROI de 150%", progress: 10 }
  ]);

  // 5S Audit state
  const [fivesScores, setFivesScores] = useState<Record<string, number>>({
    seiri: 3,
    seiton: 4,
    seiso: 3,
    seiketsu: 2,
    shitsuke: 4
  });

  // PDCA State
  const [pdcaStages, setPdcaStages] = useState({
    Plan: "Identificar gargalos operacionais e definir plano de ação para redistribuição.",
    Do: "Alocar analista sênior para apoiar o posto gargalo.",
    Check: "Comparar cartas CEP antes e depois do ajuste de postos de trabalho no simulador.",
    Act: "Adotar padronização de setup e lançar manual normativo estrito para conformidade."
  });

  // 5W2H State
  const [fiveW2hEntries, setFiveW2hEntries] = useState([
    { what: "Redesenhar o layout do posto 3", why: "Eliminar a fila de acumulação de faturas", where: "Gargalo operacional", when: "Próxima segunda", who: "Master Black Belt", how: "Redistribuição de tarefas", howMuch: "R$ 1.500", status: "Em Andamento" },
    { what: "Instruir equipe no novo POP", why: "Evitar retrabalhos e desvios de operação", where: "Posto do triador", when: "Próxima quarta", who: "Analista Sênior", how: "Atendimento presencial/remoto", howMuch: "R$ 0", status: "Não Iniciado" }
  ]);
  const [new5W2H, setNew5W2H] = useState({ what: "", why: "", where: "", when: "", who: "", how: "", howMuch: "", status: "Não Iniciado" });

  const canManageMethodology = () => {
    if (!currentCargo) return false;
    const normalized = currentCargo.toLowerCase();
    return (
      normalized === "admin" ||
      normalized === "administrador" ||
      normalized === "dono do processo" ||
      normalized.includes("dono")
    );
  };

  // Sync with active company from global state / repository
  useEffect(() => {
    if (activeCompanyId && globalCompanies && globalCompanies.length > 0) {
      const activeComp = globalCompanies.find(c => c.id === activeCompanyId);
      if (activeComp) {
        setClientContractName(activeComp.name || "Seu Contrato");
        if (activeComp.enabledMethodologies && activeComp.enabledMethodologies.length > 0) {
          setEnabledIds(activeComp.enabledMethodologies);
        } else {
          setEnabledIds(MATURITY_RECOMMENDATIONS.INITIAL);
        }
      }
    }
  }, [activeCompanyId, globalCompanies]);

  const toggleMethodology = (id: string) => {
    if (!canManageMethodology()) {
      alert("Acesso Restrito: A liberação ou alteração dos Módulos Integrados de Negócios (Metodologias Operacionais) deve ser feita exclusivamente por Administradores ou Donos do Processo!");
      return;
    }
    let updatedIds = [];
    if (enabledIds.includes(id)) {
      updatedIds = enabledIds.filter(x => x !== id);
    } else {
      updatedIds = [...enabledIds, id];
    }
    setEnabledIds(updatedIds);

    // Save to the active company
    if (activeCompanyId && globalCompanies && setGlobalCompanies) {
      const updatedComps = globalCompanies.map(c => {
        if (c.id === activeCompanyId) {
          return { ...c, enabledMethodologies: updatedIds };
        }
        return c;
      });
      setGlobalCompanies(updatedComps);
      const email = localStorage.getItem("six_sigma_active_user") 
        ? JSON.parse(localStorage.getItem("six_sigma_active_user") || "{}").email 
        : "";
      CompanyProjectRepository.saveCompanies(updatedComps, email);
    }
  };

  const applyMaturityPreset = (preset: "INITIAL" | "GROWTH" | "MATURE") => {
    if (!canManageMethodology()) {
      alert("Acesso Restrito: A aplicação de presets de maturidade e liberação de módulos operacionais deve ser feita por Administradores ou Donos do Processo.");
      return;
    }
    setSelectedMaturity(preset);
    const updatedIds = MATURITY_RECOMMENDATIONS[preset];
    setEnabledIds(updatedIds);

    // Save to the active company
    if (activeCompanyId && globalCompanies && setGlobalCompanies) {
      const updatedComps = globalCompanies.map(c => {
        if (c.id === activeCompanyId) {
          return { ...c, enabledMethodologies: updatedIds };
        }
        return c;
      });
      setGlobalCompanies(updatedComps);
      const email = localStorage.getItem("six_sigma_active_user") 
        ? JSON.parse(localStorage.getItem("six_sigma_active_user") || "{}").email 
        : "";
      CompanyProjectRepository.saveCompanies(updatedComps, email);
    }
  };

  const handleToggleAnswer = (id: number) => {
    setAnswers(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Calculations for KPI Progress bars (Eficiência vs Eficácia)
  const enabledItems = ALL_METHODOLOGIES.filter(m => enabledIds.includes(m.id));
  
  const maxWeightEf = ALL_METHODOLOGIES.filter(m => m.type !== "eficacia").reduce((acc, x) => acc + x.weightEf, 0);
  const maxWeightEc = ALL_METHODOLOGIES.filter(m => m.type !== "efificiencia").reduce((acc, x) => acc + x.weightEc, 0);

  const curWeightEf = enabledItems.reduce((acc, x) => acc + x.weightEf, 0);
  const curWeightEc = enabledItems.reduce((acc, x) => acc + x.weightEc, 0);

  const eficienciaScore = Math.min(100, Math.round((curWeightEf / maxWeightEf) * 115));
  const eficaciaScore = Math.min(100, Math.round((curWeightEc / maxWeightEc) * 115));

  // Determine maturity recommendation list
  const renderInteractiveToolModal = () => {
    if (!activeToolId) return null;

    return (
      <div className="fixed inset-0 bg-[#1A1A1A]/85 flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
        <div className="bg-white border-4 border-[#1A1A1A] max-w-3xl w-full p-6 text-left space-y-4 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] max-h-[92vh] overflow-y-auto">
          
          <div className="flex justify-between items-start border-b-2 border-[#1A1A1A] pb-3">
            <div>
              <span className="text-[8px] font-mono font-black tracking-widest bg-indigo-100 text-indigo-900 px-1.5 py-0.5 uppercase rounded-2xs">
                ⚙️ Execução de Módulo Corporativo Ativo
              </span>
              <h4 className="font-serif text-lg font-black text-gray-900 mt-1">
                {activeToolId === "swot" && "Módulo Ativo: Matriz SWOT / FOFA"}
                {activeToolId === "okr" && "Módulo Ativo: Gestão de OKRs Operacionais"}
                {activeToolId === "fives" && "Módulo Ativo: Auditoria 5S (Processo Lean)"}
                {activeToolId === "pdca" && "Módulo Ativo: Ciclo PDCA Automatizado"}
                {activeToolId === "five_w_two_h" && "Módulo Ativo: Plano de Ação Estruturado 5W2H"}
              </h4>
            </div>
            <button 
              onClick={() => setActiveToolId(null)}
              className="bg-gray-100 hover:bg-gray-200 border-2 border-[#1A1A1A] px-2 py-1 font-mono font-bold text-xs cursor-pointer rounded-xs"
            >
              FECHAR ×
            </button>
          </div>

          <div className="text-xs text-gray-800">
            {/* SWOT TOOL UI */}
            {activeToolId === "swot" && (
              <div className="space-y-4 font-sans">
                <p className="text-[11px] text-gray-500 leading-snug">
                  Mapeie as forças, fraquezas, oportunidades e ameaças da organização para definir prioridades estratégicas neste ciclo DMAIC.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  <div className="bg-emerald-50/50 border border-emerald-500/20 p-3 rounded-xs space-y-2">
                    <span className="text-[9px] font-mono font-bold text-emerald-800 block uppercase">💪 Forças (Interno - Positivo)</span>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-gray-800">
                      {swotStrengths.map((s, idx) => (
                        <li key={idx} className="flex justify-between items-center group">
                          <span>• {s}</span>
                          <button onClick={() => setSwotStrengths(p => p.filter((_, i) => i !== idx))} className="text-xs text-red-500 opacity-0 group-hover:opacity-100 font-mono hover:underline cursor-pointer">remover</button>
                        </li>
                      ))}
                    </ul>
                    <div className="flex gap-1 pt-1.5">
                      <input 
                        type="text" 
                        placeholder="Adicionar força... (pressione Enter)" 
                        className="bg-white border border-gray-300 p-1 px-1.5 focus:outline-none w-full text-[10.5px] rounded-xs"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && e.currentTarget.value.trim()) {
                            setSwotStrengths([...swotStrengths, e.currentTarget.value.trim()]);
                            e.currentTarget.value = "";
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="bg-rose-50/50 border border-rose-500/20 p-3 rounded-xs space-y-2">
                    <span className="text-[9px] font-mono font-bold text-rose-800 block uppercase">⚠️ Fraquezas (Interno - Negativo)</span>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-gray-800">
                      {swotWeaknesses.map((w, idx) => (
                        <li key={idx} className="flex justify-between items-center group">
                          <span>• {w}</span>
                          <button onClick={() => setSwotWeaknesses(p => p.filter((_, i) => i !== idx))} className="text-xs text-red-500 opacity-0 group-hover:opacity-100 font-mono hover:underline cursor-pointer">remover</button>
                        </li>
                      ))}
                    </ul>
                    <div className="flex gap-1 pt-1.5">
                      <input 
                        type="text" 
                        placeholder="Adicionar fraqueza... (pressione Enter)" 
                        className="bg-white border border-gray-300 p-1 px-1.5 focus:outline-none w-full text-[10.5px] rounded-xs"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && e.currentTarget.value.trim()) {
                            setSwotWeaknesses([...swotWeaknesses, e.currentTarget.value.trim()]);
                            e.currentTarget.value = "";
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="bg-indigo-50/50 border border-indigo-500/20 p-3 rounded-xs space-y-2">
                    <span className="text-[9px] font-mono font-bold text-indigo-800 block uppercase">🚀 Oportunidades (Externo - Positivo)</span>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-gray-800">
                      {swotOpportunities.map((o, idx) => (
                        <li key={idx} className="flex justify-between items-center group">
                          <span>• {o}</span>
                          <button onClick={() => setSwotOpportunities(p => p.filter((_, i) => i !== idx))} className="text-xs text-red-500 opacity-0 group-hover:opacity-100 font-mono hover:underline cursor-pointer">remover</button>
                        </li>
                      ))}
                    </ul>
                    <div className="flex gap-1 pt-1.5">
                      <input 
                        type="text" 
                        placeholder="Adicionar oportunidade... (pressione Enter)" 
                        className="bg-white border border-gray-300 p-1 px-1.5 focus:outline-none w-full text-[10.5px] rounded-xs"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && e.currentTarget.value.trim()) {
                            setSwotOpportunities([...swotOpportunities, e.currentTarget.value.trim()]);
                            e.currentTarget.value = "";
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="bg-amber-50/50 border border-amber-500/20 p-3 rounded-xs space-y-2">
                    <span className="text-[9px] font-mono font-bold text-amber-800 block uppercase">⚡ Ameaças (Externo - Negativo)</span>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-gray-800">
                      {swotThreats.map((t, idx) => (
                        <li key={idx} className="flex justify-between items-center group">
                          <span>• {t}</span>
                          <button onClick={() => setSwotThreats(p => p.filter((_, i) => i !== idx))} className="text-xs text-red-500 opacity-0 group-hover:opacity-100 font-mono hover:underline cursor-pointer">remover</button>
                        </li>
                      ))}
                    </ul>
                    <div className="flex gap-1 pt-1.5">
                      <input 
                        type="text" 
                        placeholder="Adicionar ameaça... (pressione Enter)" 
                        className="bg-white border border-gray-300 p-1 px-1.5 focus:outline-none w-full text-[10.5px] rounded-xs"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && e.currentTarget.value.trim()) {
                            setSwotThreats([...swotThreats, e.currentTarget.value.trim()]);
                            e.currentTarget.value = "";
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-gray-50 border border-gray-200 rounded-xs text-[10.5px] leading-snug">
                  📌 <strong>Nota do MBB:</strong> A combinação das forças internas e oportunidades externas potencializará as metas do plano de negócio em até 20%!
                </div>
              </div>
            )}

            {/* OKR TOOL UI */}
            {activeToolId === "okr" && (
              <div className="space-y-4">
                <p className="text-[11px] text-gray-500 font-sans">
                  Defina os Objetivos Estratégicos (Corporate) e meça o progresso real de cada Key Result (Métrica de Sucesso) vinculados à melhoria contínua.
                </p>

                <div className="space-y-3.5 bg-gray-50 p-4 border border-gray-200 rounded-xs">
                  {okrs.map((okr) => (
                    <div key={okr.id} className="bg-white p-3 border border-gray-250 rounded-xs space-y-2.5">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[8.5px] font-mono font-extrabold text-indigo-700 block uppercase">OBJETIVO #{okr.id}</span>
                          <h6 className="font-sans font-extrabold text-[12px] text-gray-950 mt-0.5">{okr.text}</h6>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-gray-500 bg-gray-100 px-1.5 py-0.2 rounded-xs border">
                          {okr.progress}% Concluído
                        </span>
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[10px] text-gray-600 font-sans italic">
                          <span><strong>Métrica Chave (KR):</strong> {okr.kr}</span>
                        </div>
                        {/* Interactive Slider */}
                        <div className="flex items-center gap-3">
                          <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            value={okr.progress}
                            onChange={(e) => {
                              const val = parseInt(e.target.value);
                              setOkrs(prev => prev.map(o => o.id === okr.id ? { ...o, progress: val } : o));
                            }}
                            className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-gray-200 rounded-lg appearance-none"
                          />
                          <span className="font-mono text-xs font-bold shrink-0 w-8 text-right select-none">{okr.progress}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xs font-mono text-[10.5px] flex justify-between items-center text-indigo-900">
                  <span>Média Geral Operacional de Metas OKR:</span>
                  <strong className="text-sm font-extrabold">
                    {Math.round(okrs.reduce((acc, o) => acc + o.progress, 0) / okrs.length)}% de Progresso
                  </strong>
                </div>
              </div>
            )}

            {/* 5S AUDIT TOOL UI */}
            {activeToolId === "fives" && (
              <div className="space-y-4">
                <p className="text-[11px] text-gray-500 font-sans">
                  Avalie o nível de disciplina e organização física/digital da empresa do cliente. Atribua notas de 1 (Crítico) a 5 (Excelente) para cada pilar.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                  {[
                    { key: "seiri", name: "Seiri (Utilização)", desc: "Separar o que é útil do inútil. Eliminar excesso de burocracia ou ferramentas ociosas." },
                    { key: "seiton", name: "Seiton (Ordenação)", desc: "Um lugar para cada coisa e cada coisa no seu lugar. Facilidade na busca de pastas de projetos." },
                    { key: "seiso", name: "Seiso (Limpeza)", desc: "Zelo por arquivos e dashboards digitais excelentes, limpando desvios e erros de script." },
                    { key: "seiketsu", name: "Seiketsu (Padronização)", desc: "Zelo pela higiene mental, condições de trabalho seguras e aplicação de POPs." },
                    { key: "shitsuke", name: "Shitsuke (Disciplina)", desc: "Seguir os combinados rigorosamente. Tornar o cumprimento do 5S um hábito de governança." }
                  ].map((s) => {
                    const score = fivesScores[s.key];
                    return (
                      <div key={s.key} className="bg-gray-50 border border-gray-200 p-3 rounded-xs flex flex-col justify-between text-left space-y-2">
                        <div>
                          <strong className="block text-[11px] text-gray-950 font-bold">{s.name}</strong>
                          <p className="text-[9.5px] text-gray-500 mt-0.5 leading-tight">{s.desc}</p>
                        </div>
                        <div className="space-y-1.5 pt-1">
                          <span className="text-[9.5px] font-mono text-indigo-700 block text-center font-bold">Nota: {score}/5</span>
                          <div className="flex gap-1 justify-center">
                            {[1, 2, 3, 4, 5].map((n) => (
                              <button
                                key={n}
                                onClick={() => setFivesScores(prev => ({ ...prev, [s.key]: n }))}
                                className={`w-5 h-5 text-[9.5px] font-mono font-bold rounded-xs border flex items-center justify-center transition-all cursor-pointer ${
                                  score === n 
                                    ? "bg-indigo-650 text-white border-[#1A1A1A]" 
                                    : "bg-white text-gray-600 border-gray-200 hover:border-gray-400"
                                }`}
                              >
                                {n}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Calculate score */}
                {(() => {
                  const total = (Object.values(fivesScores) as number[]).reduce((acc, s) => acc + s, 0);
                  const maxPossible = 25;
                  const ratio = Math.round((total / maxPossible) * 100);
                  return (
                    <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                      <div className="text-left font-sans text-[11px] text-emerald-950 leading-snug">
                        <strong>📊 Resultado de Maturidade 5S do Cliente: {ratio}% ({total} de 25 pontos)</strong>
                        <p className="text-[10px] text-emerald-800 mt-0.5">
                          {ratio >= 80 ? "Selo Black Belt de Organização Lean! Ambientes higienizados e focados na agilidade operacional." : "Atenção: Necessário mutirão de descarte de desperdícios para resgatar foco no SLA."}
                        </p>
                      </div>
                      <div className="w-full md:w-44 bg-gray-150 h-2 border border-gray-200 rounded-xs overflow-hidden shrink-0">
                        <div className="bg-emerald-600 h-full animate-pulse" style={{ width: `${ratio}%` }}></div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* PDCA TOOL UI */}
            {activeToolId === "pdca" && (
              <div className="space-y-4 font-sans">
                <p className="text-[11px] text-gray-500 animate-fade-in">
                  Gerencie o andamento dos ciclos de melhoria contínua. Preencha e salve cada etapa do ciclo de Deming para evitar a persistência de desvios.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3.5">
                  {[
                    { key: "Plan", title: "📝 P - PLAN (Planejar)", placeholder: "Defina metas, objetivos e trace as ações para eliminar desvios e treinar equipes...", theme: "border-indigo-200 bg-indigo-50/20 text-indigo-950 font-bold" },
                    { key: "Do", title: "⚙️ D - DO (Executar)", placeholder: "Implemente as ações planejadas de forma rigorosa e colete dados preliminares...", theme: "border-amber-200 bg-amber-50/20 text-amber-950 font-bold" },
                    { key: "Check", title: "🔍 C - CHECK (Verificar)", placeholder: "Mensurar os resultados com base em gráficos CEP ou tempos de processamento médio...", theme: "border-emerald-200 bg-emerald-50/20 text-emerald-950 font-bold" },
                    { key: "Act", title: "🏆 A - ACT (Agir Corretamente)", placeholder: "Adote a padronização definitiva se as metas foram atingidas ou revise o plano se falhar...", theme: "border-violet-200 bg-violet-50/20 text-violet-950 font-bold" }
                  ].map((st) => (
                    <div key={st.key} className={`border p-3 rounded-xs space-y-2 flex flex-col justify-between ${st.theme}`}>
                      <div className="space-y-1 text-left">
                        <span className="text-[10px] font-mono uppercase tracking-wider block">{st.title}</span>
                        <textarea
                          rows={4}
                          value={pdcaStages[st.key as "Plan" | "Do" | "Check" | "Act"]}
                          onChange={(e) => {
                            const val = e.target.value;
                            setPdcaStages(prev => ({ ...prev, [st.key]: val }));
                          }}
                          className="w-full bg-white border border-gray-300 p-1.5 focus:outline-none focus:ring-1 focus:ring-[#1A1A1A] text-[10.5px] rounded-2xs text-gray-800 font-normal mt-1 leading-snug"
                          placeholder={st.placeholder}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-gray-100 border border-gray-250 p-3 rounded-xs text-[10px] leading-snug font-sans text-gray-500">
                  ✔️ <strong>Ciclo Iterativo Realimentado:</strong> O PDCA retroalimenta diretamente as metodologias de análise e mapeamento no co-piloto, servindo de fonte de insights!
                </div>
              </div>
            )}

            {/* 5W2H TOOL UI */}
            {activeToolId === "five_w_two_h" && (
              <div className="space-y-4 font-sans">
                <p className="text-[11px] text-gray-500">
                  Preencha o Roteiro de Plano de Trabalho 5W2H (What, Why, Where, When, Who, How, How Much) para formalizar a execução das tarefas operacionais.
                </p>

                <div className="overflow-x-auto border-2 border-[#1A1A1A]">
                  <table className="w-full text-left border-collapse text-[10px] font-mono">
                    <thead>
                      <tr className="bg-[#1A1A1A] text-white">
                        <th className="p-2 border-r border-white/20 uppercase font-sans">O que? (What)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Por que? (Why)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Onde? (Where)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Quando? (When)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Quem? (Who)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Como? (How)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Quanto? (How Much)</th>
                        <th className="p-2 border-r border-white/20 uppercase font-sans">Status</th>
                        <th className="p-2 text-center uppercase font-sans">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white font-sans">
                      {fiveW2hEntries.map((entry, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="p-2 border-r border-gray-200 font-extrabold text-[#1A1A1A]">{entry.what}</td>
                          <td className="p-2 border-r border-gray-200 text-gray-600 leading-snug">{entry.why}</td>
                          <td className="p-2 border-r border-gray-200 text-gray-500">{entry.where}</td>
                          <td className="p-2 border-r border-gray-200 font-mono text-[9px]">{entry.when}</td>
                          <td className="p-2 border-r border-gray-200 font-bold">{entry.who}</td>
                          <td className="p-2 border-r border-gray-200 text-gray-600 leading-snug">{entry.how}</td>
                          <td className="p-2 border-r border-gray-200 font-mono text-[9.5px] text-[#B15309] font-bold">{entry.howMuch}</td>
                          <td className="p-2 border-r border-gray-200 text-center">
                            <span className={`text-[8.5px] font-bold px-1.5 py-0.2 rounded-xs border uppercase inline-block ${
                              entry.status === "Concluído" ? "bg-emerald-50 text-emerald-800 border-emerald-200" :
                              entry.status === "Em Andamento" ? "bg-amber-50 text-amber-800 border-amber-200" :
                              "bg-gray-50 text-gray-500 border-gray-200"
                            }`}>
                              {entry.status}
                            </span>
                          </td>
                          <td className="p-2 text-center font-mono">
                            <button 
                              onClick={() => setFiveW2hEntries(prev => prev.filter((_, i) => i !== idx))}
                              className="text-red-600 hover:underline font-bold text-[9px] cursor-pointer"
                            >
                              Excluir
                            </button>
                          </td>
                        </tr>
                      ))}
                      {/* Form inputs */}
                      <tr className="bg-gray-50">
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Tarefa..." value={new5W2H.what} onChange={(e) => setNew5W2H({...new5W2H, what: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Motivo..." value={new5W2H.why} onChange={(e) => setNew5W2H({...new5W2H, why: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Local..." value={new5W2H.where} onChange={(e) => setNew5W2H({...new5W2H, where: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Prazo..." value={new5W2H.when} onChange={(e) => setNew5W2H({...new5W2H, when: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Membro..." value={new5W2H.who} onChange={(e) => setNew5W2H({...new5W2H, who: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Como..." value={new5W2H.how} onChange={(e) => setNew5W2H({...new5W2H, how: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <input type="text" placeholder="Valor..." value={new5W2H.howMuch} onChange={(e) => setNew5W2H({...new5W2H, howMuch: e.target.value})} className="w-full bg-white border border-gray-300 p-1 text-[9.5px] focus:outline-none rounded-2xs"/>
                        </td>
                        <td className="p-1 border-r border-gray-200">
                          <select value={new5W2H.status} onChange={(e) => setNew5W2H({...new5W2H, status: e.target.value})} className="w-full bg-white border border-gray-300 p-0.5 text-[9.5px] focus:outline-none">
                            <option value="Não Iniciado">Não Iniciado</option>
                            <option value="Em Andamento">Em Andamento</option>
                            <option value="Concluído">Concluído</option>
                          </select>
                        </td>
                        <td className="p-1 text-center font-mono">
                          <button
                            onClick={() => {
                              if (!new5W2H.what.trim()) return;
                              setFiveW2hEntries([...fiveW2hEntries, new5W2H]);
                              setNew5W2H({ what: "", why: "", where: "", when: "", who: "", how: "", howMuch: "", status: "Não Iniciado" });
                            }}
                            className="bg-[#1A1A1A] text-white hover:bg-indigo-650 px-2 py-1 text-[9px] font-bold uppercase transition-colors cursor-pointer rounded-xs"
                          >
                            Inserir
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 border-t border-gray-200 pt-4 mt-2 font-mono text-[9.5px]">
            <button 
              onClick={() => setActiveToolId(null)}
              className="bg-[#1A1A1A] text-white hover:bg-black font-mono text-[9px] font-bold py-1.5 px-3 border border-[#1A1A1A] uppercase cursor-pointer"
            >
              Confirmar e Concluir ✔️
            </button>
          </div>
        </div>
      </div>
    );
  };

  const filteredItems = ALL_METHODOLOGIES.filter(m => {
    const matchesSearch = m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          m.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          m.purpose.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div id="methodology-portfolio-studio" className="bg-white border-4 border-[#1A1A1A] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden text-[#1A1A1A] select-none text-left">
      
      {/* Top Banner section */}
      <div className="bg-[#1A1A1A] p-4 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-4 border-[#1A1A1A]">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-600 text-white font-mono text-[10px] font-black rounded-xs flex items-center gap-1">
            <ShieldCheck size={14} className="stroke-2 animate-bounce" />
            CONTRATO &amp; PORTFÓLIO
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[9px] uppercase font-mono tracking-widest text-amber-500">Módulo de Organização Estratégica</span>
              <span className="text-[8px] bg-white/10 text-white/80 px-1.5 py-0.2 rounded-xs border border-white/10 font-mono">BPM System V2</span>
            </div>
            <h4 className="font-serif text-lg leading-tight font-black">
              Matriz de Permissões, Métricas &amp; Contratos de Metodologias
            </h4>
          </div>
        </div>

        <div className="flex bg-white/5 border border-white/15 p-1 rounded-sm items-center">
          <span className="text-[9px] font-mono text-white/70 px-2 font-bold uppercase">Cadência:</span>
          <span className="text-[10px] font-mono font-black text-amber-400">EFICIÊNCIA x EFICÁCIA</span>
        </div>
      </div>

      {/* Concept Alert Overview highlighting Eficiência vs Eficácia definition */}
      <div className="p-5 md:p-6 bg-amber-50/50 border-b-2 border-[#1A1A1A] text-left space-y-3">
        <div className="flex flex-col md:flex-row items-start justify-between gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs uppercase font-mono">
              <Sparkles size={14} className="text-amber-600 animate-pulse" />
              CONCEITO EXECUTIVO: SUCESSO COLETIVO
            </div>
            <p className="font-serif text-sm text-gray-800 leading-relaxed max-w-4xl">
              Como Marco ensina, para uma empresa ser <strong>eficiente</strong> e <strong>eficaz</strong>, ela não precisa aplicar todas as metodologias ao mesmo tempo. Ela precisa escolher as certas para cada desafio ou maturidade do seu contrato.
            </p>
          </div>

          <div className="flex gap-2.5 shrink-0 w-full md:w-auto">
            <button
              onClick={() => applyMaturityPreset("INITIAL")}
              className={`p-1.5 px-3 text-[9px] font-mono font-bold tracking-wider border-2 ${selectedMaturity === "INITIAL" ? "bg-amber-100 border-[#1A1A1A] font-black" : "bg-white border-transparent text-gray-500 hover:text-gray-950"}`}
            >
              🌱 FASE INICIAL
            </button>
            <button
              onClick={() => applyMaturityPreset("GROWTH")}
              className={`p-1.5 px-3 text-[9px] font-mono font-bold tracking-wider border-2 ${selectedMaturity === "GROWTH" ? "bg-amber-100 border-[#1A1A1A] font-black" : "bg-white border-transparent text-gray-500 hover:text-gray-950"}`}
            >
              📈 CRESCIMENTO
            </button>
            <button
              onClick={() => applyMaturityPreset("MATURE")}
              className={`p-1.5 px-3 text-[9px] font-mono font-bold tracking-wider border-2 ${selectedMaturity === "MATURE" ? "bg-amber-100 border-[#1A1A1A] font-black" : "bg-white border-transparent text-gray-500 hover:text-gray-950"}`}
            >
              🏆 MADURA / CORPORATE
            </button>
          </div>
        </div>

        {/* Dynamic score summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-10 gap-4 pt-3 border-t border-dashed border-[#1A1A1A]/10">
          
          <div className="lg:col-span-3 bg-white border border-[#1A1A1A]/15 p-3 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono font-extrabold text-[#C49746] block uppercase">🔋 EFICIÊNCIA DO CONTRATO</span>
              <p className="text-[9.5px] text-gray-500 mt-0.5 leading-snug">Metodologias focadas em fazer as coisas da forma correta: sem desperdício e com máxima rapidez.</p>
            </div>
            <div className="mt-2.5 space-y-1">
              <div className="flex justify-between font-mono text-xs font-bold text-gray-800 pb-0.5">
                <span>Score Estéreo Estocástico:</span>
                <span>{eficienciaScore}%</span>
              </div>
              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden border border-gray-200">
                <div className="h-full bg-[#C49746]" style={{ width: `${eficienciaScore}%` }}></div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3 bg-white border border-[#1A1A1A]/15 p-3 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono font-extrabold text-indigo-700 block uppercase">🎯 EFICÁCIA DO CONTRATO</span>
              <p className="text-[9.5px] text-gray-500 mt-0.5 leading-snug">Metodologias focadas em escolher os caminhos corretos: gerar valor estratégico, metas e resultados.</p>
            </div>
            <div className="mt-2.5 space-y-1">
              <div className="flex justify-between font-mono text-xs font-bold text-gray-800 pb-0.5">
                <span>Score Estéreo Estocástico:</span>
                <span>{eficaciaScore}%</span>
              </div>
              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden border border-gray-200">
                <div className="h-full bg-indigo-600" style={{ width: `${eficaciaScore}%` }}></div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 bg-[#1A1A1A] text-white p-3 flex flex-col justify-between rounded-xs">
            <div>
              <div className="flex justify-between items-center pb-1 border-b border-white/10">
                <span className="text-[8.5px] font-mono font-bold tracking-widest text-amber-400">CLIENTE VINCULADO</span>
                <span className="text-[8px] bg-emerald-500 text-white font-bold px-1 rounded">ATIVO</span>
              </div>
              <input 
                type="text" 
                value={clientContractName}
                onChange={(e) => setClientContractName(e.target.value)}
                className="w-full bg-transparent border-none text-[11px] font-bold text-white mt-1.5 focus:outline-none focus:ring-1 focus:ring-amber-400 p-0.5"
                placeholder="Nome do Contrato Corporativo..."
              />
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-[9px] font-mono text-white/50">{enabledIds.length} Metodologias Liberadas</span>
              <button 
                onClick={() => setIsContractPrinted(true)}
                className="bg-amber-600 hover:bg-amber-700 text-white font-mono text-[8px] font-bold py-1 px-2.5 border border-amber-500 flex items-center gap-1 cursor-pointer transition-transform duration-100 hover:scale-105"
              >
                <Printer size={9} /> EMITIR PROPOSTA COMERCIAL
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* 📂 PAINEL DE EXECUÇÃO: METODOLOGIAS DE NEGÓCIO ATIVAS */}
      <div className="p-5 md:p-6 bg-slate-50 border-b-2 border-[#1A1A1A] space-y-4 rounded-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 bg-indigo-650 text-white font-mono text-[9px] font-black rounded-xs">
              SALA DE CONTROLE ATIVA ⚙️
            </span>
            <h5 className="font-serif font-black text-xs text-gray-900 uppercase tracking-tight">
              Módulos e Metodologias de Negócio Ativas no Contrato Geral
            </h5>
          </div>
          <span className="text-[10px] font-mono text-slate-500">
            {enabledItems.length === 0 ? "Nenhum módulo ativo" : `${enabledItems.length} Módulo(s) pronto(s) para execução`}
          </span>
        </div>

        {enabledItems.length === 0 ? (
          <div className="p-5 bg-white border-2 border-dashed border-gray-300 rounded-sm text-center text-slate-500 font-sans text-xs">
            <AlertTriangle className="mx-auto text-amber-500 mb-2 stroke-2" size={24} />
            Nenhuma metodologia ativa para a organização neste projeto. 
            <br />
            {canManageMethodology() ? (
              <span className="text-[10px] font-mono text-amber-700 font-bold block mt-1">
                👉 Selecione ou ative as metodologias no painel de marcação abaixo!
              </span>
            ) : (
              <span className="text-[10px] font-mono text-indigo-700 font-bold block mt-1">
                🔒 Solicite a liberação das metodologias ao Administrador / Dono do Processo via Área Administrativa de Organização.
              </span>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {enabledItems.map((item) => (
              <div 
                key={item.id} 
                className="bg-white border-2 border-[#1A1A1A] p-2.5 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] transition-all relative group"
              >
                <div className="absolute top-1.5 right-1.5 flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </div>

                <div className="space-y-1 text-left">
                  <span className="text-[7.5px] font-mono bg-slate-105 text-slate-500 px-1 py-0.2 rounded-2xs font-extrabold uppercase">
                    {item.category}
                  </span>
                  <strong className="block text-[10.5px] font-extrabold text-gray-950 font-sans tracking-tight leading-tight pt-1">
                    {item.name}
                  </strong>
                  <span className="block text-[8.5px] text-slate-500 font-sans leading-tight line-clamp-2">
                    {item.purpose}
                  </span>
                </div>

                <div className="pt-2.5 mt-2 border-t border-dashed border-slate-150">
                  {["swot", "okr", "fives", "pdca", "five_w_two_h"].includes(item.id) ? (
                    <button
                      onClick={() => setActiveToolId(item.id)}
                      className="w-full bg-indigo-650 hover:bg-slate-900 text-white font-mono text-[8px] font-bold py-1 px-1.5 rounded-xs tracking-wider uppercase text-center cursor-pointer transition-colors"
                    >
                      🚀 Executar Framework
                    </button>
                  ) : (
                    <button
                      onClick={() => alert(`O módulo "${item.name}" está ativo no escopo deste contrato. Para consultar suas normatizações, utilize o Guia LSS.`)}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-250 font-mono text-[8px] font-bold py-1 px-1.5 rounded-xs uppercase text-center cursor-pointer"
                    >
                      📖 Ver Diretrizes
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12">
        
        {/* Left Interactive Checklist Column (Módulo de Permissionamento) */}
        <div className="lg:col-span-8 p-5 md:p-6 space-y-6">
          
          {/* Filter / Search header in checklist */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-100 pb-4">
            <div>
              <h5 className="font-serif font-black text-base text-gray-900">Módulos Integrados de Negócios</h5>
              <p className="text-[10.5px] text-gray-500">
                Ligue ou desligue as metodologias do contrato. Clientes com planos limitados terão acesso restrito.
              </p>
            </div>
            <input
              type="text"
              placeholder="Pesquisar por metodologia ou área..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full md:w-64 bg-gray-50 border-2 border-[#1A1A1A] text-xs p-1.5 px-3 focus:outline-none"
            />
          </div>

          {/* Grid of methodologies organized clearly */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[500px] overflow-y-auto pr-2">
            {filteredItems.map((item) => {
              const isActive = enabledIds.includes(item.id);
              return (
                <div 
                  key={item.id} 
                  onClick={() => toggleMethodology(item.id)}
                  className={`border-2 p-3 cursor-pointer select-none transition-all flex flex-col justify-between ${
                    isActive 
                      ? "border-amber-500 bg-amber-50/20 shadow-[2px_2px_0px_0px_rgba(217,119,6,1)]" 
                      : "border-gray-200 bg-white hover:border-gray-400"
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[8px] uppercase tracking-wider font-mono font-bold text-gray-400">{item.category}</span>
                      <span className={`text-[8px] font-bold px-1 rounded-sm uppercase ${
                        item.type === "eficacia" ? "bg-indigo-50 text-indigo-700 border border-indigo-100" : "bg-amber-50 text-amber-800 border border-amber-100"
                      }`}>
                        {item.type === "eficacia" ? "🎯 Erigir Eficácia" : "🔋 Sanar Eficiência"}
                      </span>
                    </div>

                    <h6 className="font-sans font-extrabold text-[11px] text-gray-950 flex items-center gap-1.5">
                      {isActive ? (
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                      ) : (
                        <span className="w-1.5 h-1.5 bg-gray-300 rounded-full"></span>
                      )}
                      {item.name}
                    </h6>
                    <p className="text-[10.5px] text-gray-600 font-sans leading-tight leading-snug">{item.purpose}</p>
                  </div>

                  <div className="pt-2 mt-2 border-t border-dashed border-gray-100 flex items-center justify-between text-[8px] font-mono font-bold">
                    <span className="text-gray-400">Relevância: {item.type === "eficacia" ? `Eficácia P=${item.weightEc}` : `Eficiência P=${item.weightEf}`}</span>
                    {isActive ? (
                      <span className="text-emerald-700 bg-emerald-50 px-1 py-0.2 rounded-xs border border-emerald-200">
                        Liberado no Contrato ✔️
                      </span>
                    ) : (
                      <span className="text-gray-400 hover:text-red-700">
                        Bloqueado / Upgrade necessário 🔒
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick recommendations alerts mapping maturity to business status */}
          <div className="bg-gray-50 border border-gray-200 p-4 space-y-3">
            <h6 className="font-serif font-black text-xs text-gray-900 flex items-center gap-1.5">
              <Info size={13} className="text-indigo-600" />
              Recomendação e Maturidade do Portfólio de Contratos
            </h6>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-sans leading-tight">
              <div className="bg-white p-2.5 border border-gray-150 rounded-xs">
                <span className="font-bold text-[#B15309] block mb-1">🌱 Para Empresas Iniciais:</span>
                Foque no essencial: ter direção, saber se sobra caixa e organizar a rotina de trabalho.
                <span className="block mt-1 font-mono text-[9px] text-[#B15309] font-bold">10 Metodologias sugeridas</span>
              </div>
              <div className="bg-white p-2.5 border border-gray-150 rounded-xs">
                <span className="font-bold text-indigo-700 block mb-1">📈 Para Empresas em Crescimento:</span>
                Foque em expandir integrando metas descentralizadas, processos ponta a ponta e automações básicas.
                <span className="block mt-1 font-mono text-[9px] text-indigo-700 font-bold">10 Metodologias sugeridas</span>
              </div>
              <div className="bg-white p-2.5 border border-gray-150 rounded-xs">
                <span className="font-bold text-emerald-700 block mb-1">🏆 Para Empresas Maduras:</span>
                Foque em liderança global, robustez e auditoria geral para escalar com saúde.
                <span className="block mt-1 font-mono text-[9px] text-emerald-700 font-bold">10 Metodologias sugeridas</span>
              </div>
            </div>
          </div>

        </div>

        {/* Right Sidebar: 10 Pillars Executive Score & Interactive Checklist */}
        <div className="lg:col-span-4 border-t-2 lg:border-t-0 lg:border-l-2 border-[#1A1A1A] p-5 md:p-6 bg-[#FAF9F6] space-y-6">
          
          {/* Executive Pillars Checklist header */}
          <div>
            <span className="text-[8px] font-bold bg-[#1A1A1A] text-white px-1.5 py-0.5 rounded-sm font-mono tracking-widest uppercase inline-block mb-1">
              Os 10 Pilares Corporativos
            </span>
            <h5 className="font-serif font-black text-sm text-gray-900">Roteiro Diagnóstico Executivo</h5>
            <p className="text-[10px] text-gray-500 leading-snug">
              Responda as perguntas críticas abaixo para avaliar se o cliente está negligenciando competências em algum pilar:
            </p>
          </div>

          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {PILLARS_QUESTIONS.map((q) => {
              const isChecked = answers[q.id];
              return (
                <div 
                  key={q.id}
                  onClick={() => handleToggleAnswer(q.id)}
                  className={`p-3 border transition-all cursor-pointer ${
                    isChecked 
                      ? "bg-emerald-50/40 border-emerald-500/50 hover:bg-emerald-50/60" 
                      : "bg-white border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 text-left">
                      <span className={`text-[8px] font-bold font-mono px-1 rounded-sm ${isChecked ? "bg-emerald-100 text-emerald-800" : "bg-gray-100 text-gray-500"}`}>
                        Pilar: {q.pilar}
                      </span>
                      <p className="text-[10.5px] leading-tight text-gray-900 font-sans tracking-normal">{q.label}</p>
                    </div>

                    <div className="pt-0.5">
                      {isChecked ? (
                        <div className="bg-emerald-500 text-white p-0.5 rounded-sm">
                          <Check size={12} className="stroke-3" />
                        </div>
                      ) : (
                        <div className="bg-gray-100 text-gray-400 p-0.5 rounded-sm border border-gray-200">
                          <X size={12} />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Diagnostic Insights of Pillars */}
          <div className="bg-indigo-50 border border-indigo-200 p-4 space-y-2 text-xs">
            <span className="font-mono font-bold text-indigo-700 uppercase tracking-wider text-[9px] block">Insight Gerencial dos Pilares</span>
            <div className="font-sans leading-relaxed text-gray-700">
              {Object.values(answers).filter(Boolean).length === 10 ? (
                <span>🎉 Excelente! O cliente informou conformidade em todos os pilares empresariais primários.</span>
              ) : Object.values(answers).filter(Boolean).length > 5 ? (
                <span>👍 Nível intermediário de governança. Sugerimos implantar rituais estruturados de melhoria Lean Six Sigma nos pilares que falharam.</span>
              ) : (
                <span>⚠️ Alerta de Vulnerabilidade: Alta dependência de percepção em vez de evidências. Libere urgentemente metodologias de <strong>Gestão por Processos (BPM, SIPOC)</strong> e <strong>Gestão de Indicadores</strong>.</span>
              )}
            </div>
          </div>

        </div>

      </div>

      {renderInteractiveToolModal()}

      {/* POPUP / MODAL: EMISSÃO DE PROPOSTA COMERCIAL DE CONTRATO */}
      {isContractPrinted && (
        <div className="fixed inset-0 bg-[#1A1A1A]/80 flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white border-4 border-[#1A1A1A] max-w-2xl w-full p-6 text-left space-y-4 shadow-[8px_8px_0px_0px_rgba(251,191,36,1)] max-h-[90vh] overflow-y-auto">
            
            <div className="flex justify-between items-start border-b-2 border-[#1A1A1A] pb-3">
              <div>
                <span className="text-[8px] font-mono font-black tracking-widest bg-amber-100 text-amber-900 px-1.5 py-0.5 uppercase">
                  AI STUDIO LIVE COMPLIANCE
                </span>
                <h4 className="font-serif text-lg font-black text-gray-900 mt-1">Dossiê e Carta de Contratação de Serviços de Negócios</h4>
              </div>
              <button 
                onClick={() => setIsContractPrinted(false)}
                className="bg-gray-100 hover:bg-gray-200 border-2 border-[#1A1A1A] p-1 font-bold inline-block text-xs"
              >
                FECHAR ×
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-gray-800 font-sans leading-relaxed">
              <div>
                <span className="text-[9px] font-mono text-gray-400 block uppercase">CLIENTE LICENCIADO</span>
                <strong className="text-gray-950 text-sm">{clientContractName}</strong>
              </div>

              <div>
                <span className="text-[9px] font-mono text-gray-400 block uppercase">CONTEÚDO DO CONTRATO</span>
                <p className="mt-1">
                  Este documento certifica a liberação e o licenciamento específico de <strong>{enabledIds.length} módulos e metodologias executivas</strong> para aplicação no planejamento corporativo e simulação estocástica:
                </p>
              </div>

              {/* List of active methodologies inside printed proposal */}
              <div className="bg-gray-50 border border-gray-250 p-3 rounded-xs max-h-[180px] overflow-y-auto font-mono text-[10.5px] space-y-1">
                {enabledItems.map((st, i) => (
                  <div key={st.id} className="flex justify-between border-b border-gray-100 pb-1">
                    <span className="text-gray-900 font-bold">{i+1}. {st.name}</span>
                    <span className="text-amber-800 uppercase text-[9px]">[{st.category}]</span>
                  </div>
                ))}
              </div>

              <div className="bg-indigo-50/50 p-3.5 border-l-4 border-indigo-500 font-serif italic text-xs leading-relaxed text-indigo-950">
                &ldquo;Uma empresa eficiente e eficaz sabe exatamente quando ligar as chaves de sua governança. O valor residual de um processo excelente está no rigor técnico de sua execução.&rdquo;
              </div>

              <div className="grid grid-cols-2 gap-4 text-center font-serif text-[11px] pt-4 mt-2 border-t border-dashed border-gray-200">
                <div>
                  <div className="border-b border-gray-400 pb-1 font-bold text-gray-950">{clientContractName}</div>
                  <span className="text-[9px] font-mono text-gray-500 block uppercase mt-0.5">Assinatura do Cliente Autorizado</span>
                </div>
                <div>
                  <div className="border-b border-gray-400 pb-1 font-bold text-indigo-900">M.A. Consulting &amp; BPM Corp.</div>
                  <span className="text-[9px] font-mono text-gray-500 block uppercase mt-0.5">Marco, Master Black Belt &amp; Auditor LSS</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-4 border-t border-[#1A1A1A] mt-2">
              <button 
                onClick={() => window.print()} 
                className="bg-[#1A1A1A] text-white hover:bg-black font-mono text-[9px] font-bold py-1.5 px-3 border border-[#1A1A1A] flex items-center gap-1 cursor-pointer"
              >
                Imprimir Documentação
              </button>
              <button 
                onClick={() => setIsContractPrinted(false)} 
                className="bg-amber-500 text-white hover:bg-amber-600 font-mono text-[9px] font-bold py-1.5 px-3 border border-amber-600 flex items-center gap-1 cursor-pointer"
              >
                Homologar e Fechar Contrato ✔️
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
