import React from "react";
import { ProcessStep } from "../types";
import { ShieldAlert, CheckCircle2, AlertTriangle, Sparkles } from "lucide-react";

interface AuditSuggestionProps {
  steps: ProcessStep[];
  stats: any;
}

export default function AuditSuggestion({ steps, stats }: AuditSuggestionProps) {
  const bottlenecks = steps.filter(s => s.name === stats.bottleneckStepName);
  const slaThreshold = 20; // 20 minutes SLA trigger threshold

  return (
    <div className="border border-slate-200 p-5 bg-white shadow-3xs rounded-xl text-left space-y-4">
      <h3 className="font-serif font-black text-slate-900 uppercase text-xs border-b pb-1.5 flex items-center gap-1.5">
        <Sparkles size={13} className="text-[#C49746]" />
        <span>Gere Alerta por IA de Risco</span>
      </h3>

      <div className="space-y-4">
        {/* Bottleneck Risk Indicator */}
        {bottlenecks.length > 0 && (
          <div className="bg-red-50/50 border-l-2 border-red-500 p-3 rounded text-[11px] text-red-900 leading-relaxed space-y-1">
            <span className="font-extrabold flex items-center gap-1 uppercase">
              <ShieldAlert size={12} className="text-red-650" /> Gargalo Detectado
            </span>
            <p>
              O posto <strong>"{bottlenecks[0].name}"</strong> é a maior restrição física acumuladora, provocando saturação e filas sob taxa de chegada atual.
            </p>
          </div>
        )}

        {/* Quality Yield risks */}
        {steps.some(s => s.yieldRate < 0.95) && (
          <div className="bg-amber-50/50 border-l-2 border-amber-500 p-3 rounded text-[11px] text-amber-900 leading-relaxed space-y-1">
            <span className="font-extrabold flex items-center gap-1 uppercase">
              <AlertTriangle size={12} className="text-amber-650" /> Risco de Descarte Alto
            </span>
            <p>
              Estações operacionais apresentam fator de refugo em primeira passagem (Yield) abaixo de 95%, sinalizando vulnerabilidade a variabilidade crônica.
            </p>
          </div>
        )}

        {/* Compliant status */}
        {!steps.some(s => s.yieldRate < 0.95) && bottlenecks.length === 0 && (
          <div className="bg-emerald-50/60 border-l-2 border-emerald-550 p-3 rounded text-[11px] text-emerald-990 leading-relaxed space-y-1">
            <span className="font-extrabold flex items-center gap-1 uppercase text-emerald-850">
              <CheckCircle2 size={12} className="text-emerald-650" /> Fluxo Estabilizado
            </span>
            <p>
              Nenhuma violação grave ostentada. Os postos operam com capacidade bem-balanceada frente às forças do mercado.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
