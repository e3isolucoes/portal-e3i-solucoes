import React, { useState } from "react";
import { 
  ArrowRight,
  Sparkles,
  Layers,
  Cpu,
  CheckCircle2,
  HelpCircle,
  Clock,
  ShieldCheck,
  AlertCircle,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
  FileText,
  BadgeAlert,
  Sliders,
  Maximize2
} from "lucide-react";

interface E3IDeliveryBlueprintProps {
  onSuggestAction?: (actionName: string) => void;
}

export default function E3IDeliveryBlueprint({ onSuggestAction }: E3IDeliveryBlueprintProps) {
  const [selectedPhase, setSelectedPhase] = useState<number | null>(null);

  const phases = [
    {
      id: 1,
      title: "1. Entrada",
      type: "input",
      badgeColor: "bg-blue-600",
      textColor: "text-blue-600",
      bulletIcon: "🔵",
      points: [
        { label: "ZIP do projeto E3I", desc: "Estrutura do código-fonte e bancos de dados mapeados." },
        { label: "Prompt de refatoração", desc: "Instruções inteligentes de otimização contínua." },
        { label: "Regras de usabilidade", desc: "UI limpa, sem poluição de logs técnicos ou lixo visual." },
        { label: "Perfis: leigo e especialista", desc: "Separação de canais de engajamento do usuário de acordo com maturidade." }
      ],
      details: "Define os pontos de inserção e requisitos iniciais da corporação de maneira fluida e automatizada."
    },
    {
      id: 2,
      title: "2. Diagnóstico",
      type: "step",
      badgeColor: "bg-indigo-900",
      textColor: "text-indigo-900",
      bulletIcon: "⚡",
      desc: "Mapear arquitetura atual, telas, componentes, permissões, gargalos de UX e inconsistências técnicas.",
      points: [
        { label: "Arquitetura atual", desc: "Identificação dos componentes e acoplamento do sistema." },
        { label: "Mapeamento de permissões", desc: "Controles de segurança entre leigos, especialistas e gestores." },
        { label: "Gargalos de UX", desc: "Campos desnecessários, tempos de processamento altos e fricção." }
      ],
      details: "A IA entra analisando processos descritos para encontrar erros comuns, desvios e potenciais gargalos."
    },
    {
      id: 3,
      title: "3. Arquitetura UX",
      type: "step",
      badgeColor: "bg-purple-700",
      textColor: "text-purple-700",
      bulletIcon: "🎨",
      desc: "Criar uma jornada única: Início, Clientes, Diagnóstico, Processos, Melhorias, Operação, Resultados e Administração.",
      points: [
        { label: "Jornada Unificada", desc: "Redução de tabs desnecessárias e fluxos concorrentes." },
        { label: "Sincronização do Projeto", desc: "Mapeadores fáceis em sincronia real com o repositório de dados." },
        { label: "Dashboard e BI", desc: "Telas de simples compreensão que traduzem dados em decisões." }
      ],
      details: "Centraliza e simplifica o fluxo de uso da plataforma dividindo o espaço entre tomada de decisão rápida e controle especialista."
    },
    {
      id: 4,
      title: "4. Refatoração",
      type: "step",
      badgeColor: "bg-amber-600",
      textColor: "text-amber-600",
      bulletIcon: "⚙️",
      desc: "Padronizar modos de uso, quebrar componentes gigantes, substituir alertas e organizar features por domínio.",
      points: [
        { label: "Modularização", desc: "Substituição de arquivos gigantes por blocos de alta coesão e baixo acoplamento." },
        { label: "Eliminação de Alertas", desc: "Substituição de 'window.alert' nativos por toasts de alta usabilidade." },
        { label: "Limpeza de Logs", desc: "Remoção de logs lixo nos cantos de página e cabeçalhos de tela para visual profissional." }
      ],
      details: "Ação direta no código do produto para aumentar a confiabilidade de compilação, diminuindo o débito técnico."
    },
    {
      id: 5,
      title: "5. Validação",
      type: "step",
      badgeColor: "bg-emerald-600",
      textColor: "text-emerald-600",
      bulletIcon: "🔬",
      desc: "Executar build, revisar permissões, testar fluxos por perfil e validar critérios de aceite da experiência.",
      points: [
        { label: "Build Suite", desc: "Validação rigorosa de compilação livre de erros de tipos ou dependências." },
        { label: "Teste de Fluxos", desc: "Simulação de uso de ponta a ponta na visão do Cliente Leigo vs. Consultor." },
        { label: "Critérios de Aceite", desc: "Nenhum usuário travado por falta de feedbacks visuais ou erros de backend." }
      ],
      details: "Check-point rigoroso que assegura estabilidade antes de qualquer publicação ou compartilhamento final."
    },
    {
      id: 6,
      title: "6. Saída Final",
      type: "output",
      badgeColor: "bg-green-600",
      textColor: "text-green-600",
      bulletIcon: "🟢",
      points: [
        { label: "Aplicação compilando", desc: "Zero vazamentos ou quebras de tipos TypeScript em produção." },
        { label: "Fluxos claros", desc: "Direções explícitas de ações que mantêm o usuário livre de confusão técnica." },
        { label: "UX comercial", desc: "Padrão SaaS comercial de ponta a ponta, focado na persuasão e facilidade de venda." },
        { label: "Código modular", desc: "Separação limpa, permitindo manutenção acelerada por engenheiros." },
        { label: "Testes validados", desc: "Regras de negócios verificadas com máxima segurança na nuvem." }
      ],
      details: "Entrega um sistema pronto para o deploy seguro em Cloud Run, polido, lucrativo e fácil de escalar."
    }
  ];

  return (
    <div id="e3i-delivery-blueprint-panel" className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-8 text-left transition-all">
      
      {/* 1. Header estilo Barra Azul da imagem */}
      <div className="bg-[#0b1f4c] text-white p-6 rounded border border-blue-900 shadow-inner relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 transform translate-x-12 -translate-y-6 pointer-events-none">
          <Layers size={240} className="text-white" />
        </div>
        <div className="relative z-10 space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="bg-[#C49746] text-white font-mono font-extrabold text-[9.5px] uppercase tracking-wider px-2 py-0.5 rounded shadow-sm">
              MÉTODO E3I + AI STUDIO
            </span>
            <span className="text-[10px] text-blue-200 uppercase font-mono tracking-wider">• Blueprint de Evolução Contínua</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-black tracking-tight leading-tight uppercase text-amber-50">
            Como o Google AI Studio deve entregar a ferramenta E3I
          </h2>
          <p className="text-xs md:text-sm text-slate-350 font-sans max-w-4xl font-medium leading-relaxed">
            Entrega esperada: produto <span className="text-[#C49746] font-bold">SaaS B2B guiado, comercial, simples para leigos e profundo para especialistas</span>.
          </p>
        </div>
      </div>

      {/* 2. O Diagrama de Fluxo de 6 Etapas */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-gray-200 pb-2">
          <h4 className="text-xs uppercase font-mono font-bold tracking-wider text-slate-700 flex items-center gap-1.5">
            <Cpu size={14} className="text-indigo-600" />
            Diagrama do Pipeline de Desenvolvimento e Validação
          </h4>
          <span className="text-[9.5px] font-mono text-gray-500 bg-gray-100 px-2.5 py-0.5 rounded-full">
            💡 Dica: Clique nos cards para abrir o painel de verificação
          </span>
        </div>

        {/* Desktop Pipeline Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          
          {/* Card 1: Entrada */}
          <div 
            onClick={() => setSelectedPhase(selectedPhase === 1 ? null : 1)}
            className={`lg:col-span-4 border-2 p-4 cursor-pointer transition-all flex flex-col justify-between ${
              selectedPhase === 1 
                ? "border-blue-600 bg-blue-50/40 shadow-[4px_4px_0px_0px_rgba(37,99,235,1)]" 
                : "border-[#1A1A1A] bg-[#FEFDFB] hover:bg-slate-50 hover:shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
            }`}
          >
            <div>
              <span className="font-mono text-xs font-bold text-blue-600 uppercase tracking-widest block mb-1">
                📥 Canal de Entrada
              </span>
              <h3 className="font-serif font-black text-lg text-slate-900 border-b pb-1 mb-2">
                1. Entrada
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {phases[0].points.map((p, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-blue-500 text-xs mt-0.5">{phases[0].bulletIcon}</span>
                    <span className="font-medium">{p.label}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="text-[10px] font-mono text-blue-600 mt-4 font-bold flex items-center gap-1">
              Ver mais detalhes <ChevronRight size={12} />
            </div>
          </div>

          {/* Center Engine Arrow / Indicator */}
          <div className="lg:col-span-4 flex flex-col justify-center items-center bg-slate-50 border-2 border-dashed border-gray-300 p-4 rounded text-center">
            <div className="bg-blue-600 text-white font-mono font-bold text-[10.5px] uppercase tracking-widest px-3 py-1 border-2 border-black rounded shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              GOOGLE AI STUDIO
            </div>
            <p className="text-[11px] font-sans text-gray-500 font-bold mt-2">
              Arquiteto + UX + Dev + Tester
            </p>
            <div className="flex items-center gap-2 mt-3 text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-ping"></span>
              <ArrowRight size={18} className="text-indigo-600 animate-pulse" />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
            </div>
          </div>

          {/* Card 6: Saída Final */}
          <div 
            onClick={() => setSelectedPhase(selectedPhase === 6 ? null : 6)}
            className={`lg:col-span-4 border-2 p-4 cursor-pointer transition-all flex flex-col justify-between ${
              selectedPhase === 6 
                ? "border-green-600 bg-green-50/40 shadow-[4px_4px_0px_0px_rgba(22,163,74,1)]" 
                : "border-[#1A1A1A] bg-[#FEFDFB] hover:bg-slate-50 hover:shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
            }`}
          >
            <div>
              <span className="font-mono text-xs font-bold text-green-600 uppercase tracking-widest block mb-1">
                📤 Canal de Saída
              </span>
              <h3 className="font-serif font-black text-lg text-slate-900 border-b pb-1 mb-2">
                6. Saída Final
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {phases[5].points.map((p, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-green-600 text-xs mt-0.5">{phases[5].bulletIcon}</span>
                    <span className="font-medium">{p.label}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="text-[10px] font-mono text-green-600 mt-4 font-bold flex items-center gap-1">
              Ver mais detalhes <ChevronRight size={12} />
            </div>
          </div>

          {/* Sequential Row of Workflow beneath */}
          <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-4 gap-3 mt-3">
            {phases.slice(1, 5).map((phase) => (
              <div
                key={phase.id}
                onClick={() => setSelectedPhase(selectedPhase === phase.id ? null : phase.id)}
                className={`border-2 p-4 cursor-pointer transition-all text-left flex flex-col justify-between ${
                  selectedPhase === phase.id
                    ? `border-indigo-600 bg-indigo-50/30 shadow-[4px_4px_0px_0px_rgba(79,70,229,1)]`
                    : "border-[#1A1A1A] bg-white hover:bg-indigo-50/10 hover:shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-mono font-black text-white ${phase.badgeColor}`}>
                      {phase.id}
                    </span>
                    <span className={`text-xs font-mono font-black uppercase ${phase.textColor}`}>
                      {phase.title.split(". ")[1]}
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-650 leading-relaxed font-sans">
                    {phase.desc}
                  </p>
                </div>
                <div className={`text-[9px] font-mono uppercase mt-3 font-extrabold flex items-center gap-1 ${phase.textColor}`}>
                  Explorar <ChevronRight size={10} />
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Interactive breakdown panel of selected phase */}
        {selectedPhase !== null && (
          <div className="bg-slate-50 border-2 border-indigo-950 p-5 rounded-sm shadow-inner text-left space-y-3 relative transition-all animate-fadeIn">
            <div className="flex items-center justify-between border-b border-gray-300 pb-2">
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 text-white font-mono text-[9.5px] uppercase font-bold rounded ${phases[selectedPhase - 1].badgeColor}`}>
                  Fase {selectedPhase} Ativa
                </span>
                <h4 className="font-serif font-black text-base text-gray-950">
                  {phases[selectedPhase - 1].title} — Detalhamento Operacional
                </h4>
              </div>
              <button 
                onClick={() => setSelectedPhase(null)}
                className="text-gray-400 hover:text-gray-900 font-mono text-[10.5px] font-black uppercase px-2 py-0.5 border border-gray-300 rounded cursor-pointer hover:bg-gray-100"
              >
                Fechar ✕
              </button>
            </div>
            <p className="text-xs text-gray-700 italic bg-white p-2.5 border-l-4 border-indigo-500 leading-relaxed font-sans">
              &quot;{phases[selectedPhase - 1].details}&quot;
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
              {phases[selectedPhase - 1].points.map((pt: any, idx: number) => (
                <div key={idx} className="bg-white p-3 border border-gray-300 rounded shadow-3xs">
                  <span className="font-mono text-xs font-extrabold text-indigo-900 flex items-center gap-1">
                    🎯 {pt.label}
                  </span>
                  <p className="text-[10.5px] text-gray-600 mt-1 font-sans leading-tight">
                    {pt.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 3. Dois Modos Comparativos da Imagem */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        
        {/* Modo Simples */}
        <div className="border-2 border-[#1A1A1A] p-6 bg-[#FCFAF8] shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] rounded relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b pb-3 mb-4">
              <div>
                <span className="text-[9.5px] font-mono font-bold text-amber-700 uppercase bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-sm">
                  Perfil de Operação A
                </span>
                <h3 className="font-serif font-black text-xl text-amber-950 mt-1 uppercase tracking-tight">
                  Modo Simples — Cliente leigo
                </h3>
              </div>
              <span className="text-2xl">🌱</span>
            </div>
            
            <div className="bg-amber-50/50 p-3 border-l-2 border-amber-500 text-xs text-amber-900 font-medium mb-4 italic rounded-r font-sans leading-tight">
              <strong>Objetivo:</strong> Fazer o usuário avançar de maneira intuitiva sem a necessidade de conhecer ou estudar metodologia técnica.
            </div>

            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-blue-100 text-blue-900 flex items-center justify-center text-[10px] font-black font-mono">✓</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Perguntas guiadas</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">O que quer melhorar no negócio?</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-blue-100 text-blue-900 flex items-center justify-center text-[10px] font-black font-mono">✓</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Linguagem clara</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Gargalo = etapa que segura o fluxo.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-blue-100 text-blue-900 flex items-center justify-center text-[10px] font-black font-mono">✓</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Próxima ação</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Sempre indicar o que fazer agora de forma assertiva.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-blue-100 text-blue-900 flex items-center justify-center text-[10px] font-black font-mono">✓</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Relatório executivo</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Antes x depois, ganhos econômicos e tomada de decisão.</span>
                </div>
              </li>
            </ul>
          </div>
          
          <div className="pt-6 mt-6 border-t border-gray-200">
            <span className="text-[9.5px] font-mono text-amber-800 leading-tight block">
              💡 <strong>Integrado ao Co-Piloto:</strong> Reduz a barreira técnica para que gestores de PMEs façam otimizações de processo.
            </span>
          </div>
        </div>

        {/* Modo Especialista */}
        <div className="border-2 border-[#1A1A1A] p-6 bg-[#FAF9F5] shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] rounded relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b pb-3 mb-4">
              <div>
                <span className="text-[9.5px] font-mono font-bold text-indigo-700 uppercase bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-sm">
                  Perfil de Operação B
                </span>
                <h3 className="font-serif font-black text-xl text-indigo-950 mt-1 uppercase tracking-tight">
                  Modo Especialista — Consultor / Black Belt
                </h3>
              </div>
              <span className="text-2xl">🎓</span>
            </div>
            
            <div className="bg-indigo-50 p-3 border-l-2 border-indigo-600 text-xs text-indigo-900 font-medium mb-4 italic rounded-r font-sans leading-tight">
              <strong>Objetivo:</strong> Preservar profunda metodologia técnica, governança analítica rigorosa, auditoria e parametrização avançada.
            </div>

            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-indigo-950 text-indigo-200 flex items-center justify-center text-[10px] font-black font-mono">◆</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Parâmetros técnicos</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">BPMN, DMAIC, CTQ (Críticos de Qualidade), SIPOC, FMEA.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-indigo-950 text-indigo-200 flex items-center justify-center text-[10px] font-black font-mono">◆</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Simulações operacionais</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Filas, tempo de ciclo estocástico, capacidade e variabilidade de desvios.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-indigo-950 text-indigo-200 flex items-center justify-center text-[10px] font-black font-mono">◆</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Auditoria complexa</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Histórico de mudanças, evidências em anexo, trilhas e critérios de aceite.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded bg-indigo-950 text-indigo-200 flex items-center justify-center text-[10px] font-black font-mono">◆</span>
                <div className="text-left">
                  <strong className="text-xs font-mono text-gray-950 uppercase block">Relatório técnico</strong>
                  <span className="text-[11px] text-gray-600 font-sans italic leading-tight">Fórmulas estatísticas estruturadas, premissas de capacidade, ROI e validação de desvios.</span>
                </div>
              </li>
            </ul>
          </div>

          <div className="pt-6 mt-6 border-t border-gray-200">
            <span className="text-[9.5px] font-mono text-indigo-800 leading-tight block">
              💡 <strong>Controle de Governança:</strong> Permite auditorias e relatórios de conformidade DMAIC robustos para grandes corporações.
            </span>
          </div>
        </div>

      </div>

      {/* 4. Regra de Ouro (Golden Rule) estilo Pod Escuro da Imagem */}
      <div className="bg-[#111827] text-[#FAF9F5] p-5 rounded-lg border-2 border-slate-700 shadow-2xl relative overflow-hidden text-center max-w-4xl mx-auto my-4 transition-all">
        <div className="absolute left-0 right-0 top-0 bottom-0 bg-radial-at-t from-[#1d4ed8]/20 via-[#111827] to-[#111827] opacity-60 pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-center gap-3">
          <span className="text-xl md:text-2xl animate-bounce">🏆</span>
          <p className="text-sm md:text-base font-serif font-black tracking-wide uppercase leading-snug">
            Regra de ouro: o sistema não pergunta <span className="text-[#C49746] underline decoration-wavy underline-offset-4 font-bold">&quot;qual ferramenta usar&quot;</span>; ele pergunta <span className="text-emerald-400 font-extrabold">&quot;o que você quer melhorar no negócio?&quot;</span>
          </p>
        </div>
      </div>

      {/* 5. Footer com legenda idêntica à imagem */}
      <div className="border-t border-gray-300 pt-4 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 font-sans gap-3">
        <span className="text-center sm:text-left leading-relaxed">
          📋 <strong>E3I Processos Inteligentes</strong> • Sistema de Governança LSS de Alta Precisão.
        </span>
        <span className="text-right font-mono font-bold text-[10px] text-indigo-800 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded inline-block">
          Blueprint visual para orientar a entrega do Google AI Studio na evolução da E3I Processos Inteligentes
        </span>
      </div>

    </div>
  );
}
