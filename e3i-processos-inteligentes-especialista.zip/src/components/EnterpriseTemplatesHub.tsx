import React, { useState } from "react";
import { 
  FileSpreadsheet, 
  Building2, 
  ShoppingCart, 
  Heart, 
  Truck, 
  Cpu, 
  Compass, 
  Sliders, 
  ChevronRight, 
  X, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Target, 
  Users, 
  ArrowRight,
  TrendingUp,
  FileText,
  Clock
} from "lucide-react";
import { SEGMENT_TEMPLATES, SegmentTemplate } from "../domain/templates/segmentTemplates";
import { useToast } from "../shared/ui/Toast";
import { ProcessStep, ProjectCharter, Sipoc } from "../types";
import { RaciItem } from "../domain/enterprise-architecture/raciEngine";

// Icon mapping helper
const iconMap: Record<string, React.ReactNode> = {
  FileSpreadsheet: <FileSpreadsheet className="w-5 h-5" />,
  Building2: <Building2 className="w-5 h-5" />,
  ShoppingCart: <ShoppingCart className="w-5 h-5" />,
  Heart: <Heart className="w-5 h-5" />,
  Truck: <Truck className="w-5 h-5" />,
  Cpu: <Cpu className="w-5 h-5" />,
  Compass: <Compass className="w-5 h-5" />,
  Sliders: <Sliders className="w-5 h-5" />
};

export interface EnterpriseTemplatesHubProps {
  onApplyTemplate: (
    steps: ProcessStep[],
    charter: ProjectCharter,
    sipoc: Sipoc,
    raci: RaciItem[],
    bizType: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "FINANCE" | "HUMAN_RESOURCES"
  ) => void;
  onClose?: () => void;
}

export default function EnterpriseTemplatesHub({ onApplyTemplate, onClose }: EnterpriseTemplatesHubProps) {
  const toast = useToast();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"PAINS" | "PROCESSES" | "RACI" | "METRICS" | "PLAN" | "RISKS">("PAINS");

  const templatesArray = Object.values(SEGMENT_TEMPLATES);
  const selectedTemplate = selectedId ? SEGMENT_TEMPLATES[selectedId] : null;

  const handleApply = (tpl: SegmentTemplate) => {
    // 1. Build Process Steps schema from Suggested Processes
    const processSteps: ProcessStep[] = [];
    let startX = 100;
    let startY = 180;

    // Use first suggested process as default visual process
    const defaultProc = tpl.suggestedProcesses[0];
    if (defaultProc) {
      defaultProc.steps.forEach((s, idx) => {
        const isStart = idx === 0;
        const isEnd = idx === defaultProc.steps.length - 1;
        const id = `tpl-step-${idx + 1}`;
        
        processSteps.push({
          id,
          name: s.name,
          resource: s.resource,
          resourceCount: 1,
          processingTime: s.processingTime,
          standardDeviation: Number((s.processingTime * 0.15).toFixed(1)),
          yieldRate: s.yieldRate,
          setupTime: 0,
          description: `Etapa recomendada para o segmento de ${tpl.name}.`,
          completed: false,
          requiredInputs: idx === 0 ? ["Demanda de Entrada"] : [`Saída da etapa ${idx}`],
          suppliers: idx === 0 ? ["Cliente"] : [defaultProc.steps[idx - 1].resource],
          outputs: [`Saída de ${s.name}`],
          customers: isEnd ? ["Cliente Final"] : [defaultProc.steps[idx + 1].resource],
          x: startX,
          y: startY,
          shapeType: isStart ? "START" : isEnd ? "END" : "ACTIVITY",
          nextStepId: isEnd ? undefined : `tpl-step-${idx + 2}`
        });

        startX += 170;
        // Make decision or zig-zag pattern
        if (idx % 2 === 1) {
          startY += 40;
        } else {
          startY -= 40;
        }
      });
    }

    // 2. Build Project Charter from Suggested Metrics & Name
    const targetMetric = tpl.suggestedMetrics[0];
    const newCharter: ProjectCharter = {
      title: `Otimização de ${tpl.name}`,
      problemStatement: `Presença recorrente das seguintes dores operacionais: ${tpl.pains[0]} e ${tpl.pains[1]}.`,
      goal: `Alcançar a meta de ${targetMetric ? targetMetric.name : "Vazão"} para ${targetMetric ? targetMetric.target : "99%"} em até 12 semanas.`,
      metric: "cycle_time",
      targetValue: tpl.suggestedProcesses[0]?.steps.reduce((sum, s) => sum + s.processingTime, 0) || 30
    };

    // 3. Build SIPOC schema from default process
    const newSipoc: Sipoc = {
      suppliers: "Clientes, Fornecedores e Área Administrativa",
      inputs: defaultProc ? defaultProc.steps[0].name : "Documentações e Solicitações de Clientes",
      processDescription: defaultProc ? defaultProc.description : `Fluxo de ponta a ponta para ${tpl.name}`,
      outputs: defaultProc ? defaultProc.steps[defaultProc.steps.length - 1].name : "Entrega do Serviço / Faturamento de Soluções",
      customers: "Clientes Atendidos e Organização Interna"
    };

    // 4. Build RACI list from Common Responsibilities
    const newRaci: RaciItem[] = [];
    let actIdx = 1;
    tpl.commonResponsibilities.forEach((r) => {
      r.activities.forEach((act) => {
        newRaci.push({
          id: `raci-tpl-${actIdx++}`,
          activityName: act.activityName,
          responsible: act.roleType === "R" ? [r.role] : [],
          accountable: act.roleType === "A" ? [r.role] : [],
          consulted: act.roleType === "C" ? [r.role] : [],
          informed: act.roleType === "I" ? [r.role] : [],
          criticality: "media"
        });
      });
    });

    // Handle fallbacks in RACI if too empty
    if (newRaci.length === 0 && defaultProc) {
      defaultProc.steps.forEach((s, idx) => {
        newRaci.push({
          id: `raci-tpl-${idx + 1}`,
          activityName: `Executar e validar: ${s.name}`,
          responsible: [s.resource],
          accountable: ["Gerente do Processo"],
          consulted: [],
          informed: [],
          criticality: "alta"
        });
      });
    }

    // Map segment id to active workspace business type
    let mappedType: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" = "SERVICES";
    if (tpl.id === "retail") mappedType = "RETAIL";
    if (tpl.id === "logistics") mappedType = "LOGISTICS";

    // Invoke action in App
    onApplyTemplate(processSteps, newCharter, newSipoc, newRaci, mappedType);
    toast.success(`Template para ${tpl.name} carregado com sucesso! Mapeador e Matriz RACI calibrados.`);
    if (onClose) onClose();
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs flex flex-col font-sans max-w-5xl mx-auto w-full text-left">
      {/* Header */}
      <div className="px-6 py-5 bg-slate-900 border-b border-slate-800 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500 text-slate-950 rounded-lg">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase font-mono tracking-wider">Modelos por Segmento de Atuação</h3>
            <p className="text-[11px] text-slate-300 font-mono tracking-wide mt-0.5">Selecione o segmento do seu cliente para obter diagnósticos, RACI e processos calibrados</p>
          </div>
        </div>
        {onClose && (
          <button 
            type="button" 
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors cursor-pointer p-1 rounded-full hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 min-h-[500px]">
        {/* Left Side: Template Selection */}
        <div className="md:col-span-5 border-r border-slate-200 bg-slate-50 p-4 space-y-2 max-h-[600px] overflow-y-auto">
          <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 font-mono block px-2 mb-2">Segmentos Disponíveis ({templatesArray.length})</span>
          {templatesArray.map((tpl) => {
            const isSelected = selectedId === tpl.id;
            return (
              <button
                key={tpl.id}
                type="button"
                onClick={() => {
                  setSelectedId(tpl.id);
                  setActiveTab("PAINS");
                }}
                className={`w-full text-left p-3.5 border transition-all rounded-lg flex items-start gap-3.5 cursor-pointer relative ${
                  isSelected 
                    ? "border-amber-600 bg-amber-50/55 shadow-xs" 
                    : "border-slate-200 bg-white hover:border-slate-350 hover:bg-slate-50"
                }`}
              >
                <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                  isSelected 
                    ? "bg-amber-600 text-white" 
                    : "bg-slate-100 text-slate-600"
                }`}>
                  {iconMap[tpl.icon] || <Sliders className="w-4 h-4" />}
                </div>
                <div className="flex-grow min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className={`text-xs font-bold leading-none ${isSelected ? "text-amber-950" : "text-slate-900"}`}>{tpl.name}</h4>
                    <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isSelected ? "rotate-90 text-amber-700" : "text-slate-400"}`} />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">{tpl.description}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Side: Details and Actions */}
        <div className="md:col-span-7 p-6 flex flex-col justify-between max-h-[600px] overflow-y-auto">
          {selectedTemplate ? (
            <div className="flex-grow flex flex-col justify-between h-full">
              <div>
                {/* Header detail */}
                <div className="flex items-start justify-between border-b border-slate-100 pb-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-900 text-white rounded-lg">
                      {iconMap[selectedTemplate.icon] || <Sliders className="w-5 h-5" />}
                    </div>
                    <div>
                      <h3 className="text-sm font-black uppercase text-slate-950 font-mono tracking-wider">{selectedTemplate.name}</h3>
                      <p className="text-[11px] text-slate-500 mt-0.5">Visão analítica e aceleradores táticos</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApply(selectedTemplate)}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white hover:text-white hover:shadow-xs transition-all text-xs font-bold rounded-lg cursor-pointer flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 shrink-0" />
                    Aplicar este Elemento
                  </button>
                </div>

                {/* Tab selectors */}
                <div className="flex items-center gap-1 border-b border-slate-150 mb-4 overflow-x-auto whitespace-nowrap">
                  {[
                    { id: "PAINS", label: "Dores Comuns" },
                    { id: "PROCESSES", label: "Processos e Tempos" },
                    { id: "RACI", label: "Responsabilidades" },
                    { id: "METRICS", label: "Indicadores (KPIs)" },
                    { id: "PLAN", label: "Plano Inicial" },
                    { id: "RISKS", label: "Riscos FMEA" }
                  ].map((tab) => {
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider font-extrabold border-b-2 transition-all cursor-pointer ${
                          isActive 
                            ? "border-amber-600 text-amber-700 font-bold" 
                            : "border-transparent text-slate-500 hover:text-slate-800"
                        }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* Tab Context content */}
                <div className="min-h-[220px]">
                  {activeTab === "PAINS" && (
                    <div className="space-y-4 animate-fade-in">
                      <p className="text-xs text-slate-650 leading-relaxed italic border-l-2 border-slate-250 pl-3">
                        "{selectedTemplate.description}"
                      </p>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block mb-2">Principais dores reportadas pelo cliente</span>
                        <div className="grid grid-cols-1 gap-2">
                          {selectedTemplate.pains.map((pain, i) => (
                            <div key={i} className="flex items-start gap-2.5 p-3 rounded-lg border border-red-100 bg-red-50/20 text-xs">
                              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                              <span className="font-semibold text-slate-800">{pain}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === "PROCESSES" && (
                    <div className="space-y-4 animate-fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block">Modelo de Fluxo de Processo Sugerido</span>
                      {selectedTemplate.suggestedProcesses.map((proc, idx) => (
                        <div key={idx} className="border border-slate-200 rounded-lg p-4 bg-white shadow-3xs space-y-3">
                          <div className="border-b border-slate-100 pb-2">
                            <h4 className="text-xs font-extrabold text-slate-900 font-mono uppercase tracking-wider">{proc.name}</h4>
                            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{proc.description}</p>
                          </div>
                          <div>
                            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 font-mono block mb-2">Etapas e Tempos de Execução</span>
                            <div className="space-y-1.5">
                              {proc.steps.map((st, i) => (
                                <div key={i} className="flex items-center justify-between text-xs p-2 bg-slate-50 border border-slate-100 rounded-sm">
                                  <div className="flex items-center gap-2">
                                    <span className="w-4 h-4 rounded-full bg-slate-250 text-slate-700 text-[10px] font-mono flex items-center justify-center font-black">{i + 1}</span>
                                    <span className="font-bold text-slate-800">{st.name}</span>
                                  </div>
                                  <div className="flex items-center gap-3 text-[10px] font-mono text-slate-500 shrink-0">
                                    <span className="bg-slate-200/60 px-1.5 py-0.5 rounded-xs flex items-center gap-1">
                                      <Users className="w-3 h-3 text-slate-400" /> {st.resource}
                                    </span>
                                    <span className="bg-amber-100/60 text-amber-900 px-1.5 py-0.5 rounded-xs flex items-center gap-1">
                                      <Clock className="w-3 h-3 text-amber-500" /> {st.processingTime} min
                                    </span>
                                    <span className="bg-emerald-100/60 text-emerald-900 px-1.5 py-0.5 rounded-xs">
                                      {Math.round(st.yieldRate * 100)}% acerto
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {activeTab === "RACI" && (
                    <div className="space-y-3 animate-fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block">Estrutura de Responsabilidades Comuns (RACI)</span>
                      <div className="border border-slate-200 rounded-lg overflow-hidden">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 font-mono font-bold text-slate-500 text-left">
                              <th className="p-2.5">Cargo / Perfil</th>
                              <th className="p-2.5">Atividade recomendada</th>
                              <th className="p-2.5 text-center">Relação</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white">
                            {selectedTemplate.commonResponsibilities.map((resp, i) => (
                              <React.Fragment key={i}>
                                {resp.activities.map((act, actI) => (
                                  <tr key={actI} className="hover:bg-slate-50/50">
                                    <td className="p-2.5 font-bold text-slate-800">{resp.role}</td>
                                    <td className="p-2.5 text-slate-650">{act.activityName}</td>
                                    <td className="p-2.5 text-center">
                                      <span className={`px-2 py-0.5 font-mono text-[10px] font-black rounded-sm tracking-wider uppercase border inline-block ${
                                        act.roleType === "R" ? "bg-[#e0f2fe] text-[#0369a1] border-[#bae6fd]" :
                                        act.roleType === "A" ? "bg-[#fef3c7] text-[#b45309] border-[#fde68a]" :
                                        act.roleType === "C" ? "bg-[#f3e8ff] text-[#6b21a8] border-[#e9d5ff]" :
                                        "bg-[#f1f5f9] text-[#475569] border-[#cbd5e1]"
                                      }`}>
                                        {act.roleType === "R" ? "Responsável" :
                                         act.roleType === "A" ? "Aprovador" :
                                         act.roleType === "C" ? "Consultado" : "Informado"}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                              </React.Fragment>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {activeTab === "METRICS" && (
                    <div className="space-y-3 animate-fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block">Indicadores Básicos de Desempenho (SLA/KPIs)</span>
                      <div className="grid grid-cols-1 gap-2.5">
                        {selectedTemplate.suggestedMetrics.map((met, i) => (
                          <div key={i} className="p-4 border border-slate-150 rounded-lg flex items-center justify-between bg-white shadow-3xs">
                            <div className="space-y-1">
                              <h5 className="text-xs font-bold text-slate-900">{met.name}</h5>
                              <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wide">Frequência: {met.frequency} • Unidade: {met.unit}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="text-xs font-mono font-black text-amber-700 bg-amber-50 px-2.5 py-1 rounded border border-amber-250">
                                Meta: {met.target}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === "PLAN" && (
                    <div className="space-y-4 animate-fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block">Plano de Implementação Inicial</span>
                      <div className="space-y-2.5">
                        {selectedTemplate.initialPlan.map((step, i) => (
                          <div key={i} className="flex items-start gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                            <span className="font-mono text-xs font-black text-amber-700 shrink-0 mt-0.5 bg-amber-50 rounded p-1 border border-amber-100">PASS {i + 1}</span>
                            <div className="space-y-1 flex-grow">
                              <h5 className="text-xs font-bold text-slate-900">{step.stepName}</h5>
                              <div className="text-[10px] text-slate-500 flex flex-wrap gap-x-3 gap-y-1">
                                <span><strong>Executor:</strong> {step.responsible}</span>
                                <span>• <strong>Duração:</strong> {step.duration}</span>
                                <span>• <strong>Entregável:</strong> {step.deliverable}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === "RISKS" && (
                    <div className="space-y-3 animate-fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono block">Análise Preliminar de Riscos (Modo FMEA)</span>
                      <div className="space-y-2.5">
                        {selectedTemplate.commonRisks.map((risk, i) => (
                          <div key={i} className="p-3.5 border border-slate-200 rounded-lg shadow-3xs bg-white space-y-2">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex items-start gap-2">
                                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                                <span className="text-xs font-extrabold text-slate-900">{risk.event}</span>
                              </div>
                              <div className="flex items-center gap-1 shrink-0 text-[9px] font-mono">
                                <span className="bg-red-50 text-red-700 px-1.5 py-0.5 rounded-sm">P: {risk.probability}</span>
                                <span className="bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded-sm">I: {risk.impact}</span>
                              </div>
                            </div>
                            <div className="text-[11px] text-slate-650 bg-slate-50 p-2 rounded-sm border border-slate-100 flex items-start gap-1">
                              <strong className="text-slate-800 shrink-0">Mitigação:</strong>
                              <span>{risk.mitigation}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Apply Bar */}
              <div className="border-t border-slate-100 pt-4 mt-6 flex items-center justify-between">
                <p className="text-[10px] text-slate-500 font-mono tracking-tight leading-normal max-w-sm">
                  *Ao aplicar este acelerador, os módulos de Diagnóstico, Processos, RACI e SIPOC serão reprogramados instantaneamente.
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleApply(selectedTemplate)}
                    className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all shadow-xs flex items-center gap-2 cursor-pointer"
                  >
                    Carregar no Workspace
                    <ArrowRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center text-slate-400 space-y-3">
              <Sparkles className="w-12 h-12 text-slate-350 stroke-1 animate-pulse" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-800">Selecione um segmento ao lado</h4>
                <p className="text-[11px] text-slate-500 max-w-xs mx-auto">Explore as dores, processos padrão e indicadores recomendados por tipo de negócio antes de carregar no workspace.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
