import React, { useState, useEffect } from "react";
import { 
  LayoutGrid, 
  Plus, 
  Trash2, 
  RefreshCw, 
  Sliders, 
  Clock, 
  ArrowUpRight, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  MoveRight,
  HelpCircle,
  Play,
  User,
  Sparkles,
  Tag,
  Kanban,
  Edit,
  Info
} from "lucide-react";
import { ProcessStep, ProcessMetrics } from "../types";
import { AreaId, CORPORATE_AREAS } from "../utils/areaPresets";

interface WipKanbanBoardProps {
  steps: ProcessStep[];
  stats: ProcessMetrics;
  arrivalRate: number;
  defaultFilterStepId?: string;
  activeAreaId?: AreaId;
  onSwitchArea?: (areaId: AreaId) => void;
  processesByArea?: Record<AreaId, ProcessStep[]>;
  activeCompanyId?: string | null;
  activeWorkspaceProjectId?: string | null;
  globalCompanies?: any[];
  globalProjects?: any[];
}

export interface KanbanCard {
  id: string;
  title: string;
  stepId: string;
  stepName: string;
  column: "PLANNED" | "EXECUTING" | "WAITING_TEST";
  priority: "LOW" | "MEDIUM" | "HIGH";
  minutesCost: number;
  qualityStatus: "UNKNOWN" | "PASSED" | "DEFECT_DETECTED";
  description: string;
  updatedAt: string;
  code: string;
  createdAt?: number;
}

export default function WipKanbanBoard({ 
  steps, 
  stats, 
  arrivalRate, 
  defaultFilterStepId,
  activeAreaId,
  onSwitchArea,
  processesByArea,
  activeCompanyId,
  activeWorkspaceProjectId,
  globalCompanies = [],
  globalProjects = []
}: WipKanbanBoardProps) {
  const [cards, setCards] = useState<KanbanCard[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [activeTab, setActiveTabRaw] = useState<"KANBAN" | "MATCH_ANALYTICS" | "AGILE_DA">("KANBAN");
  const [showHelpText, setShowHelpText] = useState(false);
  
  const savedScrollY = React.useRef<number>(0);

  const setActiveTab = (value: any) => {
    savedScrollY.current = window.scrollY;
    if (typeof value === "function") {
      setActiveTabRaw((prev) => value(prev));
    } else {
      setActiveTabRaw(value);
    }
  };

  useEffect(() => {
    if (savedScrollY.current > 0) {
      const targetScroll = savedScrollY.current;
      window.scrollTo(0, targetScroll);
      let count = 0;
      const restore = () => {
        window.scrollTo(0, targetScroll);
        count++;
        if (count < 15) {
          requestAnimationFrame(restore);
        }
      };
      requestAnimationFrame(restore);
    }
  }, [activeTab]);
  
  // ==========================================
  // DISCIPLINED AGILE (DA) & GESTÃO À VISTA STATES
  // ==========================================
  const [selectedArea, setSelectedArea] = useState<AreaId>(activeAreaId || "core_ops");
  
  // Sync selectedArea with activeAreaId prop if passed
  useEffect(() => {
    if (activeAreaId) {
      setSelectedArea(activeAreaId);
    }
  }, [activeAreaId]);

  // DA WoW (Way of Working) picker
  const [selectedWow, setSelectedWow] = useState<"AGILE" | "LEAN" | "CD" | "EXPLORER">(() => {
    const saved = localStorage.getItem(`da_wow_${activeWorkspaceProjectId || "default"}`);
    if (saved) return saved as any;
    // Set default based on area type
    if (["core_ops", "core_inbound", "core_outbound"].includes(selectedArea)) return "LEAN";
    if (["it_governance", "data_ai"].includes(selectedArea)) return "CD";
    return "AGILE";
  });

  useEffect(() => {
    localStorage.setItem(`da_wow_${activeWorkspaceProjectId || "default"}`, selectedWow);
  }, [selectedWow, activeWorkspaceProjectId]);

  // Team Mood & Status States
  const [teamMood, setTeamMood] = useState<"SUNNY" | "CLOUDY" | "RAINY">("SUNNY");
  const [teamCapacity, setTeamCapacity] = useState<number>(8); // present members Count
  const [avgWorkload, setAvgWorkload] = useState<string>("80%");
  
  // Daily Standup Goals and Challenges
  const [dailyGoal, setDailyGoal] = useState<string>(() => {
    return localStorage.getItem(`da_daily_goal_${activeWorkspaceProjectId || "default"}_${selectedArea}`) || "Desatarraxar gargalo do fluxo diário, revisar backlog e monitorar desvios de processo.";
  });

  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState(dailyGoal);

  const saveDailyGoal = (newGoal: string) => {
    setDailyGoal(newGoal);
    localStorage.setItem(`da_daily_goal_${activeWorkspaceProjectId || "default"}_${selectedArea}`, newGoal);
    setIsEditingGoal(false);
  };

  // Blocker Logs State
  const [impediments, setImpediments] = useState<Array<{
    id: string;
    title: string;
    severity: "HIGH" | "MEDIUM" | "LOW";
    owner: string;
    status: "OPEN" | "SOLVED";
    daGuideline: string;
  }>>(() => {
    const saved = localStorage.getItem(`da_impediments_${activeWorkspaceProjectId || "default"}_${selectedArea}`);
    if (saved) {
      try { return JSON.parse(saved); } catch(e){}
    }
    // Default impediments depending on area
    return [
      {
        id: "imp-1",
        title: "Dificuldade na aquisição de insumos de alta reprodutibilidade",
        severity: "HIGH",
        owner: "Comprador Sênior",
        status: "OPEN",
        daGuideline: "Disciplined Agile WoW Advisor: Adote práticas de 'Risk-Value Lifecycle'. Aloque um buffer estocástico prudencial temporário de estoque de segurança enquanto homologamos o novo distribuidor de fibra."
      },
      {
        id: "imp-2",
        title: "Falta de massa crítica habilitada em Green Belt / DMAIC para calibragem de maquinário",
        severity: "MEDIUM",
        owner: "Coordenador de DHO",
        status: "OPEN",
        daGuideline: "Disciplined Agile WoW Advisor: Aplique as sugestões de 'Grow Team Members'. Forme pares ágeis (pair programming de máquina) entre o operador especialista e os novos técnicos para transferência rápida de setup."
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem(`da_impediments_${activeWorkspaceProjectId || "default"}_${selectedArea}`, JSON.stringify(impediments));
  }, [impediments, selectedArea, activeWorkspaceProjectId]);

  const [newImpTitle, setNewImpTitle] = useState("");
  const [newImpSeverity, setNewImpSeverity] = useState<"HIGH" | "MEDIUM" | "LOW">("MEDIUM");
  const [newImpOwner, setNewImpOwner] = useState("");

  const handleAddImpediment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newImpTitle.trim()) return;

    let daGuideline = "Disciplined Agile WoW Advisor: Promova a cooperação técnica e coordene papéis com 'Architecture Owner' / Líder de Fluxo para estabilizar pendências diárias.";
    if (newImpTitle.toLowerCase().includes("banco") || newImpTitle.toLowerCase().includes("api") || newImpTitle.toLowerCase().includes("servidor") || newImpTitle.toLowerCase().includes("ti")) {
      daGuideline = "Disciplined Agile WoW Advisor: Aplique engenharia ágil disciplinada (Continuous Delivery WoW). Aloque testes automatizados integrados aos pipes operacionais para evitar gargalos de deploy.";
    } else if (newImpTitle.toLowerCase().includes("pessoal") || newImpTitle.toLowerCase().includes("recurso") || newImpTitle.toLowerCase().includes("membro") || newImpTitle.toLowerCase().includes("equipe") || newImpTitle.toLowerCase().includes("gente")) {
      daGuideline = "Disciplined Agile WoW Advisor: Respeite as práticas de coaching com foco em 'People First'. Use 'Team Capacity planning' e equilibre a carga mudando para 'Lean-based WoW' com limites rígidos de WIP.";
    } else if (newImpTitle.toLowerCase().includes("jurídico") || newImpTitle.toLowerCase().includes("contrato") || newImpTitle.toLowerCase().includes("fiscal") || newImpTitle.toLowerCase().includes("regulação")) {
      daGuideline = "Disciplined Agile WoW Advisor: Use as diretrizes de governança pragmática do DA. Estabeleça reuniões rápidas e estruturadas bilaterais para destravar pré-requisitos regulatórios.";
    }

    const newImp = {
      id: "imp-" + Date.now(),
      title: newImpTitle,
      severity: newImpSeverity,
      owner: newImpOwner || "Time de Operações",
      status: "OPEN" as const,
      daGuideline
    };

    setImpediments([newImp, ...impediments]);
    setNewImpTitle("");
    setNewImpOwner("");
  };

  const toggleSolveImpediment = (impId: string) => {
    setImpediments(prev => prev.map(imp => {
      if (imp.id === impId) {
        return { ...imp, status: imp.status === "OPEN" ? "SOLVED" as const : "OPEN" as const };
      }
      return imp;
    }));
  };

  const deleteImpediment = (impId: string) => {
    setImpediments(prev => prev.filter(imp => imp.id !== impId));
  };

  // Sub-activities & tasks checklist per area process steps
  const [areaTasks, setAreaTasks] = useState<Record<string, Array<{
    id: string;
    title: string;
    assignedTo: string;
    status: "BACKLOG" | "WIP" | "DONE";
    isBlocked: boolean;
    blockReason?: string;
  }>>>({});

  // Populate tasks when selectedArea changes
  useEffect(() => {
    const key = `da_tasks_${activeWorkspaceProjectId || "default"}_${selectedArea}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        setAreaTasks(JSON.parse(saved));
        return;
      } catch (e) {}
    }

    const areaSteps = processesByArea ? (processesByArea[selectedArea] || []) : steps;
    const presets: Record<string, any[]> = {};
    
    areaSteps.forEach((st) => {
      presets[st.id] = [
        {
          id: `task-pres-1-${st.id}`,
          title: `Triagem e qualificação inicial: ${st.name}`,
          assignedTo: st.resource || "Analista Principal",
          status: "DONE",
          isBlocked: false
        },
        {
          id: `task-pres-2-${st.id}`,
          title: `Processamento, digitação ou manufatura do lote`,
          assignedTo: st.resource || "Técnico do Turno",
          status: "WIP",
          isBlocked: false
        },
        {
          id: `task-pres-3-${st.id}`,
          title: `Inspeção amostral e liberação documental do lote`,
          assignedTo: "Supervisor Lean QA",
          status: "BACKLOG",
          isBlocked: Math.random() > 0.82,
          blockReason: "Aguardando assinatura digital ou liberação de conformidade regulatória"
        }
      ];
    });

    setAreaTasks(presets);
    localStorage.setItem(key, JSON.stringify(presets));
  }, [selectedArea, activeWorkspaceProjectId, processesByArea, steps]);

  const saveAreaTasks = (updated: typeof areaTasks) => {
    setAreaTasks(updated);
    const key = `da_tasks_${activeWorkspaceProjectId || "default"}_${selectedArea}`;
    localStorage.setItem(key, JSON.stringify(updated));
  };

  const handleUpdateTaskStatus = (stepId: string, taskId: string, newStatus: "BACKLOG" | "WIP" | "DONE") => {
    const stepTasks = areaTasks[stepId] || [];
    const updatedStepTasks = stepTasks.map(t => {
      if (t.id === taskId) {
        return { ...t, status: newStatus };
      }
      return t;
    });
    const updated = {
      ...areaTasks,
      [stepId]: updatedStepTasks
    };
    saveAreaTasks(updated);
  };

  const handleToggleTaskBlocked = (stepId: string, taskId: string, reason?: string) => {
    const stepTasks = areaTasks[stepId] || [];
    const updatedStepTasks = stepTasks.map(t => {
      if (t.id === taskId) {
        const nextBlocked = !t.isBlocked;
        return { 
          ...t, 
          isBlocked: nextBlocked,
          blockReason: nextBlocked ? (reason || "Impedimento sob escrutínio no Daily Standup") : undefined
        };
      }
      return t;
    });
    const updated = {
      ...areaTasks,
      [stepId]: updatedStepTasks
    };
    saveAreaTasks(updated);
  };

  const [formTaskTitle, setFormTaskTitle] = useState<Record<string, string>>({});
  const [formTaskAssignee, setFormTaskAssignee] = useState<Record<string, string>>({});

  const handleAddTaskToStep = (stepId: string, e: React.FormEvent) => {
    e.preventDefault();
    const title = formTaskTitle[stepId] || "";
    const assignee = formTaskAssignee[stepId] || "";
    if (!title.trim()) return;

    const matchedStep = (processesByArea ? (processesByArea[selectedArea] || []) : steps).find(s => s.id === stepId);
    const defaultAssignee = matchedStep ? matchedStep.resource : "Membro do Time";

    const newTask = {
      id: `task-manual-${stepId}-${Date.now()}`,
      title: title.trim(),
      assignedTo: assignee.trim() || defaultAssignee,
      status: "BACKLOG" as const,
      isBlocked: false
    };

    const currentStepTasks = areaTasks[stepId] || [];
    const updated = {
      ...areaTasks,
      [stepId]: [...currentStepTasks, newTask]
    };
    
    saveAreaTasks(updated);
    setFormTaskTitle(prev => ({ ...prev, [stepId]: "" }));
    setFormTaskAssignee(prev => ({ ...prev, [stepId]: "" }));
  };

  const handleDeleteTaskFromStep = (stepId: string, taskId: string) => {
    const stepTasks = areaTasks[stepId] || [];
    const filtered = stepTasks.filter(t => t.id !== taskId);
    const updated = {
      ...areaTasks,
      [stepId]: filtered
    };
    saveAreaTasks(updated);
  };

  const handleSelectArea = (areaId: AreaId) => {
    setSelectedArea(areaId);
    if (onSwitchArea) {
      onSwitchArea(areaId);
    }
  };
  
  // Kanban board view filters
  const [filterQuality, setFilterQuality] = useState<"ALL" | "PASSED" | "DEFECT_DETECTED" | "UNKNOWN">("ALL");
  const [filterPriority, setFilterPriority] = useState<"ALL" | "HIGH" | "MEDIUM" | "LOW">("ALL");
  const [filterStepId, setFilterStepId] = useState<string>(defaultFilterStepId || "ALL");
  const [sortBy, setSortBy] = useState<"PRIORITY_DESC" | "PRIORITY_ASC" | "CREATED_DESC" | "CREATED_ASC" | "COST_DESC" | "COST_ASC">("CREATED_DESC");

  useEffect(() => {
    if (defaultFilterStepId) {
      setFilterStepId(defaultFilterStepId);
    }
  }, [defaultFilterStepId]);

  // Create form states
  const [formTitle, setFormTitle] = useState("");
  const [formStepId, setFormStepId] = useState("");
  const [formPriority, setFormPriority] = useState<"LOW" | "MEDIUM" | "HIGH">("MEDIUM");
  const [formDescription, setFormDescription] = useState("");

  // Edit form states
  const [editingCard, setEditingCard] = useState<KanbanCard | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editFormTitle, setEditFormTitle] = useState("");
  const [editFormStepId, setEditFormStepId] = useState("");
  const [editFormPriority, setEditFormPriority] = useState<"LOW" | "MEDIUM" | "HIGH">("MEDIUM");
  const [editFormDescription, setEditFormDescription] = useState("");
  const [editFormMinutesCost, setEditFormMinutesCost] = useState(0);
  const [editFormQualityStatus, setEditFormQualityStatus] = useState<"UNKNOWN" | "PASSED" | "DEFECT_DETECTED">("UNKNOWN");

  // Load from local storage or set initial cards based on current WIP
  useEffect(() => {
    const saved = localStorage.getItem("optima_wip_kanban_cards");
    if (saved) {
      try {
        setCards(JSON.parse(saved));
        return;
      } catch (e) {
        console.error("Erro ao carregar cartões kanban", e);
      }
    }
    // If empty, generate base cards reflecting the theoretical WIP
    generateDefaultCardsFromWip();
  }, [steps]);

  // Persist cards
  const saveCards = (newCards: KanbanCard[]) => {
    setCards(newCards);
    localStorage.setItem("optima_wip_kanban_cards", JSON.stringify(newCards));
  };

  // Generate cards based on current queueing model's step metrics
  const generateDefaultCardsFromWip = () => {
    const newCards: KanbanCard[] = [];
    let counter = 101;

    steps.forEach((step) => {
      // Calculate active WIP. If not calculated, fallback to 1 card
      const stepWip = Math.max(0.5, step.wip || 0.8);
      const timesToGenerate = Math.max(1, Math.min(4, Math.ceil(stepWip)));

      for (let i = 0; i < timesToGenerate; i++) {
        // Distribute mathematically between Em Execução and Aguardando Teste/Planejado
        let col: "PLANNED" | "EXECUTING" | "WAITING_TEST" = "EXECUTING";
        if (i === 0 && Math.random() > 0.6) col = "PLANNED";
        if (i === timesToGenerate - 1 && Math.random() > 0.5) col = "WAITING_TEST";

        const priorities: ("LOW" | "MEDIUM" | "HIGH")[] = ["LOW", "MEDIUM", "HIGH"];
        const priority = priorities[Math.floor(Math.random() * 3)];
        
        newCards.push({
          id: `card-${step.id}-${i}-${Date.now()}-${counter}`,
          title: `Lote ${step.name.split(" ")[0]} #${counter}`,
          stepId: step.id,
          stepName: step.name,
          column: col,
          priority: priority,
          minutesCost: parseFloat((step.processingTime * (0.8 + Math.random() * 0.4)).toFixed(1)),
          qualityStatus: col === "WAITING_TEST" && Math.random() > 0.25 ? "PASSED" : "UNKNOWN",
          description: `Lote de placas de circuito impresso em trânsito no posto de ${step.name}.`,
          updatedAt: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' }),
          code: `OS-SMT-${counter}`,
          createdAt: Date.now() - counter * 1000
        });
        counter++;
      }
    });

    saveCards(newCards);
  };

  // Handle Drag and Drop
  const handleDragStart = (e: React.DragEvent, cardId: string) => {
    e.dataTransfer.setData("text/plain", cardId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetColumn: "PLANNED" | "EXECUTING" | "WAITING_TEST") => {
    e.preventDefault();
    const cardId = e.dataTransfer.getData("text/plain");
    if (!cardId) return;

    moveCardToColumn(cardId, targetColumn);
  };

  const moveCardToColumn = (cardId: string, targetColumn: "PLANNED" | "EXECUTING" | "WAITING_TEST") => {
    const updated = cards.map((c) => {
      if (c.id === cardId) {
        // Automatically test/update status when moved to WAITING_TEST
        let qs = c.qualityStatus;
        if (targetColumn === "WAITING_TEST" && qs === "UNKNOWN") {
          // Keep unknown until user runs Quality Check
        }
        return {
          ...c,
          column: targetColumn,
          qualityStatus: targetColumn === "PLANNED" ? "UNKNOWN" : qs,
          updatedAt: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })
        };
      }
      return c;
    });
    saveCards(updated);
  };

  // Run instant Quality Check / Simulation Run for a single card based on step yield
  const handleSimulateQualityCheck = (cardId: string) => {
    const updated = cards.map((c) => {
      if (c.id === cardId) {
        const associatedStep = steps.find(s => s.id === c.stepId);
        const yieldRate = associatedStep ? associatedStep.yieldRate : 0.95;
        
        // Exponent check representing first-pass yield logic
        const roll = Math.random();
        const passed = roll <= yieldRate;

        return {
          ...c,
          qualityStatus: passed ? ("PASSED" as const) : ("DEFECT_DETECTED" as const),
          updatedAt: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })
        };
      }
      return c;
    });
    saveCards(updated);
  };

  // Create new task manually
  const handleCreateCardInForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formStepId) return;

    const matchedStep = steps.find(s => s.id === formStepId);
    if (!matchedStep) return;

    const randomNum = Math.floor(100 + Math.random() * 900);
    const newCard: KanbanCard = {
      id: `card-manual-${Date.now()}`,
      title: formTitle,
      stepId: formStepId,
      stepName: matchedStep.name,
      column: "PLANNED",
      priority: formPriority,
      minutesCost: matchedStep.processingTime,
      qualityStatus: "UNKNOWN",
      description: formDescription || `Ficha de instrução de trabalho complementar gerada via backlog.`,
      updatedAt: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' }),
      code: `OS-MAN-${randomNum}`,
      createdAt: Date.now()
    };

    saveCards([newCard, ...cards]);
    
    // reset form states
    setFormTitle("");
    setFormStepId("");
    setFormPriority("MEDIUM");
    setFormDescription("");
    setShowCreateModal(false);
  };

  const handleDeleteCard = (cardId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = cards.filter(c => c.id !== cardId);
    saveCards(filtered);
  };

  const handleOpenEditModal = (card: KanbanCard) => {
    setEditingCard(card);
    setEditFormTitle(card.title);
    setEditFormStepId(card.stepId);
    setEditFormPriority(card.priority);
    setEditFormDescription(card.description);
    setEditFormMinutesCost(card.minutesCost);
    setEditFormQualityStatus(card.qualityStatus);
    setShowEditModal(true);
  };

  const handleSaveEditInForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCard) return;

    const chosenStep = steps.find(s => s.id === editFormStepId);
    
    const updated = cards.map((c) => {
      if (c.id === editingCard.id) {
        return {
          ...c,
          title: editFormTitle,
          stepId: editFormStepId,
          stepName: chosenStep ? chosenStep.name : c.stepName,
          priority: editFormPriority,
          description: editFormDescription,
          minutesCost: Number(editFormMinutesCost),
          qualityStatus: editFormQualityStatus,
          updatedAt: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })
        };
      }
      return c;
    });

    saveCards(updated);
    setShowEditModal(false);
    setEditingCard(null);
  };

  // Helper to extract timestamp for safe creation comparison
  const getCardTime = (card: KanbanCard): number => {
    if (card.createdAt) return card.createdAt;
    const parts = card.id.split("-");
    if (parts.length >= 4) {
      const ts = parseInt(parts[3], 10);
      if (!isNaN(ts)) return ts;
    }
    return 0;
  };

  // Filter cards for visual display on the columns
  const filteredCards = cards.filter((c) => {
    const matchesQuality = filterQuality === "ALL" || c.qualityStatus === filterQuality;
    const matchesPriority = filterPriority === "ALL" || c.priority === filterPriority;
    const matchesStep = filterStepId === "ALL" || c.stepId === filterStepId;
    return matchesQuality && matchesPriority && matchesStep;
  });

  // Sort filtered cards based on chosen sort option
  const sortedAndFilteredCards = [...filteredCards].sort((a, b) => {
    switch (sortBy) {
      case "PRIORITY_DESC": {
        const priorityWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
        return priorityWeight[b.priority] - priorityWeight[a.priority];
      }
      case "PRIORITY_ASC": {
        const priorityWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
        return priorityWeight[a.priority] - priorityWeight[b.priority];
      }
      case "CREATED_DESC":
        return getCardTime(b) - getCardTime(a);
      case "CREATED_ASC":
        return getCardTime(a) - getCardTime(b);
      case "COST_DESC":
        return b.minutesCost - a.minutesCost;
      case "COST_ASC":
        return a.minutesCost - b.minutesCost;
      default:
        return 0;
    }
  });

  // Metrics summarizing Visual Kanban WIP
  const plannedCount = sortedAndFilteredCards.filter(c => c.column === "PLANNED").length;
  const executingCount = sortedAndFilteredCards.filter(c => c.column === "EXECUTING").length;
  const waitingTestCount = sortedAndFilteredCards.filter(c => c.column === "WAITING_TEST").length;

  const totalVisualWip = cards.filter(c => c.column === "EXECUTING" || c.column === "WAITING_TEST").length;
  const theoreticalWip = stats.systemWip;

  // Percentage Deviation between empirical/visual Kanban WIP and Theoretical Queuing WIP
  const wipDeviationPct = theoreticalWip > 0 
    ? ((totalVisualWip - theoreticalWip) / theoreticalWip) * 100 
    : 0;

  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* HEADER SECTION - Compacted */}
      <div className="border-b border-gray-200 pb-3 flex flex-col md:flex-row md:items-center justify-between gap-2.5">
        <div>
          <span className="text-[9px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-sm uppercase tracking-wider inline-block">
            Fluxo Kanban &amp; Teoria de Filas
          </span>
          <h2 className="text-xl font-serif text-gray-950 uppercase tracking-tight flex items-center gap-2 mt-1">
            <Kanban size={18} className="text-indigo-600" />
            <span>Monitoramento do WIP Estocástico</span>
            {/* Informational context tooltip */}
            <span className="group relative inline-block cursor-help text-gray-400 hover:text-gray-600">
              <Info size={14} className="text-indigo-500 shrink-0" />
              <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-slate-900 text-white text-[10px] font-sans font-normal p-2.5 rounded shadow-xl opacity-0 group-hover:opacity-100 transition-opacity z-50 leading-relaxed normal-case font-semibold">
                <strong>Modelo de Filas de Kingman e Little:</strong> Computa em tempo real o WIP e o estoque teórico limite sustentável sob variabilidade de postos produtivos e taxas de entrada estocásticas.
              </span>
            </span>
          </h2>
        </div>
      </div>

      {/* METHODOLOGY LINKAGE METRICS BAR */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-[#FAF8F5] border border-gray-200 shadow-xs">
        
        <div className="space-y-1">
          <span className="text-[10px] font-mono uppercase text-gray-500 block">WIP Teórico Permanente</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-serif text-gray-950">{theoreticalWip.toFixed(2)}</span>
            <span className="text-[11px] text-gray-500 font-mono">unidades (Little's Law)</span>
          </div>
          <p className="text-[10px] text-gray-550 leading-tight">
            Estoque médio esperado na fábrica para evitar colapso de gargalo.
          </p>
        </div>

        <div className="space-y-1 border-l border-gray-200 pl-0 md:pl-4">
          <span className="text-[10px] font-mono uppercase text-gray-500 block">WIP Atual de Quadros</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-serif text-indigo-600 font-bold">{totalVisualWip}</span>
            <span className="text-[11px] text-indigo-500 font-mono">em execução/teste</span>
          </div>
          <p className="text-[10px] text-gray-550 leading-tight">
            Cards físicos ativos na fábrica (Execução + Aguardando Teste).
          </p>
        </div>

        <div className="space-y-1 border-l border-gray-200 pl-0 md:pl-4">
          <span className="text-[10px] font-mono uppercase text-gray-500 block">Desvio de WIP Operacional</span>
          <div className="flex items-baseline gap-2">
            <span className={`text-xl font-mono font-bold ${
              Math.abs(wipDeviationPct) < 20 
                ? "text-emerald-700" 
                : wipDeviationPct > 0 
                  ? "text-amber-700" 
                  : "text-blue-700"
            }`}>
              {wipDeviationPct > 0 ? "+" : ""}{wipDeviationPct.toFixed(1)}%
            </span>
            <span className="text-[9.5px] text-gray-550">vs Teórico</span>
          </div>
          <p className="text-[10px] text-gray-550 leading-tight">
            {wipDeviationPct > 50 
              ? "Saturação de WIP: risco de lead time estourar devido a gargalo de filas."
              : Math.abs(wipDeviationPct) < 20 
                ? "Processo super balanceado com a capacidade teórica do sistema."
                : "Abaixo da capacidade teórica permanente: subutilização do fluxo."}
          </p>
        </div>

        <div className="space-y-2 border-l border-gray-200 pl-0 md:pl-4 flex flex-col justify-center">
          <div className="flex items-center gap-1.5 self-start">
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-[#1A1A1A] text-white hover:bg-stone-800 font-mono text-[9px] font-bold px-2.5 py-1.5 rounded-sm flex items-center gap-1 cursor-pointer transition-all"
            >
              <Plus size={11} /> Novo Lote (Card)
            </button>
            <button
              onClick={generateDefaultCardsFromWip}
              title="Regerar cartões a partir da equação teórica de WIP"
              className="bg-white border border-gray-350 hover:border-black text-gray-700 hover:text-black font-mono text-[9px] font-bold px-2 py-1.5 rounded-sm flex items-center gap-1 cursor-pointer transition-all"
            >
              <RefreshCw size={11} /> Resetar p/ Teórico
            </button>
          </div>
        </div>

      </div>

      {/* LAYOUT NAVIGATION TABS */}
      <div className="flex flex-wrap border-b border-[#1A1A1A] gap-1">
        <button
          onClick={() => setActiveTab("KANBAN")}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "KANBAN" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <LayoutGrid size={13} />
          <span>I. Quadro Kanban de Lotes em Processo</span>
        </button>
        <button
          onClick={() => setActiveTab("MATCH_ANALYTICS")}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "MATCH_ANALYTICS" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <Activity size={13} />
          <span>II. Análise de Desvio do WIP Teórico por Posto</span>
        </button>
        <button
          onClick={() => setActiveTab("AGILE_DA")}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "AGILE_DA" 
              ? "bg-indigo-600 text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <Sparkles size={13} className="text-[#C49746] animate-pulse" />
          <span>🛡️ III. Cockpit Disciplined Agile (DA) &amp; Gestão à Vista</span>
        </button>
      </div>

      {/* VIEW A: INTERACTIVE KANBAN BOARD */}
      {activeTab === "KANBAN" && (
        <div className="space-y-6">
          
          {/* FILTERS PANEL */}
          <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-6">
              
              {/* Quality Status Filter */}
              <div className="space-y-1.5 text-left">
                <span className="text-[10px] font-mono text-gray-500 uppercase font-bold tracking-wider block">
                  🛡️ Status de Qualidade
                </span>
                <div className="flex flex-wrap items-center gap-1">
                  {(["ALL", "PASSED", "DEFECT_DETECTED", "UNKNOWN"] as const).map((q) => {
                    const labels: Record<string, string> = {
                      ALL: "Todos",
                      PASSED: "Aprovados",
                      DEFECT_DETECTED: "Falha (Refugo)",
                      UNKNOWN: "Não Testado"
                    };
                    const active = filterQuality === q;
                    return (
                      <button
                        key={q}
                        onClick={() => setFilterQuality(q)}
                        className={`px-3 py-1 font-mono text-[10px] font-bold border rounded-sm transition-all cursor-pointer ${
                          active 
                            ? "bg-indigo-600 text-white border-indigo-600" 
                            : "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200"
                        }`}
                      >
                        {labels[q]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Priority Filter */}
              <div className="space-y-1.5 text-left">
                <span className="text-[10px] font-mono text-gray-500 uppercase font-bold tracking-wider block">
                  ⚡ Nível de Prioridade
                </span>
                <div className="flex flex-wrap items-center gap-1">
                  {(["ALL", "HIGH", "MEDIUM", "LOW"] as const).map((p) => {
                    const labels: Record<string, string> = {
                      ALL: "Todas",
                      HIGH: "Alta",
                      MEDIUM: "Média",
                      LOW: "Baixa"
                    };
                    const active = filterPriority === p;
                    return (
                      <button
                        key={p}
                        onClick={() => setFilterPriority(p)}
                        className={`px-3 py-1 font-mono text-[10px] font-bold border rounded-sm transition-all cursor-pointer ${
                          active 
                            ? "bg-amber-600 text-white border-amber-600" 
                            : "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200"
                        }`}
                      >
                        {labels[p]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step/Module Filter */}
              <div className="space-y-1.5 text-left">
                <span className="text-[10px] font-mono text-gray-500 uppercase font-bold tracking-wider block">
                  🎯 Filtrar por Módulo / Etapa
                </span>
                <select
                  value={filterStepId}
                  onChange={(e) => setFilterStepId(e.target.value)}
                  className="bg-white border border-gray-300 text-[10px] sm:text-[11px] font-mono font-bold px-3 py-1 rounded-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer h-7"
                >
                  <option value="ALL">📍 Todas as Etapas</option>
                  {steps.map(s => (
                    <option key={s.id} value={s.id}>📍 {s.name.split(" - ")[0]}</option>
                  ))}
                </select>
              </div>

              {/* Sort Selector Option */}
              <div className="space-y-1.5 text-left">
                <span className="text-[10px] font-mono text-gray-500 uppercase font-bold tracking-wider block">
                  ↕️ Ordenação dos Lotes
                </span>
                <select
                  id="kanban-sort-select"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white border border-gray-300 text-[10px] sm:text-[11px] font-mono font-bold px-3 py-1 rounded-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer h-7"
                >
                  <option value="CREATED_DESC">⏱️ Criação: Recentes Primeiro</option>
                  <option value="CREATED_ASC">⏱️ Criação: Antigos Primeiro</option>
                  <option value="PRIORITY_DESC">🔥 Prioridade: Alta para Baixa</option>
                  <option value="PRIORITY_ASC">🔥 Prioridade: Baixa para Alta</option>
                  <option value="COST_DESC">⚙️ Ciclo de Trabalho: Maior primeiro</option>
                  <option value="COST_ASC">⚙️ Ciclo de Trabalho: Menor primeiro</option>
                </select>
              </div>

            </div>

            {/* Clear Filters Button */}
            {(filterQuality !== "ALL" || filterPriority !== "ALL" || filterStepId !== "ALL" || sortBy !== "CREATED_DESC") && (
              <button
                onClick={() => {
                  setFilterQuality("ALL");
                  setFilterPriority("ALL");
                  setFilterStepId("ALL");
                  setSortBy("CREATED_DESC");
                }}
                className="text-xs font-mono font-bold text-red-600 hover:text-red-800 transition-all flex items-center gap-1 self-start md:self-end py-1 px-2 hover:bg-red-50 rounded-sm cursor-pointer"
              >
                Limpar Filtros ✕
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* COLUMN 1: PLANNED */}
            <div 
              className="bg-[#FAF8F5] border border-gray-300 p-4 rounded-sm flex flex-col min-h-[500px]"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, "PLANNED")}
            >
              <div className="flex items-center justify-between border-b border-gray-300 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-gray-400 rounded-full"></span>
                  <h3 className="font-serif text-xs font-bold uppercase tracking-wider text-gray-800">
                    Planejado (Backlog)
                  </h3>
                </div>
                <span className="font-mono text-[10px] font-bold bg-white border border-gray-300 px-2 py-0.5 text-gray-700 rounded-sm">
                  {plannedCount} cards
                </span>
              </div>

              <div className="space-y-3 flex-grow overflow-y-auto max-h-[600px] pr-1">
                {sortedAndFilteredCards.filter(c => c.column === "PLANNED").length === 0 ? (
                  <div className="h-40 border-2 border-dashed border-gray-200 flex flex-col justify-center items-center text-center p-4">
                    <HelpCircle size={18} className="text-gray-300 mb-1" />
                    <p className="text-[10px] text-gray-400 font-sans">Nenhum lote correspondente nesta coluna.</p>
                  </div>
                ) : (
                  sortedAndFilteredCards.filter(c => c.column === "PLANNED").map(card => (
                    <KanbanCardItem 
                      key={card.id} 
                      card={card} 
                      steps={steps}
                      onDragStart={handleDragStart}
                      onMove={moveCardToColumn}
                      onDelete={handleDeleteCard}
                      onEdit={handleOpenEditModal}
                      onQualityCheck={handleSimulateQualityCheck}
                    />
                  ))
                )}
              </div>
            </div>

            {/* COLUMN 2: EXECUTING */}
            <div 
              className="bg-indigo-50/20 border border-indigo-200/50 p-4 rounded-sm flex flex-col min-h-[500px]"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, "EXECUTING")}
            >
              <div className="flex items-center justify-between border-b border-indigo-200 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-indigo-600 rounded-full animate-pulse"></span>
                  <h3 className="font-serif text-xs font-bold uppercase tracking-wider text-indigo-900">
                    Em Execução (WIP Ativo)
                  </h3>
                </div>
                <span className="font-mono text-[10px] font-bold bg-white border border-indigo-300 px-2 py-0.5 text-indigo-700 rounded-sm">
                  {executingCount} cards
                </span>
              </div>

              <div className="space-y-3 flex-grow overflow-y-auto max-h-[600px] pr-1">
                {sortedAndFilteredCards.filter(c => c.column === "EXECUTING").length === 0 ? (
                  <div className="h-40 border-2 border-dashed border-indigo-100 flex flex-col justify-center items-center text-center p-4 text-indigo-400">
                    <Activity size={18} className="animate-pulse mb-1" />
                    <p className="text-[10px] font-sans">Sem lotes correspondentes nesta coluna.</p>
                  </div>
                ) : (
                  sortedAndFilteredCards.filter(c => c.column === "EXECUTING").map(card => (
                    <KanbanCardItem 
                      key={card.id} 
                      card={card} 
                      steps={steps}
                      onDragStart={handleDragStart}
                      onMove={moveCardToColumn}
                      onDelete={handleDeleteCard}
                      onEdit={handleOpenEditModal}
                      onQualityCheck={handleSimulateQualityCheck}
                    />
                  ))
                )}
              </div>
            </div>

            {/* COLUMN 3: WAITING_TEST */}
            <div 
              className="bg-emerald-50/20 border border-emerald-200/50 p-4 rounded-sm flex flex-col min-h-[500px]"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, "WAITING_TEST")}
            >
              <div className="flex items-center justify-between border-b border-emerald-200 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-emerald-600 rounded-full"></span>
                  <h3 className="font-serif text-xs font-bold uppercase tracking-wider text-emerald-900">
                    Aguardando Teste / Calibração
                  </h3>
                </div>
                <span className="font-mono text-[10px] font-bold bg-white border border-emerald-300 px-2 py-0.5 text-emerald-700 rounded-sm">
                  {waitingTestCount} cards
                </span>
              </div>

              <div className="space-y-3 flex-grow overflow-y-auto max-h-[600px] pr-1">
                {sortedAndFilteredCards.filter(c => c.column === "WAITING_TEST").length === 0 ? (
                  <div className="h-40 border-2 border-dashed border-emerald-100 flex flex-col justify-center items-center text-center p-4 text-emerald-500">
                    <CheckCircle2 size={18} className="mb-1" />
                    <p className="text-[10px] font-sans">Sem lotes correspondentes nesta coluna.</p>
                  </div>
                ) : (
                  sortedAndFilteredCards.filter(c => c.column === "WAITING_TEST").map(card => (
                    <KanbanCardItem 
                      key={card.id} 
                      card={card} 
                      steps={steps}
                      onDragStart={handleDragStart}
                      onMove={moveCardToColumn}
                      onDelete={handleDeleteCard}
                      onEdit={handleOpenEditModal}
                      onQualityCheck={handleSimulateQualityCheck}
                    />
                  ))
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* VIEW B: WIP DISCREPANCY COMPARISON TAB */}
      {activeTab === "MATCH_ANALYTICS" && (
        <div className="space-y-6">
          
          <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-2">
              <h3 className="font-serif text-sm font-bold text-gray-950 uppercase">
                Auditoria de Fluxo: WIP Visual (Kanban) vs WIP Estimado (Teoria das Filas)
              </h3>
              <button
                type="button"
                onClick={() => setShowHelpText(!showHelpText)}
                className="text-[9.5px] font-mono uppercase bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-250 px-2 py-1 rounded transition-colors cursor-pointer self-start"
              >
                {showHelpText ? "▲ Minimizar Ajuda" : "💡 Mostrar Suporte Didático"}
              </button>
            </div>
            {showHelpText && (
              <p className="text-xs text-gray-600 leading-relaxed p-3 bg-slate-50 border border-slate-200">
                Em manufatura moderna, o <strong>Kanban físico de cartões</strong> limita a quantidade máxima de WIP para evitar o transbordamento das filas. Abaixo, comparamos o WIP decorrente de seus cartões no Kanban de chão de fábrica com o WIP gerado pela modelagem matemática estocástica dada pelo tráfego de demanda global.
              </p>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-gray-700 font-sans border border-gray-200">
                <thead className="bg-[#FAF8F5] text-gray-900 uppercase font-mono text-[10px] tracking-wider border-b border-gray-200">
                  <tr>
                    <th className="p-3">Posto Produtivo</th>
                    <th className="p-3">WIP Teórico Esperado (Matemático)</th>
                    <th className="p-3 text-center">Cards no Kanban Operacional</th>
                    <th className="p-3">Status de Congestionamento</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {steps.map(step => {
                    const stepTheoryWip = step.wip || 0;
                    const stepCards = cards.filter(c => c.stepId === step.id && c.column !== "PLANNED");
                    const cardCount = stepCards.length;
                    const discrepancy = cardCount - stepTheoryWip;

                    let statusClass = "text-emerald-700 bg-emerald-50";
                    let statusLabel = "Balanceado";
                    if (discrepancy > 1.2) {
                      statusClass = "text-amber-800 bg-amber-50";
                      statusLabel = "Superfaturado (WIP Elevado)";
                    } else if (discrepancy < -1.0 && stepTheoryWip > 1.0) {
                      statusClass = "text-blue-800 bg-blue-50";
                      statusLabel = "Falta de Lote (Estrangulado)";
                    }

                    return (
                      <tr key={step.id} className="hover:bg-gray-50">
                        <td className="p-3 font-medium text-gray-900 border-r border-gray-100">
                          {step.name}
                        </td>
                        <td className="p-3 font-mono text-gray-600">
                          {stepTheoryWip.toFixed(2)} unidades
                        </td>
                        <td className="p-3 text-center font-mono font-bold text-indigo-700">
                          {cardCount} cards
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-xs text-[9.5px] font-bold uppercase tracking-wider ${statusClass}`}>
                            {statusLabel}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2 leading-relaxed">
              <AlertTriangle className="text-amber-700 shrink-0 mt-0.5" size={15} />
              <div>
                <strong>Como interpretar esta divergência?</strong> 
                <p className="mt-1 text-[11px] text-amber-800">
                  Se o número de cartões ativos no Kanban for consistentemente superior ao <strong>WIP Teórico Estimado</strong>, o Lead Time de entrega real do seu lote será muito superior ao planejado na engenharia. Adote práticas anti-variabilidade (Lean Six Sigma 5S, manutenção preventiva no forno de refluxo ou calibração de maquinário) para encurtar as filas estocásticas.
                </p>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* VIEW C: COCKPIT DISCIPLINED AGILE (DA) & GESTÃO À VISTA */}
      {activeTab === "AGILE_DA" && (
        <div className="space-y-6">
          
          {/* ORG STATUS INDICATOR BLOCK */}
          <div className="bg-slate-900 text-white p-4 border border-slate-950 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono text-[#C49746] font-bold uppercase tracking-widest block">
                Metodologia Híbrida: Lean Six Sigma + Disciplined Agile (DA)
              </span>
              <div className="flex items-center gap-3 mt-1 flex-wrap">
                <h3 className="font-serif text-lg font-bold uppercase tracking-tight text-white">
                  Controle Diário Integrado &amp; Gestão à Vista
                </h3>
                <button
                  type="button"
                  onClick={() => setShowHelpText(!showHelpText)}
                  className="text-[9.5px] font-mono uppercase bg-slate-800 hover:bg-slate-750 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded transition-colors cursor-pointer"
                >
                  {showHelpText ? "▲ Minimizar Informações" : "💡 Ver Orientação Ágil"}
                </button>
              </div>
              {showHelpText && (
                <p className="text-[11px] text-slate-350 font-sans mt-2 max-w-2xl leading-relaxed p-2.5 bg-slate-950 border border-slate-800">
                  Este cockpit unifica a agilidade pragmática do <strong>Disciplined Agile (DA) Toolkit</strong> com o rigor analítico do seu modelo estocástico de filas. Use os seletores de áreas específicos para acompanhar o andamento dos processos diários da empresa.
                </p>
              )}
            </div>
            <div className="shrink-0 bg-slate-800 border border-slate-750 px-4 py-2 text-right">
              <span className="text-[9px] font-mono font-bold text-slate-400 uppercase block">Empresa de Atendimento</span>
              <span className="text-sm font-bold text-slate-100 uppercase block">
                {globalCompanies.find(c => c.id === activeCompanyId)?.name || "Unidade Corporativa Principal"}
              </span>
              <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                Projeto: <strong>{globalProjects.find(p => p.id === activeWorkspaceProjectId)?.name || "LSS Global Workspace"}</strong>
              </span>
            </div>
          </div>

          {/* CORPORATE AREA SELECTOR */}
          <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-[9.5px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-sm uppercase font-mono">
                  Seletor de Escopo
                </span>
                <h3 className="font-serif text-xs font-black text-slate-800 uppercase">
                  Gestão de Processos por Unidade de Negócio (Filtragem Específica)
                </h3>
              </div>
              <span className="text-[9.5px] text-gray-500 font-mono">
                Selecione qual área da empresa precisa auditar nesta reunião diária
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-2">
              {CORPORATE_AREAS.map((area) => {
                const isSelected = selectedArea === area.id;
                return (
                  <button
                    key={area.id}
                    onClick={() => handleSelectArea(area.id)}
                    className={`p-2 border rounded-sm text-center transition-all relative cursor-pointer group ${
                      isSelected 
                        ? "border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-600/30" 
                        : "border-slate-200 hover:border-slate-350 bg-slate-50/30"
                    }`}
                  >
                    <div className="text-lg mb-1">{area.icon}</div>
                    <span className={`text-[9px] font-black tracking-tight leading-tight uppercase block truncate ${isSelected ? "text-indigo-900" : "text-slate-800"}`}>
                      {area.name.split(",")[0].split("&")[0].split(" ")[0]}
                    </span>
                    <span className="text-[7.5px] text-slate-400 block uppercase font-mono mt-0.5">
                      {area.type === "CORE" ? "Core" : "Apoio"}
                    </span>
                    {isSelected && (
                      <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-600 rounded-full"></span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* CHOOSE YOUR WOW PANEL */}
          <div className="bg-white border text-left border-gray-200 shadow-xs p-4 rounded-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
              <div>
                <span className="text-[9px] font-mono font-bold text-[#C49746] uppercase block">
                  Disciplined Agile (DA) WoW Selector
                </span>
                <h3 className="font-serif text-xs font-bold uppercase text-slate-800 mt-0.5">
                  Modo de Trabalho Ativo (Way of Working) para a Unidade de {CORPORATE_AREAS.find(a => a.id === selectedArea)?.name || "Operações"}
                </h3>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[9.5px] font-mono text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100 uppercase font-black">
                  WoW Habilitado: {selectedWow === "AGILE" ? "Agile (Scrum)" : selectedWow === "LEAN" ? "Lean (Continuous)" : selectedWow === "CD" ? "Continuous Delivery" : "Explorer"}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              {[
                {
                  id: "AGILE",
                  name: "Agile (Scrum Iterativo)",
                  icon: "🔄",
                  desc: "Ciclos de 2 semanas baseados em priorizar backlog diário e blindagem do escopo planejado. Excelente para projetos de mudança organizacional.",
                  guidelines: [
                    "Metas fechadas de entrega no Daily Standup",
                    "Retrospectiva com foco em maturidade do processo",
                    "Uso de Story Points para triar capacidade diária"
                  ]
                },
                {
                  id: "LEAN",
                  name: "Lean (Continuous Flow)",
                  icon: "🌊",
                  desc: "Fluxo sob demanda livre de iterações rígidas. Perfeito para operações de manufatura ou vendas, com foco absoluto em reduzir Lead Times.",
                  guidelines: [
                    "WIP estrito e sinalização imediata de gargalos",
                    "Gráficos de fluxo cumulativo diários (CFD)",
                    "Balanceamento do fluxo eliminando estoques intermediários"
                  ]
                },
                {
                  id: "CD",
                  name: "Continuous Delivery",
                  icon: "🚀",
                  desc: "Fluxo veloz focado em sistemas e governança. Deploys frequentes na esteira de tarefas e tolerância zero a defeitos ou lacunas de conformidade.",
                  guidelines: [
                    "Automação e testes diários nos relatórios",
                    "Definição de Pronto (DoD) estritamente técnica",
                    "Prevenção ativa com correções de segurança imediatas"
                  ]
                },
                {
                  id: "EXPLORER",
                  name: "Exploratory (Lean Startup)",
                  icon: "🔬",
                  desc: "Ideal para áreas de inovação e pesquisa (P&D, Marketing/Sales) com alta volatilidade e incerteza regulatória ou de mercado.",
                  guidelines: [
                    "Foco no MVP (Mínimo Produto Viável) antes de investir",
                    "Métricas de feedback real do cliente da área",
                    "Ciclos curtos para Pivotar ou Perseverar nas soluções"
                  ]
                }
              ].map((wow) => {
                const isActive = selectedWow === wow.id;
                return (
                  <button
                    type="button"
                    key={wow.id}
                    onClick={() => setSelectedWow(wow.id as any)}
                    className={`p-3.5 border rounded text-left transition-all flex flex-col justify-between cursor-pointer ${
                      isActive
                        ? "border-[#C49746] bg-amber-50/20 ring-1 ring-[#C49746] shadow-xs"
                        : "border-gray-200 hover:border-gray-300 bg-white"
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <span className="text-base">{wow.icon}</span>
                        <h4 className="text-[11px] font-bold text-gray-900 uppercase tracking-tight">{wow.name}</h4>
                      </div>
                      <p className="text-[9.5px] text-gray-550 leading-relaxed mb-3">
                        {wow.desc}
                      </p>
                    </div>
                    <div className="border-t border-dashed border-gray-205 pt-2 w-full">
                      <span className="text-[8.5px] font-mono text-[#C49746] font-extrabold block mb-1 uppercase">Práticas Chave DA:</span>
                      <ul className="space-y-1 list-none">
                        {wow.guidelines.map((g, gi) => (
                          <li key={gi} className="text-[8px] text-gray-600 leading-tight flex items-start gap-1">
                            <span className="text-indigo-600 font-bold mt-0.5">•</span>
                            <span>{g}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* AGILE STANDUP & GESTÃO À VISTA COCKPIT */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* COLUMN A: DAILY CHALLENGE & TEAM STATES (SPAN 3) */}
            <div className="lg:col-span-3 space-y-4">
              
              {/* DAILY CHALLENGE CARD */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-serif font-black uppercase text-slate-800 border-b pb-1.5 border-gray-100">
                  <Sliders size={14} className="text-indigo-600" />
                  <span>Meta Operacional do Dia</span>
                </div>
                {isEditingGoal ? (
                  <div className="space-y-1.5">
                    <textarea
                      value={goalInput}
                      onChange={(e) => setGoalInput(e.target.value)}
                      className="w-full text-xs font-sans border border-gray-300 p-2 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500 h-20"
                      placeholder="Escreva a meta operacional do dia..."
                    />
                    <div className="flex gap-1">
                      <button
                        onClick={() => saveDailyGoal(goalInput)}
                        className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-mono text-[9px] font-bold rounded-sm cursor-pointer"
                      >
                        Salvar
                      </button>
                      <button
                        onClick={() => { setGoalInput(dailyGoal); setIsEditingGoal(false); }}
                        className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-mono text-[9px] font-bold rounded-sm border cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="group relative bg-slate-50 p-2.5 border rounded border-gray-200">
                    <p className="text-[11px] font-mono text-gray-750 leading-relaxed italic pr-4">
                      "{dailyGoal}"
                    </p>
                    <button
                      onClick={() => { setGoalInput(dailyGoal); setIsEditingGoal(true); }}
                      className="absolute top-1.5 right-1.5 text-gray-400 hover:text-black transition-colors cursor-pointer"
                      title="Editar Meta"
                    >
                      <Edit size={11} className="text-indigo-600" />
                    </button>
                  </div>
                )}
              </div>

              {/* MEMBERS CAPACITY & TEAM STATUS CARD */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] space-y-3">
                <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                  <span className="text-[10px] font-black uppercase text-slate-700">Equipe &amp; Capacidade</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                </div>

                {/* Mood Toggles */}
                <div className="space-y-1 text-left">
                  <span className="text-[9px] font-mono text-gray-500 uppercase block font-bold">Clima do Time (Mood)</span>
                  <div className="grid grid-cols-3 gap-1">
                    {[
                      { id: "SUNNY", label: "☀️ Alinhado", color: "border-emerald-300 bg-emerald-50 text-emerald-800" },
                      { id: "CLOUDY", label: "⛅ Sobrecarga", color: "border-amber-300 bg-amber-50 text-amber-800" },
                      { id: "RAINY", label: "🌧️ Bloqueado", color: "border-red-300 bg-red-50 text-red-800" }
                    ].map((mood) => {
                      const isActive = teamMood === mood.id;
                      return (
                        <button
                          key={mood.id}
                          onClick={() => setTeamMood(mood.id as any)}
                          className={`p-1.5 border text-center rounded text-[9px] font-bold cursor-pointer transition-colors ${
                            isActive 
                              ? mood.color + " ring-1 ring-current font-extrabold" 
                              : "border-gray-200 bg-white hover:bg-gray-50 text-gray-500"
                          }`}
                        >
                          {mood.label.split(" ")[0]} <span className="block text-[7.5px] mt-0.5 font-sans leading-none">{mood.label.split(" ")[1]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Presence Increment Controls */}
                <div className="flex items-center justify-between pt-1">
                  <div className="space-y-0.5 text-left">
                    <span className="text-[9px] font-mono text-gray-500 uppercase block font-bold">Membros Ativos</span>
                    <span className="text-xs font-mono font-black text-gray-950">{teamCapacity} profissionais</span>
                  </div>
                  <div className="flex items-center gap-1 bg-slate-50 p-1 border border-slate-200 rounded">
                    <button
                      onClick={() => setTeamCapacity(prev => Math.max(1, prev - 1))}
                      className="w-5 h-5 bg-white border border-gray-200 hover:bg-gray-100 rounded flex items-center justify-center font-bold text-xs font-mono text-gray-750 cursor-pointer"
                    >
                      -
                    </button>
                    <button
                      onClick={() => setTeamCapacity(prev => Math.min(25, prev + 1))}
                      className="w-5 h-5 bg-white border border-gray-200 hover:bg-gray-100 rounded flex items-center justify-center font-bold text-xs font-mono text-gray-750 cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Workload Indicator Progress Meter */}
                <div className="space-y-1 pt-1.5 border-t border-gray-100 text-left">
                  <div className="flex items-center justify-between text-[9px] font-mono">
                    <span className="text-gray-500 uppercase font-black">Carga Operacional</span>
                    <span className="font-bold text-indigo-700">
                      {teamMood === "SUNNY" ? "Ativos 60%" : teamMood === "CLOUDY" ? "Saturação 85%" : "Alarme 95%"}
                    </span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        teamMood === "SUNNY" ? "bg-emerald-500" : teamMood === "CLOUDY" ? "bg-amber-500" : "bg-rose-500"
                      }`}
                      style={{ width: teamMood === "SUNNY" ? "60%" : teamMood === "CLOUDY" ? "85%" : "95%" }}
                    ></div>
                  </div>
                  <p className="text-[8.5px] text-slate-500 leading-tight">
                    {teamMood === "SUNNY" ? "Processo equilibrado; os recursos estão rodando sem retenção." : teamMood === "CLOUDY" ? "Recursos sobrecarregados; risco iminente de desvios e atrasos no lote." : "Nível crítico de impedimentos! Necessária intervenção imediata para reajuste."}
                  </p>
                </div>

              </div>

            </div>

            {/* COLUMN B: DAILY STANDUP IMPEDIMENT LOG (SPAN 4) */}
            <div className="lg:col-span-4 space-y-4">
              <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] space-y-3">
                <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                  <div className="flex items-center gap-1.5">
                    <AlertTriangle size={15} className="text-amber-500" />
                    <h3 className="font-serif text-xs font-black uppercase text-slate-800">
                      Log de Impedimentos &amp; Bloqueios
                    </h3>
                  </div>
                  <span className="text-[9.5px] font-mono font-bold bg-amber-500/10 text-amber-800 border border-amber-500/20 px-2 py-0.5 rounded-sm">
                    {impediments.filter(i => i.status === "OPEN").length} Abertos
                  </span>
                </div>

                {/* New Blocker Manual Input Form */}
                <form onSubmit={handleAddImpediment} className="bg-slate-50 p-2.5 border rounded border-gray-200 text-[10px] space-y-2 text-left">
                  <span className="text-[8.5px] font-mono font-bold text-gray-500 uppercase block">Cadastrar Novo Impedimento</span>
                  <div className="space-y-1.5">
                    <input
                      type="text"
                      value={newImpTitle}
                      onChange={(e) => setNewImpTitle(e.target.value)}
                      placeholder="Ex: API instável / Falta pessoal capacitado..."
                      className="w-full bg-white border border-gray-300 p-1.5 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[10.5px] font-sans"
                    />
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        type="text"
                        value={newImpOwner}
                        onChange={(e) => setNewImpOwner(e.target.value)}
                        placeholder="Atribuído (Ex: João)"
                        className="bg-white border border-gray-300 p-1.5 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                      />
                      <select
                        value={newImpSeverity}
                        onChange={(e) => setNewImpSeverity(e.target.value as any)}
                        className="bg-white border border-gray-300 p-1 rounded focus:outline-none cursor-pointer font-sans"
                      >
                        <option value="HIGH">🚨 Gravidade: Alta</option>
                        <option value="MEDIUM">⚠️ Gravidade: Média</option>
                        <option value="LOW">🔍 Gravidade: Baixa</option>
                      </select>
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-mono font-bold py-1 px-2 rounded-xs flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <Plus size={11} /> Adicionar &amp; Gerar Prática DA
                    </button>
                  </div>
                </form>

                {/* Impediments list */}
                <div className="space-y-2.5 overflow-y-auto max-h-[300px] pr-1">
                  {impediments.length === 0 ? (
                     <div className="p-6 border border-dashed border-gray-200 rounded text-center flex flex-col justify-center items-center text-gray-405">
                       <CheckCircle2 size={22} className="text-emerald-500 mb-1" />
                       <p className="text-[10px] font-sans">Sem barreiras ativas para esta área!</p>
                     </div>
                  ) : (
                    impediments.map((imp) => {
                      const isOpen = imp.status === "OPEN";
                      return (
                        <div
                          key={imp.id}
                          className={`p-2.5 border rounded transition-all text-left space-y-2 ${
                            isOpen 
                              ? imp.severity === "HIGH" 
                                ? "border-red-200 bg-red-50/10" 
                                : "border-amber-200 bg-amber-50/5"
                              : "border-gray-200 bg-gray-50/50 opacity-75"
                          }`}
                        >
                          <div className="flex justify-between items-start gap-1.5">
                            <span className={`px-1.5 py-0.5 rounded-xs text-[7.5px] font-mono leading-none font-black tracking-wider uppercase border text-white ${
                              isOpen 
                                ? imp.severity === "HIGH" 
                                  ? "bg-red-650 border-red-700" 
                                  : "bg-amber-600 border-amber-700"
                                : "bg-gray-400 border-gray-550"
                            }`}>
                              {isOpen ? imp.severity === "HIGH" ? "MISTAKE-PROOF/CRITICAL" : "BLOCKER" : "RESOLVIDO"}
                            </span>
                            <div className="flex items-center gap-0.5">
                              <button
                                type="button"
                                onClick={() => toggleSolveImpediment(imp.id)}
                                className={`px-1.5 py-0.5 text-[8.5px] font-mono font-bold rounded-sm cursor-pointer border ${
                                  isOpen 
                                    ? "bg-white hover:bg-emerald-50 text-emerald-700 border-emerald-200" 
                                    : "bg-white text-gray-505 border-gray-200"
                                }`}
                              >
                                {isOpen ? "✓ Resolver" : "Reabrir"}
                              </button>
                              <button
                                type="button"
                                onClick={() => deleteImpediment(imp.id)}
                                className="p-1 hover:bg-rose-50 text-gray-400 hover:text-rose-600 rounded cursor-pointer"
                              >
                                <Trash2 size={10} />
                              </button>
                            </div>
                          </div>

                          <div>
                            <h4 className={`text-[10px] font-bold tracking-tight leading-tight uppercase ${isOpen ? "text-gray-900" : "text-gray-450 line-through"}`}>
                              {imp.title}
                            </h4>
                            <p className="text-[8.5px] font-mono text-gray-500 mt-1">
                              👉 Responsável: <strong className="text-gray-755">{imp.owner}</strong>
                            </p>
                          </div>

                          {isOpen && (
                            <p className="text-[9px] bg-indigo-50/30 border border-indigo-100 p-2 rounded-xs font-serif text-indigo-950 leading-normal italic">
                              {imp.daGuideline}
                            </p>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            </div>

            {/* COLUMN C: ACTIVITIES & TASKS DAILY STANDUP BOARD PER PROCESS (SPAN 5) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white border-2 border-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-gray-100 pb-2">
                  <div className="flex items-center gap-1.5">
                    <LayoutGrid size={15} className="text-indigo-600" />
                    <h3 className="font-serif text-xs font-black uppercase text-slate-800">
                      Rondada de Atividades &amp; Tarefas (Gestão à Vista)
                    </h3>
                  </div>
                  <span className="text-[9px] font-mono font-bold text-indigo-700 uppercase bg-indigo-50 px-2 py-0.5 rounded-sm">
                    {CORPORATE_AREAS.find(a => a.id === selectedArea)?.name.split(",")[0]}
                  </span>
                </div>

                {/* Process hierarchy container */}
                <div className="space-y-4 overflow-y-auto max-h-[500px] pr-1">
                  {((processesByArea ? (processesByArea[selectedArea] || []) : steps).length === 0) ? (
                    <div className="p-10 border-2 border-dashed border-gray-250 rounded text-center flex flex-col justify-center items-center text-gray-400">
                      <Sliders size={26} className="text-gray-300 mb-2 animate-bounce" />
                      <p className="text-[11px] font-bold font-mono text-gray-700">Nenhum processo mapeado nesta área.</p>
                      <p className="text-[9.5px] text-gray-505 max-w-xs mt-1">Você pode mapear os processos e tempos desta área alterando o activeArea no Mapeador de Layout na fase Medir.</p>
                    </div>
                  ) : (
                    (processesByArea ? (processesByArea[selectedArea] || []) : steps).map((step) => {
                      const tasksForStep = areaTasks[step.id] || [];
                      const total = tasksForStep.length;
                      const done = tasksForStep.filter(t => t.status === "DONE").length;
                      const progressPct = total > 0 ? (done / total) * 100 : 0;

                      return (
                        <div key={step.id} className="bg-[#FAF8F5] border border-gray-205 rounded p-3 text-left space-y-2.5 hover:border-gray-300 transition-all">
                          
                          {/* Step Title & Progress bar */}
                          <div className="border-b border-gray-150 pb-1.5 text-left animate-fade-in">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <h4 className="text-[10px] font-serif font-black uppercase text-slate-850 leading-tight">
                                  {step.name}
                                </h4>
                                <span className="text-[8.5px] text-indigo-600 font-mono tracking-tight uppercase block mt-0.5">
                                  👤 Dono do Posto: <strong>{step.resource} (x{step.resourceCount || 1})</strong>
                                </span>
                              </div>
                              <span className="text-[9px] font-mono font-bold shrink-0 text-[#C49746] bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                                {done}/{total} Done ({Math.round(progressPct)}%)
                              </span>
                            </div>
                            <div className="h-1 bg-gray-200 mt-1.5 rounded-full overflow-hidden">
                              <div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${progressPct}%` }}></div>
                            </div>
                          </div>

                          {/* Tasks Checkbox list */}
                          <div className="space-y-1.5 text-left">
                            {tasksForStep.length === 0 ? (
                              <p className="text-[8.5px] text-gray-400 font-mono italic">Sem tarefas ativas diárias cadastradas.</p>
                            ) : (
                              tasksForStep.map((task) => (
                                <div 
                                  key={task.id} 
                                  className={`p-2 border rounded-xs transition-colors text-[9.5px] space-y-1.5 ${
                                    task.isBlocked 
                                      ? "bg-red-50/10 border-red-200" 
                                      : task.status === "DONE" 
                                        ? "bg-emerald-50/5 border-emerald-100 opacity-75" 
                                        : "bg-white border-gray-200 hover:bg-slate-50"
                                  }`}
                                >
                                  <div className="flex justify-between items-start gap-1.5">
                                    <div className="flex items-start gap-1.5">
                                      <input 
                                        type="checkbox"
                                        checked={task.status === "DONE"}
                                        onChange={() => handleUpdateTaskStatus(step.id, task.id, task.status === "DONE" ? "BACKLOG" : "DONE")}
                                        className="mt-0.5 w-3.5 h-3.5 border border-gray-300 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                      />
                                      <span className={`font-semibold leading-normal ${task.status === "DONE" ? "text-gray-400 line-through" : "text-gray-800"}`}>
                                        {task.title}
                                      </span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteTaskFromStep(step.id, task.id)}
                                      className="p-0.5 text-gray-300 hover:text-red-500 rounded transition-colors cursor-pointer text-xs leading-none"
                                      title="remover tarefa"
                                    >
                                      ✕
                                    </button>
                                  </div>

                                  <div className="flex flex-wrap items-center justify-between gap-1 pt-1.5 border-t border-dotted border-gray-150">
                                    <span className="text-[8px] font-mono text-gray-500">
                                      👤 {task.assignedTo}
                                    </span>
                                    <div className="flex items-center gap-1 shrink-0">
                                      
                                      {/* Status Swappers */}
                                      <select
                                        value={task.status}
                                        onChange={(e) => handleUpdateTaskStatus(step.id, task.id, e.target.value as any)}
                                        className="border border-gray-250 text-[7.5px] font-mono text-gray-600 bg-white rounded-xs focus:outline-none p-0.5 h-4 cursor-pointer font-sans"
                                      >
                                        <option value="BACKLOG">Backlog</option>
                                        <option value="WIP">Em Progresso</option>
                                        <option value="DONE">Concluída</option>
                                      </select>

                                      {/* Block button */}
                                      <button
                                        type="button"
                                        onClick={() => handleToggleTaskBlocked(step.id, task.id, "Empedimento estocástico reportado pelo supervisor")}
                                        className={`px-1 rounded-xs text-[7.5px] font-mono font-bold h-4 flex items-center gap-0.5 border cursor-pointer ${
                                          task.isBlocked 
                                            ? "bg-red-650 text-white border-red-750" 
                                            : "bg-white text-rose-600 border-rose-300 hover:bg-rose-50"
                                        }`}
                                      >
                                        {task.isBlocked ? "🚨 Bloqueada" : "⚠️ Bloquear"}
                                      </button>

                                    </div>
                                  </div>

                                  {task.isBlocked && (
                                    <div className="p-1 border border-red-200 bg-red-50/20 text-[8px] text-rose-800 font-mono rounded-xs leading-tight">
                                      Impedimento: {task.blockReason}
                                    </div>
                                  )}

                                </div>
                              ))
                            )}
                          </div>

                          {/* Add Task Inline Form */}
                          <form onSubmit={(e) => handleAddTaskToStep(step.id, e)} className="flex gap-1 pt-1 border-t border-dashed border-gray-200">
                            <input
                              type="text"
                              value={formTaskTitle[step.id] || ""}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormTaskTitle(prev => ({ ...prev, [step.id]: val }));
                              }}
                              placeholder="Adicionar tarefa..."
                              className="flex-grow bg-white border border-gray-300 p-1 rounded-xs text-[9.5px] font-sans focus:outline-none focus:ring-1 focus:ring-indigo-500"
                            />
                            <input
                              type="text"
                              value={formTaskAssignee[step.id] || ""}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormTaskAssignee(prev => ({ ...prev, [step.id]: val }));
                              }}
                              placeholder="Responsável"
                              className="w-20 bg-white border border-gray-300 p-1 rounded-xs text-[9.5px] font-sans focus:outline-none focus:ring-1 focus:ring-indigo-500"
                            />
                            <button
                              type="submit"
                              className="bg-[#1A1A1A] hover:bg-black text-white px-2.5 py-1 rounded-xs text-[9px] font-mono font-bold cursor-pointer transition-colors"
                            >
                              +
                            </button>
                          </form>

                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            </div>

          </div>

        </div>
      )}

      {/* CREATE BACKLOG CARD MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border-2 border-slate-950 p-6 max-w-md w-full shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-4">
            
            <div className="flex justify-between items-center pb-2 border-b border-gray-200">
              <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-gray-900">
                Lançar Lote de Produção no Backlog
              </h3>
              <button 
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-black font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCardInForm} className="space-y-4 text-xs font-sans">
              
              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Título do Lote / Código</label>
                <input 
                  type="text" 
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Ex: Lote SMT Placa Master v3"
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Posto Destino Inicial</label>
                <select 
                  value={formStepId}
                  onChange={(e) => setFormStepId(e.target.value)}
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                >
                  <option value="">Selecione a Etapa Asociada...</option>
                  {steps.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.resource})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Prioridade do Lote</label>
                <select 
                  value={formPriority}
                  onChange={(e) => setFormPriority(e.target.value as any)}
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="LOW">Baixa prioridade (Green Belt)</option>
                  <option value="MEDIUM">Padrão Geral (Black Belt)</option>
                  <option value="HIGH">Crítico de Urgência (Master Black Belt)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Descrição Operacional do Lote</label>
                <textarea 
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Insira notas de controle, número de lote original ou requisitos especiais de rendimento SMT."
                  rows={3}
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-sm font-bold font-mono text-[10px]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-sm font-bold font-mono text-[10px]"
                >
                  Lançar no Kanban
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* EDIT BACKLOG CARD MODAL */}
      {showEditModal && editingCard && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border-2 border-slate-950 p-6 max-w-md w-full shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-4">
            
            <div className="flex justify-between items-center pb-2 border-b border-gray-200">
              <div className="text-left">
                <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-gray-900">
                  Editar Lote de Produção
                </h3>
                <span className="text-[10px] font-mono text-indigo-650 font-bold block">
                  Identificador: {editingCard.code}
                </span>
              </div>
              <button 
                onClick={() => setShowEditModal(false)}
                className="text-gray-400 hover:text-black font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEditInForm} className="space-y-4 text-xs font-sans text-left">
              
              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Título do Lote / Código</label>
                <input 
                  type="text" 
                  value={editFormTitle}
                  onChange={(e) => setEditFormTitle(e.target.value)}
                  placeholder="Ex: Lote SMT Placa Master v3"
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Posto / Mapeamento</label>
                  <select 
                    value={editFormStepId}
                    onChange={(e) => setEditFormStepId(e.target.value)}
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                    required
                  >
                    <option value="">Selecione...</option>
                    {steps.map(s => (
                      <option key={s.id} value={s.id}>{s.name.split(" - ")[0]}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Nível de Prioridade</label>
                  <select 
                    value={editFormPriority}
                    onChange={(e) => setEditFormPriority(e.target.value as any)}
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white font-mono"
                  >
                    <option value="LOW">Baixa (Green Belt)</option>
                    <option value="MEDIUM">Média (Black Belt)</option>
                    <option value="HIGH">Alta (Master Black Belt)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Duração (Minutos)</label>
                  <input 
                    type="number" 
                    value={editFormMinutesCost}
                    onChange={(e) => setEditFormMinutesCost(Number(e.target.value))}
                    min={1}
                    max={300}
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white font-mono"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Status de Qualidade</label>
                  <select 
                    value={editFormQualityStatus}
                    onChange={(e) => setEditFormQualityStatus(e.target.value as any)}
                    className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white font-mono"
                  >
                    <option value="UNKNOWN">Não Testado</option>
                    <option value="PASSED">Aprovado (Yield OK)</option>
                    <option value="DEFECT_DETECTED">Falha (Peça Refugo)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Descrição e Observações LSS</label>
                <textarea 
                  value={editFormDescription}
                  onChange={(e) => setEditFormDescription(e.target.value)}
                  placeholder="Insira notas operacionais de rendimento."
                  rows={3}
                  className="w-full border border-gray-300 px-3 py-2 rounded-sm text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-white"
                />
              </div>

              <div className="flex gap-2 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-sm font-bold font-mono text-[10px]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-sm font-bold font-mono text-[10px]"
                >
                  Salvar Alterações
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}

interface KanbanCardItemProps {
  key?: React.Key;
  card: KanbanCard;
  steps: ProcessStep[];
  onDragStart: (e: React.DragEvent, cardId: string) => void;
  onMove: (cardId: string, col: "PLANNED" | "EXECUTING" | "WAITING_TEST") => void;
  onDelete: (cardId: string, e: React.MouseEvent) => void;
  onEdit: (card: KanbanCard) => void;
  onQualityCheck: (cardId: string) => void;
}

function KanbanCardItem({ card, steps, onDragStart, onMove, onDelete, onEdit, onQualityCheck }: KanbanCardItemProps) {
  
  const getPriorityColor = (p: "LOW" | "MEDIUM" | "HIGH") => {
    switch(p) {
      case "HIGH": return "bg-red-50 text-red-700 border-red-200";
      case "MEDIUM": return "bg-amber-50 text-amber-700 border-amber-200";
      case "LOW": return "bg-slate-50 text-slate-700 border-slate-200";
    }
  };

  const currentStep = steps.find(s => s.id === card.stepId);
  const currentYield = currentStep ? (currentStep.yieldRate * 100).toFixed(0) : "95";

  return (
    <div 
      draggable
      onDragStart={(e) => onDragStart(e, card.id)}
      onDoubleClick={() => onEdit(card)}
      className="bg-white border-2 border-slate-900 p-3 shadow-sm hover:shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] transition-all cursor-grab active:cursor-grabbing text-left space-y-2.5 relative group"
      title="Dê um clique duplo para editar este lote!"
    >
      
      {/* Top Details & Delete icon */}
      <div className="flex items-start justify-between">
        <span className="font-mono text-[9px] font-bold text-gray-400 uppercase">
          {card.code}
        </span>
        <div className="flex items-center gap-1.5">
          <button 
            onClick={(e) => { e.stopPropagation(); onEdit(card); }}
            className="text-gray-300 hover:text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer p-0.5"
            title="Editar lote (ou dê dois cliques)"
          >
            <Edit size={10} />
          </button>
          <button 
            onClick={(e) => onDelete(card.id, e)}
            className="text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer p-0.5"
            title="Excluir Lote"
          >
            <Trash2 size={11} />
          </button>
        </div>
      </div>

      {/* Title */}
      <div>
        <h4 className="font-serif text-[11.5px] font-bold text-gray-900 uppercase tracking-tight">
          {card.title}
        </h4>
        <span className="text-[10px] text-gray-500 font-sans block mt-0.5">
          👉 Etapa: <strong className="text-[#C49746]">{card.stepName}</strong>
        </span>
      </div>

      {/* Badges row */}
      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
        <span className={`px-2 py-0.5 rounded-sm text-[8px] font-mono font-bold uppercase tracking-wider border ${getPriorityColor(card.priority)}`}>
          {card.priority === "HIGH" ? "M. Black Belt Priority" : card.priority === "MEDIUM" ? "Black Belt" : "Green Belt"}
        </span>
        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 border border-gray-200 rounded-sm text-[8px] font-mono flex items-center gap-1">
          <Clock size={8} /> {card.minutesCost} min
        </span>
      </div>

      {/* Description text */}
      <p className="text-[10px] text-gray-600 leading-normal font-sans pt-0.5">
        {card.description}
      </p>

      {/* Quality indicator / Live Simulation Check Actions */}
      <div className="border-t border-gray-100 pt-2 flex items-center justify-between text-[10px]">
        <div>
          {card.qualityStatus === "UNKNOWN" && (
            <span className="text-gray-400 font-mono italic">Aguardando Teste</span>
          )}
          {card.qualityStatus === "PASSED" && (
            <span className="text-emerald-700 font-mono font-bold flex items-center gap-1 bg-emerald-50 px-1.5 py-0.5 rounded-xs">
              <CheckCircle2 size={10} /> Yield OK ({currentYield}%)
            </span>
          )}
          {card.qualityStatus === "DEFECT_DETECTED" && (
            <span className="text-red-700 font-mono font-bold flex items-center gap-1 bg-red-50 px-1.5 py-0.5 rounded-xs">
              <AlertTriangle size={10} /> FALHA NO TESTE
            </span>
          )}
        </div>

        {/* Quick actions for touch screens or ease of toggle */}
        <div className="flex items-center gap-1">
          {card.column === "WAITING_TEST" && card.qualityStatus === "UNKNOWN" && (
            <button
              onClick={() => onQualityCheck(card.id)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[8px] font-bold px-1.5 py-0.5 rounded-xs flex items-center gap-0.5 cursor-pointer transition-all"
              title="Testar contra Yield real"
            >
              <Play size={8} /> Qualidade
            </button>
          )}

          {/* Fallback column buttons to move card easily */}
          <select 
            value={card.column}
            onChange={(e) => onMove(card.id, e.target.value as any)}
            className="border border-gray-300 text-[8px] font-mono text-gray-600 bg-white rounded-xs focus:outline-none p-0.5 cursor-pointer"
          >
            <option value="PLANNED">Ir p/ Planejado</option>
            <option value="EXECUTING">Ir p/ Em Execução</option>
            <option value="WAITING_TEST">Ir p/ Teste</option>
          </select>
        </div>
      </div>

    </div>
  );
}
