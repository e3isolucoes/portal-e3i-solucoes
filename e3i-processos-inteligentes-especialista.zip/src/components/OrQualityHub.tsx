import React, { useState, useEffect } from "react";
import { 
  Cpu, 
  Settings2, 
  HelpCircle, 
  TrendingUp, 
  Award, 
  ArrowRight, 
  ChevronRight, 
  Play, 
  Activity, 
  Sparkles, 
  AlertTriangle, 
  Check, 
  BarChart2, 
  Calculator, 
  Plus, 
  Trash2,
  Bookmark
} from "lucide-react";
import { ProcessStep, ProcessMetrics } from "../types";

interface OrQualityHubProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  stats: ProcessMetrics;
  arrivalRate: number;
}

// Interfaces for our OR and Quality states
interface FmeaRow {
  stepId: string;
  stepName: string;
  failureMode: string;
  effect: string;
  severity: number; // 1-10
  cause: string;
  occurrence: number; // 1-10
  detection: number; // 1-10
  action: string;
}

interface FishboneCause {
  method: string[];
  machine: string[];
  manpower: string[];
  material: string[];
  measurement: string[];
  environment: string[];
}

const getLpProductLabels = (category: string) => {
  switch (category) {
    case "financeiro":
      return {
        x1Name: "Faturas Simples (Padrão)",
        x2Name: "Faturas Complexas (Retenção/Divergentes)",
        x1Short: "Faturas Simples (x1)",
        x2Short: "Faturas Complexas (x2)",
        unit: "faturas"
      };
    case "contabil":
      return {
        x1Name: "Conciliações de Baixa Complexidade",
        x2Name: "Consolidações Multi-subsidiárias / Ajustes",
        x1Short: "Conciliações Simples (x1)",
        x2Short: "Consolidações Complexas (x2)",
        unit: "reconciliações"
      };
    case "fiscal":
      return {
        x1Name: "Saneamento de Notas Padrão",
        x2Name: "Auditoria SPED / Cruzamento de Retenções",
        x1Short: "Saneamento Simples (x1)",
        x2Short: "Revisão SPED Complexa (x2)",
        unit: "documentos"
      };
    default:
      return {
        x1Name: "Notebook Standard (x1)",
        x2Name: "Notebook Pro (x2)",
        x1Short: "Volume Standard (x1)",
        x2Short: "Volume Pro (x2)",
        unit: "unidades"
      };
  }
};

export default function OrQualityHub({ steps, setSteps, stats, arrivalRate }: OrQualityHubProps) {
  const [activeSubTab, setActiveSubTabRaw] = useState<"OR" | "QUALITY">("OR");

  const savedScrollY = React.useRef<number>(0);

  const setActiveSubTab = (value: any) => {
    savedScrollY.current = window.scrollY;
    if (typeof value === "function") {
      setActiveSubTabRaw((prev) => value(prev));
    } else {
      setActiveSubTabRaw(value);
    }
  };

  useEffect(() => {
    if (savedScrollY.current > 0) {
      const targetScroll = savedScrollY.current;
      window.scrollTo(0, targetScroll);
      let count = 0;
      const restore = () => {
        window.scrollTo(0, targetScroll);
        count++;
        if (count < 15) {
          requestAnimationFrame(restore);
        }
      };
      requestAnimationFrame(restore);
    }
  }, [activeSubTab]);
  
  // States for OR view
  const [selectedOrModel, setSelectedOrModel] = useState<"LP" | "QUEUE" | "MARKOV" | "TOC">("LP");
  
  // Programação Linear Inputs
  const [lpProfitX1, setLpProfitX1] = useState<number>(450); // Lucro Notebook Standard
  const [lpProfitX2, setLpProfitX2] = useState<number>(750); // Lucro Notebook Pro
  const [lpShiftHours, setLpShiftHours] = useState<number>(40); // Horas totais turno semanal
  const [lpStandardCoeffs, setLpStandardCoeffs] = useState<number[]>([12, 5, 4, 10, 8]); // Tempo Standard em min por etapa
  const [lpProCoeffs, setLpProCoeffs] = useState<number[]>([18, 10, 8, 15, 12]); // Tempo Pro em min por etapa
  const [lpMaxX1, setLpMaxX1] = useState<number>(150); // Limite de mercado Standard
  const [lpMaxX2, setLpMaxX2] = useState<number>(100); // Limite de mercado Pro

  // Teoria das Filas Otimização Econômica Inputs
  const [hourlyOperatorCost, setHourlyOperatorCost] = useState<number>(180); // R$ por hora / operador
  const [hourlyWipPenaltyCost, setHourlyWipPenaltyCost] = useState<number>(420); // R$ por hora / unidade de WIP

  // Cadeia de Markov transições
  const [markovP12, setMarkovP12] = useState<number>(0.08); // Ideal -> Degradado
  const [markovP23, setMarkovP23] = useState<number>(0.15); // Degradado -> Manutenção
  const [markovP31, setMarkovP31] = useState<number>(0.90); // Manutenção -> Ideal
  const [markovP14, setMarkovP14] = useState<number>(0.01); // Ideal -> Parada Crítica (Falha)
  const [markovP43, setMarkovP43] = useState<number>(0.80); // Parada Crítica -> Manutenção

  // States for Quality & Lean View
  const [selectedQualityTool, setSelectedQualityTool] = useState<"VSM" | "FMEA" | "ISHIKAWA" | "5S">("VSM");

  // FMEA Table Data initialized with pre-set entries base on SMT scenario
  const [fmeaRows, setFmeaRows] = useState<FmeaRow[]>([
    {
      stepId: "step-1",
      stepName: "Impressão SMT & Placer",
      failureMode: "Ecesso ou falta de pasta de solda no stencil",
      effect: "Pistas em curto circuito ou circuitos abertos",
      severity: 8,
      cause: "Variação na pressão mecânica útil do raspador",
      occurrence: 5,
      detection: 6,
      action: "Adotar sistema de raspagem pneumática proporcional calibrada semanal."
    },
    {
      stepId: "step-2",
      stepName: "Forno de Refluxo Térmico",
      failureMode: "Desvio na zona de pré-aquecimento ideal",
      effect: "Microfissuras térmicas ocultas internas nos componentes de controle",
      severity: 9,
      cause: "Descalibração estática nos termopares de zona",
      occurrence: 3,
      detection: 7,
      action: "Instalar placa de teste Kic Thermoprofiler com log diário automático."
    },
    {
      stepId: "step-3",
      stepName: "Estação Inspeção AOI & Retoque",
      failureMode: "Falso positivo / Alarme óptico ignorado",
      effect: "Envio de placas com soldas falhas para integração mecânica",
      severity: 7,
      cause: "Variação de iluminação ambiental externa sobre a câmera",
      occurrence: 6,
      detection: 4,
      action: "Acoplar domo de isolamento contra raios solares e calibrar IA de visão."
    },
    {
      stepId: "step-4",
      stepName: "Montagem Integrada Mecânica",
      failureMode: "Torqueamento excessivo frontal do gabinete",
      effect: "Rachadura oculta no chassi plástico ABS de fixação",
      severity: 6,
      cause: "Parafusadeira pneumática desregulada sem calibração digital",
      occurrence: 4,
      detection: 5,
      action: "Mapear o aperto com parafusadeiras digitais dotadas de transdutor mecânico."
    },
    {
      stepId: "step-5",
      stepName: "Teste Funcional & Embalagem",
      failureMode: "Fio de aterramento ESD da bancada desconectado",
      effect: "Descarga eletrostática silenciosa danifica o CMOS do circuito integrado",
      severity: 10,
      cause: "Rompimento do cabo helicoidal por fadiga física",
      occurrence: 2,
      detection: 9,
      action: "Substituir por pulseiras ESD monitoradas online com bip sonoro de perda."
    }
  ]);

  // Ishikawa Diagram Causes & Custom Cause State
  const [selectedIshikawaIssue, setSelectedIshikawaIssue] = useState<string>("Elevado Retrabalho na Bancada AOI");
  const [ishikawaCauses, setIshikawaCauses] = useState<FishboneCause>({
    method: ["Falta de padrão visual na junta SMD", "Velocidade excessiva do raspador na fase prévia"],
    machine: ["Desgaste no feeder SMT de componentes", "Lente da câmera AOI obstruída por fluxo residual"],
    manpower: ["Operadores com fadiga por turnos dobrados", "Falta de treinamento formal em retórica IPC-A-610"],
    material: ["Pasta de solda armazenada em geladeira descalibrada", "Placas virgens pcb com oxidação de borda"],
    measurement: ["Falta de gabarito estático padrão", "Instrumentos de medição sem certificado de calibração RNC"],
    environment: ["Variação de umidade ambiente controlada na sala", "Contaminação por micropartículas (excesso de pó)"]
  });
  const [newCauseText, setNewCauseText] = useState("");
  const [newCauseCategory, setNewCauseCategory] = useState<keyof FishboneCause>("method");

  // 5S Checklist values (1 to 5)
  const [seiriScore, setSeiriScore] = useState<number>(3);
  const [seitonScore, setSeitonScore] = useState<number>(4);
  const [seisoScore, setSeisoScore] = useState<number>(4);
  const [seiketsuScore, setSeiketsuScore] = useState<number>(3);
  const [shitsukeScore, setShitsukeScore] = useState<number>(5);

  // Identify current template active
  const detectTemplateCategory = (): "manufatura" | "financeiro" | "contabil" | "fiscal" => {
    if (!steps || steps.length === 0) return "manufatura";
    const firstStepName = steps[0].name.toLowerCase();
    if (firstStepName.includes("triagem") || firstStepName.includes("recebimento e registro") || firstStepName.includes("contas a pagar")) return "financeiro";
    if (firstStepName.includes("conciliação") || firstStepName.includes("bancária") || firstStepName.includes("razões")) return "contabil";
    if (firstStepName.includes("saneamento") || firstStepName.includes("importação") || firstStepName.includes("regula") || firstStepName.includes("fiscal")) return "fiscal";
    return "manufatura";
  };

  const detectedCategory = detectTemplateCategory();
  const lpLabels = getLpProductLabels(detectedCategory);
  const categoryRef = React.useRef<string>("");

  useEffect(() => {
    if (categoryRef.current === detectedCategory) return;
    categoryRef.current = detectedCategory;

    // Reset weights
    if (detectedCategory === "financeiro") {
      setLpProfitX1(120); // Lucro unitário simples
      setLpProfitX2(355); // Lucro complexas
      setLpStandardCoeffs([5, 6, 2, 3, 4]);
      setLpProCoeffs([12, 16, 8, 10, 10]);
      setFmeaRows([
        {
          stepId: "step-1",
          stepName: "Triagem e Registro",
          failureMode: "Erros de digitação ou OCR inacurado",
          effect: "Lançamento contábil e valores incorretos no ERP",
          severity: 8,
          cause: "Baixa qualidade de PDF digitalizado ou falta de padrão",
          occurrence: 6,
          detection: 4,
          action: "Implementar validador automático de CNPJ e CPF contra banco cadastral."
        },
        {
          stepId: "step-2",
          stepName: "Reconciliação Three-Way Matching",
          failureMode: "Divergência de frete ou quantidade sem conciliação",
          effect: "Pagamento de faturas indevidas ou interrupções de fluxo de compras",
          severity: 9,
          cause: "Falta de sincronia de notas com o recebimento das docas",
          occurrence: 5,
          detection: 7,
          action: "Centralizar o XML faturado via SEFAZ com validação física antecipada."
        },
        {
          stepId: "step-3",
          stepName: "Aprovação de Alçada",
          failureMode: "Gerente em viagem ou sem senha de rede ativa",
          effect: "Faturamento expira gerando multas setoriais por atraso",
          severity: 6,
          cause: "Aprovação restrita a telas do ERP sem aplicativo móvel",
          occurrence: 7,
          detection: 3,
          action: "Habilitar aprovação simplificada por push notification e e-mail corporativo."
        },
        {
          stepId: "step-4",
          stepName: "Agendamento Tesouraria",
          failureMode: "Boleto falsificado de favorecido divergente (Fraude bancária)",
          effect: "Rombo de caixa corporativo de alta materialidade de perda",
          severity: 10,
          cause: "Alteração manual de código de barras ou dados cadastrais em boleto impresso",
          occurrence: 2,
          detection: 8,
          action: "Auditória preventiva eletrônica comparando com a DDA e Receita Federal."
        },
        {
          stepId: "step-5",
          stepName: "Conciliação e Arquivo",
          failureMode: "Baixa com valor aproximado e diferença de centavos",
          effect: "Inconsistência crônica no saldo de conciliação de contas de bancos",
          severity: 5,
          cause: "Arredondamentos tributários e tarifas não integrados no retorno bancário",
          occurrence: 4,
          detection: 9,
          action: "Registrar arredondamentos direto em variação cambial/despesas tributárias."
        }
      ]);
      setSelectedIshikawaIssue("Atrasos Crônicos no Ciclo de Contas a Pagar (AP)");
      setIshikawaCauses({
        method: ["Falta de padrão visual na triagem inicial", "Esquemas de aprovação complexos de muitas alçadas"],
        machine: ["ERP lento e sem API de conexão", "Inexistência de leitura robotizada de notas fiscais"],
        manpower: ["Equipe cansada trabalhando no limite", "Falta de reciclagem em regras do ICMS municipal"],
        material: ["XMLs com dados corrompidos", "Ausência do número da ordem PO no corpo da fatura"],
        measurement: ["Falta de medidores de lead time por analista", "Falta de monitoramento de faturas próximas a vencer"],
        environment: ["Escritórios sem sincronismo operacional", "Acúmulo de notas manuais de serviços sem padrão digital"]
      });
    } else if (detectedCategory === "contabil") {
      setLpProfitX1(250); // Simples
      setLpProfitX2(600); // Complexas
      setLpStandardCoeffs([6, 8, 8, 4, 3]);
      setLpProCoeffs([15, 20, 25, 12, 10]);
      setFmeaRows([
        {
          stepId: "step-1",
          stepName: "Conciliação Bancária",
          failureMode: "Itens corporativos não conciliados acumulados de meses",
          effect: "Distorções no demonstrativo do balanço patrimonial perante acionistas",
          severity: 8,
          cause: "Depósitos não identificados e falta de follow-up com o comercial",
          occurrence: 6,
          detection: 5,
          action: "Parametrizar conta transitória zerada no dia D para depósitos flutuantes."
        },
        {
          stepId: "step-2",
          stepName: "Lançamento de Provisões",
          failureMode: "Omissão ou erro no reajuste de provisões de faturamento/RH",
          effect: "Resultado operacional subavaliado ou inflado artificialmente no DRE",
          severity: 9,
          cause: "Demora no repasse de horas de folha do Departamento Pessoal",
          occurrence: 4,
          detection: 6,
          action: "Congelar envio de dados no dia 25 e rodar provisões automáticas no ERP."
        },
        {
          stepId: "step-3",
          stepName: "Reconciliação Intercompany",
          failureMode: "Saldos recíprocos de fusões intergrupo não coincidem",
          effect: "Balanço societário bloqueado por auditoria reguladora",
          severity: 9,
          cause: "Utilização de taxas PTAX e taxas de conversão de câmbio difusas",
          occurrence: 5,
          detection: 7,
          action: "Estipular taxa PTAX única padrão diária compartilhada na intranet."
        },
        {
          stepId: "step-4",
          stepName: "Revisão de Balancetes",
          failureMode: "Gravação incorreta de despesas em contas correntes do ativo fixo",
          effect: "Cálculos distorcidos de depreciação de bens incorretos",
          severity: 7,
          cause: "Falta de validação primária cadastral do analista",
          occurrence: 5,
          detection: 8,
          action: "Travas estáticas de contas-contábeis versus centros de custo no sistema."
        },
        {
          stepId: "step-5",
          stepName: "Encerramento e Demonstrações",
          failureMode: "Registro manual no razão contábil pós-período bloqueado",
          effect: "Distorção sistêmica de saldos de meses anteriores fechados",
          severity: 10,
          cause: "Usuários compartilhando credenciais de administrador de banco de dados",
          occurrence: 2,
          detection: 9,
          action: "Registrar travas rígidas de ledger no SAP com liberação em duas mãos."
        }
      ]);
      setSelectedIshikawaIssue("Atraso Crônico no Encerramento de Balancete (Fast Close)");
      setIshikawaCauses({
        method: ["Ausência de trilha padrão de tarefas de fechamento", "Excesso de reclassificações manuais no fim de mês"],
        machine: ["ERP desconectado de suas coligadas", "Falta de versionamento de planilhas de ajuste em drive central"],
        manpower: ["Operadores fatigados por rotinas manuais", "Licenças médicas e faltas de backups"],
        material: ["Envio de relatórios em formato PDF não-editável", "Planilhas de equivalência patrimonial com erros de lógica"],
        measurement: ["Falta de cronograma formal detalhado de entregas", "Ausência de checks analíticos de variação MoM"],
        environment: ["Pressão extrema por fechamento ágil sem controle", "Ausência de quadros de tarefas visuais (Dashboard)"]
      });
    } else if (detectedCategory === "fiscal") {
      setLpProfitX1(300); // Saneamento
      setLpProfitX2(800); // Auditoria
      setLpStandardCoeffs([5, 8, 8, 10, 3]);
      setLpProCoeffs([12, 18, 22, 28, 8]);
      setFmeaRows([
        {
          stepId: "step-1",
          stepName: "Recebimento XML Saneamento",
          failureMode: "NCM inválido de fornecedor de produtos",
          effect: "Erro e rejeição imediata da nota no Portal PVA do governo",
          severity: 8,
          cause: "Fornecedor cadastrado incorretamente ou desatualizado no fiscal",
          occurrence: 6,
          detection: 5,
          action: "Varrer cadastros eletrônicos de notas de maneira automatizada pré-recebimento."
        },
        {
          stepId: "step-2",
          stepName: "Apuração Indiretos",
          failureMode: "Duplicidade de aproveitamento de créditos fiscais de ICMS",
          effect: "Multas fiscais severas da receita estadual fiscal",
          severity: 9,
          cause: "Lançamento e checagem duplicada manual de fretes (CT-e)",
          occurrence: 3,
          detection: 8,
          action: "Validador sistêmico de chaves eletrônicas de NF-e e CT-e no livro fiscal."
        },
        {
          stepId: "step-3",
          stepName: "Apuração Diretos",
          failureMode: "Erro no preenchimento de adições no Lalur",
          effect: "Impostos federais recolhidos abaixo do nível de lei",
          severity: 9,
          cause: "Desintegração de contas contábeis de despesa não-dedutíveis com o Lalur",
          occurrence: 4,
          detection: 6,
          action: "Vincular no plano de contas as regras de indedutibilidade para a consolidação."
        },
        {
          stepId: "step-4",
          stepName: "Transmissão SPED Fiscal",
          failureMode: "Erro estrutural interno em blocos do arquivo de saída",
          effect: "Rejeição imediata de conformidade e aplicação de sanções",
          severity: 10,
          cause: "Incongruência entre as notas emitidas e o inventário físico Bloco K",
          occurrence: 5,
          detection: 7,
          action: "Rodar cruzador de blocos SPED pré-validação do governo."
        },
        {
          stepId: "step-5",
          stepName: "Emissão de Guias de Recolhimento",
          failureMode: "Código de receita e classificação incorretos em DARF/GARE",
          effect: "Pagamentos rejeitados gerando irregularidade fiscal",
          severity: 8,
          cause: "Preenchimento de boleto em portal público com erros humanos de digitação",
          occurrence: 4,
          detection: 9,
          action: "Habilitar emissor integrado de guias que extrai a DARF pela EFD de forma selada."
        }
      ]);
      setSelectedIshikawaIssue("Inconsistências Críticas na Validação do SPED Fiscal");
      setIshikawaCauses({
        method: ["Falta de rotinas semanais de pré-validação fiscal", "Cadastros tributários alterados por faturamento livre"],
        machine: ["Portal Sefaz congestionado", "Lentidão sistêmica no processador fiscal do ERP"],
        manpower: ["Analista sobrecarregado com regras de 27 estados", "Treinamento defasado em Bloco K industrial"],
        material: ["Retorno de notas fiscais de terceiros sem XML", "NCM obsoleto mantido na base fiscal de produtos"],
        measurement: ["Falta de reconciliação cruzada analítica mensal", "Ausência de auditorias automatizadas internas"],
        environment: ["Inconstância brutal de normas governamentais", "Prazos fiscais apertados com multas automáticas"]
      });
    } else {
      // Reset Default SMT scenario
      setLpProfitX1(450);
      setLpProfitX2(750);
      setLpStandardCoeffs([12, 5, 4, 10, 8]);
      setLpProCoeffs([18, 10, 8, 15, 12]);
      setFmeaRows([
        {
          stepId: "step-1",
          stepName: "Impressão SMT & Placer",
          failureMode: "Ecesso ou falta de pasta de solda no stencil",
          effect: "Pistas em curto circuito ou circuitos abertos",
          severity: 8,
          cause: "Variação na pressão mecânica útil do raspador",
          occurrence: 5,
          detection: 6,
          action: "Adotar sistema de raspagem pneumática proporcional calibrada semanal."
        },
        {
          stepId: "step-2",
          stepName: "Forno de Refluxo Térmico",
          failureMode: "Desvio na zona de pré-aquecimento ideal",
          effect: "Microfissuras térmicas ocultas internas nos componentes de controle",
          severity: 9,
          cause: "Descalibração estática nos termopares de zona",
          occurrence: 3,
          detection: 7,
          action: "Instalar placa de teste Kic Thermoprofiler com log diário automático."
        },
        {
          stepId: "step-3",
          stepName: "Estação Inspeção AOI & Retoque",
          failureMode: "Falso positivo / Alarme óptico ignorado",
          effect: "Envio de placas com soldas falhas para integração mecânica",
          severity: 7,
          cause: "Variação de iluminação ambiental externa sobre a câmera",
          occurrence: 6,
          detection: 4,
          action: "Acoplar domo de isolamento contra raios solares e calibrar IA de visão."
        },
        {
          stepId: "step-4",
          stepName: "Montagem Integrada Mecânica",
          failureMode: "Torqueamento excessivo frontal do gabinete",
          effect: "Rachadura oculta no chassi plástico ABS de fixação",
          severity: 6,
          cause: "Parafusadeira pneumática desregulada sem calibração digital",
          occurrence: 4,
          detection: 5,
          action: "Mapear o aperto com parafusadeiras digitais dotadas de transdutor mecânico."
        },
        {
          stepId: "step-5",
          stepName: "Teste Funcional & Embalagem",
          failureMode: "Fio de aterramento ESD da bancada desconectado",
          effect: "Descarga eletrostática silenciosa danifica o CMOS do circuito integrado",
          severity: 10,
          cause: "Rompimento do cabo helicoidal por fadiga física",
          occurrence: 2,
          detection: 9,
          action: "Substituir por pulseiras ESD monitoradas online com bip sonoro de perda."
        }
      ]);
      setSelectedIshikawaIssue("Elevado Retrabalho na Bancada AOI");
      setIshikawaCauses({
        method: ["Falta de padrão visual na junta SMD", "Velocidade excessiva do raspador na fase prévia"],
        machine: ["Desgaste no feeder SMT de componentes", "Lente da câmera AOI obstruída por fluxo residual"],
        manpower: ["Operadores com fadiga por turnos dobrados", "Falta de treinamento formal em retórica IPC-A-610"],
        material: ["Pasta de solda armazenada em geladeira descalibrada", "Placas virgens pcb com oxidação de borda"],
        measurement: ["Falta de gabarito estático padrão", "Instrumentos de medição sem certificado de calibração RNC"],
        environment: ["Variação de umidade ambiente controlada na sala", "Contaminação por micropartículas (excesso de pó)"]
      });
    }
  }, [detectedCategory]);

  const handleAddFmeaRow = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple custom form simulation or default insertion
    if (!steps || steps.length === 0) return;
    const defaultStep = steps[0];
    const newRow: FmeaRow = {
      stepId: defaultStep.id,
      stepName: defaultStep.name,
      failureMode: "Novo modo de falha identificado",
      effect: "Interrupção na vazão de montagem",
      severity: 5,
      cause: "Frequência operacional indefinida",
      occurrence: 4,
      detection: 5,
      action: "Adotar plano de manutenção preventiva trimestral."
    };
    setFmeaRows([...fmeaRows, newRow]);
  };

  const handleUpdateFmeaValue = (index: number, key: keyof FmeaRow, value: any) => {
    const updated = [...fmeaRows];
    updated[index] = { ...updated[index], [key]: value };
    setFmeaRows(updated);
  };

  const handleAddIshikawaCause = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCauseText.trim()) return;
    const currentList = ishikawaCauses[newCauseCategory];
    setIshikawaCauses({
      ...ishikawaCauses,
      [newCauseCategory]: [...currentList, newCauseText.trim()]
    });
    setNewCauseText("");
  };

  const handleRemoveIshikawaCause = (category: keyof FishboneCause, index: number) => {
    const currentList = ishikawaCauses[category];
    setIshikawaCauses({
      ...ishikawaCauses,
      [category]: currentList.filter((_, i) => i !== index)
    });
  };

  // Programação Linear Mix Solver (2D Graphical Grid Corner Points Method)
  // Maximize Z = profitX1 * x1 + profitX2 * x2
  // Subject to constraints on steps: x1 * StdMin + x2 * ProMin <= LimitMinutes [Capacity of the step in minutes]
  // LimitMinutes = shiftHours * 60 * step.resourceCount
  const solveLPMix = () => {
    const limitMinutes = lpShiftHours * 60;
    
    // Core physical step constraints
    const baseConstraints = steps.map((step, idx) => {
      const standardCoef = lpStandardCoeffs[idx] || 10;
      const proCoef = lpProCoeffs[idx] || 15;
      const capacityMinutes = limitMinutes * (step.resourceCount || 1);
      return {
        stepName: step.name,
        standardCoef,
        proCoef,
        capacityMinutes,
      };
    });

    // Solve model from scratch for a given set of step constraints
    const findOptimalForCapacities = (currentStepConstraints: typeof baseConstraints) => {
      // Build full restriction array including non-negativity boundary and market limits
      const allConstraints = [
        ...currentStepConstraints,
        { stepName: "Demanda Máxima " + lpLabels.x1Short, standardCoef: 1, proCoef: 0, capacityMinutes: lpMaxX1 },
        { stepName: "Demanda Máxima " + lpLabels.x2Short, standardCoef: 0, proCoef: 1, capacityMinutes: lpMaxX2 },
      ];

      // Corner point candidates
      const candidates: { x1: number; x2: number }[] = [
        { x1: 0, x2: 0 },
        { x1: 0, x2: lpMaxX2 },
        { x1: lpMaxX1, x2: 0 },
      ];

      // Axis intercepts of all constraints
      allConstraints.forEach(c => {
        if (c.standardCoef > 0) {
          const x1Val = c.capacityMinutes / c.standardCoef;
          if (x1Val >= 0 && x1Val <= lpMaxX1 * 1.5) {
            candidates.push({ x1: x1Val, x2: 0 });
          }
        }
        if (c.proCoef > 0) {
          const x2Val = c.capacityMinutes / c.proCoef;
          if (x2Val >= 0 && x2Val <= lpMaxX2 * 1.5) {
            candidates.push({ x1: 0, x2: x2Val });
          }
        }
      });

      // Linear equation solver for pairwise intersections
      for (let i = 0; i < allConstraints.length; i++) {
        for (let j = i + 1; j < allConstraints.length; j++) {
          const c1 = allConstraints[i];
          const c2 = allConstraints[j];
          
          const det = c1.standardCoef * c2.proCoef - c1.proCoef * c2.standardCoef;
          if (Math.abs(det) > 1e-4) {
            const x1 = (c1.capacityMinutes * c2.proCoef - c1.proCoef * c2.capacityMinutes) / det;
            const x2 = (c1.standardCoef * c2.capacityMinutes - c1.capacityMinutes * c2.standardCoef) / det;
            if (x1 >= 0 && x2 >= 0) {
              candidates.push({ x1, x2 });
            }
          }
        }
      }

      // Filter feasible fractional points
      const feasiblePoints = candidates.filter(pt => {
        return allConstraints.every(c => {
          return (pt.x1 * c.standardCoef + pt.x2 * c.proCoef) <= (c.capacityMinutes + 1e-3);
        });
      });

      // Find the best fractional point
      let bestZ = -1;
      let bestPt = { x1: 0, x2: 0 };
      feasiblePoints.forEach(pt => {
        const Z = pt.x1 * lpProfitX1 + pt.x2 * lpProfitX2;
        if (Z > bestZ) {
          bestZ = Z;
          bestPt = pt;
        }
      });

      // Sound integer-feasibility selection via neighborhood grid evaluation (Integer Linear Programming)
      let bestIntPt = { x1: 0, x2: 0 };
      let bestIntZ = -1;
      const x1_floor = Math.floor(bestPt.x1);
      const x1_ceil = Math.ceil(bestPt.x1);
      const x2_floor = Math.floor(bestPt.x2);
      const x2_ceil = Math.ceil(bestPt.x2);

      const neighbors = [
        { x1: x1_floor, x2: x2_floor },
        { x1: x1_ceil, x2: x2_floor },
        { x1: x1_floor, x2: x2_ceil },
        { x1: x1_ceil, x2: x2_ceil },
      ];

      neighbors.forEach(n => {
        if (n.x1 >= 0 && n.x2 >= 0) {
          const isFeasible = allConstraints.every(c => {
            return (n.x1 * c.standardCoef + n.x2 * c.proCoef) <= (c.capacityMinutes + 1e-3);
          });
          if (isFeasible) {
            const Z = n.x1 * lpProfitX1 + n.x2 * lpProfitX2;
            if (Z > bestIntZ) {
              bestIntZ = Z;
              bestIntPt = n;
            }
          }
        }
      });

      // Robust fallback
      if (bestIntZ === -1) {
        bestIntPt = { x1: Math.floor(bestPt.x1), x2: Math.floor(bestPt.x2) };
        bestIntZ = bestIntPt.x1 * lpProfitX1 + bestIntPt.x2 * lpProfitX2;
      }

      return {
        x1: bestIntPt.x1,
        x2: bestIntPt.x2,
        revenue: bestIntZ,
        feasibleCount: feasiblePoints.length
      };
    };

    const baseResult = findOptimalForCapacities(baseConstraints);

    // Correct shadow price computation by completely re-solving the model for each constraint shift of +60 minutes (1 extra capacity hour)
    const shadowPrices = baseConstraints.map((c, idx) => {
      const shiftedConstraints = baseConstraints.map((other, oIdx) => {
        if (oIdx === idx) {
          return { ...other, capacityMinutes: other.capacityMinutes + 60 };
        }
        return { ...other };
      });
      const shiftedResult = findOptimalForCapacities(shiftedConstraints);
      // Shadow Price = incremental profit gained per hour of capacity increase
      const price = Math.max(0, shiftedResult.revenue - baseResult.revenue);
      return {
        stepName: c.stepName,
        shadowPrice: price
      };
    });

    return {
      x1: baseResult.x1,
      x2: baseResult.x2,
      revenue: baseResult.revenue,
      constraints: baseConstraints,
      shadowPrices,
      feasibleCount: baseResult.feasibleCount
    };
  };

  const lpResult = solveLPMix();

  // Teoria de Filas Economic Optimizer
  // Returns total costs under different operator levels (resource count for the bottleneck stage)
  const getQueueOptimizationData = () => {
    // We isolate the bottleneck step or step-3
    const targetStep = steps && steps.length > 0 ? (steps.find(s => s.name === stats.bottleneckStepName) || steps[0]) : null;
    if (!targetStep) {
      return {
        data: [],
        optimumResources: 1,
        minCost: 0,
        targetStepName: "Nenhum"
      };
    }
    const data = [];

    for (let c = 1; c <= 5; c++) {
      // Capacity of this step if it had 'c' resourceCount
      const capPerHour = (60 / targetStep.processingTime) * c;
      const rho = arrivalRate / capPerHour;
      
      let avgQueueTime = 0;
      let status = "Estável";
      const standardCost = c * hourlyOperatorCost * 8; // 8 hours shift

      if (rho >= 0.99) {
        avgQueueTime = 120 + (rho - 0.99) * 1200; // heavy buffer saturation
        status = "Instável (Fila Infinita!)";
      } else {
        const Cv2 = Math.pow(targetStep.standardDeviation / targetStep.processingTime, 2);
        const Ca2 = 1.0;
        const variabilityFactor = (Ca2 + Cv2) / 2;
        
        if (c === 1) {
          avgQueueTime = (rho / (1 - rho)) * variabilityFactor * targetStep.processingTime;
        } else {
          const exponent = Math.sqrt(2 * (c + 1)) - 1;
          const delayProb = Math.pow(rho, exponent);
          avgQueueTime = (delayProb / (c * (1 - rho))) * variabilityFactor * targetStep.processingTime;
        }
      }

      // Total Lead Time includes touch time
      const leadTime = targetStep.processingTime + avgQueueTime;
      // WIP in system at this step
      const stepWip = (arrivalRate / 60) * leadTime;
      // WIP cost per day (using hourly wip penalty * 8 hours)
      const wipCost = stepWip * hourlyWipPenaltyCost * 8;
      const totalCost = standardCost + wipCost;

      data.push({
        numResources: c,
        utilization: Math.min(100, Math.round(rho * 100)),
        avgWaitMin: parseFloat(avgQueueTime.toFixed(1)),
        wip: parseFloat(stepWip.toFixed(2)),
        resourceCostDay: standardCost,
        wipCostDay: Math.round(wipCost),
        totalCostDay: Math.round(totalCost),
        status,
      });
    }

    // Identify minimum cost level
    let minCost = 9999999;
    let optimumResources = 1;
    data.forEach(d => {
      if (d.totalCostDay < minCost) {
        minCost = d.totalCostDay;
        optimumResources = d.numResources;
      }
    });

    return { data, optimumResources, minCost, targetStepName: targetStep.name };
  };

  const qOpt = getQueueOptimizationData();

  // Markov Availability Steady State
  // Transition Matrix is a 4x4: row=Current, col=Next state
  // We compute state probability vector and overall availability (State 1 + State 2)
  const calculateMarkovAvailability = () => {
    // Dynamic transition probabilities driven by inputs
    // States: 1=Ideal, 2=Degraded, 3=TPM actively fixing, 4=Fatal Stop
    // P = Matrix
    // We assume realistic transition properties satisfying row sum to 1.0:
    const P = [
      [1 - markovP12 - markovP14, markovP12, 0, markovP14], // State 1 row
      [0.05, 1 - markovP23 - 0.05, markovP23, 0],         // State 2 row
      [markovP31, 1 - markovP31 - 0.05, 0.05, 0],         // State 3 row
      [0, 0, 1 - markovP43, markovP43]                    // State 4 row
    ];

    // Simple robust iterative power method to grab steady-state eigenvector (row vector pi where pi * P = pi)
    let pi = [0.25, 0.25, 0.25, 0.25];
    for (let iter = 0; iter < 120; iter++) {
      const nextPi = [0, 0, 0, 0];
      for (let j = 0; j < 4; j++) {
        for (let i = 0; i < 4; i++) {
          nextPi[j] += pi[i] * P[i][j];
        }
      }
      // re-normalize just in case
      const sum = nextPi.reduce((a, b) => a + b, 0);
      pi = nextPi.map(x => x / sum);
    }

    const avail = (pi[0] + pi[1]) * 100;

    return {
      pi: pi.map(p => parseFloat((p * 100).toFixed(1))),
      availability: parseFloat(avail.toFixed(1)),
      matrix: P
    };
  };

  const markovRes = calculateMarkovAvailability();

  // TOC Weeks Hour Budget Allocation Calculations
  const getTOCAllocation = () => {
    const bottleneck = steps && steps.length > 0 ? (steps.find(s => s.name === stats.bottleneckStepName) || steps[0]) : null;
    if (!bottleneck) {
      return {
        stepName: "Nenhum",
        currentCap: "0.0",
        targetCap: "0.0",
        percentIncrease: "0.0",
        estimatedROI: "R$ 0,00"
      };
    }
    const capacityPerHour = (60 / bottleneck.processingTime) * bottleneck.resourceCount;
    
    // Applying weekly extra hours of staff (40 hours) directly translates to adding resources or lowering processing time.
    // If we decrease bottleneck.processingTime by 25% because of streamlined flow with extra engineering, let's see:
    const improvedBottleneckTime = bottleneck.processingTime * 0.72; // 28% decrease!
    const improvedCapacity = (60 / improvedBottleneckTime) * bottleneck.resourceCount;
    const additionalMonthlyRevenue = (improvedCapacity - capacityPerHour) * 8 * 22 * lpProfitX1; // estimate monetary impact

    return {
      stepName: bottleneck.name,
      currentCap: capacityPerHour.toFixed(1),
      targetCap: improvedCapacity.toFixed(1),
      percentIncrease: (((improvedCapacity - capacityPerHour) / capacityPerHour) * 100).toFixed(1),
      estimatedROI: additionalMonthlyRevenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
    };
  };

  const tocRes = getTOCAllocation();

  // Processing Value Stream Map (VSM) Metrics
  const totalVA_Time = stats.processingTimeSum;
  // Non Value Time is the Wait Queue delays plus Setup times
  const totalQueueWaitTime = stats.leadTime - stats.processingTimeSum;
  const totalSetupTime = steps.reduce((sum, s) => sum + s.setupTime, 0);
  const totalNVA_Time = totalQueueWaitTime + totalSetupTime;
  const totalLeadTime = stats.leadTime + totalSetupTime;
  const processEfficiency = totalLeadTime > 0 ? (totalVA_Time / totalLeadTime) * 100 : 0;

  // Render subcomponents
  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* HEADER ROW */}
      <div className="border-b border-gray-200 pb-5">
        <span className="text-[10px] font-bold text-violet-700 bg-violet-700/5 px-2.5 py-0.5 rounded-sm uppercase tracking-widest inline-block mb-1">
          Operations Research (PO) &amp; Lean Quality Workbench
        </span>
        <h2 className="text-3xl font-serif text-gray-950 uppercase tracking-tight">
          Super-Módulo de Otimização e Controle de Qualidade
        </h2>
        <p className="text-xs text-gray-600 max-w-4xl mt-1 leading-relaxed">
          Execute análises avançadas utilizando matrizes matemáticas de Pesquisa Operacional para encontrar decisões ótimas de produção, e implemente as clássicas ferramentas de melhoria contínua (Shigeo Shingo, Ishikawa, Lean 5S e FMEA) de forma integrada e visual.
        </p>
      </div>

      {/* CORE MENU NAVIGATION */}
      <div className="flex border-b border-[#1A1A1A] gap-1 bg-white">
        <button
          onClick={() => setActiveSubTab("OR")}
          className={`px-6 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeSubTab === "OR" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <Cpu size={14} />
          <span>I. Pesquisa Operacional (P.O.)</span>
        </button>
        <button
          onClick={() => setActiveSubTab("QUALITY")}
          className={`px-6 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeSubTab === "QUALITY" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <TrendingUp size={14} />
          <span>II. Lean &amp; Ferramentas de Qualidade</span>
        </button>
      </div>

      {/* SUB-VIEW 1 : PESQUISA OPERACIONAL */}
      {activeSubTab === "OR" && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          
          {/* Models Selector Column (Col 4) */}
          <div className="md:col-span-4 space-y-3 bg-[#FAF8F5] border border-gray-200 p-5">
            <span className="text-[9px] font-mono font-bold uppercase text-violet-700 tracking-wider block">Selecione o Modelo Matemático</span>
            
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setSelectedOrModel("LP")}
                className={`w-full text-left p-3.5 border transition-all rounded-xs flex flex-col gap-1 cursor-pointer ${
                  selectedOrModel === "LP"
                    ? "bg-[#1A1A1A] text-white border-transparent"
                    : "bg-white text-gray-800 border-gray-200 hover:border-gray-400"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-tight">1. Mix de Podução (P.L.)</span>
                  <Calculator size={13} className={selectedOrModel === "LP" ? "text-violet-400" : "text-gray-400"} />
                </div>
                <span className="text-[10px] opacity-70 leading-normal font-sans">Programação Linear Simplex para otimizar faturamento sob tempos das máquinas.</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedOrModel("QUEUE")}
                className={`w-full text-left p-3.5 border transition-all rounded-xs flex flex-col gap-1 cursor-pointer ${
                  selectedOrModel === "QUEUE"
                    ? "bg-[#1A1A1A] text-white border-transparent"
                    : "bg-white text-gray-800 border-gray-200 hover:border-gray-400"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-tight">2. Minimização Econômica</span>
                  <Activity size={13} className={selectedOrModel === "QUEUE" ? "text-violet-400" : "text-gray-400"} />
                </div>
                <span className="text-[10px] opacity-70 leading-normal font-sans">Teoria das Filas G/G/c equilibrando custo de staff e custo financeiro de WIP.</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedOrModel("MARKOV")}
                className={`w-full text-left p-3.5 border transition-all rounded-xs flex flex-col gap-1 cursor-pointer ${
                  selectedOrModel === "MARKOV"
                    ? "bg-[#1A1A1A] text-white border-transparent"
                    : "bg-white text-gray-800 border-gray-200 hover:border-gray-400"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-tight">3. Cadeias de Markov</span>
                  <Settings2 size={13} className={selectedOrModel === "MARKOV" ? "text-violet-400" : "text-gray-400"} />
                </div>
                <span className="text-[10px] opacity-70 leading-normal font-sans">Estabilidade estocástica de transições entre óbices operacionais e TPM.</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedOrModel("TOC")}
                className={`w-full text-left p-3.5 border transition-all rounded-xs flex flex-col gap-1 cursor-pointer ${
                  selectedOrModel === "TOC"
                    ? "bg-[#1A1A1A] text-white border-transparent"
                    : "bg-white text-gray-800 border-gray-200 hover:border-gray-400"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-tight">4. Alocação por Restrições</span>
                  <TrendingUp size={13} className={selectedOrModel === "TOC" ? "text-violet-400" : "text-gray-400"} />
                </div>
                <span className="text-[10px] opacity-70 leading-normal font-sans">Alocação inteligente de orçamento de horas extras segundo Goldratt (TOC).</span>
              </button>
            </div>
            
            <div className="p-3 bg-amber-50 border border-amber-200 text-[10px] text-amber-900 leading-normal font-sans space-y-1">
              <strong>Vantagem da Pesquisa Operacional:</strong>
              <p>Tomar decisões usando heurísticas empíricas causa gargalos. P.O. substitui o palpite por algoritmos de otimização matemática robustos.</p>
            </div>
          </div>

          {/* Model Operational Board (Col 8) */}
          <div className="md:col-span-8 space-y-6">
            
            {/* MODEL A: MIX DE PRODUÇÃO PROGRAMAÇÃO LINEAR */}
            {selectedOrModel === "LP" && (
              <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6 animate-fade-in">
                
                {/* Meta explanation */}
                <div className="space-y-2 border-b border-gray-100 pb-3">
                  <h3 className="text-xl font-serif font-bold text-gray-950 uppercase">Otimização de Mix de Produção por P.L.</h3>
                  <p className="text-xs text-gray-500 leading-relaxed font-sans">
                    Formulação de Programação Linear clássica (Simplex 2-D) que encontra as quantidades ideais a processar simultaneamente de dois perfis distintos ({lpLabels.x1Short} vs {lpLabels.x2Short}) para maximizar o retorno operacional, respeitando estritamente a capacidade de processamento instalada em cada etapa física dadas as suas respectivas máquinas, sistemas e analistas.
                  </p>
                </div>

                {/* Mathematical Model Card */}
                <div className="p-4 bg-gray-50 border border-gray-100 rounded-sm font-mono space-y-2 text-xs">
                  <p className="text-[#C49746] font-bold">🎯 MODELAGEM MATEMÁTICA CONCEITUAL:</p>
                  <p className="font-sans text-gray-800">
                    <strong className="font-mono">Variáveis:</strong> <code className="bg-white p-0.5 border text-[#C49746]">x1</code> = {lpLabels.x1Name}, <code className="bg-white p-0.5 border text-[#C49746]">x2</code> = {lpLabels.x2Name}
                  </p>
                  <p className="font-sans text-gray-800">
                    <strong className="font-mono">Função Objetivo (Retorno Max):</strong> Maximize Z = <strong className="font-mono text-gray-950">R$ {lpProfitX1} • x1 + R$ {lpProfitX2} • x2</strong>
                  </p>
                  <p className="font-sans text-gray-800 text-[11px]">
                    <strong className="font-mono block">Sujeito a Restrições de Minutos de Processamento nas Etapas:</strong>
                    {steps.map((st, idx) => (
                      <span key={st.id} className="block mt-1 pl-3 text-gray-600">
                        • {st.name}: <strong className="font-mono text-gray-900">{lpStandardCoeffs[idx]}x1 + {lpProCoeffs[idx]}x2 ≤ {lpShiftHours * 60 * st.resourceCount} min</strong> (Disponível para equipe de x{st.resourceCount})
                      </span>
                    ))}
                  </p>
                </div>

                {/* Simulation Controls Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 border-t pt-4">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Lucro Unitário {lpLabels.x1Short} (R$ / un)</label>
                    <input
                      type="number"
                      value={lpProfitX1}
                      onChange={(e) => setLpProfitX1(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Lucro Unitário {lpLabels.x2Short} (R$ / un)</label>
                    <input
                      type="number"
                      value={lpProfitX2}
                      onChange={(e) => setLpProfitX2(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Horas Disponíveis Turno (Seis Sigma)</label>
                    <input
                      type="number"
                      value={lpShiftHours}
                      onChange={(e) => setLpShiftHours(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Capac. Demanda {lpLabels.x1Short}</label>
                    <input
                      type="number"
                      value={lpMaxX1}
                      onChange={(e) => setLpMaxX1(Math.max(0, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Capac. Demanda {lpLabels.x2Short}</label>
                    <input
                      type="number"
                      value={lpMaxX2}
                      onChange={(e) => setLpMaxX2(Math.max(0, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none rounded-md"
                    />
                  </div>
                </div>

                {/* SOLVER RESULT BLOCK */}
                <div className="bg-emerald-50/70 border border-emerald-200 p-5 grid grid-cols-1 md:grid-cols-12 gap-5">
                  <div className="md:col-span-5 space-y-2">
                    <span className="text-[8px] font-mono font-bold bg-emerald-100 border border-emerald-300 px-2 py-0.5 text-emerald-800 rounded-sm uppercase tracking-wide">
                      Solução Otimizada Simplex 2D
                    </span>
                    <div className="text-3xl font-serif text-[#16a34a] font-black">
                      {lpResult.revenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                      <span className="text-[10px] text-gray-500 font-sans block font-normal text-right mt-1">Retorno Máximo Operacional Semanal</span>
                    </div>

                    <div className="space-y-1.5 pt-2 border-t border-emerald-200/50">
                      <div className="text-xs text-gray-800 font-sans flex justify-between">
                        <span>{lpLabels.x1Short}:</span>
                        <strong className="font-mono text-emerald-800">{lpResult.x1} {lpLabels.unit}</strong>
                      </div>
                      <div className="text-xs text-gray-800 font-sans flex justify-between">
                        <span>{lpLabels.x2Short}:</span>
                        <strong className="font-mono text-emerald-800">{lpResult.x2} {lpLabels.unit}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Operational Shadow Prices Constraint Slack analysis */}
                  <div className="md:col-span-7 space-y-2 border-l border-emerald-200 pl-0 md:pl-5">
                    <span className="text-[8px] font-mono font-bold text-gray-500 uppercase tracking-wider block">Preços Sombra e Gargalos Econômicos (Shadow Prices)</span>
                    <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                      O Preço Sombra representa o ganho monetário incremental imediato na fabricação se adicionarmos exatamente <strong>1 hora extra</strong> para a etapa selecionada. Use este dado no CAPEX:
                    </p>

                    <div className="space-y-1.5 text-[10.5px]">
                      {lpResult.shadowPrices.map((sp, idx) => {
                        const isGargalo = idx === 0 || idx === 2; // Step 1 & 3 are hard constrained bottlenecks
                        return (
                          <div key={idx} className="flex justify-between items-center bg-white p-1.5 border border-gray-100 rounded-xs">
                            <span className="font-sans font-bold text-gray-700 truncate max-w-[170px]">{sp.stepName}</span>
                            <div className="font-mono text-right shrink-0">
                              <span className={`font-bold px-1.5 py-0.2 text-[9.5px] rounded-xs ${
                                sp.shadowPrice > 0 ? "bg-red-50 text-red-700 font-semibold" : "bg-gray-100 text-gray-500"
                              }`}>
                                + {sp.shadowPrice.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}/h
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* MODEL B: TEORIA DE FILAS ECONOMIC OPTIMIZER G/G/c */}
            {selectedOrModel === "QUEUE" && (
              <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6 animate-fade-in">
                
                <div className="space-y-2 border-b border-gray-100 pb-3">
                  <h3 className="text-xl font-serif font-bold text-gray-950 uppercase">Otimizador Econômico de Filas (G/G/c)</h3>
                  <p className="text-xs text-gray-500 leading-relaxed font-sans">
                    A Teoria das Filas prova que contratar poucos operadores economiza salário de staff mas congestiona a fábrica gerando perdas por atraso (WIP estancado). Contratar muitos operadores reduz as filas de espera ao mínimo mas encarece o custo de ociosidade operacional. O ponto ótimo minimiza o somatório desses dois fatores.
                  </p>
                </div>

                {/* Queue Math block */}
                <div className="p-4 bg-gray-50 border border-gray-100 rounded-sm font-mono text-xs space-y-1">
                  <p className="text-[#C49746] font-bold">📏 EQUAÇÕES DO MODELO MATEMÁTICO:</p>
                  <p className="text-gray-700 font-sans text-[11px] leading-relaxed">
                    Estatística de Fila de Allen-Cunneen com variabilidade genérica (G/G/c): <code className="bg-white p-0.5 border text-violet-700 text-[10px]">Wq ≈ (DelayProb / (c * (1 - ρ))) * ((Ca^2 + Cv^2) / 2) * Ts</code>. 
                    O custo econômico diário é formulado como: <strong className="text-gray-950">CT = StaffCost(c) * 8h + WIPPenalty * WIP(c) * 8h</strong>.
                  </p>
                </div>

                {/* Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Custo por Operador Contratado (R$ / hora)</label>
                    <input
                      type="number"
                      value={hourlyOperatorCost}
                      onChange={(e) => setHourlyOperatorCost(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Custo Penalização WIP de Atraso (R$ / un / hora)</label>
                    <input
                      type="number"
                      value={hourlyWipPenaltyCost}
                      onChange={(e) => setHourlyWipPenaltyCost(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-white border border-[#1A1A1A]/15 font-mono px-2.5 py-1.5 focus:border-[#C49746] text-xs focus:outline-none"
                    />
                  </div>
                </div>

                {/* Optimization Table results */}
                <div className="space-y-3">
                  <span className="text-[8.5px] font-mono font-bold uppercase text-gray-500 block">Estudo de Custo Total por Nível de Operadores (Etapa: {qOpt.targetStepName})</span>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-gray-800 font-sans border border-collapse">
                      <thead>
                        <tr className="bg-[#FAF8F5] border-b border-gray-200">
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold">Operadores (c)</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold">% Utilização</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold">Espera Média Fila</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold">WIP Estocado</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold font-sans text-right">Custo Staff diário</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-extrabold font-sans text-right">Custo Fila diário</th>
                          <th className="py-2.5 px-3 uppercase text-[8.5px] font-mono tracking-wider font-bold text-gray-900 font-sans text-right">Custo Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {qOpt.data.map((d, index) => {
                          const isOpt = d.numResources === qOpt.optimumResources;
                          return (
                            <tr key={index} className={`border-b border-gray-100 hover:bg-gray-50/50 ${isOpt ? "bg-amber-50/40 text-[#C49746] font-bold" : ""}`}>
                              <td className="py-2 px-3 shrink-1 font-mono flex items-center gap-1.5">
                                🧑‍💻 {d.numResources} {isOpt ? <span className="text-[8px] bg-[#C49746] text-white font-serif px-1 rounded-sm uppercase tracking-tighter">ÓTIMO</span> : ""}
                              </td>
                              <td className="py-2 px-3 font-mono">{d.utilization}%</td>
                              <td className="py-2 px-3 font-mono">{d.avgWaitMin} min</td>
                              <td className="py-2 px-3 font-mono">{d.wip} un</td>
                              <td className="py-2 px-3 font-mono text-right">R$ {d.resourceCostDay}</td>
                              <td className="py-2 px-3 font-mono text-right">R$ {d.wipCostDay}</td>
                              <td className="py-2 px-3 font-mono text-right font-extrabold">
                                R$ {d.totalCostDay}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="bg-amber-50/50 p-4 border-l-2 border-[#C49746] text-[10px] leading-relaxed text-[#C49746]">
                    💡 <strong>Conclusão Otimizador Econômico:</strong> O número ideal recomendando é de <strong>{qOpt.optimumResources} operadores</strong>. Alocar menos ou mais operadores do que este valor causará perdas de estocagem de WIP ou custos exorbitantes de ociosidade operacional.
                  </div>
                </div>

              </div>
            )}

            {/* MODEL C: CADEIA DE MARKOV */}
            {selectedOrModel === "MARKOV" && (
              <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6 animate-fade-in">
                
                <div className="space-y-2 border-b border-gray-100 pb-3">
                  <h3 className="text-xl font-serif font-bold text-gray-950 uppercase">Cadeia de Markov para Disponibilidade (TPM)</h3>
                  <p className="text-xs text-gray-500 leading-relaxed font-sans">
                    Máquinas e processos industriais degradam no tempo devido a desgastes e atritos físicos, variando as taxas de transição entre estados bons, degradados de alta variabilidade, paradas de reparo corretivo ou falhas de segurança imediatas. Usamos equações de Markov para calcular o regime permanente estável das probabilidades.
                  </p>
                </div>

                {/* Transitions Inputs Grid */}
                <div className="bg-slate-50 border p-4 font-mono text-xs space-y-3.5 rounded-sm">
                  <p className="text-[#C49746] font-bold flex items-center gap-1">📊 AJUSTE DE TAXAS DE TRANSIÇÃO OPERACIONAIS DE MARKOV:</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
                    <div>
                      <span className="block text-[10px] text-gray-500 font-bold mb-1">Taxa Deterioração (De Ideal para Degradado)</span>
                      <input
                        type="range"
                        min="0.01"
                        max="0.25"
                        step="0.01"
                        value={markovP12}
                        onChange={(e) => setMarkovP12(parseFloat(e.target.value))}
                        className="w-full cursor-pointer accent-[#C49746]"
                      />
                      <span className="font-mono text-[9px] text-[#C49746]">Valor atual: {(markovP12*100).toFixed(0)}% chance de desvio</span>
                    </div>

                    <div>
                      <span className="block text-[10px] text-gray-500 font-bold mb-1">Taxa de Parada Corretiva (De Degradado para TPM)</span>
                      <input
                        type="range"
                        min="0.05"
                        max="0.40"
                        step="0.01"
                        value={markovP23}
                        onChange={(e) => setMarkovP23(parseFloat(e.target.value))}
                        className="w-full cursor-pointer accent-[#C49746]"
                      />
                      <span className="font-mono text-[9px] text-[#C49746]">Valor atual: {(markovP23*100).toFixed(0)}% chance de quebra</span>
                    </div>
                  </div>
                </div>

                {/* State Vector Probabilities Outputs */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
                  {[
                    { name: "Ideal / Sem Desvios", prob: markovRes.pi[0], color: "bg-emerald-50 text-emerald-800 border-emerald-300" },
                    { name: "Modo Degradado (σ Alto)", prob: markovRes.pi[1], color: "bg-blue-50 text-blue-800 border-blue-300" },
                    { name: "Manutenção Corretiva Ativa", prob: markovRes.pi[2], color: "bg-amber-50 text-[#C49746] border-amber-300" },
                    { name: "Parada Crítica (Falha Grave)", prob: markovRes.pi[3], color: "bg-red-50 text-red-800 border-red-300" }
                  ].map((st, i) => (
                    <div key={i} className={`p-4 border text-center flex flex-col justify-between ${st.color}`}>
                      <span className="text-[10px] font-bold uppercase tracking-wider">{st.name}</span>
                      <span className="font-serif font-black text-2xl tracking-tight block mt-2">{st.prob}%</span>
                      <span className="text-[8px] mt-1 block uppercase font-mono tracking-tight text-gray-400">Tempo de Regime</span>
                    </div>
                  ))}
                </div>

                <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xs text-xs font-sans text-emerald-900 flex justify-between items-center">
                  <div>
                    <h5 className="font-bold flex items-center gap-1">🟢 Disponibilidade Operacional Estável Calculada:</h5>
                    <p className="text-[10px] text-gray-600 mt-1 max-w-md">Percentual acumulado estável das etapas em estados úteis produtivos (Ideal + Degradados úteis).</p>
                  </div>
                  <div className="text-3xl font-serif font-black text-[#16a34a]">{markovRes.availability}% Disponível</div>
                </div>

              </div>
            )}

            {/* MODEL D: ALOCAÇÃO DE RECURSOS POR RESTRIÇÕES */}
            {selectedOrModel === "TOC" && (
              <div className="bg-white border-2 border-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6 animate-fade-in">
                
                <div className="space-y-2 border-b border-gray-100 pb-3">
                  <h3 className="text-xl font-serif font-bold text-gray-950 uppercase">Alocação por Teoria das Restrições (TOC)</h3>
                  <p className="text-xs text-gray-500 leading-relaxed font-sans">
                    Segundo Eliyahu M. Goldratt, "a vazão total de qualquer processo industrial é determinada exclusivamente pelo seu gargalo principal". Portanto, qualquer investimento de tempo, automações ou horas extras aplicadas fora dele é pura perda. O modelo TOC seleciona a melhor alocação baseada na física de restrições.
                  </p>
                </div>

                {/* Allocation output cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="border border-dashed p-4 bg-slate-50 space-y-3">
                    <span className="text-[9px] font-mono font-bold uppercase text-gray-400">Diagnóstico da Restrição Ativa</span>
                    <p className="text-xs text-gray-700 leading-relaxed">
                      Nossa modelagem de rede estocástica detectou que o seu gargalo determinante atualmente é a etapa: <span className="bg-yellow-100 px-1 py-0.5 border border-yellow-300 font-bold text-[#C49746]">{tocRes.stepName}</span>.
                    </p>

                    <ul className="space-y-1 text-[11px] text-gray-500 font-sans">
                      <li>• Capacidade Atual do Posto: <strong className="text-gray-900">{tocRes.currentCap} un/hora</strong></li>
                      <li>• Utilização com demanda de entrada: <strong className="text-red-600">{stats.systemUtilization.toFixed(0)}%</strong></li>
                    </ul>
                  </div>

                  <div className="border border-emerald-500 bg-emerald-50/20 p-4 space-y-3">
                    <span className="text-[9px] font-mono font-bold uppercase text-[#16a34a]">Plano de Investimento TOC Adotado</span>
                    <p className="text-xs text-gray-800 leading-relaxed">
                      Recomendamos canalizar <strong>100% das 40 horas extras</strong> exclusivamente para redimensionar o ritmo no/a {tocRes.stepName}.
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      <div className="bg-white p-2 border border-emerald-200">
                        <span className="text-gray-400 block uppercase text-[8px]">Nova Capacidade:</span>
                        <strong className="text-[#16a34a]">{tocRes.targetCap} un/h</strong>
                      </div>
                      <div className="bg-white p-2 border border-emerald-200">
                        <span className="text-gray-400 block uppercase text-[8px]">Retorno ROI Mensal:</span>
                        <strong className="text-[#16a34a]">{tocRes.estimatedROI}</strong>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

          </div>

        </div>
      )}

      {/* SUB-VIEW 2 : LEAN & FERRAMENTAS DE QUALIDADE */}
      {activeSubTab === "QUALITY" && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          
          {/* Tool selectors (Col 3) */}
          <div className="md:col-span-3 space-y-2 bg-[#FAF8F5] border border-gray-200 p-4">
            <span className="text-[9px] font-mono font-bold uppercase text-violet-700 tracking-wider block">Estações &amp; Matrizes Kaizen</span>

            <div className="space-y-1.5 font-sans">
              <button
                type="button"
                onClick={() => setSelectedQualityTool("VSM")}
                className={`w-full text-left py-2 px-3 text-xs font-bold uppercase rounded-sm transition-all flex items-center justify-between cursor-pointer ${
                  selectedQualityTool === "VSM" ? "bg-violet-700 text-white" : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <span>1. Mapa VSM de Valor</span>
                <ChevronRight size={13} />
              </button>

              <button
                type="button"
                onClick={() => setSelectedQualityTool("FMEA")}
                className={`w-full text-left py-2 px-3 text-xs font-bold uppercase rounded-sm transition-all flex items-center justify-between cursor-pointer ${
                  selectedQualityTool === "FMEA" ? "bg-violet-700 text-white" : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <span>2. Matriz FMEA de Riscos</span>
                <ChevronRight size={13} />
              </button>

              <button
                type="button"
                onClick={() => setSelectedQualityTool("ISHIKAWA")}
                className={`w-full text-left py-2 px-3 text-xs font-bold uppercase rounded-sm transition-all flex items-center justify-between cursor-pointer ${
                  selectedQualityTool === "ISHIKAWA" ? "bg-violet-700 text-white" : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <span>3. Ishikawa (Causa-Efeito)</span>
                <ChevronRight size={13} />
              </button>

              <button
                type="button"
                onClick={() => setSelectedQualityTool("5S")}
                className={`w-full text-left py-2 px-3 text-xs font-bold uppercase rounded-sm transition-all flex items-center justify-between cursor-pointer ${
                  selectedQualityTool === "5S" ? "bg-violet-700 text-white" : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <span>4. Auditoria de Rotina 5S</span>
                <ChevronRight size={13} />
              </button>
            </div>
          </div>

          {/* Active quality tool screen (Col 9) */}
          <div className="md:col-span-9 space-y-6">
            
            {/* QUALITY TOOL 1: INTERACTIVE VSM */}
            {selectedQualityTool === "VSM" && (
              <div className="bg-white border border-[#1A1A1A]/15 p-6 shadow-sm space-y-6 animate-fade-in text-left">
                <div className="border-b pb-3 space-y-1">
                  <h3 className="text-lg font-serif font-bold text-gray-950 uppercase">Mapeamento de Fluxo de Valor (Value Stream Mapping - VSM)</h3>
                  <p className="text-xs text-gray-500">Mapear visualmente agregadores de valor práticos versus perdas de ociosidade, esperas na fila e tempo desperdiçado de Setup.</p>
                </div>

                {/* VSM Timeline Chart/Layout */}
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    {steps.map((st, idx) => (
                      <div key={st.id} className="border border-gray-200 bg-slate-50 p-3.5 space-y-2 relative">
                        <span className="text-[8px] font-mono text-gray-400 font-extrabold block">Etapa 0{idx + 1}</span>
                        <h4 className="text-xs font-serif font-bold text-gray-900 uppercase truncate leading-snug">{st.name}</h4>
                        
                        <div className="space-y-1 text-[10px] text-gray-500 font-mono">
                          <p className="text-emerald-700">✓ VA: {st.processingTime} min</p>
                          <p className="text-red-700">✗ NVA Setup: {st.setupTime} min</p>
                          <p className="text-red-500">✗ NVA Fila: {(st.processingTime * 0.4).toFixed(1)} min</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Visual timeline Waveform */}
                  <div className="p-4 bg-gray-50 border font-mono text-xs rounded-sm space-y-2">
                    <p className="text-[#C49746] font-bold text-[10px] uppercase">Reta de Tempos do Fluxo de Valor (VA/NVA wave):</p>
                    <div className="flex w-full bg-gray-200 h-10 rounded-xs overflow-hidden relative text-[9px] text-center font-bold text-white uppercase tracking-wider">
                      <div style={{ width: `${processEfficiency}%` }} className="bg-emerald-600 flex items-center justify-center p-1" title="Value Added (Produção Real útil)">
                        VA (Touch Time)
                      </div>
                      <div style={{ width: `${100 - processEfficiency}%` }} className="bg-red-500 flex items-center justify-center p-1" title="Non-Value Added (Filas, Coletas, Setups)">
                        NVA (Esperas + Setup)
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-[11px] font-sans text-gray-600 pt-2 border-t mt-2">
                      <div>
                        • Horas Ativas de Agregação de Valor (Touch Time): <strong className="text-gray-950 font-mono">{totalVA_Time.toFixed(1)} min</strong>
                      </div>
                      <div>
                        • Horas Invisíveis Perdidas em Fila &amp; Setup: <strong className="text-gray-950 font-mono">{totalNVA_Time.toFixed(1)} min</strong>
                      </div>
                    </div>
                  </div>

                  <div className="bg-emerald-50 text-emerald-950 p-4 border border-emerald-300 rounded-xs flex justify-between items-center text-xs">
                    <div>
                      <h5 className="font-extrabold text-emerald-800">Eficiência Térmica de Ciclo de Processo (Process Cycle Efficiency):</h5>
                      <p className="text-[10px] text-gray-500 mt-1 max-w-md">Percentual do Lead Time na fábrica que é dedicado à efetiva alteração física do produto de modo agregador.</p>
                    </div>
                    <div className="text-3xl font-serif font-black text-[#16a34a]">{processEfficiency.toFixed(1)}% PCE</div>
                  </div>
                </div>
              </div>
            )}

            {/* QUALITY TOOL 2: MATRIZ FMEA */}
            {selectedQualityTool === "FMEA" && (
              <div className="bg-white border border-[#1A1A1A]/15 p-6 shadow-sm space-y-6 animate-fade-in text-left">
                <div className="border-b pb-3 space-y-1">
                  <h3 className="text-lg font-serif font-bold text-gray-950 uppercase">FMEA - Ficha de Modos de Falha e Efeitos</h3>
                  <p className="text-xs text-gray-500">Mapear riscos preventivos de projetos calculando o RPN (Risk Priority Number = Gravidade × Ocorrência × Detecção).</p>
                </div>

                <div className="overflow-x-auto text-[11px] font-sans">
                  <table className="w-full text-left border border-collapse">
                    <thead>
                      <tr className="bg-[#FAF8F5] border-b text-[8.5px] uppercase font-mono text-gray-500">
                        <th className="p-2 border-r">Atividade</th>
                        <th className="p-2 border-r">Modo de Falha</th>
                        <th className="p-2 border-r">Efeito Gravíssimo</th>
                        <th className="p-2 border-r text-center">G (1-10)</th>
                        <th className="p-2 border-r">Causa raiz</th>
                        <th className="p-2 border-r text-center">O (1-10)</th>
                        <th className="p-2 border-r text-center">D (1-10)</th>
                        <th className="p-2 border-r font-bold text-gray-950 text-center">RPN</th>
                        <th className="p-2">Ação Mitigadora Recomendada</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fmeaRows.map((row, idx) => {
                        const rpn = row.severity * row.occurrence * row.detection;
                        const isHighRisk = rpn >= 200;
                        return (
                          <tr key={idx} className={`border-b border-gray-100 hover:bg-slate-50/50 ${isHighRisk ? "bg-red-50/30" : ""}`}>
                            <td className="p-2 border-r font-bold text-gray-900 truncate max-w-[120px]">{row.stepName}</td>
                            <td className="p-2 border-r text-gray-600 leading-normal">{row.failureMode}</td>
                            <td className="p-2 border-r text-gray-600 leading-normal">{row.effect}</td>
                            <td className="p-2 border-r text-center text-gray-500 font-mono">
                              <select
                                value={row.severity}
                                onChange={(e) => handleUpdateFmeaValue(idx, "severity", parseInt(e.target.value))}
                                className="bg-transparent border border-transparent hover:border-gray-300 font-bold p-0.5"
                              >
                                {[...Array(10)].map((_, i) => <option key={i+1} value={i+1}>{i+1}</option>)}
                              </select>
                            </td>
                            <td className="p-2 border-r text-gray-600 leading-normal">{row.cause}</td>
                            <td className="p-2 border-r text-center text-gray-500 font-mono">
                              <select
                                value={row.occurrence}
                                onChange={(e) => handleUpdateFmeaValue(idx, "occurrence", parseInt(e.target.value))}
                                className="bg-transparent border border-transparent hover:border-gray-300 font-bold p-0.5"
                              >
                                {[...Array(10)].map((_, i) => <option key={i+1} value={i+1}>{i+1}</option>)}
                              </select>
                            </td>
                            <td className="p-2 border-r text-center text-gray-500 font-mono">
                              <select
                                value={row.detection}
                                onChange={(e) => handleUpdateFmeaValue(idx, "detection", parseInt(e.target.value))}
                                className="bg-transparent border border-transparent hover:border-gray-300 font-bold p-0.5"
                              >
                                {[...Array(10)].map((_, i) => <option key={i+1} value={i+1}>{i+1}</option>)}
                              </select>
                            </td>
                            <td className="p-2 border-r text-center font-bold">
                              <span className={`px-1.5 py-0.5 font-mono text-xs ${
                                isHighRisk ? "bg-red-100 text-red-900" : "bg-slate-100 text-slate-700"
                              }`}>
                                {rpn}
                              </span>
                            </td>
                            <td className="p-2 text-gray-600 italic leading-normal text-[10.5px]">{row.action}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400 italic font-sans">*Dica: Altere os números G, O ou D na tabela para recalcular o RPN instantaneamente.</span>
                  <button
                    onClick={handleAddFmeaRow}
                    className="bg-[#1A1A1A] hover:bg-gray-800 text-white font-mono text-[9.5px] uppercase tracking-widest font-bold py-1.5 px-3 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    + Mapear Outro Risco FMEA
                  </button>
                </div>
              </div>
            )}

            {/* QUALITY TOOL 3: ISHIKAWA FISHBONE */}
            {selectedQualityTool === "ISHIKAWA" && (
              <div className="bg-white border border-[#1A1A1A]/15 p-6 shadow-sm space-y-6 animate-fade-in text-left">
                
                <div className="border-b pb-3 space-y-1">
                  <h3 className="text-lg font-serif font-bold text-gray-950 uppercase">Diagrama Espinha de Peixe (Ishikawa 6M)</h3>
                  <p className="text-xs text-gray-500">Identificar, explorar e organizar causas fundamentais geradoras de um problema de qualidade específico em nosso fluxo.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                  <div>
                    <label className="block text-[8px] uppercase tracking-wider font-extrabold text-gray-500 mb-1">Efeito / Problema em Investigação</label>
                    <select
                      value={selectedIshikawaIssue}
                      onChange={(e) => setSelectedIshikawaIssue(e.target.value)}
                      className="bg-white border rounded-none text-xs px-2.5 py-1.5 font-serif font-bold focus:outline-none focus:border-[#C49746]"
                    >
                      <option value="Elevado Retrabalho na Bancada AOI">Elevado Retrabalho na Bancada AOI</option>
                      <option value="Perdas Críticas de Setup (SMED) na Impressora">Perdas Críticas de Setup (SMED) na Impressora</option>
                      <option value="Saturação e Filas Constantes no Refluxo">Saturação e Filas Constantes no Refluxo</option>
                    </select>
                  </div>
                </div>

                {/* THE FISHBONE SVG BOARD */}
                <div className="bg-[#FAF8F5] border p-4 overflow-x-auto relative min-h-[300px] flex flex-col justify-between">
                  
                  {/* Spine Layout diagram */}
                  <div className="grid grid-cols-3 gap-4 text-[10px] leading-relaxed relative">
                    
                    {/* Top row causes: Método, Máquina, Mão de Obra */}
                    <div className="border border-indigo-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-indigo-800 font-mono block border-b pb-1">📐 MÉTODO (Method)</strong>
                      {ishikawaCauses.method.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("method", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                    <div className="border border-indigo-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-indigo-800 font-mono block border-b pb-1">⚙️ MÁQUINA (Machine)</strong>
                      {ishikawaCauses.machine.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("machine", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                    <div className="border border-indigo-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-indigo-800 font-mono block border-b pb-1">👥 MÃO DE OBRA (Manpower)</strong>
                      {ishikawaCauses.manpower.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("manpower", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                    {/* Central spine separator */}
                    <div className="col-span-3 h-1.5 bg-[#1A1A1A] my-3 rounded-full flex items-center justify-end pr-4 text-white text-[9px] font-mono select-none">
                      ⚠️ PROBLEMA: {selectedIshikawaIssue} →
                    </div>

                    {/* Bottom row: Material, Medida, Meio Ambiente */}
                    <div className="border border-emerald-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-emerald-800 font-mono block border-b pb-1">📦 MATERIAL</strong>
                      {ishikawaCauses.material.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("material", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                    <div className="border border-emerald-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-emerald-800 font-mono block border-b pb-1">📏 MEDIÇÃO (Measurement)</strong>
                      {ishikawaCauses.measurement.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("measurement", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                    <div className="border border-emerald-200/50 bg-white p-2.5 rounded-sm space-y-1">
                      <strong className="text-emerald-800 font-mono block border-b pb-1">🌱 MEIO AMBIENTE (Milieu)</strong>
                      {ishikawaCauses.environment.map((c, i) => (
                        <div key={i} className="flex justify-between items-center text-[9.5px] text-gray-600 bg-slate-50 p-1">
                          <span>{c}</span>
                          <button onClick={() => handleRemoveIshikawaCause("environment", i)} className="text-red-500 hover:underline">✕</button>
                        </div>
                      ))}
                    </div>

                  </div>

                  {/* Add Custom Cause Block */}
                  <form onSubmit={handleAddIshikawaCause} className="flex gap-2 pt-5 border-t mt-4 text-xs font-sans items-end">
                    <div className="flex-grow">
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Causa Fundamentada Adicional</label>
                      <input
                        type="text"
                        value={newCauseText}
                        onChange={(e) => setNewCauseText(e.target.value)}
                        placeholder="Ex: Falha na limpeza das lentes no fim do turno..."
                        className="w-full bg-white border px-3 py-1.5 focus:outline-none text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[8px] uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 mb-1">Categoria 6M</label>
                      <select
                        value={newCauseCategory}
                        onChange={(e: any) => setNewCauseCategory(e.target.value)}
                        className="bg-white border rounded-none text-xs p-1 px-2.5 focus:outline-none focus:border-violet-700"
                      >
                        <option value="method">Método (Method)</option>
                        <option value="machine">Máquina (Machine)</option>
                        <option value="manpower">Mão de Obra (Manpower)</option>
                        <option value="material">Material</option>
                        <option value="measurement">Medição (Measurement)</option>
                        <option value="environment">Meio Ambiente</option>
                      </select>
                    </div>
                    <button
                      type="submit"
                      className="bg-violet-700 hover:bg-violet-800 text-white font-mono text-[9.5px] uppercase tracking-widest font-bold py-2 px-4 transition-colors cursor-pointer"
                    >
                      Inserir Causa
                    </button>
                  </form>
                </div>

              </div>
            )}

            {/* QUALITY TOOL 4: 5S AUDITOR */}
            {selectedQualityTool === "5S" && (
              <div className="bg-white border border-[#1A1A1A]/15 p-6 shadow-sm space-y-6 animate-fade-in text-left">
                
                <div className="border-b pb-3 space-y-1">
                  <h3 className="text-lg font-serif font-bold text-gray-950 uppercase">Auditoria Kaizen Lean de Metodologia 5S</h3>
                  <p className="text-xs text-gray-500">Mapear o nível de maturidade da cultura 5S das bancadas operacionais para mitigar perdas e variabilidade acentuada.</p>
                </div>

                {/* Audit Grid list */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  {[
                    { name: "1. SEIRI (Descarte)", set: setSeiriScore, val: seiriScore, desc: "Apenas ferramentas e itens úteis imediatos na bancada. Nenhum item obsoleto." },
                    { name: "2. SEITON (Organização)", set: setSeitonScore, val: seitonScore, desc: "Identificação Clara de posições no chão (linhas amarelas) e quadros de ferramentas." },
                    { name: "3. SEISO (Limpeza)", set: setSeisoScore, val: seisoScore, desc: "Poeiras limpas, respingos eliminados na impressora e bancada AOI impecável." },
                    { name: "4. SEIKETSU (Padronização)", set: setSeiketsuScore, val: seiketsuScore, desc: "SOPs expostos à altura do olho do operador com fotos e esquemas visuais." },
                    { name: "5. SHITSUKE (Maturidade)", set: setShitsukeScore, val: shitsukeScore, desc: "Equipe audita a si mesma com checklists e preenche relatórios sem cobrança externa." }
                  ].map((s, idx) => (
                    <div key={idx} className="bg-slate-50 border p-4 text-center rounded-sm flex flex-col justify-between space-y-3">
                      <span className="text-[10px] font-bold uppercase tracking-wide text-gray-900 leading-snug block">{s.name}</span>
                      <p className="text-[9.5px] text-gray-500 leading-normal font-sans grow">{s.desc}</p>
                      
                      <select
                        value={s.val}
                        onChange={(e) => s.set(parseInt(e.target.value))}
                        className="w-full bg-white border rounded-none font-mono text-xs p-1 focus:outline-none text-center"
                      >
                        <option value="1">⭐ 1 (Crítico / Caos)</option>
                        <option value="2">⭐⭐ 2 (Iniciando)</option>
                        <option value="3">⭐⭐⭐ 3 (Parcial)</option>
                        <option value="4">⭐⭐⭐⭐ 4 (Conforme)</option>
                        <option value="5">⭐⭐⭐⭐⭐ 5 (Excelente)</option>
                      </select>
                    </div>
                  ))}
                </div>

                {/* Weighted total score display */}
                {(() => {
                  const sum = seiriScore + seitonScore + seisoScore + seiketsuScore + shitsukeScore;
                  const ratio = (sum / 25) * 100;
                  return (
                    <div className="bg-[#FAF8F5] border p-5 flex flex-col sm:flex-row justify-between items-center rounded-xs gap-4">
                      <div>
                        <h4 className="font-extrabold text-xs text-gray-900 uppercase">Pontuação Acumulada 5S para Células SMT:</h4>
                        <p className="text-[10px] text-gray-500 leading-normal mt-1 max-w-lg">Maturidades acima de 85% dão credibilidade de controle estrito mitigando em até 35% do desvio padrão do touch time.</p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="font-serif font-black text-3xl text-violet-700">{ratio.toFixed(0)}% Maturidade</span>
                        <div className="text-[9px] font-mono text-gray-400 uppercase tracking-tight text-center mt-1">Auditado Localmente</div>
                      </div>
                    </div>
                  );
                })()}

              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
