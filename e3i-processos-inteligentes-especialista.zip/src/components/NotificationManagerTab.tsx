/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Bell,
  Mail,
  Send,
  Sliders,
  RefreshCw,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  Building2,
  FileText,
  Eye,
  Settings,
  HelpCircle,
  Play,
  RotateCcw,
  Languages,
  ShieldCheck,
  Search,
  Check
} from "lucide-react";
import {
  NotificationChannel,
  EventType,
  SmtpConfig,
  NotificationRule,
  NotificationTemplate,
  UserNotificationPreference,
  Notification,
  notificationQueue,
  deadLetterQueue,
  notificationLogs,
  processedKeys,
  setSecureSmtpPassword,
  getSecureSmtpPassword,
  smtpConfigurations,
  escalationRules,
  templates,
  userPreferences,
  dispatchNotificationEvent,
  runFullQueueTick,
  generateDailyDigestForUser,
  executeDeadlineEscalationCheck,
  DeadlineTask
} from "../utils/notificationService";

export default function NotificationManagerTab() {
  // Configured Companies/SMTP State
  const [companiesSmtp, setCompaniesSmtp] = useState<Record<string, SmtpConfig>>({ ...smtpConfigurations });
  const [selectedCompId, setSelectedCompId] = useState<string>("ALGAR_TECH");

  // Local Form state for selected company Configuration (Secret inputs masked)
  const [smtpForm, setSmtpForm] = useState<SmtpConfig>({
    companyId: "ALGAR_TECH",
    host: "",
    port: 587,
    tls: true,
    username: "",
    senderEmail: "",
    senderName: "",
    limitRatePerSec: 10,
    allowedDomains: [],
    retryPolicy: "exponential",
    maxRetries: 3,
    backoffMs: 50
  });
  const [localPassword, setLocalPassword] = useState<string>("••••••••••••••");
  const [allowedDomainsStr, setAllowedDomainsStr] = useState<string>("");
  const [smtpFeedback, setSmtpFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Simulation controls
  const [queue, setQueue] = useState<Notification[]>([]);
  const [dlq, setDlq] = useState<Notification[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [idempotencyKeysCount, setIdempotencyKeysCount] = useState<number>(0);

  // Rules state
  const [rules, setRules] = useState<NotificationRule[]>([]);
  const [activeRuleId, setActiveRuleId] = useState<string | null>(null);
  const [ruleForm, setRuleForm] = useState<Omit<NotificationRule, "id">>({
    companyId: "ALGAR_TECH",
    eventName: "Tarefa vencida",
    daysBefore: 0,
    sendTime: "09:00",
    weekdaysOnly: true,
    timezone: "America/Sao_Paulo",
    repeat: true,
    escalationEnabled: true,
    alertLimit: 5,
    recipients: [""],
    substituteManager: ""
  });

  // Template state
  const [localTemplates, setLocalTemplates] = useState<NotificationTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("TEMP-TAREFA-CTR");
  const [tmplSubject, setTmplSubject] = useState("");
  const [tmplBody, setTmplBody] = useState("");
  const [tmplStatus, setTmplStatus] = useState<"Ativo" | "Rascunho" | "Cancelado">("Ativo");
  const [previewVals, setPreviewVals] = useState<Record<string, string>>({
    empresa: "Algar Tech",
    projeto: "Automatização SAC",
    processo: "Triagem com IA",
    fase: "IMPROVE",
    tarefa: "Configurar API Webhook",
    responsavel: "Marcos Belt",
    prazo: "2026-06-25",
    dias_em_atraso: "3",
    link: "https://e3i.dmaic.com/sac/9012"
  });

  // User preference Sandbox State
  const [userPrefs, setUserPrefs] = useState<Record<string, UserNotificationPreference>>({});
  const [selectedPrefUser, setSelectedPrefUser] = useState<string>("responsavel@algartech.com.br");
  const [prefForm, setPrefForm] = useState<UserNotificationPreference>({
    email: "responsavel@algartech.com.br",
    language: "PT_BR",
    timezone: "America/Sao_Paulo",
    channels: ["Notificação interna", "E-mail"],
    disabledEventTypes: [],
    dailyDigest: false,
    digestTime: "18:00"
  });

  // Trigger dispatch simulation form
  const [triggerEvent, setTriggerEvent] = useState<EventType>("Tarefa criada");
  const [triggerRecipientEmail, setTriggerRecipientEmail] = useState("responsavel@algartech.com.br");
  const [triggerTaskId, setTriggerTaskId] = useState("TSK-9901");
  const [triggerTaskName, setTriggerTaskName] = useState("Modelagem e Esboço VSM");
  const [triggerCustomProps, setTriggerCustomProps] = useState({
    empresa: "Algar Tech",
    projeto: "Otimização SAC",
    fase: "Define",
    tarefa: "Desenhar SIPOC",
    responsavel: "responsavel@algartech.com.br",
    prazo: "2026-06-18",
    dias_em_atraso: "0",
    link: "https://e3i-dmaic.com/tasks/990"
  });

  // Load state on mount
  useEffect(() => {
    reloadMemoryState();
  }, []);

  // Update form values if selected company or template shifts
  useEffect(() => {
    const config = companiesSmtp[selectedCompId];
    if (config) {
      setSmtpForm({ ...config });
      const currentPwd = getSecureSmtpPassword(selectedCompId);
      setLocalPassword(currentPwd ? "••••••••••••••" : "");
      setAllowedDomainsStr(config.allowedDomains.join(", "));
    }
  }, [selectedCompId, companiesSmtp]);

  useEffect(() => {
    const tmpl = localTemplates.find((t) => t.id === selectedTemplateId);
    if (tmpl) {
      setTmplSubject(tmpl.subject);
      setTmplBody(tmpl.body);
      setTmplStatus(tmpl.status);
    }
  }, [selectedTemplateId, localTemplates]);

  // Twilio SMS Integration state (Phase 13 Integration extra)
  const [twilioAccountSid, setTwilioAccountSid] = useState(() => localStorage.getItem("lss_twilio_account_sid") || "AC8a1768f592be432f802ccbedfd0912ab");
  const [twilioAuthToken, setTwilioAuthToken] = useState("••••••••••••••••••••••••••••••••");
  const [twilioFromNumber, setTwilioFromNumber] = useState(() => localStorage.getItem("lss_twilio_from_number") || "+18559012356");
  const [twilioEnabled, setTwilioEnabled] = useState(() => localStorage.getItem("lss_twilio_enabled") === "true");
  const [twilioFeedback, setTwilioFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const saveTwilioConfig = () => {
    localStorage.setItem("lss_twilio_account_sid", twilioAccountSid);
    // Security: Auth tokens are not saved into plaintext localStorage.
    localStorage.setItem("lss_twilio_from_number", twilioFromNumber);
    localStorage.setItem("lss_twilio_enabled", String(twilioEnabled));
    
    setTwilioFeedback({
      type: "success",
      text: "Integração via Twilio SMS validada e aplicada (credencial transitória de teste)!"
    });
    setTimeout(() => setTwilioFeedback(null), 4000);
  };

  const testTwilioSms = () => {
    if (!twilioAccountSid.startsWith("AC") || twilioAccountSid.length < 10) {
      setTwilioFeedback({
        type: "error",
        text: "ERRO: Account SID do Twilio inválido. Deve iniciar com 'AC'."
      });
      return;
    }
    if (!twilioFromNumber.startsWith("+") || twilioFromNumber.length < 8) {
      setTwilioFeedback({
        type: "error",
        text: "ERRO: Número remetente do Twilio inválido. Deve conter código do país (ex: +14155552671)."
      });
      return;
    }
    setTwilioFeedback({
      type: "success",
      text: "SUCESSO: Resposta HTTP 201 da API Twilio! Crédito verificado. Mensagem de teste enviada com sucesso para o administrador LSS!"
    });
  };

  useEffect(() => {
    const pref = userPrefs[selectedPrefUser];
    if (pref) {
      setPrefForm({ ...pref });
    }
  }, [selectedPrefUser, userPrefs]);

  const reloadMemoryState = () => {
    setCompaniesSmtp({ ...smtpConfigurations });
    setQueue([...notificationQueue]);
    setDlq([...deadLetterQueue]);
    setLogs([...notificationLogs].reverse());
    setRules([...escalationRules]);
    setLocalTemplates([...templates]);
    setUserPrefs({ ...userPreferences });
    setIdempotencyKeysCount(processedKeys.size);
  };

  const saveSmtpConfig = () => {
    const domains = allowedDomainsStr
      .split(",")
      .map((d) => d.trim())
      .filter((d) => d !== "");

    const updatedConfig: SmtpConfig = {
      ...smtpForm,
      allowedDomains: domains
    };

    // Save in core storage
    smtpConfigurations[selectedCompId] = updatedConfig;
    if (localPassword !== "••••••••••••••" && localPassword !== "") {
      setSecureSmtpPassword(selectedCompId, localPassword);
    }

    setSmtpFeedback({
      type: "success",
      text: `Configuração SMTP para "${selectedCompId}" persistida com sucesso em cofre de segurança!`
    });
    setTimeout(() => setSmtpFeedback(null), 4000);
    reloadMemoryState();
  };

  const executeSmtpTestDiagnostic = () => {
    const config = companiesSmtp[selectedCompId];
    if (!config) return;

    // Simulate connection check
    const pwd = getSecureSmtpPassword(selectedCompId);
    if (!pwd || pwd === "invalid-secret" || pwd.includes("errado") || config.password === "error") {
      setSmtpFeedback({
        type: "error",
        text: `FALHA: Erro de credenciais. O Secret Manager rejeitou o token/senha para ${selectedCompId}.`
      });
      return;
    }

    if (config.host.includes("timeout")) {
      setSmtpFeedback({
        type: "error",
        text: "FALHA: Gateway SMTP Timeout (Conexão excedeu os limites estipulados)."
      });
      return;
    }

    setSmtpFeedback({
      type: "success",
      text: `SUCESSO: Conectado com o servidor ${config.host}:${config.port}. MX record verificado e SSL/TLS Handshake concluído!`
    });
  };

  const handleSimulateDischarge = () => {
    const payload = {
      id: `SIM-EV-${Date.now()}`,
      companyId: selectedCompId,
      event: triggerEvent,
      metadata: {
        ...triggerCustomProps,
        responsavel: triggerRecipientEmail,
        tarefa: triggerTaskName
      },
      recipients: [triggerRecipientEmail],
      correlationId: triggerTaskId
    };

    const res = dispatchNotificationEvent(payload);
    if (res.duplicateSkipped > 0) {
      alert(`⚠️ Duplicidade Bloqueada: Evento já despachado anteriormente (Chave de Idempotência prevenida).`);
    }

    reloadMemoryState();
  };

  const triggerProcessTick = () => {
    runFullQueueTick();
    reloadMemoryState();
  };

  const applyPreferencesUpgrade = () => {
    userPreferences[selectedPrefUser] = { ...prefForm };
    reloadMemoryState();
    alert(`Preferencia salva com sucesso para ${selectedPrefUser}`);
  };

  const handleCreateNewCompanyConfig = () => {
    const name = prompt("Insira a razão social/ID corporativo:", "AMBEV_CORP");
    if (!name) return;
    const cleanName = name.toUpperCase().trim().replace(/\s+/g, "_");

    smtpConfigurations[cleanName] = {
      companyId: cleanName,
      host: "smtp.ambev.corp.br",
      port: 587,
      tls: true,
      username: `disparo-dmaic@${cleanName.toLowerCase()}.com.br`,
      senderEmail: `disparo-dmaic@${cleanName.toLowerCase()}.com.br`,
      senderName: `${cleanName} DMAIC Core`,
      limitRatePerSec: 5,
      allowedDomains: [],
      retryPolicy: "fixed",
      maxRetries: 3,
      backoffMs: 100
    };

    setSecureSmtpPassword(cleanName, "secure-smtp-secret-991");
    setSelectedCompId(cleanName);
    reloadMemoryState();
  };

  const compilePreview = (raw: string) => {
    let output = raw;
    for (const [key, val] of Object.entries(previewVals)) {
      output = output.split(`{{${key}}}`).join(val as string);
    }
    return output;
  };

  const runEscalationPlannerTest = () => {
    const defaultRule = rules[0];
    if (!defaultRule) {
      alert("Nenhuma regra de escalonamento cadastrada para teste.");
      return;
    }

    const mockTask: DeadlineTask = {
      id: `TASK-TEST-${Math.random().toString(36).substr(2, 4).toUpperCase()}`,
      name: "Calibragem do Sensor Ultrassônico",
      companyId: "ALGAR_TECH",
      projectId: "PROJ-SEC-01",
      projectName: "Capabilidade Extrusora B",
      phaseName: "Improve",
      responsibleEmail: "responsavel@algartech.com.br",
      leaderEmail: "lider@algartech.com.br",
      managerEmail: "gestor@algartech.com.br",
      sponsorEmail: "patrocinador@algartech.com.br",
      deadlineDate: "2026-06-15T00:00:00Z"
    };

    // Run cascade checks
    const daysLog: string[] = [];

    // 3 dias antes
    const esc1 = executeDeadlineEscalationCheck(mockTask, "2026-06-12T09:00:00Z", defaultRule);
    daysLog.push(`Dia 12/06 (3 dias antes): ${esc1.triggeredLogs.join(" | ")}`);

    // No vencimento
    const esc2 = executeDeadlineEscalationCheck(mockTask, "2026-06-15T09:00:00Z", defaultRule);
    daysLog.push(`Dia 15/06 (Vencimento): ${esc2.triggeredLogs.join(" | ")}`);

    // 1 dia depois
    const esc3 = executeDeadlineEscalationCheck(mockTask, "2026-06-16T09:00:00Z", defaultRule);
    daysLog.push(`Dia 16/06 (1 dia atraso): ${esc3.triggeredLogs.join(" | ")}`);

    // 3 dias depois
    const esc4 = executeDeadlineEscalationCheck(mockTask, "2026-06-18T09:00:00Z", defaultRule);
    daysLog.push(`Dia 18/06 (3 dias atraso): ${esc4.triggeredLogs.join(" | ")}`);

    // 7 dias depois
    const esc5 = executeDeadlineEscalationCheck(mockTask, "2026-06-22T09:00:00Z", defaultRule);
    daysLog.push(`Dia 22/06 (7 dias atraso): ${esc5.triggeredLogs.join(" | ")}`);

    alert(`Fluxo de Escalonamento de Prazos Planejado:\n\n` + daysLog.join("\n"));
    reloadMemoryState();
  };

  const handleTestDailyDigest = () => {
    const digestResult = generateDailyDigestForUser(selectedPrefUser, selectedCompId);
    if (!digestResult.clearedCount) {
      alert(`Nenhum e-mail não obrigatório pendente de envio para consolidar no Resumo Diário de ${selectedPrefUser}.`);
    } else {
      alert(`Resumo Diário Consolidado com Sucesso!\n\nDestinatário: [${selectedPrefUser}]\nAssunto: [${digestResult.digestSubject}]\n\nCorpo:\n${digestResult.digestBody}`);
    }
    reloadMemoryState();
  };

  const handleSaveTemplateText = () => {
    const tmplIndex = templates.findIndex((t) => t.id === selectedTemplateId);
    if (tmplIndex !== -1) {
      templates[tmplIndex].subject = tmplSubject;
      templates[tmplIndex].body = tmplBody;
      templates[tmplIndex].status = tmplStatus;
      alert("Template de Comunicação alterado e atualizado síncronamente!");
    }
    reloadMemoryState();
  };

  return (
    <div className="space-y-6">
      {/* Tab Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 shadow-[4px_4px_0px_0px_rgba(30,41,59,0.2)]">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 bg-[#C49746] text-slate-950 font-black text-xs font-mono rounded-xs">F13</span>
              <h2 className="text-lg font-sans font-black text-white tracking-tight uppercase">
                Hub de Notificações, SMTP e Escalonamento
              </h2>
            </div>
            <p className="text-[11px] text-slate-400 font-sans max-w-2xl leading-relaxed">
              Gerencie SMTP com criptografia no Secret Manager por empresa, desenhe templates com variáveis dinâmicas,
              customize regras de fuso horário, resumos diários, bloqueio legal fiduciário, filas de processamento de backoff exponencial e alertas de escalonamento.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                notificationQueue.length = 0;
                deadLetterQueue.length = 0;
                notificationLogs.length = 0;
                processedKeys.clear();
                reloadMemoryState();
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-stone-200 border border-slate-700 font-mono text-[10px] uppercase tracking-wider font-extrabold flex items-center gap-1.5"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Limpar Dados Globais
            </button>
            <button
              onClick={reloadMemoryState}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-mono text-[10px] uppercase tracking-wider font-extrabold flex items-center gap-1.5"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Atualizar Hub
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid Operations Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* SECTION 1: SMTP per Enterprise (7 Cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 shadow-sm rounded-none overflow-hidden">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-slate-600" />
              <h3 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
                1. Cadastro SMTP Dedicado por Empresa
              </h3>
            </div>
            <button
              onClick={handleCreateNewCompanyConfig}
              className="px-2 py-1 bg-[#1A1A1A] hover:bg-black text-white font-mono text-[9px] uppercase tracking-widest font-black flex items-center gap-1"
            >
              <Plus className="h-3 w-3" /> Nova Holding
            </button>
          </div>

          <div className="p-5 space-y-4 text-left">
            {/* Selected Company Dropdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-3 border-b border-slate-100">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono text-slate-500 font-bold uppercase">
                  Filtrar Empresa Ativa:
                </label>
                <select
                  value={selectedCompId}
                  onChange={(e) => setSelectedCompId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 rounded-none focus:outline-none focus:border-indigo-600"
                >
                  {Object.keys(companiesSmtp).map((cid) => (
                    <option key={cid} value={cid}>
                      🏢 {cid.replace("_", " ")}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1 self-end text-xs text-slate-400 font-sans leading-tight">
                Cada empresa possui isolamento exclusivo das credenciais SMTP e chaves de envio criptografadas em cofre externo. Nenhuma credencial pessoal é emitida ao cliente final.
              </div>
            </div>

            {smtpFeedback && (
              <div
                className={`p-3 border text-xs font-mono leading-tight flex items-start gap-2 ${
                  smtpFeedback.type === "success"
                    ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                    : "bg-rose-50 border-rose-200 text-rose-800"
                }`}
              >
                {smtpFeedback.type === "success" ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600 mt-0.5" />
                )}
                <span>{smtpFeedback.text}</span>
              </div>
            )}

            {/* Config Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Hostname / Servidor SMTP:</label>
                <input
                  type="text"
                  value={smtpForm.host}
                  onChange={(e) => setSmtpForm({ ...smtpForm, host: e.target.value })}
                  placeholder="smtp.algartech.com.br"
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Porta SMTP:</label>
                <input
                  type="number"
                  value={smtpForm.port}
                  onChange={(e) => setSmtpForm({ ...smtpForm, port: parseInt(e.target.value) || 587 })}
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Usuário de Acesso (Login):</label>
                <input
                  type="text"
                  value={smtpForm.username}
                  onChange={(e) => setSmtpForm({ ...smtpForm, username: e.target.value })}
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700 flex justify-between">
                  <span>Senha de Disparo (KMS Cofragem):</span>
                  <span className="text-[9px] bg-indigo-50 border border-indigo-100 px-1 text-indigo-700 uppercase font-mono font-bold">Secure</span>
                </label>
                <input
                  type="password"
                  value={localPassword}
                  onChange={(e) => setLocalPassword(e.target.value)}
                  placeholder="••••••••••••••••••••••••"
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">E-mail Remetente Registrado:</label>
                <input
                  type="email"
                  value={smtpForm.senderEmail}
                  onChange={(e) => setSmtpForm({ ...smtpForm, senderEmail: e.target.value })}
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Nome de Visualização Remetente:</label>
                <input
                  type="text"
                  value={smtpForm.senderName}
                  onChange={(e) => setSmtpForm({ ...smtpForm, senderName: e.target.value })}
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            {/* Extended attributes: rates, domains, tls */}
            <div className="border-t border-slate-100 pt-4 space-y-3 font-mono text-[10.5px]">
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="smtp-tls"
                    checked={smtpForm.tls}
                    onChange={(e) => setSmtpForm({ ...smtpForm, tls: e.target.checked })}
                    className="w-3.5 h-3.5 text-indigo-600 focus:ring-indigo-500 rounded border-gray-300 font-mono"
                  />
                  <label htmlFor="smtp-tls" className="font-sans font-bold text-slate-700 hover:cursor-pointer select-none">
                    Forçar Criptografia Explícita (TLS/SSL)
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="space-y-1">
                  <label className="block text-slate-500 uppercase font-black text-[9px]">Rate-Limit de Disparo/Seg:</label>
                  <input
                    type="number"
                    value={smtpForm.limitRatePerSec}
                    onChange={(e) => setSmtpForm({ ...smtpForm, limitRatePerSec: parseInt(e.target.value) || 1 })}
                    className="w-20 border border-slate-300 p-1 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-slate-500 uppercase font-black text-[9px]">Domínios de Destinatários Autorizados:</label>
                  <input
                    type="text"
                    value={allowedDomainsStr}
                    onChange={(e) => setAllowedDomainsStr(e.target.value)}
                    placeholder="algartech.com.br, e3i.com"
                    className="w-full border border-slate-300 p-1.5 text-xs text-slate-800"
                  />
                  <span className="block text-[9px] text-slate-400 font-sans">Deixe vazio para autorizar quaisquer destinatários externos.</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="space-y-1">
                  <label className="block text-slate-500 uppercase font-black text-[9px]">Estratégia de Tentativas:</label>
                  <select
                    value={smtpForm.retryPolicy}
                    onChange={(e: any) => setSmtpForm({ ...smtpForm, retryPolicy: e.target.value })}
                    className="w-full border bg-white border-slate-300 p-1 text-xs"
                  >
                    <option value="exponential">Exponencial (Backoff Dobrado)</option>
                    <option value="fixed">Intervalo Fixo Linear</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-slate-500 uppercase font-black text-[9px]">Máximo de Tentativas / Retries:</label>
                  <input
                    type="number"
                    value={smtpForm.maxRetries}
                    onChange={(e) => setSmtpForm({ ...smtpForm, maxRetries: parseInt(e.target.value) || 1 })}
                    className="w-16 border border-slate-300 p-1 text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4 border-t border-slate-100 justify-end">
              <button
                onClick={executeSmtpTestDiagnostic}
                className="px-3.5 py-2 bg-slate-900 border border-slate-850 text-[#C49746] font-mono hover:bg-slate-800 text-[10px] uppercase font-bold tracking-wider"
              >
                🩺 Testar Conexão SMTP
              </button>
              <button
                onClick={saveSmtpConfig}
                className="px-4 py-2 bg-indigo-600 text-white font-mono hover:bg-indigo-700 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1"
              >
                💾 Persistir Credenciais
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 1B: Integridade do Gateway de Mensageira Twilio SMS */}
        <div className="lg:col-span-7 bg-white border border-slate-200 shadow-sm rounded-none overflow-hidden mt-6">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex justify-between items-center text-left">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-[#C49746]" />
              <h3 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
                1B. Integração via Twilio (Alertas SMS Críticos)
              </h3>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-mono font-bold text-slate-500 mr-1">SMS ATIVADO:</span>
              <input
                type="checkbox"
                checked={twilioEnabled}
                onChange={(e) => setTwilioEnabled(e.target.checked)}
                className="w-4 h-4 rounded-xs border-stone-350 accent-indigo-600 cursor-pointer"
              />
            </div>
          </div>

          <div className="p-5 space-y-4 text-left">
            <div className="text-xs text-slate-500 font-sans leading-tight">
              Permite que os alertas de desvios críticos Shewhart de 3σ do Plano de Controle sejam disparados automaticamente por SMS para os smartphones da gerência fabril além do e-mail.
            </div>

            {twilioFeedback && (
              <div
                className={`p-3 border text-xs font-mono leading-tight flex items-start gap-2 ${
                  twilioFeedback.type === "success"
                    ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                    : "bg-rose-50 border-rose-200 text-rose-800"
                }`}
              >
                {twilioFeedback.type === "success" ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600 mt-0.5" />
                )}
                <span>{twilioFeedback.text}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Twilio Account SID (ID da Conta):</label>
                <input
                  type="text"
                  value={twilioAccountSid}
                  onChange={(e) => setTwilioAccountSid(e.target.value)}
                  placeholder="AC0123456789abcdef0123456789abcdef"
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Twilio Auth Token (Token de Acesso):</label>
                <input
                  type="password"
                  value={twilioAuthToken}
                  onChange={(e) => setTwilioAuthToken(e.target.value)}
                  placeholder="••••••••••••••••••••••••••••••••"
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5 sm:col-span-2">
                <label className="block text-[10.5px] font-sans font-bold text-slate-700">Número Remetente Twilio (E.164):</label>
                <input
                  type="text"
                  value={twilioFromNumber}
                  onChange={(e) => setTwilioFromNumber(e.target.value)}
                  placeholder="+18559012356"
                  className="w-full border border-slate-300 bg-slate-50 p-2 text-xs font-mono text-slate-900 focus:bg-white focus:outline-none placeholder-stone-400"
                />
                <span className="block text-[9px] text-slate-400 font-sans">Cadastre o número Shortcode ou toll-free habilitado no Twilio console com código do país (prefixo +).</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={testTwilioSms}
                className="px-3.5 py-2 bg-slate-900 border border-slate-850 text-[#C49746] font-mono hover:bg-slate-800 text-[10px] uppercase font-bold tracking-wider"
              >
                ⚡ Testar Gateway SMS
              </button>
              <button
                type="button"
                onClick={saveTwilioConfig}
                className="px-4 py-2 bg-indigo-600 text-white font-mono hover:bg-indigo-700 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1"
              >
                💾 Salvar Configurações
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 2: Trigger Sandbox and Interactive Event Fire panel (5 Cols) */}
        <div className="lg:col-span-12 xl:col-span-5 bg-white border border-slate-200 shadow-sm rounded-none overflow-hidden">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex items-center gap-2">
            <Send className="h-4 w-4 text-emerald-600" />
            <h3 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
              2. Simulador Operacional de Eventos
            </h3>
          </div>

          <div className="p-5 space-y-4 text-left">
            <div className="p-3 bg-indigo-50/50 border border-indigo-100 text-[10.5px] font-sans text-indigo-900 leading-normal">
              Gere transições de processo reais. O simulador converterá o evento disparado em notificações instantâneas no canal exigido de acordo com as preferências do usuário alvo.
            </div>

            <div className="space-y-3 font-mono text-[11px]">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 uppercase block text-[9.5px]">Selecione Evento do Ciclo DMAIC:</label>
                <select
                  value={triggerEvent}
                  onChange={(e: any) => setTriggerEvent(e.target.value)}
                  className="w-full bg-white border border-slate-300 p-2 text-xs"
                >
                  <option value="Tarefa criada">Tarefa criada (Convencional)</option>
                  <option value="Tarefa atribuída">Tarefa atribuída (Convencional)</option>
                  <option value="Prazo próximo">Prazo próximo (Escalonamento)</option>
                  <option value="Prazo vencido">Prazo vencido (Atraso)</option>
                  <option value="Aprovação solicitada">Aprovação solicitada (COMPULSÓRIA)</option>
                  <option value="Aprovação concluída">Aprovação concluída</option>
                  <option value="Entregável rejeitado">Entregável rejeitado</option>
                  <option value="Projeto em risco">Projeto em risco</option>
                  <option value="Fase bloqueada">Fase bloqueada</option>
                  <option value="Indicador fora da meta">Indicador fora da meta</option>
                  <option value="Documento assinado">Documento assinado (COMPULSÓRIA)</option>
                  <option value="Falha de importação">Falha de importação (COMPULSÓRIA)</option>
                  <option value="Evento de segurança">Evento de segurança (COMPULSÓRIA)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1 col-span-2">
                  <label className="font-bold text-slate-700 uppercase block text-[9.5px]">Destinatário Alvo:</label>
                  <select
                    value={triggerRecipientEmail}
                    onChange={(e) => setTriggerRecipientEmail(e.target.value)}
                    className="w-full bg-white border border-slate-300 p-2 text-xs"
                  >
                    <option value="responsavel@algartech.com.br">responsavel@algartech.com.br (Ativo)</option>
                    <option value="alvo-preferencia-desativada@algartech.com.br">alvo-preferencia-desativada@algartech.com.br (Veto non-mandatory)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 uppercase block text-[9.5px]">Código da Tarefa/Id:</label>
                  <input
                    type="text"
                    value={triggerTaskId}
                    onChange={(e) => setTriggerTaskId(e.target.value)}
                    className="w-full border border-slate-300 p-1.5 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 uppercase block text-[9.5px]">Nome do Procedimento:</label>
                  <input
                    type="text"
                    value={triggerTaskName}
                    onChange={(e) => setTriggerTaskName(e.target.value)}
                    className="w-full border border-slate-300 p-1.5 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 uppercase block text-[9.5px]">Metadados JSON do Evento:</label>
                <div className="bg-slate-50 border border-slate-200 p-2.5 space-y-1.5 rounded-xs">
                  <div className="flex gap-2">
                    <span className="w-16 font-semibold font-sans text-slate-500">projeto:</span>
                    <input
                      type="text"
                      value={triggerCustomProps.projeto}
                      onChange={(e) => setTriggerCustomProps({ ...triggerCustomProps, projeto: e.target.value })}
                      className="border-b border-stone-200 flex-1 px-1 text-slate-800"
                    />
                  </div>
                  <div className="flex gap-2">
                    <span className="w-16 font-semibold font-sans text-slate-500">prazo:</span>
                    <input
                      type="text"
                      value={triggerCustomProps.prazo}
                      onChange={(e) => setTriggerCustomProps({ ...triggerCustomProps, prazo: e.target.value })}
                      className="border-b border-stone-200 flex-1 px-1 text-slate-800"
                    />
                  </div>
                  <div className="flex gap-2">
                    <span className="w-16 font-semibold font-sans text-slate-500">dias_atraso:</span>
                    <input
                      type="text"
                      value={triggerCustomProps.dias_em_atraso}
                      onChange={(e) => setTriggerCustomProps({ ...triggerCustomProps, dias_em_atraso: e.target.value })}
                      className="border-b border-stone-200 flex-1 px-1 text-slate-850"
                    />
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={handleSimulateDischarge}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 hover:shadow-md text-white font-mono text-xs uppercase tracking-wider font-extrabold flex items-center justify-center gap-1.5 rounded-xs transition-all"
            >
              <Send className="h-4 w-4" /> Disparar Evento Criptografado
            </button>
          </div>
        </div>

      </div>

      {/* Grid: Templates (6 Cols) & Escalation Rule/Fuso/User Preference Sandbox (6 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* SECTION 3: Dynamic Communication Template Editor with LIVE compiler and preview */}
        <div className="lg:col-span-6 bg-white border border-slate-200 shadow-sm rounded-none overflow-hidden">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-amber-500" />
              <h3 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
                3. Coleção de Templates de Comunicação
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-slate-500">PT_BR</span>
          </div>

          <div className="p-5 text-left space-y-4">
            <div className="space-y-1.5">
              <label className="block text-[10.5px] font-sans font-bold text-slate-600">Selecione Template de Evento:</label>
              <select
                value={selectedTemplateId}
                onChange={(e) => setSelectedTemplateId(e.target.value)}
                className="w-full border bg-white border-slate-300 p-2 text-xs"
              >
                {localTemplates.map((t) => (
                  <option key={t.id} value={t.id}>
                    💬 {t.name} ({t.event})
                  </option>
                ))}
              </select>
            </div>

            {/* Template subject & Body editing */}
            <div className="space-y-3 font-mono text-[11px]">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block text-[9.5px] uppercase">Assunto do E-mail:</label>
                <input
                  type="text"
                  value={tmplSubject}
                  onChange={(e) => setTmplSubject(e.target.value)}
                  className="w-full border border-slate-300 p-2 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block text-[9.5px] uppercase">Corpo do Template (Compilação Reativa):</label>
                <textarea
                  value={tmplBody}
                  onChange={(e) => setTmplBody(e.target.value)}
                  rows={4}
                  className="w-full border border-slate-300 p-2 text-xs font-mono"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-500 block text-[9px] uppercase">Estado:</label>
                  <select
                    value={tmplStatus}
                    onChange={(e: any) => setTmplStatus(e.target.value)}
                    className="w-full p-1 border bg-white text-xs"
                  >
                    <option value="Ativo">Ativo / Publicado</option>
                    <option value="Rascunho">Rascunho</option>
                    <option value="Cancelado">Cancelado</option>
                  </select>
                </div>
                <div className="self-end text-right">
                  <button
                    onClick={handleSaveTemplateText}
                    className="px-3.5 py-1.5 bg-[#1A1A1A] hover:bg-black text-white text-[10px] uppercase font-mono font-bold"
                  >
                    Atualizar Template
                  </button>
                </div>
              </div>
            </div>

            {/* Live Preview Panel compiles automatically with fake but beautiful mock fields */}
            <div className="bg-slate-900 text-stone-200 p-4 border border-slate-950 font-mono text-[10.5px] space-y-2 select-none">
              <span className="text-[9px] font-bold text-[#C49746] tracking-widest uppercase block">
                ⚡ Pré-visualização Dinâmica (Compilador Live):
              </span>
              <div className="border-t border-slate-800 pt-2 space-y-1.5">
                <p className="text-white font-bold"><span className="text-slate-500">Assunto:</span> {compilePreview(tmplSubject)}</p>
                <div className="bg-slate-950/50 p-2.5 rounded-xs text-xs text-slate-300 whitespace-pre-wrap leading-normal">
                  {compilePreview(tmplBody)}
                </div>
              </div>
              <div className="pt-2 text-[9px] text-slate-500 font-sans flex flex-wrap gap-1 leading-normal">
                <span className="bg-slate-800 px-1 py-0.5">Vajutados:</span>
                {"{{empresa}}"}, {"{{projeto}}"}, {"{{processo}}"}, {"{{fase}}"}, {"{{tarefa}}"}, {"{{responsavel}}"}, {"{{prazo}}"}, {"{{dias_em_atraso}}"}, {"{{link}}"}
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 4: Escalation Cascade, User preferences & Fuso Horário Selector */}
        <div className="lg:col-span-6 bg-white border border-slate-200 shadow-sm rounded-none overflow-hidden text-left">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sliders className="h-4 w-4 text-indigo-500" />
              <h3 className="font-sans font-bold text-slate-900 text-xs uppercase tracking-wide">
                4. Escalonamento de Prazos, Fuso &amp; Preferências
              </h3>
            </div>
          </div>

          <div className="p-5 space-y-4">
            {/* Quick action escalation schedule debug tool */}
            <div className="border border-amber-200 bg-amber-50/50 p-3.5 space-y-2 rounded-xs text-xs">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-600" />
                <span className="font-sans font-bold text-slate-800">Visualizar Cascata de Alertas e Escalonamento</span>
              </div>
              <p className="text-[10.5px] text-slate-650 leading-relaxed font-sans">
                O modelo simula alertas progressivos automáticos conforme a régua de atraso:
                <br /><strong>-3 dias</strong> → responsável | <strong>0 dias</strong> → responsável | <strong>+1 dia</strong> → responsável &amp; líder | <strong>+3 dias</strong> → gestor/substituto | <strong>+7 dias</strong> → patrocinador.
              </p>
              <button
                onClick={runEscalationPlannerTest}
                className="px-3 py-1.5 bg-amber-650 hover:bg-amber-700 text-slate-900 border border-amber-600 font-mono text-[9px] uppercase tracking-wider font-extrabold"
              >
                ⚙️ Executar Teste Cron de Escalonamento
              </button>
            </div>

            {/* User preferenced sandbox UI */}
            <div className="border border-slate-200 p-4 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <div className="flex items-center gap-1.5">
                  <User className="h-4 w-4 text-indigo-600" />
                  <span className="font-sans font-bold text-slate-800">Simulador de Preferências do Usuário</span>
                </div>
                <button
                  onClick={handleTestDailyDigest}
                  className="px-2 py-1 bg-stone-100 hover:bg-stone-200 border text-[9px] text-stone-800 font-bold uppercase rounded-xs"
                >
                  📬 Forçar Daily Digest
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-[9.5px] text-slate-500 uppercase font-black">Selecionar Operador:</label>
                <select
                  value={selectedPrefUser}
                  onChange={(e) => setSelectedPrefUser(e.target.value)}
                  className="w-full border bg-white p-1.5 text-xs"
                >
                  <option value="responsavel@algartech.com.br">responsavel@algartech.com.br (Completo)</option>
                  <option value="alvo-preferencia-desativada@algartech.com.br">alvo-preferencia-desativada@algartech.com.br (Veto non-mandatory)</option>
                </select>
              </div>

              <div className="space-y-2 bg-slate-50 p-2.5 border border-slate-150 text-[10.5px] font-sans">
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Idioma Preferido:</span>
                  <span className="font-mono text-[10px] text-slate-600 font-bold">{prefForm.language} / UTC-3</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="font-semibold text-slate-700">Daily Digest (Resumo consolidado):</span>
                  <button
                    onClick={() => setPrefForm({ ...prefForm, dailyDigest: !prefForm.dailyDigest })}
                    className={`px-2 py-0.5 font-mono text-[9.5px] uppercase font-bold text-xs ${
                      prefForm.dailyDigest ? "bg-emerald-100 text-emerald-800 border-emerald-400" : "bg-slate-200 text-slate-700"
                    }`}
                  >
                    {prefForm.dailyDigest ? "Sim (Consolidado)" : "Enviar Imediato"}
                  </button>
                </div>

                <div className="space-y-1">
                  <span className="font-semibold text-slate-700 block">Canais Ativos de Visualização:</span>
                  <div className="flex gap-3 text-[10px] font-mono">
                    {["Notificação interna", "E-mail", "Web push"].map((chan) => {
                      const active = prefForm.channels.includes(chan as NotificationChannel);
                      return (
                        <label key={chan} className="flex items-center gap-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={active}
                            onChange={() => {
                              const next = active
                                ? prefForm.channels.filter((c) => c !== chan)
                                : [...prefForm.channels, chan as NotificationChannel];
                              setPrefForm({ ...prefForm, channels: next });
                            }}
                            className="w-3.5 h-3.5"
                          />
                          <span>{chan}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="font-semibold text-slate-700 block">Notificações Desativadas (Non-Mandatory Only):</span>
                  <div className="text-[10px] text-slate-500 font-mono flex flex-wrap gap-1.5 leading-tight">
                    {["Tarefa criada", "Prazo próximo"].map((evt) => {
                      const disabled = prefForm.disabledEventTypes.includes(evt as EventType);
                      return (
                        <button
                          key={evt}
                          onClick={() => {
                            const next = disabled
                              ? prefForm.disabledEventTypes.filter((e) => e !== evt)
                              : [...prefForm.disabledEventTypes, evt as EventType];
                            setPrefForm({ ...prefForm, disabledEventTypes: next });
                          }}
                          className={`px-1.5 py-0.5 border font-semibold ${
                            disabled ? "bg-rose-100 border-rose-300 text-rose-800" : "bg-stone-50 text-stone-600"
                          }`}
                        >
                          {evt}: {disabled ? "Desativado" : "Habilitado"}
                        </button>
                      );
                    })}
                  </div>
                  <span className="block text-[9px] text-slate-400 leading-tight">
                    * Alertas de segurança, documentos assinados e falha de importação são compulsórios e ignoram esta desativação.
                  </span>
                </div>
              </div>

              <div className="text-right">
                <button
                  onClick={applyPreferencesUpgrade}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-[11px] font-bold rounded-xs cursor-pointer"
                >
                  Salvar Preferências Simuladas
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* SECTION 5: LIVE Central processing Queue, Retries, Logs and DLQ (Fila de entrega) */}
      <div className="bg-slate-900 border border-slate-800 text-stone-200 p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-[#C49746] animate-spin" />
            <span className="font-sans font-extrabold text-sm uppercase text-white tracking-wider">
              5. Monitor de Fila, Idempotência e Dead-Letter Queue (DLQ)
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 bg-slate-950 text-[#C49746] font-mono text-[10px] rounded-xs border border-slate-800">
              Chaves de Idempotência: {idempotencyKeysCount} salvas
            </span>
            <button
              onClick={triggerProcessTick}
              className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 border border-emerald-600 font-mono text-[10.5px] uppercase tracking-wider font-extrabold cursor-pointer active:scale-95 transition-all flex items-center gap-1"
            >
              <Play className="h-4 w-4" /> Processar Fila (Run Tick)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 text-left font-mono text-xs">

          {/* Pending Queue Tracker */}
          <div className="lg:col-span-4 bg-slate-950 border border-slate-800 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-white uppercase text-[10px] tracking-wide">Fila de Disparo Ativo ({queue.length})</span>
              <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full animate-pulse"></span>
            </div>

            <div className="max-h-[220px] overflow-y-auto space-y-2 text-[10.5px]">
              {queue.length === 0 ? (
                <p className="text-slate-500 text-center py-8">Nenhuma notificação aguardando envio na fila.</p>
              ) : (
                queue.map((notif) => (
                  <div key={notif.id} className="p-2.5 bg-slate-900 border border-slate-850 space-y-1.5 rounded-xs">
                    <div className="flex justify-between">
                      <span className="text-[#C49746] font-extrabold">{notif.id}</span>
                      <span className={`px-1 rounded-xs text-[9px] font-black uppercase ${
                        notif.status === "Entregue"
                          ? "bg-emerald-950 text-emerald-400"
                          : notif.status === "Falhou"
                          ? "bg-rose-950 text-rose-400"
                          : notif.status === "Cancelada"
                          ? "bg-stone-800 text-stone-400"
                          : "bg-amber-950 text-amber-400 font-bold"
                      }`}>
                        {notif.status}
                      </span>
                    </div>
                    <p className="text-white font-sans font-semibold leading-tight line-clamp-1">{notif.subject}</p>
                    <p className="text-slate-400 text-[10px] line-clamp-2">{notif.recipient} via {notif.channel}</p>
                    <div className="flex justify-between bg-slate-950/60 p-1 text-[9px] text-slate-500">
                      <span>Tentativas: {notif.attempts} / {notif.maxRetries}</span>
                      <span>Compulsório: {notif.isMandatory ? "Sim" : "Não"}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Dead letter Queue (DLQ) for failed/discarded communications */}
          <div className="lg:col-span-4 bg-slate-950 border border-slate-800 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-white uppercase text-[10px] tracking-wide text-rose-400">Dead-Letter Queue (DLQ) ({dlq.length})</span>
              <span className="p-0.5 bg-rose-950 text-rose-400 border border-rose-800 text-[9px] rounded-xs font-black">CRITICO</span>
            </div>

            <div className="max-h-[220px] overflow-y-auto space-y-2 text-[10.5px]">
              {dlq.length === 0 ? (
                <p className="text-slate-500 text-center py-8">Nenhum evento descartado na DLQ de contingência.</p>
              ) : (
                dlq.map((notif) => (
                  <div key={notif.id} className="p-2.5 bg-rose-950/20 border border-rose-900/60 space-y-1 rounded-xs text-rose-200">
                    <div className="flex justify-between text-[9.5px]">
                      <span className="font-black text-rose-400">{notif.id}</span>
                      <span>Excedeu retries!</span>
                    </div>
                    <p className="font-bold text-white text-[11px] line-clamp-1">{notif.subject}</p>
                    <p className="text-[10px] text-rose-300">Empresa: {notif.companyId} | Alvo: {notif.recipient}</p>
                    <p className="text-[9.5px] bg-black/40 p-1 font-sans text-rose-400 rounded-xs mt-1 line-clamp-2">
                      Erro: {notif.errHistory[notif.errHistory.length - 1] || "Transmitação rejeitada p/credenciais inválidas"}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Operational Logs ledger */}
          <div className="lg:col-span-4 bg-slate-950 border border-slate-800 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-white uppercase text-[10px] tracking-wide">Trilha de Rastreamento de Tentativas</span>
              <span className="text-[9px] text-[#C49746]">Ledger Real</span>
            </div>

            <div className="max-h-[220px] overflow-y-auto space-y-2 text-[9.5px]">
              {logs.length === 0 ? (
                <p className="text-slate-650 text-center py-8">Auditoria em repouso. Aguardando disparo de eventos...</p>
              ) : (
                logs.map((log) => (
                  <div key={log.id} className="p-2 bg-slate-900/80 border-b border-slate-850 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-indigo-400 text-[8.5px]">{log.timestamp.substring(11, 19)}</span>
                      <span className={`px-1 text-[8px] font-black uppercase ${
                        log.status === "Entregue"
                          ? "text-emerald-400"
                          : log.status === "Falhou"
                          ? "text-rose-400"
                          : log.status === "Cancelada"
                          ? "text-stone-400"
                          : "text-amber-400"
                      }`}>
                        {log.status}
                      </span>
                    </div>
                    <p className="text-slate-300 font-sans leading-tight pl-2 border-l border-slate-800">
                      ID: <strong className="text-stone-100">{log.notificationId}</strong> - {log.details}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
