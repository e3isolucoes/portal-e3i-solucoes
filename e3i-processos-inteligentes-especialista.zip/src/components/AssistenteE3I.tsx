import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  Send, 
  X, 
  Check, 
  ChevronRight, 
  Calendar, 
  Trash2, 
  TrendingUp, 
  LifeBuoy, 
  Activity, 
  Award,
  Zap,
  Sliders,
  Maximize2
} from "lucide-react";
import { ProcessStep, ProjectCharter, Sipoc } from "../types";

interface AssistenteE3IProps {
  isOpen: boolean;
  onClose: () => void;
  // State from parent
  steps: ProcessStep[];
  arrivalRate: number;
  stats: any;
  charter: ProjectCharter;
  sipoc: Sipoc;
  completedPhases: string[];
  setCompletedPhases: (phases: string[]) => void;
  setActivePhase: (phase: string) => void;
  
  // Handlers from parent (useAiAnalysis / useProcessCopilot proxies)
  aiLoading: boolean;
  aiError: string | null;
  aiResult: any;
  setAiResult: (res: any) => void;
  setAiError: (err: string | null) => void;
  handleCallGeminiApi: () => Promise<void>;

  copilotInput: string;
  setCopilotInput: (text: string) => void;
  isCopilotProcessing: boolean;
  startDate: string;
  setStartDate: (d: string) => void;
  endDate: string;
  setEndDate: (d: string) => void;
  handleCopilotRequest: () => Promise<void>;
  filteredHistory: any[];
  clearHistory: () => void;

  // Single click Kaizen actions
  onApplyBalanceamentoGargalo: () => void;
  onApplyVariabilidadeKaizen: () => void;
  onApplyPokaYokeYield: () => void;
  onApplyStaffSizingIncrement: () => void;
}

export function AssistenteE3I({
  isOpen,
  onClose,
  steps,
  arrivalRate,
  stats,
  charter,
  sipoc,
  completedPhases,
  setCompletedPhases,
  setActivePhase,
  aiLoading,
  aiError,
  aiResult,
  setAiResult,
  setAiError,
  handleCallGeminiApi,
  copilotInput,
  setCopilotInput,
  isCopilotProcessing,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  handleCopilotRequest,
  filteredHistory,
  clearHistory,
  onApplyBalanceamentoGargalo,
  onApplyVariabilidadeKaizen,
  onApplyPokaYokeYield,
  onApplyStaffSizingIncrement
}: AssistenteE3IProps) {
  const [activeTab, setActiveTab] = useState<"KAIZEN" | "GEMINI_ANALYST">("KAIZEN");

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black z-[99]"
            onClick={onClose}
          />

          {/* Contextual Assistant Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 220 }}
            className="fixed right-0 top-0 bottom-0 w-full sm:w-[460px] bg-white border-l-4 border-[#1A1A1A] p-6 shadow-2xl z-[100] flex flex-col h-full text-left"
          >
            {/* Header Title Bar */}
            <div className="flex justify-between items-center border-b border-gray-150 pb-4 mb-4 shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-1 px-2 bg-[#C49746] text-black font-mono text-[10px] font-black uppercase rounded-sm">
                  ⚡ E3I AI Hub
                </div>
                <h3 className="font-serif text-base font-black text-slate-900 uppercase tracking-tight">
                  Assistente E3I Processos
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 text-slate-400 hover:text-red-650 hover:bg-red-50 rounded-full transition-colors cursor-pointer"
                title="Fechar Painel do Assistente"
              >
                <X size={18} />
              </button>
            </div>

            {/* Diagnostic Alert Box */}
            <div className="bg-[#FAF9F5] border border-[#C49746]/20 p-3 rounded-md mb-4 flex flex-col gap-1.5 text-xs text-slate-700 shrink-0">
              <span className="text-[8px] font-mono uppercase tracking-widest text-[#C49746] font-bold">🩺 Status Real-time do Processo</span>
              <div className="flex flex-col gap-0.5 font-sans">
                <p className="leading-snug text-slate-900 flex items-center gap-1.5">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-rose-600 animate-pulse"></span>
                  Gargalo: <strong>{stats?.bottleneckStepName || "Nenhum"}</strong> ({stats?.systemCapacity?.toFixed(1) || 0} u/h)
                </p>
                <p className="leading-snug text-slate-500 pl-3 leading-relaxed">
                  Eficiência global projetada em <strong>{((stats?.rolledFirstPassYield || 0.95) * 100).toFixed(1)}% First Pass Yield</strong> com robustez de <strong>{stats?.sigmaLevel?.toFixed(2) || "4.1"}σ Sigmas</strong>.
                </p>
              </div>
            </div>

            {/* Drawer Tabs Navigation */}
            <div className="flex border-b border-[#1A1A1A] mb-4 shrink-0 font-mono text-[10px] font-bold uppercase">
              <button
                onClick={() => setActiveTab("KAIZEN")}
                className={`flex-1 py-2 text-center border-b-2 transition-all cursor-pointer ${
                  activeTab === "KAIZEN"
                    ? "border-[#1A1A1A] text-slate-900 font-extrabold bg-[#1A1A1A]/5"
                    : "border-transparent text-slate-400 hover:text-slate-800"
                }`}
              >
                🚀 Copiloto Kaizen
              </button>
              <button
                onClick={() => setActiveTab("GEMINI_ANALYST")}
                className={`flex-1 py-2 text-center border-b-2 transition-all cursor-pointer ${
                  activeTab === "GEMINI_ANALYST"
                    ? "border-[#1A1A1A] text-slate-900 font-extrabold bg-[#1A1A1A]/5"
                    : "border-transparent text-slate-400 hover:text-slate-800"
                }`}
              >
                💡 Análise de IA (Gemini)
              </button>
            </div>

            {/* Scrollable Content Viewport */}
            <div className="flex-grow overflow-y-auto space-y-4 pr-1 text-xs">
              
              {/* TAB 1: KAIZEN & COPILOT ACTION CARDS */}
              {activeTab === "KAIZEN" && (
                <div className="space-y-4 animate-fade-in">
                  
                  {/* One-click Optimization triggers */}
                  <div className="space-y-2">
                    <span className="text-[8.5px] block font-mono uppercase tracking-widest text-slate-400 font-extrabold">⚡ Ferramentas Científicas Kaizen (1-Clique)</span>
                    <div className="grid grid-cols-1 gap-2">
                      <button
                        onClick={onApplyBalanceamentoGargalo}
                        className="w-full text-left p-2.5 bg-[#FDFCFB] hover:bg-slate-50 border border-gray-250 hover:border-[#C49746] transition-all flex items-start gap-2.5 cursor-pointer rounded"
                      >
                        <span className="text-sm bg-amber-50 p-1.5 rounded text-[#C49746]">⚖️</span>
                        <div>
                          <strong className="block text-slate-900 font-bold">Balanceamento Estocástico de Gargalo</strong>
                          <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Aloca dinamicamente tempos ociosos de etapas mais rápidas do fluxo.</span>
                        </div>
                      </button>

                      <button
                        onClick={onApplyVariabilidadeKaizen}
                        className="w-full text-left p-2.5 bg-[#FDFCFB] hover:bg-slate-50 border border-gray-250 hover:border-[#C49746] transition-all flex items-start gap-2.5 cursor-pointer rounded"
                      >
                        <span className="text-sm bg-amber-50 p-1.5 rounded text-[#C49746]">📉</span>
                        <div>
                          <strong className="block text-slate-900 font-bold">Redução de Variabilidade (SMED Setup)</strong>
                          <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Aplica metodologia SMED para mitigar tempos de setup e desvio padrão.</span>
                        </div>
                      </button>

                      <button
                        onClick={onApplyPokaYokeYield}
                        className="w-full text-left p-2.5 bg-[#FDFCFB] hover:bg-slate-50 border border-gray-250 hover:border-[#C49746] transition-all flex items-start gap-2.5 cursor-pointer rounded"
                      >
                        <span className="text-sm bg-amber-50 p-1.5 rounded text-[#C49746]">🛡️</span>
                        <div>
                          <strong className="block text-slate-900 font-bold">Implantar Selo Poka-Yoke de Qualidade</strong>
                          <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Incrementa passagens corretas consecutivas blindando as etapas de qualidade.</span>
                        </div>
                      </button>

                      <button
                        onClick={onApplyStaffSizingIncrement}
                        className="w-full text-left p-2.5 bg-[#FDFCFB] hover:bg-slate-50 border border-gray-250 hover:border-[#C49746] transition-all flex items-start gap-2.5 cursor-pointer rounded"
                      >
                        <span className="text-sm bg-amber-50 p-1.5 rounded text-[#C49746]">👥</span>
                        <div>
                          <strong className="block text-slate-900 font-bold">Aumentar a Equipe (+1 Operador)</strong>
                          <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">Expande a capacidade de vazão do gargalo através de redundância paralela.</span>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Dialogue & Chat control */}
                  <div className="space-y-2 pt-2 border-t border-gray-100">
                    <span className="text-[8.5px] block font-mono uppercase tracking-widest text-slate-400 font-extrabold pb-1">🗣️ Comando por Linguagem Natural</span>
                    <div className="flex flex-col gap-2">
                      <textarea
                        value={copilotInput}
                        onChange={(e) => setCopilotInput(e.target.value)}
                        placeholder="Ex: 'Reduza a variabilidade', 'Aloque mais operadores no picking' ou 'Reduza tempo do gargalo'..."
                        className="w-full h-16 text-[11px] p-2 bg-white border border-slate-300 focus:outline-none focus:border-indigo-500 rounded font-sans leading-relaxed resize-none text-slate-900 placeholder-slate-400"
                      />
                      <button
                        onClick={handleCopilotRequest}
                        disabled={isCopilotProcessing || !copilotInput.trim()}
                        className="w-full bg-slate-950 hover:bg-slate-800 disabled:bg-slate-300 text-white font-mono font-bold text-[10px] uppercase py-2 px-3 tracking-wide flex items-center justify-center gap-1.5 rounded cursor-pointer transition-colors"
                      >
                        <Send size={11} className={isCopilotProcessing ? "animate-bounce text-amber-300" : "text-amber-400"} />
                        {isCopilotProcessing ? "Processando comando..." : "Enviar Comando Kaizen"}
                      </button>
                    </div>
                  </div>

                  {/* History Logs */}
                  {filteredHistory.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-gray-100 animate-fade-in text-left">
                      <div className="flex items-center justify-between">
                        <span className="text-[8.5px] font-mono uppercase tracking-widest text-slate-400 font-extrabold">📈 Histórico de Melhoria LSS</span>
                        <button
                          onClick={clearHistory}
                          className="text-[9px] font-mono text-red-500 hover:text-red-700 flex items-center gap-1 cursor-pointer"
                          title="Limpar histórico"
                        >
                          <Trash2 size={10} />
                          Limpar
                        </button>
                      </div>

                      {/* Date Filter */}
                      <div className="grid grid-cols-2 gap-2 text-[9px] bg-slate-50 p-2 border border-slate-200 rounded font-mono text-slate-600">
                        <div className="space-y-0.5">
                          <label className="block text-slate-400 font-extrabold uppercase text-[8px]">Início:</label>
                          <input
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            className="bg-white border rounded p-1 w-full text-[9px]"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <label className="block text-slate-400 font-extrabold uppercase text-[8px]">Término:</label>
                          <input
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            className="bg-white border rounded p-1 w-full text-[9px]"
                          />
                        </div>
                      </div>

                      {/* Logs Container */}
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-0.5 custom-scrollbar">
                        {filteredHistory.map((h) => (
                          <div key={h.id} className="p-2 bg-slate-50 border border-slate-150 rounded flex items-start gap-1.5 font-sans">
                            <span className="text-[10px] text-emerald-600 font-bold shrink-0">✓</span>
                            <div className="text-[10px] text-slate-700 space-y-0.5 leading-relaxed">
                              <p className="font-semibold text-slate-900">{h.message}</p>
                              <span className="text-[8px] font-mono text-slate-400 block flex items-center gap-1">
                                <Calendar size={8} />
                                {h.dateStr}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* TAB 2: DETAILED GEMINI API ANALYSIS */}
              {activeTab === "GEMINI_ANALYST" && (
                <div className="space-y-4 animate-fade-in text-slate-700 font-sans leading-relaxed">
                  <div className="space-y-2">
                    <span className="text-[8.5px] block font-mono uppercase tracking-widest text-slate-400 font-extrabold">💡 Consultoria Estatística Cognitiva</span>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Este gerador utiliza modelos Gemini para realizar um estudo de filas sobre a holding ativa. A inteligência analisa o tempo médio, volume estocástico, índice sigma e rascunha recomendações de simulação.
                    </p>
                    
                    <button
                      onClick={handleCallGeminiApi}
                      disabled={aiLoading}
                      className="w-full bg-[#C49746] hover:bg-amber-800 disabled:bg-slate-300 text-black font-mono font-black text-[10.5px] uppercase py-2 px-4 shadow-[3px_3px_0px_rgba(26,26,26,1)] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all flex items-center justify-center gap-1.5 rounded cursor-pointer"
                    >
                      <Sparkles size={13} className={aiLoading ? "animate-spin text-black" : "text-black"} />
                      {aiLoading ? "Gemini Analisando Processo..." : "Disparar Diagnóstico DMAIC"}
                    </button>
                  </div>

                  {aiError && (
                    <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-[10.5px] rounded-md flex items-start gap-2 font-mono">
                      <span className="font-bold text-red-650 shrink-0">⚠️ ERRO:</span>
                      <span>{aiError}</span>
                    </div>
                  )}

                  {/* AI Results Output Container */}
                  {aiResult ? (
                    <div className="space-y-3 bg-slate-50 border border-slate-200 p-4 rounded text-left animate-fade-in">
                      <div className="flex items-center gap-1 mb-1 text-slate-900 border-b border-dashed pb-1.5">
                        <Sparkles size={14} className="text-[#C49746]" />
                        <span className="font-serif font-extrabold text-xs uppercase">Relatório Gerencial Emitido</span>
                      </div>

                      <div className="space-y-2.5 text-[11px]">
                        <div>
                          <strong className="block text-slate-900 font-bold uppercase text-[9px] font-mono text-indigo-750">📈 Problem Statement (Status Atual):</strong>
                          <p className="text-slate-600 mt-0.5 pl-1.5 border-l-2 border-indigo-200">{aiResult.orAnalysis?.problemStatement || aiResult.problemStatement || "Identificado estresse operacional no gargalo técnico do fluxo."}</p>
                        </div>
                        
                        <div>
                          <strong className="block text-slate-900 font-bold uppercase text-[9px] font-mono text-[#C49746]">🎛️ Modelo de Balanceamento Sugerido:</strong>
                          <p className="text-slate-600 mt-0.5 pl-1.5 border-l-2 border-[#C49746]/40">{aiResult.orAnalysis?.recommendedConfiguration || aiResult.recommendedConfiguration || "Configuração paralela m/M/c com redistribuição proporcional à ociosidade."}</p>
                        </div>

                        <div>
                          <strong className="block text-slate-900 font-bold uppercase text-[9px] font-mono text-emerald-755">💡 Recomendações Táticas do Consultor:</strong >
                          <p className="text-slate-600 mt-0.5 pl-1.5 border-l-2 border-emerald-200">{aiResult.orAnalysis?.orSuggestions || aiResult.orSuggestions || "Ajuste metas de setup, aplique blindagens Kaizen nos desvios padrões e duplique servidores de picking."}</p>
                        </div>

                        <div>
                          <strong className="block text-slate-900 font-bold uppercase text-[9px] font-mono text-amber-750">⚡ Dica de Engenharia Lean Six Sigma:</strong>
                          <p className="text-slate-600 mt-0.5 pl-1.5 border-l-2 border-amber-200 font-medium italic">{aiResult.orAnalysis?.operationalTip || aiResult.operationalTip || "A variabilidade age como amplificador de WIP. Reduzir 10% do desvio padrão vale mais que expandir 20% do staff físico."}</p>
                        </div>
                      </div>

                      <div className="p-2 bg-emerald-50 border border-emerald-150 rounded flex items-center gap-1.5 text-[10px] text-emerald-800">
                        <span className="font-bold text-xs shrink-0 font-serif">✓</span>
                        <span>As fases **MEASURE** e **ANALYZE** da governança corporativa DMAIC foram homologadas automaticamente com este rascunho de IA!</span>
                      </div>
                    </div>
                  ) : (
                    !aiLoading && (
                      <div className="h-44 border border-dashed border-slate-200 rounded flex flex-col justify-center items-center text-center p-4 text-slate-400">
                        <Sparkles size={20} className="text-slate-300 mb-1.5" />
                        <p className="text-[10.5px]">Nenhum diagnóstico de IA carregado neste turno.</p>
                        <p className="text-[9.5px] text-slate-350 mt-1">Dispare a análise estatística para ver recomendações do consultor.</p>
                      </div>
                    )
                  )}

                </div>
              )}

            </div>

            {/* Footer Workspace Action */}
            <div className="border-t border-gray-150 pt-4 mt-4 text-[9px] font-mono text-slate-400 flex items-center justify-between shrink-0">
              <span>E3I PROCESSOS KAIZEN ENGINE</span>
              <span>v2.8.2-SECURE</span>
            </div>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
