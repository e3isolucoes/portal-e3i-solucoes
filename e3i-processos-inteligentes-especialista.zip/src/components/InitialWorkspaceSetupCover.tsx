import React, { useState, useEffect } from "react";
import { Building2, Briefcase, Plus, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, Database, FlaskConical, Layers, HelpCircle, Sliders } from "lucide-react";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";
import { Company } from "../types";
import E3ILogo from "./E3ILogo";

interface Props {
  activeUser: any;
  setActiveCompanyId: (id: string | null) => void;
  setActiveWorkspaceProjectId: (id: string | null) => void;
  onRefreshGlobalData: () => void;
}

export default function InitialWorkspaceSetupCover({
  activeUser,
  setActiveCompanyId,
  setActiveWorkspaceProjectId,
  onRefreshGlobalData
}: Props) {
  const email = activeUser?.email || "anonymous";

  // Environment tab: "production" (Dados Reais) vs "test" (Sandbox / Casos de Demonstração)
  const [envTab, setEnvTab] = useState<"production" | "test">(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("lss_training_mode") === "true" ? "test" : "production";
    }
    return "production";
  });

  const handleSwitchEnvTab = (tab: "production" | "test") => {
    setEnvTab(tab);
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_training_mode", tab === "test" ? "true" : "false");
      window.dispatchEvent(new Event("lss_training_mode_changed"));
    }
  };

  // Repositories fetch
  const [companies, setCompanies] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);

  // Local selection state
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");

  // Quick manual create state
  const [isCreatingNewCompany, setIsCreatingNewCompany] = useState(false);
  const [newCompName, setNewCompName] = useState("");
  const [newCompCnpj, setNewCompCnpj] = useState("00.000.000/0001-00");
  const [newCompInd, setNewCompInd] = useState("Varejo & Serviços");

  const [isCreatingNewProject, setIsCreatingNewProject] = useState(false);
  const [newProjName, setNewProjName] = useState("");
  const [newProjObj, setNewProjObj] = useState("");
  const [initBatchSize, setInitBatchSize] = useState<number>(15);
  const [defaultSetupTime, setDefaultSetupTime] = useState<number>(5);

  const refreshLocal = () => {
    const listComps = CompanyProjectRepository.getCompanies(email);
    const listProjs = CompanyProjectRepository.getProjects(email);
    setCompanies(listComps);
    setProjects(listProjs);
  };

  useEffect(() => {
    const unsubscribe = CompanyProjectRepository.addChangeListener(() => {
      refreshLocal();
    });
    return () => {
      unsubscribe();
    };
  }, [email]);

  // Autoload last accessed company and project once list loads
  useEffect(() => {
    if (companies.length > 0) {
      const lastCompanyId = localStorage.getItem("lss_last_company_id_" + email);
      if (lastCompanyId && companies.some(c => c.id === lastCompanyId)) {
        setSelectedCompanyId(lastCompanyId);
        
        const lastProjectId = localStorage.getItem("lss_last_project_id_" + email);
        const compProjects = projects.filter(p => p.companyId === lastCompanyId);
        if (lastProjectId && compProjects.some(p => p.id === lastProjectId)) {
          setSelectedProjectId(lastProjectId);
        } else {
          setSelectedProjectId("");
        }
      } else {
        const firstCompany = companies[0];
        setSelectedCompanyId(firstCompany.id);
        setSelectedProjectId("");
      }
    }
  }, [companies, projects, email]);

  // Adjust selected project when company changes
  useEffect(() => {
    if (selectedCompanyId) {
      const companyProjects = projects.filter((p) => p.companyId === selectedCompanyId);
      if (selectedProjectId === "") return;
      const isStillValid = companyProjects.some((p) => p.id === selectedProjectId);
      if (!isStillValid) setSelectedProjectId("");
    } else {
      setSelectedProjectId("");
    }
  }, [selectedCompanyId, projects, selectedProjectId]);

  const handleCreateCompanyManual = () => {
    if (!newCompName.trim()) return;
    
    // Ensure production mode is set for real user data
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_training_mode", "false");
      window.dispatchEvent(new Event("lss_training_mode_changed"));
    }

    const cid = "comp_" + Date.now().toString(36).substring(2, 6);
    const newCompany = {
      id: cid,
      name: newCompName.trim(),
      cnpj: newCompCnpj.trim() || "00.000.000/0001-00",
      industry: newCompInd,
      enabledModules: [],
      createdAt: new Date().toISOString()
    };

    const currentComps = CompanyProjectRepository.getCompanies(email);
    CompanyProjectRepository.saveCompanies([...currentComps, newCompany], email);
    
    // Auto-provision a clean initial project for this company
    const pid = "proj_" + Date.now().toString(36).substring(2, 6);
    const projTitle = newProjName.trim() || ("Otimização de Processo - " + newCompName.trim());
    const newProject = {
      id: pid,
      companyId: cid,
      name: projTitle,
      objective: newProjObj.trim() || "Mapear o fluxo de trabalho, identificar gargalos e otimizar a estabilidade operacional.",
      status: "Em Andamento" as const,
      createdAt: new Date().toISOString()
    };
    const currentProjs = CompanyProjectRepository.getProjects(email);
    CompanyProjectRepository.saveProjects([...currentProjs, newProject], email);

    // Initial setup in project data store with clean structure
    const store = { ...CompanyProjectRepository.getProjectDataStore(email) };
    store[pid] = {
      companyId: cid,
      initialBatchSize: initBatchSize,
      defaultSetupTime: defaultSetupTime,
      steps: [
        {
          id: "step_ini_1",
          name: "Entrada e Triagem Operacional",
          resource: "Operador de Atendimento",
          resourceCount: 1,
          processingTime: 10,
          standardDeviation: 1.5,
          setupTime: defaultSetupTime,
          yieldRate: 0.98
        },
        {
          id: "step_ini_2",
          name: "Processamento e Execução Principal",
          resource: "Analista Responsável",
          resourceCount: 1,
          processingTime: 15,
          standardDeviation: 2.0,
          setupTime: defaultSetupTime,
          yieldRate: 0.96
        }
      ],
      arrivalRate: 4,
      charter: {
        id: "char_" + pid,
        title: newProject.name,
        businessCase: "Otimizar tempo de resposta e capacidade de entrega com dados reais da empresa.",
        problemStatement: "Mapeamento inicial de gargalos e oscilações no fluxo de trabalho.",
        goalStatement: "Garantir previsibilidade de prazos e cumprimento das metas de SLA estipuladas.",
        scopeIn: "Processos operacionais diretos da organização.",
        scopeOut: "Fornecedores externos e áreas não correlacionadas.",
        team: "Equipe LSS: " + (activeUser?.fullName || "Líder de Projeto"),
        targetValue: 200
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(store, email);

    setCompanies([...currentComps, newCompany]);
    setProjects([...currentProjs, newProject]);
    setSelectedCompanyId(cid);
    setSelectedProjectId(pid);
    setIsCreatingNewCompany(false);
    setNewCompName("");
    setNewProjName("");
    setNewProjObj("");

    // Directly access workspace
    localStorage.setItem("lss_last_company_id_" + email, cid);
    localStorage.setItem("lss_last_project_id_" + email, pid);
    setActiveCompanyId(cid);
    setActiveWorkspaceProjectId(pid);
    onRefreshGlobalData();
  };

  const handleCreateProjectManual = () => {
    if (!newProjName.trim() || !selectedCompanyId) return;

    if (typeof window !== "undefined") {
      localStorage.setItem("lss_training_mode", "false");
      window.dispatchEvent(new Event("lss_training_mode_changed"));
    }

    const pid = "proj_" + Date.now().toString(36).substring(2, 6);
    const newProject = {
      id: pid,
      companyId: selectedCompanyId,
      name: newProjName.trim(),
      objective: newProjObj.trim() || "Otimizar tempo de ciclo, capacidade operacional e estabilidade Six Sigma.",
      status: "Em Andamento" as const,
      createdAt: new Date().toISOString()
    };

    const currentProjs = CompanyProjectRepository.getProjects(email);
    CompanyProjectRepository.saveProjects([...currentProjs, newProject], email);

    const store = { ...CompanyProjectRepository.getProjectDataStore(email) };
    store[pid] = {
      companyId: selectedCompanyId,
      initialBatchSize: initBatchSize,
      defaultSetupTime: defaultSetupTime,
      steps: [
        {
          id: "step_ini_1",
          name: "Entrada e Triagem Operacional",
          resource: "Operador",
          resourceCount: 1,
          processingTime: 10,
          standardDeviation: 1.5,
          setupTime: defaultSetupTime,
          yieldRate: 0.98
        },
        {
          id: "step_ini_2",
          name: "Processamento e Execução Principal",
          resource: "Analista",
          resourceCount: 1,
          processingTime: 12,
          standardDeviation: 2.0,
          setupTime: defaultSetupTime,
          yieldRate: 0.95
        }
      ],
      arrivalRate: 4,
      charter: {
        id: "char_" + pid,
        title: newProject.name,
        businessCase: "Diagnóstico e otimização contínua de processos com dados reais.",
        problemStatement: "Monitoramento e identificação de desperdícios no fluxo operacional.",
        goalStatement: "Elevar capacidade e estabilidade do processo.",
        scopeIn: "Escopo de atuação direta do projeto.",
        scopeOut: "Áreas administrativas secundárias.",
        team: "Equipe LSS: " + (activeUser?.fullName || "Líder LSS"),
        targetValue: 200
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(store, email);

    setProjects([...currentProjs, newProject]);
    setSelectedProjectId(pid);
    setIsCreatingNewProject(false);
    setNewProjName("");
    setNewProjObj("");

    // Automatically activate the newly created project
    localStorage.setItem("lss_last_company_id_" + email, selectedCompanyId);
    localStorage.setItem("lss_last_project_id_" + email, pid);
    setActiveCompanyId(selectedCompanyId);
    setActiveWorkspaceProjectId(pid);
    onRefreshGlobalData();
  };

  const handleAccessSelectedWorkspace = () => {
    if (selectedCompanyId) {
      localStorage.setItem("lss_last_company_id_" + email, selectedCompanyId);
      if (selectedProjectId) {
        localStorage.setItem("lss_last_project_id_" + email, selectedProjectId);
        setActiveWorkspaceProjectId(selectedProjectId);
      } else {
        localStorage.removeItem("lss_last_project_id_" + email);
        setActiveWorkspaceProjectId(null);
      }
      setActiveCompanyId(selectedCompanyId);
      onRefreshGlobalData();
    }
  };

  // Instanciar caso de uso pré-fabricado em Modo Teste/Demo
  const handleLoadDemoCase = (caseId: "smt" | "clinic" | "logistic") => {
    // Force training/test mode so demo data does not pollute production Firestore
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_training_mode", "true");
      window.dispatchEvent(new Event("lss_training_mode_changed"));
    }

    let demoCompany: Company = { id: "", name: "", cnpj: "", industry: "", createdAt: "", enabledModules: [] };
    let demoProject = { id: "", companyId: "", name: "", objective: "", status: "Em Andamento" as const, createdAt: "" };
    let steps: any[] = [];
    let controlPlans: any[] = [];
    let arrivalRate = 4;
    let charterObj = { title: "", businessCase: "", problemStatement: "", goalStatement: "", scopeIn: "", scopeOut: "", team: "", targetValue: 300 };

    const randomId = () => Math.random().toString(36).substring(2, 6);

    if (caseId === "smt") {
      const cid = "comp_smt_" + randomId();
      const pid = "proj_smt_" + randomId();
      demoCompany = {
        id: cid,
        name: "DeltaTech Sistemas Eletrônicos S.A. [DEMO]",
        cnpj: "12.345.678/0001-90",
        industry: "Industrial & Montagem SMT",
        enabledModules: ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "OR_HUB", "REPORT", "ENTERPRISE_STUDIO", "BI_STUDIO", "SIGMA_TREND", "E3I_INTELLIGENCE"],
        createdAt: new Date().toISOString()
      };
      demoProject = {
        id: pid,
        companyId: cid,
        name: "Otimização de Gargalos na Linha SMT [TESTE]",
        objective: "Reduzir o lead time de calibração eletrônica em 40% e elevar a estabilidade acima de 4σ.",
        status: "Em Andamento",
        createdAt: new Date().toISOString()
      };
      steps = [
        { id: "step_smt_1", name: "Alimentação de Placa", resource: "Técnico SMT", resourceCount: 2, processingTime: 5, standardDeviation: 0.8, setupTime: 10, yieldRate: 0.99 },
        { id: "step_smt_2", name: "Impressor de Pasta de Solda", resource: "Operador de Máquina", resourceCount: 1, processingTime: 7, standardDeviation: 1.4, setupTime: 15, yieldRate: 0.97 },
        { id: "step_smt_3", name: "Inspeção Óptica AOI (Gargalo)", resource: "Inspetor da Qualidade", resourceCount: 1, processingTime: 9, standardDeviation: 2.1, setupTime: 5, yieldRate: 0.96 },
        { id: "step_smt_4", name: "Forno de Refluxo térmico", resource: "Auxiliar Logístico", resourceCount: 2, processingTime: 4, standardDeviation: 0.5, setupTime: 8, yieldRate: 1.0 }
      ];
      controlPlans = [
        { id: "cp_smt_1", stepId: "step_smt_3", metric: "Taxa de Falhas Ópticas (DPMO)", ucl: 1200, lcl: 150, target: 400, enableAlarm: true, currentReading: 320 }
      ];
      arrivalRate = 6;
      charterObj = {
        title: "Otimização de Linha SMT de Placas Eletrônicas",
        businessCase: "Caso de teste demonstrativo para simulação de filas, gargalos e controle CEP em linha industrial.",
        problemStatement: "Inspecão AOI com alta oscilação e retrabalho de soldas.",
        goalStatement: "Garantir o balanceamento de cargos e reduzir Lead Time.",
        scopeIn: "Linha SMT e bancada operacional de soldas manuais.",
        scopeOut: "Setores externos.",
        team: "Green Belt Force - DeltaTech S.A.",
        targetValue: 400
      };
    } else if (caseId === "clinic") {
      const cid = "comp_hosp_" + randomId();
      const pid = "proj_hosp_" + randomId();
      demoCompany = {
        id: cid,
        name: "Hospital Alfa - Pronto Atendimento [DEMO]",
        cnpj: "98.765.432/0001-11",
        industry: "Saúde & Hospitais",
        createdAt: new Date().toISOString()
      };
      demoProject = {
        id: pid,
        companyId: cid,
        name: "Redução do Tempo de Espera na Triagem [TESTE]",
        objective: "Otimizar o fluxo de triagem de classificação de risco mantendo tempo de fila abaixo de 10 min.",
        status: "Em Andamento",
        createdAt: new Date().toISOString()
      };
      steps = [
        { id: "step_cli_1", name: "Ficha de Entrada & Cadastro", resource: "Recepcionista", resourceCount: 2, processingTime: 4, standardDeviation: 1.1, setupTime: 2, yieldRate: 1.0 },
        { id: "step_cli_2", name: "Classificação de Risco (Triagem)", resource: "Enfermeira Chefe", resourceCount: 1, processingTime: 8, standardDeviation: 2.5, setupTime: 1, yieldRate: 0.98 },
        { id: "step_cli_3", name: "Consulta Médica Emergencial", resource: "Médico de Plantão", resourceCount: 3, processingTime: 15, standardDeviation: 3.5, setupTime: 3, yieldRate: 0.95 },
        { id: "step_cli_4", name: "Medicação & Alta", resource: "Técnico de Enfermagem", resourceCount: 2, processingTime: 6, standardDeviation: 1.2, setupTime: 2, yieldRate: 0.99 }
      ];
      controlPlans = [
        { id: "cp_cli_1", stepId: "step_cli_2", metric: "Tempo de Classificação (Min)", ucl: 12.0, lcl: 3.0, target: 6.0, enableAlarm: true, currentReading: 7.5 }
      ];
      arrivalRate = 5;
      charterObj = {
        title: "Gargalo na Recepção e Triagem de Pacientes",
        businessCase: "Caso de teste demonstrativo para simulação de saúde e teoria das filas hospitalares.",
        problemStatement: "A triagem de enfermeiros apresenta alta variabilidade no horário de pico.",
        goalStatement: "Cumprir protocolo Manchester com tempos de triagem científicos inferiores a 8 minutos.",
        scopeIn: "Setor de Urgências e classificação de risco.",
        scopeOut: "Procedimentos cirúrgicos de alta complexidade.",
        team: "Analistas de Fluxo Hospitalar",
        targetValue: 180
      };
    } else {
      const cid = "comp_log_" + randomId();
      const pid = "proj_log_" + randomId();
      demoCompany = {
        id: cid,
        name: "ExpressLogística Omnichannel [DEMO]",
        cnpj: "45.678.911/0002-88",
        industry: "Logística & Distribuição",
        createdAt: new Date().toISOString()
      };
      demoProject = {
        id: pid,
        companyId: cid,
        name: "Ciclo de Picking e Embalagem e-Commerce [TESTE]",
        objective: "Reduzir desperdícios e tempos ociosos operacionais em rotas de separação interna do galpão.",
        status: "Em Andamento",
        createdAt: new Date().toISOString()
      };
      steps = [
        { id: "step_log_1", name: "Recepção do Pedido Digital", resource: "Operador de TI", resourceCount: 1, processingTime: 3, standardDeviation: 0.5, setupTime: 1, yieldRate: 1.0 },
        { id: "step_log_2", name: "Varredura & Coleta no Estoque (Picking)", resource: "Ajudante de Galpão", resourceCount: 2, processingTime: 12, standardDeviation: 3.0, setupTime: 5, yieldRate: 0.97 },
        { id: "step_log_3", name: "Conferência de Item & Etiquetagem", resource: "Conferente", resourceCount: 1, processingTime: 5, standardDeviation: 1.0, setupTime: 4, yieldRate: 0.99 },
        { id: "step_log_4", name: "Empacotamento & Carga", resource: "Auxiliar de Envios", resourceCount: 2, processingTime: 6, standardDeviation: 1.2, setupTime: 3, yieldRate: 0.98 }
      ];
      controlPlans = [
        { id: "cp_log_1", stepId: "step_log_2", metric: "Tempo Médio de Coleta (Min)", ucl: 18.0, lcl: 6.0, target: 10.0, enableAlarm: true, currentReading: 11.2 }
      ];
      arrivalRate = 4;
      charterObj = {
        title: "Aceleração do Ciclo de Separação Logístico",
        businessCase: "Caso de teste demonstrativo para logística e-commerce e despacho acelerado.",
        problemStatement: "Falta de balanceamento de rotas de separadores.",
        goalStatement: "Mapear o fluxo lean do galpão e atingir ritmo de despacho estatístico seguro.",
        scopeIn: "Área de Picking e conferência física.",
        scopeOut: "Entrega rodoviária externa.",
        team: "Lean Warehouse Team",
        targetValue: 500
      };
    }

    const currentComps = CompanyProjectRepository.getCompanies(email);
    CompanyProjectRepository.saveCompanies([...currentComps, demoCompany], email);

    const currentProjs = CompanyProjectRepository.getProjects(email);
    CompanyProjectRepository.saveProjects([...currentProjs, demoProject], email);

    const store = { ...CompanyProjectRepository.getProjectDataStore(email) };
    store[demoProject.id] = {
      steps,
      arrivalRate,
      charter: {
        id: "char_" + demoProject.id,
        ...charterObj
      },
      controlPlans
    };
    CompanyProjectRepository.saveProjectDataStore(store, email);

    localStorage.setItem("lss_last_company_id_" + email, demoCompany.id);
    localStorage.setItem("lss_last_project_id_" + email, demoProject.id);

    setActiveCompanyId(demoCompany.id);
    setActiveWorkspaceProjectId(demoProject.id);
    onRefreshGlobalData();
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 md:p-8 select-none">
      <div className="max-w-5xl w-full bg-white border-2 border-slate-900 shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] overflow-hidden flex flex-col md:flex-row rounded-sm">
        
        {/* Left Side: Brand & Environment Status */}
        <div className="md:w-5/12 bg-[#0E2C54] text-white p-6 md:p-10 flex flex-col justify-between border-b-2 md:border-b-0 md:border-r-2 border-slate-900 relative">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-[#C49746]"></div>
          
          <div className="space-y-6">
            <div className="inline-flex items-center gap-1.5 bg-[#C49746]/20 text-[#C49746] border border-[#C49746]/30 text-[10px] font-mono font-extrabold uppercase tracking-widest px-2.5 py-1 rounded-sm">
              <Sparkles size={11} /> ATIVAÇÃO DE ESPAÇO DE TRABALHO
            </div>
            
            <div className="py-2 bg-white/5 rounded-md p-3 border border-white/10 flex justify-center">
              <E3ILogo width={210} height={112} variant="dark" />
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mt-2">
              Plataforma para mapeamento de processos reais, simulações estatísticas Monte Carlo, gráficos de controle CEP e otimização Six Sigma.
            </p>

            <div className="border-t border-blue-900/50 pt-5 space-y-3.5">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 size={16} className="text-[#C49746] shrink-0 mt-0.5" />
                <div className="text-left">
                  <h4 className="text-[11px] uppercase font-mono tracking-wider font-extrabold text-slate-100">Isolamento de Ambientes</h4>
                  <p className="text-[10.5px] text-slate-400">Separação estrita entre dados operacionais reais e sandbox de teste.</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <CheckCircle2 size={16} className="text-[#C49746] shrink-0 mt-0.5" />
                <div className="text-left">
                  <h4 className="text-[11px] uppercase font-mono tracking-wider font-extrabold text-slate-100">Multi-Tenant Seguro</h4>
                  <p className="text-[10.5px] text-slate-400">Armazenamento isolado no Cloud Firestore por usuário e empresa.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-blue-900/50 text-left mt-6 md:mt-0">
            <span className="text-[8.5px] font-mono text-slate-400 uppercase tracking-widest block">Usuário Conectado</span>
            <div className="text-[11px] text-[#C49746] font-bold truncate max-w-[220px]">{email}</div>
            <div className="text-[8px] font-mono text-slate-400 uppercase mt-0.5 tracking-tight flex items-center gap-1">
              <ShieldCheck size={9} className="text-emerald-500" /> PRIVACIDADE E SEGURANÇA ATIVA
            </div>
          </div>
        </div>

        {/* Right Side: Setup Controls & Environment Switcher */}
        <div className="md:w-7/12 p-6 md:p-8 flex flex-col justify-between bg-white text-left overflow-y-auto max-h-[85vh] md:max-h-none">
          
          <div className="space-y-5">
            {/* ENVIRONMENT TAB SWITCHER */}
            <div>
              <div className="text-[10px] font-mono font-extrabold uppercase tracking-wider text-slate-400 mb-2">
                Selecione o Modo de Trabalho
              </div>

              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-md border border-slate-200">
                <button
                  type="button"
                  onClick={() => handleSwitchEnvTab("production")}
                  className={`py-2 px-3 text-xs font-bold uppercase tracking-wider rounded transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    envTab === "production"
                      ? "bg-slate-900 text-white shadow-sm"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-200"
                  }`}
                >
                  <Database size={13} className={envTab === "production" ? "text-emerald-400" : "text-slate-500"} />
                  <span>🟢 Produção (Dados Reais)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSwitchEnvTab("test")}
                  className={`py-2 px-3 text-xs font-bold uppercase tracking-wider rounded transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    envTab === "test"
                      ? "bg-amber-600 text-white shadow-sm"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-200"
                  }`}
                >
                  <FlaskConical size={13} className={envTab === "test" ? "text-amber-200" : "text-slate-500"} />
                  <span>🧪 Testes & Demo</span>
                </button>
              </div>
            </div>

            {/* TAB CONTENT: PRODUCTION MODE */}
            {envTab === "production" && (
              <div className="space-y-4 pt-1 animate-fadeIn">
                <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-sm">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs uppercase tracking-tight">
                    <Database size={14} className="text-emerald-600 shrink-0" />
                    <span>Ambiente de Produção Ativo (Limpo)</span>
                  </div>
                  <p className="text-[11px] text-emerald-800 leading-normal mt-1">
                    Este ambiente está configurado para receber exclusivamente informações reais inseridas por você. Nenhum dado fictício de teste é carregado automaticamente.
                  </p>
                </div>

                {/* IF NO COMPANY EXISTS YET -> SHOW ONBOARDING CREATE FORM */}
                {(companies.length === 0 || isCreatingNewCompany) ? (
                  <div className="p-4 bg-slate-50 border-2 border-slate-900 rounded-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Building2 size={16} className="text-[#C49746]" />
                        <h4 className="text-xs font-extrabold uppercase text-slate-900">Cadastrar Empresa Real</h4>
                      </div>
                      {companies.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setIsCreatingNewCompany(false)}
                          className="text-[10px] font-bold text-slate-500 hover:text-slate-800 uppercase"
                        >
                          Selecionar Existente
                        </button>
                      )}
                    </div>

                    <div className="space-y-2.5">
                      <div>
                        <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                          Razão Social / Nome da Empresa *
                        </label>
                        <input
                          type="text"
                          placeholder="Ex: E3I Soluções S.A., Indústrias Alfa Ltda..."
                          value={newCompName}
                          onChange={(e) => setNewCompName(e.target.value)}
                          className="w-full bg-white border border-slate-300 p-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-slate-900 rounded-xs"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">CNPJ</label>
                          <input
                            type="text"
                            placeholder="00.000.000/0001-00"
                            value={newCompCnpj}
                            onChange={(e) => setNewCompCnpj(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-slate-900 rounded-xs"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">Ramo de Atuação</label>
                          <select
                            value={newCompInd}
                            onChange={(e) => setNewCompInd(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-slate-900 rounded-xs"
                          >
                            <option value="Industrial & Manufatura">Industrial & Manufatura</option>
                            <option value="Saúde & Hospitais">Saúde & Hospitais</option>
                            <option value="Varejo & Serviços">Varejo & Serviços</option>
                            <option value="Logística & Distribuição">Logística & Distribuição</option>
                            <option value="Tecnologia & Software">Tecnologia & Software</option>
                            <option value="Financeiro & Bancário">Financeiro & Bancário</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                          Nome do Projeto DMAIC Inicial (Opcional)
                        </label>
                        <input
                          type="text"
                          placeholder="Ex: Redução de SLA no Atendimento, Otimização de Processo..."
                          value={newProjName}
                          onChange={(e) => setNewProjName(e.target.value)}
                          className="w-full bg-white border border-slate-300 p-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-slate-900 rounded-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                          Objetivo Principal do Projeto
                        </label>
                        <textarea
                          placeholder="Descreva o objetivo real do projeto..."
                          value={newProjObj}
                          onChange={(e) => setNewProjObj(e.target.value)}
                          className="w-full bg-white border border-slate-300 p-2 text-xs h-14 resize-none focus:outline-none focus:border-slate-900 rounded-xs"
                        />
                      </div>

                      {/* Painel de Configuração Rápida do Projeto */}
                      <div className="bg-slate-100 border border-slate-300 p-2.5 rounded-xs space-y-2 text-left">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-800">
                          <Sliders size={12} className="text-[#C49746]" />
                          <span>Painel de Configuração Rápida do Projeto</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[9px] font-bold text-slate-600 uppercase block mb-0.5">
                              Lote Inicial (unid.)
                            </label>
                            <input
                              type="number"
                              min={1}
                              max={10000}
                              value={initBatchSize}
                              onChange={(e) => setInitBatchSize(Math.max(1, parseInt(e.target.value) || 1))}
                              className="w-full bg-white border border-slate-300 px-2 py-1 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-slate-900"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-600 uppercase block mb-0.5">
                              Setup Padrão (min)
                            </label>
                            <input
                              type="number"
                              min={0}
                              max={1440}
                              value={defaultSetupTime}
                              onChange={(e) => setDefaultSetupTime(Math.max(0, parseFloat(e.target.value) || 0))}
                              className="w-full bg-white border border-slate-300 px-2 py-1 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-slate-900"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleCreateCompanyManual}
                      disabled={!newCompName.trim()}
                      className="w-full py-2.5 bg-[#0E2C54] hover:bg-black disabled:bg-slate-300 text-white font-extrabold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 rounded-xs shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]"
                    >
                      <span>⚡ Cadastrar Empresa & Acessar Produção</span>
                      <ArrowRight size={14} className="text-[#C49746]" />
                    </button>
                  </div>
                ) : (
                  /* SELECT EXISTING PRODUCTION COMPANY & PROJECT */
                  <div className="space-y-4">
                    {/* STEP 1: SELECT COMPANY */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label htmlFor="intro-company-select" className="text-[10px] font-bold text-slate-700 uppercase tracking-tight flex items-center gap-1">
                          <Building2 size={13} className="text-slate-500" /> 1. Empresa / Cliente Ativo
                        </label>
                        <button
                          type="button"
                          onClick={() => setIsCreatingNewCompany(true)}
                          className="text-[10px] font-bold text-[#C49746] hover:underline uppercase"
                        >
                          + Nova Empresa Real
                        </button>
                      </div>

                      <select
                        id="intro-company-select"
                        value={selectedCompanyId}
                        onChange={(e) => setSelectedCompanyId(e.target.value)}
                        className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-800 cursor-pointer rounded-xs"
                      >
                        <option value="">-- Escolha uma Empresa Cadastrada --</option>
                        {companies.map((c) => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* STEP 2: SELECT OR CREATE PROJECT */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label htmlFor="intro-project-select" className="text-[10px] font-bold text-slate-700 uppercase tracking-tight flex items-center gap-1">
                          <Briefcase size={13} className="text-slate-500" /> 2. Projeto DMAIC Associado
                        </label>
                        {selectedCompanyId && (
                          <button
                            type="button"
                            onClick={() => setIsCreatingNewProject(!isCreatingNewProject)}
                            className="text-[10px] font-bold text-[#C49746] hover:underline uppercase"
                          >
                            {isCreatingNewProject ? "Escolher Existente" : "+ Criar Projeto Real"}
                          </button>
                        )}
                      </div>

                      {isCreatingNewProject ? (
                        <div className="p-3 bg-slate-50 border border-slate-200 rounded-sm space-y-2.5">
                          <input
                            type="text"
                            placeholder="Nome do Projeto Real..."
                            value={newProjName}
                            onChange={(e) => setNewProjName(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2 text-xs font-semibold text-slate-800 focus:outline-none"
                          />
                          <textarea
                            placeholder="Objetivo principal do projeto..."
                            value={newProjObj}
                            onChange={(e) => setNewProjObj(e.target.value)}
                            className="w-full bg-white border border-slate-300 p-2 text-xs h-14 resize-none focus:outline-none"
                          />

                          {/* Painel de Configuração Rápida no Projeto na Empresa Existente */}
                          <div className="bg-slate-100 border border-slate-200 p-2 rounded-xs space-y-1.5 text-left">
                            <div className="flex items-center gap-1 text-[9.5px] font-bold uppercase tracking-wider text-slate-700">
                              <Sliders size={11} className="text-[#C49746]" />
                              <span>Painel de Configuração Rápida</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-[9px] font-bold text-slate-500 uppercase block mb-0.5">
                                  Lote Inicial (unid.)
                                </label>
                                <input
                                  type="number"
                                  min={1}
                                  max={10000}
                                  value={initBatchSize}
                                  onChange={(e) => setInitBatchSize(Math.max(1, parseInt(e.target.value) || 1))}
                                  className="w-full bg-white border border-slate-300 px-2 py-1 text-xs font-mono font-bold text-slate-800 focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] font-bold text-slate-500 uppercase block mb-0.5">
                                  Setup Padrão (min)
                                </label>
                                <input
                                  type="number"
                                  min={0}
                                  max={1440}
                                  value={defaultSetupTime}
                                  onChange={(e) => setDefaultSetupTime(Math.max(0, parseFloat(e.target.value) || 0))}
                                  className="w-full bg-white border border-slate-300 px-2 py-1 text-xs font-mono font-bold text-slate-800 focus:outline-none"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="flex justify-end gap-1.5 pt-1">
                            <button type="button" onClick={() => setIsCreatingNewProject(false)} className="text-[9px] uppercase font-bold bg-white border border-slate-200 px-2 py-1 text-slate-500">Cancelar</button>
                            <button type="button" onClick={handleCreateProjectManual} className="text-[9px] uppercase font-bold bg-[#C49746] hover:bg-amber-700 text-white px-3 py-1">Criar na Empresa</button>
                          </div>
                        </div>
                      ) : (
                        <select
                          id="intro-project-select"
                          disabled={!selectedCompanyId}
                          value={selectedProjectId}
                          onChange={(e) => setSelectedProjectId(e.target.value)}
                          className="w-full bg-slate-50 hover:bg-slate-100 disabled:bg-slate-100 disabled:text-slate-400 border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-800 cursor-pointer rounded-xs"
                        >
                          <option value="">-- Sem Projeto (Apenas Estruturação Inicial) --</option>
                          {projects
                            .filter((p) => p.companyId === selectedCompanyId)
                            .map((p) => (
                              <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                        </select>
                      )}
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={handleAccessSelectedWorkspace}
                        disabled={!selectedCompanyId}
                        className="w-full py-3 bg-[#0E2C54] hover:bg-black disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs uppercase font-extrabold tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 rounded-xs shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] disabled:shadow-none"
                      >
                        <span>Acessar Ambiente de Produção</span>
                        <ArrowRight size={14} className="text-[#C49746]" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: TEST / DEMO MODE */}
            {envTab === "test" && (
              <div className="space-y-4 pt-1 animate-fadeIn">
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-sm">
                  <div className="flex items-center gap-2 text-amber-900 font-bold text-xs uppercase tracking-tight">
                    <FlaskConical size={14} className="text-amber-600 shrink-0" />
                    <span>Ambiente de Testes & Demonstração (Sandbox)</span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-normal mt-1">
                    Ideal para testar algoritmos, explorar os gráficos de controle CEP e experimentar simulações de fluxo sem afetar seu banco de dados de produção.
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-mono font-bold tracking-widest text-[#C49746] uppercase block">
                    🚀 Escolha um Caso Prático de Demonstração
                  </span>

                  <div className="grid grid-cols-1 gap-2.5">
                    {/* SMT Case */}
                    <button
                      type="button"
                      onClick={() => handleLoadDemoCase("smt")}
                      className="w-full border-2 border-dashed border-[#C49746]/40 hover:border-[#C49746] bg-[#C49746]/5 hover:bg-[#C49746]/10 p-3 flex items-center justify-between text-left transition-all rounded-sm cursor-pointer group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">🏭</span>
                          <span className="text-xs font-bold text-slate-900 group-hover:text-[#C49746]">
                            Manufatura SMT DeltaTech (Eletrônicos)
                          </span>
                        </div>
                        <p className="text-[10.5px] text-slate-500 max-w-md leading-normal">
                          Gargalos de máquina AOI, gráficos CEP de refugo e simulação Monte Carlo de placas.
                        </p>
                      </div>
                      <ArrowRight size={14} className="text-[#C49746] shrink-0 transform group-hover:translate-x-1.5 transition-transform" />
                    </button>

                    {/* Clinic Case */}
                    <button
                      type="button"
                      onClick={() => handleLoadDemoCase("clinic")}
                      className="w-full border-2 border-dashed border-indigo-200 hover:border-indigo-600 bg-indigo-50/20 hover:bg-indigo-50/50 p-3 flex items-center justify-between text-left transition-all rounded-sm cursor-pointer group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">🏥</span>
                          <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-800">
                            Pronto Atendimento Clínico (Hospital Alfa)
                          </span>
                        </div>
                        <p className="text-[10.5px] text-slate-500 max-w-md leading-normal">
                          Simulação de filas de triagem protocolo Manchester e dimensionamento de leitos.
                        </p>
                      </div>
                      <ArrowRight size={14} className="text-indigo-600 shrink-0 transform group-hover:translate-x-1.5 transition-transform" />
                    </button>

                    {/* Logistics Case */}
                    <button
                      type="button"
                      onClick={() => handleLoadDemoCase("logistic")}
                      className="w-full border-2 border-dashed border-emerald-200 hover:border-emerald-600 bg-emerald-50/20 hover:bg-emerald-50/50 p-3 flex items-center justify-between text-left transition-all rounded-sm cursor-pointer group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">📦</span>
                          <span className="text-xs font-bold text-slate-900 group-hover:text-emerald-800">
                            Picking Logístico e-Commerce (ExpressLog)
                          </span>
                        </div>
                        <p className="text-[10.5px] text-slate-500 max-w-md leading-normal">
                          Otimização de movimentação em galpão para atendimento same-day delivery.
                        </p>
                      </div>
                      <ArrowRight size={14} className="text-emerald-600 shrink-0 transform group-hover:translate-x-1.5 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>E3I PLATAFORMA DE PROCESSO © 2026</span>
            <span>{envTab === "production" ? "PRODUÇÃO ISOLADA" : "SANDBOX DE TESTES"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
