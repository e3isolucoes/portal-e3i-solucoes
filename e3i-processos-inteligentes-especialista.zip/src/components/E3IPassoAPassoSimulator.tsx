import React, { useState, useEffect } from "react";
import { 
  Laptop, 
  Layers, 
  HelpCircle, 
  AlertTriangle, 
  RefreshCw, 
  Cpu, 
  TrendingUp, 
  Save, 
  Share2, 
  CheckCircle2, 
  Sparkles, 
  Info,
  Check,
  Copy,
  Plus
} from "lucide-react";
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from "recharts";

interface SavedCopy {
  id: string;
  name: string;
  timestamp: string;
  p1: number;
  p2: number;
  p3: number;
  p4: number;
  sigma: number;
}

export default function E3IPassoAPassoSimulator() {
  // Spreadsheet simulated state (Yellow editable cells - Initializing with exact values from image step 3)
  const [p1, setP1] = useState<string>("100"); // Parâmetro 1: Carga de entrada
  const [p2, setP2] = useState<string>("250"); // Parâmetro 2: Tempo VA
  const [p3, setP3] = useState<string>("40");  // Parâmetro 3: Defeitos por 1000
  const [p4, setP4] = useState<string>("120"); // Parâmetro 4: Tempo NVA (mínimo)

  // Simulation controls
  const [sheetTab, setSheetTab] = useState<"ENTRADAS" | "PROCESSAMENTO" | "SAÍDAS" | "AJUDA">("ENTRADAS");
  const [isCopiedBackup, setIsCopiedBackup] = useState<boolean>(false);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [hasCalculated, setHasCalculated] = useState<boolean>(false);
  const [selectedRoadmapStep, setSelectedRoadmapStep] = useState<number>(1);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [savedVersions, setSavedVersions] = useState<SavedCopy[]>([]);
  const [newVersionName, setNewVersionName] = useState<string>("Versão de Direção " + new Date().toLocaleDateString());

  // Alerts validator (Step 4 of current process)
  const [validationAlerts, setValidationAlerts] = useState<string[]>([]);
  const [showRoadmap, setShowRoadmap] = useState<boolean>(false);

  // Synchronize Roadmap Step selection with the spreadsheet tab view (Correspondence requirement)
  useEffect(() => {
    if (selectedRoadmapStep === 1 || selectedRoadmapStep === 2) {
      setSheetTab("AJUDA");
    } else if (selectedRoadmapStep === 3 || selectedRoadmapStep === 4 || selectedRoadmapStep === 5) {
      setSheetTab("ENTRADAS");
    } else if (selectedRoadmapStep === 6) {
      setSheetTab("PROCESSAMENTO");
    } else if (selectedRoadmapStep === 7 || selectedRoadmapStep === 8) {
      setSheetTab("SAÍDAS");
    }
  }, [selectedRoadmapStep]);

  const numP1 = parseFloat(p1) || 0;
  const numP2 = parseFloat(p2) || 0;
  const numP3 = parseFloat(p3) || 0;
  const numP4 = parseFloat(p4) || 0;

  // Calculativos da Planilha
  const calculatedLeadTime = numP2 + numP4;
  const calculatedPce = calculatedLeadTime > 0 ? (numP2 / calculatedLeadTime) * 100 : 0;
  const calculatedYield = numP3 > 0 ? Math.max(0, 100 - (numP3 / 10)) : 100;
  const calculatedDpmo = numP3 > 0 ? (numP3 / 1000) * 1000000 : 0;

  // Six Sigma Shift Table Approximation
  const getSigma = (y: number): number => {
    if (y <= 0.001) return 0.5;
    if (y >= 0.999999) return 6.0;
    const p = 1.0 - y;
    const t = Math.sqrt(-2.0 * Math.log(p));
    const c0 = 2.515517;
    const c1 = 0.802853;
    const c2 = 0.010328;
    const d1 = 1.432788;
    const d2 = 0.189269;
    const d3 = 0.001308;
    const approx = t - ((c0 + c1 * t + c2 * t * t) / (1.0 + d1 * t + d2 * t * t + d3 * t * t * t));
    return parseFloat((approx + 1.5).toFixed(2));
  };
  const calculatedSigma = getSigma(calculatedYield / 100);

  // Validation hook (Step 4)
  useEffect(() => {
    const errs: string[] = [];
    if (!p1 || isNaN(numP1) || numP1 <= 0) {
      errs.push("O Parâmetro 1 (Taxa de Chegada) deve ser preenchido com valor positivo.");
    }
    if (!p2 || isNaN(numP2) || numP2 < 0) {
      errs.push("O Parâmetro 2 (Tempo Agregado VA) deve ser igual ou maior que zero.");
    }
    if (!p3 || isNaN(numP3) || numP3 < 0 || numP3 > 1000) {
      errs.push("O Parâmetro 3 (Defeitos por 1000) deve estar no limite entre 0 e 1000.");
    }
    if (isNaN(numP4) || numP4 < 0) {
      errs.push("O Parâmetro 4 (Tempo NVA) deve ser maior ou igual a zero.");
    }
    setValidationAlerts(errs);
  }, [p1, p2, p3, p4]);

  const handleRecalculate = () => {
    if (validationAlerts.length > 0) return;
    setIsCalculating(true);
    // Simula a transição para aba Processamento com gears girando
    setSheetTab("PROCESSAMENTO");
    setSelectedRoadmapStep(6);
    setTimeout(() => {
      setIsCalculating(false);
      setHasCalculated(true);
      setSheetTab("SAÍDAS");
      setSelectedRoadmapStep(7);
    }, 1500);
  };

  const saveSimulationCopy = () => {
    const copy: SavedCopy = {
      id: "ver_" + Date.now(),
      name: newVersionName,
      timestamp: new Date().toLocaleTimeString(),
      p1: numP1,
      p2: numP2,
      p3: numP3,
      p4: numP4,
      sigma: calculatedSigma
    };
    setSavedVersions([copy, ...savedVersions]);
    alert(`Sucesso! "${newVersionName}" salva no banco local da suíte E3I.`);
    setSelectedRoadmapStep(8);
  };

  const copyShareLink = () => {
    setCopiedLink(true);
    navigator.clipboard.writeText(window.location.href);
    setTimeout(() => setCopiedLink(false), 2000);
    setSelectedRoadmapStep(8);
  };

  // Charts data formats
  const pceChartData = [
    { name: "VA (Tempo Agregado)", value: numP2, color: "#10B981" },
    { name: "NVA (Tempo Desperdiçado/Fila)", value: numP4, color: "#EF4444" }
  ];

  const sigmaChartData = [
    { name: "Processo E3I", Sigma: calculatedSigma, color: "#C49746" },
    { name: "Classe Mundial", Sigma: 6.0, color: "#1E293B" }
  ];

  return (
    <div id="e3i-passo-a-passo" className="space-y-6">
      {/* 8-Step Interactive Roadmap Timeline */}
      {!showRoadmap ? (
        <div className="bg-white border-2 border-[#1A1A1A] p-2.5 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex items-center justify-between text-xs font-sans">
          <div className="flex items-center gap-2">
            <span className="text-emerald-600 font-bold">🧭</span>
            <div>
              <p className="font-serif text-[11px] font-black text-gray-950 uppercase tracking-tight leading-none">
                E3I - Passo a Passo de Uso ({selectedRoadmapStep}/8): <span className="text-indigo-600 font-sans normal-case font-bold">{
                  selectedRoadmapStep === 1 ? "Crie a Cópia Inicial de Segurança" :
                  selectedRoadmapStep === 2 ? "Entenda as 3 Abas da Planilha" :
                  selectedRoadmapStep === 3 ? "Preencha a Aba Entradas (Células Amarelas)" :
                  selectedRoadmapStep === 4 ? "Verifique Painel de Alertas de Dados" :
                  selectedRoadmapStep === 5 ? "Execute a Atualização Fórmulas" :
                  selectedRoadmapStep === 6 ? "Acompanhe Processamento e Otimização" :
                  selectedRoadmapStep === 7 ? "Analise Indicadores e Capabilidade" :
                  "Crie Versões de Controle e Compartilhe"
                }</span>
              </p>
              <p className="text-[9px] text-gray-500 font-mono leading-none mt-1">Sincronizado interativamente com a Aba Ativa / Modificações no Painel abaixo.</p>
            </div>
          </div>
          <button
            onClick={() => setShowRoadmap(true)}
            className="bg-slate-100 hover:bg-slate-200 text-[#1A1A1A] font-mono text-[9px] font-bold px-2.5 py-1 border border-[#1A1A1A] rounded-none cursor-pointer transition-all uppercase"
          >
            🧭 Ver Roteiro Integral (8 Passos)
          </button>
        </div>
      ) : (
        <div className="bg-white border-2 border-[#1A1A1A] p-5 space-y-4 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]">
          <div className="flex items-center justify-between border-b pb-2">
            <div>
              <h3 className="font-serif text-sm font-black text-gray-950 uppercase tracking-tight flex items-center gap-1.5">
                <span className="text-emerald-600">🧭</span> E3I - PASSO A PASSO DE USO
              </h3>
              <p className="text-[10px] text-gray-500 font-mono">
                Siga a sequência lógica abaixo para realizar os ajustes na ferramenta de engenharia de processos E3I.
              </p>
            </div>
            <button
              onClick={() => setShowRoadmap(false)}
              className="bg-slate-100 hover:bg-slate-200 text-[#1A1A1A] font-mono text-[9px] font-bold px-2.5 py-1 border border-[#1A1A1A] rounded-none cursor-pointer transition-all uppercase"
            >
              📁 RECOLHER ROTEIRO
            </button>
          </div>

          {/* The 8 interactive Cards layout */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Card 1 */}
            <div 
              onClick={() => setSelectedRoadmapStep(1)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 1 
                  ? "border-emerald-600 bg-emerald-50/40 ring-2 ring-emerald-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-mono text-xs flex items-center justify-center font-black">
                    1
                  </span>
                  <Laptop size={15} className="text-emerald-600 animate-pulse" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Abra a Ferramenta</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Abra o arquivo da ferramenta E3I. A tela inicial de controle de processos será exibida de imediato.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsCopiedBackup(true);
                    setSelectedRoadmapStep(2);
                  }}
                  className={`w-full text-[9px] font-mono font-bold uppercase p-1.5 border border-[#1A1A1A] ${
                    isCopiedBackup ? "bg-emerald-600 text-white" : "bg-white hover:bg-slate-100"
                  }`}
                >
                  {isCopiedBackup ? "✓ Cópia Salva Secundária" : "📁 Salvar Cópia Inicial"}
                </button>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Sempre salve uma cópia do arquivo antes de começar as edições.
                </div>
              </div>
            </div>

            {/* Card 2 */}
            <div 
              onClick={() => setSelectedRoadmapStep(2)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 2 
                  ? "border-blue-600 bg-blue-50/40 ring-2 ring-blue-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-mono text-xs flex items-center justify-center font-black">
                    2
                  </span>
                  <Layers size={15} className="text-blue-600" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-950">Entenda as 3 Abas</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Navegue pelas 3 divisões: <strong>ENTRADAS</strong> (Dados), <strong>PROCESSAMENTO</strong> (Modelo) e <strong>SAÍDAS</strong> (Gráficos).
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <div className="flex gap-1 justify-center text-[8px] font-mono font-bold">
                  <span className="bg-emerald-100 text-emerald-800 px-1 py-0.5 rounded-xs">Entradas</span>
                  <span className="bg-blue-100 text-blue-800 px-1 py-0.5 rounded-xs">Process</span>
                  <span className="bg-orange-100 text-orange-850 px-1 py-0.5 rounded-xs">Saídas</span>
                </div>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Você só precisa mexer na aba ENTRADAS e nas auxiliares.
                </div>
              </div>
            </div>

            {/* Card 3 */}
            <div 
              onClick={() => setSelectedRoadmapStep(3)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 3 
                  ? "border-purple-650 bg-purple-50/30 ring-2 ring-purple-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-purple-600 text-white font-mono text-xs flex items-center justify-center font-black">
                    3
                  </span>
                  <HelpCircle size={15} className="text-purple-600" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Preencha Aba Entradas</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Preencha apenas as células em amarelo. Insira valores de carga de entrada, tempo agregado VA e erros.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setSheetTab("ENTRADAS");
                    setSelectedRoadmapStep(3);
                  }}
                  className="w-full text-[9px] font-mono font-bold uppercase p-1.5 bg-purple-50 hover:bg-purple-100 text-purple-950 border border-purple-300"
                >
                  📝 Ir Para Células Amarelas
                </button>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Não altere células brancas ou que contenham fórmulas prontas.
                </div>
              </div>
            </div>

            {/* Card 4 */}
            <div 
              onClick={() => setSelectedRoadmapStep(4)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 4 
                  ? "border-amber-500 bg-amber-50/40 ring-2 ring-amber-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-[#D97706] text-white font-mono text-xs flex items-center justify-center font-black">
                    4
                  </span>
                  <AlertTriangle size={15} className="text-amber-500" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-950">Verifique Alertas</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  A ferramenta emitirá avisos se houver entradas erradas ou contraditórias. Verifique o quadro de status.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <div className={`p-1 text-[8.5px] font-mono text-center font-bold ${
                  validationAlerts.length > 0 ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"
                }`}>
                  {validationAlerts.length > 0 ? "⚠️ Há Células com Erros" : "✅ Nenhuma Inconsistência"}
                </div>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Não avance para cálculos enquanto houver alertas ativos.
                </div>
              </div>
            </div>

          </div>

          {/* Second Group of 4 Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">

            {/* Card 5 */}
            <div 
              onClick={() => setSelectedRoadmapStep(5)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 5 
                  ? "border-teal-600 bg-teal-50/40 ring-2 ring-teal-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-mono text-xs flex items-center justify-center font-black">
                    5
                  </span>
                  <RefreshCw size={15} className="text-teal-600" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Clique em Atualizar</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Use o botão ATUALIZAR para recalcular o motor de simulação matemática (PCE, DPMO, Sigma).
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRecalculate();
                  }}
                  disabled={validationAlerts.length > 0}
                  className="w-full text-[9px] font-mono font-bold uppercase p-1.5 bg-teal-600 hover:bg-teal-700 text-white flex items-center justify-center gap-1 cursor-pointer"
                >
                  <RefreshCw size={10} className={isCalculating ? "animate-spin" : ""} />
                  Executar Atualizar
                </button>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Sempre atualize os cálculos após alterar qualquer dado na tabela.
                </div>
              </div>
            </div>

            {/* Card 6 */}
            <div 
              onClick={() => setSelectedRoadmapStep(6)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 6 
                  ? "border-blue-700 bg-blue-50/45 ring-2 ring-blue-700/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-indigo-750 bg-blue-800 text-white font-mono text-xs flex items-center justify-center font-black">
                    6
                  </span>
                  <Cpu size={15} className="text-indigo-700" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Aba Processamento</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  As relações estocásticas de capacidade e filas calculam os resultados em tempo real. Não mexer aqui.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setSheetTab("PROCESSAMENTO");
                    setSelectedRoadmapStep(6);
                  }}
                  className="w-full text-[9px] font-mono font-bold uppercase p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200"
                >
                  ⚙️ Visualizar Processamento
                </button>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Aguarde o processamento terminar. Pode durar alguns segundos.
                </div>
              </div>
            </div>

            {/* Card 7 */}
            <div 
              onClick={() => setSelectedRoadmapStep(7)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 7 
                  ? "border-orange-500 bg-orange-50/40 ring-2 ring-orange-500/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-orange-500 text-white font-mono text-xs flex items-center justify-center font-black">
                    7
                  </span>
                  <TrendingUp size={15} className="text-orange-500" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Analise Resultados</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Veja o Nível Sigma final, eficiência PCE e Gráficos de capabilidade na aba de Saídas prontas.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setSheetTab("SAÍDAS");
                    setSelectedRoadmapStep(7);
                  }}
                  className="w-full text-[9px] font-mono font-bold uppercase p-1.5 bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-200"
                >
                  📊 Abrir Aba SAÍDAS
                </button>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Os resultados mudam interativamente ao alterar as células de entrada.
                </div>
              </div>
            </div>

            {/* Card 8 */}
            <div 
              onClick={() => setSelectedRoadmapStep(8)}
              className={`border-2 p-3.5 flex flex-col justify-between cursor-pointer rounded-none transition-all ${
                selectedRoadmapStep === 8 
                  ? "border-emerald-700 bg-emerald-50/50 ring-2 ring-emerald-750/20" 
                  : "border-[#1A1A1A] bg-white hover:bg-slate-50"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-full bg-emerald-750 text-white font-mono text-xs flex items-center justify-center font-black">
                    8
                  </span>
                  <Save size={15} className="text-emerald-750" />
                </div>
                <h4 className="text-[11px] font-extrabold uppercase text-gray-900">Salve e Compartilhe</h4>
                <p className="text-[10px] text-gray-650 leading-relaxed">
                  Salve as premissas atuais e envie os indicadores atualizados para os diretores do comitê.
                </p>
              </div>
              <div className="mt-4 pt-2 border-t border-[#1A1A1A]/10 space-y-2">
                <div className="flex gap-1">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      saveSimulationCopy();
                    }}
                    className="w-1/2 text-[8px] font-mono font-bold uppercase p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border border-emerald-300 flex items-center justify-center gap-0.5 animate-pulse"
                  >
                    <Save size={9} /> Salvar
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      copyShareLink();
                    }}
                    className="w-1/2 text-[8px] font-mono font-bold uppercase p-1.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 flex items-center justify-center gap-0.5"
                  >
                    <Share2 size={9} /> {copiedLink ? "Copiado!" : "Link"}
                  </button>
                </div>
                <div className="bg-yellow-50 border border-yellow-200 p-1.5 text-[9px] text-amber-900 leading-tight">
                  💡 <strong>DICA:</strong> Salve salvaguardas com nomes claros contendo a data e versão de controle.
                </div>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* --- EXCEL SHEET INTERACTIVE SIMULATOR FRAME --- */}
      <div className="bg-slate-100 border-2 border-[#1A1A1A] p-1 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] overflow-hidden">
        
        {/* Mock Spreadsheet Application Bar */}
        <div className="bg-slate-800 text-white px-3 py-1.5 flex items-center justify-between text-[11px] font-mono select-none">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block"></span>
            <span className="font-bold text-[10px] text-slate-300 ml-1">E3I_Spreadsheet_Engine_v4.2.xlsx</span>
          </div>
          <div className="text-[10px] text-slate-400">
            Aba Ativa: <span className="text-amber-400 font-bold uppercase">{sheetTab}</span>
          </div>
        </div>

        {/* Excel style Tab Nav buttons */}
        <div 
          role="tablist" 
          aria-label="Abas da Planilha E3I" 
          onKeyDown={(e) => {
            const tabs = ["ENTRADAS", "PROCESSAMENTO", "SAÍDAS", "AJUDA"] as const;
            if (e.key === "ArrowRight") {
              const nextIndex = (tabs.indexOf(sheetTab) + 1) % tabs.length;
              setSheetTab(tabs[nextIndex]);
              setSelectedRoadmapStep(nextIndex === 0 ? 3 : nextIndex === 1 ? 6 : nextIndex === 2 ? 7 : 2);
            } else if (e.key === "ArrowLeft") {
              const prevIndex = (tabs.indexOf(sheetTab) - 1 + tabs.length) % tabs.length;
              setSheetTab(tabs[prevIndex]);
              setSelectedRoadmapStep(prevIndex === 0 ? 3 : prevIndex === 1 ? 6 : prevIndex === 2 ? 7 : 2);
            }
          }}
          className="flex bg-slate-200 border-b border-slate-300 p-1.5 gap-1 overflow-x-auto select-none"
        >
          
          <button 
            role="tab"
            id="tab-entradas"
            aria-selected={sheetTab === "ENTRADAS"}
            aria-controls="sheets-tab-viewport"
            tabIndex={sheetTab === "ENTRADAS" ? 0 : -1}
            onClick={() => {
              setSheetTab("ENTRADAS");
              setSelectedRoadmapStep(3);
            }}
            className={`py-1 px-3 text-[10px] font-mono uppercase tracking-wide border font-bold shrink-0 cursor-pointer transition-colors ${
              sheetTab === "ENTRADAS" 
                ? "bg-emerald-600 text-white border-emerald-700 shadow-3xs" 
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-300"
            }`}
          >
            📥 1. Aba ENTRADAS
          </button>
 
          <button 
            role="tab"
            id="tab-processamento"
            aria-selected={sheetTab === "PROCESSAMENTO"}
            aria-controls="sheets-tab-viewport"
            tabIndex={sheetTab === "PROCESSAMENTO" ? 0 : -1}
            onClick={() => {
              setSheetTab("PROCESSAMENTO");
              setSelectedRoadmapStep(6);
            }}
            className={`py-1 px-3 text-[10px] font-mono uppercase tracking-wide border font-bold shrink-0 cursor-pointer transition-colors ${
              sheetTab === "PROCESSAMENTO" 
                ? "bg-blue-600 text-white border-blue-700 shadow-3xs" 
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-300"
            }`}
          >
            ⚙️ 2. Aba PROCESSAMENTO
          </button>
 
          <button 
            role="tab"
            id="tab-saidas"
            aria-selected={sheetTab === "SAÍDAS"}
            aria-controls="sheets-tab-viewport"
            tabIndex={sheetTab === "SAÍDAS" ? 0 : -1}
            onClick={() => {
              setSheetTab("SAÍDAS");
              setSelectedRoadmapStep(7);
            }}
            className={`py-1 px-3 text-[10px] font-mono uppercase tracking-wide border font-bold shrink-0 cursor-pointer transition-colors ${
              sheetTab === "SAÍDAS" 
                ? "bg-orange-600 text-white border-orange-700 shadow-3xs" 
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-300"
            }`}
          >
            📊 3. Aba SAÍDAS
          </button>
 
          <button 
            role="tab"
            id="tab-ajuda"
            aria-selected={sheetTab === "AJUDA"}
            aria-controls="sheets-tab-viewport"
            tabIndex={sheetTab === "AJUDA" ? 0 : -1}
            onClick={() => {
              setSheetTab("AJUDA");
              setSelectedRoadmapStep(2);
            }}
            className={`py-1 px-3 text-[10px] font-mono uppercase tracking-wide border font-bold shrink-0 cursor-pointer transition-colors ${
              sheetTab === "AJUDA" 
                ? "bg-slate-700 text-white border-slate-800 shadow-3xs" 
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-300"
            }`}
          >
            📕 4. Aba AJUDA / REGRAS
          </button>
 
        </div>

        {/* Tab view area */}
        <div id="sheets-tab-viewport" className="bg-white p-4 min-h-[340px] border-t border-slate-300 text-left">
          
          {/* ENTRADAS TAB - Interactive yellow cells */}
          {sheetTab === "ENTRADAS" && (
            <div className="space-y-4 animate-fade-in text-slate-800">
              <div className="border-l-4 border-emerald-600 pl-3">
                <h4 className="font-serif text-sm font-black text-gray-950 uppercase">Formulário Auxiliar de Entradas Operacionais</h4>
                <p className="text-[10px] text-gray-500 font-mono">Modifique apenas as células amarelas conforme as instruções e assista o cálculo dinâmico.</p>
              </div>

              {/* Grid representation standard Excel like */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-slate-300 font-mono text-[11px] leading-relaxed">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600">
                      <th className="border border-slate-300 p-1.5 w-12 text-center">Célula</th>
                      <th className="border border-slate-300 p-1.5 text-left">Nome do Parâmetro / Item</th>
                      <th className="border border-slate-300 p-1.5 w-40 text-center">Valor do Item (Célula)</th>
                      <th className="border border-slate-300 p-1.5 text-left text-slate-500">Diretriz e Exemplo Prático</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-slate-300 p-1.5 bg-slate-50 text-center font-bold">B3</td>
                      <td className="border border-slate-300 p-1.5 font-bold">Parâmetro 1: Carga de entrada (lambda)</td>
                      <td className="border border-slate-300 p-1 bg-yellow-100 text-center relative">
                        <input 
                          type="text" 
                          value={p1} 
                          onChange={(e) => setP1(e.target.value)}
                          className="w-full text-center bg-transparent border-none font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 p-1 text-[11px]"
                        />
                      </td>
                      <td className="border border-slate-300 p-1.5 text-[10px] text-slate-500 text-left">Quantidade requisitada por hora pelo cliente. <em>(Exemplo: 100 itens)</em></td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-1.5 bg-slate-50 text-center font-bold">B4</td>
                      <td className="border border-slate-300 p-1.5 font-bold">Parâmetro 2: Tempo VA de Operação (minutos)</td>
                      <td className="border border-slate-300 p-1 bg-yellow-100 text-center relative">
                        <input 
                          type="text" 
                          value={p2} 
                          onChange={(e) => setP2(e.target.value)}
                          className="w-full text-center bg-transparent border-none font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 p-1 text-[11px]"
                        />
                      </td>
                      <td className="border border-slate-300 p-1.5 text-[10px] text-slate-500 text-left">Tempo de agregação de valor real na tarefa. <em>(Exemplo: 250 minutos)</em></td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-1.5 bg-slate-50 text-center font-bold">B5</td>
                      <td className="border border-slate-300 p-1.5 font-bold">Parâmetro 3: Defeitos ocorridos por 1000</td>
                      <td className="border border-slate-300 p-1 bg-yellow-100 text-center relative">
                        <input 
                          type="text" 
                          value={p3} 
                          onChange={(e) => setP3(e.target.value)}
                          className="w-full text-center bg-transparent border-none font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 p-1 text-[11px]"
                        />
                      </td>
                      <td className="border border-slate-300 p-1.5 text-[10px] text-slate-500 text-left">Quantidade insatisfatória a cada 1000 entregas. <em>(Exemplo: 40 falhas)</em></td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-1.5 bg-slate-50 text-center font-bold">B6</td>
                      <td className="border border-slate-300 p-1.5 font-bold">Parâmetro 4: Tempo de Fila / Espera NVA (minutos)</td>
                      <td className="border border-slate-300 p-1 bg-yellow-100 text-center relative">
                        <input 
                          type="text" 
                          value={p4} 
                          onChange={(e) => setP4(e.target.value)}
                          className="w-full text-center bg-transparent border-none font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 p-1 text-[11px]"
                        />
                      </td>
                      <td className="border border-slate-300 p-1.5 text-[10px] text-slate-500 text-left">Fila e latência inútil no fluxo. <em>(Exemplo: 120 minutos)</em></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Warnings / Alerts (Step 4 of current process) */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2">
                <div className="md:col-span-7">
                  {validationAlerts.length > 0 ? (
                    <div className="bg-rose-50 border-2 border-rose-600 p-3.5 space-y-2">
                      <div className="flex items-center gap-1.5 text-rose-800 font-extrabold text-[11px] uppercase font-mono">
                        <AlertTriangle size={14} className="text-rose-600" />
                        ATENÇÃO! Verifique os dados informados.
                      </div>
                      <ul className="list-disc pl-4 text-[10px] text-rose-700 space-y-0.5 font-mono">
                        {validationAlerts.map((alertText, idx) => (
                          <li key={idx}>{alertText}</li>
                        ))}
                      </ul>
                      <p className="text-[9px] text-rose-800 font-bold leading-tight">
                        Corrija os itens destacados de forma que os cálculos possam ser estabilizados.
                      </p>
                    </div>
                  ) : (
                    <div className="bg-emerald-50/70 border-2 border-emerald-600 p-3.5 flex items-center gap-2.5">
                      <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                      <div>
                        <div className="text-[11px] font-extrabold text-emerald-800 uppercase font-mono">Tudo em Ordem! Sem alertas impeditivos.</div>
                        <p className="text-[9.5px] text-emerald-700 font-mono mt-0.5">As células de entrada foram validadas com total conformidade estatística. Prossiga para atualizar os cálculos.</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Submit trigger button (Step 5) */}
                <div className="md:col-span-5 flex flex-col justify-center">
                  <button 
                    onClick={handleRecalculate}
                    disabled={validationAlerts.length > 0}
                    className={`w-full font-mono text-xs font-black uppercase tracking-wider p-3 px-5 border-2 flex items-center justify-center gap-2 transition-all ${
                      validationAlerts.length > 0
                        ? "bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed"
                        : "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:translate-y-[-1px] cursor-pointer"
                    }`}
                  >
                    <RefreshCw size={12} className={isCalculating ? "animate-spin" : ""} />
                    {isCalculating ? "Atualizando Cálculos..." : "Atualizar Ferramenta E3I"}
                  </button>
                  <p className="text-[8.5px] text-center text-slate-400 font-mono mt-1.5 leading-none">
                    Clique para garantir que o mecanismo stocástico rode a simulação.
                  </p>
                </div>
              </div>

            </div>
          )}

          {/* PROCESSAMENTO TAB - Automated maths and status (Step 6) */}
          {sheetTab === "PROCESSAMENTO" && (
            <div className="space-y-4 animate-fade-in text-slate-800">
              <div className="border-l-4 border-blue-600 pl-3">
                <h4 className="font-serif text-sm font-black text-gray-950 uppercase">Processamento e Modelagem de Variâncias</h4>
                <p className="text-[10px] text-gray-500 font-mono">Sessão protegida por encriptação local. A ferramenta calcula automaticamente as estatísticas do lóbulo.</p>
              </div>

              {isCalculating ? (
                <div className="flex flex-col items-center justify-center py-10 space-y-3">
                  <RefreshCw size={40} className="text-blue-600 animate-spin" />
                  <p className="text-xs font-mono font-bold text-blue-800 animate-pulse uppercase tracking-wider">Aguarde o término dos cálculos do simulador...</p>
                  <span className="text-[9.5px] font-mono text-slate-400">Calculando equações de Little, balanço de cargas e distribuição normal estocástica.</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pb-2">
                  <div className="bg-blue-50/50 border border-blue-200 p-4 space-y-3">
                    <h5 className="font-mono text-[11px] font-extrabold text-blue-900 uppercase">Equações Atreladas:</h5>
                    
                    <div className="space-y-2.5 text-[10.5px] font-mono select-all">
                      <div className="bg-white p-2 border border-blue-100 rounded-none">
                        <span className="text-gray-400 uppercase block text-[8px] font-bold">1. Lead Time Total (Tempo de Resposta)</span>
                        <div className="font-black mt-0.5">Cycle Time (CT) = VA + NVA</div>
                        <div className="text-blue-700 text-[10px] mt-0.5">Resolução: {numP2} + {numP4} = <strong className="text-gray-900">{calculatedLeadTime} min</strong></div>
                      </div>

                      <div className="bg-white p-2 border border-blue-100 rounded-none">
                        <span className="text-gray-400 uppercase block text-[8px] font-bold">2. Process Cycle Efficiency (PCE)</span>
                        <div className="font-black mt-0.5">PCE % = (VA / CT) &times; 100</div>
                        <div className="text-blue-700 text-[10px] mt-0.5">Resolução: ({numP2} / {calculatedLeadTime}) &times; 100 = <strong className="text-gray-900">{calculatedPce.toFixed(2)}%</strong></div>
                      </div>

                      <div className="bg-white p-2 border border-blue-100 rounded-none">
                        <span className="text-gray-400 uppercase block text-[8px] font-bold">3. Rolled First Pass Yield (Y)</span>
                        <div className="font-black mt-0.5">Y % = (1000 - Defeitos) / 10</div>
                        <div className="text-blue-700 text-[10px] mt-0.5">Resolução: (1000 - {numP3}) / 10 = <strong className="text-gray-900">{calculatedYield.toFixed(2)}%</strong></div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border-2 border-dashed border-slate-300 p-4 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse inline-block"></span>
                        <h6 className="text-[11px] font-mono font-extrabold text-gray-900 uppercase">Estatuto de Proteção de Fórmulas</h6>
                      </div>
                      <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                        Como estipulado no <strong>Passo 6 (Não altere nada aqui)</strong>, as relações acima estão devidamente protegidas contra digitações involuntárias de forma a salvaguardar a estabilidade e o rigor analítico exigido pelo comitê de controle Sigma E3I.
                      </p>
                    </div>

                    <button 
                      onClick={() => setSheetTab("SAÍDAS")}
                      className="w-full mt-4 text-[10px] font-mono font-black uppercase p-2 border-2 border-[#1A1A1A] bg-slate-900 hover:bg-slate-800 text-white shadow-[1px_1px_0px_0px_rgba(26,26,26,1)] text-center cursor-pointer"
                    >
                      Avançar para Saídas &rarr;
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* SAÍDAS TAB - Resulting analytics, KPIs and Charts (Step 7) */}
          {sheetTab === "SAÍDAS" && (
            <div className="space-y-4 animate-fade-in text-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-2 gap-2">
                <div>
                  <h4 className="font-serif text-sm font-black text-gray-950 uppercase">Indicadores Operacionais e Capabilidade Sigma</h4>
                  <p className="text-[10px] text-gray-500 font-mono">Resultados calculados dinamicamente baseados nas suas respostas nas células amarelas.</p>
                </div>
                <div className="bg-emerald-50 text-emerald-800 text-[9px] font-mono border border-emerald-300 px-2.5 py-0.5 font-bold rounded-xs shrink-0 self-start sm:self-auto">
                  ✓ Estatística Sincronizada
                </div>
              </div>

              {/* Core numbers cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono">
                
                <div className="bg-slate-50 border border-slate-300 p-3 select-all">
                  <span className="text-[8px] text-slate-400 block uppercase font-bold">Nível Sigma</span>
                  <div className="text-xl font-black text-[#C49746] mt-0.5">
                    {calculatedSigma} &sigma;
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 block">Rendimento do fluxo</span>
                </div>

                <div className="bg-slate-50 border border-slate-300 p-3">
                  <span className="text-[8px] text-slate-400 block uppercase font-bold">First Pass Yield</span>
                  <div className="text-xl font-black text-emerald-700 mt-0.5">
                    {calculatedYield.toFixed(1)}%
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 block">Rendimento Sem Erros</span>
                </div>

                <div className="bg-slate-50 border border-slate-300 p-3">
                  <span className="text-[8px] text-slate-400 block uppercase font-bold">DPMO de Entrada</span>
                  <div className="text-xl font-black text-rose-800 mt-0.5">
                    {calculatedDpmo.toLocaleString()}
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 block">Erros por milhão</span>
                </div>

                <div className="bg-slate-50 border border-slate-300 p-3">
                  <span className="text-[8px] text-slate-400 block uppercase font-bold">Eficiência (PCE)</span>
                  <div className="text-xl font-black text-blue-700 mt-0.5">
                    {calculatedPce.toFixed(1)}%
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 block">Razão VA / Tempo Total</span>
                </div>

              </div>

              {/* Diagrams and Chart Representation */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* PCE Pie chart representation */}
                <div className="bg-white border border-slate-300 p-3 text-center">
                  <h5 className="font-serif text-[11px] font-black uppercase text-gray-900 border-b pb-1 text-left">
                    Distribuição de Tempo Agregado (PCE %)
                  </h5>
                  <div className="h-44 w-full mt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pceChartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={65}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {pceChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value} min`} />
                        <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'monospace' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Sigma level target chart */}
                <div className="bg-white border border-slate-300 p-3 text-center">
                  <h5 className="font-serif text-[11px] font-black uppercase text-gray-900 border-b pb-1 text-left">
                    Nível Sigma vs Benchmark Mundial
                  </h5>
                  <div className="h-44 w-full mt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={sigmaChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" tick={{ fontSize: 9, fontFamily: 'monospace' }} />
                        <YAxis domain={[0, 6]} tick={{ fontSize: 9, fontFamily: 'monospace' }} />
                        <Tooltip formatter={(value) => `${value} σ`} />
                        <Bar dataKey="Sigma" radius={[2, 2, 0, 0]}>
                          {sigmaChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>

              {/* Version History & Export (Step 8) */}
              <div className="bg-slate-50 border border-slate-300 p-4 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h5 className="font-mono text-[11px] font-extrabold text-slate-800 uppercase flex items-center gap-1">
                    <Save size={11} className="text-emerald-700" />
                    SALVE SUAS ALTERAÇÕES NAS DIRETRIZES DO PROJETO
                  </h5>
                  <span className="text-[8px] font-mono text-slate-400">Data de Atualização: {new Date().toLocaleDateString()}</span>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <input 
                    type="text" 
                    value={newVersionName}
                    onChange={(e) => setNewVersionName(e.target.value)}
                    placeholder="Nome da versão..."
                    className="flex-1 text-[10.5px] p-2 bg-white border border-slate-300 font-mono text-slate-800 focus:outline-none"
                  />
                  <button 
                    onClick={saveSimulationCopy}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[10px] font-bold uppercase p-2 px-4 cursor-pointer"
                  >
                    Salvar Cópia Histórica
                  </button>
                  <button 
                    onClick={copyShareLink}
                    className="bg-slate-800 hover:bg-slate-900 text-white font-mono text-[10px] font-bold uppercase p-2 px-4 cursor-pointer"
                  >
                    {copiedLink ? "Copiado!" : "Copiar Link"}
                  </button>
                </div>

                {savedVersions.length > 0 && (
                  <div className="border-t pt-2 space-y-1 text-[10px] font-mono">
                    <span className="text-slate-400 font-bold block text-[8px] uppercase">Histórico de Alterações Salvas:</span>
                    <div className="max-h-24 overflow-y-auto space-y-1">
                      {savedVersions.map((v) => (
                        <div key={v.id} className="flex justify-between bg-white p-1.5 border leading-tight">
                          <span>📁 <strong>{v.name}</strong> ({v.timestamp}) - P1: {v.p1}, P2: {v.p2}, P3: {v.p3}</span>
                          <span className="text-[#C49746] font-bold">{v.sigma} &sigma;</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* AJUDA TAB */}
          {sheetTab === "AJUDA" && (
            <div className="space-y-4 animate-fade-in text-slate-800">
              <div className="border-l-4 border-slate-700 pl-3">
                <h4 className="font-serif text-sm font-black text-gray-950 uppercase">Central de Ajuda da Ferramenta E3I</h4>
                <p className="text-[10px] text-gray-400 font-mono">Esclarecimentos rápidos sobre o roteiro de qualidade estatística de processos.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <h5 className="font-mono text-xs font-bold text-slate-800 uppercase">Qual o objetivo desta simulação?</h5>
                  <p className="text-slate-650 leading-relaxed text-[11px]">
                    Oferecer um portal sandbox de experimentação imediata. Mudar as taxas de carga operacional ou defasagem de esperas (NVA) possibilita estimar com rigor como se comportaria o processo real no que tange o rendimento Sigma da diretoria.
                  </p>
                  <h5 className="font-mono text-xs font-bold text-slate-800 uppercase mt-4">Por que focar nos Parâmetros 1, 2 e 3?</h5>
                  <p className="text-slate-650 leading-relaxed text-[11px]">
                    Estes são os eixos lógicos mais impactados pelas ações do lean. O tempo de valor agregado e o número de falhas guiam a capabilidade e são os dínamos da produtividade industrial ou administrativa.
                  </p>
                </div>

                <div className="bg-amber-50/50 border border-amber-200 p-4 space-y-3">
                  <h5 className="font-mono text-[11px] font-extrabold text-amber-900 uppercase">Resumo Conceitual da Engenharia:</h5>
                  <ul className="space-y-2 text-[10.5px] font-mono leading-relaxed text-amber-950">
                    <li>✔️ <strong>VA (Valor Agregado):</strong> Atividade pela qual o cliente está disposto a pagar o preço comercial.</li>
                    <li>✔️ <strong>NVA (Não Agregado):</strong> Desperdícios, esperas, burocracias, triagem manual ou setups ineficientes.</li>
                    <li>✔️ <strong>Nível Sigma:</strong> Medida de capabilidade que representa quantos desvios-padrão cabem na tolerância. Exceder 3.0σ é o alvo inicial de maturidade.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

        </div>
        
        {/* Mock Spreadsheet Application Footer containing GOLDEN RULES from image */}
        <div className="bg-slate-200 border-t border-slate-300 p-3 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 text-[10.5px] font-mono leading-relaxed text-slate-700">
          
          <div className="flex-1 flex gap-2.5 items-center bg-white p-2.5 border border-slate-300 select-all">
            <span className="text-xl shrink-0">🏆</span>
            <div>
              <span className="font-extrabold text-[#15803D] uppercase block text-[9.5px]">PRONTO! Sequência de Uso Concluída</span>
              Você concluiu o processo de ajustes na ferramenta E3I. Sempre que precisar, siga esta sequência lógica para obter os melhores resultados!
            </div>
          </div>

          <div className="flex-1 flex gap-2 items-start bg-slate-850 bg-slate-900 text-white p-2.5 border border-slate-750">
            <span className="text-md font-bold shrink-0 text-amber-400">💡</span>
            <div>
              <span className="font-bold text-amber-400 uppercase tracking-wide block text-[8px]">REGRAS DE OURO</span>
              <ul className="list-disc pl-3 text-[9.5px] text-slate-300 space-y-0.5">
                <li>Preencha apenas o que for solicitado nos eixos de dados.</li>
                <li>Respeite estritamente as instruções de preenchimento e exemplos.</li>
                <li>Em caso de dúvidas, consulte a aba <strong className="text-white hover:underline cursor-pointer" onClick={() => setSheetTab("AJUDA")}>AJUDA</strong> da ferramenta.</li>
              </ul>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
