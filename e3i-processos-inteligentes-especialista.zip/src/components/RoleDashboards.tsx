import React, { useState } from "react";
import {
  Briefcase,
  Target,
  Bell,
  TrendingUp,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Play,
  ArrowRight,
  Shield,
  Clock,
  UserCheck,
  Calendar,
  Layers,
  FileText,
  Search,
  Plus,
  Trash2,
  FileCheck2,
  FolderOpen,
  TrendingDown,
  Info
} from "lucide-react";
import {
  UserProfileRole,
  PermissionType,
  DelegationRecord,
  getCustomKpisForRole,
  checkPermission,
  checkModuleAllowed
} from "../utils/permissionMatrix";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, AreaChart, Area } from "recharts";
import { useToast } from "../shared/ui/Toast";

interface RoleDashboardsProps {
  currentRole: UserProfileRole;
  steps: any[];
  stats: any;
  arrivalRate: number;
  activeCompanyId: string | null;
  activeCompanyName: string;
  activeProjectId: string | null;
  activeProjectName: string;
  delegations: DelegationRecord[];
  setDelegations: React.Dispatch<React.SetStateAction<DelegationRecord[]>>;
  onNavigateToView: (view: string) => void;
  // State mutations we can trigger
  onTriggerAction: (actionType: string, meta?: any) => void;
}

export const RoleDashboards: React.FC<RoleDashboardsProps> = ({
  currentRole,
  steps,
  stats,
  arrivalRate,
  activeCompanyId,
  activeCompanyName,
  activeProjectId,
  activeProjectName,
  delegations,
  setDelegations,
  onNavigateToView,
  onTriggerAction
}) => {
  const { warning, success } = useToast();
  // New delegation form state
  const [showDelModal, setShowDelModal] = useState<boolean>(false);
  const [newDelGrantorRole, setNewDelGrantorRole] = useState<UserProfileRole>(currentRole);
  const [newDelDelegateeName, setNewDelDelegateeName] = useState<string>("");
  const [newDelDelegateeRole, setNewDelDelegateeRole] = useState<UserProfileRole>("Auditor");
  const [newDelStartDate, setNewDelStartDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [newDelEndDate, setNewDelEndDate] = useState<string>(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
  );
  const [newDelReason, setNewDelReason] = useState<string>("");
  const [newDelPerms, setNewDelPerms] = useState<PermissionType[]>(["visualizar", "aprovar"]);
  
  // Simulated trends data
  const trendsDataMap: Record<UserProfileRole, any[]> = {
    Executivo: [
      { name: "Sem 1", roi: 120000, sla: 92 },
      { name: "Sem 2", roi: 145000, sla: 94 },
      { name: "Sem 3", roi: 190000, sla: 95 },
      { name: "Sem 4", roi: Math.round((stats.leadTime - stats.processingTimeSum) * arrivalRate * 125 * 12 * 0.08), sla: 96.8 }
    ],
    "Gestor de Portfólio": [
      { name: "Jan", projetos: 8, atrasos: 4 },
      { name: "Fev", projetos: 10, atrasos: 3 },
      { name: "Mar", projetos: 12, atrasos: 2 },
      { name: "Abr", projetos: 14, atrasos: 2 }
    ],
    "Dono do Processo": [
      { name: "Dia 1", sla: 84, gargalo: 12 },
      { name: "Dia 2", sla: 88, gargalo: 10 },
      { name: "Dia 3", sla: 92, gargalo: 8 },
      { name: "Dia 4", sla: 98.5, gargalo: stats.systemWip }
    ],
    "Líder do Projeto": [
      { name: "Definir", progresso: 20, entregaveis: 3 },
      { name: "Medir", progresso: 40, entregaveis: 7 },
      { name: "Analisar", progresso: 60, entregaveis: 11 },
      { name: "Melhorar", progresso: 75, entregaveis: 14 }
    ],
    Analista: [
      { name: "Medição 1", vaRatio: 0.15, yield: 92 },
      { name: "Medição 2", vaRatio: 0.22, yield: 95 },
      { name: "Medição 3", vaRatio: 0.35, yield: 97 },
      { name: "Medição 4", vaRatio: (stats.processingTimeSum / stats.leadTime), yield: Math.round(stats.rolledFirstPassYield * 100) }
    ],
    Colaborador: [
      { name: "Seg", concluidos: 2, pendentes: 5 },
      { name: "Ter", concluidos: 4, pendentes: 4 },
      { name: "Qua", concluidos: 8, pendentes: 3 },
      { name: "Qui", concluidos: 11, pendentes: 3 }
    ],
    Auditor: [
      { name: "Lote A", conformidade: 85, graves: 2 },
      { name: "Lote B", conformidade: 91, graves: 1 },
      { name: "Lote C", conformidade: 96, graves: 0 },
      { name: "Lote D", conformidade: 98.2, graves: 0 }
    ],
    Administrador: [
      { name: "Mon", logs: 320, acessos: 15 },
      { name: "Tue", logs: 480, acessos: 24 },
      { name: "Wed", logs: 650, acessos: 32 },
      { name: "Thu", logs: 1428, acessos: 32 }
    ],
    Visualizador: [
      { name: "Sem 1", progresso: 65, roi: 100000 },
      { name: "Sem 2", progresso: 72, roi: 125000 },
      { name: "Sem 3", progresso: 78, roi: 130000 },
      { name: "Sem 4", progresso: 84, roi: Math.round((stats.leadTime - stats.processingTimeSum) * arrivalRate * 100 * 12 * 0.08) }
    ]
  };

  // Get current KPIs (up to 5 or 6 maximum as instructed)
  const kpis = getCustomKpisForRole(currentRole, stats, arrivalRate);

  // Filter dynamic attentions / warnings based on selected profile
  const getAttentionsForRole = (): { id: string; type: "alert" | "warning" | "info"; text: string; actionText?: string; targetView?: string }[] => {
    switch (currentRole) {
      case "Executivo":
        return [
          {
            id: "att-exe-1",
            type: "alert",
            text: `Há ${steps.filter(s => s.processingTime > 6).length} etapas de alto custo no fluxo estocástico com perdas estimadas acima da tolerância.`,
            actionText: "Ver Relatório ROI",
            targetView: "IMPROVEMENTS"
          },
          {
            id: "att-exe-2",
            type: "warning",
            text: "O projeto avançou para a fase de Melhoria LSS sem homologação financeira assinada.",
            actionText: "Aprovar Charter",
            targetView: "DIAGNOSTIC"
          }
        ];
      case "Gestor de Portfólio":
        return [
          {
            id: "att-port-1",
            type: "alert",
            text: `Gargalo identificado no posto "${stats.bottleneckStepName}" está gerando efeito chicote e 2 projetos de melhoria atrasados.`,
            actionText: "Equilibrar Carga",
            targetView: "KANBAN"
          },
          {
            id: "att-port-2",
            type: "warning",
            text: "Alocação de capacidade técnica está acima de 90% na unidade de Tecnologia.",
            actionText: "Gerenciar Recursos",
            targetView: "CLIENT_PROJECTS"
          }
        ];
      case "Dono do Processo": {
        const breached = stats.leadTime > 30;
        return [
          {
            id: "att-owner-1",
            type: breached ? "alert" : "info",
            text: breached
              ? `🚨 SLA ESTOCÁSTICO CRÍTICO: Lead Time de ${stats.leadTime.toFixed(1)} min ultrapassa o limite de 30 min.`
              : "SLA estocástico operando dentro da margem segura de qualidade desejada.",
            actionText: "Análise de Filas",
            targetView: "IMPROVEMENTS"
          },
          {
            id: "att-owner-2",
            type: "warning",
            text: `Rendimento de Primeira Passagem (FPY) no posto de montagem está estagnado em ${(stats.rolledFirstPassYield * 100).toFixed(0)}%.`,
            actionText: "Ver Planos de Controle",
            targetView: "MAP"
          }
        ];
      }
      case "Líder do Projeto":
        return [
          {
            id: "att-lead-1",
            type: "warning",
            text: "A fase de Análise (A) do DMAIC está aguardando anexação de nova evidência fotográfica.",
            actionText: "Anexar Arquivo",
            targetView: "IMPROVEMENTS"
          },
          {
            id: "att-lead-2",
            type: "info",
            text: "Auditores solicitaram revisão do SIPOC vinculado ao Project Charter da linha.",
            actionText: "Editar SIPOC",
            targetView: "DIAGNOSTIC"
          }
        ];
      case "Analista":
        return [
          {
            id: "att-ana-1",
            type: "alert",
            text: `Análise Estatística aponta coeficiente de variação (CV) instável no posto "${stats.bottleneckStepName}".`,
            actionText: "Executar Simulação",
            targetView: "MAP"
          },
          {
            id: "att-ana-2",
            type: "warning",
            text: `O desvio padrão do ciclo do gargalo (${(stats.leadTime * 0.15).toFixed(1)} min) indica instabilidade severa.`,
            actionText: "Gráfico de Controle SPC",
            targetView: "IMPROVEMENTS"
          }
        ];
      case "Colaborador":
        return [
          {
            id: "att-col-1",
            type: "warning",
            text: "A atividade de setup do posto SMT-01 está prestes a expirar o prazo planejado.",
            actionText: "Ver Minhas Tarefas",
            targetView: "KANBAN"
          },
          {
            id: "att-col-2",
            type: "info",
            text: "Procedimento operacional padrão (POP) de equalização de ICMS atualizado por Black Belt.",
            actionText: "Visualizar POP",
            targetView: "PROCESSES"
          }
        ];
      case "Auditor":
        return [
          {
            id: "att-aud-1",
            type: "alert",
            text: "Existem 3 evidências de entregáveis DMAIC pendentes de revisão e encerramento técnico.",
            actionText: "Rever Evidências",
            targetView: "IMPROVEMENTS"
          },
          {
            id: "att-aud-2",
            type: "warning",
            text: "Não conformidade técnica aberta: O tempo de setup ultrapassou o UCL de engenharia.",
            actionText: "Abrir Auditoria",
            targetView: "COMPLIANCE"
          }
        ];
      case "Visualizador":
        return [
          {
            id: "att-vis-1",
            type: "info",
            text: "O projeto de otimização de PCB obteve a homologação final de R$ 42K economizados.",
            actionText: "Gerar Relatório",
            targetView: "REPORTS"
          }
        ];
      case "Administrador":
      default:
        return [
          {
            id: "att-adm-1",
            type: "info",
            text: "A trilha de auditoria registrou 14 novas movimentações de dados isolados intercompany hoje.",
            actionText: "Ver Painel Admin",
            targetView: "ADMINISTRATION"
          }
        ];
    }
  };

  const currentAttentions = getAttentionsForRole();

  // Handle priority action triggers
  const executePriorityAction = (actionKey: string) => {
    switch (actionKey) {
      case "approve-charter":
        onTriggerAction("APPROVE_CHARTER");
        break;
      case "submit-evidence":
        onTriggerAction("SUBMIT_EVIDENCE");
        break;
      case "run-simulation":
        onTriggerAction("RUN_SIMULATION");
        break;
      case "export-report":
        onTriggerAction("EXPORT_REPORT");
        success("📊 Relatório operacional exportado com sucesso em conformidade com as permissões do perfil!");
        break;
      case "log-nonconformity":
        onTriggerAction("LOG_NONCONFORMITY");
        break;
      default:
        console.log("Ação não identificada:", actionKey);
    }
  };

  // Custom role actions list
  const getPriorityActionsForRole = (): { id: string; label: string; description: string; handlerKey: string; buttonColor: string }[] => {
    switch (currentRole) {
      case "Administrador":
        return [
          {
            id: "act-adm-1",
            label: "Homologar Ganhos Financeiros",
            description: "Aprova com assinatura criptografada real o ROI medido na fase de Controle.",
            handlerKey: "approve-charter",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-adm-2",
            label: "Trilha de Eventos e Auditoria",
            description: "Visualizar histórico detalhado de alterações e isolamento entre empresas.",
            handlerKey: "export-report",
            buttonColor: "bg-slate-800 hover:bg-slate-900 text-white"
          }
        ];
      case "Executivo":
        return [
          {
            id: "act-exe-1",
            label: "Aprovar Project Charter",
            description: "Homologar escopo estratégico, metas de qualidade e orçamento do projeto.",
            handlerKey: "approve-charter",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-exe-2",
            label: "Exportar Sumário de ROI",
            description: "Exportar planilha executiva auditada de redução de custos de inércia.",
            handlerKey: "export-report",
            buttonColor: "bg-indigo-900 hover:bg-indigo-950 text-white"
          }
        ];
      case "Gestor de Portfólio":
        return [
          {
            id: "act-port-1",
            label: "Reatribuir Recursos de Capacidade",
            description: "Alocar mais recursos humanos aos postos gargalo para estabilização de atrasos.",
            handlerKey: "run-simulation",
            buttonColor: "bg-indigo-900 hover:bg-indigo-950 text-white"
          },
          {
            id: "act-port-2",
            label: "Exportar Cronograma Global",
            description: "Gerar plano consolidado de entregas das 14 iniciativas do portfólio.",
            handlerKey: "export-report",
            buttonColor: "bg-slate-800 hover:bg-slate-900 text-white"
          }
        ];
      case "Dono do Processo":
        return [
          {
            id: "act-own-1",
            label: "Ajustar Limites de SLA",
            description: "Alinhamento das tolerâncias estocásticas com o time operacional técnico.",
            handlerKey: "run-simulation",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-own-2",
            label: "Disparar Plano de Ação",
            description: "Iniciar ação corretiva Kaizen imediata com equipe para eliminação do gargalo.",
            handlerKey: "submit-evidence",
            buttonColor: "bg-indigo-900 hover:bg-indigo-950 text-white"
          }
        ];
      case "Líder do Projeto":
        return [
          {
            id: "act-lead-1",
            label: "Submeter Entregável DMAIC",
            description: "Enviar documentação técnica da fase atual para aprovação e encerramento.",
            handlerKey: "approve-charter",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-lead-2",
            label: "Anexar Nova Evidência",
            description: "Inserir comprovante, fotos ou manuais SOP de alteração em posto de trabalho.",
            handlerKey: "submit-evidence",
            buttonColor: "bg-slate-800 hover:bg-slate-900 text-white"
          }
        ];
      case "Analista":
        return [
          {
            id: "act-ana-1",
            label: "Executar Simulação de Cenário",
            description: "Rodar simulador estocástico para testar novos setups de capacidade balanceados.",
            handlerKey: "run-simulation",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-ana-2",
            label: "Gerar Relatório de Causas",
            description: "Consolidar diagrama de Ishikawa com dados de medições para a diretoria.",
            handlerKey: "export-report",
            buttonColor: "bg-[#0F172A] hover:bg-slate-900 text-white"
          }
        ];
      case "Colaborador":
        return [
          {
            id: "act-col-1",
            label: "Concluir Checklist de SOP",
            description: "Marcar tarefa padronizada operacional como realizada no posto ativo.",
            handlerKey: "submit-evidence",
            buttonColor: "bg-emerald-700 hover:bg-emerald-800 text-white"
          },
          {
            id: "act-col-2",
            label: "Solicitar Suporte de Engenharia",
            description: "Disparar notificação técnica descrevendo mau funcionamento ou desvios de processo.",
            handlerKey: "submit-evidence",
            buttonColor: "bg-slate-800 hover:bg-slate-950 text-white"
          }
        ];
      case "Auditor":
        return [
          {
            id: "act-aud-1",
            label: "Homologar Auditoria de Campo",
            description: "Aprovar fisicamente todas as evidências anexadas de conformidade DMAIC.",
            handlerKey: "approve-charter",
            buttonColor: "bg-[#C49746] hover:bg-amber-700 text-white"
          },
          {
            id: "act-aud-2",
            label: "Apontar Não Conformidade",
            description: "Registrar quebra de procedimento técnico em posto produtivo ativo.",
            handlerKey: "log-nonconformity",
            buttonColor: "bg-red-700 hover:bg-red-800 text-white"
          }
        ];
      case "Visualizador":
      default:
        return [
          {
            id: "act-vis-1",
            label: "Exportar Relatório em PDF",
            description: "Fazer o download da documentação consolidada da cadeia de valor ativa.",
            handlerKey: "export-report",
            buttonColor: "bg-indigo-900 hover:bg-indigo-950 text-white"
          }
        ];
    }
  };

  const priorityActions = getPriorityActionsForRole();

  // Create new delegation handler
  const handleCreateDelegation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDelDelegateeName.trim()) {
      warning("Por favor, preencha o nome do responsável temporário.");
      return;
    }
    const newRecord: DelegationRecord = {
      id: "del-" + Date.now(),
      grantorUser: activeUserFullName(),
      grantorRole: currentRole,
      delegateeName: newDelDelegateeName,
      delegateeRole: newDelDelegateeRole,
      startDate: newDelStartDate,
      endDate: newDelEndDate,
      status: "Ativa",
      reason: newDelReason || "Ajuste operacional temporário",
      delegatedPermissions: newDelPerms
    };

    setDelegations(prev => [newRecord, ...prev]);
    setShowDelModal(false);
    setNewDelDelegateeName("");
    setNewDelReason("");
    success("🎫 Delegação de autoridade implantada com sucesso! O substituto receberá os privilégios correspondentes no período.");
  };

  const handleDeleteDelegation = (id: string) => {
    setDelegations(prev => prev.filter(d => d.id !== id));
  };

  const activeUserFullName = () => {
    return activeCompanyName === "Itaú Unibanco" ? "Marco Antonio Miranda" : "Usuário E3I Sênior";
  };

  // Render chart conditionally
  const renderTrendChart = () => {
    const chartData = trendsDataMap[currentRole] || trendsDataMap.Analista;
    
    if (currentRole === "Executivo" || currentRole === "Visualizador") {
      return (
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorRoi" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#C49746" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#C49746" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
            <YAxis stroke="#64748B" fontSize={11} />
            <Tooltip />
            <Area type="monotone" dataKey="roi" stroke="#C49746" fillOpacity={1} fill="url(#colorRoi)" name="ROI (R$)" />
          </AreaChart>
        </ResponsiveContainer>
      );
    }

    if (currentRole === "Dono do Processo" || currentRole === "Auditor") {
      return (
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
            <YAxis stroke="#64748B" fontSize={11} />
            <Tooltip />
            <Line type="monotone" dataKey="sla" stroke="#10B981" strokeWidth={2.5} name="SLA (%)" />
            <Line type="monotone" dataKey="gargalo" stroke="#EF4444" strokeWidth={2.5} name="Estoque" />
          </LineChart>
        </ResponsiveContainer>
      );
    }

    return (
      <ResponsiveContainer width="100%" height={240}>
        <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorProgreso" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#1E3A8A" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#1E3A8A" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
          <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
          <YAxis stroke="#64748B" fontSize={11} />
          <Tooltip />
          <Area type="monotone" dataKey={currentRole === "Colaborador" ? "concluidos" : "progresso"} stroke="#1E3A8A" fillOpacity={1} fill="url(#colorProgreso)" name="Adesão / Progresso" />
        </AreaChart>
      </ResponsiveContainer>
    );
  };

  // Find active delegation where we are the grantor or delegatee for banner display
  const todayStr = new Date().toISOString().split("T")[0];
  const activeDelegationForBanner = delegations.find(
    d => (d.status === "Ativa" || d.status === "Agendada") && d.delegateeRole === currentRole
  );

  return (
    <div className="space-y-8">
      {/* 1. SEÇÃO DE CONTEXTO E INCLINAÇÃO METODOLÓGICA */}
      <div className="bg-white border border-[#1A1A1A]/10 p-5 rounded-none shadow-3xs text-left" id="dashboard-context-card">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#C49746] uppercase tracking-wider block">CONTEÚDO DE ATRAVESSAMENTO ATIVO</span>
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-slate-100 border border-slate-200 text-slate-800 text-[10.5px] px-2.5 py-1 font-bold rounded-md flex items-center gap-1.5 shadow-3xs">
                🏢 {activeCompanyName}
              </span>
              <span className="bg-indigo-50 border border-indigo-100 text-indigo-805 text-[10.5px] px-2.5 py-1 font-bold rounded-md flex items-center gap-1.5 shadow-3xs">
                🎯 {activeProjectName}
              </span>
              <span className="bg-amber-50 border border-amber-150 text-amber-900 text-[10.5px] px-2.5 py-1 font-mono font-bold rounded-md flex items-center gap-1">
                🛡️ Perfil: <strong>{currentRole}</strong>
              </span>
            </div>
          </div>
          
          <button
            type="button"
            onClick={() => onNavigateToView("CLIENT_PROJECTS")}
            className="text-xs font-sans font-bold text-indigo-900 hover:text-indigo-950 flex items-center gap-1 px-3 py-2 border border-slate-200 hover:border-slate-300 rounded-md transition-all cursor-pointer bg-[#FAF9F5]"
          >
            Mudar Contexto <ArrowRight size={13} />
          </button>
        </div>

        {/* ACTIVE DELEGATION WARNING BANNER */}
        {activeDelegationForBanner && (
          <div className="mt-4 bg-amber-50 border border-amber-250 p-3 flex items-center gap-3 text-amber-900 rounded-md">
            <UserCheck className="text-amber-600 shrink-0" size={18} />
            <div className="text-[11px] font-sans leading-relaxed">
              <strong>🎫 Privilégios Delegados Ativos:</strong> Você obteve autoridade temporária concedida por{" "}
              <strong>{activeDelegationForBanner.grantorUser} ({activeDelegationForBanner.grantorRole})</strong> de{" "}
              <strong>{activeDelegationForBanner.startDate}</strong> até{" "}
              <strong>{activeDelegationForBanner.endDate}</strong>. Motivo:{" "}
              <span className="italic">"{activeDelegationForBanner.reason}"</span>.
            </div>
          </div>
        )}
      </div>

      {/* 2. DASHBOARD GRID principal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* COLUNA ESQUERDA + MEIO: INDICADORES + ATENÇÕES + TENDÊNCIAS */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* A. INDICADORES PRINCIPAIS (MAX 5-6 KPIs) */}
          <div className="space-y-3">
            <h3 className="text-sm font-sans font-extrabold text-[#1A1A1A] uppercase tracking-wider text-left">
              📊 Indicadores Decisórios ({kpis.length} KPIs Principais)
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {kpis.map(kpi => (
                <div
                  key={kpi.id}
                  id={`kpi-card-${kpi.id}`}
                  className="bg-white border border-slate-200 hover:border-slate-300 p-4 rounded-xl flex flex-col justify-between shadow-3xs hover:shadow-2xs transition-all text-left"
                >
                  <div className="flex items-start justify-between gap-1.5">
                    <span className="text-[10.5px] font-sans font-bold text-slate-500 max-w-[80%] leading-tight truncate-2-lines h-8 block">
                      {kpi.name}
                    </span>
                    <Info size={12} className="text-slate-400 cursor-help" title={kpi.helpText} />
                  </div>
                  
                  <div className="mt-2.5">
                    <span className="text-xl font-serif font-black text-slate-900 block tracking-tight leading-none">
                      {kpi.value}
                    </span>
                    <span className="text-[9.5px] font-mono text-slate-400 mt-1 block uppercase">
                      {kpi.unit}
                    </span>
                  </div>

                  {/* Micro gradient or trend badge */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[9px] font-bold font-mono">
                    <span className="text-slate-400">STATUS DA META</span>
                    <span className={`px-2 py-0.5 rounded-sm ${
                      kpi.trend === "up" ? "bg-emerald-50 text-emerald-700" :
                      kpi.trend === "down" ? "bg-red-50 text-red-700" : "bg-slate-50 text-slate-700"
                    }`}>
                      {kpi.trend === "up" ? "▲ EVOLUINDO" : kpi.trend === "down" ? "▼ CRÍTICO" : "■ ESTABILIZADO"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* B. TENDÊNCIAS OPERACIONAIS */}
          <div className="bg-white border border-slate-200 p-5 rounded-xl text-left space-y-4 shadow-3xs" id="trend-graph-card">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp size={16} className="text-indigo-805" />
                <h4 className="text-xs font-sans font-extrabold text-[#1A1A1A] uppercase tracking-wider">
                  📈 Curva de Tendência de Qualidade e Atravessamento
                </h4>
              </div>
              <span className="bg-slate-100 text-slate-600 text-[9px] font-mono font-bold px-2 py-0.5 rounded-sm">
                ANÁLISE TEMPORAL
              </span>
            </div>

            {renderTrendChart()}

            <p className="text-[9.5px] font-mono text-slate-400 italic leading-relaxed">
              * Gráfico estocástico atualizado em tempo real correspondente ao comportamento operacional monitorado e simulado sob o perfil de {currentRole}.
            </p>
          </div>

          {/* C. DELEGAÇÃO E SUBSTITUIÇÃO DE PAPÉIS */}
          <div className="bg-white border border-[#1A1A1A]/10 p-5 rounded-xl text-left space-y-4 shadow-3xs" id="delegations-manager-card">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-1.5">
                <UserCheck size={16} className="text-[#C49746]" />
                <h4 className="text-xs font-sans font-extrabold text-[#1A1A1A] uppercase tracking-wider">
                  🎫 Delegações e Substituições Temporárias (Compliance B2B)
                </h4>
              </div>
              
              <button
                type="button"
                onClick={() => setShowDelModal(true)}
                className="bg-slate-900 hover:bg-slate-950 text-white text-[10px] font-mono font-bold px-3 py-1.5 uppercase rounded-sm cursor-pointer transition-all flex items-center gap-1"
              >
                <Plus size={12} /> Nova Delegação
              </button>
            </div>

            {/* List of active delegations */}
            {delegations.length === 0 ? (
              <p className="text-xs text-slate-450 italic py-2 text-center">Nenhuma delegação temporária ativa cadastrada neste projeto.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left font-sans text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase font-mono">
                      <th className="py-2">De (Titular)</th>
                      <th className="py-2">Para (Substituto)</th>
                      <th className="py-2">Vigência</th>
                      <th className="py-2">Status</th>
                      <th className="py-2">Ações Delegadas</th>
                      <th className="py-2 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {delegations.map(del => (
                      <tr key={del.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                        <td className="py-2.5">
                          <div className="font-bold text-slate-800">{del.grantorUser}</div>
                          <div className="text-[9px] font-mono text-slate-450">{del.grantorRole}</div>
                        </td>
                        <td className="py-2.5">
                          <div className="font-bold text-slate-800">{del.delegateeName}</div>
                          <div className="text-[9px] font-mono text-slate-450">{del.delegateeRole}</div>
                        </td>
                        <td className="py-2.5 font-mono text-[10.5px]">
                          {del.startDate} a {del.endDate}
                        </td>
                        <td className="py-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            del.status === "Ativa" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-705"
                          }`}>
                            {del.status}
                          </span>
                        </td>
                        <td className="py-2.5 text-slate-500">
                          <span className="text-[10px] bg-slate-100 text-slate-650 px-1 py-0.5 rounded-sm mr-1">
                            {del.delegatedPermissions.join(", ")}
                          </span>
                        </td>
                        <td className="py-2.5 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeleteDelegation(del.id)}
                            className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                            title="Remover Delegação"
                          >
                            <Trash2 size={13} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>

        {/* COLUNA DIREITA: ATENÇÕES NECESSÁRIAS + AÇÕES PRIORITÁRIAS */}
        <div className="space-y-6">
          
          {/* A. ATENÇÕES NECESSÁRIAS */}
          <div className="bg-white border border-slate-200 p-5 rounded-xl text-left space-y-4 shadow-3xs" id="attentions-panel">
            <div className="flex items-center gap-1.5 border-b border-slate-150 pb-2.5">
              <Bell size={15} className="text-slate-700" />
              <h4 className="text-xs font-sans font-extrabold text-[#1A1A1A] uppercase tracking-wider">
                🚨 Atenções Necessárias ({currentAttentions.length})
              </h4>
            </div>

            {currentAttentions.length === 0 ? (
              <p className="text-xs text-slate-450 italic py-1">Nenhum evento anômalo pendente neste nível de função.</p>
            ) : (
              <div className="space-y-3">
                {currentAttentions.map(att => (
                  <div
                    key={att.id}
                    className={`p-3 border-l-4 rounded-r-md text-[11px] leading-relaxed flex flex-col justify-between gap-1.5 ${
                      att.type === "alert"
                        ? "bg-red-50/50 border-red-500 text-red-900"
                        : att.type === "warning"
                        ? "bg-amber-50/50 border-amber-400 text-amber-900"
                        : "bg-blue-50/50 border-blue-500 text-blue-900"
                    }`}
                  >
                    <div className="flex gap-2">
                      <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                      <span>{att.text}</span>
                    </div>

                    {att.actionText && att.targetView && (
                      <button
                        type="button"
                        onClick={() => onNavigateToView(att.targetView!)}
                        className="text-[10px] font-bold text-slate-800 hover:underline text-right mt-1 cursor-pointer self-end flex items-center gap-0.5"
                      >
                        {att.actionText} →
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* B. AÇÕES PRIORITÁRIAS SEGUROS-RBAC */}
          <div className="bg-white border border-[#1A1A1A] p-5 rounded-none text-left space-y-4 shadow-3xs" id="priority-actions-panel">
            <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2.5">
              <CheckCircle2 size={15} className="text-[#C49746]" />
              <h4 className="text-xs font-sans font-extrabold text-[#1A1A1A] uppercase tracking-wider">
                ⚡ Ações e Decisões Prioritárias
              </h4>
            </div>

            <div className="space-y-4">
              {priorityActions.map(act => (
                <div key={act.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-left">
                  <h5 className="font-sans font-bold text-xs text-slate-800">{act.label}</h5>
                  <p className="text-[10px] text-slate-500 leading-normal">{act.description}</p>
                  
                  <button
                    type="button"
                    onClick={() => executePriorityAction(act.handlerKey)}
                    className={`w-full py-1.5 text-xs font-mono font-bold uppercase rounded-sm cursor-pointer transition-all ${act.buttonColor}`}
                  >
                    Disparar Decisão
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-[#FAF9F5] border border-slate-200 p-3 rounded-md text-[10px] font-mono text-slate-500 leading-normal">
              🔒 <strong>Acesso Seguro RBAC:</strong> Esses botões executam operações reais no banco de dados e são ativados com assinaturas exclusivas do perfil de <strong>{currentRole}</strong>.
            </div>
          </div>

        </div>

      </div>

      {/* 3. MODAL DE NOVA DELEGAÇÃO DE PAPÉIS */}
      {showDelModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-2xs" id="delegation-form-modal">
          <div className="bg-white border-2 border-[#1A1A1A] rounded-none max-w-md w-full p-6 text-left relative shadow-lg">
            <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <UserCheck className="text-[#C49746]" size={18} />
                <h3 className="font-serif font-black text-lg text-slate-900 uppercase">
                  Implantar Nova Delegação
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowDelModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateDelegation} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">De (Titular Cedente)</label>
                <input
                  type="text"
                  disabled
                  value={`${activeUserFullName()} (${currentRole})`}
                  className="w-full bg-slate-100 border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 rounded-md outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Nome do Substituto Temporário</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Ana Clara Silva"
                  value={newDelDelegateeName}
                  onChange={(e) => setNewDelDelegateeName(e.target.value)}
                  className="w-full bg-white border border-[#1A1A1A]/25 px-3 py-2 text-xs text-slate-800 rounded-md focus:outline-none focus:border-[#C49746]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Perfil do Substituto</label>
                  <select
                    value={newDelDelegateeRole}
                    onChange={(e) => setNewDelDelegateeRole(e.target.value as any)}
                    className="w-full bg-white border border-[#1A1A1A]/25 px-2 py-2 text-xs rounded-md focus:outline-none focus:border-[#C49746]"
                  >
                    <option value="Administrador">Administrador</option>
                    <option value="Executivo">Executivo</option>
                    <option value="Gestor de Portfólio">Gestor de Portfólio</option>
                    <option value="Dono do Processo">Dono do Processo</option>
                    <option value="Líder do Projeto">Líder do Projeto</option>
                    <option value="Analista">Analista</option>
                    <option value="Colaborador">Colaborador</option>
                    <option value="Auditor">Auditor</option>
                    <option value="Visualizador">Visualizador</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Tolerância / Permissão</label>
                  <div className="flex border border-[#1A1A1A]/25 px-1 py-1 rounded-md justify-between gap-1">
                    <button
                      type="button"
                      onClick={() => setNewDelPerms(["visualizar"])}
                      className={`flex-1 py-1 rounded-sm text-[9.5px] font-mono uppercase ${newDelPerms.length === 1 ? "bg-slate-900 text-white" : "bg-transparent text-slate-600"}`}
                    >
                      Apenas Ler
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewDelPerms(["visualizar", "aprovar", "editar"])}
                      className={`flex-1 py-1 rounded-sm text-[9.5px] font-mono uppercase ${newDelPerms.length > 1 ? "bg-[#C49746] text-white" : "bg-transparent text-slate-600"}`}
                    >
                      Total (Exec)
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Início da Ausência</label>
                  <input
                    type="date"
                    required
                    value={newDelStartDate}
                    onChange={(e) => setNewDelStartDate(e.target.value)}
                    className="w-full bg-white border border-[#1A1A1A]/25 p-2 text-xs rounded-md focus:outline-none focus:border-[#C49746]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block">Término Previsto</label>
                  <input
                    type="date"
                    required
                    value={newDelEndDate}
                    onChange={(e) => setNewDelEndDate(e.target.value)}
                    className="w-full bg-white border border-[#1A1A1A]/25 p-2 text-xs rounded-md focus:outline-none focus:border-[#C49746]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-slate-500 block font-bold">Motivo da Substituição / Ausência</label>
                <textarea
                  rows={2}
                  placeholder="EX: Cobertura de viagem de negócios à filial SMT."
                  value={newDelReason}
                  onChange={(e) => setNewDelReason(e.target.value)}
                  className="w-full bg-white border border-[#1A1A1A]/25 p-2 text-xs rounded-md focus:outline-none focus:border-[#C49746] leading-tight"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowDelModal(false)}
                  className="flex-1 py-2 text-xs font-mono font-bold uppercase border border-slate-350 hover:bg-slate-50 rounded-sm cursor-pointer transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-mono font-bold uppercase bg-[#C49746] hover:bg-amber-700 text-white rounded-sm cursor-pointer transition-all"
                >
                  Implantar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// Simple standalone SVG placeholder for Lucide X in modal without custom imports
const X: React.FC<{ size?: number }> = ({ size = 18 }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
};
