import React, { useState, useEffect } from "react";
import { 
  TrendingUp, 
  ShieldCheck, 
  Database, 
  Cpu, 
  Users, 
  Briefcase, 
  Award, 
  Zap, 
  Layers, 
  FileText, 
  ArrowRight, 
  HelpCircle, 
  AlertTriangle, 
  Play, 
  RefreshCw, 
  BarChart3, 
  CheckCircle2, 
  Activity,
  HeartHandshake,
  BookOpen,
  DollarSign,
  Workflow,
  Boxes,
  Network,
  FileSpreadsheet,
  Gauge,
  GitBranch,
  Building2,
  ChevronRight,
  Info
} from "lucide-react";
import { 
  ResponsiveContainer, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from "recharts";

import { AreaId } from "../utils/areaPresets";
import { probit } from "../utils";
import { motion } from "motion/react";
import { ProjectCharter } from "../types";
import { FiveWhysRootCauseModule } from "./FiveWhysRootCauseModule";

interface EnterpriseSuiteProps {
  steps: { id: string; name: string; resource: string; resourceCount: number; processingTime: number; yieldRate: number }[];
  stats: {
    arrivalRate: number;
    bottleneckStepName: string;
    systemCapacity: number;
    systemUtilization: number;
    leadTime: number;
    rolledFirstPassYield: number;
    sigmaLevel: number;
    dpmo: number;
  };
  activeTemplateId: string;
  onNavigateToProcess?: (areaId: AreaId) => void;
  // Dynamic Drill Down Navigators
  onNavigateToView?: (view: any) => void;
  onNavigateToDmaicPhase?: (phase: any) => void;
  arrivalRate?: number;
  charter?: ProjectCharter;
}

// BIZBOK and TOGAF logical blueprint structures
interface FrameworkElement {
  id: string;
  title: string;
  framework: "TOGAF" | "BIZBOK" | "CROSS";
  sequenceOrder: number;
  category: "ESTRATEGIA" | "CAPACIDADES" | "VALOR" | "SISTEMAS" | "TECNOLOGIA" | "CONTROLE";
  icon: React.ReactNode;
  shortDesc: string;
  impactMetrics: string[];
  suggestedWorkspace: "DIAGNOSTIC" | "MAP" | "BI_STUDIO" | "OR_HUB" | "DMAIC" | "KANBAN" | "REPORT";
  dmaicPhaseFallback?: "DEFINE" | "MEASURE" | "ANALYZE" | "IMPROVE" | "CONTROL";
  relationships: { targetId: string; type: string }[];
  checklist: string[];
}

export default function EnterpriseArchitectureSuite({ 
  steps, 
  stats, 
  activeTemplateId, 
  onNavigateToProcess,
  onNavigateToView,
  onNavigateToDmaicPhase,
  arrivalRate = 4,
  charter
}: EnterpriseSuiteProps) {
  // Navigation states
  const [activeTabPanel, setActiveTabPanel] = useState<"BLUEPRINT_BUILDER" | "RELATIONSHIP_NAV" | "TOGAF_ADM" | "BIZBOK_MAP" | "DRILLDOWN_NAV" | "CHANGE_MANAGEMENT" | "OKR_DASHBOARD" | "QUALITY_DASHBOARD">("BLUEPRINT_BUILDER");
  
  // Custom interactive company setup simulation parameters
  const [companyName, setCompanyName] = useState<string>("Sinergia Corp & CO");
  const [companySlogan, setCompanySlogan] = useState<string>("Excelência End-to-End Orientada a Valor");
  const [strategicPosture, setStrategicPosture] = useState<"COST_LEADER" | "DIFFERENTIATION" | "AGILE_SPEED">("AGILE_SPEED");
  const [completedPhasesList, setCompletedPhasesList] = useState<string[]>(["phase-1", "phase-2"]);
  
  // Active selected detail node for Drill Down Panel
  const [selectedNodeId, setSelectedNodeId] = useState<string>("phase-3");
  const [complianceGrids, setComplianceGrids] = useState<Record<string, boolean>>({
    "check-1-1": true, "check-1-2": true, "check-1-3": false,
    "check-2-1": true, "check-2-2": true, "check-2-3": false,
    "check-3-1": true, "check-3-2": true, "check-3-3": true,
    "check-4-1": false, "check-4-2": true, "check-4-3": false,
    "check-5-1": true, "check-5-2": false, "check-5-3": false,
    "check-6-1": true, "check-6-2": true, "check-6-3": true,
  });

  const [activeDetailSection, setActiveDetailSection] = useState<"METRICS" | "GUIDELINE">("METRICS");

  // State for TOGAF vs BIZBOK methodology filter
  const [selectedMethodology, setSelectedMethodology] = useState<"ALL" | "TOGAF" | "BIZBOK">("ALL");

  // Selection toggle for Empresa do Zero builder
  const [activeSegmentNav, setActiveSegmentNav] = useState<"SEQUENCIA" | "MODELADOR_RELACIONAL">("SEQUENCIA");

  // Models for relational mappings (Structured from scratch)
  interface EnterpriseObjective {
    id: string;
    title: string;
    strategyType: "QUALIDADE" | "EFICIENCIA" | "TEMPO" | "CRESCIMENTO";
    metricTarget: string;
    description: string;
    framework?: "TOGAF" | "BIZBOK" | "AMBOS";
  }

  interface EnterpriseProcess {
    id: string;
    name: string;
    owner: string;
    associatedStepId?: string; // Links to real 'steps' prop
    suggestedWorkspace: "DIAGNOSTIC" | "MAP" | "BI_STUDIO" | "OR_HUB" | "DMAIC" | "KANBAN" | "REPORT" | "SIGMA_TREND";
    framework?: "TOGAF" | "BIZBOK" | "AMBOS";
  }

  interface EnterpriseResource {
    id: string;
    name: string;
    type: "HUMANO" | "FISICO" | "TECNOLOGICO" | "ESTRATEGICO";
    capacityInfo: string;
    framework?: "TOGAF" | "BIZBOK" | "AMBOS";
  }

  interface CustomRelationship {
    id: string;
    objectiveId: string;
    processId: string;
    resourceId: string;
    integrationNote: string;
  }

  interface EnterpriseChange {
    id: string;
    title: string;
    description: string;
    objectiveId: string;
    keyResultId?: string;
    expectedImpact: string;
    impactLevel: "ALTO" | "MEDIO" | "BAIXO";
    status: "PROPOSTA" | "APROVADA" | "PLANEJAMENTO" | "EXECUTADA";
    responsible: string;
    date: string;
  }

  interface KeyResult {
    id: string;
    objectiveId: string;
    title: string;
    currentValue: number;
    targetValue: number;
    unit: string;
    progress: number;
  }

  interface FiveWhysAnalysis {
    id: string;
    title: string;
    problem: string;
    why1: string;
    why2: string;
    why3: string;
    why4: string;
    why5: string;
    rootCause: string;
    proposedAction: string;
    linkedObjectiveId: string;
    responsible: string;
    date: string;
  }

  // State objects pre-populated with BIZBOK and TOGAF relationships
  const [customObjectives, setCustomObjectives] = useState<EnterpriseObjective[]>(() => {
    const saved = localStorage.getItem("lss_ea_objectives");
    if (saved) return JSON.parse(saved);
    return [
      { id: "obj-1", title: "Maximizar Yield de Primeira Passagem (FPY)", strategyType: "QUALIDADE", metricTarget: "> 95%", description: "Garantir integridade do produto sem retrabalhos conforme norma BIZBOK Quality Directive", framework: "BIZBOK" },
      { id: "obj-2", title: "Mitigar Gargalo de Fluxo e Saturação", strategyType: "EFICIENCIA", metricTarget: "< 85% Saturação", description: "Otimizar balanceamento de linhas táticas para diminuir tempo de repouso na fila estocástica (TOGAF Fase B)", framework: "TOGAF" },
      { id: "obj-3", title: "Reduzir o Lead Time de Ponta a Ponta", strategyType: "TEMPO", metricTarget: "< 140 segundos", description: "Encurtar tempo do percurso total da ordem de faturamento/peças nas baias operacionais (TOGAF Fase D)", framework: "TOGAF" }
    ];
  });

  const [customProcesses, setCustomProcesses] = useState<EnterpriseProcess[]>(() => {
    const saved = localStorage.getItem("lss_ea_processes");
    if (saved) return JSON.parse(saved);
    // Dynamically derive some processes using actual workspace steps!
    const baseProcs: EnterpriseProcess[] = [
      { id: "proc-diagnostic", name: "Planejamento Estratégico & Setup", owner: "Champion Black Belt", suggestedWorkspace: "DIAGNOSTIC", framework: "BIZBOK" },
      { id: "proc-or", name: "Dimensionamento e Análise de Filas", owner: "Engenheiro Operacional", suggestedWorkspace: "OR_HUB", framework: "TOGAF" },
      { id: "proc-dmaic", name: "Auditoria LSS e Melhoria Contínua", owner: "Sponsor Corporativo", suggestedWorkspace: "DMAIC", framework: "TOGAF" }
    ];

    // Map each step from the steps props
    steps.forEach((step) => {
      baseProcs.push({
        id: `proc-step-${step.id}`,
        name: `Operação: ${step.name}`,
        owner: `Operador de Posto (${step.resource})`,
        associatedStepId: step.id,
        suggestedWorkspace: "MAP",
        framework: "AMBOS"
      });
    });

    return baseProcs;
  });

  const [customResources, setCustomResources] = useState<EnterpriseResource[]>(() => {
    const saved = localStorage.getItem("lss_ea_resources");
    if (saved) return JSON.parse(saved);
    const baseResources: EnterpriseResource[] = [
      { id: "res-database", name: "Servidor Cloud PostgreSQL", type: "TECNOLOGICO", capacityInfo: "Persistência e Log de Auditoria (TOGAF Fase C)", framework: "TOGAF" },
      { id: "res-consulting", name: "Time de Belts LSS Certificados", type: "HUMANO", capacityInfo: "Facilitadores de Kaizen tático", framework: "BIZBOK" },
      { id: "res-simplex", name: "Mecanismo LP Solvers / Simplex", type: "TECNOLOGICO", capacityInfo: "Cálculo de restrições de insumos", framework: "TOGAF" }
    ];

    steps.forEach((step) => {
      const exists = baseResources.some(r => r.name === step.resource);
      if (!exists && step.resource) {
        baseResources.push({
          id: `res-step-${step.id}`,
          name: step.resource,
          type: "FISICO",
          capacityInfo: `Capacidade tática no posto - Total: ${step.resourceCount} unidade(s)`,
          framework: "AMBOS"
        });
      }
    });

    return baseResources;
  });

  const [relationships, setRelationships] = useState<CustomRelationship[]>(() => {
    const saved = localStorage.getItem("lss_ea_relationships");
    if (saved) return JSON.parse(saved);
    return [
      { id: "rel-1", objectiveId: "obj-1", processId: `proc-step-${steps[0]?.id || "reception"}`, resourceId: "res-consulting", integrationNote: "Garantia de setup otimizado para evitar falhas no início" },
      { id: "rel-2", objectiveId: "obj-2", processId: "proc-or", resourceId: "res-simplex", integrationNote: "Simulação matemática de balanceamento de linha e restrição de setups" },
      { id: "rel-3", objectiveId: "obj-3", processId: `proc-step-${steps[steps.length - 1]?.id || "quality"}`, resourceId: "res-database", integrationNote: "Auditoria tátil com salvamento imediato em repositório" }
    ];
  });

  const [customChanges, setCustomChanges] = useState<EnterpriseChange[]>(() => {
    const saved = localStorage.getItem("lss_ea_changes");
    if (saved) return JSON.parse(saved);
    return [
      {
        id: "chg-1",
        title: "Automatização do Processo de Triagem via RPA",
        description: "Substituir a entrada manual de dados por uma fila balanceada com robô de automação inteligente.",
        objectiveId: "obj-2",
        expectedImpact: "Redução de até 40% no tempo de fila das ordens de serviço no gargalo.",
        impactLevel: "ALTO",
        status: "PLANEJAMENTO",
        responsible: "Dr. Roberto Santos (Black Belt)",
        date: "2026-06-15"
      },
      {
        id: "chg-2",
        title: "Inserção de Poka-Yoke na Etapa de Soldagem",
        description: "Mecanismo eletrônico físico de travamento para prevenir inversão das placas PCB.",
        objectiveId: "obj-1",
        expectedImpact: "Eliminação total de retrabalho na prensa de primeira passagem garantindo FPY acima de 98%.",
        impactLevel: "ALTO",
        status: "APROVADA",
        responsible: "Maria Oliveira (Master Black Belt)",
        date: "2026-06-20"
      },
      {
        id: "chg-3",
        title: "Treinamento Metodológico Lean para Lideranças",
        description: "Capacitar gestores no método DMAIC simplificado para redução de resistência organizacional.",
        objectiveId: "obj-3",
        expectedImpact: "Engajamento interno de 90% dos operadores de baia tática nas cartas CEP.",
        impactLevel: "MEDIO",
        status: "PROPOSTA",
        responsible: "Ana Teresa (Dpto. Pessoa & Cultura)",
        date: "2026-06-25"
      }
    ];
  });

  const [customKeyResults, setCustomKeyResults] = useState<KeyResult[]>(() => {
    const saved = localStorage.getItem("lss_ea_key_results");
    if (saved) return JSON.parse(saved);
    return [
      { id: "kr-1-1", objectiveId: "obj-1", title: "Alcançar 96% de FPY no posto de solda PCB", currentValue: 92, targetValue: 96, unit: "%", progress: 95 },
      { id: "kr-1-2", objectiveId: "obj-1", title: "Reduzir taxa de retrabalho na prensa para < 2%", currentValue: 3.5, targetValue: 2, unit: "%", progress: 65 },
      { id: "kr-2-1", objectiveId: "obj-2", title: "Manter utilização máxima do gargalo tático sob 82%", currentValue: 87, targetValue: 82, unit: "%", progress: 80 },
      { id: "kr-2-2", objectiveId: "obj-2", title: "Reduzir o tempo de parada não programada em 50%", currentValue: 120, targetValue: 60, unit: "min", progress: 50 },
      { id: "kr-3-1", objectiveId: "obj-3", title: "Otimizar tempo de triagem de ordens para 15 minutos", currentValue: 22, targetValue: 15, unit: "min", progress: 60 },
      { id: "kr-3-2", objectiveId: "obj-3", title: "Reduzir tempo total de trânsito em lote de 180s para 135s", currentValue: 160, targetValue: 135, unit: "s", progress: 75 }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_ea_objectives", JSON.stringify(customObjectives));
  }, [customObjectives]);

  useEffect(() => {
    localStorage.setItem("lss_ea_key_results", JSON.stringify(customKeyResults));
  }, [customKeyResults]);

  useEffect(() => {
    localStorage.setItem("lss_ea_processes", JSON.stringify(customProcesses));
  }, [customProcesses]);

  useEffect(() => {
    localStorage.setItem("lss_ea_resources", JSON.stringify(customResources));
  }, [customResources]);

  useEffect(() => {
    localStorage.setItem("lss_ea_relationships", JSON.stringify(relationships));
  }, [relationships]);

  useEffect(() => {
    localStorage.setItem("lss_ea_changes", JSON.stringify(customChanges));
  }, [customChanges]);

  // Sub Tab Navigation in Change Management View
  const [subTab, setSubTab] = useState<"CHANGES_LIST" | "FIVE_WHYS_ANALYSIS">("CHANGES_LIST");

  // State objects pre-populated with realistic 5 Whys Root Cause Analysis
  const [customFiveWhys, setCustomFiveWhys] = useState<FiveWhysAnalysis[]>(() => {
    const saved = localStorage.getItem("lss_ea_five_whys");
    if (saved) return JSON.parse(saved);
    return [
      {
        id: "why-1",
        title: "Instabilidade Crônica no Posto de Solda PCB",
        problem: "O posto de solda automática do circuito PCB falha inesperadamente, parando o fluxo e acumulando WIP excessivo no gargalo.",
        why1: "Por que a solda falha e desliga preventivamente? Porque o bico extrusor atinge temperatura crítica de segurança de 380°C.",
        why2: "Por que ele atinge essa temperatura crítica? Porque há obstrução crônica de resíduos carbonizados no canal de arrefecimento do bico.",
        why3: "Por que há obstrução de resíduos carbonizados no canal de ar? Porque o acionamento de auto-limpeza por sopro falha ao ejetar completamente as escórias.",
        why4: "Por que o acionamento de auto-limpeza falha? Porque a válvula solenoide pneumática engripa devido à contaminação de umidade acumulada.",
        why5: "Por que a válvula engripa por umidade? Porque o filtro purgador de água do compressor principal saturou sem manutenção preventiva programada.",
        rootCause: "Saturação dos filtros purificadores de ar comprimido por falta de gatilho para troca baseada no volume real de fluxo.",
        proposedAction: "Trocar o purgador pneumático manual por um purgador automático inteligente com sensor de saturação de umidade acoplado à carta CEP.",
        linkedObjectiveId: "obj-1",
        responsible: "Maria Oliveira (Master Black Belt)",
        date: "2026-06-11"
      },
      {
        id: "why-2",
        title: "Tempo Excessivo na Triagem de Ordens",
        problem: "A triagem de peças na recepção demora em média 22 minutos por lote, gerando atraso e elevado tempo de fila operacional.",
        why1: "Por que a triagem demora tanto? Porque o operador tático precisa conferir as ordens e contratos de fornecedores manualmente em três planilhas legadas separadas.",
        why2: "Por que precisa conferir manualmente em três planilhas? Porque os sistemas de cadastro de fornecedores e estoque usam bancos obsoletos incompatíveis.",
        why3: "Por que usam bancos incompatíveis? Porque não há uma API integrada de comunicação direta entre os módulos fiscais e de estoque.",
        why4: "Por que não há essa API de ligação direta? Porque a governança de TI priorizava chamados operacionais rápidos e urgentes em vez de integrações.",
        why5: "Por que priorizavam somente chamados rápidos? Porque a diretoria de TI não possuía visibilidade do impacto financeiro do gargalo industrial corporativo.",
        rootCause: "Desconexão estratégica entre a governança de engenharia de software da TI e os objetivos macro de eficiência de cadeia de suprimentos.",
        proposedAction: "Desenvolver um microsserviço de barramento integrado em lote sob supervisão direta do patrocinador de valor corporativo.",
        linkedObjectiveId: "obj-2",
        responsible: "Dr. Roberto Santos (Black Belt)",
        date: "2026-06-12"
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_ea_five_whys", JSON.stringify(customFiveWhys));
  }, [customFiveWhys]);

  // States for 5 Whys Form input and active item
  const [activeFiveWhysId, setActiveFiveWhysId] = useState<string>("why-1");
  const [newWhyTitle, setNewWhyTitle] = useState("");
  const [newWhyProblem, setNewWhyProblem] = useState("");
  const [newWhy1, setNewWhy1] = useState("");
  const [newWhy2, setNewWhy2] = useState("");
  const [newWhy3, setNewWhy3] = useState("");
  const [newWhy4, setNewWhy4] = useState("");
  const [newWhy5, setNewWhy5] = useState("");
  const [newWhyRoot, setNewWhyRoot] = useState("");
  const [newWhyAction, setNewWhyAction] = useState("");
  const [newWhyOkr, setNewWhyOkr] = useState("");
  const [newWhyResp, setNewWhyResp] = useState("");

  const [notification, setNotification] = useState<{ show: boolean; message: string; type: "SUCCESS" | "INFO" }>({
    show: false,
    message: "",
    type: "SUCCESS"
  });
  const [showNewWhyForm, setShowNewWhyForm] = useState<boolean>(false);

  // Conversion of Five Whys analysis directly into a Formal Change Request (RFC)
  const handleConvertFiveWhysToChg = (analysis: FiveWhysAnalysis) => {
    const newChange: EnterpriseChange = {
      id: `chg-5w-${Date.now()}`,
      title: `RFC: ${analysis.title}`,
      description: `Disparado da Causa Raiz: "${analysis.rootCause}". Mapeado para sanar de forma definitiva o seguinte gargalo estrutural: "${analysis.problem}".`,
      objectiveId: analysis.linkedObjectiveId || "obj-1",
      expectedImpact: analysis.proposedAction || "Eliminação sistêmica de causa raiz",
      impactLevel: "ALTO",
      status: "PROPOSTA",
      responsible: analysis.responsible || "Especialista LSS",
      date: analysis.date || "2026-06-11"
    };
    
    setCustomChanges(prev => [newChange, ...prev]);
    
    setNotification({
      show: true,
      message: `RFC "${newChange.title}" gerada com sucesso a partir dos 5 Porquês e injetada no Quadro CCB!`,
      type: "SUCCESS"
    });
    
    setTimeout(() => {
      setNotification({ show: false, message: "", type: "SUCCESS" });
    }, 4000);
  };

  // Relational creator state
  const [showAddRelationalModal, setShowAddRelationalModal] = useState(false);
  const [selectedObjectiveIdRel, setSelectedObjectiveIdRel] = useState("");
  const [selectedProcessIdRel, setSelectedProcessIdRel] = useState("");
  const [selectedResourceIdRel, setSelectedResourceIdRel] = useState("");
  const [newIntegrationNote, setNewIntegrationNote] = useState("");

  const [showObjectiveModal, setShowObjectiveModal] = useState(false);
  const [newObjTitle, setNewObjTitle] = useState("");
  const [newObjStrategy, setNewObjStrategy] = useState<"QUALIDADE" | "EFICIENCIA" | "TEMPO" | "CRESCIMENTO">("QUALIDADE");
  const [newObjMetric, setNewObjMetric] = useState("");
  const [newObjDesc, setNewObjDesc] = useState("");
  const [newObjFramework, setNewObjFramework] = useState<"TOGAF" | "BIZBOK" | "AMBOS">("BIZBOK");

  // States indeed for the change management form
  const [newChgTitle, setNewChgTitle] = useState("");
  const [newChgDescription, setNewChgDescription] = useState("");
  const [newChgObjectiveId, setNewChgObjectiveId] = useState("");
  const [newChgKeyResultId, setNewChgKeyResultId] = useState("");
  const [newChgExpectedImpact, setNewChgExpectedImpact] = useState("");
  const [newChgImpactLevel, setNewChgImpactLevel] = useState<"ALTO" | "MEDIO" | "BAIXO">("ALTO");
  const [newChgStatus, setNewChgStatus] = useState<"PROPOSTA" | "APROVADA" | "PLANEJAMENTO" | "EXECUTADA">("PROPOSTA");
  const [newChgResponsible, setNewChgResponsible] = useState("");
  const [newChgDate, setNewChgDate] = useState("2026-06-11");

  // Hover target states for active connection highlighters
  const [hoveredObjectiveId, setHoveredObjectiveId] = useState<string | null>(null);
  const [hoveredProcessId, setHoveredProcessId] = useState<string | null>(null);
  const [hoveredResourceId, setHoveredResourceId] = useState<string | null>(null);

  const [selectedRelationId, setSelectedRelationId] = useState<string | null>("rel-1");

  // OKR Dashboard interactive helper states
  const [addingKrObjectiveId, setAddingKrObjectiveId] = useState<string | null>(null);
  const [newKrTitle, setNewKrTitle] = useState("");
  const [newKrUnit, setNewKrUnit] = useState("%");
  const [newKrCurrent, setNewKrCurrent] = useState<number>(0);
  const [newKrTarget, setNewKrTarget] = useState<number>(100);
  const [newKrProgress, setNewKrProgress] = useState<number>(50);
  const [selectedChangeIdToBind, setSelectedChangeIdToBind] = useState<Record<string, string>>({});

  // Quality Dashboard helper states
  const [selectedQualityStepId, setSelectedQualityStepId] = useState<string>("");
  const [simulationYield, setSimulationYield] = useState<number>(95);
  const [simulationBatchSize, setSimulationBatchSize] = useState<number>(10000);
  const [qualityChartMetric, setQualityChartMetric] = useState<"YIELD" | "DPMO" | "SIGMA">("YIELD");

  useEffect(() => {
    if (steps && steps.length > 0 && !selectedQualityStepId) {
      setSelectedQualityStepId(steps[0].id);
      setSimulationYield(steps[0].yieldRate);
    }
  }, [steps, selectedQualityStepId]);

  // States for the interactive Drill Down Navigator
  const [selectedDrillObjectiveId, setSelectedDrillObjectiveId] = useState<string | null>(null);
  const [selectedDrillProcessId, setSelectedDrillProcessId] = useState<string | null>(null);
  const [selectedDrillSubActivityId, setSelectedDrillSubActivityId] = useState<string | null>(null);
  const [drillImpactResult, setDrillImpactResult] = useState<{
    simulated: boolean;
    benefitPercent: number;
    description: string;
    metricsAffected: string[];
  } | null>(null);

  // Toggle compliance checkboxes
  const handleToggleCheck = (id: string) => {
    setComplianceGrids(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Define BIZBOK and TOGAF Logical Sequence for structuring a company from scratch
  const enterpriseFrameworkNodes: FrameworkElement[] = [
    {
      id: "phase-1",
      sequenceOrder: 1,
      title: "1. Intenção Estratégica & Visão de Negócios",
      framework: "BIZBOK",
      category: "ESTRATEGIA",
      icon: <Building2 className="text-[#C49746]" size={16} />,
      shortDesc: "Definição do propósito organizativo, metas de mercado, slogan e core stakeholders, alinhando a arquitetura inicial (TOGAF Fase Preliminar).",
      impactMetrics: [`Foco Estratégico: ${strategicPosture === "COST_LEADER" ? "Liderança de Custo" : strategicPosture === "DIFFERENTIATION" ? "Diferenciação Premium" : "Velocidade Ágil / Entrega"}`, `Propósito: ${companyName}`],
      suggestedWorkspace: "DIAGNOSTIC",
      relationships: [
        { targetId: "phase-2", type: "Define o escopo das de" },
        { targetId: "phase-3", type: "Rege as metas de ciclo" }
      ],
      checklist: [
        "Definir metas ecológicas e de rentabilidade a longo prazo",
        "Cadastrar o Project Charter no painel estratégico com aprovação dos black belts",
        "Configurar restrições iniciais de mercado para Programação Linear"
      ]
    },
    {
      id: "phase-2",
      sequenceOrder: 2,
      title: "2. Mapeamento de Capacidades (Capability Model)",
      framework: "BIZBOK",
      category: "CAPACIDADES",
      icon: <Boxes className="text-indigo-600" size={16} />,
      shortDesc: "Organização estrutural de todas as habilidades da empresa (Core vs Suporte), estabelecendo matrizes de maturidade e belts operacionais.",
      impactMetrics: ["92% Compliance de Governança", "Número de Processos: 9 Áreas Mapeadas", "Alocação: Belts LSS Certificados"],
      suggestedWorkspace: "KANBAN",
      relationships: [
        { targetId: "phase-3", type: "Dada a habilidade, executa o fluxo" },
        { targetId: "phase-4", type: "Exige metadados estruturados" }
      ],
      checklist: [
        "Identificar core business e elencar líderes de conformidade",
        "Sincronizar capacidades de suporte no mapa de interação de negócios",
        "Configurar visualização de kanban ágil de equipes interdisciplinares"
      ]
    },
    {
      id: "phase-3",
      sequenceOrder: 3,
      title: "3. Fluxos de Valor & Processo Core (SIPOC)",
      framework: "CROSS",
      category: "VALOR",
      icon: <Workflow className="text-amber-600" size={16} />,
      shortDesc: "Conexão horizontal de capacidades gerando lead time real. Mapeamento das atividades operacionais primárias e identificação do gargalo ativo (TOGAF Fase B).",
      impactMetrics: [
        `Gargalo Ativo: ${stats.bottleneckStepName || "Bancada Ativa"}`,
        `Lead Time Total: ${stats.leadTime.toFixed(1)} segundos`,
        `Fitas Ativas: ${steps.length} postos sequenciais`
      ],
      suggestedWorkspace: "MAP",
      relationships: [
        { targetId: "phase-4", type: "Transfere logs de faturas e peças" },
        { targetId: "phase-6", type: "Sinaliza desvios para carta de controle" }
      ],
      checklist: [
        "Desenhar caminho contínuo de ponta a ponta (Suppliers -> Inputs -> Process -> Outputs -> Customers)",
        "Calcular tempos de ciclo, yield de primeira passagem e tempos de setup",
        "Identificar o principal limitador de capacidade operacional"
      ]
    },
    {
      id: "phase-4",
      sequenceOrder: 4,
      title: "4. Arquitetura de Redes de Informação",
      framework: "TOGAF",
      category: "SISTEMAS",
      icon: <Database className="text-teal-600" size={16} />,
      shortDesc: "Sincronização dos ativos de sistemas de informação (TOGAF Fase C). Estruturação de bancos relacinais, tratamento de logs de mineração e integridade de ERP.",
      impactMetrics: [
        `F Yield Global: ${(stats.rolledFirstPassYield * 100).toFixed(1)}%`,
        "Conectores de Dados: 3 Presets CSV/Simulados ativos",
        "Logs Processados: Tempo Real"
      ],
      suggestedWorkspace: "BI_STUDIO",
      relationships: [
        { targetId: "phase-5", type: "Informa limites físicos de capacidade" },
        { targetId: "phase-6", type: "Armazena amostragens para cartas CEP" }
      ],
      checklist: [
        "Estabelecer governança de dados segundo DAMA DMBoK (Linhagem)",
        "Configurar banco para persistência e rastreamento de desvios",
        "Modelar dashboards e estudos BI para decisões táticas"
      ]
    },
    {
      id: "phase-5",
      sequenceOrder: 5,
      title: "5. Engenharia Física & Modelagem de Filas",
      framework: "TOGAF",
      category: "TECNOLOGIA",
      icon: <Cpu className="text-purple-600" size={16} />,
      shortDesc: "Tecnologia e infraestrutura física (TOGAF Fase D). Modelagem estocástica do fluxo de faturamento/peças, tempos de espera, fila e Otimização Linear Simplex.",
      impactMetrics: [
        `Capacidade do Sistema: ${stats.systemCapacity.toFixed(1)} un/hora`,
        `Saturação do Gargalo: ${stats.systemUtilization.toFixed(1)}%`,
        `Taxa de Chegada: ${arrivalRate} un/hora`
      ],
      suggestedWorkspace: "OR_HUB",
      relationships: [
        { targetId: "phase-6", type: "Estabiliza capacidade de mitigação" }
      ],
      checklist: [
        "Calcular custos horários de WIP e operadores na fila G/G/1",
        "Otimizar equações lineares de mistura ou mix no Simplex com horas limite",
        "Implementar melhoria SMED ou Poka-Yoke eletrônico"
      ]
    },
    {
      id: "phase-6",
      sequenceOrder: 6,
      title: "6. Controle Estatístico CEP & Governança LSS",
      framework: "TOGAF",
      category: "CONTROLE",
      icon: <TrendingUp className="text-emerald-600" size={16} />,
      shortDesc: "Arquitetura sob controle e Gestão de Mudança (TOGAF Fase H). Aplicação de Cartas de Controle Shewhart, limites UCL/LCL e ciclo DMAIC ativo.",
      impactMetrics: [
        `Nível Sigma: ${stats.sigmaLevel.toFixed(2)} σ`,
        `DPMO: ${Math.round(stats.dpmo)} falhas/milhão`,
        "Status Operacional: Sob Controle Estatístico"
      ],
      suggestedWorkspace: "DMAIC",
      relationships: [
        { targetId: "phase-1", type: "Retroalimenta novas metas na estratégia" }
      ],
      checklist: [
        "Inserir medições periódicas nos painéis de qualidade",
        "Calcular limites UCL/LCL dinamicamente para mitigar causas especiais",
        "Sinalizar planos de ação/reação imediata para desvios detectados"
      ]
    }
  ];

  // Calculate compliance score based on checklists
  const getPhaseCompliancePercentage = (phaseId: string) => {
    const checks = Object.keys(complianceGrids).filter(k => k.startsWith(`check-${phaseId.split("-")[1]}-`));
    if (checks.length === 0) return 0;
    const completed = checks.filter(c => complianceGrids[c]).length;
    return Math.round((completed / checks.length) * 100);
  };

  const getOverallCompliancePercentage = () => {
    const total = Object.keys(complianceGrids).length;
    const completed = Object.values(complianceGrids).filter(Boolean).length;
    return Math.round((completed / total) * 100);
  };

  // Node visual connections configuration for diagram rendering
  const connectionsMap = [
    { from: "phase-1", to: "phase-2", label: "Requisitos" },
    { from: "phase-2", to: "phase-3", label: "Realiza" },
    { from: "phase-3", to: "phase-4", label: "Sistemas logs" },
    { from: "phase-4", to: "phase-5", label: "Dimensiona" },
    { from: "phase-5", to: "phase-6", label: "Estabiliza" },
    { from: "phase-6", to: "phase-1", label: "Refina estratégia" },
  ];

  const selectedNode = enterpriseFrameworkNodes.find(n => n.id === selectedNodeId) || enterpriseFrameworkNodes[0];

  // Radar Data for visual display
  const getRadarMaturityData = () => {
    return [
      { subject: "Estratégia (BIZBOK)", A: 4.8, B: strategicPosture === "COST_LEADER" ? 3.9 : 4.4, fullMark: 5 },
      { subject: "Capacidade (BIZBOK)", A: 4.5, B: 4.1, fullMark: 5 },
      { subject: "Cadeia Valor (BIZBOK)", A: 4.9, B: (steps.length > 3 ? 4.3 : 3.2), fullMark: 5 },
      { subject: "Sis. Informação (TOGAF B-C)", A: 4.6, B: stats.rolledFirstPassYield * 5, fullMark: 5 },
      { subject: "Infra Tecnologia (TOGAF D)", A: 4.7, B: stats.systemUtilization < 80 ? 4.5 : 3.5, fullMark: 5 },
      { subject: "Melhoria Contínua (TOGAF H)", A: 4.8, B: stats.sigmaLevel, fullMark: 5 },
    ];
  };

  // Drill down function
  const handleDrillDownAction = () => {
    if (!onNavigateToView) return;
    
    // Switch workspaces dynamically according to selected stage suggestion
    if (selectedNode.suggestedWorkspace === "DMAIC" && onNavigateToDmaicPhase) {
      onNavigateToDmaicPhase("CONTROL");
    } else {
      onNavigateToView(selectedNode.suggestedWorkspace);
    }
  };

  return (
    <div className="bg-[#FAF9F6] border-4 border-slate-900 p-6 md:p-8 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] text-slate-900" id="enterprise-architecture-suite">
      
      {/* Title Header with TOGAF/BIZBOK Badges */}
      <div className="border-b-4 border-slate-900 pb-5 mb-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] border-2">
        <div className="text-left">
          <div className="flex flex-wrap gap-2 mb-2">
            <span className="text-[10px] bg-slate-900 text-white font-mono px-2 py-0.5 font-bold tracking-widest uppercase">
              TOGAF ADM Framework v10
            </span>
            <span className="text-[10px] bg-[#C49746] text-white font-mono px-2 py-0.5 font-bold tracking-widest uppercase">
              BIZBOK® Guide v12
            </span>
            <span className="text-[10px] bg-indigo-600 text-white font-mono px-2 py-0.5 font-bold tracking-widest uppercase">
              Sequenciador lógico "Empresa do Zero"
            </span>
          </div>
          <h2 className="text-3xl font-serif font-black tracking-tight uppercase leading-none text-slate-900">
            Suíte de Engenharia e Arquitetura Corporativa
          </h2>
          <p className="text-xs text-slate-500 max-w-2xl mt-2 leading-relaxed">
            Mapeamos relações essenciais de negócio desde a intenção estratégica de criação da firma (BIZBOK) 
            até a infraestrutura estocástica operacional e ciclos de melhoria contínua (TOGAF), permitindo monitorar 
            metas e acessar fases específicas do projeto instantaneamente via Drill Down.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-amber-50 border-2 border-slate-900 p-3 rounded-none shrink-0 text-left">
          <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-amber-400 font-mono text-lg font-black shrink-0 shadow-sm animate-pulse">
            {getOverallCompliancePercentage()}%
          </div>
          <div>
            <div className="text-[9px] uppercase font-bold text-slate-500 font-mono">Estrutura Corporativa</div>
            <div className="text-xs font-black text-slate-900 uppercase">Arquitetura Coerente</div>
            <div className="text-[9px] font-mono text-[#047857] font-bold">Checklists: {Object.values(complianceGrids).filter(Boolean).length}/{Object.keys(complianceGrids).length} Aprovados</div>
          </div>
        </div>
      </div>

      {/* Main navigation across subsystems */}
      <div className="flex flex-wrap gap-2 border-b-2 border-slate-900 mb-6 pb-2">
        <button
          onClick={() => setActiveTabPanel("BLUEPRINT_BUILDER")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "BLUEPRINT_BUILDER"
              ? "bg-[#C49746] text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px] italic font-serif"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          🏗️ 1. Do Zero: Sequência de Criação
        </button>

        <button
          onClick={() => setActiveTabPanel("RELATIONSHIP_NAV")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "RELATIONSHIP_NAV"
              ? "bg-slate-900 text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px] italic font-serif"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          👁️ 2. Mapa Visual de Relações (Strategy to Ops)
        </button>

        <button
          onClick={() => setActiveTabPanel("TOGAF_ADM")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "TOGAF_ADM"
              ? "bg-indigo-600 text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px]"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          🌍 3. Ciclo ADM TOGAF Completo
        </button>

        <button
          onClick={() => setActiveTabPanel("BIZBOK_MAP")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "BIZBOK_MAP"
              ? "bg-teal-700 text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px]"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          📐 4. Visão de Domínios BIZBOK
        </button>

        <button
          onClick={() => setActiveTabPanel("DRILLDOWN_NAV")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "DRILLDOWN_NAV"
              ? "bg-amber-500 text-slate-900 border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px] italic font-serif"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          🔍 5. Navegador Drill Down (Traceability)
        </button>

        <button
          onClick={() => setActiveTabPanel("CHANGE_MANAGEMENT")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "CHANGE_MANAGEMENT"
              ? "bg-[#047857] text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px]"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          🚧 6. Gestão de Mudanças
        </button>

        <button
          onClick={() => setActiveTabPanel("OKR_DASHBOARD")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "OKR_DASHBOARD"
              ? "bg-amber-600 text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px] italic font-serif"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          🎯 7. Dashboard de OKRs
        </button>

        <button
          onClick={() => setActiveTabPanel("QUALITY_DASHBOARD")}
          className={`px-4 py-2 border-2 text-xs font-bold leading-none tracking-wider uppercase transition-all duration-150 cursor-pointer ${
            activeTabPanel === "QUALITY_DASHBOARD"
              ? "bg-blue-600 text-white border-slate-900 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] translate-y-[-2px] italic"
              : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
          }`}
        >
          📊 8. Dashboard de Qualidade
        </button>
      </div>

      {/* RENDER VIEWPORTS */}
      {activeTabPanel === "BLUEPRINT_BUILDER" && (
        <div className="space-y-6 text-left">
          
          {/* Quick interactive parameters of 'Structuring the company from scratch' */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white border-2 border-slate-900 p-4 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <div>
              <label className="block text-[8px] font-mono font-bold uppercase tracking-wider text-slate-400 mb-1">Nome da Empresa nascente</label>
              <input 
                type="text" 
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 px-2 py-1 text-xs font-serif font-bold italic text-slate-900 focus:outline-none focus:border-slate-900 rounded-none"
                placeholder="Exemplo: TechInova Fab & CO"
              />
            </div>
            <div>
              <label className="block text-[8px] font-mono font-bold uppercase tracking-wider text-slate-400 mb-1">Slogan Estratégico (BIZBOK Vision)</label>
              <input 
                type="text" 
                value={companySlogan}
                onChange={(e) => setCompanySlogan(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 px-2 py-1 text-xs text-slate-700 focus:outline-none focus:border-slate-900 rounded-none font-mono"
                placeholder="Exemplo: Qualidade e agilidade em primeiro lugar"
              />
            </div>
            <div>
              <label className="block text-[8px] font-mono font-bold uppercase tracking-wider text-slate-400 mb-1">Postura Estratégica Competitiva</label>
              <div className="flex gap-1">
                {(["COST_LEADER", "DIFFERENTIATION", "AGILE_SPEED"] as const).map(style => (
                  <button
                    key={style}
                    onClick={() => setStrategicPosture(style)}
                    className={`flex-1 text-[8.5px] font-mono font-bold uppercase tracking-tighter py-1.5 border transition cursor-pointer ${
                      strategicPosture === style
                        ? "bg-slate-900 text-white border-slate-900"
                        : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    {style === "COST_LEADER" ? "Líder Custo" : style === "DIFFERENTIATION" ? "Diferenciação" : "Ágil/Tempo"}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* INTERRUPTOR DE METODOLOGIA ATIVA (TOGAF vs BIZBOK) */}
          <div className="bg-[#1E293B] border-4 border-slate-900 p-4 text-white shadow-[4px_4px_0px_0px_rgba(196,151,70,1)] flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="text-left">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse"></span>
                <h4 className="text-sm font-mono font-bold uppercase tracking-wider text-amber-400">
                  Filtro de Metodologia de Arquitetura Ativa
                </h4>
              </div>
              <p className="text-[11px] text-slate-305 mt-1 max-w-xl leading-relaxed">
                Alternar abaixo filtra instantaneamente os componentes em tempo real (metas/objetivos estratégicos BIZBOK, processos táticos de valor TOGAF e recursos de infraestrutura e TI).
              </p>
            </div>

            <div className="flex border-2 border-slate-700 bg-slate-950 p-1 rounded-none shrink-0">
              {(["ALL", "BIZBOK", "TOGAF"] as const).map((method) => (
                <button
                  key={method}
                  onClick={() => setSelectedMethodology(method)}
                  className={`px-3 py-1.5 font-mono text-[10px] font-extrabold uppercase cursor-pointer transition-all duration-100 ${
                    selectedMethodology === method
                      ? "bg-[#C49746] text-white"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
                  }`}
                >
                  {method === "ALL" ? "🔮 Unificado (Todos)" : method === "BIZBOK" ? "📐 BIZBOK" : "🌍 TOGAF ADM"}
                </button>
              ))}
            </div>
          </div>

          {/* Sub-navigation inside BLUEPRINT_BUILDER */}
          <div className="flex flex-wrap gap-2 border-b-2 border-slate-300 pb-2">
            <button
              onClick={() => setActiveSegmentNav("SEQUENCIA")}
              className={`px-3 py-1.5 border font-mono text-xs font-bold uppercase transition duration-150 cursor-pointer ${
                activeSegmentNav === "SEQUENCIA"
                  ? "bg-slate-900 text-white border-slate-900 shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                  : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
              }`}
            >
              📋 1.1 Sequência Cronológica (6 Marcos de Implantação)
            </button>
            <button
              onClick={() => setActiveSegmentNav("MODELADOR_RELACIONAL")}
              className={`px-3 py-1.5 border font-mono text-xs font-bold uppercase transition duration-150 cursor-pointer ${
                activeSegmentNav === "MODELADOR_RELACIONAL"
                  ? "bg-[#C49746] text-white border-[#C49746] shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                  : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
              }`}
            >
              🏛️ 1.2 Mapeador de Relações Tridimensionais (Objetivos ➔ Processos ➔ Recursos)
            </button>
          </div>

          {/* RENDERING SEGMENT SECTIONS */}
          {activeSegmentNav === "SEQUENCIA" ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Left side: Sequential interactive bento layout */}
              <div className="lg:col-span-7 col-span-1 space-y-4">
                <div className="bg-slate-900 text-white p-3 border-2 border-slate-900 flex justify-between items-center">
                  <span className="font-serif italic font-bold text-sm">Estruturação de Negócios Sequencial ("Empresa do Zero")</span>
                  <span className="text-[9px] font-mono tracking-widest text-[#C49746] font-bold">6 PASSOS LÓGICOS</span>
                </div>

                <div className="grid grid-cols-1 gap-3.5">
                  {enterpriseFrameworkNodes
                    .filter(node => selectedMethodology === "ALL" || node.framework === selectedMethodology || node.framework === "CROSS")
                    .map((node) => {
                      const isSelected = selectedNodeId === node.id;
                    const complianceNum = getPhaseCompliancePercentage(node.id);
                    return (
                      <div 
                        key={node.id}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`text-left p-4 border-2 transition-all duration-200 cursor-pointer relative flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                          isSelected 
                            ? "bg-amber-50/50 border-slate-900 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] scale-[1.01]" 
                            : "bg-white border-slate-200 hover:border-slate-400"
                        }`}
                      >
                        {/* Left Block info */}
                        <div className="flex gap-3 items-start flex-1 min-w-0">
                          <div className="w-8 h-8 rounded-none border border-slate-900 bg-white shadow-[1px_1px_0px_0px_rgba(26,26,26,1)] shrink-0 flex items-center justify-center">
                            {node.icon}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-[8.5px] font-mono font-bold tracking-wider px-1 text-white bg-slate-800 uppercase">
                                {node.framework}
                              </span>
                              <span className="text-[8.5px] font-mono font-bold text-indigo-700 tracking-tight">
                                FASE {node.sequenceOrder}
                              </span>
                              <span className="text-[8.5px] font-mono text-emerald-800 bg-emerald-50 px-1 border border-emerald-100 uppercase rounded-2xs font-extrabold">
                                {complianceNum}% Checked
                              </span>
                            </div>
                            <h4 className="text-sm font-bold text-slate-900 mt-1 truncate">{node.title}</h4>
                            <p className="text-[10.5px] text-slate-500 mt-1 leading-snug line-clamp-2">
                              {node.shortDesc}
                            </p>
                          </div>
                        </div>

                        {/* Right Block Metrics and compliance check status */}
                        <div className="flex md:flex-col items-end gap-2 pr-1 select-none font-mono shrink-0 justify-between md:justify-center">
                          <div className="text-right">
                            <span className="text-[8px] text-slate-400 block uppercase font-bold tracking-wider">Acessar via</span>
                            <span className="text-[10px] text-indigo-700 font-extrabold uppercase flex items-center gap-0.5 mt-0.5">
                              {node.suggestedWorkspace === "DIAGNOSTIC" ? "DIAGNÓSTICO" : 
                               node.suggestedWorkspace === "MAP" ? "MAPER DE PROCESSO" : 
                               node.suggestedWorkspace === "BI_STUDIO" ? "ESTÚDIO BI" : 
                               node.suggestedWorkspace === "OR_HUB" ? "ORQUESTRA OR-HUB" : 
                               node.suggestedWorkspace === "DMAIC" ? "PLANILHA DMAIC" : "KANBAN DE WIP"}
                              <ChevronRight size={10} />
                            </span>
                          </div>
                          
                          {isSelected && (
                            <span className="absolute -top-2.5 -right-2 px-1.5 py-0.5 bg-slate-900 text-white font-mono text-[7px] font-bold tracking-widest border border-slate-700 uppercase animate-bounce">
                              Selecionado
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right side: Detailed Workspace Drill Down Panel */}
              <div className="lg:col-span-5 col-span-1 bg-white border-4 border-slate-900 p-5 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] self-start relative">
                <div className="border-b-2 border-slate-200 pb-3 mb-4">
                  <span className="text-[8px] font-mono font-extrabold tracking-widest text-[#C49746] uppercase block">
                    Painel de Drill Down de Arquitetura
                  </span>
                  <h3 className="text-lg font-serif font-black uppercase text-slate-900 leading-tight mt-1">
                    {selectedNode.title}
                  </h3>
                  <p className="text-[10.5px] text-slate-500 font-mono mt-1">
                    Metodologia de Enquadramento: <strong className="text-slate-700">{selectedNode.framework}</strong> (Fase sequencial #{selectedNode.sequenceOrder})
                  </p>
                </div>

                {/* TABS of drill down panel: metrics vs guidelines */}
                <div className="flex border-b border-slate-200 mb-4 pb-1">
                  <button
                    onClick={() => setActiveDetailSection("METRICS")}
                    className={`flex-1 text-[10px] font-mono font-bold uppercase tracking-wider py-1.5 transition-all cursor-pointer ${
                      activeDetailSection === "METRICS" 
                        ? "border-b-2 border-indigo-600 text-indigo-700 font-extrabold" 
                        : "text-slate-400 hover:text-slate-600"
                    }`}
                  >
                    📈 Telemetria Real
                  </button>
                  <button
                    onClick={() => setActiveDetailSection("GUIDELINE")}
                    className={`flex-1 text-[10px] font-mono font-bold uppercase tracking-wider py-1.5 transition-all cursor-pointer ${
                      activeDetailSection === "GUIDELINE" 
                        ? "border-b-2 border-[#C49746] text-[#C49746] font-extrabold" 
                        : "text-slate-400 hover:text-slate-600"
                    }`}
                  >
                    📋 Checklist TOGAF/BIZBOK
                  </button>
                </div>

                {/* RENDER ACTIVE DETAILS SUBSECTION */}
                {activeDetailSection === "METRICS" ? (
                  <div className="space-y-4 text-left animate-fade-in">
                    <p className="text-[11.5px] text-slate-600 leading-relaxed font-sans">
                      Nossa IA vincula as métricas extraídas em tempo real da sua operação diretamente a este nível. 
                      Veja as variáveis impactantes calculadas:
                    </p>

                    <div className="space-y-2 font-mono">
                      {selectedNode.impactMetrics.map((met, idx) => (
                        <div key={idx} className="bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-800 flex justify-between items-center rounded-none shadow-[1px_1px_0px_rgba(0,0,0,0.05)]">
                          <span className="text-[10px] uppercase font-bold tracking-tight text-slate-500">Métrica {idx + 1}</span>
                          <span className="font-extrabold text-slate-900">{met}</span>
                        </div>
                      ))}
                    </div>

                    {/* Flow relationships mini summary */}
                    <div className="bg-[#FAF9F6] border-l-4 border-amber-500 p-3 mt-4 text-left">
                      <span className="text-[8px] font-mono text-amber-800 font-bold tracking-widest uppercase block mb-1">
                        🔗 Relações de Dependência Corporativa (Trilhas):
                      </span>
                      <ul className="space-y-1 text-[10.5px] text-slate-600 font-sans">
                        {selectedNode.relationships.map((rel, idx) => {
                          const targetNode = enterpriseFrameworkNodes.find(n => n.id === rel.targetId);
                          return (
                            <li key={idx} className="flex gap-1 items-start">
                              <span>➔</span>
                              <span>
                                <strong>{rel.type}</strong> conectando com a fase: <strong>"{targetNode?.title.split(".")[1].trim()}"</strong>.
                              </span>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 text-left animate-fade-in font-sans">
                    <p className="text-[11.5px] text-slate-600 leading-normal">
                      Checklist oficial de conformidade metodológica da arquitetura. Marque os requisitos cumpridos para alimentar o índice geral de integridade da firma:
                    </p>

                    <div className="space-y-2.5">
                      {selectedNode.checklist.map((item, idx) => {
                        const checkId = `check-${selectedNode.id.split("-")[1]}-${idx + 1}`;
                        const isChecked = !!complianceGrids[checkId];
                        return (
                          <div 
                            key={idx}
                            onClick={() => handleToggleCheck(checkId)}
                            className={`p-2.5 border-2 transition duration-200 cursor-pointer flex items-start gap-2 select-none ${
                              isChecked 
                                ? "bg-emerald-50/50 border-emerald-600 text-emerald-950" 
                                : "bg-white border-slate-200 text-slate-600 hover:border-slate-350"
                            }`}
                          >
                            <input 
                              type="checkbox" 
                              checked={isChecked}
                              readOnly
                              className="mt-0.5 accent-emerald-700" 
                            />
                            <span className="text-[10.5px] leading-snug font-medium text-left">
                              {item}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* ACTION: DEEP DRILL DOWN DRILLS INTO WORKSPACE VIEWPORT */}
                <div className="border-t border-slate-200 mt-6 pt-4 flex flex-col gap-2">
                  <button
                    onClick={handleDrillDownAction}
                    className="w-full bg-slate-900 text-white font-mono text-xs font-black uppercase py-3 border-2 border-slate-900 shadow-[3px_3px_0px_0px_rgba(196,151,70,1)] hover:translate-y-[-1px] active:translate-y-[0px] duration-150 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>🚀 Acessar Fase via DRILL DOWN</span>
                    <ArrowRight size={14} className="text-amber-400" />
                  </button>

                  <p className="text-[9px] text-slate-400 font-mono text-center">
                    *Ao clicar, o cockpit corporativo altera o workspace ativo para {selectedNode.suggestedWorkspace === "DIAGNOSTIC" ? "Estatísticas & Project Charter" : 
                     selectedNode.suggestedWorkspace === "MAP" ? "Visual Process Mapper" : 
                     selectedNode.suggestedWorkspace === "BI_STUDIO" ? "Business Intelligence Studio" : 
                     selectedNode.suggestedWorkspace === "OR_HUB" ? "Pesquisa Operacional & Filas" : "DMAIC Wizard"}.
                  </p>
                </div>

              </div>

            </div>
          ) : (
            /* 1.2 MODELADOR RELACIONAL (STARTING COMPANY FROM SCRATCH) */
            <div className="space-y-6 animate-fade-in text-left">
              
              {/* Context Summary card */}
              <div className="bg-amber-50/80 border-2 border-[#C49746] p-4 text-slate-900 relative">
                <h4 className="text-sm font-serif font-black uppercase text-slate-900 flex items-center gap-2">
                  <Workflow className="text-[#C49746]" size={16} />
                  Mapeador da Firma do Zero (TOGAF Phase B/C & BIZBOK Strategic Alignments)
                </h4>
                <p className="text-xs text-slate-700 mt-1 leading-relaxed max-w-4xl">
                  Aqui você desenha a infraestrutura do zero. Mapeamos interativamente <strong>Metas de Negócio</strong> (BIZBOK) com <strong>Processos Reais da Planta</strong> (TOGAF Business Architecture) e <strong>Recursos Físicos/Sistemas</strong> (TOGAF Data/Technology Architecture). Clique nas caixas ou relações no painel inferior para iluminar e rastrear a cadeia vertical de influência.
                </p>

                <div className="absolute top-2 right-2 text-[9px] font-mono text-slate-400 italic bg-white px-2 py-0.5 border">
                  Sinergia Ativa
                </div>
              </div>

              {/* THREE COLS ARCHITECTURE MAP */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch font-sans">
                
                {/* COLUMN 1: OBJECTIVES (BIZBOK STRATEGY TIER) */}
                <div className="bg-white border-2 border-slate-900 p-4 shadow-[3px_3px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center border-b border-slate-200 pb-2 mb-3">
                      <span className="text-[10px] font-mono font-bold text-emerald-800 uppercase bg-emerald-50 px-1 border border-emerald-200">
                        BIZBOK Strategy Core
                      </span>
                      <span className="text-[8px] font-mono text-slate-400">PASSO 1</span>
                    </div>
                    <h5 className="text-xs font-mono font-black uppercase text-slate-800 mb-2">
                      🎯 OBJETIVOS DE NEGÓCIO
                    </h5>
                    <p className="text-[10px] text-slate-500 mb-3 leading-snug">
                      Intenções de valor e KPIs táticos que orientam a engenharia de fluxo da firma.
                    </p>

                    <div className="space-y-2.5">
                      {customObjectives
                        .filter(obj => selectedMethodology === "ALL" || !obj.framework || obj.framework === "AMBOS" || obj.framework === selectedMethodology)
                        .map((obj) => {
                          const isHovered = hoveredObjectiveId === obj.id;
                          const isLinkedToActiveRel = relationships.find(r => r.id === selectedRelationId)?.objectiveId === obj.id;
                          return (
                            <div
                              key={obj.id}
                              onClick={() => {
                                setHoveredObjectiveId(obj.id);
                                // Auto filter relationship finding
                                const rel = relationships.find(r => r.objectiveId === obj.id);
                                if (rel) setSelectedRelationId(rel.id);
                              }}
                              className={`p-3 border-2 transition duration-200 cursor-pointer text-left relative ${
                                isLinkedToActiveRel 
                                  ? "bg-amber-50/70 border-[#C49746] shadow-[2px_2px_0px_rgba(26,26,26,0.15)]" 
                                  : isHovered
                                    ? "bg-slate-50 border-slate-950" 
                                    : "bg-white border-slate-200 hover:border-slate-450"
                              }`}
                            >
                              <div className="flex flex-wrap gap-1 items-center">
                                <span className={`text-[8px] font-mono font-bold px-1 py-0.2 rounded uppercase ${
                                  obj.strategyType === "QUALIDADE" ? "bg-emerald-100 text-emerald-900" :
                                  obj.strategyType === "EFICIENCIA" ? "bg-indigo-100 text-indigo-900" :
                                  obj.strategyType === "TEMPO" ? "bg-amber-100 text-amber-900" : "bg-slate-100 text-slate-900"
                                }`}>
                                  {obj.strategyType} • Meta: {obj.metricTarget}
                                </span>
                                {obj.framework && (
                                  <span className="text-[7.5px] font-mono font-bold px-1 py-0.2 rounded bg-slate-950 text-white uppercase">
                                    {obj.framework}
                                  </span>
                                )}
                              </div>
                              <h6 className="text-[11.5px] font-bold text-slate-900 mt-1.5">{obj.title}</h6>
                              <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">{obj.description}</p>
                            </div>
                          );
                        })}
                    </div>
                  </div>

                  <button
                    onClick={() => setShowObjectiveModal(!showObjectiveModal)}
                    className="w-full mt-4 text-[9px] font-mono font-bold uppercase py-1.5 border-2 border-dashed border-slate-700 hover:bg-slate-50 text-slate-800 cursor-pointer"
                  >
                    {showObjectiveModal ? "Fechar Formulário ✕" : "+ CADASTRAR NOVO OBJETIVO BIZBOK"}
                  </button>
                </div>

                {/* COLUMN 2: PROCESSES (TOGAF BUSINESS ARCHITECTURE) */}
                <div className="bg-white border-2 border-slate-900 p-4 shadow-[3px_3px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center border-b border-slate-200 pb-2 mb-3">
                      <span className="text-[10px] font-mono font-bold text-indigo-800 uppercase bg-indigo-50 px-1 border border-indigo-200">
                        TOGAF Phase B Core
                      </span>
                      <span className="text-[8px] font-mono text-slate-400">PASSO 2</span>
                    </div>
                    <h5 className="text-xs font-mono font-black uppercase text-slate-800 mb-2">
                      ⚙️ PROCESSOS CORRESPONDENTES
                    </h5>
                    <p className="text-[10px] text-slate-500 mb-3 leading-snug">
                      Fluxos de valor operacionais onde o produto recebe agregação física de valor.
                    </p>

                    <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                      {customProcesses
                        .filter(proc => selectedMethodology === "ALL" || !proc.framework || proc.framework === "AMBOS" || proc.framework === selectedMethodology)
                        .map((proc) => {
                          const isHovered = hoveredProcessId === proc.id;
                          const isLinkedToActiveRel = relationships.find(r => r.id === selectedRelationId)?.processId === proc.id;
                          
                          // Look up step in real-time execution steps prop to extract actual variables
                          const linkedRealStep = steps.find(s => s.id === proc.associatedStepId);

                          return (
                            <div
                              key={proc.id}
                              onClick={() => {
                                setHoveredProcessId(proc.id);
                                const rel = relationships.find(r => r.processId === proc.id);
                                if (rel) setSelectedRelationId(rel.id);
                              }}
                              className={`p-3 border-2 transition duration-200 cursor-pointer text-left ${
                                isLinkedToActiveRel 
                                  ? "bg-amber-50/70 border-indigo-700 shadow-[2px_2px_0px_rgba(26,26,26,0.15)]" 
                                  : isHovered
                                    ? "bg-slate-50 border-slate-950" 
                                    : "bg-white border-slate-200 hover:border-slate-450"
                              }`}
                            >
                              <div className="flex flex-wrap justify-between items-center gap-1.5">
                                <div className="flex items-center gap-1">
                                  <span className="text-[8.5px] font-mono text-indigo-700 font-extrabold uppercase">
                                    WS: {proc.suggestedWorkspace}
                                  </span>
                                  {proc.framework && (
                                    <span className="text-[7px] font-mono font-bold bg-slate-900 text-white px-1 uppercase">
                                      {proc.framework}
                                    </span>
                                  )}
                                </div>
                                {linkedRealStep && (
                                  <span className="text-[8px] font-mono text-emerald-800 bg-emerald-50 px-1 border font-bold">
                                    Yield Ativo: {linkedRealStep.yieldRate}%
                                  </span>
                                )}
                              </div>
                              <h6 className="text-[11.5px] font-bold text-slate-900 mt-1">{proc.name}</h6>
                            <div className="text-[10px] mt-1 text-slate-500 font-mono space-y-0.5">
                              <div>Dono: <span className="font-sans font-bold text-slate-700">{proc.owner}</span></div>
                              {linkedRealStep && (
                                <div className="text-[8.5px] text-slate-400">
                                  Tempo Processo: {linkedRealStep.processingTime}s | Recursos: {linkedRealStep.resourceCount} maquinário(s)
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="text-[9.5px] text-[#C49746] font-mono border-t pt-3 mt-3">
                    ✔ Auto-Sincronizado: {steps.length} postos sequenciais importados da planta.
                  </div>
                </div>

                {/* COLUMN 3: TECHNOLOGY RESOURCES (TOGAF SYSTEMS & TECH ARCHITECTURE) */}
                <div className="bg-white border-2 border-slate-900 p-4 shadow-[3px_3px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center border-b border-slate-200 pb-2 mb-3">
                      <span className="text-[10px] font-mono font-bold text-purple-800 uppercase bg-purple-50 px-1 border border-purple-200">
                        TOGAF Phase C/D Logic
                      </span>
                      <span className="text-[8px] font-mono text-slate-400">PASSO 3</span>
                    </div>
                    <h5 className="text-xs font-mono font-black uppercase text-slate-800 mb-2">
                      💻 RECURSOS DE TI & INFRAESTRUTURA
                    </h5>
                    <p className="text-[10px] text-slate-500 mb-3 leading-snug">
                      Sistemas computacionais, misturadores físicos, solvers matemáticos e bancos PostgreSQL.
                    </p>

                    <div className="space-y-2.5">
                      {customResources
                        .filter(res => selectedMethodology === "ALL" || !res.framework || res.framework === "AMBOS" || res.framework === selectedMethodology)
                        .map((res) => {
                          const isHovered = hoveredResourceId === res.id;
                          const isLinkedToActiveRel = relationships.find(r => r.id === selectedRelationId)?.resourceId === res.id;
                          return (
                            <div
                              key={res.id}
                              onClick={() => {
                                setHoveredResourceId(res.id);
                                const rel = relationships.find(r => r.resourceId === res.id);
                                if (rel) setSelectedRelationId(rel.id);
                              }}
                              className={`p-3 border-2 transition duration-200 cursor-pointer text-left ${
                                isLinkedToActiveRel 
                                  ? "bg-amber-50/70 border-purple-700 shadow-[2px_2px_0px_rgba(26,26,26,0.15)]" 
                                  : isHovered
                                    ? "bg-slate-50 border-slate-950" 
                                    : "bg-white border-slate-200 hover:border-slate-450"
                              }`}
                            >
                              <div className="flex flex-wrap gap-1 items-center">
                                <span className="text-[8px] font-mono bg-purple-100 text-purple-900 px-1 py-0.2 rounded uppercase">
                                  {res.type}
                                </span>
                                {res.framework && (
                                  <span className="text-[7.5px] font-mono font-bold bg-slate-950 text-white px-1 uppercase">
                                    {res.framework}
                                  </span>
                                )}
                              </div>
                              <h6 className="text-[11.5px] font-bold text-slate-900 mt-1">{res.name}</h6>
                            <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">{res.capacityInfo}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="text-[9.5px] italic text-indigo-700 mt-4 font-mono font-bold leading-normal bg-indigo-50 border p-2 text-left">
                    🧠 <strong>TOGAF ADM:</strong> O repositório central de governança sincroniza cada ativo à infraestrutura da baia.
                  </div>
                </div>

              </div>

              {/* INLINE FORM FOR CREATING CUSTOM OBJECTIVE (TOGGLES ON DEMAND) */}
              {showObjectiveModal && (
                <div className="bg-white border-4 border-slate-900 p-4 shadow-[4px_4px_0px_rgba(0,0,0,1)] animate-fade-in font-sans">
                  <h5 className="text-xs font-mono font-black uppercase text-slate-800 border-b pb-1.5 mb-3 flex justify-between items-center">
                    <span>📝 CADASTRAR DIRETIVA ESTRATÉGICA BIZBOK</span>
                    <span className="text-[9px] text-[#C49746]">Nova Meta da Empresa</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-left">
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5">Título / Meta</label>
                      <input
                        type="text"
                        value={newObjTitle}
                        onChange={(e) => setNewObjTitle(e.target.value)}
                        placeholder="Ex: Minimizar lead time faturamento"
                        className="w-full bg-slate-50 border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5">Foco de Postura</label>
                      <select
                        value={newObjStrategy}
                        onChange={(e) => setNewObjStrategy(e.target.value as any)}
                        className="w-full bg-slate-50 border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-mono"
                      >
                        <option value="QUALIDADE">Qualidade (LSS FPY)</option>
                        <option value="EFICIENCIA">Eficiência (Ocelos Saturação)</option>
                        <option value="TEMPO">Tempo (Lead Time)</option>
                        <option value="CRESCIMENTO">Crescimento (Escopo / Vol)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5">Métrica Alvo (KPI)</label>
                      <input
                        type="text"
                        value={newObjMetric}
                        onChange={(e) => setNewObjMetric(e.target.value)}
                        placeholder="Ex: < 120 segundos"
                        className="w-full bg-slate-50 border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5">Metodologia</label>
                      <select
                        value={newObjFramework}
                        onChange={(e) => setNewObjFramework(e.target.value as any)}
                        className="w-full bg-slate-50 border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-mono"
                      >
                        <option value="BIZBOK">📐 BIZBOK</option>
                        <option value="TOGAF">🌍 TOGAF</option>
                        <option value="AMBOS">🔮 Ambos</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5">Descrição Curta</label>
                      <input
                        type="text"
                        value={newObjDesc}
                        onChange={(e) => setNewObjDesc(e.target.value)}
                        placeholder="Ex: Alinhar com Sponsor Governança v1"
                        className="w-full bg-slate-50 border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex gap-2 justify-end">
                    <button
                      onClick={() => {
                        if (!newObjTitle) return;
                        const nobj: EnterpriseObjective = {
                          id: `obj-${Date.now()}`,
                          title: newObjTitle,
                          strategyType: newObjStrategy,
                          metricTarget: newObjMetric || "N/A",
                          description: newObjDesc || "Diretriz tática customizada por arquiteto sênior.",
                          framework: newObjFramework
                        };
                        setCustomObjectives(prev => [...prev, nobj]);
                        setNewObjTitle("");
                        setNewObjMetric("");
                        setNewObjDesc("");
                        setNewObjFramework("BIZBOK");
                        setShowObjectiveModal(false);
                      }}
                      className="bg-slate-900 text-white font-mono text-xs font-bold py-1.5 px-4 uppercase hover:bg-slate-800"
                    >
                      ✓ Adicionar ao Portfólio Estratégico
                    </button>
                    <button
                      onClick={() => setShowObjectiveModal(false)}
                      className="bg-slate-100 text-slate-600 font-mono text-xs py-1.5 px-3 border border-slate-200"
                    >
                      Mudar de Ideia
                    </button>
                  </div>
                </div>
              )}

              {/* DYNAMIC RELATIONSHIP CONNECTORS BOARD (REPRESENTING SHOWN LINKAGES) */}
              <div className="bg-slate-900 text-[#FAF9F6] border-4 border-slate-900 p-5 shadow-[5px_5px_0px_rgba(0,0,0,1)] flex flex-col gap-5 text-left font-sans">
                
                <div className="border-b border-slate-800 pb-3 flex justify-between items-center flex-wrap gap-2">
                  <div className="text-left">
                    <span className="text-[9px] font-mono text-[#C49746] font-bold tracking-widest uppercase block">
                      Blueprint de Vinculação Ativa (TOGAF Arq Model ➔ BIZBOK Core)
                    </span>
                    <h4 className="text-sm font-serif font-black uppercase text-white tracking-tight mt-1">
                      🔗 Relações de Integração da Empresa do Zero
                    </h4>
                  </div>
                  <button
                    onClick={() => {
                      setShowAddRelationalModal(!showAddRelationalModal);
                      // Pre-select some options
                      if (customObjectives.length > 0) setSelectedObjectiveIdRel(customObjectives[0].id);
                      if (customProcesses.length > 0) setSelectedProcessIdRel(customProcesses[0].id);
                      if (customResources.length > 0) setSelectedResourceIdRel(customResources[0].id);
                    }}
                    className="bg-[#C49746] text-white font-mono text-xs font-bold px-3 py-1.5 border border-slate-900 shadow-sm uppercase hover:bg-[#b5883a] cursor-pointer"
                  >
                    {showAddRelationalModal ? "Fechar Painel" : "🔗 Mapear Nova Relação do Zero"}
                  </button>
                </div>

                {/* QUICK CONNECTOR ASSEMBLY PANEL */}
                {showAddRelationalModal && (
                  <div className="bg-white text-slate-900 p-4 border border-dashed border-[#C49746] mb-2 text-left animate-slide-in">
                    <h5 className="text-xs font-mono font-bold uppercase text-indigo-900 mb-3 block">
                      🏗️ ACOPLADOR DE METAS OPERACIONAIS (FÓRMULA DE RELAÇÃO)
                    </h5>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5">1. Selecione a Meta BIZBOK</label>
                        <select
                          value={selectedObjectiveIdRel}
                          onChange={(e) => setSelectedObjectiveIdRel(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-1.5 text-xs rounded-none font-sans text-slate-900 focus:outline-none focus:border-slate-900"
                        >
                          {customObjectives.map(o => (
                            <option key={o.id} value={o.id}>{o.title}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5">2. Vincular ao Processo TOGAF</label>
                        <select
                          value={selectedProcessIdRel}
                          onChange={(e) => setSelectedProcessIdRel(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-1.5 text-xs rounded-none font-sans text-slate-900 focus:outline-none focus:border-slate-900"
                        >
                          {customProcesses.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5">3. Consumir Recurso de TI / Físico</label>
                        <select
                          value={selectedResourceIdRel}
                          onChange={(e) => setSelectedResourceIdRel(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-1.5 text-xs rounded-none font-sans text-slate-900 focus:outline-none focus:border-slate-900"
                        >
                          {customResources.map(r => (
                            <option key={r.id} value={r.id}>{r.name} ({r.type})</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="mt-3">
                      <label className="block text-[8px] font-mono font-bold text-slate-400 mb-0.5">Nota de Integração / Justificativa LSS de Coerência</label>
                      <input
                        type="text"
                        value={newIntegrationNote}
                        onChange={(e) => setNewIntegrationNote(e.target.value)}
                        placeholder="Ex: Auditoria imediata na retífica para estabilizar índice First Pass Yield global"
                        className="w-full bg-slate-50 border border-slate-300 p-1.5 text-xs rounded-none font-sans text-slate-900 focus:outline-none focus:border-slate-900"
                      />
                    </div>

                    <div className="mt-4 flex gap-2 justify-end">
                      <button
                        onClick={() => {
                          if (!selectedObjectiveIdRel || !selectedProcessIdRel || !selectedResourceIdRel) return;
                          
                          const nrel: CustomRelationship = {
                            id: `rel-${Date.now()}`,
                            objectiveId: selectedObjectiveIdRel,
                            processId: selectedProcessIdRel,
                            resourceId: selectedResourceIdRel,
                            integrationNote: newIntegrationNote || "Alinhamento sistêmico de processos e metas no cockpit LSS."
                          };
                          setRelationships(prev => [...prev, nrel]);
                          setSelectedRelationId(nrel.id);
                          setNewIntegrationNote("");
                          setShowAddRelationalModal(false);
                        }}
                        className="bg-indigo-700 text-white font-mono text-xs font-bold py-1.5 px-4 uppercase hover:bg-indigo-800"
                      >
                        ✓ Consolidar Dependência de Negócio
                      </button>
                      <button
                        onClick={() => setShowAddRelationalModal(false)}
                        className="bg-slate-100 text-slate-600 font-mono text-xs py-1.5 px-3"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                )}

                {/* LIVE CONNECTIONS LIST MAP */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {relationships.map((rel) => {
                    const mappedObj = customObjectives.find(o => o.id === rel.objectiveId);
                    const mappedProc = customProcesses.find(p => p.id === rel.processId);
                    const mappedRes = customResources.find(r => r.id === rel.resourceId);

                    const isActive = selectedRelationId === rel.id;

                    return (
                      <div
                        key={rel.id}
                        onClick={() => {
                          setSelectedRelationId(rel.id);
                          if (mappedObj) setHoveredObjectiveId(mappedObj.id);
                          if (mappedProc) setHoveredProcessId(mappedProc.id);
                          if (mappedRes) setHoveredResourceId(mappedRes.id);
                        }}
                        className={`p-3.5 border text-left cursor-pointer transition duration-150 relative flex flex-col justify-between ${
                          isActive 
                            ? "bg-amber-50 text-slate-900 border-[#C49746] shadow-[3px_3px_0px_rgba(255,255,255,0.1)]" 
                            : "bg-[#1E293B] border-slate-700 hover:border-slate-500"
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-center mb-1 flex-wrap gap-1">
                            <span className="text-[8px] font-mono tracking-widest text-[#C49746] font-bold uppercase">
                              CADENCIAL MAPPED CONEXÃO
                            </span>
                            {isActive && (
                              <span className="text-[7.5px] font-mono text-white bg-[#C49746] px-1 font-bold animate-pulse">
                                ILUMINADO
                              </span>
                            )}
                          </div>
                          
                          <div className="text-xs font-bold leading-tight line-clamp-1">
                            {mappedObj?.title || "Objetivo não encontrado"}
                          </div>

                          <div className={`text-[10px] my-2 p-1 font-mono leading-none ${isActive ? "bg-amber-100/40 text-slate-700" : "bg-slate-800 text-slate-400"}`}>
                            ➔ Processo: {mappedProc?.name || "N/A"}<br/>
                            ➔ Recurso: {mappedRes?.name || "N/A"}
                          </div>

                          <p className={`text-[10px] leading-snug line-clamp-3 ${isActive ? "text-slate-600" : "text-slate-400"}`}>
                            {rel.integrationNote}
                          </p>
                        </div>

                        <div className="mt-4 pt-3.5 border-t border-slate-100/10 flex items-center justify-between">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!mappedProc || !onNavigateToView) return;
                              // Drift drill down directly to defined workspace
                              onNavigateToView(mappedProc.suggestedWorkspace);
                            }}
                            className={`font-mono text-[9px] font-extrabold uppercase tracking-tight flex items-center gap-1 cursor-pointer py-1 px-1.5 border duration-100 ${
                              isActive
                                ? "bg-slate-900 text-white border-slate-900 hover:bg-slate-800"
                                : "bg-[#273549] text-amber-400 border-transparent hover:bg-slate-800"
                            }`}
                          >
                            <span>🚀 Drill Down {mappedProc?.suggestedWorkspace}</span>
                            <ChevronRight size={10} />
                          </button>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setRelationships(prev => prev.filter(r => r.id !== rel.id));
                              if (selectedRelationId === rel.id) setSelectedRelationId(null);
                            }}
                            className="text-[9px] text-red-400 font-mono hover:text-red-600 cursor-pointer p-1"
                            title="Desfazer Relação"
                          >
                            Desvincular
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="text-center font-mono text-[9px] text-slate-500 mt-2">
                  *Ao interagir com as conexões acima, as variáveis dependentes são destacadas e o usuário pode disparar o drill down para qualquer fase do projeto na hora!
                </div>

              </div>

            </div>
          )}

        </div>
      )}

      {/* VIEWPORT 2: CHRONOLOGICAL RELATIONSHIPS MAP */}
      {activeTabPanel === "RELATIONSHIP_NAV" && (
        <div className="space-y-6 text-left animate-fade-in">
          <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 mb-2">
              <Network size={14} className="animate-spin text-[#C49746]" />
              Estrutura em Camadas (Layered Enterprise Grid)
            </h3>
            <p className="text-xs text-slate-600 mb-6 leading-relaxed max-w-4xl">
              De acordo com as abordagens combinadas de modelagem BIZBOK e TOGAF, o negócio é estruturado sobre camadas interdependentes. 
              Ao interagir com os níveis das caixas abaixo, você enxergará visualmente a dependência e o fluxo vertical de influência (da Estratégia até as Baias Operacionais).
            </p>

            {/* Hierarchical layers layout */}
            <div className="space-y-8 relative">
              
              {/* LAYER 1: STRATEGY TIER (BIZBOK Domain) */}
              <div className="border-2 border-[#C49746] bg-amber-50/20 p-4 relative">
                <div className="absolute -top-3.5 left-4 bg-[#C49746] text-white font-mono text-[8px] font-bold px-2 py-0.5 tracking-widest uppercase">
                  Camada 1: Estratégia, Visão &amp; Escopo (BIZBOK Body of Knowledge)
                </div>
                <div className="text-[10px] text-slate-400 font-mono mb-3 uppercase tracking-tighter text-left">
                  Governança sênior: Propósito mercadológico ➔ Alinhamento de Portfólio ➔ Escopo de Melhoria
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div 
                    onClick={() => { setSelectedNodeId("phase-1"); }}
                    className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                      selectedNodeId === "phase-1" ? "bg-[#C49746]/10 border-slate-900 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-[#C49746] font-black uppercase">Goal Alignment</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">Slogan &amp; Patrocínio</h4>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono leading-none">{companySlogan}</p>
                  </div>

                  <div 
                    onClick={() => { setSelectedNodeId("phase-2"); }}
                    className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                      selectedNodeId === "phase-2" ? "bg-indigo-50/40 border-slate-900 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-indigo-700 font-black uppercase">BIZBOK Capacidades</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">Mapeamento de Áreas</h4>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono leading-none">Maturidade de Belts Lean</p>
                  </div>

                  <div 
                    onClick={() => { setSelectedNodeId("phase-3"); }}
                    className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                      selectedNodeId === "phase-3" ? "bg-amber-50 border-slate-900 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-amber-700 font-black uppercase">BIZBOK Value Stream</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">Cadeia de Fornecimento</h4>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono leading-none">Vazão &amp; Entregas</p>
                  </div>
                </div>
              </div>

              {/* Vertical connector helper arrows */}
              <div className="flex justify-center gap-12 font-mono text-[#C49746] text-xs font-black animate-pulse py-0 leading-none my-[-10px] select-none">
                <span className="rotate-90 block transform origin-center text-slate-400 font-bold">➔</span>
                <span className="text-[9px] uppercase tracking-wider text-slate-400">Desce requisitos sistêmicos operacionais</span>
                <span className="rotate-90 block transform origin-center text-slate-400 font-bold">➔</span>
              </div>

              {/* LAYER 2: SYSTEM BLUEPRINT TIER (TOGAF ADM C-D) */}
              <div className="border-2 border-indigo-600 bg-indigo-50/10 p-4 relative">
                <div className="absolute -top-3.5 left-4 bg-indigo-600 text-white font-mono text-[8px] font-bold px-2 py-0.5 tracking-widest uppercase">
                  Camada 2: Arquitetura de Sistemas de Informação &amp; Tecnologia (TOGAF IS/IT)
                </div>
                <div className="text-[10px] text-slate-400 font-mono mb-3 uppercase tracking-tighter text-left">
                  Pontes de tecnologia: Ledger de dados ➔ BI Studio do Processo ➔ Otimização e Estocástica de Filas G/G/1
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div 
                    onClick={() => { setSelectedNodeId("phase-4"); }}
                    className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                      selectedNodeId === "phase-4" ? "bg-teal-50 border-slate-800 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-teal-800 font-black uppercase">TOGAF Fase C (Sistema de Dados)</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">BI &amp; Saneamento Cadastral FP&amp;A</h4>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono leading-none">FPY Compounded: {(stats.rolledFirstPassYield * 100).toFixed(1)}%</p>
                  </div>

                  <div 
                    onClick={() => { setSelectedNodeId("phase-5"); }}
                    className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                      selectedNodeId === "phase-5" ? "bg-purple-50 border-slate-800 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-purple-700 font-black uppercase">TOGAF Fase D (Física &amp; Infraestrutura)</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">Filas &amp; Limitadores Físicos de Setup</h4>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono leading-none">Capacidade Max: {stats.systemCapacity.toFixed(1)} un/hora</p>
                  </div>
                </div>
              </div>

              {/* Vertical connector helper arrows */}
              <div className="flex justify-center gap-12 font-mono text-indigo-600 text-xs font-black animate-pulse py-0 leading-none my-[-10px] select-none">
                <span className="rotate-90 block transform origin-center text-slate-400 font-bold">➔</span>
                <span className="text-[9px] uppercase tracking-wider text-slate-400">Instancia controle nas baias reais</span>
                <span className="rotate-90 block transform origin-center text-slate-400 font-bold">➔</span>
              </div>

              {/* LAYER 3: OPERATIONS & QUALITY MONITOR TIER (Six Sigma Ops) */}
              <div className="border-2 border-emerald-600 bg-emerald-50/10 p-4 relative">
                <div className="absolute -top-3.5 left-4 bg-emerald-600 text-white font-mono text-[8px] font-bold px-2 py-0.5 tracking-widest uppercase">
                  Camada 3: Monitoramento Tático de Baias &amp; Gestão Lean Six Sigma (LSS)
                </div>
                <div className="text-[10px] text-slate-400 font-mono mb-3 uppercase tracking-tighter text-left">
                  Linha de frente: Atividades nas baias de conformidade ➔ Desvios e Cartas estatísticas ➔ Ciclo DMAIC
                </div>

                <div 
                  onClick={() => { setSelectedNodeId("phase-6"); }}
                  className={`p-3 border-2 border-dashed rounded-none transition text-left cursor-pointer ${
                    selectedNodeId === "phase-6" ? "bg-emerald-50 border-slate-900 shadow-sm" : "bg-white border-slate-200 hover:border-slate-400"
                  }`}
                >
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <div>
                      <span className="text-[9px] font-mono text-emerald-800 font-black uppercase">Arquitetura de Mudança (TOGAF Fase H)</span>
                      <h4 className="text-xs font-bold text-slate-800 mt-1 truncate">Controle Estatístico CEP &amp; DMAIC de Estabilidade</h4>
                    </div>
                    <div className="bg-emerald-100 border border-emerald-200 p-2 text-right font-mono text-xs scale-[0.9] shrink-0">
                      <span className="block text-[8px] text-emerald-800 uppercase font-black">Performance</span>
                      <strong>{stats.sigmaLevel.toFixed(2)} σ</strong> / {Math.round(stats.dpmo)} DPMO
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Quick interactive drill-down bridge widget */}
          <div className="bg-slate-900 text-[#FAF9F6] border-2 border-slate-900 p-5 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-left">
              <span className="text-[9px] font-mono font-bold text-[#C49746] tracking-wider uppercase block">Navegação Integrada de Negócio</span>
              <h4 className="text-sm font-bold uppercase mt-1 leading-none font-serif italic text-white">Visualisador Ativo de Drill Down</h4>
              <p className="text-[10.5px] text-slate-400 mt-1 leading-snug">
                Você pode interagir ou clicar em qualquer caixa de camada das metodologias para detalhar. 
                Utilize o botão de drill down para acessar o workspace correspondente.
              </p>
            </div>
            <button
              onClick={() => {
                const node = enterpriseFrameworkNodes.find(n => n.id === selectedNodeId) || enterpriseFrameworkNodes[0];
                if (onNavigateToView) onNavigateToView(node.suggestedWorkspace);
              }}
              className="bg-[#C49746] text-white border-slate-900 border-2 font-mono text-xs font-bold py-2.5 px-5 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex items-center gap-1.5 cursor-pointer hover:bg-[#b08337]"
            >
              <span>Navegar para Workspace ➔</span>
            </button>
          </div>
        </div>
      )}

      {/* VIEWPORT 3: TOGAF ADM THEORETICAL BLUEPRINT */}
      {activeTabPanel === "TOGAF_ADM" && (
        <div className="space-y-6 text-left animate-fade-in relative">
          <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <h3 className="text-base font-serif font-bold text-slate-900 mb-2 uppercase">
              O Círculo ADM TOGAF (Architecture Development Method)
            </h3>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed">
              O método ADM representa o núcleo do TOGAF, uma sequência de fases interativas em carrossel circular para planejar, monitorar, implantar e gerir a evolução da arquitetura corporativa da sua organização:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">P</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Preliminar</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Princípios da empresa, equipe de governança e alinhamento de escopo geral.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-1"); }}
                  className="text-[9px] text-[#C49746] font-mono font-bold mt-3 block"
                >
                  Visualizar Requisitos ➔
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">A</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Fase A: Visão</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Declarações de compromisso, slogan e o escopo fundamental do seu pipeline.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-1"); }}
                  className="text-[9px] text-slate-500 font-mono font-bold mt-3 block"
                >
                  Visualizar Requisitos ➔
                </button>
              </div>

              <div className="p-4 bg-[#FAF9F6] border border-amber-300 text-left shadow-2xs">
                <span className="w-6 h-6 rounded-full bg-[#C49746] text-white font-mono text-xs flex items-center justify-center font-bold">B</span>
                <h4 className="text-xs font-black uppercase text-[#C49746] font-mono mt-2">Fase B: Business</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Mapeamentos de atividades reais, fluxos de valor e diagramação visual (SIPOC).
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-3"); }}
                  className="text-[9px] text-[#C49746] font-mono font-bold mt-3 block"
                >
                  Ir para Cadeia Real ➔
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">C</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Fase C: Informações Plan</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Arquitetura de dados relacionais e software de monitoramento BI.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-4"); }}
                  className="text-[9px] text-slate-500 font-mono font-bold mt-3 block"
                >
                  Ver Bases de Dados ➔
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">D</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Fase D: Technology</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Aplicações físicas de servidores, fluxos de faturamento e taxas de filas.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-5"); }}
                  className="text-[9px] text-slate-500 font-mono font-bold mt-3 block"
                >
                  Modelar Engenharia ➔
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">E/F</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Soluções &amp; Roadmap</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Planejamento e análise de restrição de transição para o Estado Futuro LSS.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-5"); }}
                  className="text-[9px] text-slate-500 font-mono font-bold mt-3 block"
                >
                  Refinar Soluções ➔
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 text-left">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono text-xs flex items-center justify-center font-bold">G</span>
                <h4 className="text-xs font-black uppercase text-slate-800 font-mono mt-2">Fase G: Governança</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Saneamento e controle operacional do setup nas baias de prioridade.
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-6"); }}
                  className="text-[9px] text-slate-500 font-mono font-bold mt-3 block"
                >
                  Monitorar Governança ➔
                </button>
              </div>

              <div className="p-4 bg-[#FAF9F6] border border-emerald-300 text-left shadow-2xs">
                <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-mono text-xs flex items-center justify-center font-bold">H</span>
                <h4 className="text-xs font-black uppercase text-emerald-800 font-mono mt-2">Fase H: Mudança</h4>
                <p className="text-[10.5px] text-slate-600 mt-1 leading-snug">
                  Gestão contínua com ciclos LSS DMAIC, mantendo controle estatístico (CEP).
                </p>
                <button 
                  onClick={() => { setSelectedNodeId("phase-6"); }}
                  className="text-[9px] text-[#047857] font-mono font-bold mt-3 block"
                >
                  Ver Matriz de Establidade ➔
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* VIEWPORT 4: BIZBOK METHODOLOGY MAP */}
      {activeTabPanel === "BIZBOK_MAP" && (
        <div className="space-y-6 text-left animate-fade-in">
          <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3 mb-4 flex-wrap gap-2">
              <div>
                <h3 className="text-lg font-serif font-bold text-slate-900 uppercase leading-none">
                  BIZBOK® Guide Blueprints
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-normal">
                  Foco na representação robusta das dimensões essenciais para governança do negócio.
                </p>
              </div>
              <span className="text-[10px] bg-slate-100 text-slate-600 font-mono border px-2 py-0.5 rounded-none font-bold">
                Arquitetura de Capacidades Integrada
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* Radar charts of BIZBOK framework domain status */}
              <div className="lg:col-span-5 border border-slate-200 p-4 bg-slate-50/50 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 mb-2">Maturidade de Alinhamento das Dimensões BIZBOK</h4>
                  <p className="text-[11px] text-slate-500 leading-snug mb-4">
                    De acordo com as configurações do cenário ({activeTemplateId === "manufacturing-pcb" ? "CORES" : "SERVIÇOS"}), 
                    estimamos a maturidade estratégica atual versus ideal de negócio.
                  </p>
                </div>

                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="75%" data={getRadarMaturityData()}>
                      <PolarGrid stroke="#e2e8f0" />
                      <PolarAngleAxis dataKey="subject" tick={{ fontSize: 9, fill: "#334155" }} />
                      <PolarRadiusAxis angle={30} domain={[0, 5]} tick={{ fontSize: 8 }} />
                      <Radar name="Ideal BIZBOK" dataKey="A" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.10} />
                      <Radar name="Atual Estimado" dataKey="B" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.20} />
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: 9 }} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-amber-50 border border-amber-200 p-2.5 text-[10px] text-amber-900 leading-snug font-mono text-left mt-3">
                  💡 <strong>Capacidades táticas:</strong> O gargalo produtivo restringe o valor real (Value Stream). 
                  Subir o yield operacional de {stats.bottleneckStepName} eleva o compliance do fluxo de valor global.
                </div>
              </div>

              {/* Hierarchical blocks mapping for BIZBOK domains */}
              <div className="lg:col-span-7 space-y-4">
                
                <div className="border border-slate-200 p-4 bg-white">
                  <h5 className="text-xs font-mono font-bold uppercase text-slate-800 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-indigo-600 block"></span>
                    1. Domínio de Capacidades ("What we do")
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                    Habilidades fundamentais do negócio. Mapeado no sistema como áreas de Suporte (Controladoria, Redes, RH, Legal e P&amp;D) versus áreas operacionais.
                  </p>
                  
                  <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Finanças &amp; FP&amp;A</span>
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Tecnologia &amp; REDE</span>
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Cultura &amp; Belts</span>
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Compliance</span>
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Entradas Core</span>
                    <span className="p-1 px-2 border text-[9px] text-slate-700 font-mono uppercase bg-slate-50">Atividade Execução</span>
                  </div>
                </div>

                <div className="border border-slate-200 p-4 bg-white">
                  <h5 className="text-xs font-mono font-bold uppercase text-slate-800 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-600 block"></span>
                    2. Domínio de Fluxos de Valor ("Value Streams")
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                    Conexão de ponta a ponta que realiza valor ao cliente final. O gargalo limitador de vazão determina a velocidade real de faturamento e o lead time global de {stats.leadTime.toFixed(1)} segundos.
                  </p>
                  
                  {/* Real visual pipeline of value streams */}
                  <div className="mt-3 flex items-center gap-1 overflow-x-auto pb-1 text-[9px] font-mono select-none">
                    <span className="p-1 px-1.5 border bg-slate-900 text-white shrink-0 uppercase">RECEPÇÃO</span>
                    <span className="text-slate-400">➔</span>
                    <span className="p-1 px-1.5 border bg-amber-500 text-slate-900 shrink-0 uppercase font-black">GARGALO</span>
                    <span className="text-slate-400">➔</span>
                    <span className="p-1 px-1.5 border bg-slate-900 text-white shrink-0 uppercase">REVISÃO</span>
                    <span className="text-slate-400">➔</span>
                    <span className="p-1 px-1.5 border bg-slate-950 text-white shrink-0 uppercase">FATURADO</span>
                  </div>
                </div>

                <div className="border border-slate-200 p-4 bg-white">
                  <h5 className="text-xs font-mono font-bold uppercase text-slate-800 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 block"></span>
                    3. Domínio de Informações e Objetos
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                    Vocabulário operacional inteligível de negócio. No seu cockpit, o tratamento cadastral estruturado de dados de pedidos de peças garante que logs de faturamento entrem de forma consolidada, reduzindo causas comuns de variação.
                  </p>
                </div>

              </div>

            </div>
          </div>
        </div>
      )}

      {/* VIEWPORT 5: INTERACTIVE DRILL DOWN RELATIONSHIPS NAVIGATOR */}
      {activeTabPanel === "DRILLDOWN_NAV" && (
        <div className="space-y-6 text-left animate-fade-in text-slate-900">
          <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-slate-200 pb-4 mb-6 gap-4">
              <div>
                <span className="text-[9px] bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 font-bold tracking-widest uppercase">
                  Navegação de Rastreamento (End-to-End Traceability)
                </span>
                <h3 className="text-xl font-serif font-black uppercase text-slate-900 mt-1 flex items-center gap-2">
                  <span>🔍 Carrossel de Drill Down de Relações</span>
                  <span className="text-xs bg-slate-100 text-slate-600 border border-slate-200 uppercase px-1 font-mono tracking-tighter">BIZBOK ⬌ TOGAF ADM</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-normal max-w-2xl">
                  Selecione um Objetivo Estratégico (BIZBOK Core) para descer aos Processos de Negócio associados (TOGAF Fase B) e suas Sub-atividades táticas de baia, mapeando as conexões físicas e servidores de persistência (TOGAF Fases C/D).
                </p>
              </div>

              {/* Toggle Methodology Filter directly inside visualizer */}
              <div className="flex border-2 border-slate-900 bg-slate-100 p-1 rounded-none shrink-0 font-mono">
                {(["ALL", "BIZBOK", "TOGAF"] as const).map((method) => (
                  <button
                    key={method}
                    onClick={() => {
                      setSelectedMethodology(method);
                      setDrillImpactResult(null);
                    }}
                    className={`px-3 py-1 font-mono text-[9px] font-extrabold uppercase cursor-pointer transition-all duration-100 ${
                      selectedMethodology === method
                        ? "bg-slate-900 text-white"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {method === "ALL" ? "🔮 Unificado" : method === "BIZBOK" ? "📐 BIZBOK" : "🌍 TOGAF"}
                  </button>
                ))}
              </div>
            </div>

            {/* Breadcrumb Path Map showing trace dynamic */}
            <div className="bg-slate-900 text-white p-3 mb-6 flex flex-wrap items-center gap-2 text-xs font-mono shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] border-2 border-slate-905">
              <span className="text-amber-400 font-bold uppercase text-[9px]">Caminho Ativo:</span>
              <span className="bg-slate-800 text-white px-2 py-0.5 rounded-none border border-slate-700 text-[10px] truncate max-w-xs">
                🎯 {customObjectives.find(o => o.id === (selectedDrillObjectiveId || customObjectives[0]?.id))?.title || "Selecione Meta"}
              </span>
              <span className="text-slate-500 font-black">❯</span>
              <span className="bg-indigo-900 text-indigo-100 px-2 py-0.5 rounded-none text-[10px]">
                ⚙️ {customProcesses.find(p => p.id === (selectedDrillProcessId || relationships.find(r => r.objectiveId === (selectedDrillObjectiveId || customObjectives[0]?.id))?.processId))?.name || "Nenhum Processo Ativo"}
              </span>
              <span className="text-slate-500 font-black">❯</span>
              <span className="bg-[#10B981] text-white px-2 py-0.5 rounded-none text-[10px]">
                📋 Sub-atividade
              </span>
              <span className="text-slate-500 font-black">❯</span>
              <span className="bg-purple-900 text-purple-100 px-2 py-0.5 rounded-none text-[10px] truncate max-w-xs">
                💾 Recurso: {customResources.find(r => r.id === relationships.find(r => r.objectiveId === (selectedDrillObjectiveId || customObjectives[0]?.id) && r.processId === (selectedDrillProcessId || relationships.find(re => re.objectiveId === (selectedDrillObjectiveId || customObjectives[0]?.id))?.processId))?.resourceId)?.name || "Nenhum Recurso Ativo"}
              </span>
            </div>

            {/* THREE-COLUMN EXPANSION CASCADE GRID */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* INTERACTIVE COLUMN 1: OBJECTIVES SELECTOR (BIZBOK Strategy Domain) */}
              <div className="lg:col-span-4 border border-slate-200 bg-slate-50/50 p-4">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span>
                    1. Objetivos Estratégicos
                  </h4>
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-mono font-bold px-1.5 uppercase rounded-none">BIZBOK Strategy</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-normal mb-3">
                  Selecione um dos objetivos definidos no portfólio da governança. Isto determina o ponto de partida do fluxo de valor.
                </p>

                <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                  {customObjectives
                    .filter(obj => selectedMethodology === "ALL" || !obj.framework || obj.framework === "AMBOS" || obj.framework === selectedMethodology)
                    .map((obj) => {
                      const isSelected = (selectedDrillObjectiveId || customObjectives[0]?.id) === obj.id;
                      
                      // Count connected processes
                      const connectedRels = relationships.filter(r => r.objectiveId === obj.id);
                      
                      return (
                        <div
                          key={obj.id}
                          onClick={() => {
                            setSelectedDrillObjectiveId(obj.id);
                            // Auto-select first associated process to drill down immediately
                            const firstProcId = connectedRels[0]?.processId || null;
                            setSelectedDrillProcessId(firstProcId);
                            setDrillImpactResult(null);
                          }}
                          className={`p-3 border-2 transition duration-150 cursor-pointer text-left relative hover:translate-y-[-1px] ${
                            isSelected
                              ? "bg-white border-[#C49746] shadow-[3px_3px_0px_rgba(196,151,70,0.15)]"
                              : "bg-white border-slate-200 hover:border-slate-400"
                          }`}
                        >
                          {isSelected && (
                            <div className="absolute right-0 top-0 bottom-0 w-1.5 bg-[#C49746]" />
                          )}
                          <div className="flex flex-wrap gap-1.5 items-center">
                            <span className={`text-[8px] font-mono font-bold px-1 py-0.2 rounded uppercase ${
                              obj.strategyType === "QUALIDADE" ? "bg-emerald-100 text-emerald-950" :
                              obj.strategyType === "EFICIENCIA" ? "bg-indigo-100 text-indigo-955" :
                              obj.strategyType === "TEMPO" ? "bg-amber-100 text-amber-955" : "bg-slate-100 text-slate-900"
                            }`}>
                              {obj.strategyType} • Meta: {obj.metricTarget}
                            </span>
                            {obj.framework && (
                              <span className="text-[7.5px] font-mono font-bold px-1 py-0.2 rounded bg-slate-900 text-white uppercase leading-none">
                                {obj.framework}
                              </span>
                            )}
                          </div>
                          <h5 className="text-[12px] font-bold text-slate-900 mt-2">{obj.title}</h5>
                          <p className="text-[10.5px] text-slate-500 mt-1 leading-snug line-clamp-2">
                            {obj.description}
                          </p>
                          <div className="mt-2.5 pt-2 border-t border-slate-100 flex justify-between items-center text-[9px] font-mono text-slate-400">
                            <span>Relacionados: {connectedRels.length} Processos</span>
                            {isSelected && <span className="text-[#C49746] font-bold">Ativo ✔</span>}
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* INTERACTIVE COLUMN 2: ASSOCIATED PROCESSES & SUB-ACTIVITIES (TOGAF Business Domain) */}
              <div className="lg:col-span-4 border border-slate-200 bg-slate-50/50 p-4">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 block animate-pulse"></span>
                    2. Processos de Negócio
                  </h4>
                  <span className="text-[10px] bg-indigo-100 text-indigo-800 font-mono font-bold px-1.5 uppercase rounded-none">TOGAF Phase B</span>
                </div>
                
                {(() => {
                  const activeObjId = selectedDrillObjectiveId || customObjectives[0]?.id;
                  const connectedRels = relationships.filter(r => r.objectiveId === activeObjId);
                  
                  if (!activeObjId) {
                    return (
                      <div className="p-6 bg-white border border-dashed border-slate-300 rounded text-center text-xs text-slate-400 font-mono font-bold uppercase">
                        Selecione um objetivo estratégico primeiro.
                      </div>
                    );
                  }

                  if (connectedRels.length === 0) {
                    return (
                      <div className="p-6 bg-white border border-dashed border-slate-300 rounded text-center text-xs text-slate-500 font-sans space-y-3">
                        <p>Nenhum processo mapeado para esta diretiva estrategista.</p>
                        <button
                          onClick={() => {
                            setActiveTabPanel("BLUEPRINT_BUILDER");
                            setShowAddRelationalModal(true);
                            setSelectedObjectiveIdRel(activeObjId);
                          }}
                          className="bg-slate-900 text-white font-mono text-[9px] px-2 py-1 font-bold uppercase hover:bg-slate-800"
                        >
                          🔗 Criar Conexão Rápida
                        </button>
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-4">
                      <p className="text-[11px] text-slate-500 leading-normal font-medium">
                        Processos associados via matriz de arquitetura. Clique em um para detalhar as sub-atividades de baia operacionais correspondentes.
                      </p>

                      <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                        {connectedRels.map((rel) => {
                          const proc = customProcesses.find(p => p.id === rel.processId);
                          if (!proc) return null;
                          const isProcSelected = (selectedDrillProcessId || connectedRels[0]?.processId) === proc.id;
                          
                          // Look up step in real-time execution steps prop to extract actual variables
                          const linkedRealStep = steps.find(s => s.id === proc.associatedStepId);

                          return (
                            <div key={proc.id} className="space-y-2">
                              {/* Process Card Selector */}
                              <div
                                onClick={() => {
                                  setSelectedDrillProcessId(proc.id);
                                  setDrillImpactResult(null);
                                }}
                                className={`p-3 border-2 transition duration-150 cursor-pointer text-left relative ${
                                  isProcSelected
                                    ? "bg-white border-indigo-600 shadow-[3px_3px_0px_rgba(79,70,229,0.15)]"
                                    : "bg-white border-slate-200 hover:border-slate-400"
                                }`}
                              >
                                {isProcSelected && (
                                  <div className="absolute right-0 top-0 bottom-0 w-1.5 bg-indigo-600" />
                                )}
                                <div className="flex flex-wrap justify-between items-center gap-1">
                                  <span className="text-[8.5px] font-mono text-indigo-700 font-extrabold uppercase">
                                    WS: {proc.suggestedWorkspace}
                                  </span>
                                  {proc.framework && (
                                    <span className="text-[7.5px] font-mono font-bold bg-slate-900 text-white px-1 uppercase leading-none text-[6.5px]">
                                      {proc.framework}
                                    </span>
                                  )}
                                </div>
                                <h5 className="text-[12px] font-bold text-slate-905 mt-1">{proc.name}</h5>
                                <div className="text-[10px] mt-1.5 text-slate-500 font-mono space-y-0.5">
                                  <div>Dono: <span className="font-sans font-bold text-slate-700">{proc.owner}</span></div>
                                  {linkedRealStep && (
                                    <div className="flex justify-between items-center border-t border-slate-100 pt-1 mt-1 text-[9px] text-[#047857] font-bold">
                                      <span>Yield (FPY): {linkedRealStep.yieldRate}%</span>
                                      <span>Tempo: {linkedRealStep.processingTime}s</span>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* NESTED DRILL DOWN SUB-ACTIVITIES */}
                              {isProcSelected && (
                                <div className="ml-4 border-l-2 border-indigo-600 pl-3 py-1 space-y-2 animate-fade-in text-left">
                                  <div className="text-[9px] font-mono text-indigo-750 font-bold uppercase tracking-wider flex items-center justify-between">
                                    <span>📋 SUB-ATIVIDADES TÁTICAS</span>
                                  </div>
                                  
                                  {[
                                    { sId: "sub-1", title: "Verificação e Calibragem de Posto", time: "25% Ciclo", role: "Operador de Posto", desc: "Inspeção tátil dos lotes de faturamento físico de acordo com diretrizes de conformidade do pipeline de valor." },
                                    { sId: "sub-2", title: "Controle de Coerência Estatística & CEP", time: "45% Ciclo", role: "Champion Black Belt", desc: "Monitoramento das cartas de controle estatístico LSS imediatas para erradicação de causas comuns e especiais." },
                                    { sId: "sub-3", title: "Faturamento e Sincronismo no Core", time: "30% Ciclo", role: "Coordenador de Célula", desc: "Sincronização cadastral segura diretamente em banco de logs locais criptografados BIZBOK/TOGAF compliant." }
                                  ].map((sub) => {
                                    const combinedSubId = `${proc.id}-${sub.sId}`;
                                    const isSubSelected = selectedDrillSubActivityId === combinedSubId;
                                    return (
                                      <div
                                        key={sub.sId}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setSelectedDrillSubActivityId(isSubSelected ? null : combinedSubId);
                                        }}
                                        className={`p-2 border transition text-[11px] cursor-pointer text-left ${
                                          isSubSelected
                                            ? "bg-indigo-50 border-[#10B981] text-slate-905"
                                            : "bg-white border-slate-200 hover:bg-slate-50"
                                        }`}
                                      >
                                        <div className="flex justify-between items-center font-mono text-[9px] font-bold text-slate-400">
                                          <span>{sub.role}</span>
                                          <span className="text-[#10B981]">{sub.time}</span>
                                        </div>
                                        <div className="font-bold text-slate-800 mt-0.5">{sub.title}</div>
                                        {isSubSelected && (
                                          <p className="text-[10px] text-slate-500 mt-1 font-sans leading-relaxed animate-fade-in">
                                            {sub.desc}
                                          </p>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* INTERACTIVE COLUMN 3: SYSTEM RESOURCES & TRACEABILITY NOTES (TOGAF Technology/Infrastructure Domains) */}
              <div className="lg:col-span-4 border border-slate-200 bg-slate-50/50 p-4 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-purple-600 block animate-pulse"></span>
                      3. Recursos de Infraestrutura e TI
                    </h4>
                    <span className="text-[10px] bg-purple-100 text-purple-800 font-mono font-bold px-1.5 uppercase rounded-none">TOGAF Phase C/D</span>
                  </div>

                  {(() => {
                    const activeObjId = selectedDrillObjectiveId || customObjectives[0]?.id;
                    const activeProcId = selectedDrillProcessId || relationships.find(r => r.objectiveId === activeObjId)?.processId;
                    
                    const matchedRel = relationships.find(r => r.objectiveId === activeObjId && r.processId === activeProcId);
                    
                    if (!matchedRel) {
                      return (
                        <div className="p-6 bg-white border border-dashed border-slate-300 rounded text-center text-xs text-slate-400 font-mono">
                          Nenhum recurso mapeado para esta conexão ativa. Selecione um processo ao lado para vincular seu recurso correspondente.
                        </div>
                      );
                    }

                    const res = customResources.find(r => r.id === matchedRel.resourceId);
                    if (!res) return null;

                    return (
                      <div className="space-y-4 text-left">
                        <p className="text-[11px] text-slate-500 leading-normal">
                          Detalhamento do recurso arquitetado necessário para dar suporte tecnológico ou humano ao processo corporativo.
                        </p>

                        <div className="p-3.5 bg-white border-2 border-purple-600 relative">
                          <div className="flex justify-between items-center gap-2 mb-1.5">
                            <span className="text-[8px] font-mono bg-purple-100 text-purple-900 px-1.5 py-0.2 rounded font-bold uppercase leading-none">
                              {res.type}
                            </span>
                            {res.framework && (
                              <span className="text-[7.5px] font-mono font-bold bg-slate-900 text-white px-1 uppercase leading-none text-[7.5px]">
                                {res.framework}
                              </span>
                            )}
                          </div>
                          
                          <h5 className="text-[13px] font-bold text-slate-905 mt-1">{res.name}</h5>
                          <p className="text-[10.5px] text-slate-600 mt-1 font-mono leading-snug">
                            {res.capacityInfo}
                          </p>

                          {/* Dynamic resource specific detail badge */}
                          <div className="mt-4 pt-3 border-t border-slate-100 text-[10.5px] text-slate-500 space-y-1 bg-slate-50 p-2 border">
                            <div className="flex justify-between font-mono">
                              <span>Mapeamento:</span>
                              <strong className="text-slate-800">TOGAF ADM</strong>
                            </div>
                            <div className="flex justify-between font-mono">
                              <span>Infraestrutura:</span>
                              <strong className="text-slate-800">{res.type === "TECNOLOGICO" ? "Inter-regional Cloud" : "Alocação Dedicada LSS"}</strong>
                            </div>
                            <div className="flex justify-between font-mono">
                              <span>Capacidade Síncrona:</span>
                              <strong className="text-emerald-800">Adequada</strong>
                            </div>
                          </div>
                        </div>

                        {/* Rationale and Traceability description matching exact framework integrity */}
                        <div className="bg-amber-50 border border-amber-300 p-3.5 rounded-none text-left">
                          <span className="text-[8px] font-mono tracking-widest text-[#C49746] font-bold uppercase block mb-1">
                            Rastreabilidade Estrita BIZBOK ⬌ TOGAF
                          </span>
                          <p className="text-[10.5px] text-amber-955 font-sans leading-relaxed">
                            <strong>Nota de Coerência:</strong> {matchedRel.integrationNote || "Alinhamento sistêmico de processos e metas no cockpit LSS."}
                          </p>
                          <div className="text-[9.5px] text-slate-500 font-mono mt-2 leading-tight">
                            *Esta relação preserva a rastreabilidade ligando a intenção de mercado da diretiva empresarial BIZBOK (Camada de Governança Estratégica) com o servidor de persistência de log estocástico da Fase C/D do TOGAF ADM.
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* DYNAMIC METRICS SIMULATION REPORT WIDGET */}
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="bg-slate-900 text-white p-3.5 text-left">
                    <h5 className="text-[11px] font-mono font-bold text-white uppercase flex items-center justify-between">
                      <span>⚡ Simulador de Impacto Tático</span>
                      <span className="text-[8px] bg-[#C49746] px-1 text-white uppercase font-black tracking-widest">REAL TIME</span>
                    </h5>
                    <p className="text-[10.5px] text-slate-400 mt-1 leading-normal">
                      Clique abaixo para simular o impacto de elevar a maturidade deste objetivo estratégico nas métricas de produção reais do processo.
                    </p>

                    <button
                      onClick={() => {
                        const activeObjId = selectedDrillObjectiveId || customObjectives[0]?.id;
                        const activeObj = customObjectives.find(o => o.id === activeObjId);
                        
                        let benefit = 12;
                        let desc = "";
                        let metrics: string[] = [];

                        if (activeObj?.strategyType === "QUALIDADE") {
                          benefit = 15;
                          desc = "Elevando a qualidade de inspeção BIZBOK, o yield do primeiro estágio e o Rolled First Pass Yield aumentam com menos desperdício.";
                          metrics = ["Sigma Level: " + (stats.sigmaLevel + 0.35).toFixed(2) + " σ", "Rolled Yield: " + ((stats.rolledFirstPassYield * 1.15) * 100).toFixed(1) + "%"];
                        } else if (activeObj?.strategyType === "EFICIENCIA") {
                          benefit = 20;
                          desc = "Eliminação de desperdício tático baseada na análise de gargalo, reduzindo a utilização saturada de infraestrutura tática.";
                          metrics = ["Saturação máxima: < 75%", "Vazão Máxima: " + (stats.systemCapacity * 1.12).toFixed(1) + " un/hora"];
                        } else if (activeObj?.strategyType === "TEMPO") {
                          benefit = 18;
                          desc = "Otimização de tempo de fluxo e setup das baias operacionais. Encurtamento de percurso no layout modular.";
                          metrics = ["Lead Time: " + (stats.leadTime * 0.82).toFixed(1) + " segundos", "Tempo de resposta TI: < 2.0s"];
                        } else {
                          benefit = 10;
                          desc = "Crescimento sustentado e expansão redundante de servidores para redundância alta e resiliência governamental.";
                          metrics = ["Redundância Cloud: +2 Nodes Actives", "Diferencial de Retorno: Alto"];
                        }

                        setDrillImpactResult({
                          simulated: true,
                          benefitPercent: benefit,
                          description: desc,
                          metricsAffected: metrics
                        });
                      }}
                      className="mt-3 w-full bg-amber-500 hover:bg-amber-600 text-slate-900 font-mono text-[9.5px] font-bold py-1.5 px-3 uppercase tracking-wider text-center cursor-pointer"
                    >
                      🚀 RODAR SIMULAÇÃO MÁXIMA DE COMPLIANCE
                    </button>

                    {drillImpactResult?.simulated && (
                      <div className="mt-3 bg-white text-slate-905 p-2.5 border-l-4 border-amber-500 animate-slide-up text-left">
                        <div className="text-[9px] font-mono uppercase font-black text-[#C49746]">
                          ✓ Prognóstico de Impacto: +{drillImpactResult.benefitPercent}% Otimização
                        </div>
                        <p className="text-[10px] text-slate-705 mt-1 leading-snug">
                          {drillImpactResult.description}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {drillImpactResult.metricsAffected.map((metric, idx) => (
                            <span key={idx} className="bg-slate-900 text-[#FAF9F6] text-[8.5px] font-mono px-1.5 py-0.5 rounded-none">
                              {metric}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            </div>

            {/* Quick drill down action helper bridge directly to standard workspaces */}
            <div className="mt-6 border-t border-slate-200 pt-5 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50 p-4 border">
              <div className="text-left">
                <span className="text-[10px] font-bold text-indigo-700 font-mono block">NÃO-MOCKADO E DRILL DOWN INSTANTÂNEO</span>
                <p className="text-[11px] text-slate-500 mt-0.5 max-w-xl leading-normal">
                  Utilize os canais de transição de arquitetura integrados para simular mudanças ou pular diretamente para a baia de execução e testar o funcionamento em tempo real desta parametrização.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    const activeObjId = selectedDrillObjectiveId || customObjectives[0]?.id;
                    const rel = relationships.find(r => r.objectiveId === activeObjId);
                    const proc = customProcesses.find(p => p.id === rel?.processId);
                    if (proc && onNavigateToView) {
                      onNavigateToView(proc.suggestedWorkspace);
                    } else if (onNavigateToView) {
                      onNavigateToView("MAP");
                    }
                  }}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-mono text-[10px] font-bold py-2 px-4 shadow-[2px_2px_0px_rgba(0,0,0,1)] uppercase cursor-pointer"
                >
                  🚀 Navegar para Área Ativa
                </button>
                
                <button
                  onClick={() => {
                    if (onNavigateToView) onNavigateToView("DIAGNOSTIC");
                  }}
                  className="bg-white hover:bg-slate-50 text-slate-800 border font-mono text-[10px] font-bold py-2 px-3 uppercase cursor-pointer"
                >
                  Configuração Geral
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* VIEWPORT 6: GESTÃO DE MUDANÇAS & CONTROLE DE ALTERAÇÕES */}
      {activeTabPanel === "CHANGE_MANAGEMENT" && (
        <div className="space-y-6 text-left animate-fade-in text-slate-900">
          <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-slate-200 pb-4 mb-6 gap-4">
              <div>
                <span className="text-[9px] bg-emerald-100 text-emerald-900 border border-emerald-300 px-2 py-0.5 font-bold tracking-widest uppercase">
                  Gestão de Mudanças de Processos (TOGAF Fase H: Architecture Change Management)
                </span>
                <h3 className="text-xl font-serif font-black uppercase text-slate-900 mt-1 flex items-center gap-2">
                  <span>🚧 Controle de Alterações &amp; Alinhamento Estratégico</span>
                  <span className="text-xs bg-slate-100 text-slate-600 border border-slate-200 uppercase px-1 font-mono tracking-tighter">OKR Aligned</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-normal max-w-2xl">
                  Gerencie as solicitações de mudança em todo o fluxo de valor, associando cada ajuste técnico a um Objetivo Estratégico (OKR) corporativo e mensurando o impacto esperado na organização.
                </p>
              </div>

              {/* Status Counters */}
              <div className="flex gap-2 flex-wrap text-left">
                <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 min-w-[70px]">
                  <span className="text-[8px] font-mono uppercase text-emerald-600 block leading-none mb-0.5">Total</span>
                  <strong className="text-sm font-bold text-slate-900">{customChanges.length}</strong>
                </div>
                <div className="bg-rose-50 border border-rose-200 px-3 py-1.5 min-w-[70px]">
                  <span className="text-[8px] font-mono uppercase text-rose-600 block leading-none mb-0.5 font-bold">Alto Impacto</span>
                  <strong className="text-sm font-bold text-rose-800 font-mono">
                    {customChanges.filter(c => c.impactLevel === "ALTO").length}
                  </strong>
                </div>
                <div className="bg-indigo-50 border border-indigo-200 px-3 py-1.5 min-w-[70px]">
                  <span className="text-[8px] font-mono uppercase text-indigo-600 block leading-none mb-0.5 font-bold">Executadas</span>
                  <strong className="text-sm font-bold text-indigo-800 font-mono">
                    {customChanges.filter(c => c.status === "EXECUTADA").length}
                  </strong>
                </div>
              </div>
            </div>

            {/* Global Notification Toast */}
            {notification.show && (
              <div className="mb-4 p-3 bg-slate-900 border-2 border-slate-900 text-white shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex justify-between items-center text-xs font-mono animate-fade-in">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">✔️</span>
                  <span>{notification.message}</span>
                </div>
                <button 
                  onClick={() => setNotification({ show: false, message: "", type: "SUCCESS" })}
                  className="hover:underline font-bold font-mono pl-3 text-[#C49746] cursor-pointer"
                >
                  [fechar]
                </button>
              </div>
            )}

            {/* SubTab Navigation */}
            <div className="flex border-b border-slate-200 mb-6 gap-2 flex-wrap sm:flex-nowrap">
              <button
                onClick={() => setSubTab("CHANGES_LIST")}
                className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                  subTab === "CHANGES_LIST"
                    ? "border-[#047857] text-[#047857] bg-emerald-55/40"
                    : "border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                📋 Quadro de Alterações (RFC &amp; OKR)
              </button>
              <button
                onClick={() => setSubTab("FIVE_WHYS_ANALYSIS")}
                className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                  subTab === "FIVE_WHYS_ANALYSIS"
                    ? "border-[#C49746] text-[#C49746] bg-amber-50/20"
                    : "border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                🎯 Ferramenta '5 Porquês' (Causa Raiz)
              </button>
            </div>

            {subTab === "CHANGES_LIST" ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* LEFT COLUMN: ADD NEW CHANGE FORM */}
              <div className="lg:col-span-5 border border-slate-200 bg-slate-50/50 p-4">
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 border-b pb-2 mb-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 block"></span>
                  Nova Solicitação de Mudança (RFC)
                </h4>

                <form onSubmit={(e) => {
                  e.preventDefault();
                  if (!newChgTitle.trim() || !newChgExpectedImpact.trim()) return;

                  const newChange: EnterpriseChange = {
                    id: `chg-${Date.now()}`,
                    title: newChgTitle.trim(),
                    description: newChgDescription.trim() || "Nenhuma descrição detalhada provida.",
                    objectiveId: newChgObjectiveId || (customObjectives[0]?.id || "obj-1"),
                    keyResultId: newChgKeyResultId || undefined,
                    expectedImpact: newChgExpectedImpact.trim(),
                    impactLevel: newChgImpactLevel,
                    status: newChgStatus,
                    responsible: newChgResponsible.trim() || "Responsável não designado",
                    date: newChgDate || "2026-06-11"
                  };

                  setCustomChanges(prev => [newChange, ...prev]);
                  
                  // Reset form fields
                  setNewChgTitle("");
                  setNewChgDescription("");
                  setNewChgObjectiveId("");
                  setNewChgKeyResultId("");
                  setNewChgExpectedImpact("");
                  setNewChgResponsible("");
                }} className="space-y-4">
                  
                  <div>
                    <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Título da Alteração *</label>
                    <input
                      type="text"
                      required
                      value={newChgTitle}
                      onChange={(e) => setNewChgTitle(e.target.value)}
                      placeholder="Ex: Refatorar gargalo de soldagem..."
                      className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Descrição Detalhada / Escopo</label>
                    <textarea
                      value={newChgDescription}
                      onChange={(e) => setNewChgDescription(e.target.value)}
                      placeholder="Detalhes sobre a mudança física..."
                      rows={2}
                      className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-[#C49746] mb-0.5 uppercase">🎯 Vincular ao OKR Estratégico *</label>
                      <select
                        value={newChgObjectiveId}
                        onChange={(e) => {
                          setNewChgObjectiveId(e.target.value);
                          setNewChgKeyResultId("");
                        }}
                        className="w-full bg-white border border-slate-300 px-2 py-1.5 text-[10.5px] text-slate-900 focus:outline-none focus:border-[#C49746] rounded-none font-sans"
                      >
                        <option value="">-- Selecione OKR --</option>
                        {customObjectives.map(o => (
                          <option key={o.id} value={o.id}>
                            [{o.strategyType}] {o.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono font-bold text-teal-600 mb-0.5 uppercase">🎯 Resultado Chave (KR)</label>
                      <select
                        value={newChgKeyResultId}
                        onChange={(e) => setNewChgKeyResultId(e.target.value)}
                        disabled={!newChgObjectiveId}
                        className="w-full bg-white border border-slate-300 px-2 py-1.5 text-[10.5px] text-slate-900 focus:outline-none focus:border-teal-600 rounded-none font-sans disabled:bg-slate-100 disabled:text-slate-400"
                      >
                        <option value="">-- Selecione Resultado Chave (Opcional) --</option>
                        {customKeyResults
                          .filter(kr => kr.objectiveId === newChgObjectiveId)
                          .map(kr => (
                            <option key={kr.id} value={kr.id}>
                              {kr.title} ({kr.progress}%)
                            </option>
                          ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Nível de Impacto no Negócio</label>
                      <select
                        value={newChgImpactLevel}
                        onChange={(e) => setNewChgImpactLevel(e.target.value as any)}
                        className="w-full bg-white border border-slate-300 px-2 py-1.5 text-[10.5px] text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      >
                        <option value="ALTO">📌 Alto Impacto</option>
                        <option value="MEDIO">⚡ Médio Impacto</option>
                        <option value="BAIXO">🌱 Baixo Impacto</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono font-bold text-indigo-700 mb-0.5 uppercase">⚡ Impacto Esperado *</label>
                    <input
                      type="text"
                      required
                      value={newChgExpectedImpact}
                      onChange={(e) => setNewChgExpectedImpact(e.target.value)}
                      placeholder="Ex: Elevação de 15% no FPY e menor Lead time"
                      className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans font-bold"
                    />
                    <p className="text-[9px] text-slate-400 mt-1 leading-snug">
                      Defina claramente o benefício ou métrica LSS que essa alteração visa atingir.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Responsável (Black Belt)</label>
                      <input
                        type="text"
                        value={newChgResponsible}
                        onChange={(e) => setNewChgResponsible(e.target.value)}
                        placeholder="Ex: João M. (Engenheiro)"
                        className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      />
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Status da RFC</label>
                      <select
                        value={newChgStatus}
                        onChange={(e) => setNewChgStatus(e.target.value as any)}
                        className="w-full bg-white border border-slate-300 px-2 py-1.5 text-[10.5px] text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-sans"
                      >
                        <option value="PROPOSTA">PROPOSTA (Sob análise)</option>
                        <option value="APROVADA">APROVADA (Comitê CCB)</option>
                        <option value="PLANEJAMENTO">PLANEJAMENTO (Desenho)</option>
                        <option value="EXECUTADA">EXECUTADA (Implantada)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono font-bold text-slate-400 mb-0.5 uppercase">Data Limite / Programada</label>
                    <input
                      type="date"
                      value={newChgDate}
                      onChange={(e) => setNewChgDate(e.target.value)}
                      className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900 rounded-none font-mono"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#047857] hover:bg-[#065f46] text-white font-mono text-xs font-bold py-2.5 px-3 uppercase tracking-wider text-center cursor-pointer transition shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex items-center justify-center gap-1 border border-slate-900"
                  >
                    <span>✓ Enviar Solicitação de Mudança</span>
                  </button>

                </form>
              </div>

              {/* RIGHT COLUMN: LIST OF CHANGES / ALTERAÇÕES WITH OKR ENHANCEMENTS */}
              <div className="lg:col-span-7 space-y-4">
                
                <div className="flex justify-between items-center mb-1">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    📋 Matriz de Controle de Mudanças Organizadas ({customChanges.length} Solicitadas)
                  </h4>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono font-bold px-1.5 uppercase rounded-none">CCB Board (Fase H)</span>
                </div>

                <div className="space-y-4 max-h-[640px] overflow-y-auto pr-1">
                  {customChanges.length === 0 ? (
                    <div className="bg-slate-50 border border-dashed border-slate-300 p-8 text-center">
                      <span className="text-slate-400 block font-serif italic mb-1 text-sm">Nenhuma mudança cadastrada no projeto</span>
                      <p className="text-[11px] text-slate-500">Utilize o formulário à esquerda para propor e vincular a primeira alteração de arquitetura baseada no framework OKR.</p>
                    </div>
                  ) : (
                    customChanges.map((chg) => {
                      // Find associated Objective/OKR
                      const linkedOkr = customObjectives.find(o => o.id === chg.objectiveId);
                      const linkedKr = chg.keyResultId ? customKeyResults.find(k => k.id === chg.keyResultId) : null;

                      return (
                        <div key={chg.id} className="bg-white border-2 border-slate-900 hover:border-emerald-600 transition p-4 relative text-left shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]">
                          
                          {/* Badge indicators absolute layout */}
                          <div className="absolute top-4 right-4 flex gap-1.5 items-center">
                            <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.5 uppercase ${
                              chg.impactLevel === "ALTO" 
                                ? "bg-rose-100 text-rose-800 border border-rose-200" 
                                : chg.impactLevel === "MEDIO"
                                ? "bg-amber-100 text-amber-800 border border-amber-200"
                                : "bg-blue-100 text-blue-800 border border-blue-200"
                            }`}>
                              Impacto {chg.impactLevel}
                            </span>
                            
                            <span className={`text-[8.5px] font-mono font-black px-1.5 py-0.5 border uppercase ${
                              chg.status === "EXECUTADA"
                                ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                                : chg.status === "PLANEJAMENTO"
                                ? "bg-indigo-100 text-indigo-800 border-indigo-300"
                                : chg.status === "APROVADA"
                                ? "bg-purple-100 text-purple-800 border-purple-300"
                                : "bg-amber-50 text-amber-700 border-amber-300"
                            }`}>
                              {chg.status}
                            </span>
                          </div>

                          {/* Detail of change */}
                          <div className="max-w-[70%]">
                            <span className="text-[8.5px] font-mono text-slate-400 block tracking-wide">ID: {chg.id.toUpperCase()}</span>
                            <h5 className="text-sm font-bold text-slate-900 mt-0.5 leading-snug">{chg.title}</h5>
                            <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">{chg.description}</p>
                          </div>

                          {/* OKR VINCULATION FIELD (OBJECTIVES AND KEY RESULTS) */}
                          <div className="mt-3.5 border-t border-dashed border-slate-200 pt-3">
                            <div className="bg-[#FAF9F5] border border-[#C49746]/20 p-2.5 rounded-none flex items-start gap-3">
                              <span className="w-6 h-6 bg-[#C49746]/10 text-[#C49746] font-bold text-xs uppercase flex items-center justify-center border border-[#C49746]/15 shrink-0 mt-0.5">
                                🎯
                              </span>
                              <div className="text-left w-full">
                                <span className="text-[8.5px] font-mono text-[#C49746] font-bold tracking-wide block uppercase">
                                  OKR / Objetivo Estratégico Vinculado (Strategic BIZBOK Linkage)
                                </span>
                                {linkedOkr ? (
                                  <>
                                    <strong className="text-xs text-slate-900 block mt-0.5">{linkedOkr.title}</strong>
                                    <span className="text-[10px] text-slate-500 font-mono mt-0.5 block border-b border-slate-100 pb-1.5 mb-1.5">
                                      Métrica Alvo (KPI / Requisito): <strong className="text-indigo-900">{linkedOkr.metricTarget}</strong> | Tipo: {linkedOkr.strategyType}
                                    </span>
                                    {linkedKr && (
                                      <div className="bg-teal-50 border border-teal-200 p-2 text-left">
                                        <div className="flex items-center justify-between gap-2.5">
                                          <span className="text-[8.5px] font-mono text-teal-800 font-bold block uppercase">🎯 Resultado Chave Associado</span>
                                          <span className="text-[9px] font-mono font-bold bg-teal-600 text-white px-1 leading-normal">{linkedKr.progress}%</span>
                                        </div>
                                        <strong className="text-[11px] text-teal-950 block mt-0.5">{linkedKr.title}</strong>
                                        <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1.5 overflow-hidden">
                                          <div className="bg-teal-600 h-full" style={{ width: `${linkedKr.progress}%` }}></div>
                                        </div>
                                      </div>
                                    )}
                                  </>
                                ) : (
                                  <span className="text-xs text-rose-700 font-bold block mt-0.5">⚠️ Nenhum OKR ativo ou objetivo original desvinculado!</span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Expected Impact display section */}
                          <div className="mt-2 text-left bg-emerald-50/50 border border-emerald-300/30 p-2.5 rounded-none flex items-start gap-2.5">
                            <span className="w-5 h-5 bg-emerald-100 text-emerald-850 font-bold text-[9px] uppercase flex items-center justify-center shrink-0 mt-0.5">
                              ⚡
                            </span>
                            <div>
                              <span className="text-[8px] font-mono uppercase text-emerald-700 font-bold block text-left">Impacto Esperado no Negócio (Business Expected Impact)</span>
                              <div className="text-[11px] text-emerald-950 font-black mt-0.5 text-left">{chg.expectedImpact}</div>
                            </div>
                          </div>

                          {/* Footer details (Responsible Person, Date) */}
                          <div className="mt-3.5 flex justify-between items-center text-[10px] font-mono text-slate-500 border-t pt-2 border-slate-100 flex-wrap gap-2">
                            <div>
                              <span>Responsável: </span>
                              <strong className="text-slate-800 font-sans">{chg.responsible}</strong>
                            </div>
                            <div className="flex gap-4">
                              <span>Data programada: <strong>{chg.date}</strong></span>
                              <button
                                onClick={() => {
                                  // Simple deletion hook to manage list
                                  setCustomChanges(prev => prev.filter(p => p.id !== chg.id));
                                }}
                                className="text-red-650 hover:text-red-800 hover:underline font-bold uppercase text-[9px] cursor-pointer"
                              >
                                Excluir RFC
                              </button>
                            </div>
                          </div>

                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            </div>
            ) : (
              <FiveWhysRootCauseModule
                customFiveWhys={customFiveWhys}
                setCustomFiveWhys={setCustomFiveWhys}
                activeFiveWhysId={activeFiveWhysId}
                setActiveFiveWhysId={setActiveFiveWhysId}
                customObjectives={customObjectives}
                handleConvertFiveWhysToChg={handleConvertFiveWhysToChg}
                setNotification={setNotification}
              />
            )}

          </div>
        </div>
      )}

      {/* VIEWPORT 7: OKR DASHBOARD */}
      {activeTabPanel === "OKR_DASHBOARD" && (
        <div className="space-y-6 text-left animate-fade-in text-slate-900">
          <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            
            {/* Header section with fine labels and styling */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-slate-200 pb-4 mb-6 gap-4">
              <div>
                <span className="text-[9px] bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 font-bold tracking-widest uppercase">
                  Gestão Estratégica Baseada em Resultados (BIZBOK Strategic Mapping &amp; TOGAF Fase H)
                </span>
                <h3 className="text-xl font-serif font-black uppercase text-slate-900 mt-1 flex items-center gap-2">
                  <span>🎯 Dashboard de OKRs e Resultados Chave (Strategic Board)</span>
                  <span className="text-xs bg-amber-550/10 text-amber-800 border border-amber-200 px-1 font-mono tracking-tighter">100% Sincronizado</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-normal max-w-2xl">
                  Acompanhe em tempo real o progresso dos Objetivos macro da firma e seus Resultados Chave (Key Results). Conecte e gerencie diretamente as ações operacionais e alterações de arquitetura (Mudanças RFC) a suas respectivas métricas chave.
                </p>
              </div>

              {/* Action and stats buttons */}
              <div className="flex gap-2 flex-wrap text-left">
                <button
                  onClick={() => setShowObjectiveModal(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-mono text-[10px] font-bold py-2 px-3 shadow-[2px_2px_0px_rgba(0,0,0,1)] uppercase cursor-pointer"
                >
                  ➕ Novo Objetivo Macro
                </button>
              </div>
            </div>

            {/* General OKR Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                <span className="text-[9px] font-mono uppercase text-slate-405 block mb-0.5">Total de Objetivos</span>
                <strong className="text-lg font-serif font-black text-slate-900">{customObjectives.length}</strong>
                <span className="text-[8.5px] font-mono text-slate-500 block mt-1">Estratégias Ativas</span>
              </div>
              <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                <span className="text-[9px] font-mono uppercase text-amber-600 block mb-0.5 font-bold">Resultados Chave</span>
                <strong className="text-lg font-serif font-black text-amber-900">{customKeyResults.length}</strong>
                <span className="text-[8.5px] font-mono text-slate-500 block mt-1">KRs Cadastrados</span>
              </div>
              <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                <span className="text-[9px] font-mono uppercase text-emerald-600 block mb-0.5 font-bold">Progresso Global Médio</span>
                <div className="flex items-baseline gap-1.5">
                  <strong className="text-lg font-mono font-bold text-emerald-900">
                    {customKeyResults.length > 0 
                      ? Math.round(customKeyResults.reduce((acc, kr) => acc + kr.progress, 0) / customKeyResults.length) 
                      : 0}%
                  </strong>
                </div>
                <div className="w-full bg-slate-200 h-1 mt-1.5 overflow-hidden">
                  <motion.div 
                    className="bg-emerald-600 h-full" 
                    initial={{ width: 0 }}
                    animate={{ 
                      width: `${customKeyResults.length > 0 
                        ? Math.round(customKeyResults.reduce((acc, kr) => acc + kr.progress, 0) / customKeyResults.length) 
                        : 0}%` 
                    }}
                    transition={{ duration: 1.0, ease: "easeOut" }}
                  />
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                <span className="text-[9px] font-mono uppercase text-teal-650 block mb-0.5 font-bold">Alterações Vinculadas</span>
                <strong className="text-lg font-serif font-black text-teal-900">
                  {customChanges.filter(c => c.keyResultId).length}
                </strong>
                <span className="text-[8.5px] font-mono text-slate-500 block mt-1">RFCs Alinhadas</span>
              </div>
            </div>

            {/* Global Notification Inside OKR Panel */}
            {notification.show && (
              <div className="mb-4 p-3 bg-slate-900 border-2 border-slate-900 text-white shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] flex justify-between items-center text-xs font-mono animate-fade-in">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">✔️</span>
                  <span>{notification.message}</span>
                </div>
                <button 
                  onClick={() => setNotification({ show: false, message: "", type: "SUCCESS" })}
                  className="hover:underline font-bold font-mono pl-3 text-[#C49746] cursor-pointer"
                >
                  [fechar]
                </button>
              </div>
            )}

            {/* Main Interactive Grid */}
            <div className="space-y-6">
              {customObjectives.map(obj => {
                const krs = customKeyResults.filter(kr => kr.objectiveId === obj.id);
                const objProgress = krs.length > 0 ? Math.round(krs.reduce((a, b) => a + b.progress, 0) / krs.length) : 0;

                return (
                  <div key={obj.id} className="border-2 border-slate-900 p-5 bg-white shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] hover:border-amber-500 transition">
                    
                    {/* Objective header details */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-100 pb-3 mb-4 gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2 text-left">
                          <span className="text-[8.5px] font-mono font-bold bg-[#C49746]/10 text-[#C49746] px-1.5 py-0.2 border border-[#C49746]/20 uppercase">
                            OBJETIVO: {obj.id.toUpperCase()}
                          </span>
                          <span className="text-[8.5px] font-mono font-bold bg-slate-100 text-slate-600 px-1.5 py-0.2 border border-slate-200 uppercase">
                            Estrutura: {obj.framework || "BIZBOK / TOGAF"}
                          </span>
                          <span className="text-[8.5px] font-mono font-bold bg-indigo-50 text-indigo-700 px-1.5 py-0.2 border border-indigo-100 uppercase">
                            {obj.strategyType}
                          </span>
                        </div>
                        <h4 className="text-lg font-serif font-black text-slate-900 mt-1.5 text-left">{obj.title}</h4>
                        <p className="text-xs text-slate-500 mt-1 max-w-3xl leading-normal text-left">{obj.description}</p>
                      </div>

                      {/* Visual Progress gauge for this Objective (average of KRs) */}
                      <div className="shrink-0 text-left md:text-right min-w-[150px]">
                        <span className="text-[8.5px] font-mono text-slate-400 block uppercase font-bold">Progresso do Objetivo</span>
                        <div className="flex items-center gap-2 md:justify-end mt-1">
                          <strong className="text-sm font-mono font-black text-slate-900">{objProgress}%</strong>
                          <span className="text-[10px] text-slate-400 font-mono">({krs.length} KRs)</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 mt-1.5 border overflow-hidden">
                          <motion.div 
                            className="bg-amber-550 h-full" 
                            initial={{ width: 0 }}
                            animate={{ width: `${objProgress}%` }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* KEY RESULTS SECTION GRID */}
                    <div className="mt-4">
                      <div className="flex justify-between items-center pb-2 mb-3 border-b border-dashed border-slate-200">
                        <h5 className="text-[10px] font-mono font-black uppercase text-slate-600 tracking-wider">
                          🎯 Resultados Chave Relacionados (KRs - Key Results)
                        </h5>
                        
                        <button
                          onClick={() => {
                            if (addingKrObjectiveId === obj.id) {
                              setAddingKrObjectiveId(null);
                            } else {
                              setAddingKrObjectiveId(obj.id);
                              // setup defaults
                              setNewKrTitle("");
                              setNewKrUnit("%");
                              setNewKrCurrent(0);
                              setNewKrTarget(100);
                              setNewKrProgress(50);
                            }
                          }}
                          className="text-[9.5px] font-mono font-bold text-amber-600 hover:text-amber-800 hover:underline uppercase flex items-center gap-1 cursor-pointer"
                        >
                          {addingKrObjectiveId === obj.id ? "✕ Cancelar" : "➕ Adicionar Resultado Chave (KR)"}
                        </button>
                      </div>

                      {/* Add new KR inline form */}
                      {addingKrObjectiveId === obj.id && (
                        <div className="mb-4 bg-[#FFFDF9] border border-dashed border-amber-300 p-4 animate-fade-in text-slate-900">
                          <h6 className="text-[9.5px] font-mono font-black text-amber-950 uppercase tracking-widest mb-3">
                            Cadastro de Novo Resultado Chave para {obj.title}
                          </h6>
                          <form
                            onSubmit={(e) => {
                              e.preventDefault();
                              if (!newKrTitle.trim()) return;

                              const newKR: KeyResult = {
                                id: `kr-${obj.id}-${Date.now()}`,
                                objectiveId: obj.id,
                                title: newKrTitle.trim(),
                                currentValue: Number(newKrCurrent),
                                targetValue: Number(newKrTarget),
                                unit: newKrUnit,
                                progress: Math.min(100, Math.max(0, Number(newKrProgress)))
                              };

                              setCustomKeyResults(prev => [...prev, newKR]);
                              setAddingKrObjectiveId(null);
                              
                              setNotification({
                                show: true,
                                message: `Resultado Chave "${newKR.title}" adicionado de forma duritária no suite!`,
                                type: "SUCCESS"
                              });
                              setTimeout(() => setNotification({ show: false, message: "", type: "SUCCESS" }), 3500);
                            }}
                            className="space-y-3"
                          >
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                              <div className="md:col-span-6">
                                <label className="block text-[8px] font-mono font-bold uppercase text-slate-400 mb-0.5">Título do Resultado Chave *</label>
                                <input
                                  type="text"
                                  required
                                  value={newKrTitle}
                                  onChange={(e) => setNewKrTitle(e.target.value)}
                                  placeholder="Ex: Reduzir taxa de erro no CLP..."
                                  className="w-full bg-white border border-slate-300 text-xs px-2 py-1.5 focus:outline-none focus:border-amber-500 rounded-none text-slate-900"
                                />
                              </div>
                              <div className="md:col-span-2">
                                <label className="block text-[8px] font-mono font-bold uppercase text-slate-400 mb-0.5">Unidade</label>
                                <input
                                  type="text"
                                  required
                                  value={newKrUnit}
                                  onChange={(e) => setNewKrUnit(e.target.value)}
                                  placeholder="Ex: % ou s ou min"
                                  className="w-full bg-white border border-slate-300 text-xs px-2 py-1.5 focus:outline-none focus:border-amber-500 rounded-none text-center font-mono text-slate-900"
                                />
                              </div>
                              <div className="md:col-span-2">
                                <label className="block text-[8px] font-mono font-bold uppercase text-slate-400 mb-0.5">Valor Atual</label>
                                <input
                                  type="number"
                                  required
                                  value={newKrCurrent}
                                  onChange={(e) => setNewKrCurrent(Number(e.target.value))}
                                  className="w-full bg-white border border-slate-300 text-xs px-2 py-1.5 focus:outline-none focus:border-amber-500 rounded-none text-center font-mono text-slate-900"
                                />
                              </div>
                              <div className="md:col-span-2">
                                <label className="block text-[8px] font-mono font-bold uppercase text-slate-400 mb-0.5">Valor Alvo</label>
                                <input
                                  type="number"
                                  required
                                  value={newKrTarget}
                                  onChange={(e) => setNewKrTarget(Number(e.target.value))}
                                  className="w-full bg-white border border-slate-300 text-xs px-2 py-1.5 focus:outline-none focus:border-amber-500 rounded-none text-center font-mono text-slate-900"
                                />
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-1">
                              <div className="w-full sm:max-w-xs text-left">
                                <label className="block text-[8px] font-mono font-bold uppercase text-slate-400 mb-0.5 mt-1">
                                  Definir Progresso do KR: <strong className="text-amber-800">{newKrProgress}%</strong>
                                </label>
                                <input
                                  type="range"
                                  min="0"
                                  max="100"
                                  value={newKrProgress}
                                  onChange={(e) => setNewKrProgress(Number(e.target.value))}
                                  className="w-full accent-amber-605 cursor-ew-resize mt-1"
                                />
                              </div>

                              <button
                                type="submit"
                                className="bg-[#047857] hover:bg-[#065f46] text-white font-mono text-[9px] font-bold uppercase tracking-wider py-1.5 px-4 cursor-pointer shadow-[1px_1px_0px_rgba(0,0,0,1)] flex items-center gap-1.5 border border-slate-900 shrink-0"
                              >
                                ✓ Registrar Resultado Chave
                              </button>
                            </div>
                          </form>
                        </div>
                      )}

                      {/* Display of our direct Key Results */}
                      {krs.length === 0 ? (
                        <div className="p-4 bg-slate-50 border border-dashed border-slate-200 text-center">
                          <span className="text-slate-400 font-serif italic text-xs block mb-0.5">Nenhum Key Result registrado</span>
                          <p className="text-[10px] text-slate-400">Clique em "Adicionar Resultado Chave" para iniciar o rastreamento estratégico.</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {krs.map(kr => {
                            // Find linked alterations/changes (chg.keyResultId === kr.id)
                            const linkedChgs = customChanges.filter(chg => chg.keyResultId === kr.id);
                            
                            // Unlinked changes for linking selection dropdown
                            const unlinkedChgs = customChanges.filter(
                              chg => chg.keyResultId !== kr.id
                            );

                            // Select dropdown value for this KR
                            const currentSelChangeId = selectedChangeIdToBind[kr.id] || "";

                            return (
                              <div key={kr.id} className="bg-slate-50/70 border border-slate-200 p-4 hover:bg-slate-50 transition relative flex flex-col justify-between">
                                
                                <div>
                                  {/* Title and stats layout */}
                                  <div className="flex justify-between items-start gap-2 mb-2">
                                    <div className="text-left">
                                      <span className="text-[8px] font-mono text-teal-800 bg-teal-50 border border-teal-100 px-1 py-0.2 uppercase font-bold tracking-wider">
                                        KR: {kr.id.replace("kr-", "").replace("obj-", "OBJ")}
                                      </span>
                                      <h6 className="font-sans font-bold text-xs text-slate-950 mt-1 leading-snug">{kr.title}</h6>
                                    </div>
                                    <div className="shrink-0 text-right">
                                      <span className="text-[10.5px] font-mono font-bold text-slate-900 bg-white border border-slate-300 px-1.5 py-0.5 leading-none block shadow-xs">
                                        {kr.currentValue}{kr.unit} / {kr.targetValue}{kr.unit}
                                      </span>
                                    </div>
                                  </div>

                                  {/* Progress bar visual */}
                                  <div className="mb-4">
                                    <div className="flex justify-between text-[8px] font-mono text-slate-400 mb-0.5 font-bold">
                                      <span>Métrica Operacional</span>
                                      <span className={kr.progress >= 80 ? "text-emerald-750" : kr.progress >= 50 ? "text-teal-755" : "text-amber-755"}>
                                        Progresso do KR: {kr.progress}%
                                      </span>
                                    </div>
                                    <div className="w-full bg-slate-200 h-1.5 border overflow-hidden">
                                      <motion.div 
                                        className={`h-full ${
                                          kr.progress >= 80 
                                            ? "bg-emerald-600" 
                                            : kr.progress >= 50 
                                            ? "bg-teal-500" 
                                            : "bg-amber-500"
                                        }`} 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${kr.progress}%` }}
                                        transition={{ duration: 1.4, ease: "easeOut" }}
                                      />
                                    </div>
                                  </div>

                                  {/* Linked changes / RFC */}
                                  <div className="border-t border-slate-205 pt-2.5 mt-2.5">
                                    <div className="flex justify-between items-center mb-1.5">
                                      <span className="text-[8.5px] font-mono uppercase font-black text-slate-500 tracking-wider block">
                                        🚧 Solicitações de Mudança Associadas ({linkedChgs.length})
                                      </span>
                                    </div>

                                    {linkedChgs.length === 0 ? (
                                      <div className="text-[9.5px] text-slate-400 font-serif italic mb-2 py-1 pl-1 bg-white border border-dashed border-slate-200">
                                        Nenhuma solicitação vinculada a este resultado chave.
                                      </div>
                                    ) : (
                                      <div className="space-y-1.5 mb-2.5">
                                        {linkedChgs.map(chg => (
                                          <div key={chg.id} className="bg-white border border-slate-200 p-2 text-left text-xs flex justify-between items-center gap-3 hover:border-emerald-600 transition shadow-xs">
                                            <div className="min-w-0">
                                              <div className="flex gap-1.5 items-center">
                                                <span className="bg-slate-100 border text-slate-600 font-mono text-[7px] px-1 py-0.2 uppercase font-semibold">
                                                  RFC: {chg.id.split("-").pop() || "N/A"}
                                                </span>
                                                <span className={`text-[7px] font-mono px-1 border uppercase font-bold ${
                                                  chg.status === "EXECUTADA" 
                                                    ? "bg-emerald-50 text-emerald-700 border-emerald-200" 
                                                    : "bg-amber-50 text-amber-700 border-amber-200"
                                                }`}>
                                                  {chg.status}
                                                </span>
                                              </div>
                                              <strong className="text-slate-800 text-[10.5px] block truncate mt-0.5 leading-snug">{chg.title}</strong>
                                              <span className="text-[9px] text-slate-400 block font-mono">Dono: {chg.responsible}</span>
                                            </div>
                                            <button
                                              onClick={() => {
                                                // Unlink action!
                                                setCustomChanges(prev => prev.map(p => {
                                                  if (p.id === chg.id) {
                                                    return { ...p, keyResultId: undefined };
                                                  }
                                                  return p;
                                                }));
                                                setNotification({
                                                  show: true,
                                                  message: `Alteração "${chg.title}" desvinculada do KR com sucesso!`,
                                                  type: "INFO"
                                                });
                                                setTimeout(() => setNotification({ show: false, message: "", type: "INFO" }), 3500);
                                              }}
                                              className="text-rose-600 hover:text-rose-800 font-mono text-[8.5px] uppercase font-bold shrink-0 hover:underline cursor-pointer leading-none"
                                              title="Desvincular do KR"
                                            >
                                              [desvincular]
                                            </button>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </div>

                                {/* Direct linkages interactive form helper */}
                                <div className="border-t border-slate-200/65 pt-2 mt-2 bg-white/40 p-2 border border-slate-150">
                                  <label className="block text-[8px] font-mono font-black uppercase text-[#047857] mb-0.5 text-left">
                                    🔗 Vincular Solicitação de Mudança Operacional
                                  </label>
                                  <div className="flex gap-1.5 mt-1">
                                    <select
                                      value={currentSelChangeId}
                                      onChange={(e) => {
                                        const val = e.target.value;
                                        setSelectedChangeIdToBind(prev => ({
                                          ...prev,
                                          [kr.id]: val
                                        }));
                                      }}
                                      className="bg-white border text-[10px] px-1.5 py-1 text-slate-950 focus:outline-none focus:border-[#047857] rounded-none font-sans shrink min-w-0 w-full"
                                    >
                                      <option value="">-- Vincular RFC Existente --</option>
                                      {unlinkedChgs.map(chg => (
                                        <option key={chg.id} value={chg.id}>
                                          [{chg.id.split("-").pop()}] {chg.title} ({chg.status})
                                        </option>
                                      ))}
                                    </select>
                                    <button
                                      onClick={() => {
                                        if (!currentSelChangeId) return;
                                        
                                        // Update change linkage!
                                        setCustomChanges(prev => prev.map(p => {
                                          if (p.id === currentSelChangeId) {
                                            return { ...p, keyResultId: kr.id, objectiveId: obj.id }; // link
                                          }
                                          return p;
                                        }));

                                        const linkedChgObj = customChanges.find(c => c.id === currentSelChangeId);

                                        // Reset select
                                        setSelectedChangeIdToBind(prev => ({
                                          ...prev,
                                          [kr.id]: ""
                                        }));

                                        setNotification({
                                          show: true,
                                          message: `Alteração "${linkedChgObj?.title}" acoplada diretamente ao Resultado Chave e Objetivo estrategico!`,
                                          type: "SUCCESS"
                                        });
                                        setTimeout(() => setNotification({ show: false, message: "", type: "SUCCESS" }), 3500);
                                      }}
                                      disabled={!currentSelChangeId}
                                      className="bg-[#047857] hover:bg-[#065f46] disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed disabled:border-slate-300 text-white font-mono text-[9px] px-2.5 py-1 uppercase font-bold tracking-wider shrink-0 cursor-pointer border border-slate-900 shadow-xs"
                                    >
                                      Vincular
                                    </button>
                                  </div>
                                </div>

                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        </div>
      )}

      {/* VIEWPORT 8: QUALITY DASHBOARD */}
      {activeTabPanel === "QUALITY_DASHBOARD" && (
        <div className="space-y-6 text-left animate-fade-in text-slate-900 bg-slate-50 p-1 md:p-2">
          <div className="bg-white border-2 border-slate-900 p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            
            {/* Header section with fine labels and styling */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-slate-200 pb-4 mb-6 gap-4">
              <div>
                <span className="text-[9px] bg-red-100 text-red-900 border border-red-300 px-2 py-0.5 font-bold tracking-widest uppercase">
                  Controle Estatístico de Processo (SPC) &amp; Capabilidade Lean Six Sigma
                </span>
                <h3 className="text-xl font-serif font-black uppercase text-slate-900 mt-1 flex items-center gap-2">
                  <span>📊 Dashboard de Qualidade e Nível Sigma (SPC Suite)</span>
                  <span className="text-xs bg-blue-50 text-blue-800 border border-blue-200 px-1 font-mono tracking-tighter">Métricas Lean Six Sigma</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-normal max-w-2xl">
                  Análise consolidada e comparativa de falhas por milhão de oportunidades (DPMO), rendimento operacional (Yield Rate) e estabilidade de capabilidade (Nível Sigma σ) por posto de trabalho.
                </p>
              </div>

              {/* Formula guide label */}
              <div className="flex gap-2">
                <span className="text-xs text-slate-400 font-mono self-center">Fórmula Base: Probit(Yield) + 1.5σ Shift</span>
              </div>
            </div>

            {/* General Quality KPIs */}
            {(() => {
              // Calculate derived stats
              const productOfYields = steps.reduce((acc, s) => acc * (s.yieldRate / 100), 1);
              const calculatedRolledYield = productOfYields * 100;
              const calculatedDpmo = (1 - productOfYields) * 1000000;
              const calculatedSigma = Math.max(1.0, Math.min(6.0, probit(productOfYields) + 1.5));

              // Find step with lowest yield
              const stepsWithCalculations = steps.map(s => {
                const ratio = s.yieldRate / 100;
                const sig = Math.max(1.0, Math.min(6.0, probit(ratio) + 1.5));
                return { ...s, sig };
              });
              const worstQualityStep = stepsWithCalculations.reduce((worst, current) => {
                return (current.yieldRate < worst.yieldRate) ? current : worst;
              }, stepsWithCalculations[0] || { name: "N/A", yieldRate: 100, sig: 6.0 });

              return (
                <div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-mono uppercase text-slate-400 block mb-0.5">Yield Rolado (RFPY)</span>
                        <span className="text-xs">🔄</span>
                      </div>
                      <strong className="text-lg font-mono font-bold text-slate-900">
                        {calculatedRolledYield.toFixed(3)}%
                      </strong>
                      <span className="text-[8.5px] font-mono text-slate-500 block mt-1">Acumulado End-to-End</span>
                    </div>

                    <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-mono uppercase text-blue-600 block mb-0.5 font-bold">Nível Sigma dO SISTEMA</span>
                        <span className="text-xs">🎯</span>
                      </div>
                      <strong className="text-lg font-serif font-black text-blue-900">
                        {calculatedSigma.toFixed(2)} σ
                      </strong>
                      <span className="text-[8.5px] font-mono text-slate-500 block mt-1">Capabilidade Global Estimada</span>
                    </div>

                    <div className="bg-slate-50 border border-slate-300 p-3.5 pb-2.5">
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-mono uppercase text-red-650 block mb-0.5 font-bold">DPMO Total Acumulado</span>
                        <span className="text-xs">⚠️</span>
                      </div>
                      <strong className="text-lg font-mono text-slate-900">
                        {Math.round(calculatedDpmo).toLocaleString("pt-BR")}
                      </strong>
                      <span className="text-[8.5px] font-mono text-slate-500 block mt-1">Falhas por Milhão Oportunidades</span>
                    </div>

                    <div className="bg-red-50 border border-red-200 p-3.5 pb-2.5">
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-mono uppercase text-red-700 block mb-0.5 font-bold">Gargalo de Qualidade Alvo</span>
                        <span className="text-xs">🛑</span>
                      </div>
                      <strong className="text-sm font-sans font-bold text-red-950 block truncate">
                        {worstQualityStep.name}
                      </strong>
                      <span className="text-[9.5px] font-mono text-red-700 block mt-1 font-bold">
                        Rendimento: {worstQualityStep.yieldRate}% | {worstQualityStep.sig.toFixed(2)}σ
                      </span>
                    </div>
                  </div>

                  {/* COMPARATIVE WITH PROJECT CHARTER METRIC */}
                  <div className="bg-slate-900 text-white p-5 border-2 border-slate-900 mb-6 relative overflow-hidden shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]">
                    {/* Background decorative badge */}
                    <div className="absolute right-0 bottom-0 translate-x-4 translate-y-4 text-slate-850 opacity-10 text-8xl font-serif font-black select-none pointer-events-none">
                      CHARTER
                    </div>

                    <div className="flex flex-col lg:flex-row lg:items-stretch gap-6 relative z-10 text-left">
                      {/* Left: Charter details */}
                      <div className="lg:w-5/12 border-b lg:border-b-0 lg:border-r border-slate-750 pb-4 lg:pb-0 lg:pr-6 flex flex-col justify-between">
                        <div className="space-y-2">
                          <span className="text-[9px] bg-amber-500 text-slate-900 font-mono font-bold px-2 py-0.5 tracking-wider uppercase">
                            Termo de Abertura do Projeto (Project Charter) Ativo
                          </span>
                          <h4 className="text-lg font-serif font-black uppercase text-amber-400">
                            {charter?.title || "Otimização de Linha SMT Integrada"}
                          </h4>
                          <p className="text-xs text-slate-300 italic leading-relaxed">
                            "{charter?.problemStatement || "Gargalo físico e variabilidade estocástica impactando o rendimento final acumulado na linha de montagem e gerando custos de refugo."}"
                          </p>
                        </div>
                        
                        <div className="mt-4 pt-4 border-t border-slate-800 space-y-1">
                          <span className="text-[9px] font-mono uppercase text-slate-450 block font-bold">Meta Estratégica do Projeto (Objetivo):</span>
                          <p className="text-xs text-slate-250">
                            {charter?.goal || "Atingir rendimento final ótimo em Six Sigma, mitigar quebras e minimizar lead time global."}
                          </p>
                        </div>
                      </div>

                      {/* Right: Comparative Indicators */}
                      <div className="lg:w-7/12 space-y-4 flex flex-col justify-center">
                        <span className="text-[10px] font-mono font-bold uppercase text-slate-400 block tracking-wider">
                          🎯 Comparador Visual de Desempenho Real vs. Metas do Project Charter
                        </span>

                        <div className="space-y-4">
                          {/* Indicator 1: Qualidade / Defect Rate vs Yield */}
                          {(() => {
                            // Let's determine defect rate meta
                            // If charter's metric is 'defect_rate', its goal is charter.targetValue (e.g. 2% defect rate = 98% Yield)
                            const isDefectRateMetric = charter?.metric === "defect_rate";
                            const targetDefectRate = isDefectRateMetric ? (charter?.targetValue ?? 2) : 2; 
                            const targetYield = 100 - targetDefectRate;
                            const targetDpmo = targetDefectRate * 10000; // e.g. 2% defect rate is 20,000 DPMO
                            
                            const actualYield = calculatedRolledYield;
                            const actualDpmo = calculatedDpmo;
                            const isAchieved = actualYield >= targetYield;

                            return (
                              <div className="bg-slate-800 p-3.5 border border-slate-700">
                                <div className="flex justify-between items-start mb-1.5">
                                  <div>
                                    <span className="text-[10px] font-mono font-bold text-slate-300 uppercase block">INDICADOR DE QUALIDADE: ROLLED YIELD (RFPY)</span>
                                    <p className="text-[10px] text-slate-400">Yield de Primeira Passagem Acumulado</p>
                                  </div>
                                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 border uppercase ${
                                    isAchieved 
                                      ? "bg-emerald-950 text-emerald-300 border-emerald-500" 
                                      : "bg-rose-950 text-rose-300 border-rose-500"
                                  }`}>
                                    {isAchieved ? "✔️ Meta Atingida" : "⚠️ Abaixo da Meta"}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold mb-2">
                                  <div className="bg-slate-900 border border-slate-700 p-2">
                                    <span className="text-[8px] text-slate-500 block">REAL ATUAL</span>
                                    <span className="text-sm text-white">{actualYield.toFixed(3)}%</span>
                                    <span className="text-[8px] text-red-400 block font-normal">({Math.round(actualDpmo).toLocaleString("pt-BR")} DPMO)</span>
                                  </div>
                                  <div className="bg-slate-900 border border-slate-700 p-2 border-l-4 border-l-amber-500">
                                    <span className="text-[8px] text-amber-400 block">META CHARTER</span>
                                    <span className="text-sm text-amber-300">≥ {targetYield.toFixed(2)}%</span>
                                    <span className="text-[8px] text-amber-500 block font-normal">(&le; {targetDefectRate}% de falhas)</span>
                                  </div>
                                </div>

                                {/* Progress bar comparator */}
                                <div className="space-y-1">
                                  <div className="w-full bg-slate-900 h-2.5 overflow-hidden border border-slate-700 relative">
                                    {/* Draw target mark */}
                                    <div 
                                      className="absolute top-0 bottom-0 w-[3px] bg-amber-400 z-20" 
                                      style={{ left: `${targetYield}%` }}
                                      title={`Target: ${targetYield}%`}
                                    />
                                    {/* Actual Progress bar */}
                                    <motion.div 
                                      className={`h-full ${isAchieved ? "bg-emerald-500" : "bg-red-500"}`} 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${Math.min(100, Math.max(0, actualYield))}%` }}
                                      transition={{ duration: 1.2, ease: "easeOut" }}
                                    />
                                  </div>
                                  <div className="flex justify-between text-[8px] text-slate-500 font-mono font-semibold">
                                    <span>Rendimento de 0%</span>
                                    <span>Limite do Contrato ({targetYield.toFixed(1)}%)</span>
                                    <span>100% (Sem Defeitos)</span>
                                  </div>
                                </div>
                              </div>
                            );
                          })()}

                          {/* Indicator 2: Vazão / Throughput vs Target */}
                          {(() => {
                            const isThroughputMetric = charter?.metric === "throughput";
                            const targetValue = isThroughputMetric ? (charter?.targetValue ?? 400) : 400; // units per hour
                            
                            // Let's retrieve actual hourly capacity from stats
                            const actualThroughput = stats.systemCapacity;
                            const isAchieved = actualThroughput >= targetValue;

                            return (
                              <div className="bg-slate-800 p-3.5 border border-slate-700">
                                <div className="flex justify-between items-start mb-1.5">
                                  <div>
                                    <span className="text-[10px] font-mono font-bold text-slate-300 uppercase block">INDICADOR DE VAZÃO: CAPACIDADE DO SISTEMA</span>
                                    <p className="text-[10px] text-slate-400 font-sans">Capacidade Real Mapeada pelo Gargalo Ativo</p>
                                  </div>
                                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 border uppercase ${
                                    isAchieved 
                                      ? "bg-emerald-950 text-emerald-300 border-emerald-500" 
                                      : "bg-rose-950 text-rose-300 border-rose-500"
                                  }`}>
                                    {isAchieved ? "✔️ Meta Atingida" : "⚠️ Abaixo da Meta"}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold mb-2">
                                  <div className="bg-slate-900 border border-slate-700 p-2">
                                    <span className="text-[8px] text-slate-500 block">REAL ATUAL</span>
                                    <span className="text-sm text-white">{actualThroughput.toFixed(1)} un / h</span>
                                    <span className="text-[8px] text-slate-400 block font-normal">Gargalo: {stats.bottleneckStepName}</span>
                                  </div>
                                  <div className="bg-slate-900 border border-slate-700 p-2 border-l-4 border-l-blue-500">
                                    <span className="text-[8px] text-blue-400 block">META CHARTER</span>
                                    <span className="text-sm text-blue-300">≥ {targetValue} un / h</span>
                                    <span className="text-[8px] text-slate-400 block font-normal">Capacidade de Vazão Alvo</span>
                                  </div>
                                </div>

                                {/* Progress bar comparator */}
                                <div className="space-y-1">
                                  <div className="w-full bg-slate-900 h-2.5 overflow-hidden border border-slate-700 relative">
                                    {/* Draw target mark as percent of max expected capacity */}
                                    <div 
                                      className="absolute top-0 bottom-0 w-[3px] bg-blue-400 z-20" 
                                      style={{ left: `${Math.min(100, (targetValue / 600) * 100)}%` }}
                                      title={`Target: ${targetValue} un/h`}
                                    />
                                    {/* Actual Progress bar */}
                                    <motion.div 
                                      className={`h-full ${isAchieved ? "bg-emerald-500" : "bg-red-500"}`} 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${Math.min(100, (actualThroughput / 600) * 100)}%` }}
                                      transition={{ duration: 1.2, ease: "easeOut" }}
                                    />
                                  </div>
                                  <div className="flex justify-between text-[8px] text-slate-500 font-mono font-semibold">
                                    <span>0 un/h</span>
                                    <span>Limite do Contrato ({targetValue} un/h)</span>
                                    <span>Escala de Pico (600 un/h)</span>
                                  </div>
                                </div>
                              </div>
                            );
                          })()}

                          {/* Indicator 3: Tempo de Ciclo / Lead Time vs Target */}
                          {(() => {
                            const isCycleTimeMetric = charter?.metric === "cycle_time";
                            const targetValue = isCycleTimeMetric ? (charter?.targetValue ?? 25) : 25; // minutes limit
                            
                            // Let's retrieve actual system Lead Time
                            const actualLeadTime = stats.leadTime;
                            const isAchieved = actualLeadTime <= targetValue;

                            return (
                              <div className="bg-slate-800 p-3.5 border border-slate-700">
                                <div className="flex justify-between items-start mb-1.5">
                                  <div>
                                    <span className="text-[10px] font-mono font-bold text-slate-300 uppercase block">INDICADOR DE FLUXO: LEAD TIME INTEGRADO</span>
                                    <p className="text-[10px] text-slate-400 font-sans">Soma dos Tempos de Fila e Processamento do Fluxo</p>
                                  </div>
                                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 border uppercase ${
                                    isAchieved 
                                      ? "bg-emerald-950 text-emerald-300 border-emerald-500" 
                                      : "bg-rose-950 text-rose-300 border-rose-500"
                                  }`}>
                                    {isAchieved ? "✔️ Meta Atingida" : "⚠️ Acima do Limite"}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold mb-2">
                                  <div className="bg-slate-900 border border-slate-700 p-2">
                                    <span className="text-[8px] text-slate-500 block">REAL ATUAL</span>
                                    <span className="text-sm text-white">{actualLeadTime.toFixed(2)} min</span>
                                    <span className="text-[8px] text-slate-400 block font-normal">Lead Time de Produção</span>
                                  </div>
                                  <div className="bg-slate-900 border border-slate-700 p-2 border-l-4 border-l-rose-500">
                                    <span className="text-[8px] text-rose-400 block">LIMITE DE CONTRATO</span>
                                    <span className="text-sm text-rose-300">&le; {targetValue} min</span>
                                    <span className="text-[8px] text-slate-400 block font-normal">Máximo Tolerado no Charter</span>
                                  </div>
                                </div>

                                {/* Progress bar comparator */}
                                <div className="space-y-1">
                                  <div className="w-full bg-slate-900 h-2.5 overflow-hidden border border-slate-700 relative">
                                    {/* Draw target limit mark */}
                                    <div 
                                      className="absolute top-0 bottom-0 w-[3px] bg-red-400 z-20" 
                                      style={{ left: `${Math.min(100, (targetValue / 50) * 100)}%` }}
                                      title={`Limit: ${targetValue} min`}
                                    />
                                    {/* Actual Progress bar */}
                                    <motion.div 
                                      className={`h-full ${isAchieved ? "bg-emerald-500" : "bg-red-500"}`} 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${Math.min(100, (actualLeadTime / 50) * 100)}%` }}
                                      transition={{ duration: 1.2, ease: "easeOut" }}
                                    />
                                  </div>
                                  <div className="flex justify-between text-[8px] text-slate-500 font-mono font-semibold">
                                    <span>Velocidade Instantânea</span>
                                    <span>Tolerância do Charter ({targetValue} min)</span>
                                    <span>Gargalo Crítico (50 min)</span>
                                  </div>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Visual charts comparing steps */}
                  <div className="bg-slate-50 border-2 border-slate-900 p-4 mb-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 pb-3 mb-4 gap-2">
                      <div>
                        <h4 className="text-xs font-mono font-bold uppercase text-slate-700">📈 Gráfico Comparativo de Capabilidade por Etapa</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Compare visualmente o rendimento ou erros estatísticos esperados de cada posto sequencial</p>
                      </div>
                      
                      {/* Metric Toggle Buttons */}
                      <div className="flex border border-slate-300 rounded overflow-hidden">
                        <button
                          onClick={() => setQualityChartMetric("YIELD")}
                          className={`px-3 py-1 text-[10px] font-mono font-bold uppercase transition ${
                            qualityChartMetric === "YIELD" ? "bg-slate-900 text-white" : "bg-white text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          Yield (%)
                        </button>
                        <button
                          onClick={() => setQualityChartMetric("DPMO")}
                          className={`px-3 py-1 text-[10px] font-mono font-bold uppercase border-l border-r border-slate-300 transition ${
                            qualityChartMetric === "DPMO" ? "bg-slate-900 text-white" : "bg-white text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          DPMO
                        </button>
                        <button
                          onClick={() => setQualityChartMetric("SIGMA")}
                          className={`px-3 py-1 text-[10px] font-mono font-bold uppercase transition ${
                            qualityChartMetric === "SIGMA" ? "bg-slate-900 text-white" : "bg-white text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          Sigma (σ)
                        </button>
                      </div>
                    </div>

                    {/* Chart Frame */}
                    <div className="h-[240px] w-full bg-white border border-slate-200 p-2">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={stepsWithCalculations.map(s => {
                            const ratio = s.yieldRate / 100;
                            const dpmVal = Math.round((1 - ratio) * 1000000);
                            return {
                              name: s.name,
                              "Yield Rate (%)": s.yieldRate,
                              "Nível Sigma": Number(s.sig.toFixed(2)),
                              "DPMO (Falhas)": dpmVal
                            };
                          })}
                          margin={{ top: 15, right: 15, left: 15, bottom: 5 }}
                        >
                          <XAxis 
                            dataKey="name" 
                            stroke="#475569" 
                            fontSize={9} 
                            tickLine={false} 
                            axisLine={{ stroke: '#cbd5e1' }}
                            fontFamily="JetBrains Mono, monospace"
                          />
                          <YAxis 
                            stroke="#475569" 
                            fontSize={9} 
                            tickLine={false} 
                            axisLine={{ stroke: '#cbd5e1' }}
                            fontFamily="JetBrains Mono, monospace"
                            domain={qualityChartMetric === "YIELD" ? [80, 100] : [0, 'auto']}
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: "#1e293b", color: "#f8fafc", fontFamily: "sans-serif", fontSize: "11px", borderRadius: "2px", border: "none" }}
                            labelStyle={{ fontWeight: "bold", color: "#f1f5f9", fontFamily: "monospace" }}
                          />
                          <Legend wrapperStyle={{ fontSize: "10px", fontFamily: "JetBrains Mono" }} />
                          {qualityChartMetric === "YIELD" && (
                            <Bar dataKey="Yield Rate (%)" fill="#3b82f6" name="Rendimento Yield (%)" radius={[2, 2, 0, 0]} />
                          )}
                          {qualityChartMetric === "DPMO" && (
                            <Bar dataKey="DPMO (Falhas)" fill="#ef4444" name="Defeitos por Milhão (DPMO)" radius={[2, 2, 0, 0]} />
                          )}
                          {qualityChartMetric === "SIGMA" && (
                            <Bar dataKey="Nível Sigma" fill="#10b981" name="Nível Sigma (σ)" radius={[2, 2, 0, 0]} />
                          )}
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Interactive Dashboard Workspace: Steps list (Left) vs Simulator Playground (Right) */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* LEFT COLUMN: LIST OF WORKSTATIONS & CALCULATIONS */}
                    <div className="lg:col-span-7 space-y-4">
                      <div className="border-b border-slate-200 pb-2 flex justify-between items-center">
                        <h4 className="text-xs font-mono font-bold uppercase text-slate-700 flex items-center gap-1.5">
                          <span>🔄 Postos de Trabalho e Parâmetros Reais</span>
                        </h4>
                        <span className="text-[9px] text-slate-400 uppercase font-mono">Clique para carregar no Simulador</span>
                      </div>

                      <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                        {stepsWithCalculations.map((pStep, index) => {
                          const ratioStep = pStep.yieldRate / 100;
                          const dpmoValue = Math.round((1 - ratioStep) * 1000000);
                          const isSelected = selectedQualityStepId === pStep.id;

                          // Classification color of the capability status
                          let badgeBg = "bg-rose-100 text-rose-800 border-rose-300";
                          let labelTxt = "Crítico (<3σ)";
                          if (pStep.sig >= 4.5) {
                            badgeBg = "bg-emerald-100 text-emerald-800 border-emerald-300";
                            labelTxt = "Classe Mundial (≥4.5σ)";
                          } else if (pStep.sig >= 3.5) {
                            badgeBg = "bg-teal-100 text-teal-800 border-teal-300";
                            labelTxt = "Estável (≥3.5σ)";
                          } else if (pStep.sig >= 2.5) {
                            badgeBg = "bg-amber-100 text-amber-800 border-amber-300";
                            labelTxt = "Instável (≥2.5σ)";
                          }

                          return (
                            <div 
                              key={pStep.id}
                              onClick={() => {
                                setSelectedQualityStepId(pStep.id);
                                setSimulationYield(pStep.yieldRate);
                              }}
                              className={`border-2 p-3.5 transition cursor-pointer relative text-left ${
                                isSelected 
                                  ? "bg-blue-50/70 border-blue-600 shadow-[3px_3px_0px_rgba(29,78,216,1)] animate-pulse-once" 
                                  : "bg-white border-slate-900 hover:border-blue-500 shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                              }`}
                            >
                              {/* Selection overlay badge */}
                              {isSelected && (
                                <span className="absolute top-2 right-2 text-[8px] font-mono font-bold bg-blue-600 text-white px-1 py-0.2 uppercase">
                                  ★ Ativo No Simulador
                                </span>
                              )}

                              <div className="flex justify-between items-start">
                                <div className="space-y-0.5">
                                  <span className="text-[8.5px] font-mono text-slate-400 block uppercase">Posto {index + 1} • Recurso: {pStep.resource}</span>
                                  <h5 className="font-serif font-black text-sm text-slate-900">{pStep.name}</h5>
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-slate-100 text-left">
                                <div>
                                  <span className="text-[8px] font-mono text-slate-400 block uppercase">Yield Real</span>
                                  <strong className="text-xs font-mono text-blue-600">{pStep.yieldRate}%</strong>
                                </div>
                                <div>
                                  <span className="text-[8px] font-mono text-slate-400 block uppercase">DPMO Projetado</span>
                                  <strong className="text-xs font-mono text-slate-900">{dpmoValue.toLocaleString("pt-BR")}</strong>
                                </div>
                                <div>
                                  <span className="text-[8px] font-mono text-slate-400 block uppercase">Nível Sigma</span>
                                  <strong className="text-xs font-mono text-slate-900">{pStep.sig.toFixed(2)} σ</strong>
                                </div>
                              </div>

                              {/* Progress visually represented */}
                              <div className="w-full bg-slate-100 h-1 mt-2.5 overflow-hidden">
                                <div className="bg-blue-600 h-full" style={{ width: `${pStep.yieldRate}%` }}></div>
                              </div>

                              <div className="mt-2.5 flex justify-between items-center text-[10px]">
                                <span className="text-slate-400 font-mono text-[8px]">Ciclo: {pStep.processingTime} min</span>
                                <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.2 border rounded-xs uppercase ${badgeBg}`}>
                                  {labelTxt}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* RIGHT COLUMN: INTERACTIVE LSS QUALITY PLAYGROUND */}
                    <div className="lg:col-span-5">
                      {(() => {
                        const activeSelStep = steps.find(s => s.id === selectedQualityStepId) || steps[0];
                        if (!activeSelStep) return null;

                        const playYieldRatio = simulationYield / 100;
                        const playDpmo = Math.round((1 - playYieldRatio) * 1000000);
                        const playSigma = Math.max(1.0, Math.min(6.0, probit(playYieldRatio) + 1.5));
                        const playDefects = Math.round(simulationBatchSize * (1 - playYieldRatio));

                        return (
                          <div className="border-2 border-slate-900 p-5 bg-[#FAF9F6] shadow-[3px_3px_0px_rgba(26,26,26,1)] h-full">
                            <span className="text-[8.5px] font-mono font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 uppercase block w-fit mb-2">
                              Simulador Dinâmico de Processo
                            </span>

                            <h4 className="font-serif font-black text-md text-slate-900 uppercase text-left">
                              🛠️ LSS Quality Playground
                            </h4>
                            <p className="text-[11px] text-slate-500 mt-1 mb-4 leading-relaxed text-left">
                              Arraste os controles para simular cenários hipotéticos de melhoria (e.g. Kaizen, novos maquinários) no posto <strong>{activeSelStep.name}</strong> e analise o retorno estatístico imediato.
                            </p>

                            <div className="space-y-4 text-left border-b border-dashed border-slate-200 pb-4 mb-4 font-sans">
                              {/* Step reference */}
                              <div className="bg-white border p-3">
                                <span className="text-[8px] font-mono text-slate-400 block uppercase">Etapa Alvo Selecionada</span>
                                <strong className="text-xs text-slate-900">{activeSelStep.name}</strong>
                                <div className="text-[10px] text-slate-500 mt-1 font-mono">Yield Real Atual: {activeSelStep.yieldRate}% ({activeSelStep.resource})</div>
                              </div>

                              {/* Yield range slider */}
                              <div className="space-y-1">
                                <div className="flex justify-between items-center">
                                  <label className="text-[10px] font-mono font-bold uppercase text-slate-700 font-sans">Simular Yield Rate:</label>
                                  <strong className="text-sm font-mono text-blue-600 font-black">{simulationYield.toFixed(2)}%</strong>
                                </div>
                                <input 
                                  type="range" 
                                  min="80" 
                                  max="100" 
                                  step="0.05"
                                  value={simulationYield}
                                  onChange={(e) => setSimulationYield(Number(e.target.value))}
                                  className="w-full accent-blue-600 h-2 bg-slate-200 cursor-ew-resize rounded-lg"
                                />
                                <div className="flex justify-between text-[8px] font-mono text-slate-400 font-bold">
                                  <span>80.00% (Crítico)</span>
                                  <span>93.3% (3.0σ)</span>
                                  <span>100.00% (Perfeito)</span>
                                </div>
                              </div>

                              {/* Batch size simulator */}
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold uppercase text-slate-700 block font-sans">Volume de Lote para Teste:</label>
                                <select 
                                  value={simulationBatchSize} 
                                  onChange={(e) => setSimulationBatchSize(Number(e.target.value))}
                                  className="w-full bg-white border border-slate-300 px-2 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600 rounded-none font-mono"
                                >
                                  <option value="1000">1.000 Unidades</option>
                                  <option value="5000">5.000 Unidades</option>
                                  <option value="10000">10.000 Unidades (Meta Padrão)</option>
                                  <option value="50000">50.000 Unidades</option>
                                  <option value="100000">100.000 Unidades</option>
                                  <option value="1000000">1.000.000 Unidades (DPMO Scale)</option>
                                </select>
                              </div>
                            </div>

                            {/* OUTPUT SIMULATION METRICS */}
                            <div className="space-y-3 text-left">
                              <h5 className="text-[9.5px] font-mono font-black uppercase text-slate-400 tracking-wider">
                                📊 Resultados de Saída Projetados
                              </h5>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="bg-white border p-3">
                                  <span className="text-[8px] font-mono text-slate-400 block uppercase">Nível Sigma Estimado</span>
                                  <strong className="text-lg font-serif font-black text-emerald-700 block mt-0.5">{playSigma.toFixed(2)} σ</strong>
                                  <span className="text-[8.5px] font-mono text-slate-500 block mt-0.5">
                                    {playSigma >= 4.5 ? "✔️ Classe Mundial" : playSigma >= 3.5 ? "✔️ Estável" : "⚠️ Instável"}
                                  </span>
                                </div>

                                <div className="bg-white border p-3">
                                  <span className="text-[8px] font-mono text-slate-400 block uppercase">DPMO Projetado</span>
                                  <strong className="text-md font-mono text-slate-950 block mt-1">{playDpmo.toLocaleString("pt-BR")}</strong>
                                  <span className="text-[8px] font-mono text-slate-400 block mt-1">erros em 1 milhão</span>
                                </div>
                              </div>

                              <div className="bg-blue-900 text-white p-3 border border-slate-900">
                                <div className="flex justify-between items-center">
                                  <span className="text-[8.5px] font-mono uppercase tracking-wider block text-blue-200">Defeitos de Qualidade no Lote</span>
                                  <span className="text-xs">💥</span>
                                </div>
                                <strong className="text-xl font-mono block mt-1 text-yellow-300">
                                  {playDefects.toLocaleString("pt-BR")} peças
                                </strong>
                                <span className="text-[9px] text-blue-100 block mt-1 font-sans">
                                  Esperado produzir num lote de {simulationBatchSize.toLocaleString("pt-BR")} itens de forma sequencial nesta etapa específica.
                                </span>
                              </div>

                              {/* Compare Six Sigma Scale reference table helper */}
                              <div className="bg-slate-100 border p-2.5 text-[9px] font-mono text-slate-500 space-y-1">
                                <span className="font-bold text-slate-700 block uppercase border-b pb-0.5 mb-1 text-[8.5px]">Guia de Referência Six Sigma:</span>
                                <div className="flex justify-between">
                                  <span>6 Sigma (6.0σ):</span>
                                  <strong className="text-slate-700">3.4 DPMO | 99.9997%</strong>
                                </div>
                                <div className="flex justify-between">
                                  <span>5 Sigma (5.0σ):</span>
                                  <span>233 DPMO | 99.977%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>4 Sigma (4.0σ):</span>
                                  <span>6.210 DPMO | 99.38%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>3 Sigma (3.0σ):</span>
                                  <span>66.810 DPMO | 93.32%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>2 Sigma (2.0σ):</span>
                                  <span>308.537 DPMO | 69.15%</span>
                                </div>
                              </div>

                            </div>
                          </div>
                        );
                      })()}
                    </div>

                  </div>

                  {/* LSS DMAIC RECOMMENDATION BLOCK */}
                  <div className="mt-8 border-2 border-slate-900 bg-white p-5 text-left shadow-[3px_3px_0px_rgba(0,0,0,1)]">
                    <h4 className="font-serif font-black text-md text-slate-900 uppercase flex items-center gap-1.5 border-b pb-2 mb-3">
                      <span>⚙️ Guia de Melhoria de Processo e Mitigação de Desvios (DMAIC Core)</span>
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs text-slate-700">
                      <div>
                        <span className="text-[8.5px] font-mono font-bold text-blue-600 block uppercase mb-1">Passo 1: DEFINE &amp; MEASURE (D-M)</span>
                        <strong className="text-slate-900 block font-serif">Mapear Oportunidades de Erro</strong>
                        <p className="text-[11px] text-slate-500 mt-1 leading-normal">
                          Identifique em cada etapa o que constitui um defeito. Estabeleça auditorias pontuais para medir o baseline através dos sensores da Sinergia Corp, alimentando este Dashboard.
                        </p>
                      </div>

                      <div>
                        <span className="text-[8.5px] font-mono font-bold text-indigo-600 block uppercase mb-1">Passo 2: ANALYZE (A)</span>
                        <strong className="text-slate-900 block font-serif">Descobrir Variabilidade Estocástica</strong>
                        <p className="text-[11px] text-slate-500 mt-1 leading-normal">
                          Utilize o diagrama Ishikawa e os <strong>5 Porquês</strong> do Módulo de Gestão de Mudanças para mapear incidentes técnicos do pior posto de trabalho ({
                            worstQualityStep.name
                          }) antes de propor correções.
                        </p>
                      </div>

                      <div>
                        <span className="text-[8.5px] font-mono font-bold text-emerald-600 block uppercase mb-1">Passo 3: IMPROVE &amp; CONTROL (I-C)</span>
                        <strong className="text-slate-900 block font-serif">Implantar Dispositivos Poka-Yoke</strong>
                        <p className="text-[11px] text-slate-500 mt-1 leading-normal">
                          Aplique blindagem mecânica e lógica contra erros. Estabeleça quadros de controle SPC com alarmes ativos e mantenha o monitoramento para que o nível Sigma flutue acima de 4.0σ.
                        </p>
                      </div>
                    </div>
                  </div>

                </div>
              );
            })()}

          </div>
        </div>
      )}

      {/* QUICK FOOTER SYSTEM BAR */}
      <div className="mt-8 pt-4 border-t-2 border-slate-900 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-slate-500">
        <div>
          <span>Sincronização Ativa: </span>
          <strong className="text-slate-800">{steps.length} postos sequenciais mapeados</strong>
        </div>
        <div className="flex gap-4 items-center flex-wrap">
          <span className="text-[10px] uppercase font-bold text-slate-400">Padrões de Auditoria: PwC / ISO 9001 / TOGAF v10</span>
          <span className="text-[#C49746] font-bold">✔️ Conectado</span>
        </div>
      </div>

    </div>
  );
}
