/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RefreshCw } from "lucide-react";

export const LoadingFallback = () => (
  <div className="flex flex-col items-center justify-center p-12 min-h-[300px] border border-dashed border-[#1A1A1A]/10 bg-[#FBFBFA]/50 animate-pulse text-xs font-mono text-[#1A1A1A]/60">
    <div className="flex items-center gap-2 mb-2">
      <RefreshCw className="animate-spin h-4 w-4 text-indigo-600" />
      <span>Carregando módulo inteligente...</span>
    </div>
    <p className="text-[10px] text-[#1A1A1A]/40 text-center max-w-xs leading-relaxed">
      Otimizando recursos, instanciando modelos estocásticos e compilando subsistemas enxutos.
    </p>
  </div>
);
