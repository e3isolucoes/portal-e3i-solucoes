import React, { useState } from "react";
import { 
  Sparkles, 
  HelpCircle, 
  ArrowRight, 
  Layers, 
  Cpu, 
  FileText, 
  ChevronRight, 
  CheckCircle2, 
  Info, 
  RefreshCw, 
  Plus, 
  Trash2,
  Download,
  Award,
  AlertTriangle,
  Play,
  RotateCcw,
  Check,
  Zap,
  User,
  ShieldCheck,
  Laptop,
  Eye,
  Save,
  Share2
} from "lucide-react";
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from "recharts";
import { ProcessStep, ProjectCharter, Sipoc } from "../types";
import E3IPassoAPassoSimulator from "./E3IPassoAPassoSimulator";
import E3IDeliveryBlueprint from "./E3IDeliveryBlueprint";
import { 
  buildAssistantResult, 
  calculateProcessScores, 
  generateContinuousImprovementAnalysis, 
  buildRecommendations, 
  buildExecutiveReport,
  DISCOVERY_QUESTIONS,
  splitLines,
  ProcessDraft
} from "../utils/e3iIntelligence";

interface E3IProcessosInteligentesProps {
  steps: ProcessStep[];
  setSteps: React.Dispatch<React.SetStateAction<ProcessStep[]>>;
  charter: ProjectCharter;
  setCharter: (charter: ProjectCharter) => void;
  setCurrentWorkspaceView: (view: any) => void;
}

export default function E3IProcessosInteligentes({
  steps,
  setSteps,
  charter,
  setCharter,
  setCurrentWorkspaceView
}: E3IProcessosInteligentesProps) {
  // E3I - PASSO A PASSO DE USO (Interactive Simulation Sheet state)
  const [moduleMode, setModuleMode] = useState<"PASSO_A_PASSO" | "CO_PILOTO" | "BLUEPRINT">("PASSO_A_PASSO");
  
  // Interactive yellow input cells (Standard inputs mimicking the exact values from step 3 of the image)
  const [param1Value, setParam1Value] = useState<string>("100"); // Parâmetro 1 (Taxa de Chegada de Itens)
  const [param2Value, setParam2Value] = useState<string>("250"); // Parâmetro 2 (Tempo VA de Processamento em minutos)
  const [param3Value, setParam3Value] = useState<string>("40");  // Parâmetro 3 (Total de Defeitos por 1000)
  const [param4Value, setParam4Value] = useState<string>("150"); // Parâmetro Auxiliar (Tempo NVA de Fila / Espera em minutos)

  const [step1BackupSaved, setStep1BackupSaved] = useState<boolean>(false);
  const [sheetActiveTab, setSheetActiveTab] = useState<"ENTRADAS" | "PROCESSAMENTO" | "SAÍDAS" | "AJUDA">("ENTRADAS");
  const [activeRoadmapStep, setActiveRoadmapStep] = useState<number>(1);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [hasUpdated, setHasUpdated] = useState<boolean>(false);
  const [sheetAlerts, setSheetAlerts] = useState<string[]>([]);
  const [savedVersions, setSavedVersions] = useState<Array<{ id: string; name: string; timestamp: string; p1: string; p2: string; p3: string; p4: string }>>([]);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Core Calculations for the Excel simulator
  const numP1 = parseFloat(param1Value) || 0;
  const numP2 = parseFloat(param2Value) || 0;
  const numP3 = parseFloat(param3Value) || 0;
  const numP4 = parseFloat(param4Value) || 0;

  // Total lead time (Tempo Total)
  const simulatedLeadTime = numP2 + numP4;
  // Process Cycle Efficiency
  const simulatedPce = simulatedLeadTime > 0 ? (numP2 / simulatedLeadTime) * 100 : 0;
  // Yield (FPP %)
  const computedYield = numP3 > 0 ? Math.max(0, 100 - (numP3 / 10)) : 100;
  // DPMO
  const computedDpmo = numP3 > 0 ? (numP3 / 1000) * 1000000 : 0;

  // Sigma approximation helper
  const getSigmaFromYield = (y: number): number => {
    if (y <= 0.001) return 0.5;
    if (y >= 0.999999) return 6.0;
    const p = 1.0 - y;
    const t = Math.sqrt(-2.0 * Math.log(p));
    const c0 = 2.515517;
    const c1 = 0.802853;
    const c2 = 0.010328;
    const d1 = 1.432788;
    const d2 = 0.189269;
    const d3 = 0.001308;
    const approx = t - ((c0 + c1*t + c2*t*t) / (1.0 + d1*t + d2*t*t + d3*t*t*t));
    return parseFloat((approx + 1.5).toFixed(2));
  };
  
  const computedSigma = getSigmaFromYield(computedYield / 100);

  // Recalculate and flag alerts
  React.useEffect(() => {
    const alerts: string[] = [];
    if (!param1Value || isNaN(numP1) || numP1 <= 0) {
      alerts.push("Parâmetro 1 (Taxa de Chegada) deve ser uma célula positiva.");
    }
    if (!param2Value || isNaN(numP2) || numP2 < 0) {
      alerts.push("Parâmetro 2 (Tempo VA) não pode ser uma célula em branco ou negativa.");
    }
    if (!param3Value || isNaN(numP3) || numP3 < 0 || numP3 > 1000) {
      alerts.push("Parâmetro 3 (Defeitos por 1000) deve ser uma célula entre 0 e 1000.");
    }
    if (isNaN(numP4) || numP4 < 0) {
      alerts.push("Parâmetro 4 (Tempo NVA) deve ser uma célula válida maior ou igual a zero.");
    }
    setSheetAlerts(alerts);
  }, [param1Value, param2Value, param3Value, param4Value]);

  const handleUpdateSheet = () => {
    if (sheetAlerts.length > 0) return;
    setIsUpdating(true);
    setTimeout(() => {
      setIsUpdating(false);
      setHasUpdated(true);
      setSheetActiveTab("SAÍDAS");
      setActiveRoadmapStep(7); // Jump straight to analyze results in outputs!
    }, 1500);
  };

  const [interviewText, setInterviewText] = useState("");
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"sipoc" | "lean" | "cbok" | "dmaic" | "backlog" | "graph" | "ciclo_bpm">("sipoc");
  const [selectedBpmPhase, setSelectedBpmPhase] = useState<string>("PLANEJAMENTO");
  const [bpmCompletedChecks, setBpmCompletedChecks] = useState<Record<string, boolean>>({
    "PLANEJAMENTO-0": true, // preset some defaults so the user sees progress initially
    "PLANEJAMENTO-2": true,
    "ANALISE-1": true
  });

  // Bottom form validation or feedback messages
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Load samples
  const loadSampleTI = () => {
    setInterviewText(
      "Nome do Processo: Atendimento de Chamados de TI.\n" +
      "Área: Tecnologia da Informação / Service Desk.\n" +
      "Responsável: Coordenação de Suporte Técnico.\n\n" +
      "Objetivo: Resolver incidentes e requisições de usuários internos dentro da meta do SLA, minimizando o tempo de indisponibilidade de ferramentas core.\n" +
      "Resultado esperado: Chamados solucionados, sistemas restabelecidos e usuários satisfeitos.\n\n" +
      "Etapas:\n" +
      "1. Abertura do chamado pelo usuário via portal ou e-mail\n" +
      "2. Triagem e classificação de prioridade pelo suporte N1\n" +
      "3. Diagnóstico e atendimento especializado pelo N2 ou infraestrutura\n" +
      "4. Validação da solução com o usuário solicitante\n" +
      "5. Registro de evidências e encerramento definitivo\n\n" +
      "Sistemas: ServiceNow, Teams, BigQuery, Excel e E-mail.\n" +
      "Dores: Longa espera para triagem de e-mails manuais, retrabalho em chamados com dados incompletos e frequentes transferências erradas entre grupos.\n" +
      "Riscos: Estouro de SLA contratual, insatisfação de clientes vip e perda de rastreabilidade de acessos confidenciais.\n" +
      "Volume aproximado: 950 chamados mensais.\n" +
      "Tempo médio de ciclo: 8 horas úteis.\n" +
      "Retrabalho estimado: 18%.\n\n" +
      "Indicadores: MTTR (tempo médio de reparo), First Contact Resolution (FCR) e % de SLAs atendidos.\n" +
      "Evidências: Logs do ServiceNow e avaliações de satisfação enviadas após o fechamento."
    );
    setFeedbackMsg(null);
  };

  const loadSampleContab = () => {
    setInterviewText(
      "Nome do Processo: Fechamento Contábil Mensal (Month-End Close).\n" +
      "Área: Contabilidade Geral / Controladoria.\n" +
      "Responsável: Coordenador de Contabilidade.\n\n" +
      "Objetivo do processo: Consolidar todas as movimentações financeiras para emissão de demonstrações financeiras em compliance IFRS.\n\n" +
      "Etapas do processo:\n" +
      "Corte (Cut-off) de lançamentos auxiliares -> Importação e integração no Livro Razão ERP -> Lançamentos manuais de provisões -> Conciliação de contas patrimoniais -> Análise das variações orçamentadas -> Fechamento definitivo do período contábil.\n\n" +
      "Sistemas utilizados: SAP ERP S/4HANA, Planilhas de provisão e BlackLine.\n" +
      "Gargalos: Atrasos na entrega de relatórios das áreas fornecedoras, lançamentos duplicados por centros de custo descentralizados e assinaturas colhidas por e-mails soltos.\n" +
      "Riscos: Erro de divulgação em balancetes oficiais, multas de fiscalização da receita e atrasos de consolidação da matriz internacional.\n" +
      "Frequência / Volume: Execução mensal. Cerca de 1.200 notas e provisões por fechamento.\n" +
      "Tempo médio: 5 dias úteis (40 horas de esforço de equipe).\n" +
      "Retrabalho estimado: 22% dos lançamentos pós-cutoff recomendam estornos manuais.\n" +
      "Indicadores: Dias totais para liberação (Fast Close), % de contas patrimoniais conciliadas e volume de ajustes manuais retardatários."
    );
    setFeedbackMsg(null);
  };

  const handleAnalyze = () => {
    if (!interviewText.trim()) {
      setFeedbackMsg({ type: "error", text: "Por favor, insira ou carregue uma entrevista de processo para iniciar." });
      return;
    }
    setIsLoading(true);
    setFeedbackMsg(null);
    try {
      // Direct call to our highly robust, explainable heuristic engine
      const result = buildAssistantResult(interviewText);
      setAnalysisResult(result);
    } catch (e: any) {
      setFeedbackMsg({ type: "error", text: `Erro na análise local: ${e.message}` });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSyncToProject = () => {
    if (!analysisResult) return;
    const draft = analysisResult.process;
    const stepsList = analysisResult.flow_markdown.split(" → ");

    // Build real workspace ProcessSteps based on the AI output
    const mappedSteps: ProcessStep[] = stepsList.map((stepName: string, index: number) => {
      const isFirst = index === 0;
      // Synthesize smart defaults
      const processingTime = isFirst
        ? Math.max(1, Math.round((draft.cycle_time_hours * 60) / stepsList.length))
        : Math.max(1, Math.round((draft.cycle_time_hours * 60) * 0.15));
      
      const resource = index % 2 === 0 ? "Analista Principal" : "Coordenador Técnico";

      return {
        id: `step-${index + 1}`,
        name: stepName,
        resource,
        resourceCount: 1,
        processingTime: parseFloat(processingTime.toFixed(1)),
        standardDeviation: parseFloat((processingTime * 0.25).toFixed(1)) || 0.5,
        yieldRate: parseFloat((1 - (draft.rework_percentage / 100) / stepsList.length).toFixed(3)) || 0.95,
        setupTime: index === 0 ? 10 : 0,
        x: 100 + index * 180,
        y: 150,
        shapeType: index === 0 ? "START" : index === stepsList.length - 1 ? "END" : "ACTIVITY",
        subProcesses: [],
        linkedProcesses: [],
        evidenceOrigin: "USER_DECLARATION", // E3I Origin tracking mark
        stepInstructions: [
          `Verificar conformidade da atividade "${stepName}".`,
          `Garantir SLA esperado sob gestão de ${draft.owner}.`
        ],
        requiredInputs: isFirst ? draft.documents.split("\n") : [],
        outputs: isFirst ? draft.indicators.split("\n") : [],
        suppliers: isFirst ? [draft.owner] : [],
        customers: isFirst ? ["Áreas Cliente"] : []
      };
    });

    // Link steps sequentially
    for (let i = 0; i < mappedSteps.length - 1; i++) {
      mappedSteps[i].nextStepId = mappedSteps[i + 1].id;
    }

    setSteps(mappedSteps);

    // Sync project charter based on AI objective
    setCharter({
      title: `Otimização ${draft.name}`,
      problemStatement: draft.pain_points.substring(0, 300) || "Gargalos identificados via IA E3I.",
      goal: draft.objective.substring(0, 200) || "Melhorar previsibilidade e Nível Sigma.",
      metric: "cycle_time",
      targetValue: draft.cycle_time_hours > 0 ? parseFloat((draft.cycle_time_hours * 0.7).toFixed(1)) : 10
    });

    setFeedbackMsg({
      type: "success",
      text: `Sincronização concluída com sucesso! O processo "${draft.name}" foi injetado na suíte operacional. Todas as taxas, simulação estocástica de Monte Carlo, análise DMAIC e controle estatístico de alertas Shewhart estão sincronizados!`
    });
  };

  const handleDownloadReport = () => {
    if (!analysisResult) return;
    const scores = calculateProcessScores(analysisResult.process);
    const reportMd = buildExecutiveReport(analysisResult.process, scores);
    
    const blob = new Blob([reportMd], { type: "text/markdown;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `relatorio_e3i_${analysisResult.process.name.toLowerCase().replace(/[^a-z0-9]+/g, "_")}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Metrics render
  const scores = analysisResult ? calculateProcessScores(analysisResult.process) : null;
  const ci = analysisResult && scores ? generateContinuousImprovementAnalysis(analysisResult.process, scores) : null;

  return (
    <div className="bg-[#FAF9F5] border-2 border-[#1A1A1A] p-6 shadow-[5px_5px_0px_0px_rgba(26,26,26,1)] space-y-6 text-left font-sans">
      
      {/* Tab Switcher for Sub-Modules */}
      <div 
        role="tablist" 
        aria-label="Sub-Módulos E3I" 
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") {
            if (moduleMode === "PASSO_A_PASSO") setModuleMode("CO_PILOTO");
            else if (moduleMode === "CO_PILOTO") setModuleMode("BLUEPRINT");
            else setModuleMode("PASSO_A_PASSO");
          } else if (e.key === "ArrowLeft") {
            if (moduleMode === "BLUEPRINT") setModuleMode("CO_PILOTO");
            else if (moduleMode === "CO_PILOTO") setModuleMode("PASSO_A_PASSO");
            else setModuleMode("BLUEPRINT");
          }
        }}
        className="flex border-b-2 border-[#1A1A1A] overflow-x-auto gap-2 p-1 bg-slate-100/50"
      >
        <button
          role="tab"
          id="intel-tab-passo-a-passo"
          aria-selected={moduleMode === "PASSO_A_PASSO"}
          tabIndex={moduleMode === "PASSO_A_PASSO" ? 0 : -1}
          onClick={() => setModuleMode("PASSO_A_PASSO")}
          className={`py-2 px-4 text-xs font-mono uppercase tracking-wide border-t-2 font-black cursor-pointer transition-all ${
            moduleMode === "PASSO_A_PASSO"
              ? "bg-[#C49746] text-white border-[#C49746] shadow-3xs"
              : "bg-transparent border-transparent text-gray-500 hover:text-gray-950 hover:bg-slate-200/50"
          }`}
        >
          🧭 1. PASSO A PASSO DE USO
        </button>
        <button
          role="tab"
          id="intel-tab-co-piloto"
          aria-selected={moduleMode === "CO_PILOTO"}
          tabIndex={moduleMode === "CO_PILOTO" ? 0 : -1}
          onClick={() => setModuleMode("CO_PILOTO")}
          className={`py-2 px-4 text-xs font-mono uppercase tracking-wide border-t-2 font-black cursor-pointer transition-all ${
            moduleMode === "CO_PILOTO"
              ? "bg-[#C49746] text-white border-[#C49746] shadow-3xs"
              : "bg-transparent border-transparent text-gray-500 hover:text-gray-950 hover:bg-slate-200/50"
          }`}
        >
          🧠 2. CO-PILOTO DE IA EXPLICÁVEL
        </button>
        <button
          role="tab"
          id="intel-tab-blueprint"
          aria-selected={moduleMode === "BLUEPRINT"}
          tabIndex={moduleMode === "BLUEPRINT" ? 0 : -1}
          onClick={() => setModuleMode("BLUEPRINT")}
          className={`py-2 px-4 text-xs font-mono uppercase tracking-wide border-t-2 font-black cursor-pointer transition-all ${
            moduleMode === "BLUEPRINT"
              ? "bg-[#C49746] text-white border-[#C49746] shadow-3xs"
              : "bg-transparent border-transparent text-gray-500 hover:text-gray-950 hover:bg-slate-200/50"
          }`}
        >
          🗺️ 3. BLUEPRINT DE ENTREGA E3I
        </button>
      </div>

      {moduleMode === "PASSO_A_PASSO" ? (
        <E3IPassoAPassoSimulator />
      ) : moduleMode === "BLUEPRINT" ? (
        <E3IDeliveryBlueprint />
      ) : (
        <>
          {/* Title & Badge */}
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b-2 border-[#1A1A1A] pb-4 gap-4">
            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#C49746] bg-[#C49746]/5 px-2.5 py-1 border border-[#C49746]/30 rounded-xs">
                💡 Módulo de IA Explicável
              </span>
              <h2 className="font-serif text-3xl font-black text-gray-950 mt-1.5 uppercase tracking-tight">
                E3I Soluções
              </h2>
              <p className="text-xs text-gray-650 font-sans mt-0.5 max-w-2xl">
                Ative o onboarding por IA em linguagem natural. Descreva o funcionamento de suas rotinas de fábrica, comércio, tecnologia ou escritórios e nossa IA local fará a interpretação, cálculo estrutural de capabilidade e recomendação lean imediata.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={loadSampleTI}
                className="bg-white hover:bg-gray-100 text-[#1A1A1A] font-mono font-black text-[9.5px] uppercase p-2 border-2 border-[#1A1A1A] cursor-pointer"
              >
                Exemplo TI 💻
              </button>
              <button 
                onClick={loadSampleContab}
                className="bg-white hover:bg-gray-100 text-[#1A1A1A] font-mono font-black text-[9.5px] uppercase p-2 border-2 border-[#1A1A1A] cursor-pointer"
              >
                Exemplo Contabilidade 💰
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Input Panel */}
            <div className="lg:col-span-5 space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] uppercase font-mono font-bold text-gray-800 tracking-wider flex items-center justify-between">
              <span>Descreva o Processo Livre (Entrevista de Onboarding):</span>
              <span className="text-gray-400 font-normal">{interviewText.length} caract.</span>
            </label>
            <textarea
              value={interviewText}
              onChange={(e) => {
                setInterviewText(e.target.value);
                if (feedbackMsg) setFeedbackMsg(null);
              }}
              placeholder="Descreva quem executa o processo, qual é o objetivo de negócio, quais etapas ocorrem na sequência, qual é a frequência, volume aproximado de demandas mensais, tempo de ciclo, dores operacionais e riscos de falhas..."
              className="w-full h-80 text-xs p-3.5 bg-white border-2 border-[#1A1A1A] focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-none font-mono leading-relaxed"
            />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isLoading}
            className="w-full bg-[#1A1A1A] hover:bg-gray-800 text-white font-mono font-black text-xs uppercase tracking-wider p-3 px-6 border-2 border-[#1A1A1A] flex items-center justify-center gap-2 cursor-pointer transition-all shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]"
          >
            <Sparkles size={14} className={isLoading ? "animate-spin text-amber-500" : "text-amber-500"} />
            {isLoading ? "Processando Inteligência E3I..." : "Analisar Processo com IA"}
          </button>

          {/* Discovery Questions Helper */}
          <div className="bg-white border-2 border-[#1A1A1A] p-4 text-xs font-sans space-y-2">
            <h5 className="font-serif font-black text-[11px] text-[#1A1A1A] uppercase tracking-wider flex items-center gap-1">
              <HelpCircle size={12} className="text-[#C49746]" />
              Roteiro de Perguntas Orientadoras E3I
            </h5>
            <ol className="list-decimal pl-4.5 space-y-1 text-gray-650 text-[10.5px]">
              {DISCOVERY_QUESTIONS.slice(0, 5).map((q, i) => (
                <li key={i}>{q}</li>
              ))}
            </ol>
            <p className="text-[9px] text-[#C49746] font-mono leading-tight">
              A IA detecta respostas estruturais para esses eixos sob premissas explícitas!
            </p>
          </div>
        </div>

        {/* Right Output Dashboard Panel */}
        <div className="lg:col-span-7 space-y-5">
          {analysisResult ? (
            <div className="space-y-5">
              
              {/* Process Main Metadata Bar */}
              <div className="bg-white border-2 border-[#1A1A1A] p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[8px] font-mono font-bold uppercase tracking-widest text-[#1D4ED8] bg-blue-50 px-2 py-0.5 border border-blue-250">
                      {analysisResult.process.area}
                    </span>
                    <span className="text-[8.5px] font-mono text-gray-400">
                      Frequência: {analysisResult.process.frequency}
                    </span>
                  </div>
                  <h3 className="font-serif text-xl font-black text-gray-950 mt-1 leading-none">
                    {analysisResult.process.name}
                  </h3>
                  <p className="text-[10px] text-gray-500 font-sans mt-1">
                    Responsável: <strong>{analysisResult.process.owner}</strong> | Criticidade: <strong className="text-[#C49746]">{analysisResult.process.criticality}</strong>
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto shrink-0 font-mono">
                  <button
                    onClick={handleSyncToProject}
                    className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black uppercase tracking-wider p-2 px-4 shadow-[1.5px_1.5px_0px_0px_rgba(26,26,26,1)] border border-[#1A1A1A] cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Zap size={11} className="text-yellow-300" />
                    Bancar no Projeto Ativo
                  </button>
                  <button
                    onClick={handleDownloadReport}
                    className="w-full sm:w-auto bg-white hover:bg-gray-100 text-gray-900 text-[10px] font-black uppercase tracking-wider p-2 px-4 shadow-[1.5px_1.5px_0px_0px_rgba(26,26,26,1)] border-2 border-[#1A1A1A] cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Download size={11} />
                    Salvar MD
                  </button>
                </div>
              </div>

              {/* High Intensity Math Score Cards */}
              {scores && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-white border-2 border-[#1A1A1A] p-3 text-left relative overflow-hidden">
                    <div className="text-[8.5px] uppercase font-mono font-bold text-gray-500">Maturidade</div>
                    <div className="text-2xl font-serif font-black text-gray-900 mt-1">{scores.maturity_score}/100</div>
                    <div className="text-[8px] font-mono text-blue-700 bg-blue-50 px-1 py-0.2 rounded-xs border border-blue-100 inline-block mt-1 font-bold">{scores.maturity_stage}</div>
                  </div>

                  <div className="bg-white border-2 border-[#1A1A1A] p-3 text-left relative overflow-hidden">
                    <div className="text-[8.5px] uppercase font-mono font-bold text-gray-500">Risco Operacional</div>
                    <div className="text-2xl font-serif font-black text-rose-800 mt-1">{scores.risk_score}/100</div>
                    <div className="text-[8px] font-mono text-rose-700 bg-rose-50 px-1 py-0.2 rounded-xs border border-rose-100 inline-block mt-1 font-bold">Risco Acumulado</div>
                  </div>

                  <div className="bg-white border-2 border-[#1A1A1A] p-3 text-left relative overflow-hidden">
                    <div className="text-[8.5px] uppercase font-mono font-bold text-gray-500">Potencial Automação</div>
                    <div className="text-2xl font-serif font-black text-indigo-850 mt-1">{scores.automation_score}/100</div>
                    <div className="text-[8px] font-mono text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded-xs border border-indigo-100 inline-block mt-1 font-bold">Automação</div>
                  </div>

                  <div className="bg-[#C49746]/5 border-2 border-[#C49746] p-3 text-left relative overflow-hidden">
                    <div className="text-[8.5px] uppercase font-mono font-bold text-amber-900">Priorização</div>
                    <div className="text-2xl font-serif font-black text-[#C49746] mt-1">{scores.priority_score}/100</div>
                    <div className="text-[8px] font-mono text-white bg-[#C49746] px-1 py-0.2 rounded-xs inline-block mt-1 font-semibold">{scores.priority_label}</div>
                  </div>
                </div>
              )}

              {/* Rework Math Box */}
              {scores && (
                <div className="bg-amber-50/50 border border-amber-200 p-3.5 text-xs text-[#C49746] leading-relaxed flex items-center gap-3">
                  <span className="text-xl shrink-0">⚠️</span>
                  <div>
                    <span className="font-bold">Estimativa de Capacidade Crítica:</span> O volume de <strong className="text-gray-950">{analysisResult.process.monthly_volume} execuções/mês</strong> com o tempo real médio de <strong className="text-gray-950">{analysisResult.process.cycle_time_hours}h</strong> sob <strong className="text-gray-950">{analysisResult.process.rework_percentage}% de retrabalho</strong> gera o desperdício oculto de aproximadamente <strong className="text-gray-950">{scores.estimated_rework_hours_month} horas de retrabalho por mês</strong>!
                  </div>
                </div>
              )}

              {/* Interactive Tabs for Intelligence Insights */}
              <div className="space-y-2">
                
                {/* Tabs selection buttons */}
                <div className="flex border-b border-gray-200 overflow-x-auto gap-1">
                  {(["sipoc", "lean", "cbok", "dmaic", "backlog", "graph", "ciclo_bpm"] as const).map((tab) => {
                    const labelMap = {
                      sipoc: "1. Capa SIPOC",
                      lean: "2. Lean & Desperdícios",
                      cbok: "3. CBOK & Charter",
                      dmaic: "4. DMAIC & PDCA",
                      backlog: "5. Backlog 5W2H",
                      graph: "6. Fluxo Sequencial",
                      ciclo_bpm: "🔄 7. Ciclo BPM"
                    };
                    const isActive = activeTab === tab;
                    return (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`py-2 px-3.5 text-[10px] font-mono uppercase tracking-wide border-t-2 shrink-0 cursor-pointer ${
                          isActive
                            ? "bg-white border-[#1A1A1A] text-[#1A1A1A] font-black"
                            : "bg-transparent border-transparent text-gray-500 hover:text-gray-950"
                        }`}
                      >
                        {labelMap[tab]}
                      </button>
                    );
                  })}
                </div>

                {/* Tab content frames */}
                <div className="bg-white border-2 border-[#1A1A1A] p-5 space-y-4">
                  
                  {activeTab === "sipoc" && ci && (
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <h4 className="font-serif text-sm font-black text-gray-950 uppercase flex items-center gap-1 h-fit">
                          <span>📋</span> Capa SIPOC Estruturada por Linguagem Natural
                        </h4>
                        <p className="text-[10px] text-gray-500 leading-tight">Fornecedores, Entradas, Processo Macro, Saídas e Receptores sugeridos pelas Heurísticas E3I.</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-1">
                        {Object.entries(ci.sipoc).map(([col, items]) => (
                          <div key={col} className="bg-gray-50/50 border border-gray-250 p-3 rounded-none flex flex-col gap-2">
                            <span className="text-[9px] font-mono font-black text-indigo-750 uppercase tracking-wider">{col}</span>
                            <div className="space-y-1">
                              {items.map((it, i) => (
                                <div key={i} className="text-[9.5px] p-1.5 bg-white border border-gray-200 text-gray-900 leading-tight rounded-xs">
                                  {it}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === "lean" && ci && (
                    <div className="space-y-4 text-left">
                      <div className="space-y-1">
                        <h4 className="font-serif text-sm font-black text-gray-950 uppercase">🚨 Desperdícios MUD / Lean Combinados</h4>
                        <p className="text-[10px] text-gray-500 leading-tight">Heurísticas baseadas na Toyota Production System para triagem de perdas invisíveis na rotina de faturamento, chamados e SMT.</p>
                      </div>

                      <div className="space-y-2">
                        {ci.lean_wastes.map((waste, i) => (
                          <div key={i} className="flex gap-2 p-2.5 bg-rose-50/30 border border-rose-150 rounded-xs text-[11px] leading-relaxed text-gray-800">
                            <span className="shrink-0 text-[#C49746] font-bold">⚠️</span>
                            <span>{waste}</span>
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                        <div className="space-y-2 border-r border-[#1A1A1A]/10 pr-2">
                          <span className="text-[9px] font-mono font-bold text-indigo-755 uppercase block">Hipóteses de Causa Raiz (5 Porquês):</span>
                          <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-650 leading-relaxed">
                            {ci.root_cause_hypotheses.map((h, i) => (
                              <li key={i}>{h}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <span className="text-[9px] font-mono font-bold text-indigo-755 uppercase block">Painel de KPIs Sugeridos para o Quadro:</span>
                          <div className="flex flex-wrap gap-1.5">
                            {ci.suggested_kpis.map((kpi, i) => (
                              <span key={i} className="text-[9px] font-mono font-bold text-gray-800 bg-gray-100 border border-gray-250 px-2 py-0.5 rounded-xs">
                                📊 {kpi}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === "cbok" && ci && (
                    <div className="space-y-4">
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div className="space-y-3 border-r border-[#1A1A1A]/10 pr-4">
                          <span className="text-[9px] font-mono font-bold text-indigo-750 uppercase block">Lacunas de Maturidade CBOK / BPM:</span>
                          <div className="space-y-2">
                            {ci.cbok_gaps.map((gap, i) => (
                              <div key={i} className="flex gap-1.5 text-[10.5px] text-gray-650 leading-tight">
                                <span className="text-gray-400">⚡</span>
                                <span>{gap}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <span className="text-[9px] font-mono font-bold text-indigo-750 uppercase block">Escopo Mini Project Charter (Lean Six Sigma):</span>
                          <div className="bg-[#FAF9F5] border border-gray-250 p-3 space-y-2 text-[10.5px] leading-normal font-sans">
                            <div>
                              <strong className="text-gray-950 font-semibold">Problema Declarado: </strong>
                              <span className="text-gray-600">{ci.project_charter.Problema}</span>
                            </div>
                            <div>
                              <strong className="text-gray-950 font-semibold">Objetivo / Meta: </strong>
                              <span className="text-gray-600">{ci.project_charter.Objetivo}</span>
                            </div>
                            <div>
                              <strong className="text-gray-950 font-semibold">Dono do Projeto Sugerido: </strong>
                              <span className="text-gray-600">{ci.project_charter["Dono sugerido"]}</span>
                            </div>
                            <div>
                              <strong className="text-gray-950 font-semibold">Critérios de Sucesso: </strong>
                              <span className="text-gray-600">{ci.project_charter["Critério de sucesso"]}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  )}

                  {activeTab === "dmaic" && ci && (
                    <div className="space-y-4 font-sans text-left">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        
                        <div className="space-y-3">
                          <span className="text-[9.5px] font-mono font-black text-amber-900 bg-amber-50 px-2 py-0.5 rounded-xs border border-amber-200 uppercase inline-block font-bold">Roteiro DMAIC Recomendado (Six Sigma)</span>
                          <div className="space-y-2.5">
                            {Object.entries(ci.dmaic_plan).map(([phase, desc]) => (
                              <div key={phase} className="text-[10.5px]">
                                <strong className="text-gray-950 font-extrabold font-mono text-[9px] uppercase tracking-wider block">{phase}:</strong>
                                <span className="text-gray-650 leading-relaxed block">{desc}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-3">
                          <span className="text-[9.5px] font-mono font-black text-teal-900 bg-teal-50 px-2 py-0.5 rounded-xs border border-teal-200 uppercase inline-block font-bold font-bold">Ciclo PDCA Sugerido (Melhoria Contínua)</span>
                          <div className="space-y-2.5">
                            {Object.entries(ci.pdca_cycle).map(([phase, desc]) => (
                              <div key={phase} className="text-[10.5px]">
                                <strong className="text-gray-950 font-extrabold font-mono text-[9px] uppercase tracking-wider block">{phase} (Planejar/Fazer/Checar/Agir):</strong>
                                <span className="text-gray-650 leading-relaxed block">{desc}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                      </div>
                    </div>
                  )}

                  {activeTab === "backlog" && ci && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b pb-1">
                        <span className="text-[9px] font-mono font-bold text-gray-500">BACKLOG DE MELHORIAS PARADOS PARA EXECUTAR</span>
                        <span className="text-[8.5px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.2 border border-emerald-250 font-bold uppercase">Mapeados por IA</span>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-[10px] border-collapse">
                          <thead>
                            <tr className="border-b border-gray-300 font-bold font-mono text-gray-600 uppercase">
                              <th className="pb-1.5 font-bold">Ação Sugerida</th>
                              <th className="pb-1.5 font-bold">Framework</th>
                              <th className="pb-1.5 font-bold">Valor</th>
                              <th className="pb-1.5 font-bold">Dono</th>
                              <th className="pb-1.5 font-bold">Métrica Esperada</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ci.actions.map((act, idx) => (
                              <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50/50">
                                <td className="py-2 pr-2">
                                  <div className="font-extrabold text-gray-950">{act.title}</div>
                                  <div className="text-[8.5px] text-gray-500 leading-tight font-sans mt-0.5">{act.why}</div>
                                </td>
                                <td className="py-2 font-mono text-[9px] text-[#C49746]">{act.framework}</td>
                                <td className="py-2"><span className="font-bold text-indigo-750 bg-indigo-50 px-1 py-0.2 rounded-xs border border-indigo-200">{act.value_score}</span></td>
                                <td className="py-2 text-gray-600">{act.suggested_owner}</td>
                                <td className="py-2 text-gray-600">{act.metric}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {activeTab === "ciclo_bpm" && ci && (
                    <div className="space-y-6 font-sans text-left animate-fade-in">
                      <div className="border-b border-[#1A1A1A]/10 pb-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest block">Metodologia ABPMP CBOK V3.0</span>
                            <h3 className="font-serif text-lg font-black text-gray-950 uppercase">Roteiro Ciclo BPM de Melhoria Contínua</h3>
                          </div>
                          {/* Overall Progress and Maturity Indicator */}
                          <div className="bg-gray-50 border border-gray-250 p-3 flex items-center gap-4">
                            <div className="text-center font-mono">
                              <span className="text-[8px] text-gray-400 block tracking-wider font-extrabold uppercase">Maturidade do Ciclo</span>
                              <span className="text-sm font-black text-indigo-755 block">
                                {Object.values(bpmCompletedChecks).filter(Boolean).length === 24 
                                  ? "Fase 5 (Otimizado)" 
                                  : Object.values(bpmCompletedChecks).filter(Boolean).length >= 16 
                                    ? "Fase 4 (Monitorado)"
                                    : Object.values(bpmCompletedChecks).filter(Boolean).length >= 8 
                                      ? "Fase 3 (Padronizado)" 
                                      : "Fase 2 (Inicial)"}
                              </span>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-[11px] font-mono leading-none">
                                <span className="font-bold text-gray-700">Progresso de Conformidade</span>
                                <span className="font-black text-gray-950">
                                  {Math.round((Object.values(bpmCompletedChecks).filter(Boolean).length / 24) * 100)}%
                                </span>
                              </div>
                              <div className="w-36 h-2 bg-gray-200 border border-gray-300">
                                <div 
                                  className="h-full bg-indigo-750 transition-all duration-300"
                                  style={{ width: `${Math.round((Object.values(bpmCompletedChecks).filter(Boolean).length / 24) * 100)}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                        <p className="text-xs text-gray-600 font-sans mt-2 max-w-2xl leading-relaxed">
                          Segundo o manual <strong className="text-gray-900">BPM CBOK V3.0 (Capítulo 2, Seção 2.2.8)</strong>, os processos de negócio devem ser gerenciados em um ciclo contínuo para manter sua integridade e permitir a transformação. Este ciclo de feedback sem fim conecta os objetivos do negócio com o foco no cliente.
                        </p>
                      </div>

                      {/* Diagnostic layout: SVG Circle and Details Panel */}
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-2">
                        
                        {/* LEFT COLUMN: Visual SVG interactive cycle */}
                        <div className="lg:col-span-5 flex flex-col items-center justify-center space-y-4">
                          <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest text-center block">Clique em uma fase para abrir os detalhes</span>
                          
                          <div className="relative w-full max-w-[320px]">
                            {/* Circular Vector representation */}
                            <svg viewBox="0 0 400 400" className="w-full h-auto">
                              {/* Background circular connector lines representing continuous cycle flow */}
                              <circle cx="200" cy="200" r="120" fill="none" stroke="#E2E8F0" strokeWidth="4" strokeDasharray="6,4" />
                              <circle cx="200" cy="200" r="120" fill="none" stroke="#6366F1" strokeWidth="2" opacity="0.3" />
                              
                              {/* Connecting Arrows in circular trend */}
                              <defs>
                                <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#818CF8" />
                                </marker>
                              </defs>
                              
                              {/* 6 Node coordinates dynamically mapped */}
                              {[
                                { k: "PLANEJAMENTO", cx: 200, cy: 80, num: "1" },
                                { k: "ANALISE", cx: 304, cy: 140, num: "2" },
                                { k: "DESENHO", cx: 304, cy: 260, num: "3" },
                                { k: "IMPLEMENTACAO", cx: 200, cy: 320, num: "4" },
                                { k: "MONITORAMENTO", cx: 96, cy: 260, num: "5" },
                                { k: "REFINAMENTO", cx: 96, cy: 140, num: "6" }
                              ].map((node, i) => {
                                const isSelected = selectedBpmPhase === node.k;
                                // Verify if all 4 checks of this phase are completed
                                const phaseChecks = [0, 1, 2, 3].map(idx => `${node.k}-${idx}`);
                                const isCompleted = phaseChecks.every(k => bpmCompletedChecks[k]);
                                
                                return (
                                  <g key={node.k} className="cursor-pointer group" onClick={() => setSelectedBpmPhase(node.k)}>
                                    {/* Selected highlighted halo */}
                                    <circle 
                                      cx={node.cx} 
                                      cy={node.cy} 
                                      r={isSelected ? "32" : "25"} 
                                      fill={isSelected ? "#EEF2FF" : "white"} 
                                      stroke={isSelected ? "#4F46E5" : isCompleted ? "#059669" : "#1A1A1A"} 
                                      strokeWidth={isSelected ? "4" : isCompleted ? "2" : "1.5"}
                                      className="transition-all duration-300"
                                    />
                                    {/* Number / Checked Icon */}
                                    {isCompleted ? (
                                      <text cx={node.cx} cy={node.cy} x={node.cx} y={node.cy + 4} textAnchor="middle" className="text-emerald-700 font-extrabold font-mono text-xs" fill="#059669">✓</text>
                                    ) : (
                                      <text cx={node.cx} cy={node.cy} x={node.cx} y={node.cy + 4} textAnchor="middle" className={`font-mono text-xs font-black ${isSelected ? "fill-indigo-750 font-bold" : "fill-gray-900"}`}>{node.num}</text>
                                    )}
                                  </g>
                                );
                              })}

                              {/* Center core block showing active context */}
                              <rect x="130" y="165" width="140" height="70" fill="#1A1A1A" rx="4" />
                              <text x="200" y="195" textAnchor="middle" className="font-mono text-[9px] fill-amber-400 font-bold uppercase tracking-wider">CICLO BPM</text>
                              <text x="200" y="215" textAnchor="middle" className="font-serif text-[10px] fill-white font-extrabold uppercase">ABPMP CBOK</text>
                            </svg>
                          </div>

                          <div className="flex flex-wrap items-center justify-center gap-3">
                            <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                              <span className="w-2.5 h-2.5 rounded-full border border-indigo-700 bg-indigo-50 inline-block block" />
                              <span>Fase Selecionada</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block block" />
                              <span>Fase 100% Concluída</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                              <span className="w-2.5 h-2.5 rounded-full border border-gray-400 inline-block block" />
                              <span>Não Iniciada / Parcial</span>
                            </div>
                          </div>
                        </div>

                        {/* RIGHT COLUMN: Interactive workspace panel for selected phase */}
                        <div className="lg:col-span-7 bg-[#FAF9F5]/60 border-2 border-[#1A1A1A] p-5 space-y-5 rounded-none relative">
                          {(() => {
                            const phaseMap: Record<string, {
                              title: string;
                              short: string;
                              description: string;
                              cbokQuotes: string[];
                              checks: string[];
                            }> = {
                              PLANEJAMENTO: {
                                title: "1. Planejamento (Planning)",
                                short: "Alinhamento Estratégico",
                                description: "Definição do contexto do processo de negócio e harmonização do desenho futuro com os objetivos estratégicos da organização. Trata da contextualização, do porquê o processo existe de dentro para fora e de fora para dentro, mapeando seus limites originais.",
                                cbokQuotes: [
                                  "O objetivo da fase Planejar é assegurar alinhamento do contexto de processos de negócio com os objetivos estratégicos da organização.",
                                  "Identificar claramente o cliente e construir o entendimento do valor como base para a transformação contínua.",
                                  "Definição de controles legais e regras e premissas gerais antes de começar a modelagem operacional."
                                ],
                                checks: [
                                  "Project Charter para o processo atual validado e aprovado com metas declaradas.",
                                  "Definição do propósito do processo (por que existe na cadeia de valor global).",
                                  "Principais partes interessadas (stakeholders e lideranças) engajadas para suporte político.",
                                  "Identificação do cliente principal e da sua respectiva proposta de valor pretendida."
                                ]
                              },
                              ANALISE: {
                                title: "2. Análise (Analysis AS-IS)",
                                short: "Investigação do Estado Atual",
                                description: "Análise profunda de como o processo realmente opera na rotina operacional (o estado atual 'AS-IS'). Identifica restrições, gargalos materiais ou de informação, custos, complexidade, retrabalho, pontos de quebra e conformidades.",
                                cbokQuotes: [
                                  "A análise de processos proporciona uma compreensão de como os processos agem em relação à sua capacidade de atender metas planejadas.",
                                  "O principal benefício é o entendimento comum e consensualizado de como o trabalho é executado, evitando a cegueira de silos.",
                                  "Cuidado para evitar a paralisia por análise: simplificar o mapeamento até o nível de detalhe estritamente gerenciável."
                                ],
                                checks: [
                                  "Mapeamento do processo 'AS-IS' (Como É) consolidado de forma transparente com os executores.",
                                  "Triagem qualitativa de perdas invisíveis (os 7 Desperdícios Lean) e medições de tempos operacionais.",
                                  "Mapeamento físico de pontos de quebra e do nível de retrabalho estimado por etapa.",
                                  "Normalização e listagem das regras de negócio informais aplicadas na rotina pelas equipes."
                                ]
                              },
                              DESENHO: {
                                title: "3. Desenho (Design TO-BE)",
                                short: "Especificação do Estado Futuro",
                                description: "Concepção de soluções criativas que mitiguem ou eliminem os gargalos identificados na análise. Modelagem do estado futuro ('TO-BE') visando fluxo contínuo, eliminação de complexidade desnecessária e alinhamento com a tecnologia de suporte.",
                                cbokQuotes: [
                                  "Desenho de processos é a concepção de novos processos e a especificação de como funcionarão, serão medidos e controlados.",
                                  "Focar na modularização das operações. Tratar cada fluxo como blocos de construção reutilizáveis.",
                                  "Os clientes buscam viver uma rotina fluida e simplificada. Reduzir handoffs e focar no ponto único de contato."
                                ],
                                checks: [
                                  "Novo mapeamento de valor (TO-BE) idealizado com a eliminação de redundâncias de baixo valor.",
                                  "Criação e especificação técnica das novas regras de negócio padronizadas.",
                                  "Estabelecimento de métricas alvo que comprovem a economia nas dimensões de Tempo, Custo e Qualidade.",
                                  "Previsão de uso de tecnologias adequadas de automação corporativa (ex: BPMS, iBPMS, APIs)."
                                ]
                              },
                              IMPLEMENTACAO: {
                                title: "4. Implementação (Implementation)",
                                short: "Colocação em Prática",
                                description: "Fase de execução física ou sistêmica dos novos fluxos de processos de negócio. Engloba o provisionamento de recursos, a parametrização de ferramentas de suporte, a homologação técnica de soluções e o treinamento sistemático das pessoas.",
                                cbokQuotes: [
                                  "A implementação física do processo de negócio pode assumir várias formas, como novas regras em BPMS ou reestruturação funcional.",
                                  "A autoconfiança da equipe é essencial para o sucesso. O treinamento sistemático mitiga as resistências naturais à mudança.",
                                  "Evitar implementar sistemas automatizados em cima de processos mal concebidos ('automatizar a ineficiência')."
                                ],
                                checks: [
                                  "Novos Procedimentos Operacionais Padrão (SOPs) e ferramentas de treinamento desenvolvidos e publicados.",
                                  "Capacitação prática com testes de aproveitamento aplicados para as equipes executoras.",
                                  "Parametrização e publicação do fluxo no ambiente produtivo (Web Application ou BPMS).",
                                  "Instauração formal do comitê de controle para apoiar e mitigar incidentes nos primeiros dias de Go-live."
                                ]
                              },
                              MONITORAMENTO: {
                                title: "5. Monitoramento & Controle",
                                short: "Verificação Operacional",
                                description: "Acompanhamento formal para verificar se o processo em operação atende as especificações. Envolve a medição sistemática do rendimento e cruzamento de dados contra as metas corporativas.",
                                cbokQuotes: [
                                  "Gerenciamento de desempenho de processos é o monitoramento planejado para apurar a eficiência e eficácia das operações.",
                                  "As medições do processo devem ser consistentes nas 4 dimensões fundamentais: Tempo, Custo, Capacidade e Qualidade.",
                                  "Diferenciação clara de métricas de eficiência (fazer certo as coisas) e eficácia (fazer as coisas certas)."
                                ],
                                checks: [
                                  "Painel em tempo real (BAM) ou relatórios gerenciais consolidados automatizados.",
                                  "Cálculo e monitoração contínua de Variabilidade (limites superior e inferior de controle Shewhart).",
                                  "Avaliação direta de satisfação do cliente final (proposta de valor percebido e momentos da verdade).",
                                  "Auditorias periódicas do cumprimento de conformidades legais e financeiras no pipeline."
                                ]
                              },
                              REFINAMENTO: {
                                title: "6. Refinamento (Refinement)",
                                short: "Melhoria Contínua Dinâmica",
                                description: "Análise contínua das observações identificadas no monitoramento para iniciar novos ciclos de melhoria. Trata do tratamento de variações assinaláveis persistentes e realimentação prática para planejamento de novos saltos de valor.",
                                cbokQuotes: [
                                  "A fase Agir visa manter a integridade do processo e assegurar sua melhoria sistemática na curva de maturidade.",
                                  "Tratar a 'tirania das pequenas decisões' e variações persistentes no fluxo.",
                                  "Adoção de lições aprendidas de forma a realimentar um novo ciclo PDCA contínuo."
                                ],
                                checks: [
                                  "Revisão formal dos desvios com o comitê de processo e análise detalhada de lacunas residuais.",
                                  "Estudo e aplicação imediata de pequenas melhorias de custo zero ou baixo impacto (quick wins).",
                                  "Priorização e envio de novos requisitos de alta complexidade para a fila de planejamento estratégico (TO-BE).",
                                  "Garantia da transferência de conhecimento acumulado entre as pessoas para evitar a perda de maturidade."
                                ]
                              }
                            };

                            const phase = phaseMap[selectedBpmPhase] || phaseMap.PLANEJAMENTO;

                            return (
                              <div className="space-y-4 animate-fade-in" key={selectedBpmPhase}>
                                {/* Phase Header */}
                                <div>
                                  <span className="text-[9px] font-mono font-bold text-gray-500 uppercase bg-[#B7924F]/10 text-[#C49746] px-2 py-0.5 border border-[#B7924F]/20 rounded-xs">
                                    {phase.short}
                                  </span>
                                  <h4 className="font-serif text-base font-black text-gray-950 mt-1 select-none">
                                    {phase.title}
                                  </h4>
                                </div>

                                <p className="text-xs text-gray-700 leading-relaxed font-sans">
                                  {phase.description}
                                </p>

                                {/* CBOK Quotes Box */}
                                <div className="bg-[#FAF9F5] border-l-4 border-amber-500 p-3 space-y-1.5 rounded-none">
                                  <span className="text-[9px] font-mono text-amber-900 font-extrabold block">EXCERTOS & CONCEITOS DO BPM CBOK V3.0</span>
                                  {phase.cbokQuotes.map((quote, idx) => (
                                    <div key={idx} className="text-[10px] text-gray-650 leading-relaxed flex items-start gap-1.5">
                                      <span className="text-amber-500 font-bold shrink-0">▪</span>
                                      <span>{quote}</span>
                                    </div>
                                  ))}
                                </div>

                                {/* Custom checklist with live state update */}
                                <div className="space-y-2">
                                  <span className="text-[9px] font-mono font-bold text-gray-500 block uppercase">CHECKLIST DE ENTREGÁVEIS & COMPLIANCES</span>
                                  <div className="space-y-1.5">
                                    {phase.checks.map((checkText, idx) => {
                                      const checkKey = `${selectedBpmPhase}-${idx}`;
                                      const isChecked = !!bpmCompletedChecks[checkKey];
                                      return (
                                        <label 
                                          key={idx} 
                                          className={`flex items-start gap-2.5 p-2 border border-gray-200 cursor-pointer select-none rounded-xs transition-all ${
                                            isChecked 
                                              ? "bg-[#FAFBF9] hover:bg-emerald-50/20" 
                                              : "bg-white hover:bg-gray-50/50"
                                          }`}
                                        >
                                          <input 
                                            type="checkbox" 
                                            checked={isChecked}
                                            onChange={() => {
                                              setBpmCompletedChecks(prev => ({
                                                ...prev,
                                                [checkKey]: !prev[checkKey]
                                              }));
                                              // Display a temporary feedback success
                                              setFeedbackMsg({
                                                type: "success",
                                                text: isChecked 
                                                  ? `Entregável desmarcado.` 
                                                  : `Entregável concluído com sucesso!`
                                              });
                                              setTimeout(() => setFeedbackMsg(null), 2500);
                                            }}
                                            className="w-3.5 h-3.5 mt-0.5 accent-indigo-750 text-indigo-750 rounded-xs border-gray-300 focus:ring-indigo-700" 
                                          />
                                          <span className={`text-[10.5px] leading-tight ${isChecked ? "text-gray-950 font-bold line-through" : "text-gray-700"}`}>
                                            {checkText}
                                          </span>
                                        </label>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* Contextual Recommendations Panel (reads active process context) */}
                                <div className="bg-[#FAF9F5] border border-gray-250 p-4 space-y-2.5 text-left rounded-none">
                                  <span className="text-[9px] font-mono font-bold text-gray-500 block uppercase">RECOMENDAÇÃO INTELIGENTE PARA A MINHA OPERAÇÃO</span>
                                  {selectedBpmPhase === "PLANEJAMENTO" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>O processo analisado <strong className="text-gray-950 font-bold">"{analysisResult.process.name}"</strong> está na área de <strong className="text-gray-950 font-bold">{analysisResult.process.area}</strong> sob responsabilidade de <strong className="text-gray-950 font-bold">{analysisResult.process.owner}</strong>.</p>
                                      <p className="mt-1.5 text-indigo-750 font-black">Ação sugerida: Validar o escopo do Project Charter para que o principal gargalo de <strong>"{analysisResult.process.pain_points.split(',')[0]}"</strong> e o risco de <strong>"{analysisResult.process.risks.split(',')[0]}"</strong> sejam o foco de transição!</p>
                                    </div>
                                  )}
                                  {selectedBpmPhase === "ANALISE" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>No estado atual, contabilizamos <strong className="text-gray-950 font-bold">{analysisResult.process.rework_percentage}% de retrabalho</strong>.</p>
                                      <p className="mt-1 text-rose-800 font-bold">Principais hipóteses de Causa Raiz para investigar durante esta Análise:</p>
                                      <ul className="list-disc pl-4 mt-1 text-gray-700 space-y-0.5">
                                        {ci.root_cause_hypotheses.slice(0, 2).map((h, idx) => (
                                          <li key={idx}>{h}</li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                  {selectedBpmPhase === "DESENHO" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>Projete seu estado futuro considerando o suporte de interfaces. Sugestão E3I:</p>
                                      <ul className="list-disc pl-4 mt-1 text-gray-700 space-y-0.5">
                                        <li>Substituir planilhas manuais pela centralização no <strong>{analysisResult.process.systems.split(',')[0]}</strong>.</li>
                                        <li>Redesenhar as transições para os momentos com alta insatisfação identificados.</li>
                                      </ul>
                                    </div>
                                  )}
                                  {selectedBpmPhase === "IMPLEMENTACAO" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>Roteiro recomendado para implementar e mitigar desconfianças na transição para o TO-BE:</p>
                                      <ol className="list-decimal pl-4 mt-1 text-gray-700 space-y-1">
                                        {ci.actions.slice(0, 2).map((act, idx) => (
                                          <li key={idx}>
                                            <strong className="text-gray-950">{act.title}: </strong>
                                            <span>{act.why} Responsável: {act.suggested_owner}.</span>
                                          </li>
                                        ))}
                                      </ol>
                                    </div>
                                  )}
                                  {selectedBpmPhase === "MONITORAMENTO" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>Estabeleça as saídas para monitoramento de eficácia ("Fazer as coisas certas"). Indicadores recomendados para implantar:</p>
                                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                                        {ci.suggested_kpis.map((kpi, idx) => (
                                          <span key={idx} className="bg-white border text-indigo-750 border-[#1A1A1A]/10 px-2 py-0.5 text-[9px] font-mono font-bold rounded-xs">
                                            📊 {kpi}
                                          </span>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                  {selectedBpmPhase === "REFINAMENTO" && (
                                    <div className="text-[10.5px] text-gray-800 leading-relaxed font-sans">
                                      <p>Evite o declínio natural do processo no decorrer dos anos através de rigor metodológico:</p>
                                      <p className="mt-1 text-indigo-750 font-bold">Ação sugerida: Tratar cada quick win em reuniões mensais de retroalimentação baseada nas estatísticas do lóbulo de monitoramento.</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })()}
                        </div>

                      </div>
                    </div>
                  )}

                  {activeTab === "graph" && ci && (
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono font-bold text-gray-500 uppercase block">Fluxo Seqüencial de Atividades Onboardedas no MVP</span>
                        <h4 className="font-serif text-sm font-black text-gray-950 uppercase">Bancada de Modelos de Transformação</h4>
                      </div>

                      <div className="flex flex-col md:flex-row flex-wrap items-stretch gap-4 justify-start pt-3">
                        {splitLines(analysisResult.process.steps).map((st, i, arr) => (
                          <React.Fragment key={i}>
                            <div className="bg-gray-50 border-2 border-[#1A1A1A] p-3.5 flex flex-col justify-between w-full md:w-36 shadow-sm select-none relative hover:border-amber-500 transition-colors">
                              <div className="space-y-1">
                                <span className="text-[7.5px] font-mono text-gray-400 block font-bold">ETAPA {i + 1}</span>
                                <div className="text-[10px] font-extrabold text-gray-900 leading-snug">{st}</div>
                              </div>
                              <div className="mt-3 flex items-center justify-between text-[8px] font-mono text-gray-400">
                                <span>Yield: 99%</span>
                                <span>Setup: {i === 0 ? "10m" : "0m"}</span>
                              </div>
                            </div>
                            {i < arr.length - 1 && (
                              <div className="hidden md:flex items-center justify-center text-gray-400 select-none animate-pulse">
                                <ArrowRight size={14} className="text-[#C49746]" />
                              </div>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              </div>

              {/* Premises Used */}
              <div className="bg-gray-100/60 p-4 border border-gray-200 text-xs font-sans space-y-2 text-left">
                <h5 className="font-serif font-black text-[11px] text-gray-750 uppercase">🔮 Premissas Operacionais Adotadas</h5>
                <ul className="list-disc pl-4.5 space-y-1 text-gray-600 text-[10px]">
                  {analysisResult.assumptions.map((as, i) => (
                    <li key={i}>{as}</li>
                  ))}
                </ul>
              </div>

            </div>
          ) : (
            <div className="h-full min-h-[460px] flex flex-col items-center justify-center text-center p-8 bg-white border-2 border-dashed border-[#1A1A1A]/20">
              <span className="text-3xl block filter animate-bounce mb-3">🧭</span>
              <h4 className="font-serif text-base font-black text-gray-950 uppercase tracking-tight">Painel de Insights Vazio</h4>
              <p className="text-xs text-gray-500 font-sans mt-0.5 max-w-sm">
                Nenhum onboarding processado ainda. Carregue uma entrevista de exemplo ou escreva a história da sua operação ao lado e clique em "Analisar Processo" para preencher a inteligência!
              </p>
            </div>
          )}
        </div>

      </div>
      </>
      )}

      {feedbackMsg && (
        <div className={`p-4 border-2 text-xs font-mono font-bold text-left animate-fade-in ${
          feedbackMsg.type === "success" 
            ? "bg-emerald-50 border-emerald-500 text-emerald-800" 
            : "bg-rose-50 border-rose-500 text-rose-800"
        }`}>
          {feedbackMsg.type === "success" ? "✓" : "⚠️"} {feedbackMsg.text}
        </div>
      )}

    </div>
  );
}
