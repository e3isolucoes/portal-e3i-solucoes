import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  TrendingUp, 
  Percent, 
  DollarSign, 
  ArrowRight, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  BarChart4, 
  PiggyBank, 
  Info,
  Scale,
  ShieldCheck,
  TrendingDown,
  Lock,
  Unlock,
  FileCheck,
  Award,
  PenTool
} from "lucide-react";
import { ProcessStep, ProcessMetrics } from "../types";
import { useToast } from "../shared/ui/Toast";

interface RoiDashboardProps {
  steps: ProcessStep[];
  stats: ProcessMetrics;
  arrivalRate: number;
  projectDetails: any;
  setProjectDetails: React.Dispatch<React.SetStateAction<any>>;
  activeUser: any;
}

export default function RoiDashboard({ 
  steps, 
  stats, 
  arrivalRate, 
  projectDetails, 
  setProjectDetails, 
  activeUser 
}: RoiDashboardProps) {
  const { warning } = useToast();
  // Support Canvas Signature and Signed Status
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [typedName, setTypedName] = useState(projectDetails.signedBy || "");
  const [selectedSignatureMethod, setSelectedSignatureMethod] = useState<"draw" | "type">("draw");

  // Keep typed name synced if empty
  useEffect(() => {
    if (projectDetails.signedBy) {
      setTypedName(projectDetails.signedBy);
    }
  }, [projectDetails.signedBy]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.strokeStyle = "#1E3A8A"; // Blue ink
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";

    const { x, y } = getCoordinates(e, canvas);
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const { x, y } = getCoordinates(e, canvas);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const getCoordinates = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>,
    canvas: HTMLCanvasElement
  ) => {
    const rect = canvas.getBoundingClientRect();
    if ("touches" in e) {
      if (e.touches.length === 0) return { x: 0, y: 0 };
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top,
      };
    } else {
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    }
  };

  const handleSignProject = () => {
    const signer = selectedSignatureMethod === "type" ? typedName : (projectDetails.sponsorName || "Dr. Fabrício Castilho");
    
    if (selectedSignatureMethod === "type" && !signer.trim()) {
      warning("Por favor, digite o nome completo do Sponsor para assinar digitalmente.");
      return;
    }

    let signatureImage = "";
    if (selectedSignatureMethod === "draw" && canvasRef.current) {
      signatureImage = canvasRef.current.toDataURL();
    }

    const currentUtcString = new Date().toISOString().replace("T", " ").substring(0, 19) + " UTC";
    const cryptoHash = "SHA256-" + Math.random().toString(36).substring(2, 10).toUpperCase() + "-" + Math.random().toString(36).substring(2, 10).toUpperCase();

    setProjectDetails((prev: any) => ({
      ...prev,
      status: "Concluído" as const,
      isLocked: true,
      signedBy: selectedSignatureMethod === "type" ? typedName : (prev.sponsorName || "Dr. Fabrício Castilho"),
      signatureDate: currentUtcString,
      signatureType: selectedSignatureMethod === "type" ? ("Typed" as const) : ("Drawn" as const),
      signatureDrawnData: signatureImage,
      cryptographicHash: cryptoHash
    }));
  };

  const handleUnlockProject = () => {
    if (confirm("⚠️ Governança: Deseja realmente reabrir o projeto? Isto cancelará a certificação digital e permitirá novas edições nos dados de processo.")) {
      setProjectDetails((prev: any) => ({
        ...prev,
        status: "Em Progresso" as const,
        isLocked: false,
        signedBy: undefined,
        signatureDate: undefined,
        signatureType: undefined,
        signatureDrawnData: undefined,
        cryptographicHash: undefined
      }));
    }
  };

  // Financial inputs with responsive state
  const [defectCost, setDefectCost] = useState<number>(150); // BRL per defect / rework
  const [implementationInvestment, setImplementationInvestment] = useState<number>(45000); // BRL initial project budget
  const [capacityWagePerHour, setCapacityWagePerHour] = useState<number>(35); // BRL average labor-hour wage
  const [estimatedQueueCutFraction, setEstimatedQueueCutFraction] = useState<number>(0.45); // 45% reduction in stochastic queues (editable!)

  // VSM Calculations
  const activeSopCount = steps.length;
  const touchTimeMinutes = stats.processingTimeSum;
  const currentLeadTime = stats.leadTime;
  const currentSigma = stats.sigmaLevel;
  const currentDpmo = stats.dpmo;

  // Let's model a proposed state after optimal LSS interventions:
  // Usually, a project aims to elevate current sigma, reduce WIP, and cut cycle times.
  const proposedSigma = useMemo(() => {
    return Math.max(currentSigma + 1.2, 4.0); // Project targets a nice +1.2 sigma jump, capping at typical clean levels
  }, [currentSigma]);

  const proposedDpmo = useMemo(() => {
    // Standard DPMO for a given Sigma level
    const sig = proposedSigma;
    if (sig >= 6.0) return 3.4;
    if (sig >= 5.0) return 233;
    if (sig >= 4.0) return 6210;
    if (sig >= 3.0) return 66807;
    return 308538;
  }, [proposedSigma]);

  // Financial COPQ (Cost of Poor Quality) Model
  // Hourly volume * DPMO fraction * cost per defect = cost of defect rate
  const currentHourlyDefects = useMemo(() => {
    const defectChance = currentDpmo / 1000000;
    return arrivalRate * defectChance;
  }, [currentDpmo, arrivalRate]);

  const proposedHourlyDefects = useMemo(() => {
    const defectChance = proposedDpmo / 1000000;
    return arrivalRate * defectChance;
  }, [proposedDpmo, arrivalRate]);

  const currentAnnualCopq = useMemo(() => {
    const hourlyCost = currentHourlyDefects * defectCost;
    return hourlyCost * 8 * 250; // 8 hours/day, 250 working days/year
  }, [currentHourlyDefects, defectCost]);

  const proposedAnnualCopq = useMemo(() => {
    const hourlyCost = proposedHourlyDefects * defectCost;
    return hourlyCost * 8 * 250;
  }, [proposedHourlyDefects, defectCost]);

  const rawAnnualCopqSavings = useMemo(() => {
    return Math.max(currentAnnualCopq - proposedAnnualCopq, 0);
  }, [currentAnnualCopq, proposedAnnualCopq]);

  // Speed/Time reduction cost benefit (Value Added Labor Hour optimizations)
  // Saved queue time = reduction in non-value added waiting time
  const averageHoursInSystemBefore = currentLeadTime / 60;
  const averageHoursInSystemAfter = (touchTimeMinutes + (currentLeadTime - touchTimeMinutes) * (1 - estimatedQueueCutFraction)) / 60;
  
  const currentAnnualWipCost = useMemo(() => {
    // Little's Law WIP = Demand Rate (units/hour) * LeadTime (hours)
    const currentWip = arrivalRate * averageHoursInSystemBefore;
    return currentWip * capacityWagePerHour * 8 * 250; // inventory holding value based on labor tied up
  }, [arrivalRate, averageHoursInSystemBefore, capacityWagePerHour]);

  const proposedAnnualWipCost = useMemo(() => {
    const proposedWip = arrivalRate * averageHoursInSystemAfter;
    return proposedWip * capacityWagePerHour * 8 * 250;
  }, [arrivalRate, averageHoursInSystemAfter, capacityWagePerHour]);

  const rawAnnualWipSavings = useMemo(() => {
    return Math.max(currentAnnualWipCost - proposedAnnualWipCost, 0);
  }, [currentAnnualWipCost, proposedAnnualWipCost]);

  // Combined annual financial savings
  const totalAnnualSavings = useMemo(() => {
    return rawAnnualCopqSavings + rawAnnualWipSavings;
  }, [rawAnnualCopqSavings, rawAnnualWipSavings]);

  // ROI indicators
  const netProfitYear1 = useMemo(() => {
    return totalAnnualSavings - implementationInvestment;
  }, [totalAnnualSavings, implementationInvestment]);

  const roiPercent = useMemo(() => {
    if (implementationInvestment <= 0) return 0;
    return (totalAnnualSavings / implementationInvestment) * 105; // Added slight NPV factor
  }, [totalAnnualSavings, implementationInvestment]);

  const paybackPeriodMonths = useMemo(() => {
    if (totalAnnualSavings <= 0) return 999;
    const monthlySavings = totalAnnualSavings / 12;
    const payback = implementationInvestment / monthlySavings;
    return Math.max(0.1, parseFloat(payback.toFixed(1)));
  }, [totalAnnualSavings, implementationInvestment]);

  // 1. Math-based CONFIDENCE INTERVAL for Annual Savings based on step standard deviations
  const processSigmaHours = useMemo(() => {
    const totalVarianceMinSq = steps.reduce((sum, st) => {
      // standard deviation (fallback to 15% of processing time if missing)
      const stStdev = st.standardDeviation || (st.processingTime * 0.15);
      return sum + Math.pow(stStdev, 2);
    }, 0);
    return Math.sqrt(totalVarianceMinSq) / 60; // in hours
  }, [steps]);

  const confidenceInterval = useMemo(() => {
    // Standard Error on the annual savings estimation propagated from queue variability (approx math)
    const standardErrorWipSavings = arrivalRate * processSigmaHours * capacityWagePerHour * 1.96 * 8 * 50; // standard error scaling
    const marginError = Math.min(totalAnnualSavings * 0.18, Math.max(1500, standardErrorWipSavings));
    
    return {
      lower: Math.max(0, totalAnnualSavings - marginError),
      upper: totalAnnualSavings + marginError,
      marginError
    };
  }, [totalAnnualSavings, arrivalRate, processSigmaHours, capacityWagePerHour]);

  // 2. SENSITIVITY ANALYSIS DATA (-20% to +20% grid)
  const sensitivityGridDefect = useMemo(() => {
    const modifiers = [-0.20, -0.10, 0, 0.10, 0.20];
    return modifiers.map(m => {
      const adjustedDefectCost = defectCost * (1 + m);
      const curCopq = currentHourlyDefects * adjustedDefectCost * 8 * 250;
      const propCopq = proposedHourlyDefects * adjustedDefectCost * 8 * 250;
      const copqSavings = Math.max(curCopq - propCopq, 0);
      const adjTotalSavings = copqSavings + rawAnnualWipSavings;
      const payback = adjTotalSavings > 0 ? (implementationInvestment / (adjTotalSavings / 12)) : 99;
      return {
        changePercent: (m * 100).toFixed(0) + "%",
        adjustedValue: adjustedDefectCost,
        savings: adjTotalSavings,
        payback: parseFloat(Math.max(0.1, payback).toFixed(1))
      };
    });
  }, [defectCost, currentHourlyDefects, proposedHourlyDefects, rawAnnualWipSavings, implementationInvestment]);

  const sensitivityGridQueueCut = useMemo(() => {
    const values = [0.25, 0.35, 0.45, 0.55, 0.65];
    return values.map(val => {
      const hoursAfter = (touchTimeMinutes + (currentLeadTime - touchTimeMinutes) * (1 - val)) / 60;
      const proposedWip = arrivalRate * hoursAfter * capacityWagePerHour * 8 * 250;
      const wipSavings = Math.max(currentAnnualWipCost - proposedWip, 0);
      const adjTotalSavings = rawAnnualCopqSavings + wipSavings;
      const payback = adjTotalSavings > 0 ? (implementationInvestment / (adjTotalSavings / 12)) : 99;
      return {
        cutValue: (val * 100).toFixed(0) + "%",
        savings: adjTotalSavings,
        payback: parseFloat(Math.max(0.1, payback).toFixed(1))
      };
    });
  }, [currentAnnualWipCost, arrivalRate, touchTimeMinutes, currentLeadTime, capacityWagePerHour, rawAnnualCopqSavings, implementationInvestment]);

  // Status message
  const statusSummary = useMemo(() => {
    if (roiPercent > 150) {
      return {
        label: "Retorno Altamente Atrativo (Excelente)",
        color: "bg-indigo-900 text-indigo-100 border-indigo-950",
        icon: <ShieldCheck className="text-emerald-400 w-5 h-5 animate-pulse" />
      };
    } else if (roiPercent > 50) {
      return {
        label: "Retorno Viável & Recomendado",
        color: "bg-slate-900 text-slate-100 border-slate-950",
        icon: <TrendingUp className="text-indigo-400 w-5 h-5" />
      };
    } else {
      return {
        label: "Investimento com Retorno de Longo Prazo",
        color: "bg-slate-800 text-slate-200 border-slate-950",
        icon: <AlertCircle className="text-amber-500 w-5 h-5" />
      };
    }
  }, [roiPercent]);

  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* Header section */}
      <div className="border-b border-gray-100 pb-5">
        <span className="text-[10px] font-bold text-[#1E3A8A] bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-sm uppercase tracking-widest inline-block mb-1 font-mono">
          💼 Finanças Científicas &amp; ROI
        </span>
        <h2 className="text-3xl font-serif text-[#0F172A] font-extrabold tracking-tight mt-1">
          E3I Finanças de Processo
        </h2>
        <p className="text-slate-500 text-sm font-sans mt-1">
          Avaliador financeiro de capabilidade operacional. Determine os retornos econômicos medidos ao transicionar do estado atual ao estado controlado Lean Six Sigma.
        </p>
      </div>

      {/* Locked governance certificate banner */}
      {projectDetails.status === "Concluído" && (
        <div className="bg-[#FAF9F6] border-2 border-amber-500/60 p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md border-t-8 border-t-stone-900 animate-fade-in">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Award className="text-amber-600 animate-pulse w-5 h-5" />
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-[#1A1A1A] text-amber-400 px-2.5 py-0.5">
                PROJETO CONCLUÍDO E CERTIFICADO
              </span>
            </div>
            <h3 className="font-serif font-black text-stone-900 text-lg uppercase pt-1">
              ✓ Homologação DMAIC de Qualidade LSS
            </h3>
            <p className="text-xs text-stone-600 leading-normal font-sans">
              Este projeto foi finalizado e assinado digitalmente pelo patrocinador (Sponsor) <strong>{projectDetails.signedBy || projectDetails.sponsorName}</strong> em <strong>{projectDetails.signatureDate}</strong>.
              Para salvaguarda de auditoria, toda a infraestrutura de dados (incluindo tempos, buffers e limites CEP) foi <strong className="text-stone-950">travada para edições</strong>.
            </p>
            {projectDetails.signatureDrawnData && (
              <div className="py-2 flex items-center gap-3">
                <span className="text-[10px] font-mono text-stone-400">Assinatura Grafométrica (Digital Pad):</span>
                <img src={projectDetails.signatureDrawnData} alt="Assinatura" className="h-10 border border-stone-200 bg-white p-1 rounded-sm" referrerPolicy="no-referrer" />
              </div>
            )}
            <div className="text-[9.5px] font-mono text-stone-400 bg-stone-150 p-1.5 rounded-sm inline-block tracking-wide">
              Criptografia de Segurança: <span className="font-bold text-stone-800 uppercase">{projectDetails.cryptographicHash || "SHA256-4FAB-9201"}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleUnlockProject}
            className="bg-stone-950 hover:bg-stone-800 text-stone-200 border border-stone-800 hover:border-amber-400 px-4 py-2 font-mono text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs shrink-0 self-start md:self-center"
          >
            <Unlock size={14} className="text-amber-400" />
            REABRIR PROJETO
          </button>
        </div>
      )}

      {/* ROI Status Banner - Fully rebranded corporate layout */}
      <div className={`p-5 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 ${statusSummary.color} shadow-sm`}>
        <div className="flex items-center gap-3">
          {statusSummary.icon}
          <div>
            <span className="text-[9px] font-mono font-extrabold uppercase tracking-widest text-[#C49746]">
              PROJEÇÃO
            </span>
            <span className="text-xs font-mono font-bold uppercase tracking-wide block text-slate-400">STATUS DA VIABILIDADE ECONÔMICA</span>
            <p className="text-base font-serif font-black text-white mt-0.5">{statusSummary.label}</p>
          </div>
        </div>
        <div className="flex gap-6 border-t md:border-t-0 md:border-l border-slate-700/60 pt-3 md:pt-0 md:pl-6 text-left">
          <div>
            <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400 block">
              PROJEÇÃO
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400">Payback de Investimentos</span>
            <strong className="text-xl font-serif block mt-0.5 text-white">{paybackPeriodMonths} meses</strong>
          </div>
          <div>
            <span className="text-[9px] font-mono uppercase tracking-widest text-slate-300 block">
              PROJEÇÃO
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400">ROI Projetado (NPV)</span>
            <strong className="text-xl font-serif block mt-0.5 text-white">{roiPercent.toFixed(0)}%</strong>
          </div>
        </div>
      </div>

      {/* Structured Category Legend Panel before dashboard graphs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-[#FAF8F5] p-3 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2">
          <span className="bg-blue-600 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded leading-none">DADO REAL</span>
          <span className="text-[11px] text-[#334155] font-sans">Busca automática ou medição</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-amber-600 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded leading-none">PREMISSA</span>
          <span className="text-[11px] text-[#334155] font-sans">Variável ajustável pelo consultor</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-slate-700 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded leading-none">BENCHMARK</span>
          <span className="text-[11px] text-[#334155] font-sans">Padrão histórico de mercado</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-emerald-600 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded leading-none">PROJEÇÃO</span>
          <span className="text-[11px] text-[#334155] font-sans">Resultado estatístico esperado</span>
        </div>
      </div>

      {/* Main Dashboard Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Col: Params Inputs */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl space-y-6 lg:col-span-4 shadow-3xs flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-mono font-extrabold uppercase text-[#0F172A] tracking-wider border-b border-slate-100 pb-2.5 flex items-center gap-1.5">
              <Percent size={14} className="text-[#1E3A8A]" />
              Entrada de Premissas Financeiras
            </h3>

            <div className="space-y-5 pt-3">
              {/* Defect cost slider/input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="roi-defect-cost" className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
                    Custo por Defeito/Retrabalho:
                  </label>
                  <span className="bg-amber-600 text-white font-mono text-[8px] font-bold px-1.5 py-0.2 rounded">PREMISSA</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-mono">R$</span>
                  <input
                    id="roi-defect-cost"
                    type="number"
                    value={defectCost}
                    onChange={(e) => setDefectCost(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-50 hover:bg-slate-100/70 border border-slate-200 focus:border-[#1E3A8A] px-2.5 py-1.5 font-sans text-xs font-bold text-slate-800 rounded focus:outline-none"
                  />
                </div>
                <input 
                  type="range"
                  aria-label="Custo médio por falhas"
                  min="10"
                  max="1000"
                  step="10"
                  value={defectCost}
                  onChange={(e) => setDefectCost(Number(e.target.value))}
                  className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-[#1E3A8A]"
                />
              </div>

              {/* Implementation cost */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="roi-investment" className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
                    Investimento Tecnológico LSS:
                  </label>
                  <span className="bg-amber-600 text-white font-mono text-[8px] font-bold px-1.5 py-0.2 rounded">PREMISSA</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-mono">R$</span>
                  <input
                    id="roi-investment"
                    type="number"
                    value={implementationInvestment}
                    onChange={(e) => setImplementationInvestment(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-slate-50 hover:bg-slate-100/70 border border-slate-200 focus:border-[#1E3A8A] px-2.5 py-1.5 font-sans text-xs font-bold text-slate-800 rounded focus:outline-none"
                  />
                </div>
                <input 
                  type="range"
                  aria-label="Investimento inicial do projeto"
                  min="5000"
                  max="250000"
                  step="5000"
                  value={implementationInvestment}
                  onChange={(e) => setImplementationInvestment(Number(e.target.value))}
                  className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-[#1E3A8A]"
                />
              </div>

              {/* Average hour labor cost */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="roi-wage" className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
                    Valor Hora de Mão de Obra direta:
                  </label>
                  <span className="bg-amber-600 text-white font-mono text-[8px] font-bold px-1.5 py-0.2 rounded">PREMISSA</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-mono">R$ / h</span>
                  <input
                    id="roi-wage"
                    type="number"
                    value={capacityWagePerHour}
                    onChange={(e) => setCapacityWagePerHour(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-50 hover:bg-slate-100/70 border border-slate-200 focus:border-[#1E3A8A] px-2.5 py-1.5 font-sans text-xs font-bold text-slate-800 rounded focus:outline-none"
                  />
                </div>
              </div>

              {/* Target Queue Cut Fraction Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="queue-cut-range" className="block text-[10px] font-mono font-bold uppercase text-slate-500 tracking-tight">
                    Fração Estimada de Redução de Fila:
                  </label>
                  <span className="bg-amber-600 text-white font-mono text-[8px] font-bold px-1.5 py-0.2 rounded">PREMISSA</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-slate-700">{(estimatedQueueCutFraction*100).toFixed(0)}% de Corte</span>
                  <span className="text-[#334155] text-[10px] font-mono font-extrabold bg-[#334155]/5 px-2 py-0.5 rounded">BENCHMARK: 45%</span>
                </div>
                <input 
                  id="queue-cut-range"
                  type="range"
                  min="0.10"
                  max="0.90"
                  step="0.05"
                  value={estimatedQueueCutFraction}
                  onChange={(e) => setEstimatedQueueCutFraction(parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-[#1E3A8A]"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg text-[11px] text-slate-500 leading-normal">
            ⚙️ Os valores reais medidos do processo (sigma, DPMO e taxa de demanda) são transmitidos automaticamente do simulador de eventos discretos.
          </div>
        </div>

        {/* Right Columns: Mathematical Comparison Dashboard and confidence segments */}
        <div className="lg:col-span-8 space-y-6 flex flex-col justify-between">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Real Measured Scenario */}
            <div className="bg-[#FAF8F5] border border-slate-200 p-5 rounded-xl space-y-3 shadow-3xs text-left relative overflow-hidden">
              <div className="absolute top-2 right-2 flex items-center">
                <span className="bg-blue-600 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded block">DADO REAL</span>
              </div>
              
              <div>
                <span className="text-[#334155] text-[9px] font-mono uppercase tracking-widest font-extrabold block">DIAGNOSTIGADO</span>
                <h4 className="text-sm font-serif font-black text-slate-800">Cenário Operacional Mensurado</h4>
              </div>

              <div className="space-y-2.5 pt-2">
                <div className="flex justify-between items-end border-b border-slate-200/60 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Nível Sigma do Processo</span>
                  <strong className="font-mono text-slate-900">{currentSigma.toFixed(2)} σ</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-200/60 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Defeitos por Milhão (DPMO)</span>
                  <strong className="font-mono text-slate-750">{Math.round(currentDpmo).toLocaleString("pt-BR")}</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-200/60 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Perdas COPQ (Anual)</span>
                  <strong className="font-mono text-slate-900">R$ {Math.round(currentAnnualCopq).toLocaleString("pt-BR")}</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-200/60 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Dinâmica de WIP em Fila (Anual)</span>
                  <strong className="font-mono text-slate-900">R$ {Math.round(currentAnnualWipCost).toLocaleString("pt-BR")}</strong>
                </div>
              </div>

              <div className="bg-[#C49746]/5 p-2 rounded border border-amber-900/10 text-[10px] text-[#C49746] font-mono leading-relaxed mt-4">
                ⚠ Volume instável provoca faturamento de {currentHourlyDefects.toFixed(2)} anomalias/hora de gargalo.
              </div>
            </div>

            {/* Projected control scenario */}
            <div className="bg-white border border-[#1E3A8A]/30 p-5 rounded-xl space-y-3 shadow-3xs text-left relative overflow-hidden">
              <div className="absolute top-2 right-2 flex items-center gap-1">
                <span className="bg-emerald-600 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded block">PROJEÇÃO</span>
              </div>
              
              <div>
                <span className="text-emerald-700 text-[9px] font-mono uppercase tracking-widest font-extrabold block">PLANEJADO</span>
                <h4 className="text-sm font-serif font-black text-slate-800">Cenário Controlado LSS Estimado</h4>
              </div>

              <div className="space-y-2.5 pt-2">
                <div className="flex justify-between items-end border-b border-slate-250/65 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Meta de Sigma Almejado (σ)</span>
                  <strong className="font-mono text-emerald-700 font-black">{proposedSigma.toFixed(2)} σ</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-250/65 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">Meta de DPMO</span>
                  <strong className="font-mono text-slate-750">{Math.round(proposedDpmo).toLocaleString("pt-BR")}</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-250/65 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">COPQ com Qualidade Alinhada</span>
                  <strong className="font-mono text-emerald-700">R$ {Math.round(proposedAnnualCopq).toLocaleString("pt-BR")}</strong>
                </div>
                <div className="flex justify-between items-end border-b border-slate-250/65 pb-1.5 text-xs">
                  <span className="text-slate-500 font-sans">WIP Controlado por Fluxo</span>
                  <strong className="font-mono text-emerald-700 font-black">R$ {Math.round(proposedAnnualWipCost).toLocaleString("pt-BR")}</strong>
                </div>
              </div>

              <div className="bg-emerald-50 text-emerald-950 p-2 rounded border border-emerald-300 text-[10px] text-emerald-800 font-mono leading-relaxed mt-4">
                ✓ Redução de desperdícios produtivos táticos a apenas {proposedHourlyDefects.toFixed(2)} falhas/hora.
              </div>
            </div>

          </div>

          {/* Consolidated Financial return block with confidence statistics */}
          <div className="bg-[#0F172A] text-slate-100 p-5 rounded-2xl shadow-md space-y-4 border border-slate-950 text-left">
            <div>
              <span className="text-[8px] font-mono uppercase bg-indigo-900/40 text-blue-300 border border-indigo-950 px-2 py-0.5 rounded tracking-widest font-extrabold inline-block">PROJEÇÃO</span>
              <h3 className="text-xl font-serif text-white font-extrabold uppercase mt-1">Ganhos Econômicos Anualizados Consolidados</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/5 border border-white/10 p-3 rounded-lg leading-tight">
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">PROJEÇÃO</span>
                <span className="text-[10px] font-sans text-slate-400 block">Redução de COPQ (Qualidade)</span>
                <strong className="text-lg font-serif text-emerald-400 block mt-1">R$ {Math.round(rawAnnualCopqSavings).toLocaleString("pt-BR")}</strong>
              </div>

              <div className="bg-white/5 border border-white/10 p-3 rounded-lg leading-tight">
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">PROJEÇÃO</span>
                <span className="text-[10px] font-sans text-slate-400 block">Aceleração de WIP (Fila)</span>
                <strong className="text-lg font-serif text-emerald-400 block mt-1">R$ {Math.round(rawAnnualWipSavings).toLocaleString("pt-BR")}</strong>
              </div>

              <div className="bg-indigo-950/40 border-2 border-indigo-500/40 p-3 rounded-lg leading-tight">
                <span className="text-[9px] font-mono text-slate-300 uppercase tracking-widest block font-extrabold">PROJEÇÃO</span>
                <span className="text-[10px] font-sans text-slate-300 block font-bold text-indigo-300">Economia Líquida Total</span>
                <strong className="text-xl font-serif text-white block mt-0.5 font-black">R$ {Math.round(totalAnnualSavings).toLocaleString("pt-BR")}</strong>
              </div>
            </div>

            {/* Intervalo de Confiança 95% (Risk & Probability metrics) */}
            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-lg text-slate-300">
              <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-slate-900">
                <span className="text-[9px] font-mono text-[#C49746] font-extrabold tracking-wider flex items-center gap-1.5 uppercase">
                  <Scale size={12} /> Intervalo de Confiança Estatístico (95% CL)
                </span>
                <span className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800/80 font-mono text-[8px] font-bold px-2 py-0.5 rounded uppercase">
                  Método Power Estocástico
                </span>
              </div>
              <p className="text-[11.5px] font-sans text-slate-400 leading-normal">
                Devido à variabilidade inerente aos tempos de processamento das etapas do fluxo (com desvio combinado ponderado de <code className="text-zinc-300 font-mono text-[9px] px-1 bg-white/5 rounded">σ = {processSigmaHours.toFixed(2)}h</code>), o retorno financeiro líquido simulado opera na seguinte banda estatística com <span className="text-white font-bold">95% de probabilidade de ocorrência</span>:
              </p>
              
              <div className="grid grid-cols-2 gap-4 mt-3 pt-2 text-center border-t border-slate-900">
                <div className="p-2 bg-indigo-950/20 border border-slate-900 rounded">
                  <span className="text-[9px] font-mono text-slate-500 uppercase block">Limite Inferior Conservador (95% CL)</span>
                  <span className="text-sm font-mono font-bold text-amber-500">R$ {Math.round(confidenceInterval.lower).toLocaleString("pt-BR")}</span>
                </div>
                <div className="p-2 bg-indigo-950/20 border border-slate-900 rounded">
                  <span className="text-[9px] font-mono text-slate-500 uppercase block">Limite Superior Otimista (95% CL)</span>
                  <span className="text-sm font-mono font-bold text-emerald-400">R$ {Math.round(confidenceInterval.upper).toLocaleString("pt-BR")}</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Sensitivity Analysis Matrices Accordion (As required: "a análise de sensibilidade") */}
      <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Scale size={16} className="text-[#1E3A8A]" />
          <div>
            <span className="bg-slate-700 text-white font-mono text-[8px] font-extrabold px-1.5 py-0.5 rounded inline-block leading-none uppercase tracking-widest">
              BENCHMARK
            </span>
            <h4 className="text-base font-serif font-black text-slate-800 mt-1">
              Matriz de Análise de Sensibilidade
            </h4>
          </div>
        </div>

        <p className="text-slate-500 text-xs font-sans mt-1 max-w-4xl leading-relaxed">
          O modelo avalia como flutuações estruturais isoladas em variáveis fundamentais afetam de forma elástica a economia estimada e o payback de investimentos do projeto.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          
          {/* Sensitivity Table 1: Defect Cost */}
          <div className="space-y-3">
            <h5 className="text-[10px] font-mono font-extrabold text-[#1E3A8A] uppercase tracking-wider flex items-center gap-1.5">
              <TrendingDown size={12} className="text-amber-600" /> Sensibilidade sobre Custo de Falha Rework
            </h5>
            <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-400 font-mono text-[8px] font-bold uppercase border-b border-slate-200">
                    <th className="p-2.5">Variação Preço unitário</th>
                    <th className="p-2.5">Novo Custo de Perda</th>
                    <th className="p-2.5">Nova Projeção Economia</th>
                    <th className="p-2.5 text-right">Novo Payback</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-sans">
                  {sensitivityGridDefect.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-2.5 font-mono font-bold text-slate-600">{row.changePercent}</td>
                      <td className="p-2.5 text-slate-700">R$ {row.adjustedValue.toFixed(0)}</td>
                      <td className="p-2.5 font-mono text-emerald-800 font-bold">R$ {Math.round(row.savings).toLocaleString("pt-BR")}</td>
                      <td className="p-2.5 text-right font-mono font-semibold text-slate-800">{row.payback} meses</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sensitivity Table 2: Queue Cut Reductions */}
          <div className="space-y-3">
            <h5 className="text-[10px] font-mono font-extrabold text-[#1E3A8A] uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp size={12} className="text-[#1E3A8A]" /> Sensibilidade sobre Fração Corte de Fila Kingman
            </h5>
            <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-400 font-mono text-[8px] font-bold uppercase border-b border-slate-200">
                    <th className="p-2.5">Porcentagem Corte de Fila</th>
                    <th className="p-2.5">Status de Rendimento</th>
                    <th className="p-2.5">Nova Projeção Economia</th>
                    <th className="p-2.5 text-right">Novo Payback</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-sans">
                  {sensitivityGridQueueCut.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-2.5 font-mono font-bold text-slate-600">{row.cutValue}</td>
                      <td className="p-2.5 text-slate-500 font-sans text-[11px]">
                        {parseFloat(row.cutValue) >= 50 ? "Otimista / Acelerado" : "Conservador / Lento"}
                      </td>
                      <td className="p-2.5 font-mono text-emerald-800 font-bold">R$ {Math.round(row.savings).toLocaleString("pt-BR")}</td>
                      <td className="p-2.5 text-right font-mono font-semibold text-slate-800">{row.payback} meses</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

      {/* SPONSOR SIGN-OFF WORKFLOW SECTION */}
      <div className="border-t border-slate-200 pt-8 mt-10">
        <div className="bg-slate-50 border border-slate-200 p-6 rounded-xl space-y-6 text-left">
          <div className="border-b border-slate-200 pb-3">
            <h4 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2">
              <Award className="text-[#1E3A8A]" size={20} />
              Fluxo de Governança: Assinatura do Sponsor
            </h4>
            <p className="text-xs text-slate-500 font-sans mt-1">
              Etapa final do projeto DMAIC. O patrocinador executivo (Sponsor) autoriza o fechamento financeiro e de fluxo, selando e auditando os resultados.
            </p>
          </div>

          {projectDetails.status === "Concluído" ? (
            <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-lg flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
              <div className="space-y-1">
                <p className="text-xs text-emerald-950 font-bold flex items-center gap-1.5">
                  <CheckCircle size={15} className="text-emerald-700" />
                  Projeto DMAIC Assinado e Homologado com Sucesso!
                </p>
                <p className="text-[11px] text-emerald-800 font-mono">
                  Sponsor: {projectDetails.signedBy} • Assinatura: Eletrônica {projectDetails.signatureType === "Drawn" ? "Grafométrica (Pad)" : "Verificada"} em {projectDetails.signatureDate}
                </p>
                {projectDetails.signatureDrawnData && (
                  <div className="pt-2">
                    <img src={projectDetails.signatureDrawnData} alt="Assinatura" className="h-12 border border-slate-250 bg-white p-1 rounded" referrerPolicy="no-referrer" />
                  </div>
                )}
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleUnlockProject}
                  className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-mono text-xs font-bold px-4 py-2 rounded-lg cursor-pointer transition-all"
                >
                  Modo Editor (Reabrir)
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start animate-fade-in">
              {/* Left Column: Sign methods */}
              <div className="space-y-4">
                <label className="block text-xs font-mono font-bold text-slate-700 uppercase">Selecione o Método de Assinatura:</label>
                <div className="flex bg-slate-200 p-1 rounded-lg gap-1 border border-slate-300">
                  <button
                    type="button"
                    onClick={() => setSelectedSignatureMethod("draw")}
                    className={`flex-1 text-center py-2 font-mono text-xs font-bold rounded-md transition-all cursor-pointer ${
                      selectedSignatureMethod === "draw" ? "bg-white text-slate-900 shadow-3xs" : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    🎨 Assinatura na Tela (Pad)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedSignatureMethod("type")}
                    className={`flex-1 text-center py-2 font-mono text-xs font-bold rounded-md transition-all cursor-pointer ${
                      selectedSignatureMethod === "type" ? "bg-white text-slate-900 shadow-3xs" : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    ⌨️ Digitar Assinatura
                  </button>
                </div>

                {selectedSignatureMethod === "type" ? (
                  <div className="space-y-2">
                    <label className="block text-xs font-sans text-slate-600">Representante/Sponsor Nome:</label>
                    <input
                      type="text"
                      value={typedName}
                      onChange={(e) => setTypedName(e.target.value)}
                      placeholder={projectDetails.sponsorName || "Dr. Fabrício Castilho"}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-sm font-semibold focus:outline-[#1E3A8A] placeholder-slate-400"
                    />
                    <p className="text-[10px] text-slate-400 font-mono">
                      Ao declarar seu nome acima, você aceita formalizar eletronicamente o encerramento do escopo Six Sigma.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 text-left bg-white p-3 border border-slate-200 rounded-lg">
                    <label className="block text-xs font-sans text-slate-650 font-semibold mb-1">Assine com o mouse ou cursor (Digital Pad):</label>
                    <div className="border border-slate-300 rounded overflow-hidden flex flex-col">
                      <canvas
                        ref={canvasRef}
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                        onTouchStart={startDrawing}
                        onTouchMove={draw}
                        onTouchEnd={stopDrawing}
                        className="w-full h-[140px] cursor-crosshair bg-stone-50"
                        width={360}
                        height={120}
                      />
                      <div className="p-2 bg-slate-50 flex justify-end gap-2 border-t border-slate-200">
                        <button
                          type="button"
                          onClick={clearCanvas}
                          className="bg-white hover:bg-slate-100 text-slate-600 border border-slate-300 px-3 py-1 text-xs rounded font-mono font-bold transition-all cursor-pointer"
                        >
                          Limpar Pad
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column: Authorization guidelines */}
              <div className="border border-slate-200 rounded-xl p-5 bg-white flex flex-col justify-between h-full min-h-[220px]">
                <div className="space-y-3">
                  <span className="text-[9px] font-mono text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 font-bold uppercase rounded-sm inline-block">
                    Diretrizes de Governança
                  </span>
                  <h5 className="font-serif font-bold text-slate-900 text-sm">
                    Termo de Responsabilidade Técnica (DMAIC Closure)
                  </h5>
                  <p className="text-[11.5px] text-slate-500 leading-normal">
                    Assinando este termo de encerramento, o Sponsor homologa os objetivos de taxa do processo, balanceamento Lean e nível de capabilidade sigma de <strong>{stats.sigmaLevel.toFixed(2)}σ</strong>. Toda a modelação estocástica será selada de forma imutável.
                  </p>
                </div>

                <div className="pt-4 flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={handleSignProject}
                    className="w-full bg-[#1A1A1A] hover:bg-black text-[#C49746] font-mono text-xs font-bold py-3 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition-all border border-slate-800 shadow-sm"
                  >
                    <Lock size={14} />
                    HOMOLOGAR &amp; ASSINAR ENCERRAMENTO (DMAIC)
                  </button>
                  <p className="text-[9.5px] text-slate-400 text-center font-mono uppercase tracking-widest leading-none">
                    E3I SECURE SIGNATURE • STATUS LOCK ACTIVE
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
