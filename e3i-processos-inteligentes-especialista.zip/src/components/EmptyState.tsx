import React from "react";
import { 
  Building2, 
  Target, 
  Workflow, 
  RefreshCw, 
  Lock, 
  AlertOctagon, 
  AlertTriangle, 
  Clock, 
  CheckCircle2,
  HelpCircle,
  ShieldCheck,
  FileSpreadsheet
} from "lucide-react";

export type EmptyStateType = 
  | "no_company" 
  | "no_project" 
  | "no_process"
  | "loading"
  | "no_data"
  | "no_context"
  | "no_permission"
  | "error"
  | "partial_data"
  | "outdated_data"
  | "success"
  | "no_diagnostic"
  | "no_raci";

export interface EmptyStateAction {
  label: string;
  onClick: () => void;
}

interface EmptyStateProps {
  type: EmptyStateType;
  title?: string;
  message?: string;
  importance?: string;         // Business Importance ("Importância para o Negócio")
  nextAction?: string;         // Next Action ("Próxima Ação")
  primaryAction?: EmptyStateAction;
  secondaryAction?: EmptyStateAction;
  tertiaryAction?: EmptyStateAction;
  onRetry?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ 
  type, 
  title, 
  message, 
  importance,
  nextAction,
  primaryAction,
  secondaryAction,
  tertiaryAction,
  onRetry 
}) => {
  const configs = {
    no_company: {
      title: "Nenhuma Empresa Ativa",
      message: "Selecione uma empresa / cliente no seletor superior para acessar projetos, processos e indicadores operacionais.",
      icon: <Building2 className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-[#1A1A1A]/10 bg-amber-50/5"
    },
    no_project: {
      title: "Nenhum Projeto de Melhoria Ativo",
      message: "Selecione ou crie um projeto de melhoria LSS no seletor do topo para continuar.",
      icon: <Target className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-[#1A1A1A]/10 bg-slate-50/5"
    },
    no_diagnostic: {
      title: "Sem Diagnóstico Cadastrado",
      message: "Antes de reorganizar a empresa, precisamos entender onde estão os principais desalinhamentos.",
      importance: "Diagnosticar a empresa permite mapear as inconsistências reais da operação nos 7 eixos estratégicos para que as iniciativas não sejam baseadas em intuição, mas sim em dados e fatos reais de rentabilidade.",
      nextAction: "Responda ao questionário operacional guiado para gerar instantaneamente seu índice de maturidade e plano estratégico.",
      icon: <HelpCircle className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-amber-200 bg-amber-50/20"
    },
    no_process: {
      title: "Nenhum Processo Cadastrado",
      message: "Mapear processos ajuda a identificar gargalos, retrabalho e responsabilidades confusas.",
      importance: "Sem caminhos e tempos medidos, a organização perde velocidade na transição de tarefas e as decisões operacionais tomadas em nível de liderança geram atritos e perdas financeiras crônicas.",
      nextAction: "Mapeie seu fluxo, importe uma planilha de rotinas ou use um modelo pronto do simulador estruturado.",
      icon: <Workflow className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-indigo-200 bg-indigo-50/10"
    },
    no_raci: {
      title: "Sem Matriz RACI Definida",
      message: "Definir responsabilidades evita conflitos, atrasos e decisões sem dono.",
      importance: "Garante clareza absoluta sobre quem executa (R), quem aprova (A), e quem precisa opinar (C/I), extinguindo comitês excessivamente demorados e garantindo agilidade real de liderança.",
      nextAction: "Crie a primeira atividade da matriz ou gere as atribuições de forma autônoma baseada nos seus postos de trabalho cadastrados.",
      icon: <ShieldCheck className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-emerald-200 bg-emerald-50/10"
    },
    loading: {
      title: "Compilando subsistemas enxutos...",
      message: "Por favor, aguarde. Otimizando trajetórias Gaussianas e instanciando modelos estocásticos de fila.",
      icon: <RefreshCw className="h-10 w-10 text-indigo-650 animate-spin stroke-[1.5]" />,
      style: "border-indigo-100 bg-indigo-50/10"
    },
    no_data: {
      title: "Sem Dados Registrados",
      message: "Não identificamos nenhum registro na tabela atual. Adicione novas etapas ou aplique os modelos padrões.",
      icon: <AlertOctagon className="h-10 w-10 text-slate-400 stroke-[1.5]" />,
      style: "border-slate-200 bg-slate-50/30"
    },
    no_context: {
      title: "Aguardando Contexto Operacional",
      message: "Configure as metas corporativas ou mude de perfil no topo para liberar as análises integradas.",
      icon: <Building2 className="h-10 w-10 text-[#C49746] stroke-[1.5]" />,
      style: "border-amber-100 bg-amber-50/10"
    },
    no_permission: {
      title: "Acesso Bloqueado (RBAC)",
      message: "Seu cargo atual não possui privilégios para executar esta ação. Verifique as delegações temporárias de assinatura.",
      icon: <Lock className="h-10 w-10 text-rose-600 stroke-[1.5]" />,
      style: "border-rose-150 bg-rose-50/10"
    },
    error: {
      title: "Erro Inesperado na Simulação",
      message: "Não foi possível calcular o fluxo LSS. Pode haver loops infinitos nas etapas ou taxas de entrada inválidas.",
      icon: <AlertOctagon className="h-10 w-10 text-rose-600 stroke-[1.5]" />,
      style: "border-rose-200 bg-rose-50/10"
    },
    partial_data: {
      title: "Exibindo Dados Parciais",
      message: "Atenção: Algumas etapas não possuem tempos reais preenchidos. Usando estimativa padrão ajustada de 5 minutos.",
      icon: <AlertTriangle className="h-10 w-10 text-amber-550 stroke-[1.5]" />,
      style: "border-amber-200 bg-amber-50/10"
    },
    outdated_data: {
      title: "Simulação Desatualizada",
      message: "Os parâmetros do fluxo foram modificados. Re-execute o modelo de Monte Carlo para sintonizar as filas.",
      icon: <Clock className="h-10 w-10 text-slate-500 stroke-[1.5]" />,
      style: "border-slate-200 bg-slate-50/40"
    },
    success: {
      title: "Processo Aprovado & Selado",
      message: "Parabéns! Todas as etapas de melhoria dadas sob as metas SOX/DMAIC foram integralmente cumpridas com sucesso.",
      icon: <CheckCircle2 className="h-10 w-10 text-emerald-600 stroke-[1.5]" />,
      style: "border-emerald-200 bg-emerald-50/15"
    }
  };

  const current = configs[type] || configs.no_company;
  const displayTitle = title || current.title;
  const displayMessage = message || current.message;
  
  // Use config defaults if not provided via props
  const displayImportance = importance || (current as any).importance;
  const displayNextAction = nextAction || (current as any).nextAction;

  return (
    <div className={`p-6 md:p-10 text-left max-w-2xl mx-auto my-6 border rounded-xl shadow-sm transition-all duration-300 ${current.style}`}>
      
      {/* Icon and Title */}
      <div className="flex items-start gap-4 mb-5">
        <div className="w-14 h-14 bg-white border border-slate-100 rounded-lg flex items-center justify-center shadow-xs shrink-0">
          {current.icon}
        </div>
        <div>
          <h3 className="text-base font-sans font-black uppercase tracking-tight text-slate-900 leading-tight">
            {displayTitle}
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed mt-1">
            {displayMessage}
          </p>
        </div>
      </div>

      {/* Importance Section */}
      {displayImportance && (
        <div className="bg-white/60 p-4 border border-slate-100 rounded-lg mb-4 text-xs">
          <span className="block font-sans font-extrabold uppercase tracking-widest text-[#C49746] text-[9px] mb-1">
            Importância para o Negócio
          </span>
          <p className="text-slate-600 leading-relaxed">
            {displayImportance}
          </p>
        </div>
      )}

      {/* Next Action Section */}
      {displayNextAction && (
        <div className="bg-[#1A1A1A] text-slate-300 p-4 rounded-lg mb-6 text-xs border border-[#1A1A1A]">
          <span className="block font-sans font-extrabold uppercase tracking-widest text-amber-400 text-[9px] mb-1">
            Próxima Ação Sugerida
          </span>
          <p className="leading-relaxed">
            {displayNextAction}
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center gap-3">
        {primaryAction && (
          <button
            onClick={primaryAction.onClick}
            className="px-5 py-2.5 bg-[#C49746] hover:bg-[#B08434] text-white rounded-lg font-sans font-extrabold text-xs uppercase tracking-wider cursor-pointer shadow-xs transition-all"
          >
            {primaryAction.label}
          </button>
        )}

        {secondaryAction && (
          <button
            onClick={secondaryAction.onClick}
            className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-lg font-sans font-semibold text-xs uppercase tracking-wider cursor-pointer transition-all"
          >
            {secondaryAction.label}
          </button>
        )}

        {tertiaryAction && (
          <button
            onClick={tertiaryAction.onClick}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg font-sans font-semibold text-xs uppercase tracking-wider cursor-pointer transition-all"
          >
            {tertiaryAction.label}
          </button>
        )}

        {onRetry && !primaryAction && (
          <button
            onClick={onRetry}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-sans font-black text-xs uppercase tracking-wider cursor-pointer transition-all"
          >
            Tentar Novamente
          </button>
        )}
      </div>

    </div>
  );
};

export default EmptyState;
