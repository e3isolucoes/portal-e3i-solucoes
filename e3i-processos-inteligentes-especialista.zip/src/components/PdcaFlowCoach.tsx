import React, { useState, useMemo } from "react";
import { 
  Play, 
  CheckCircle, 
  TrendingUp, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  ArrowRight, 
  RotateCcw, 
  Sparkles, 
  X, 
  Compass, 
  CheckSquare, 
  Square,
  Award
} from "lucide-react";
import { PDCA_STEPS, PdcaStep } from "../data/pdcaSteps";

interface PdcaFlowCoachProps {
  currentWorkspaceView: string;
  setCurrentWorkspaceView: (view: any) => void;
  completedSteps: string[];
  setCompletedSteps: React.Dispatch<React.SetStateAction<string[]>>;
  cycleCount: number;
  setCycleCount: React.Dispatch<React.SetStateAction<number>>;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export default function PdcaFlowCoach({
  currentWorkspaceView,
  setCurrentWorkspaceView,
  completedSteps,
  setCompletedSteps,
  cycleCount,
  setCycleCount,
  isOpen,
  setIsOpen
}: PdcaFlowCoachProps) {
  const [expandedStepId, setExpandedStepId] = useState<string | null>("step-diagnostic");
  const [activeTab, setActiveTab] = useState<"ALL" | "P" | "D" | "C" | "A">("ALL");
  const [showCelebration, setShowCelebration] = useState(false);

  // Map of views to steps to auto-expand the step representing the current active view
  React.useEffect(() => {
    const matchedStep = PDCA_STEPS.find(s => s.targetView === currentWorkspaceView);
    if (matchedStep) {
      setExpandedStepId(matchedStep.id);
    }
  }, [currentWorkspaceView]);

  const toggleStepCompleted = (stepId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCompletedSteps(prev => 
      prev.includes(stepId) ? prev.filter(id => id !== stepId) : [...prev, stepId]
    );
  };

  const handleResetCycle = () => {
    setCompletedSteps([]);
    setCycleCount(prev => prev + 1);
    setShowCelebration(false);
    // Take back to step 1
    setCurrentWorkspaceView("DIAGNOSTIC");
  };

  const currentPhaseLetter = useMemo(() => {
    const matchedStep = PDCA_STEPS.find(s => s.targetView === currentWorkspaceView);
    return matchedStep ? matchedStep.phase : "P";
  }, [currentWorkspaceView]);

  const filteredSteps = useMemo(() => {
    if (activeTab === "ALL") return PDCA_STEPS;
    return PDCA_STEPS.filter(s => s.phase === activeTab);
  }, [activeTab]);

  const stats = useMemo(() => {
    const total = PDCA_STEPS.length;
    const completed = completedSteps.length;
    const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    // Group counts
    const pTotal = PDCA_STEPS.filter(s => s.phase === "P").length;
    const pDone = PDCA_STEPS.filter(s => s.phase === "P" && completedSteps.includes(s.id)).length;
    
    const dTotal = PDCA_STEPS.filter(s => s.phase === "D").length;
    const dDone = PDCA_STEPS.filter(s => s.phase === "D" && completedSteps.includes(s.id)).length;
    
    const cTotal = PDCA_STEPS.filter(s => s.phase === "C").length;
    const cDone = PDCA_STEPS.filter(s => s.phase === "C" && completedSteps.includes(s.id)).length;
    
    const aTotal = PDCA_STEPS.filter(s => s.phase === "A").length;
    const aDone = PDCA_STEPS.filter(s => s.phase === "A" && completedSteps.includes(s.id)).length;

    return {
      total,
      completed,
      pct,
      P: { done: pDone, total: pTotal },
      D: { done: dDone, total: dTotal },
      C: { done: cDone, total: cTotal },
      A: { done: aDone, total: aTotal }
    };
  }, [completedSteps]);

  return (
    <>
      {/* Floating Widget Toggle Trigger (Sits elegantly on the screen) */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed right-0 top-32 bg-slate-900 border-l border-y border-slate-700/60 text-white z-40 p-3 pr-4 rounded-l-2xl shadow-2xl transition-all hover:bg-slate-800 flex items-center gap-2 group cursor-pointer border-[#C49746]/40"
        title="Abrir o Copiloto Interativo de Roteiro PDCA"
      >
        <div className="relative">
          <RotateCcw className={`w-5 h-5 text-[#C49746] ${isOpen ? "animate-spin" : "group-hover:rotate-180 transition-transform duration-700"}`} />
          {stats.completed > 0 && (
            <span className="absolute -top-2 -right-2 bg-emerald-600 border border-slate-900 text-white font-mono text-[8.5px] font-bold rounded-full w-4 flex items-center justify-center h-4 shadow">
              {stats.completed}
            </span>
          )}
        </div>
        <div className="flex flex-col text-left">
          <span className="text-[10px] uppercase font-black tracking-tight font-mono text-slate-100">Guia PDCA</span>
          <span className="text-[8px] font-mono text-slate-400 font-semibold">{stats.pct}% Concluído</span>
        </div>
      </button>

      {/* Slide-out Sidebar Drawer */}
      <div 
        className={`fixed inset-y-0 right-0 w-full sm:w-[480px] bg-slate-950 border-l border-slate-800 text-slate-100 z-50 shadow-3xl flex flex-col transition-all duration-300 transform ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-slate-950 border border-[#C49746] flex items-center justify-center">
              <RotateCcw className="w-4 h-4 text-[#C49746] animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-xs font-mono font-black uppercase text-slate-150 tracking-wider">
                Copiloto de Fluxo PDCA
              </h3>
              <p className="text-[9.5px] text-slate-400 font-mono">
                Ciclo #{cycleCount} • Melhoria de Processo Contínua
              </p>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-800 hover:bg-slate-700 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-slate-350" />
          </button>
        </div>

        {/* PDCA Circular Wheel Component */}
        <div className="p-4 bg-slate-900/60 border-b border-slate-800/80">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            {/* Visual Mini Wheel */}
            <div className="md:col-span-5 flex justify-center">
              <div className="relative w-28 h-28 flex items-center justify-center">
                {/* SVG circular track with quadrants */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" fill="none" stroke="#1E293B" strokeWidth="10" />
                  
                  {/* Segment P: 0 to 25 */}
                  <circle cx="50" cy="50" r="40" fill="none" 
                    stroke={currentPhaseLetter === "P" ? "#C49746" : stats.P.done === stats.P.total ? "#10B981" : "#3B82F6"} 
                    strokeWidth="10" strokeDasharray="62.8 188.4" strokeDashoffset="0" 
                    className="transition-all duration-300"
                  />
                  {/* Segment D: 25 to 50 */}
                  <circle cx="50" cy="50" r="40" fill="none" 
                    stroke={currentPhaseLetter === "D" ? "#C49746" : stats.D.done === stats.D.total ? "#10B981" : "#3B82F6"} 
                    strokeWidth="10" strokeDasharray="62.8 188.4" strokeDashoffset="-62.8" 
                    className="transition-all duration-300"
                  />
                  {/* Segment C: 50 to 75 */}
                  <circle cx="50" cy="50" r="40" fill="none" 
                    stroke={currentPhaseLetter === "C" ? "#C49746" : stats.C.done === stats.C.total ? "#10B981" : "#3B82F6"} 
                    strokeWidth="10" strokeDasharray="62.8 188.4" strokeDashoffset="-125.6" 
                    className="transition-all duration-300"
                  />
                  {/* Segment A: 75 to 100 */}
                  <circle cx="50" cy="50" r="40" fill="none" 
                    stroke={currentPhaseLetter === "A" ? "#C49746" : stats.A.done === stats.A.total ? "#10B981" : "#3B82F6"} 
                    strokeWidth="10" strokeDasharray="62.8 188.4" strokeDashoffset="-188.4" 
                    className="transition-all duration-300"
                  />
                </svg>
                {/* Center text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-[9px] font-mono text-slate-400 font-bold uppercase leading-none">Ciclo</span>
                  <span className="text-xl font-black text-slate-100 font-mono leading-none mt-0.5">#{cycleCount}</span>
                  <span className="text-[8px] font-mono font-extrabold text-[#C49746] uppercase leading-none mt-1">{stats.pct}%</span>
                </div>
              </div>
            </div>

            {/* Quick Metrics & Segment Status */}
            <div className="md:col-span-7 space-y-2">
              <div className="flex justify-between text-[10px] font-mono">
                <span className="text-slate-400">Total de Progresso Geral:</span>
                <span className="font-bold text-[#C49746]">{stats.completed}/{stats.total} passos</span>
              </div>
              
              {/* Global Progress Bar */}
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-700/50">
                <div 
                  className="bg-gradient-to-r from-[#C49746] to-emerald-500 h-full transition-all duration-500 rounded-full"
                  style={{ width: `${stats.pct}%` }}
                ></div>
              </div>

              {/* Grid showing phase status */}
              <div className="grid grid-cols-4 gap-1 pt-1.5">
                {[
                  { phase: "P", label: "PLAN", stats: stats.P, active: currentPhaseLetter === "P" },
                  { phase: "D", label: "DO", stats: stats.D, active: currentPhaseLetter === "D" },
                  { phase: "C", label: "CHECK", stats: stats.C, active: currentPhaseLetter === "C" },
                  { phase: "A", label: "ACT", stats: stats.A, active: currentPhaseLetter === "A" }
                ].map(item => (
                  <div 
                    key={item.phase} 
                    className={`p-1.5 rounded text-center border transition-all ${
                      item.active 
                        ? "bg-slate-800 border-[#C49746] text-[#C49746]" 
                        : item.stats.done === item.stats.total 
                          ? "bg-emerald-950/40 border-emerald-800/40 text-emerald-400"
                          : "bg-slate-900 border-slate-800 text-slate-400"
                    }`}
                  >
                    <div className="text-[8px] font-black font-mono leading-none">{item.label}</div>
                    <div className="text-[10px] font-mono font-bold leading-none mt-1">{item.stats.done}/{item.stats.total}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Tabs */}
        <div className="px-4 py-2 border-b border-slate-800 bg-slate-950 flex gap-1 overflow-x-auto">
          {[
            { id: "ALL", label: "Tudo (14)" },
            { id: "P", label: "Plan (P)" },
            { id: "D", label: "Do (D)" },
            { id: "C", label: "Check (C)" },
            { id: "A", label: "Act (A)" }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-2.5 py-1 text-[9px] font-mono font-black uppercase rounded-md transition-all cursor-pointer border ${
                activeTab === tab.id
                  ? "bg-[#C49746] text-black border-[#C49746]"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Steps List */}
        <div className="flex-grow overflow-y-auto p-4 space-y-3 bg-slate-950">
          {filteredSteps.map((step, index) => {
            const isExpanded = expandedStepId === step.id;
            const isCompleted = completedSteps.includes(step.id);
            const isCurrentInApp = currentWorkspaceView === step.targetView;
            
            // Icon color styling based on phase
            const phaseBadgeStyle = 
              step.phase === "P" ? "bg-blue-950 border-blue-700 text-blue-400" :
              step.phase === "D" ? "bg-amber-950 border-amber-700 text-amber-400" :
              step.phase === "C" ? "bg-purple-950 border-purple-700 text-purple-400" :
              "bg-emerald-950 border-emerald-700 text-emerald-400";

            return (
              <div 
                key={step.id}
                className={`border rounded-lg transition-all text-left ${
                  isCurrentInApp 
                    ? "border-[#C49746] bg-slate-900/60 shadow-lg" 
                    : isCompleted 
                      ? "border-emerald-900/50 bg-slate-900/20 opacity-85" 
                      : "border-slate-800 bg-slate-900/40 hover:bg-slate-900/60"
                }`}
              >
                {/* Accordion Trigger */}
                <div 
                  onClick={() => setExpandedStepId(isExpanded ? null : step.id)}
                  className="p-3.5 flex items-center justify-between cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Checkbox trigger */}
                    <button 
                      onClick={(e) => toggleStepCompleted(step.id, e)}
                      className="shrink-0 w-5 h-5 rounded flex items-center justify-center transition-all bg-slate-950 border hover:scale-105"
                      style={{ borderColor: isCompleted ? "#10B981" : "#475569" }}
                      title={isCompleted ? "Desmarcar como concluída" : "Marcar como concluída"}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 fill-emerald-500/10" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-xs bg-slate-800 group-hover:bg-slate-700" />
                      )}
                    </button>

                    {/* Step Phase Indicator Badge */}
                    <span className={`w-6 h-6 rounded-md font-mono text-[10px] font-bold flex items-center justify-center border shrink-0 ${phaseBadgeStyle}`}>
                      {step.phase}
                    </span>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-mono text-slate-450 font-semibold uppercase">Etapa {index + 1}</span>
                        {isCurrentInApp && (
                          <span className="bg-amber-500/10 border border-amber-500/30 text-[#C49746] font-mono text-[7px] px-1.5 py-0.2 rounded-2xs font-bold tracking-wider animate-pulse">
                            VOCÊ ESTÁ AQUI
                          </span>
                        )}
                      </div>
                      <h4 className={`text-xs font-black uppercase tracking-tight truncate ${isCurrentInApp ? "text-[#C49746]" : "text-slate-100"}`}>
                        {step.label}
                      </h4>
                    </div>
                  </div>
                  <div className="text-slate-400">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="px-3.5 pb-4 pt-1 border-t border-slate-800/80 bg-slate-950/60 rounded-b-lg space-y-3.5 text-[11px] leading-relaxed">
                    <p className="text-slate-350 italic text-[10.5px]">
                      {step.subtitle}
                    </p>

                    <div className="space-y-2.5">
                      {/* Onde clicar */}
                      <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                        <span className="text-[8.5px] uppercase font-mono font-black text-[#C49746] block mb-0.5">
                          📍 Onde clicar / Acessar:
                        </span>
                        <p className="text-slate-200 font-mono text-[10px]">
                          {step.whereToClick}
                        </p>
                      </div>

                      {/* O que preencher */}
                      <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                        <span className="text-[8.5px] uppercase font-mono font-black text-indigo-400 block mb-0.5">
                          📝 O que preencher / Informar:
                        </span>
                        <p className="text-slate-200">
                          {step.whatToFill}
                        </p>
                      </div>

                      {/* Onde isso impacta */}
                      <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                        <span className="text-[8.5px] uppercase font-mono font-black text-emerald-400 block mb-0.5">
                          ⚡ Onde isso impacta / Desdobramento:
                        </span>
                        <p className="text-slate-200">
                          {step.whereItImpacts}
                        </p>
                      </div>
                    </div>

                    {/* Navigation and state actions */}
                    <div className="flex gap-2 pt-1 flex-wrap">
                      <button
                        onClick={() => {
                          setCurrentWorkspaceView(step.targetView);
                          setTimeout(() => {
                            const element = document.getElementById("active-work-viewport");
                            if (element) {
                              element.scrollIntoView({ behavior: "smooth", block: "start" });
                            }
                          }, 100);
                        }}
                        className="flex-1 bg-[#C49746] hover:bg-[#B38535] text-slate-950 text-[10px] font-black uppercase py-2 px-3 rounded flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title={`Ir direto para o módulo ${step.label}`}
                      >
                        <Play className="w-3 h-3 fill-slate-950" />
                        <span>Ir para o Módulo</span>
                      </button>

                      <button
                        onClick={(e) => toggleStepCompleted(step.id, e)}
                        className={`px-3 py-2 text-[10px] font-bold rounded border uppercase transition-all cursor-pointer ${
                          isCompleted
                            ? "border-emerald-800 bg-emerald-950/20 text-emerald-400 hover:bg-emerald-950/40"
                            : "border-slate-700 bg-slate-900 text-slate-300 hover:bg-slate-800"
                        }`}
                      >
                        {isCompleted ? "✓ Concluído" : "Marcar Concluído"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer actions with Reset Cycle PDCA */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 space-y-3">
          <div className="flex items-center justify-between text-[10px] font-mono">
            <span className="text-slate-400">Total Concluído:</span>
            <span className="font-bold text-white">{stats.completed} de 14 etapas</span>
          </div>

          {stats.completed >= 10 ? (
            <button
              onClick={() => setShowCelebration(true)}
              className="w-full bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white text-xs font-black uppercase py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg animate-bounce border border-emerald-400/30 cursor-pointer"
            >
              <Award className="w-4 h-4 text-amber-300 fill-amber-300/10" />
              <span>Finalizar Ciclo &amp; Concluir PDCA!</span>
            </button>
          ) : (
            <button
              onClick={handleResetCycle}
              className="w-full bg-slate-850 hover:bg-slate-800 text-slate-200 border border-slate-750 text-xs font-bold uppercase py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
              title="Zera a lista de progresso das etapas e inicia uma nova volta de otimização contínua"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#C49746]" />
              <span>Zerar &amp; Reiniciar Giro PDCA</span>
            </button>
          )}
        </div>
      </div>

      {/* Backdrop for mobile */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 transition-opacity"
        />
      )}

      {/* Celebratory Completion Modal */}
      {showCelebration && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-[#C49746] rounded-xl max-w-md w-full p-6 text-center space-y-6 shadow-2xl relative overflow-hidden animate-scale-up">
            <div className="absolute -top-12 -left-12 w-24 h-24 bg-[#C49746]/10 rounded-full blur-2xl"></div>
            <div className="absolute -bottom-12 -right-12 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl"></div>

            <div className="w-16 h-16 rounded-full bg-slate-950 border-2 border-emerald-500 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
              <Sparkles className="w-8 h-8 text-[#C49746] animate-pulse" />
            </div>

            <div className="space-y-2">
              <span className="text-[10px] font-mono font-black text-[#C49746] uppercase tracking-widest block">Metodologia Científica Concluída</span>
              <h3 className="text-lg font-serif font-black text-white uppercase tracking-tight">
                Giro de Melhoria Concluído! 🏆
              </h3>
              <p className="text-xs text-slate-350 leading-relaxed font-sans">
                Parabéns! Sua empresa completou com sucesso as etapas do ciclo PDCA (Planejar, Executar, Verificar e Agir), estabelecendo um novo padrão de eficiência e governança.
              </p>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg text-left space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Giro do PDCA Finalizado:</span>
                <span className="font-bold text-white">Ciclo #{cycleCount}</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Etapas Validadas:</span>
                <span className="font-bold text-emerald-400">14 de 14 Completas</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Impacto no EBITDA:</span>
                <span className="font-bold text-emerald-400">Sinergia Otimizada ✓</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={handleResetCycle}
                className="w-full bg-[#C49746] hover:bg-[#B38535] text-slate-950 text-xs font-black uppercase py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 fill-slate-950" />
                <span>Girar o PDCA (Iniciar Novo Ciclo)</span>
              </button>
              
              <button
                onClick={() => setShowCelebration(false)}
                className="w-full bg-slate-850 hover:bg-slate-800 text-slate-400 text-xs font-bold uppercase py-2 px-4 rounded-lg transition-all cursor-pointer"
              >
                Rever Relatório Atual
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
