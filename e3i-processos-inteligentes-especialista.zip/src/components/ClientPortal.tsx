import React, { useState, useEffect, useRef } from "react";
import { db } from "../firebase";
import { doc, onSnapshot, updateDoc, arrayUnion } from "firebase/firestore";
import { 
  Sparkles, Send, HelpCircle, ArrowRight, Layers, Cpu, FileText, ChevronRight, CheckCircle2, Info, RefreshCw, Award, AlertTriangle, Zap, Briefcase, Layers2, ThumbsUp, Clock, ArrowBigUpDash, Lock, Target, TrendingUp, Presentation, Map, Kanban, Building2,
  Plus, Trash2, Edit2, Check, CheckSquare, Square, X, AlertCircle, Play, ChevronDown, Brain, Loader2
} from "lucide-react";
import { buildAssistantResult, splitLines, DISCOVERY_QUESTIONS } from "../utils/e3iIntelligence";
import { calculateProcessMetrics } from "../utils";
import { AiService } from "../services/AiService";
import VisualProcessMapper from "./VisualProcessMapper";
import ReportPresentationGenerator from "./ReportPresentationGenerator";
import SigmaTrendDashboard from "./SigmaTrendDashboard";
import BiStudio from "./BiStudio";
import GuidedProcessDescription from "./GuidedProcessDescription";
import E3IDeliveryBlueprint from "./E3IDeliveryBlueprint";
import { Company, WorkspaceProject } from "../types";
import { ProcessStep, ProjectCharter, Sipoc, ControlPlan } from "../types";

export default function ClientPortal({ activeUser, onBackToApp }: { activeUser?: any; onBackToApp?: () => void }) {
  const [activePortalTab, setActivePortalTab] = useState<"EASY_MAP" | "NEW" | "TRACK" | "MAP" | "REPORT" | "DASHBOARD">("EASY_MAP");
  const [selectedCompanyId, setSelectedCompanyId] = useState("");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");

  const uSuffix = activeUser?.email ? `_${activeUser.email}` : "";

  const [companies, setCompanies] = useState<Company[]>(() => {
    try {
      const userEmail = activeUser?.email;
      const key = userEmail ? `lss_companies_${userEmail}` : "lss_companies";
      return JSON.parse(localStorage.getItem(key) || "[]");
    } catch {
      return [];
    }
  });

  const [projects, setProjects] = useState<WorkspaceProject[]>(() => {
    try {
      const userEmail = activeUser?.email;
      const key = userEmail ? `lss_workspace_projects_${userEmail}` : "lss_workspace_projects";
      return JSON.parse(localStorage.getItem(key) || "[]");
    } catch {
      return [];
    }
  });

  const [projectDataStore, setProjectDataStore] = useState<Record<string, any>>(() => {
    try {
      const uSuffix = activeUser?.email ? `_${activeUser.email}` : "_anonymous";
      const key = activeUser?.email ? `lss_project_data_store${uSuffix}` : "lss_project_data_store";
      return JSON.parse(localStorage.getItem(key) || "{}");
    } catch {
      return {};
    }
  });

  const [inputPasscode, setInputPasscode] = useState("");
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passcodeError, setPasscodeError] = useState("");

  const [isTokenLocked, setIsTokenLocked] = useState(false);
  const [lockedCompanyName, setLockedCompanyName] = useState<string | null>(null);
  const [tokenExpired, setTokenExpired] = useState(false);
  const [tokenInvalid, setTokenInvalid] = useState(false);

  const [dbComments, setDbComments] = useState<any[]>([]);
  const [dbRequests, setDbRequests] = useState<any[]>([]);

  // --- EASY PROCESS MAPPING CLIENT PLAYGROUND STATES ---
  const [easyBusinessType, setEasyBusinessType] = useState<"SERVICES" | "INDUSTRIAL" | "RETAIL" | "LOGISTICS">(() => {
    return (localStorage.getItem("lss_easy_business_type") as any) || "SERVICES";
  });

  const [easyArrivalRate, setEasyArrivalRate] = useState<number>(() => {
    const saved = localStorage.getItem("lss_easy_arrival_rate");
    return saved ? parseFloat(saved) : 10;
  });

  const [easySteps, setEasySteps] = useState<ProcessStep[]>(() => {
    try {
      const saved = localStorage.getItem("lss_easy_steps");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    // Default initial steps for SERVICES
    return [
      {
        id: "step_easy_1",
        name: "Triagem & Abertura de Chamado",
        resource: "Atendentes",
        resourceCount: 1,
        processingTime: 4.5,
        standardDeviation: 0.9,
        yieldRate: 0.95,
        setupTime: 0,
        description: "Etapa onde o cliente é recebido e o atendente registra a solicitação inicial."
      },
      {
        id: "step_easy_2",
        name: "Análise Técnica & Resolução",
        resource: "Suporte Nível 2",
        resourceCount: 2,
        processingTime: 12.0,
        standardDeviation: 2.4,
        yieldRate: 0.88,
        setupTime: 0,
        description: "Análise profunda do problema técnico e aplicação de correções pelo especialista."
      },
      {
        id: "step_easy_3",
        name: "Validação & Encerramento",
        resource: "Equipe de Sucesso",
        resourceCount: 1,
        processingTime: 5.0,
        standardDeviation: 1.0,
        yieldRate: 0.98,
        setupTime: 0,
        description: "Confirmação com o cliente de que o problema foi de fato solucionado e posterior fechamento."
      }
    ];
  });

  const [easyActiveSubTab, setEasyActiveSubTab] = useState<"FLOW" | "METRICS" | "INDICATORS" | "AI_CONSULT">("FLOW");

  // Custom KPIs mapping the 3 categories: ENTRADA, PROCESSO, RESULTADO
  const [customKpis, setCustomKpis] = useState<{ id: string; category: "ENTRADA" | "PROCESSO" | "RESULTADO"; name: string; target: string; checked: boolean }[]>(() => {
    try {
      const saved = localStorage.getItem("lss_custom_kpis");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "kpi_1", category: "ENTRADA", name: "% de solicitações dentro do padrão de abertura", target: ">= 95%", checked: true },
      { id: "kpi_2", category: "ENTRADA", name: "Disponibilidade operacional de ferramentas/sistema", target: ">= 99.5%", checked: true },
      { id: "kpi_3", category: "PROCESSO", name: "Tempo médio de ciclo (Lead Time)", target: "< 25 min", checked: true },
      { id: "kpi_4", category: "PROCESSO", name: "Produtividade média da equipe ativa", target: ">= 80%", checked: false },
      { id: "kpi_5", category: "RESULTADO", name: "% de entregas no prazo acordado (SLA)", target: ">= 98%", checked: true },
      { id: "kpi_6", category: "RESULTADO", name: "Taxa de Satisfação do Cliente (NPS)", target: ">= 75", checked: true }
    ];
  });

  const [newKpiName, setNewKpiName] = useState("");
  const [newKpiCategory, setNewKpiCategory] = useState<"ENTRADA" | "PROCESSO" | "RESULTADO">("ENTRADA");
  const [newKpiTarget, setNewKpiTarget] = useState("");
  const [isSimulatingBadInput, setIsSimulatingBadInput] = useState(false);

  // Step adding / editing form states
  const [isAddingEasyStep, setIsAddingEasyStep] = useState(false);
  const [editingEasyStepId, setEditingEasyStepId] = useState<string | null>(null);
  
  const [easyStepName, setEasyStepName] = useState("");
  const [easyStepResource, setEasyStepResource] = useState("");
  const [easyStepResourceCount, setEasyStepResourceCount] = useState(1);
  const [easyStepProcessingTime, setEasyStepProcessingTime] = useState(5);
  const [easyStepFailureRate, setEasyStepFailureRate] = useState(5); // in percent
  const [easyStepDescription, setEasyStepDescription] = useState("");

  // Easy AI states
  const [easyAiDiagnostic, setEasyAiDiagnostic] = useState<string | null>(() => {
    return localStorage.getItem("lss_easy_ai_diagnostic");
  });
  const [easyAiRecommendations, setEasyAiRecommendations] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("lss_easy_ai_recs");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [easyAiAnalogy, setEasyAiAnalogy] = useState<string | null>(() => {
    return localStorage.getItem("lss_easy_ai_analogy");
  });
  const [isEasyAiLoading, setIsEasyAiLoading] = useState(false);
  const [easyAiError, setEasyAiError] = useState<string | null>(null);

  // Easy Kaizen Tasks states
  const [easyTasks, setEasyTasks] = useState<{ id: string; text: string; done: boolean }[]>(() => {
    try {
      const saved = localStorage.getItem("lss_easy_tasks");
      if (saved) return JSON.parse(saved);
    } catch {}
    
    // Default Tasks for services
    return [
      { id: "etask_1", text: "Remover assinaturas ou etapas de aprovação redundantes do fluxo de chamados", done: false },
      { id: "etask_2", text: "Criar uma lista de respostas rápidas/templates padronizados para triagem inicial", done: false },
      { id: "etask_3", text: "Capacitar a equipe com rotinas de resolução imediata (First Contact Resolution)", done: false }
    ];
  });
  const [newEasyTaskText, setNewEasyTaskText] = useState("");

  // --- INFORMAÇÕES DO SCRIPT GUIADO ---
  const [useGuidedScript, setUseGuidedScript] = useState(true);
  const [guidedContactName, setGuidedContactName] = useState("");
  const [guidedContactEmail, setGuidedContactEmail] = useState("");
  const [guidedContactPhone, setGuidedContactPhone] = useState("");
  const [guidedProcessName, setGuidedProcessName] = useState("");

  const [guidedGatilho, setGuidedGatilho] = useState("");
  const [guidedFluxo, setGuidedFluxo] = useState("");
  const [guidedDesvios, setGuidedDesvios] = useState("");
  const [guidedFerramentas, setGuidedFerramentas] = useState("");
  const [guidedEntrega, setGuidedEntrega] = useState("");
  const [guidedRegras, setGuidedRegras] = useState("");

  const [wizardStep, setWizardStep] = useState(0); 
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
  const [previewCompiledText, setPreviewCompiledText] = useState("");
  const [parsedAnalysisResult, setParsedAnalysisResult] = useState<any>(null);
  const [isSubmittingGuided, setIsSubmittingGuided] = useState(false);

  // Synchronize simplified mappings to localStorage
  useEffect(() => {
    localStorage.setItem("lss_easy_business_type", easyBusinessType);
  }, [easyBusinessType]);

  useEffect(() => {
    localStorage.setItem("lss_easy_arrival_rate", easyArrivalRate.toString());
  }, [easyArrivalRate]);

  useEffect(() => {
    localStorage.setItem("lss_easy_steps", JSON.stringify(easySteps));
  }, [easySteps]);

  useEffect(() => {
    localStorage.setItem("lss_easy_tasks", JSON.stringify(easyTasks));
  }, [easyTasks]);

  useEffect(() => {
    localStorage.setItem("lss_custom_kpis", JSON.stringify(customKpis));
  }, [customKpis]);

  useEffect(() => {
    if (easyAiDiagnostic) localStorage.setItem("lss_easy_ai_diagnostic", easyAiDiagnostic);
    else localStorage.removeItem("lss_easy_ai_diagnostic");

    if (easyAiAnalogy) localStorage.setItem("lss_easy_ai_analogy", easyAiAnalogy);
    else localStorage.removeItem("lss_easy_ai_analogy");

    localStorage.setItem("lss_easy_ai_recs", JSON.stringify(easyAiRecommendations));
  }, [easyAiDiagnostic, easyAiAnalogy, easyAiRecommendations]);

  useEffect(() => {
    try {
      const userEmail = activeUser?.email;
      const key = userEmail ? `lss_workspace_projects_${userEmail}` : "lss_workspace_projects";
      localStorage.setItem(key, JSON.stringify(projects));
    } catch (e) {
      console.warn("Error saving projects to localStorage in ClientPortal:", e);
    }
  }, [projects, activeUser?.email]);

  const loadDefaultEasyStepsForSector = (sector: "SERVICES" | "INDUSTRIAL" | "RETAIL" | "LOGISTICS") => {
    let steps: ProcessStep[] = [];
    let tasks: { id: string; text: string; done: boolean }[] = [];

    if (sector === "SERVICES") {
      steps = [
        {
          id: "step_easy_1",
          name: "Triagem & Abertura de Chamado",
          resource: "Atendentes",
          resourceCount: 1,
          processingTime: 4.5,
          standardDeviation: 0.9,
          yieldRate: 0.95,
          setupTime: 0,
          description: "Etapa onde o cliente é recebido e o atendente registra a solicitação inicial."
        },
        {
          id: "step_easy_2",
          name: "Análise Técnica & Resolução",
          resource: "Suporte Nível 2",
          resourceCount: 2,
          processingTime: 12.0,
          standardDeviation: 2.4,
          yieldRate: 0.88,
          setupTime: 0,
          description: "Análise profunda do problema técnico e aplicação de correções pelo especialista."
        },
        {
          id: "step_easy_3",
          name: "Validação & Encerramento",
          resource: "Equipe de Sucesso",
          resourceCount: 1,
          processingTime: 5.0,
          standardDeviation: 1.0,
          yieldRate: 0.98,
          setupTime: 0,
          description: "Confirmação com o cliente de que o problema foi de fato solucionado e posterior fechamento."
        }
      ];
      tasks = [
        { id: "etask_1", text: "Remover assinaturas ou etapas de aprovação redundantes do fluxo de chamados", done: false },
        { id: "etask_2", text: "Criar uma lista de respostas rápidas/templates padronizados para triagem inicial", done: false },
        { id: "etask_3", text: "Capacitar a equipe com rotinas de resolução imediata (First Contact Resolution)", done: false }
      ];
    } else if (sector === "INDUSTRIAL") {
      steps = [
        {
          id: "step_easy_1",
          name: "Preparação & Corte de Peças",
          resource: "Operador de Serra",
          resourceCount: 1,
          processingTime: 6.0,
          standardDeviation: 1.2,
          yieldRate: 0.98,
          setupTime: 0,
          description: "Medição de painéis de alumínio e corte automatizado em dimensões padrão."
        },
        {
          id: "step_easy_2",
          name: "Montagem de Componentes Eletrônicos",
          resource: "Bancada de Solda",
          resourceCount: 2,
          processingTime: 20.0,
          standardDeviation: 4.0,
          yieldRate: 0.85,
          setupTime: 0,
          description: "Fixação e solda de micro-placas e circuitos integrados no corpo principal."
        },
        {
          id: "step_easy_3",
          name: "Inspeção Visual & Embalagem Final",
          resource: "Inspetor de Qualidade",
          resourceCount: 1,
          processingTime: 5.0,
          standardDeviation: 1.0,
          yieldRate: 0.99,
          setupTime: 0,
          description: "Check visual contra arranhões, teste rápido de corrente e colocação em caixas de entrega."
        }
      ];
      tasks = [
        { id: "etask_1", text: "Organizar ferramentas da bancada de solda usando sombras táteis (5S)", done: false },
        { id: "etask_2", text: "Sinalizar as pilhas de peças com placas de Kanban físico de alívio rápido", done: false },
        { id: "etask_3", text: "Instalar iluminação de alta resolução na bancada de inspeção visual para evitar erros", done: false }
      ];
    } else if (sector === "RETAIL") {
      steps = [
        {
          id: "step_easy_1",
          name: "Atendimento ao Cliente / Escolha",
          resource: "Consultor de Vendas",
          resourceCount: 3,
          processingTime: 12.0,
          standardDeviation: 2.4,
          yieldRate: 0.95,
          setupTime: 0,
          description: "Atendimento consultivo, tirando dúvidas de vestuário e provando tamanhos."
        },
        {
          id: "step_easy_2",
          name: "Pagamento & Registro no Caixa",
          resource: "Operador de Caixa",
          resourceCount: 1,
          processingTime: 3.5,
          standardDeviation: 0.7,
          yieldRate: 0.99,
          setupTime: 0,
          description: "Passar código de barras, faturar pagamento em cartão ou dinheiro e emitir NFC-e."
        },
        {
          id: "step_easy_3",
          name: "Empacotamento de Saída",
          resource: "Auxiliar de Pacote",
          resourceCount: 1,
          processingTime: 2.0,
          standardDeviation: 0.4,
          yieldRate: 1.0,
          setupTime: 0,
          description: "Conferir itens contra nota fiscal, pendurar cabides e embalar com fitas corporativas."
        }
      ];
      tasks = [
        { id: "etask_1", text: "Separar canal de troco facilitado para agilizar o tempo de caixa em horários de pico", done: false },
        { id: "etask_2", text: "Estampar sinalização de fila única central organizada para evitar cansaço de clientes", done: false },
        { id: "etask_3", text: "Disponibilizar sacolas de embalagem rápida diretamente na gaveta do caixa principal", done: false }
      ];
    } else { // LOGISTICS
      steps = [
        {
          id: "step_easy_1",
          name: "Separar Pedidos (Picking)",
          resource: "Operadores de Almoxarifado",
          resourceCount: 2,
          processingTime: 8.0,
          standardDeviation: 1.6,
          yieldRate: 0.96,
          setupTime: 0,
          description: "Coleta manual de paletes de caixas seguindo o terminal rádio de picking."
        },
        {
          id: "step_easy_2",
          name: "Check de Qualidade & Embalagem",
          resource: "Mesa de Triagem",
          resourceCount: 1,
          processingTime: 10.0,
          standardDeviation: 2.0,
          yieldRate: 0.92,
          setupTime: 0,
          description: "Escaneamento, check de peso real e aplicação de fita shrink-wrap."
        },
        {
          id: "step_easy_3",
          name: "Carregamento & Despacho",
          resource: "Operador de Empilhadeira",
          resourceCount: 1,
          processingTime: 6.0,
          standardDeviation: 1.2,
          yieldRate: 0.99,
          setupTime: 0,
          description: "Alocação do lote no palete correspondente na baia de expedição de saída."
        }
      ];
      tasks = [
        { id: "etask_1", text: "Organizar as prateleiras de insumos mais pesados na entrada da baia para economizar passos", done: false },
        { id: "etask_2", text: "Implementar pesagem automática na mesa de triagem para evitar retrabalho de contagem manual", done: false },
        { id: "etask_3", text: "Criar uma rota clara pintada no chão para movimentação livre das empilhadeiras", done: false }
      ];
    }
    
    setEasySteps(steps);
    setEasyTasks(tasks);
    setEasyAiDiagnostic(null);
    setEasyAiRecommendations([]);
    setEasyAiAnalogy(null);
  };

  const handleAddEasyStep = () => {
    if (!easyStepName.trim()) return;
    const failureRatio = easyStepFailureRate / 100;
    const yieldRate = parseFloat((1 - failureRatio).toFixed(4));
    const newStep: ProcessStep = {
      id: "step_easy_" + Date.now(),
      name: easyStepName.trim(),
      resource: easyStepResource.trim() || "Equipe",
      resourceCount: Math.max(1, easyStepResourceCount),
      processingTime: Math.max(0.1, easyStepProcessingTime),
      standardDeviation: parseFloat((easyStepProcessingTime * 0.2).toFixed(2)), // standard 20% variability
      yieldRate,
      setupTime: 0,
      description: easyStepDescription.trim() || "Etapa operacional."
    };
    setEasySteps([...easySteps, newStep]);
    resetEasyStepForm();
  };

  const handleEditEasyStep = (id: string) => {
    const target = easySteps.find(s => s.id === id);
    if (!target) return;
    setEditingEasyStepId(id);
    setEasyStepName(target.name);
    setEasyStepResource(target.resource);
    setEasyStepResourceCount(target.resourceCount);
    setEasyStepProcessingTime(target.processingTime);
    setEasyStepFailureRate(Math.round((1 - target.yieldRate) * 100));
    setEasyStepDescription(target.description || "");
    setIsAddingEasyStep(true);
  };

  const handleUpdateEasyStep = () => {
    if (!editingEasyStepId || !easyStepName.trim()) return;
    const failureRatio = easyStepFailureRate / 100;
    const yieldRate = parseFloat((1 - failureRatio).toFixed(4));

    setEasySteps(easySteps.map(s => {
      if (s.id === editingEasyStepId) {
        return {
          ...s,
          name: easyStepName.trim(),
          resource: easyStepResource.trim() || "Equipe",
          resourceCount: Math.max(1, easyStepResourceCount),
          processingTime: Math.max(0.1, easyStepProcessingTime),
          standardDeviation: parseFloat((easyStepProcessingTime * 0.2).toFixed(2)),
          yieldRate,
          description: easyStepDescription.trim() || "Etapa operacional."
        };
      }
      return s;
    }));
    resetEasyStepForm();
  };

  const handleDeleteEasyStep = (id: string) => {
    if (confirm("Gostaria de realmente remover esta etapa do seu fluxo simplificado?")) {
      setEasySteps(easySteps.filter(s => s.id !== id));
    }
  };

  const resetEasyStepForm = () => {
    setIsAddingEasyStep(false);
    setEditingEasyStepId(null);
    setEasyStepName("");
    setEasyStepResource("");
    setEasyStepResourceCount(1);
    setEasyStepProcessingTime(5);
    setEasyStepFailureRate(5);
    setEasyStepDescription("");
  };

  const handleRequestEasyAiImprovement = async () => {
    setIsEasyAiLoading(true);
    setEasyAiError(null);
    try {
      const urlToken = new URLSearchParams(window.location.search).get("token");
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (urlToken) {
        headers["Authorization"] = `Bearer ${urlToken}`;
      }

      const response = await fetch("/api/layperson-improve", {
        method: "POST",
        headers,
        body: JSON.stringify({
          steps: easySteps.map(s => ({
            name: s.name,
            resource: s.resource || "Equipe",
            resourceCount: s.resourceCount,
            processingTime: s.processingTime,
            yieldRate: s.yieldRate,
            description: s.description || ""
          })),
          arrivalRate: easyArrivalRate
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Erro de conexão com o consultor de IA.");
      }

      const data = await response.json();
      setEasyAiDiagnostic(data.diagnostic);
      setEasyAiRecommendations(data.recommendations || []);
      setEasyAiAnalogy(data.funnyAnalogy);
    } catch (err: any) {
      console.error(err);
      setEasyAiError(err.message || "Erro para consultar a IA. Por favor, cheque se sua chave do Gemini está provida.");
    } finally {
      setIsEasyAiLoading(false);
    }
  };

  const handleAddEasyAiRecToTasks = (title: string, desc: string) => {
    const taskId = "etask_" + Date.now();
    const newTask = {
      id: taskId,
      text: `${title}: ${desc}`,
      done: false
    };
    setEasyTasks([...easyTasks, newTask]);
    alert("💡 Ideia adicionada com sucesso ao seu Plano Kaizen de melhorias!");
  };

  const handleToggleEasyTask = (id: string) => {
    setEasyTasks(easyTasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const handleAddEasyTaskManual = () => {
    if (!newEasyTaskText.trim()) return;
    const newTask = {
      id: "etask_" + Date.now(),
      text: newEasyTaskText.trim(),
      done: false
    };
    setEasyTasks([...easyTasks, newTask]);
    setNewEasyTaskText("");
  };

  const handleDeleteEasyTask = (id: string) => {
    setEasyTasks(easyTasks.filter(t => t.id !== id));
  };

  useEffect(() => {
    if (!isUnlocked) return;
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    if (!urlToken) {
      // Load local requests from localStorage in direct preview mode
      const localReqs = JSON.parse(localStorage.getItem("lss_local_portal_requests") || "[]");
      setDbRequests(localReqs);
      return;
    }

    const docId = urlToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
    console.log("[Portal] Listening to Firestore real-time docId:", docId);
    
    const unsubscribe = onSnapshot(doc(db, "shared_portals", docId), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        console.log("[Portal] Loaded real-time snapshot data:", data);
        
        if (data.company) {
          setCompanies([data.company]);
          setSelectedCompanyId(data.company.id);
        }
        if (data.project) {
          setProjects([data.project]);
          setSelectedProjectId(data.project.id);
        }
        if (data.project && data.projectData) {
          setProjectDataStore({
            [data.project.id]: data.projectData
          });
        }
        setDbComments(data.comments || []);
        setDbRequests(data.requests || []);
      } else {
        console.warn("[Portal] Shared snapshot document not found in Firestore.");
      }
    }, (err) => {
      console.error("[Portal] Listener error:", err);
    });

    return () => unsubscribe();
  }, [isUnlocked]);

  const hasParsed = useRef(false);

  useEffect(() => {
    if (hasParsed.current) return;
    hasParsed.current = true;

    const initializePortalFromUrl = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const urlCompany = params.get("company");
        const urlToken = params.get("token");

        let tokenVerifiedCompany: string | null = null;
        let isTokenValid = false;

        if (urlToken) {
          try {
            // Attempt cryptographically secure backend token validation of signature (without passcode yet)
            const verifyRes = await fetch("/api/portal/verify-token", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ token: urlToken })
            });
            const result = await verifyRes.json();

            if (!result.isValid) {
              setTokenInvalid(true);
              setPasscodeError("🔒 Assinatura do link de convite inválida ou modificada. Acesso bloqueado.");
              return;
            }
            if (result.isExpired) {
              setTokenExpired(true);
              setPasscodeError("⏰ Este link de convite seguro expirou (limite de 7 dias excedido). Solicite um novo link ao seu consultor.");
              return;
            }
            
            setIsTokenLocked(true);
            setLockedCompanyName(result.companyName);
            tokenVerifiedCompany = result.companyName;
            isTokenValid = true;
          } catch (apiErr) {
            console.error("API verification error:", apiErr);
            setTokenInvalid(true);
            setPasscodeError("🔒 Falha de conexão segura com o servidor.");
            return;
          }
        }

        if (urlCompany || tokenVerifiedCompany) {
          const rawTargetCompany = tokenVerifiedCompany || urlCompany;
          if (rawTargetCompany) {
            const decodedCompany = decodeURIComponent(rawTargetCompany).trim();
            const existing = companies.find(c => c.name.toLowerCase() === decodedCompany.toLowerCase() || c.id === decodedCompany);
            if (existing) {
              setSelectedCompanyId(existing.id);
            } else {
              // Auto-register company to link the portal
              const newCompany: Company = {
                id: "comp_" + Date.now().toString() + "_" + Math.floor(Math.random() * 1000),
                name: decodedCompany,
                cnpj: "",
                industry: "Geral",
                createdAt: new Date().toISOString()
              };
              const updatedCompanies = [...companies, newCompany];
              const key = activeUser?.email ? `lss_companies_${activeUser.email}` : "lss_companies";
              localStorage.setItem(key, JSON.stringify(updatedCompanies));
              setCompanies(updatedCompanies);
              setSelectedCompanyId(newCompany.id);
            }
          }
        }
      } catch (e) {
        console.error("Erro ao inicializar portal via URL:", e);
      }
    };

    initializePortalFromUrl();
  }, [companies]);

  const handleUnlockPortal = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasscodeError("");

    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    const normalizedInput = (inputPasscode || "").trim().toUpperCase();

    if (normalizedInput === "LSS-2026") {
      setPasscodeError("❌ O PIN público padrão 'LSS-2026' foi revogado com base em diretrizes corporativas de controle de risco. Digite um PIN corporativo robusto.");
      return;
    }

    if (urlToken) {
      // SECURE SERVER-SIDE TOKEN + PIN CORROBORATION
      try {
        const verifyRes = await fetch("/api/portal/verify-token", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: urlToken, passcode: normalizedInput })
        });
        const result = await verifyRes.json();

        if (verifyRes.ok && result.isValid) {
          setIsUnlocked(true);
          setPasscodeError("");
        } else {
          setPasscodeError("🔒 Código de acesso corporativo incorreto ou convite expirado.");
        }
      } catch (err) {
        console.error("Erro ao validar token de segurança:", err);
        setPasscodeError("Falha de conexão com os servidores de segurança. Tente novamente mais tarde.");
      }
      return;
    }

    // Direct preview or localized team workspace workflow
    if (!selectedCompanyId) {
      setPasscodeError("Por favor, selecione sua empresa.");
      return;
    }
    
    const passcodeEnabled = localStorage.getItem("lss_client_portal_passcode_enabled") !== "false";
    const customPasscode = (localStorage.getItem("lss_client_portal_passcode") || "").trim().toUpperCase();

    if (!passcodeEnabled) {
      setIsUnlocked(true);
      setPasscodeError("");
      return;
    }

    if (customPasscode && normalizedInput === customPasscode) {
      setIsUnlocked(true);
      setPasscodeError("");
    } else {
      setPasscodeError("🔒 PIN de acesso corporativo inválido.");
    }
  };

  const [clientName, setClientName] = useState("");
  const [interviewText, setInterviewText] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const isBlocked = localStorage.getItem("lss_client_portal_blocked") === "true";

  if (isBlocked) {
    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex flex-col justify-center items-center p-4 font-sans relative" id="portal-suspended-gate">
        <div className="max-w-md w-full bg-[#242424] border-4 border-red-500 p-8 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-6 relative z-10 rounded-sm text-center">
          <AlertTriangle size={48} className="mx-auto text-red-500 animate-pulse" />
          <h2 className="text-xl font-serif text-white font-black uppercase tracking-wide">Acesso Suspenso</h2>
          <p className="text-xs text-gray-350 leading-relaxed font-sans">
            O canal de comunicação para este portal foi temporariamente suspenso pelos administradores.
          </p>
          <div className="p-3 bg-red-950/45 border border-red-500/25 rounded-xs text-left text-[11px] text-red-200">
            <strong>Instruções de Recuperação:</strong> Entre em contato direto com o Especialista em Processos LSS responsável de sua conta para regularizar seu acesso e reativar as visualizações do fluxo do seu lote.
          </div>
          {onBackToApp && <button onClick={onBackToApp} className="w-full text-center text-xs text-gray-500 hover:text-white pt-4 cursor-pointer">Voltar ao Painel Admin</button>}
        </div>
      </div>
    );
  }

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex flex-col justify-center items-center p-4 font-sans relative">
        <div className="max-w-md w-full bg-[#242424] border-4 border-[#C49746] p-8 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-6 relative z-10 rounded-sm">
          <div className="text-center space-y-2">
            <h2 className="text-xl font-serif text-white font-black uppercase tracking-wide">Portal do Cliente LSS</h2>
            <p className="text-xs text-gray-400 leading-relaxed font-sans max-w-xs mx-auto">
              {isTokenLocked 
                ? "Sessão corporativa criptografada vinculada e homologada por assinatura."
                : "Selecione sua empresa e insira o código corporativo para visualizar seus projetos LSS."
              }
            </p>
          </div>

          {tokenExpired || tokenInvalid ? (
            <div className="space-y-4 text-center">
              <div className="p-4 bg-red-950/40 border border-red-500/35 text-red-350 text-xs rounded-sm leading-relaxed space-y-2">
                <AlertTriangle size={32} className="mx-auto text-red-500 mb-1 animate-pulse" />
                <p className="font-bold uppercase tracking-wider font-mono text-red-400">Canal Não Autorizado</p>
                <p className="font-sans text-[11px]">{passcodeError}</p>
              </div>
              <p className="text-[9px] text-gray-500 select-none uppercase font-mono">OptimaFlow Audit & Security Guard Core • 2026</p>
            </div>
          ) : (
            <form onSubmit={handleUnlockPortal} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold tracking-widest text-[#C49746] uppercase block text-center">Sua Empresa:</label>
                {isTokenLocked && lockedCompanyName ? (
                  <div className="w-full bg-[#1A1A1A] border-2 border-emerald-500/40 p-3 text-center font-mono font-bold text-emerald-400 text-xs rounded-xs flex items-center justify-center gap-1.5 uppercase select-none">
                     <Lock size={12} className="text-emerald-400" /> {lockedCompanyName}
                  </div>
                ) : (
                  <select value={selectedCompanyId} onChange={(e) => setSelectedCompanyId(e.target.value)} className="w-full bg-[#1A1A1A] border border-amber-500/30 p-3 text-center font-mono font-bold text-[#F5F2ED] text-xs outline-none" required>
                    <option value="">-- Selecione --</option>
                    {companies.map(c => (<option key={c.id} value={c.id}>{c.name}</option>))}
                  </select>
                )}
              </div>
              
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold tracking-widest text-[#C49746] uppercase block text-center">PIN Corporativo de Acesso:</label>
                <input type="password" value={inputPasscode} onChange={e => setInputPasscode(e.target.value)} className="w-full bg-[#1A1A1A] border border-amber-500/30 p-3 text-center text-[#F5F2ED] text-xs outline-none uppercase font-mono tracking-widest" placeholder="EX: E3I-XXXX-XXXX" required />
                <p className="text-[9.5px] text-gray-400 text-center font-sans leading-relaxed">
                  Insira o PIN recebido de seu consultor de excelência para autenticar esta visualização segura.
                </p>
              </div>
              
              {passcodeError && <p className="text-[10px] text-red-400 text-center font-sans">{passcodeError}</p>}
              <button type="submit" className="w-full bg-[#C49746] hover:bg-[#D97706] text-white p-3 font-mono font-black uppercase text-[11px] tracking-widest transition-all">Entrar</button>
            </form>
          )}

          {onBackToApp && <button onClick={onBackToApp} className="w-full text-center text-xs text-gray-500 hover:text-white pt-4 cursor-pointer">Voltar ao Painel Admin</button>}
        </div>
      </div>
    );
  }

  const handleGenerateGuidedPreview = async () => {
    setIsGeneratingPreview(true);
    setSuccessMsg("");
    
    // Exactly matched wording from the prompt instruction
    const greeting = `Olá! Para criarmos um padrão perfeito do processo "${guidedProcessName || '[NOME DO PROCESSO]'}\", preciso que você o descreva com o máximo de detalhes possível. Não se preocupe com termos técnicos. Apenas responda às perguntas abaixo pensando no seu dia a dia real:`;
    
    const block1 = `1. O Ponto de Partida (Gatilho)
Como esse processo começa? (Ex: Você recebe um e-mail? O cliente liga? Um sistema emite um alerta?)
Exatamente qual informação ou documento chega até você para o trabalho começar?
R: ${guidedGatilho || "Não preenchido."}`;

    const block2 = `2. O Passo a Passo Detalhado (O Fluxo)
Descreva a sequência de ações. Use o modelo: Quem (Cargo) faz O que e Onde (Sistema/Papel).
Exemplo: "Eu (Analista) abro o sistema X, clico em 'Novo Pedido' e digito o CPF do cliente."
Escreva todas as etapas, desde a primeira ação até a conclusão.
R: ${guidedFluxo || "Não preenchido."}`;

    const block3 = `3. Os Desvios e Tomadas de Decisão (E se der errado?)
Quais decisões você precisa tomar no meio do caminho? (Ex: "Eu preciso checar se o valor é maior que R$ 5.000")
O que acontece se a resposta for SIM? Para onde o processo vai?
O que acontece se a resposta for NÃO ou se houver um erro? Quem você aciona?
R: ${guidedDesvios || "Não preenchido."}`;

    const block4 = `4. Ferramentas e Sistemas
Quais sistemas, planilhas, sites ou blocos de papel você usa durante esse processo? (Cite os nomes das ferramentas).
R: ${guidedFerramentas || "Não preenchido."}`;

    const block5 = `5. O Ponto Final (A Entrega)
Como você sabe que a sua parte terminou?
O que você gera no final e para quem você envia? (Ex: Um relatório PDF enviado por e-mail para o gerente; Um produto embalado na esteira).
R: ${guidedEntrega || "Não preenchido."}`;

    const block6 = `6. Regras, Prazos e Gargalos
Existe algum prazo obrigatório a ser cumprido? (Ex: Deve ser feito em até 2 horas).
Qual é o erro ou problema mais comum que costuma travar esse processo?
R: ${guidedRegras || "Não preenchido."}`;

    const compiled = `${greeting}

==================================================
RELATO ESTRUTURADO DE PROCESSO: ${(guidedProcessName || 'MAPEAMENTO').toUpperCase()}
==================================================
Solicitante: ${guidedContactName || "Não especificado"}
E-mail: ${guidedContactEmail || "Não especificado"}
Telefone: ${guidedContactPhone || "Não especificado"}

${block1}

${block2}

${block3}

${block4}

${block5}

${block6}`;

    setPreviewCompiledText(compiled);
    
    try {
      const urlToken = new URLSearchParams(window.location.search).get("token");
      const promptToParse = `Setor de atuação com o relato do processo "${guidedProcessName || "Mapeamento Guiado"}": ${compiled}`;
      const result = await AiService.suggestStructure(promptToParse, urlToken || undefined);
      
      if (result && result.sipoc && result.steps) {
        const analysis = {
          sipoc: {
            Suppliers: result.sipoc.suppliers.split(",").map(s => s.trim()),
            Inputs: result.sipoc.inputs.split(",").map(i => i.trim()),
            Process: result.sipoc.processDescription || guidedProcessName || "Fluxo Geral",
            Outputs: result.sipoc.outputs.split(",").map(o => o.trim()),
            Customers: result.sipoc.customers.split(",").map(c => c.trim())
          },
          metrics: {
            confidenceScore: 94,
            reworkEst: result.steps[0] ? Math.round(100 - (result.steps[0].yieldRate * 100)) : 15,
            tempoMedioCiclo: `${result.steps.reduce((acc, s) => acc + s.processingTime, 0)} minutos`
          },
          steps: result.steps.map(s => s.name)
        };
        setParsedAnalysisResult(analysis);
      } else {
        throw new Error("Formato de sugestão sem passos válidos");
      }
    } catch (e) {
      console.warn("[Portal AI Parser] falhou ao gerar passos estruturados, fallback:", e);
      // Fallback heuristics
      const fallbackSteps: string[] = [];
      if (guidedGatilho) fallbackSteps.push("Recebimento do Gatilho");
      if (guidedFluxo) fallbackSteps.push("Execução das Etapas Básicas");
      if (guidedDesvios) fallbackSteps.push("Tratamento de Exceções");
      if (guidedFerramentas) fallbackSteps.push("Integração e Sistemas");
      if (guidedEntrega) fallbackSteps.push("Geração e Entrega de Saídas");
      
      if (fallbackSteps.length === 0) {
        fallbackSteps.push("Análise de Início", "Controle de Fluxograma", "Validação de Processo", "Fim");
      }
      
      setParsedAnalysisResult({
        sipoc: {
          Suppliers: ["Fornecedores da " + (guidedProcessName || "Operação")],
          Inputs: ["Dados de Entrada"],
          Process: guidedProcessName || "Fluxo Geral",
          Outputs: ["Entrega Concluída"],
          Customers: ["Clientes do Projeto"]
        },
        metrics: {
          confidenceScore: 84,
          reworkEst: 15,
          tempoMedioCiclo: "A definir"
        },
        steps: fallbackSteps
      });
    } finally {
      setIsGeneratingPreview(false);
      setWizardStep(7); // To Preview Step
    }
  };

  const handleSubmitGuidedRequest = async () => {
    if (!guidedContactName || !guidedProcessName) {
      alert("Por favor, preencha as informações do solicitante e o nome do processo.");
      return;
    }
    
    setIsSubmittingGuided(true);
    setSuccessMsg("");
    
    const reqId = "req_" + Date.now().toString();
    const solId = "sol_" + Date.now().toString();
    const clientCompany = companies.find(c => c.id === selectedCompanyId)?.name || lockedCompanyName || "Empresa Cliente";
    
    const newReq = {
      id: reqId,
      clientName: guidedContactName.trim(),
      text: previewCompiledText,
      status: "Em Análise",
      timestamp: new Date().toISOString()
    };

    // Prepare complete solicitation for Admin panel
    const newSolicitation = {
      id: solId,
      clientCompany,
      clientName: guidedContactName.trim(),
      clientEmail: (guidedContactEmail || "cliente@sandbox.com").trim(),
      contactPhone: (guidedContactPhone || "").trim(),
      processName: guidedProcessName.trim(),
      projectGoal: "Análise estratégica de gargalo via Roteiro Guiado",
      urgency: "Média",
      rawText: previewCompiledText,
      status: "Pendente",
      createdAt: new Date().toISOString(),
      analysisResult: parsedAnalysisResult || {
        sipoc: {
          Suppliers: ["Fornecedores"],
          Inputs: ["Insumos"],
          Process: guidedProcessName.trim(),
          Outputs: ["Resultados"],
          Customers: ["Clientes"]
        },
        metrics: {
          confidenceScore: 90,
          reworkEst: 15,
          tempoMedioCiclo: "A calcular"
        },
        steps: []
      }
    };
    
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    if (urlToken) {
      try {
        const docId = urlToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
        if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
          console.log("[Portal] [Modo de Treinamento] Firestore write bypassed inside Shared Portal. Simulating in state.");
          setDbRequests((prev) => [...prev, newReq]);
        } else {
          await updateDoc(doc(db, "shared_portals", docId), {
            requests: arrayUnion(newReq)
          });
        }
        console.log("[Portal] Persistent request submitted to Firestore!");
      } catch (e) {
        console.error("[Portal] Error saving request to Firestore:", e);
      }
    } else {
      const localReqs = JSON.parse(localStorage.getItem("lss_local_portal_requests") || "[]");
      const updated = [...localReqs, newReq];
      localStorage.setItem("lss_local_portal_requests", JSON.stringify(updated));
      setDbRequests(updated);
    }

    // Always push to the specialist's queue lss_project_solicitations
    try {
      const existingSols = JSON.parse(localStorage.getItem("lss_project_solicitations") || "[]");
      localStorage.setItem("lss_project_solicitations", JSON.stringify([...existingSols, newSolicitation]));
      console.log("[Portal] Solicitation successfully added to Specialist queue.");
    } catch (e) {
      console.error("[Portal] Error writing to specialist's lss_project_solicitations list:", e);
    }
    
    setSuccessMsg("Seu relato foi validado e enviado com sucesso para análise do especialista técnico na ferramenta!");
    setIsSubmittingGuided(false);
    
    // Clear inputs and reset wizard back to Step 0
    setGuidedGatilho("");
    setGuidedFluxo("");
    setGuidedDesvios("");
    setGuidedFerramentas("");
    setGuidedEntrega("");
    setGuidedRegras("");
    setWizardStep(0);
  };

  const renderDataView = () => {
    if (!selectedProjectId) {
      return (
        <div className="bg-white p-12 text-center text-gray-400 italic border-4 border-dashed border-gray-200 mt-4 rounded">
          Selecione um de seus projetos LSS ativos para consultar os Dados & Relatórios.
        </div>
      );
    }
    const currentData = projectDataStore[selectedProjectId] || {};
    const stepsData = currentData.steps || [];
    const arrivalRateData = currentData.arrivalRate || 10;
    const charterData = currentData.charter || { name: "", objective: "", scope: "", timeline: "", budget: 0, roitarget: 0, team: { champion:"", blackBelt:"", greenBelts:[], members:[] } };
    const sipocData = currentData.sipoc || { suppliers:[], inputs:[], process:[], outputs:[], customers:[] };
    const statsData = calculateProcessMetrics(stepsData, arrivalRateData);

    if (activePortalTab === "MAP") {
      return (
        <div className="bg-[#FAF9F6] border-2 border-gray-300 p-4 mt-6">
          <VisualProcessMapper steps={stepsData} setSteps={() => {}} bottleneckStepName={statsData.bottleneckStepName} onOpenDetails={() => {}} activeAreaId={"core_ops"} onSwitchArea={() => {}} />
        </div>
      );
    }
    if (activePortalTab === "DASHBOARD") {
      return (
        <div className="space-y-6 mt-6">
          <SigmaTrendDashboard stats={statsData} onNavigateHome={() => {}} />
          <div className="pt-8 border-t-4 border-gray-300">
            <BiStudio steps={stepsData} stats={statsData} arrivalRate={arrivalRateData} onNavigateHome={() => {}} onOpenStepDetails={() => {}} />
          </div>
        </div>
      );
    }
    if (activePortalTab === "REPORT") {
      return (
        <div className="bg-white p-2 border-2 border-[#1A1A1A] shadow-lg mt-6">
          <ReportPresentationGenerator steps={stepsData} stats={statsData} charter={charterData} sipoc={sipocData} controlPlans={currentData.controlPlans || []} arrivalRate={arrivalRateData} />
        </div>
      );
    }
    return null;
  };

  const renderEasyMappingView = () => {
    const easyStats = calculateProcessMetrics(easySteps, easyArrivalRate);
    
    return (
      <div className="space-y-6 mt-6 animate-fadeIn">
        {/* Top Header info for Easy mapping */}
        <div className="bg-linear-to-r from-indigo-950 via-slate-900 to-[#1A1A1A] text-white p-6 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,1)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-2 border-slate-900">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold tracking-widest text-[#C49746] bg-amber-500/10 px-2 py-0.5 border border-[#C49746]/20 uppercase">
              Simulador LSS Intuitivo
            </span>
            <h2 className="text-xl font-serif font-black tracking-wide text-[#F5F2ED] uppercase">
              🌱 Mapeador de Processos Descomplicado
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-sans max-w-2xl">
              Modele as etapas operacionais de seu negócio sem termos técnicos complicados. Receba um diagnóstico automático das pilhas acumuladas, descubra qual é seu maior gargalo e acione nossa IA para sugerir ideias imediatas de alívio!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0 w-full md:w-auto">
            {/* Sector / Business Type selector */}
            <div className="space-y-1">
              <label className="text-[9px] font-mono font-bold text-[#C49746] uppercase block">
                Setor da Empresa:
              </label>
              <select
                value={easyBusinessType}
                onChange={(e) => {
                  const val = e.target.value as any;
                  if (confirm("Deseja redefinir as etapas para os templates padrão deste setor? Suas alterações locais serão limpas.")) {
                    setEasyBusinessType(val);
                    loadDefaultEasyStepsForSector(val);
                  } else {
                    setEasyBusinessType(val);
                  }
                }}
                className="bg-[#1A1A1A] border border-[#C49746]/40 text-xs font-mono font-bold text-[#F5F2ED] p-2 w-full sm:w-44 focus:ring-1 focus:ring-[#C49746]"
              >
                <option value="SERVICES">💼 Prestação de Serviços</option>
                <option value="INDUSTRIAL">🏭 Indústria/Manufatura</option>
                <option value="RETAIL">🛍️ Comércio & Varejo</option>
                <option value="LOGISTICS">📦 Logística & Despacho</option>
              </select>
            </div>
            
            {/* Arrival Rate demand selector */}
            <div className="space-y-1">
              <label className="text-[9px] font-mono font-bold text-[#C49746] uppercase block">
                Entrada (Novos pedidos / hora):
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="0.5"
                  max="1000"
                  step="0.5"
                  value={easyArrivalRate}
                  onChange={(e) => setEasyArrivalRate(Math.max(0.1, parseFloat(e.target.value) || 1))}
                  className="bg-[#1A1A1A] border border-[#C49746]/40 text-xs font-mono font-bold text-[#F5F2ED] p-2 w-20 focus:ring-1 focus:ring-[#C49746]"
                />
                <span className="text-[10.5px] text-slate-400 font-mono">pedidos/h</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sub tabs of easy mapping workspace */}
        <div className="flex flex-wrap border-b-2 border-gray-300 gap-1.5">
          <button
            onClick={() => setEasyActiveSubTab("FLOW")}
            className={`px-4 py-2.5 text-xs font-mono font-bold uppercase transition-all border-b-2 -mb-0.5 flex items-center gap-1.5 cursor-pointer ${
              easyActiveSubTab === "FLOW"
                ? "border-indigo-950 text-indigo-950 font-black scale-102 border-b-3"
                : "border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-200"
            }`}
          >
            <Layers className="w-4 h-4" /> 1. Lista de Atividades ({easySteps.length})
          </button>
          
          <button
            onClick={() => setEasyActiveSubTab("METRICS")}
            className={`px-4 py-2.5 text-xs font-mono font-bold uppercase transition-all border-b-2 -mb-0.5 flex items-center gap-1.5 cursor-pointer ${
              easyActiveSubTab === "METRICS"
                ? "border-indigo-950 text-indigo-950 font-black scale-102 border-b-3"
                : "border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-200"
            }`}
          >
            <TrendingUp className="w-4 h-4" /> 2. Diagnóstico & Gargalos
          </button>

          <button
            onClick={() => setEasyActiveSubTab("INDICATORS")}
            className={`px-4 py-2.5 text-xs font-mono font-bold uppercase transition-all border-b-2 -mb-0.5 flex items-center gap-1.5 cursor-pointer ${
              easyActiveSubTab === "INDICATORS"
                ? "border-indigo-950 text-indigo-950 font-black scale-102 border-b-3"
                : "border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-200"
            }`}
          >
            <Target className="w-4 h-4 text-[#D97706]" /> 3. Matriz de Indicadores (3 Esferas)
          </button>
          
          <button
            onClick={() => setEasyActiveSubTab("AI_CONSULT")}
            className={`px-4 py-2.5 text-xs font-mono font-bold uppercase transition-all border-b-2 -mb-0.5 flex items-center gap-1.5 cursor-pointer ${
              easyActiveSubTab === "AI_CONSULT"
                ? "border-indigo-950 text-indigo-950 font-black scale-102 border-b-3"
                : "border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-200"
            }`}
          >
            <Sparkles className="w-4 h-4 text-indigo-650" /> 4. Conselhos da IA & Plano Kaizen
          </button>
        </div>

        {/* Render child view depend on easyActiveSubTab */}
        {easyActiveSubTab === "FLOW" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            
            {/* Steps stream */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-mono font-bold uppercase text-slate-800 tracking-wider">
                  Etapas Atuais do Processo:
                </h3>
                <button
                  onClick={() => {
                    resetEasyStepForm();
                    setIsAddingEasyStep(true);
                  }}
                  className="bg-[#1A1A1A] text-white font-mono px-3 py-1.5 text-[10.5px] uppercase font-bold flex items-center gap-1 border border-slate-900 hover:bg-[#C49746] hover:text-white transition-all shadow-[2px_2px_0px_rgba(0,0,0,1)] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar Etapa
                </button>
              </div>

              {easySteps.length === 0 ? (
                <div className="bg-white p-12 text-center text-slate-450 italic border border-slate-300">
                  Nenhuma etapa cadastrada no simulador. Crie suas próprias rotinas operacionais clicando no botão acima!
                </div>
              ) : (
                <div className="space-y-3.5 animate-fadeIn">
                  {easySteps.map((step, idx) => {
                    const capacity = (60 / step.processingTime) * step.resourceCount;
                    const isStepSaturated = easyArrivalRate >= capacity;
                    
                    return (
                      <div
                        key={step.id}
                        className={`bg-white p-4 relative border shadow-[3px_3px_0px_rgba(0,0,0,0.06)] hover:shadow-[3px_3px_0px_rgba(0,0,0,0.15)] transition-all ${
                          isStepSaturated ? "border-red-400 hover:border-red-500 bg-red-50/10" : "border-slate-300 hover:border-slate-400"
                        }`}
                      >
                        {/* Sequence circle */}
                        <div className="absolute top-3 left-3 bg-[#1A1A1A] text-white font-mono text-[10px] w-5 h-5 flex items-center justify-center font-extrabold">
                          {idx + 1}
                        </div>

                        <div className="pl-8 space-y-3">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-gray-100 pb-2">
                            <div>
                              <h4 className="text-sm font-black text-slate-900 leading-snug">
                                {step.name}
                              </h4>
                              <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                                Responsável: <strong className="text-slate-800">{step.resource}</strong> ({step.resourceCount} {step.resourceCount === 1 ? "pessoa" : "pessoas"})
                              </p>
                            </div>
                            
                            {/* Action buttons */}
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleEditEasyStep(step.id)}
                                className="p-1 px-2 border border-slate-350 bg-slate-100 text-slate-700 hover:bg-slate-200 font-mono text-[9.5px] uppercase font-bold flex items-center gap-1 cursor-pointer transition-all"
                              >
                                <Edit2 className="w-3 h-3" /> Editar
                              </button>
                              <button
                                onClick={() => handleDeleteEasyStep(step.id)}
                                className="p-1 px-2 border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 font-mono text-[9.5px] uppercase font-bold flex items-center gap-1 cursor-pointer transition-all"
                              >
                                <Trash2 className="w-3 h-3" /> Excluir
                              </button>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50/70 p-2.5 border border-slate-200 text-slate-700">
                            <div>
                              <p className="text-[10px] text-slate-500 uppercase font-mono">Tempo gasto:</p>
                              <p className="text-xs font-extrabold font-mono mt-0.5">{step.processingTime} minutos</p>
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-500 uppercase font-mono">Taxa de erros:</p>
                              <p className="text-xs font-extrabold font-mono mt-0.5 text-amber-800">
                                {Math.round((1 - step.yieldRate) * 100)}%
                              </p>
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-500 uppercase font-mono">Capacidade limite:</p>
                              <p className={`text-xs font-extrabold font-mono mt-0.5 ${isStepSaturated ? "text-red-650" : "text-emerald-700"}`}>
                                {capacity.toFixed(1)} itens/hora
                              </p>
                            </div>
                          </div>

                          {step.description && (
                            <p className="text-[11.5px] text-slate-600 leading-relaxed font-sans border-l-2 border-[#C49746] pl-2">
                              {step.description}
                            </p>
                          )}

                          {isStepSaturated && (
                            <div className="bg-red-50 border border-red-200 p-2 text-[10.5px] text-red-700 flex items-center gap-1.5 font-mono">
                              <AlertCircle size={14} className="text-red-600 shrink-0 animate-bounce" />
                              <span>
                                ⚠️ <strong>Fila Formando:</strong> A demanda ({easyArrivalRate}/h) excede o limite operável ({capacity.toFixed(1)}/h) desta etapa.
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Sidebar simple adding form */}
            <div className="space-y-4">
              <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_rgba(0,0,0,1)]">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
                  <h3 className="text-xs font-mono font-black uppercase text-slate-900 tracking-wider flex items-center gap-1">
                    <Layers2 className="w-4 h-4 text-indigo-950" />
                    {editingEasyStepId ? "✏️ Editar Etapa" : "➕ Nova Etapa"}
                  </h3>
                  {isAddingEasyStep && (
                    <button onClick={resetEasyStepForm} className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-700 cursor-pointer">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {!isAddingEasyStep ? (
                  <div className="py-4 text-center space-y-3">
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Deseja mapear mais alguma atividade para entender o tempo de espera real e perdas no fluxo?
                    </p>
                    <button
                      onClick={() => setIsAddingEasyStep(true)}
                      className="w-full text-center py-2 bg-slate-50 hover:bg-[#1A1A1A] hover:text-white text-slate-950 font-mono font-bold text-[11px] uppercase border border-slate-300 transition-all select-none cursor-pointer"
                    >
                      🔌 Inserir Atividade
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3.5 animate-fadeIn">
                    {/* Step name */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block">
                        Nome da Etapa:
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Embalagem, Lavagem, Atendimento"
                        value={easyStepName}
                        onChange={(e) => setEasyStepName(e.target.value)}
                        className="w-full border border-slate-350 p-2 text-xs font-sans outline-none focus:border-amber-600 bg-slate-50/50"
                        required
                      />
                    </div>

                    {/* Whom / Resource */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block">
                          Quem faz:
                        </label>
                        <input
                          type="text"
                          placeholder="Ex: Operador, Caixa"
                          value={easyStepResource}
                          onChange={(e) => setEasyStepResource(e.target.value)}
                          className="w-full border border-slate-350 p-2 text-xs font-sans outline-none focus:border-amber-600 bg-slate-50/50"
                        />
                      </div>
                      
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block text-right">
                          Qtd Pessoas:
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="99"
                          value={easyStepResourceCount}
                          onChange={(e) => setEasyStepResourceCount(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full border border-slate-350 p-2 text-xs font-mono outline-none focus:border-amber-600 text-right bg-slate-50/50"
                        />
                      </div>
                    </div>

                    {/* Cycle Process Time & failure percent */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block">
                          Tempo (min):
                        </label>
                        <input
                          type="number"
                          min="0.1"
                          max="999"
                          step="0.1"
                          value={easyStepProcessingTime}
                          onChange={(e) => setEasyStepProcessingTime(Math.max(0.1, parseFloat(e.target.value) || 1))}
                          className="w-full border border-slate-350 p-2 text-xs font-mono outline-none focus:border-amber-600 bg-slate-50/50"
                        />
                      </div>
                      
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block text-right">
                          % Erros:
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="99"
                          value={easyStepFailureRate}
                          onChange={(e) => setEasyStepFailureRate(Math.min(99, Math.max(0, parseInt(e.target.value) || 0)))}
                          className="w-full border border-slate-350 p-2 text-xs font-mono outline-none focus:border-amber-600 text-right bg-slate-50/50"
                        />
                      </div>
                    </div>

                    {/* Small description */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-slate-705 block">
                        Rotina / Regulamento:
                      </label>
                      <textarea
                        placeholder="O que de fato é executado nesta tarefa?..."
                        value={easyStepDescription}
                        onChange={(e) => setEasyStepDescription(e.target.value)}
                        className="w-full border border-slate-350 p-2 text-xs font-sans outline-none h-16 focus:border-amber-600 bg-slate-50/50"
                      />
                    </div>

                    {/* Actions form */}
                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={resetEasyStepForm}
                        className="flex-1 py-2 font-mono text-[10px] uppercase font-bold text-slate-500 bg-white border border-slate-300 hover:bg-slate-50 text-center cursor-pointer"
                      >
                        Cancelar
                      </button>
                      
                      <button
                        onClick={editingEasyStepId ? handleUpdateEasyStep : handleAddEasyStep}
                        className="flex-1 py-2 font-mono text-[10px] uppercase font-bold bg-[#1A1A1A] text-white hover:bg-slate-800 border border-slate-900 text-center cursor-pointer"
                      >
                        {editingEasyStepId ? "Confirmar" : "Salvar"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {easyActiveSubTab === "METRICS" && (
          <div className="space-y-6 animate-fadeIn">
            {/* Bento metrics collection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              
              {/* Lead Time block */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-indigo-900 px-2 py-0.5 bg-indigo-50 border border-indigo-100">
                      tempo total (lead time)
                    </span>
                    <Clock size={16} className="text-indigo-600" />
                  </div>
                  <h4 className="text-2xl font-serif font-black text-slate-900 mt-4">
                    {easyStats.leadTime > 999 
                      ? `${(easyStats.leadTime / 60).toFixed(1)} horas` 
                      : `${easyStats.leadTime.toFixed(1)} minutos`}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Tempo de Atravessamento (Lead Time):</strong> É a rota temporal completa que o cliente experimenta, incluindo os gargalos de espera acumulados nas filas físicas/digitais.
                  </p>
                </div>
              </div>

              {/* Bottleneck block */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-red-900 px-2 py-0.5 bg-red-50 border border-red-150">
                      posto mais lento / gargalo
                    </span>
                    <AlertTriangle size={16} className="text-red-500" />
                  </div>
                  <h4 className="text-[15px] font-black uppercase text-red-700 mt-4 truncate" title={easyStats.bottleneckStepName}>
                    {easyStats.bottleneckStepName ? `🚨 ${easyStats.bottleneckStepName}` : "Fluido (Sem Gargalo)"}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Etapa Crítica:</strong> Este posto determina a velocidade limite de sua empresa inteira. Otimizar as outras etapas sem agir no gargalo é desperdício de energia.
                  </p>
                </div>
              </div>

              {/* Rolled first pass yield block */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-emerald-900 px-2 py-0.5 bg-emerald-50 border border-emerald-150">
                      qualidade consolidada
                    </span>
                    <CheckCircle2 size={16} className="text-emerald-650" />
                  </div>
                  <h4 className="text-2xl font-serif font-black text-emerald-800 mt-4">
                    {(easyStats.rolledFirstPassYield * 100).toFixed(1)}%
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Rendimento Real (Rolled Yield):</strong> Probabilidade científica de uma demanda ser finalizada de primeira classe correta, sem desperdícios operacionais ou perdas.
                  </p>
                </div>
              </div>

              {/* System Capacity block */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-amber-900 px-2 py-0.5 bg-amber-50 border border-amber-100">
                      capacidade máxima de saída
                    </span>
                    <Zap size={16} className="text-amber-500" />
                  </div>
                  <h4 className="text-2xl font-serif font-black text-[#C49746] mt-4">
                    {easyStats.systemCapacity.toFixed(1)} itens/hora
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Capacidade do Sistema:</strong> Volume máximo absoluto de demandas concluídas faturáveis que sua operação é fisicamente capaz de descarregar em uma hora de atividade.
                  </p>
                </div>
              </div>

              {/* Work in progress block / Queues */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-slate-800 px-2 py-0.5 bg-slate-50 border border-slate-150">
                      serviços acumulados (WIP)
                    </span>
                    <Layers size={16} className="text-slate-650" />
                  </div>
                  <h4 className="text-2xl font-serif font-black text-slate-900 mt-4">
                    {easyStats.systemWip.toFixed(1)} demandas
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Pilhas no Fluxo (Trabalho em Processamento):</strong> Estimativa de quanto trabalho fica estagnado nas mesas acumulando estresse para a equipe em qualquer momento aleatório.
                  </p>
                </div>
              </div>

              {/* Sigma Level simple */}
              <div className="bg-white p-5 border border-slate-300 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] hover:border-indigo-350 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-orange-900 px-2 py-0.5 bg-orange-50 border border-orange-150">
                      robustez lean six sigma
                    </span>
                    <Award size={16} className="text-orange-500" />
                  </div>
                  <h4 className="text-2xl font-serif font-black text-orange-850 mt-4">
                    {easyStats.sigmaLevel.toFixed(2)} σ
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5">
                    <strong>Nível de Estabilidade:</strong> Métrica matemática contra falhas. Processos rudimentares operam em torno de 1σ-2σ de estabilidade; excelência de nível mundial mira acima de 4.5σ.
                  </p>
                </div>
              </div>

            </div>

            {/* Health verdict banner */}
            <div className="border border-slate-900 bg-[#1A1A1A] p-5 text-[#F5F2ED] rounded-none">
              <h5 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-[#C49746]" /> Veredito Automatizado de Gargalo
              </h5>
              <p className="text-[11.5px] text-slate-350 leading-relaxed font-sans mt-2 max-w-4xl">
                Seu fluxo conta com <strong>{easySteps.length} etapas</strong>. Diante da entrada parametrizada de <strong>{easyArrivalRate} pedidos por hora</strong>, 
                {easyStats.systemWip > easySteps.length * 2.5 ? (
                  <span className="text-red-400 block mt-1.5 font-bold">
                    ⚠️ Alerta de Saturação: Seu processo está acumulando gargalos severos de fila ({easyStats.systemWip.toFixed(1)} itens travados em média). Melhore o tempo operacional ou as pessoas da etapa "{easyStats.bottleneckStepName}" com ajuda da consultoria IA ao lado.
                  </span>
                ) : (
                  <span className="text-emerald-400 block mt-1.5 font-bold">
                    ✅ Fluxo Saudável: Seu processo opera com estabilidade! A entrada de trabalho está condizente com a velocidade produtiva geral das suas atividades.
                  </span>
                )}
              </p>
            </div>
          </div>
        )}

        {easyActiveSubTab === "INDICATORS" && (() => {
          const simulatedArrivalRate = Math.max(12, easyArrivalRate * 1.6);
          const simulatedSteps = easySteps.map((s) => ({
            ...s,
            yieldRate: Math.max(0.45, s.yieldRate * 0.6),
            processingTime: s.processingTime * 1.7,
          }));
          const simulatedStats = calculateProcessMetrics(simulatedSteps, simulatedArrivalRate);

          return (
            <div className="space-y-6 animate-fadeIn font-sans text-slate-800">
              
              {/* Infographic Banner Title */}
              <div className="bg-[#1A1A1A] border-2 border-slate-900 p-5 md:p-6 text-[#F5F2ED] rounded-none relative overflow-hidden">
                <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center justify-center p-4">
                  <Target size={180} className="text-[#C49746]" />
                </div>
                <div className="relative z-10 space-y-1.5 max-w-3xl">
                  <span className="text-[9.5px] font-mono font-black text-[#C49746] tracking-widest px-2 py-0.5 bg-[#C49746]/10 border border-[#C49746]/30 uppercase">
                    Framework de Performance: Metrologia Lean
                  </span>
                  <h3 className="text-xl md:text-2xl font-serif font-black tracking-tight text-white leading-tight">
                    Os 3 Tipos de Indicadores que Toda Área Precisa Ter
                  </h3>
                  <p className="text-[12px] text-slate-300 leading-relaxed font-sans pt-1">
                    A maioria das empresas mede apenas o <strong>RESULTADO</strong>. Mas o resultado é consequência direta da engrenagem anterior. Para obter controle de verdade da sua operação e blindar seus resultados, você precisa monitorar a relação contínua entre as três esferas.
                  </p>
                </div>
              </div>

              {/* Three Indicators Pillars (Infographic Layout) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* 1. Indicador de Entrada */}
                <div className="bg-white border-2 border-[#059669] shadow-[3px_3px_0px_rgba(5,150,105,1)] flex flex-col justify-between p-5">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 border-b-2 border-[#059669]/20 pb-3">
                      <div className="bg-[#059669] text-white p-2 rounded-full flex items-center justify-center">
                        <ArrowRight size={18} className="rotate-90 md:rotate-0" />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-black text-[#059669] uppercase tracking-wider">01. Esfera de Entrada</span>
                        <h4 className="text-sm font-mono font-black text-slate-900 uppercase">Indicadores de Entrada</h4>
                      </div>
                    </div>

                    <p className="text-[11.5px] text-slate-550 leading-relaxed font-sans">
                      Medem a <strong>qualidade, conformidade e disponibilidade</strong> de insumos e recursos que dão início e alimentam a rotina operacional do processo.
                    </p>

                    <div className="space-y-2.5 bg-emerald-50/30 p-3 border border-emerald-100 rounded-sm">
                      <p className="text-[10px] font-mono font-black uppercase text-[#047857]">Exemplos Clássicos:</p>
                      <ul className="space-y-1.5 text-xs text-slate-705">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#059669] shrink-0" />
                          <span>% de solicitações dentro do padrão</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#059669] shrink-0" />
                          <span>Disponibilidade de ferramentas/rede</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#059669] shrink-0" />
                          <span>Qualidade das informações recebidas</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#059669] shrink-0" />
                          <span>Capacidade habilitada no início do dia</span>
                        </li>
                      </ul>
                    </div>

                    {/* Active target list */}
                    <div className="space-y-2 border-t border-slate-150 pt-3">
                      <p className="text-[9.5px] font-mono font-bold text-slate-500 uppercase">Seu Dashboard Ativo (Entrada):</p>
                      {customKpis.filter(k => k.category === "ENTRADA" && k.checked).length === 0 ? (
                        <p className="text-xs text-slate-400 italic">Nenhum indicador de entrada ativado de momento.</p>
                      ) : (
                        <div className="space-y-1.5">
                          {customKpis.filter(k => k.category === "ENTRADA" && k.checked).map(kpi => (
                            <div key={kpi.id} className="flex items-center justify-between bg-emerald-50/15 p-1.5 border border-emerald-300/30 text-xs font-mono">
                              <span className="truncate text-slate-700 max-w-[150px]" title={kpi.name}>🔹 {kpi.name}</span>
                              <span className="bg-emerald-100 text-emerald-800 font-bold px-1 py-0.5 text-[9.5px] rounded-xs">{kpi.target || "N/A"}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-[#E6F4EA] border border-emerald-200 p-2 text-center text-[10.5px] font-mono mt-4 font-bold text-[#137333]">
                    📊 Demanda de Entrada: {easyArrivalRate} pedidos/h
                  </div>
                </div>

                {/* 2. Indicador de Processo */}
                <div className="bg-white border-2 border-indigo-950 shadow-[3px_3px_0px_rgba(30,41,59,1)] flex flex-col justify-between p-5">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 border-b-2 border-slate-900/10 pb-3">
                      <div className="bg-indigo-950 text-white p-2 rounded-full flex items-center justify-center">
                        <Cpu size={18} />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-black text-indigo-950 uppercase tracking-wider">02. Esfera de Meio</span>
                        <h4 className="text-sm font-mono font-black text-slate-900 uppercase">Indicadores de Processo</h4>
                      </div>
                    </div>

                    <p className="text-[11.5px] text-slate-550 leading-relaxed font-sans">
                      Medem a <strong>eficiência da execução, tempo operacional e produtividade</strong> durante a realização das atividades em si pelas equipes.
                    </p>

                    <div className="space-y-2.5 bg-indigo-50/20 p-3 border border-indigo-100 rounded-sm">
                      <p className="text-[10px] font-mono font-black uppercase text-indigo-900">Exemplos Clássicos:</p>
                      <ul className="space-y-1.5 text-xs text-slate-705">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-indigo-950 shrink-0" />
                          <span>Tempo médio de ciclo (Cycle Time)</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-indigo-950 shrink-0" />
                          <span>Taxa de retrabalho / Desvios</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-indigo-950 shrink-0" />
                          <span>Volume físico processador por dia</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-indigo-950 shrink-0" />
                          <span>Ocupação / Produtividade da equipe</span>
                        </li>
                      </ul>
                    </div>

                    {/* Active target list */}
                    <div className="space-y-2 border-t border-slate-150 pt-3">
                      <p className="text-[9.5px] font-mono font-bold text-slate-500 uppercase">Seu Dashboard Ativo (Processo):</p>
                      {customKpis.filter(k => k.category === "PROCESSO" && k.checked).length === 0 ? (
                        <p className="text-xs text-slate-400 italic">Nenhum indicador de processo ativado de momento.</p>
                      ) : (
                        <div className="space-y-1.5">
                          {customKpis.filter(k => k.category === "PROCESSO" && k.checked).map(kpi => (
                            <div key={kpi.id} className="flex items-center justify-between bg-indigo-50/20 p-1.5 border border-indigo-200/40 text-xs font-mono">
                              <span className="truncate text-slate-700 max-w-[150px]" title={kpi.name}>🔹 {kpi.name}</span>
                              <span className="bg-indigo-100 text-indigo-900 font-bold px-1 py-0.5 text-[9.5px] rounded-xs">{kpi.target || "N/A"}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-[#E8EAF6] border border-indigo-200 p-2 text-center text-[10.5px] font-mono mt-4 font-bold text-[#1A237E]">
                    ⚙️ Lead Time Médio: {easyStats.leadTime.toFixed(1)} min
                  </div>
                </div>

                {/* 3. Indicador de Resultado */}
                <div className="bg-white border-2 border-[#15803D] shadow-[3px_3px_0px_rgba(21,128,61,1)] flex flex-col justify-between p-5">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 border-b-2 border-emerald-900/10 pb-3">
                      <div className="bg-[#15803D] text-white p-2 rounded-full flex items-center justify-center">
                        <Award size={18} />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-black text-[#15803D] uppercase tracking-wider">03. Esfera de Fim</span>
                        <h4 className="text-sm font-mono font-black text-slate-900 uppercase">Indicadores de Resultado</h4>
                      </div>
                    </div>

                    <p className="text-[11.5px] text-slate-550 leading-relaxed font-sans">
                      Medem o que o processo efetivamente <strong>conclui e entrega ao cliente</strong>, refletindo os resultados finais de negócio.
                    </p>

                    <div className="space-y-2.5 bg-green-50/20 p-3 border border-green-150 rounded-sm">
                      <p className="text-[10px] font-mono font-black uppercase text-[#15803D]">Exemplos Clássicos:</p>
                      <ul className="space-y-1.5 text-xs text-slate-755">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#15803D] shrink-0" />
                          <span>% de entregas corretas no prazo (SLA)</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#15803D] shrink-0" />
                          <span>Taxa de satisfação (NPS ou Satisfação)</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#15803D] shrink-0" />
                          <span>Taxa de erro final / Reprovações em lote</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#15803D] shrink-0" />
                          <span>Cumprimento de metas estratégicas</span>
                        </li>
                      </ul>
                    </div>

                    {/* Active target list */}
                    <div className="space-y-2 border-t border-slate-150 pt-3">
                      <p className="text-[9.5px] font-mono font-bold text-slate-500 uppercase">Seu Dashboard Ativo (Resultado):</p>
                      {customKpis.filter(k => k.category === "RESULTADO" && k.checked).length === 0 ? (
                        <p className="text-xs text-slate-400 italic">Nenhum indicador de resultado ativado de momento.</p>
                      ) : (
                        <div className="space-y-1.5">
                          {customKpis.filter(k => k.category === "RESULTADO" && k.checked).map(kpi => (
                            <div key={kpi.id} className="flex items-center justify-between bg-green-50/20 p-1.5 border border-green-200/40 text-xs font-mono">
                              <span className="truncate text-slate-700 max-w-[150px]" title={kpi.name}>🔹 {kpi.name}</span>
                              <span className="bg-[#15803D]/10 text-[#15803D] font-bold px-1 py-0.5 text-[9.5px] rounded-xs">{kpi.target || "N/A"}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-[#E8F5E9] border border-green-200 p-2 text-center text-[10.5px] font-mono mt-4 font-bold text-[#1B5E20]">
                    💎 Rendimento Global (FTY): {(easyStats.rolledFirstPassYield * 100).toFixed(1)}%
                  </div>
                </div>

              </div>

              {/* Relação Entre Eles - Interactive Simulator */}
              <div className="border border-slate-900 bg-[#FAF9F6] p-5 shadow-[4px_4px_0px_rgba(0,0,0,1)] rounded-none space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-3">
                  <div>
                    <h4 className="text-sm font-mono font-black uppercase text-slate-900 tracking-tight flex items-center gap-1.5">
                      🔗 Simulador de Causa &amp; Efeito ("A Dinâmica Das Esferas")
                    </h4>
                    <p className="text-xs text-slate-550 mt-1 font-sans">
                      Descubra como ruídos ou falhas na entrada degradam a eficiência do processo interno e colapsam o resultado final de forma científica.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsSimulatingBadInput(!isSimulatingBadInput)}
                    className={`px-4 py-2 text-[11px] font-mono font-bold uppercase cursor-pointer rounded-none border transition-all flex items-center gap-1.5 select-none ${
                      isSimulatingBadInput
                        ? "bg-red-650 border-red-750 hover:bg-red-700 text-white animate-pulse"
                        : "bg-slate-102 hover:bg-slate-200 text-slate-800 border-slate-350"
                    }`}
                  >
                    <span>{isSimulatingBadInput ? "🟢 Desativar Estresse (Normalizar)" : "🧪 Forçar Entrada Ruim/Com Defeito"}</span>
                  </button>
                </div>

                {isSimulatingBadInput ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono animate-fadeIn">
                    
                    {/* Simulated Entrada */}
                    <div className="bg-red-50 border border-red-200 p-4 space-y-3 relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 right-0 bg-red-650 text-white font-mono text-[8px] px-2 py-0.5 uppercase tracking-wider font-bold">
                        Estágio 1 (Causa)
                      </div>
                      <div className="space-y-2">
                        <h5 className="font-extrabold text-red-900 uppercase text-[11px] flex items-center gap-1">🔴 ENTRADA Compromete-se</h5>
                        <p className="text-[11px] text-slate-600 leading-relaxed font-sans">
                          A área passa a receber dados incompletos ou errados de clientes e a demanda nominal salta para <strong>{simulatedArrivalRate.toFixed(1)}/hora</strong> (+60%).
                        </p>
                      </div>
                      <div className="bg-white/80 p-2.5 border border-red-150 text-[10.5px] space-y-1">
                        <div className="text-red-750 font-bold">📉 Cadastro Ruim / Incompleto</div>
                        <div className="text-red-750 font-bold">⚠️ Sobrecarga Crítica (+60%)</div>
                      </div>
                    </div>

                    {/* Simulated Processo */}
                    <div className="bg-amber-50 border border-amber-200 p-4 space-y-3 relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 right-0 bg-amber-650 text-white font-mono text-[8px] px-2 py-0.5 uppercase tracking-wider font-bold">
                        Estágio 2 (Efeito Meio)
                      </div>
                      <div className="space-y-2">
                        <h5 className="font-extrabold text-amber-900 uppercase text-[11px] flex items-center gap-1">⚠️ PROCESSO Sofre e Trava</h5>
                        <p className="text-[11px] text-slate-600 leading-relaxed font-sans">
                          Devido aos erros de entrada, a equipe gasta o triplo do tempo com triagem, retrabalho e correções manuais. O gargalo transborda!
                        </p>
                      </div>
                      <div className="bg-white/80 p-2.5 border border-amber-150 text-[10.5px] space-y-1">
                        <div>⏱️ Tempo de Ciclo: <strong className="text-amber-700 font-extrabold">{simulatedStats.leadTime.toFixed(1)} min</strong></div>
                        <div>🚨 Saturação total em: <strong className="text-amber-700">"{simulatedStats.bottleneckStepName}"</strong></div>
                      </div>
                    </div>

                    {/* Simulated Resultado */}
                    <div className="bg-red-100/30 border border-red-300 p-4 space-y-3 relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 right-0 bg-red-800 text-white font-mono text-[8px] px-2 py-0.5 uppercase tracking-wider font-bold">
                        Estágio 3 (Consequência)
                      </div>
                      <div className="space-y-2">
                        <h5 className="font-extrabold text-red-950 uppercase text-[11px] flex items-center gap-1">❌ RESULTADO Piora Drasticamente</h5>
                        <p className="text-[11px] text-red-900 leading-relaxed font-sans">
                          O cliente final experimenta atrasos acumulados absurdo. O rendimento produtivo colapsa com alta taxa de cancelamento.
                        </p>
                      </div>
                      <div className="bg-red-950 text-white p-2 text-center text-[11px] rounded-xs font-bold">
                        Estabilidade: {simulatedStats.sigmaLevel.toFixed(2)} σ • Yield: {(simulatedStats.rolledFirstPassYield * 100).toFixed(1)}%
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="bg-[#EFF6FF] border border-blue-200 p-4 flex flex-col sm:flex-row items-center gap-4 text-xs font-mono text-[#1E40AF]">
                    <div className="bg-[#3B82F6] text-white p-2.5 rounded-full shrink-0 flex items-center justify-center">
                      <Info size={16} />
                    </div>
                    <div>
                      <p className="font-bold uppercase text-[11px] text-blue-900">📌 Teste o Alerta de Causa &amp; Efeito acima!</p>
                      <p className="text-slate-650 font-medium leading-relaxed font-sans mt-0.5">
                        O erro mais brutal cometido por gestores comuns é monitorar unicamente métricas finais (Ex: "Faturamento" ou "Reclamações"). Quando o resultado final desmorona, ninguém sabe exatamente onde reside o problema porque faltavam parâmetros estruturais de entrada e processamento. Clique no botão de teste ao lado e experimente a reação física do fluxo!
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* KPI Configuration and Customization Engine */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                
                {/* Active dictionary list - 2 Columns */}
                <div className="lg:col-span-2 bg-white border border-slate-300 p-5 shadow-[2px_2px_0px_rgba(0,0,0,0.05)] space-y-4">
                  <div>
                    <h4 className="text-xs font-mono font-black uppercase text-slate-900 tracking-wider">
                      📒 Cadastro e Gestão de Metas de Performance
                    </h4>
                    <p className="text-[11px] text-slate-500 font-sans mt-0.5">
                      Personalize seus próprios limites. Selecione, edite ou declare as metas operacionais de sua área abaixo de forma dinâmica.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {customKpis.map((kpi) => {
                      const badgeColor = kpi.category === "ENTRADA" 
                        ? "border-[#059669] bg-emerald-50/30 text-[#059669]" 
                        : kpi.category === "PROCESSO" 
                        ? "border-indigo-950 bg-indigo-50/25 text-indigo-950" 
                        : "border-[#15803D] bg-green-50/25 text-[#15803D]";

                      return (
                        <div
                          key={kpi.id}
                          className={`p-3 border-l-4 border flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[1px_1px_0px_rgba(0,0,0,0.02)] transition-all ${
                            kpi.checked ? "border-slate-300" : "border-slate-200 opacity-60 bg-gray-50/30"
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <button
                              type="button"
                              onClick={() => {
                                setCustomKpis(prev => prev.map(item => item.id === kpi.id ? { ...item, checked: !item.checked } : item));
                              }}
                              className="mt-0.5 flex-shrink-0 cursor-pointer text-slate-500 hover:text-slate-900"
                            >
                              {kpi.checked ? <CheckSquare size={16} className="text-indigo-950" /> : <Square size={16} />}
                            </button>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={`text-[8px] font-mono font-black uppercase px-2 py-0.5 border rounded-xs ${badgeColor}`}>
                                  {kpi.category}
                                </span>
                                <span className="text-xs font-bold text-slate-800 font-sans">{kpi.name}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3 pl-6 sm:pl-0">
                            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">Meta:</span>
                            <input
                              type="text"
                              value={kpi.target}
                              placeholder="Fórmula"
                              onChange={(e) => {
                                const newval = e.target.value;
                                setCustomKpis(prev => prev.map(item => item.id === kpi.id ? { ...item, target: newval } : item));
                              }}
                              className="border border-slate-350 px-2 py-1 text-xs font-mono font-bold w-28 bg-white outline-none focus:border-indigo-950 rounded-none text-right"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                setCustomKpis(prev => prev.filter(item => item.id !== kpi.id));
                              }}
                              className="p-1 text-red-500 hover:bg-red-50 hover:text-red-700 cursor-pointer transition-colors"
                              title="Excluir Métrica"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Adding new KPI section */}
                <div className="bg-white border-2 border-slate-900 p-5 shadow-[4px_4px_0px_rgba(0,0,0,1)] space-y-4">
                  <h4 className="text-xs font-mono font-black uppercase text-slate-900 tracking-wider flex items-center gap-1 border-b border-slate-150 pb-2.5">
                    <Plus size={14} className="text-[#D97706]" /> Nova Métrica / Parâmetro
                  </h4>

                  <form
                    onSubmit={(e) => e.preventDefault()}
                    className="space-y-3"
                  >
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-slate-750">Nome do Indicador:</label>
                      <input
                        type="text"
                        placeholder="Ex: Tempo de Triagem Nível 1"
                        value={newKpiName}
                        onChange={(e) => setNewKpiName(e.target.value)}
                        className="w-full border border-slate-350 p-2 text-xs font-sans outline-none focus:border-indigo-950 bg-slate-50/50"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-slate-755">Esfera (Tipologia):</label>
                      <select
                        value={newKpiCategory}
                        onChange={(e: any) => setNewKpiCategory(e.target.value)}
                        className="w-full border border-slate-350 p-2 text-xs font-mono outline-none focus:border-indigo-950 bg-slate-50"
                      >
                        <option value="ENTRADA">📥 ENTRADA (Recursos)</option>
                        <option value="PROCESSO">⚙️ PROCESSO (Eficiência)</option>
                        <option value="RESULTADO">💎 RESULTADO (Entregas)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-slate-755">Meta de Alvo (Target):</label>
                      <input
                        type="text"
                        placeholder="Ex: >= 98% ou < 30m"
                        value={newKpiTarget}
                        onChange={(e) => setNewKpiTarget(e.target.value)}
                        className="w-full border border-slate-350 p-2 text-xs font-mono outline-none focus:border-indigo-950 bg-slate-50/50"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={!newKpiName.trim()}
                      onClick={() => {
                        const newKpiItem = {
                          id: `kpi_${Date.now()}`,
                          category: newKpiCategory,
                          name: newKpiName.trim(),
                          target: newKpiTarget.trim() || "A definir",
                          checked: true,
                        };
                        setCustomKpis(prev => [...prev, newKpiItem]);
                        setNewKpiName("");
                        setNewKpiTarget("");
                      }}
                      className="w-full text-center py-2 bg-[#1A1A1A] hover:bg-[#D97706] text-white hover:text-white font-mono font-bold text-[11px] uppercase transition-all select-none cursor-pointer disabled:opacity-40 disabled:hover:bg-[#1A1A1A]"
                    >
                      🔌 Incorporar à Matriz
                    </button>
                    <p className="text-[9px] text-slate-450 font-sans leading-relaxed text-center leading-normal">
                      Os indicadores configurados alimentam dinamicamente a governança de métricas do seu painel e podem ser exportados.
                    </p>
                  </form>
                </div>

              </div>

            </div>
          );
        })()}

        {easyActiveSubTab === "AI_CONSULT" && (
          <div className="space-y-6 animate-fadeIn">
            
            {/* AI consultant block */}
            <div className="border border-indigo-950 bg-linear-to-br from-indigo-50/50 to-amber-50/30 p-6 shadow-[3px_3px_0px_rgba(0,0,0,1)] rounded-none space-y-5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-indigo-100 pb-4">
                <div className="space-y-1">
                  <span className="text-[9px] uppercase font-mono tracking-wider font-extrabold px-1.5 py-0.5 bg-amber-100 border border-amber-200 text-amber-800 rounded-xs">
                    consultoria lean express inteligente
                  </span>
                  <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-2">
                    🔮 Diagnóstico Exclusivo do Conselheiro Gemini
                  </h3>
                  <p className="text-xs text-slate-600 max-w-2xl">
                    Solicite uma auditoria rápida de IA para receber uma analogia super fácil, análise limpa livre de termos técnicos pesados e até 3 sugestões imediatas com alto impacto.
                  </p>
                </div>
                
                <button
                  disabled={isEasyAiLoading}
                  onClick={handleRequestEasyAiImprovement}
                  className={`py-2 px-5 font-mono text-xs font-black uppercase transition-all flex items-center gap-2 border select-none cursor-pointer tracking-wider shrink-0 ${
                    isEasyAiLoading
                      ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                      : "bg-[#1A1A1A] text-white border-slate-800 hover:bg-[#C49746] hover:text-white hover:border-[#C49746] shadow-[2px_2px_0px_rgba(15,23,42,1)] active:translate-x-0.5 active:translate-y-0.5 animate-pulse"
                  }`}
                >
                  {isEasyAiLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-slate-405" />
                      Consultando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      Analisar com IA
                    </>
                  )}
                </button>
              </div>

              {easyAiError && (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs font-mono">
                  ⚠️ Erro ao acionar o motor de consultoria: {easyAiError}
                </div>
              )}

              {!easyAiDiagnostic && !isEasyAiLoading && (
                <div className="py-8 text-center text-slate-400 text-xs font-mono max-w-xl mx-auto space-y-1">
                  <Brain className="w-8 h-8 text-slate-350 mx-auto animate-pulse mb-1" />
                  <p>Pronto para receber soluções estratégicas!</p>
                  <p className="font-sans text-[11px] text-slate-500">
                    O Gemini lerá suas {easySteps.length} etapas cadastradas e criará planos de ação.
                  </p>
                </div>
              )}

              {isEasyAiLoading && (
                <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-500 text-xs font-mono">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-950" />
                  <span>O Consultor Gemini está desenhando melhorias operacionais adaptadas ao seu negócio...</span>
                </div>
              )}

              {easyAiDiagnostic && !isEasyAiLoading && (
                <div className="space-y-6 animate-fadeIn">
                  
                  {/* Diagnosis */}
                  <div className="bg-white border border-slate-300 p-5 rounded-none space-y-2 leading-relaxed">
                    <h4 className="text-xs font-mono font-black uppercase text-indigo-950 flex items-center gap-1">
                      <CheckCircle2 className="w-4.5 h-4.5 text-indigo-700 font-extrabold" /> Diagnóstico da IA
                    </h4>
                    <p className="text-xs text-slate-750 leading-relaxed">
                      {easyAiDiagnostic}
                    </p>
                  </div>

                  {/* Analogy */}
                  {easyAiAnalogy && (
                    <div className="bg-amber-50/55 border border-amber-200 p-5 rounded-none space-y-2">
                      <h4 className="text-xs font-mono font-black uppercase text-amber-850 flex items-center gap-1">
                        🍔 Traduzindo o Desafio: Analogia Didática
                      </h4>
                      <p className="text-xs text-amber-900 font-serif italic leading-relaxed">
                        {easyAiAnalogy}
                      </p>
                    </div>
                  )}

                  {/* AI recommendations cards */}
                  {easyAiRecommendations && easyAiRecommendations.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-mono font-black uppercase text-indigo-900 tracking-wider flex items-center gap-1">
                        ⚡ Ideias de Otimização Propostas:
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {easyAiRecommendations.map((rec: any, idx: number) => (
                          <div
                            key={idx}
                            className="bg-white border border-slate-300 p-4 shrink-0 flex flex-col justify-between space-y-4 hover:border-indigo-400 transition-all rounded-none shadow-xs"
                          >
                            <div className="space-y-2">
                              <span className="text-[9px] uppercase font-mono tracking-wider font-extrabold px-1.5 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700">
                                Ideia #{idx + 1}
                              </span>
                              <h5 className="text-xs font-black text-slate-900 leading-snug">
                                {rec.title}
                              </h5>
                              <p className="text-[11px] text-slate-600 leading-relaxed font-sans">
                                {rec.description}
                              </p>
                              {rec.expectedBenefit && (
                                <div className="text-[10px] text-emerald-800 bg-emerald-50 p-2 border border-emerald-100 rounded-none leading-relaxed font-mono">
                                  <strong>Doará benefício:</strong> {rec.expectedBenefit}
                                </div>
                              )}
                            </div>

                            <button
                              onClick={() => handleAddEasyAiRecToTasks(rec.title, rec.description)}
                              className="w-full text-center py-2 bg-indigo-50 hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A] font-mono font-black uppercase text-[10px] border border-slate-300 transition-all cursor-pointer"
                            >
                              ➕ Guardar no Plano Kaizen
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>

            {/* Client Kaizen Action checklist */}
            <div className="border border-slate-300 bg-slate-50/50 p-6 rounded-none space-y-4 shadow-[3px_3px_0px_rgba(0,0,0,0.03)]">
              <h3 className="text-sm font-serif font-black uppercase text-slate-900 tracking-wider flex items-center gap-1.5 border-b pb-2.5">
                📋 Seu Plano Kaizen de Otimização ({easyTasks.filter(t => t.done).length} / {easyTasks.length} concluídas)
              </h3>
              
              <div className="space-y-3.5">
                {easyTasks.map(task => (
                  <div
                    key={task.id}
                    className="p-3 bg-white border border-slate-300 flex items-center justify-between hover:bg-slate-50 transition-all shadow-xs"
                  >
                    <div
                      onClick={() => handleToggleEasyTask(task.id)}
                      className="flex items-center gap-3 cursor-pointer flex-1 animate-fadeIn"
                    >
                      {task.done ? (
                        <CheckSquare className="w-5 h-5 text-emerald-600 shrink-0" />
                      ) : (
                        <Square className="w-5 h-5 text-slate-400 shrink-0" />
                      )}
                      <span className={`text-xs leading-relaxed ${task.done ? "line-through text-slate-400 font-medium font-mono" : "text-slate-800 font-semibold"}`}>
                        {task.text}
                      </span>
                    </div>
                    
                    <button
                      onClick={() => handleDeleteEasyTask(task.id)}
                      className="text-slate-450 hover:text-red-650 p-2 rounded cursor-pointer transition-all"
                      title="Excluir item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}

                {easyTasks.length === 0 && (
                  <p className="text-xs text-slate-400 italic py-4 text-center font-mono">
                    Seu plano Kaizen de melhorias está limpo. Recrute conselhos da IA acima ou adicione tarefas customizadas abaixo!
                  </p>
                )}
              </div>

              {/* Add manual task item */}
              <div className="flex gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Inserir outra melhoria operacional customizada para sua equipe..."
                  value={newEasyTaskText}
                  onChange={(e) => setNewEasyTaskText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAddEasyTaskManual()}
                  className="flex-1 bg-white border border-slate-300 p-2.5 text-xs font-sans outline-none focus:border-indigo-600 shadow-inner"
                />
                <button
                  onClick={handleAddEasyTaskManual}
                  className="bg-[#1A1A1A] text-white font-mono font-bold text-xs px-5 py-2.5 uppercase hover:bg-[#C49746] transition-all cursor-pointer shadow-[2px_2px_0px_rgba(0,0,0,1)] shrink-0"
                >
                  Adicionar
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#F5F2ED] text-[#1A1A1A] flex flex-col font-sans">
      <header className="bg-[#1A1A1A] text-white py-10 px-6 border-b-4 border-[#C49746] relative shadow-md">
        <div className="absolute top-4 right-4 flex items-center gap-4">
          <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">🏢 {companies.find(c => c.id === selectedCompanyId)?.name}</span>
          {onBackToApp && <button onClick={onBackToApp} className="text-[10px] font-mono text-gray-400 hover:text-white underline cursor-pointer">[Sair do Portal]</button>}
        </div>
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-serif text-white tracking-tight">Portal Exclusivo do Cliente</h1>
          <p className="text-xs text-gray-300 mt-2 max-w-2xl">Acesse seus projetos ativos, visualize o mapeamento do fluxo, indicadores de desempenho BI e os relatórios estratégicos Six Sigma consolidados.</p>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:p-8 font-sans">
        <div className="flex flex-wrap gap-2 border-b-2 border-gray-300 pb-1">
          <button onClick={() => setActivePortalTab("EASY_MAP")} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab === "EASY_MAP" ? 'bg-indigo-950 text-white shadow' : 'bg-white text-gray-750 hover:bg-indigo-50'}`}>🌱 Mapeamento Simplificado (Fácil/IA)</button>
          <button onClick={() => setActivePortalTab("NEW")} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab === "NEW" ? 'bg-[#C49746] text-white shadow' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>📋 Formulário de Processo</button>
          <button onClick={() => setActivePortalTab("MAP")} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab === "MAP" ? 'bg-[#1A1A1A] text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>🗺️ Desenho do Processo</button>
          <button onClick={() => setActivePortalTab("DASHBOARD")} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab === "DASHBOARD" ? 'bg-[#1A1A1A] text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>📈 Dashboards (BI)</button>
          <button onClick={() => setActivePortalTab("REPORT")} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab === "REPORT" ? 'bg-[#1A1A1A] text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>📑 Relatórios PDF</button>
          <button onClick={() => setActivePortalTab("BLUEPRINT" as any)} className={`px-4 py-2 text-xs font-mono font-bold uppercase transition-all ${activePortalTab as any === "BLUEPRINT" ? 'bg-blue-900 text-white shadow' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>🗺️ Blueprint de Entrega E3I</button>
        </div>

        {["MAP", "DASHBOARD", "REPORT"].includes(activePortalTab) && (
          <div className="mt-4 bg-indigo-50 border border-indigo-200 p-4 flex items-center gap-4">
            <span className="font-bold text-sm uppercase text-indigo-900 flex items-center gap-2"><Briefcase size={16} /> Projeto Ativo:</span>
            <select value={selectedProjectId} onChange={(e) => setSelectedProjectId(e.target.value)} className="px-4 py-2 border border-indigo-300 rounded text-sm bg-white min-w-[300px] outline-none">
              <option value="">-- Escolha um de seus Projetos --</option>
              {projects.filter(p => p.companyId === selectedCompanyId).map(p => (
                <option key={p.id} value={p.id}>{p.name} - ({p.status})</option>
              ))}
            </select>
          </div>
        )}

        {activePortalTab === "EASY_MAP" ? renderEasyMappingView() : (activePortalTab as any) === "BLUEPRINT" ? (
          <div className="mt-6">
            <E3IDeliveryBlueprint />
          </div>
        ) : ["MAP", "DASHBOARD", "REPORT"].includes(activePortalTab) ? renderDataView() : (
          <div className="mt-6 space-y-6">
            <GuidedProcessDescription
              selectedProjectId={selectedProjectId}
              selectedCompanyId={selectedCompanyId}
              companies={companies}
              lockedCompanyName={lockedCompanyName}
              onSuccess={(msg) => setSuccessMsg(msg)}
              clientPortalRequests={dbRequests}
              setClientPortalRequests={setDbRequests}
              useGuidedScript={useGuidedScript}
              setUseGuidedScript={setUseGuidedScript}
              projects={projects}
              onProjectsUpdate={setProjects}
            />

            {false && (
              <div className="bg-white p-6 border-2 border-[#1A1A1A] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b pb-4 mb-6 gap-4">
              <div className="text-left">
                <h3 className="text-xl font-bold font-serif text-gray-900">Mapeador de Processos E3I</h3>
                <p className="text-xs text-gray-500 mt-1">Envie rascunhos de seus processos corporativos para refinamento por nossos engenheiros Lean Six Sigma.</p>
              </div>
              
              {/* Submission Mode Toggle */}
              <div className="flex bg-[#F5F2ED] p-1 border border-gray-300 rounded gap-1 self-start md:self-auto">
                <button
                  type="button"
                  onClick={() => { setUseGuidedScript(true); setSuccessMsg(""); }}
                  className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-all cursor-pointer ${useGuidedScript ? 'bg-indigo-950 text-white shadow' : 'bg-transparent text-gray-700 hover:bg-gray-200'}`}
                >
                  🍀 Roteiro Guiado (Recomendado)
                </button>
                <button
                  type="button"
                  onClick={() => { setUseGuidedScript(false); setSuccessMsg(""); }}
                  className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-all cursor-pointer ${!useGuidedScript ? 'bg-indigo-950 text-white shadow' : 'bg-transparent text-gray-700 hover:bg-gray-200'}`}
                >
                  📝 Texto Livre
                </button>
              </div>
            </div>

            {successMsg && <div className="p-4 bg-green-100 border border-green-300 text-green-900 font-bold mb-6 rounded text-left">{successMsg}</div>}

            {useGuidedScript ? (
              // --- RENDER FLOW OF GUIDED WIZARD ---
              <div className="space-y-6">
                
                {/* Stepper progress track */}
                <div className="flex items-center justify-between gap-2 max-w-xl mx-auto border-b pb-4 overflow-x-auto">
                  {[
                    "Contato", 
                    "1. Gatilho", 
                    "2. Fluxo", 
                    "3. Decisões", 
                    "4. Sistemas", 
                    "5. Entrega", 
                    "6. Gargalos", 
                    "Concluir"
                  ].map((stepLabel, idx) => {
                    const isActive = wizardStep === idx;
                    const isCompleted = wizardStep > idx;
                    return (
                      <div key={idx} className="flex items-center gap-1.5 shrink-0">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[10px] font-bold border transition-all ${
                          isActive ? 'bg-indigo-700 text-white border-indigo-700 font-black' :
                          isCompleted ? 'bg-emerald-600 text-white border-emerald-600' :
                          'bg-white text-gray-400 border-gray-300'
                        }`}>
                          {isCompleted ? "✓" : idx + 1}
                        </span>
                        <span className={`text-[10px] font-mono leading-none tracking-tight transition-all hidden sm:inline ${
                          isActive ? 'text-indigo-900 font-bold' :
                          isCompleted ? 'text-emerald-700' :
                          'text-gray-400'
                        }`}>
                          {stepLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {wizardStep === 0 && (
                  // --- STEP 0: SENDER INFO AND PROCESS NAME ---
                  <div className="space-y-4 max-w-xl mx-auto bg-gray-50 p-5 border rounded animate-fadeIn">
                    <div className="border-b pb-3 mb-2 text-left">
                      <span className="text-[10px] font-mono font-bold uppercase bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">Identificação Operacional</span>
                      <h4 className="text-sm font-bold text-gray-900 font-serif mt-1.5">Quem está liderando esta iniciativa de melhoria?</h4>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5 col-span-2 text-left">
                        <label className="text-[11px] font-bold text-gray-700 block text-left">Seu Nome de Contato:</label>
                        <input
                          type="text"
                          value={guidedContactName}
                          onChange={e => setGuidedContactName(e.target.value)}
                          placeholder="Ex: Carlos Alberto Miranda"
                          className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans"
                        />
                      </div>
                      <div className="space-y-1.5 text-left">
                        <label className="text-[11px] font-bold text-gray-700 block text-left">E-mail Corporativo:</label>
                        <input
                          type="email"
                          value={guidedContactEmail}
                          onChange={e => setGuidedContactEmail(e.target.value)}
                          placeholder="Ex: carlos@empresa.com"
                          className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans"
                        />
                      </div>
                      <div className="space-y-1.5 text-left">
                        <label className="text-[11px] font-bold text-gray-700 block text-left">WhatsApp / Telefone:</label>
                        <input
                          type="tel"
                          value={guidedContactPhone}
                          onChange={e => setGuidedContactPhone(e.target.value)}
                          placeholder="Ex: (11) 98888-7777"
                          className="w-full border p-2.5 text-xs rounded bg-white outline-indigo-500 font-sans"
                        />
                      </div>
                      <div className="space-y-1.5 col-span-2 text-left">
                        <label className="text-[11px] font-bold text-gray-700 block text-left">Nome do Processo a ser mapeado:</label>
                        <input
                          type="text"
                          value={guidedProcessName}
                          onChange={e => setGuidedProcessName(e.target.value)}
                          placeholder="Ex: Solicitação de Reembolso, Expedição de Produtos..."
                          className="w-full border-2 border-indigo-200 p-2.5 text-xs rounded bg-indigo-50/20 font-bold focus:border-indigo-600 outline-none"
                        />
                      </div>
                    </div>
                    
                    <div className="pt-4 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          if (!guidedContactName || !guidedProcessName) {
                            alert("Por favor, preencha seu nome e o nome do processo para iniciar!");
                            return;
                          }
                          setWizardStep(1);
                        }}
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2.5 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Começar Roteiro <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 1 && (
                  // --- STEP 1: GATILHO ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <span className="text-[10px] font-mono text-gray-400 tracking-widest font-black uppercase">Olá! Para criarmos um padrão perfeito do processo "{guidedProcessName || '[NOME DO PROCESSO]'}":</span>
                      <h4 className="text-base font-serif font-bold text-gray-950">1. O Ponto de Partida (Gatilho)</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Como esse processo começa? (Ex: Você recebe um e-mail? O cliente liga? Um sistema emite um alerta?)</p>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">Exatamente qual informação ou documento chega até você para o trabalho começar?</strong>
                    </div>
                    
                    <textarea
                      value={guidedGatilho}
                      onChange={e => setGuidedGatilho(e.target.value)}
                      placeholder="Ex: Recebemos um arquivo em anexo no e-mail 'atendimento@...' com as notas anexas, ou o alerta automatizado de novo chamado no CRM Zendesk."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-2">
                      <button type="button" onClick={() => setWizardStep(0)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(2)} 
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Próximo <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 2 && (
                  // --- STEP 2: FLUXO ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <h4 className="text-base font-serif font-bold text-gray-950">2. O Passo a Passo Detalhado (O Fluxo)</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Descreva a sequência de ações. Use o modelo: <strong>Quem (Cargo)</strong> faz <strong>O que</strong> e <strong>Onde (Sistema/Papel)</strong>.</p>
                      <div className="bg-amber-500/5 border-l-2 border-[#C49746] p-2.5 text-[11px] text-amber-900 font-sans space-y-0.5 leading-relaxed rounded-xs">
                        <strong>Exemplo Prático:</strong><br/>
                        "Eu (Analista) abro o sistema X, clico em 'Novo Pedido' e digito o CPF do cliente."
                      </div>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">Escreva todas as etapas, desde a primeira ação até a conclusão do trabalho.</strong>
                    </div>
                    
                    <textarea
                      value={guidedFluxo}
                      onChange={e => setGuidedFluxo(e.target.value)}
                      placeholder="Ex: 1. Eu (Analista de Faturamento) abro o ERP Totvs, clico na tela de Notas Fiscais, importo os pedidos recebidos..."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-2">
                      <button type="button" onClick={() => setWizardStep(1)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(3)} 
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Próximo <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 3 && (
                  // --- STEP 3: DECISÕES ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <h4 className="text-base font-serif font-bold text-gray-950">3. Os Desvios e Tomadas de Decisão (E se der errado?)</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Quais decisões você precisa tomar no meio do caminho? (Ex: "Eu preciso checar se o valor é maior que R$ 5.000").</p>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">O que acontece se a resposta for SIM? Para onde o processo vai? O que acontece se for NÃO, ou se houver um erro grave? Quem você aciona?</strong>
                    </div>
                    
                    <textarea
                      value={guidedDesvios}
                      onChange={e => setGuidedDesvios(e.target.value)}
                      placeholder="Ex: Se o valor exceder R$ 5.000, eu preciso encaminhar o boleto por e-mail para aprovação do Diretor Comercial. Se for menor, eu mesmo aprovo e liquido. Se houver divergência no imposto de renda retido, devolvo para o fornecedor refazer."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-2">
                      <button type="button" onClick={() => setWizardStep(2)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(4)} 
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Próximo <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 4 && (
                  // --- STEP 4: FERRAMENTAS ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <h4 className="text-base font-serif font-bold text-gray-950">4. Ferramentas e Sistemas</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Quais sistemas, planilhas, sites ou blocos de papel você usa durante esse processo?</p>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">Por favor, cite nominalmente as ferramentas (Ex: CRM Salesforce, Planilha Excel de Clientes, Telegram, Bloco de rascunhos físico).</strong>
                    </div>
                    
                    <textarea
                      value={guidedFerramentas}
                      onChange={e => setGuidedFerramentas(e.target.value)}
                      placeholder="Ex: ERP SAP Business One, Outlook da Microsoft, Planilha de Consolidação Faturamento no Google Drive e um bloco de notas físico na minha mesa de trabalho."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-2">
                      <button type="button" onClick={() => setWizardStep(3)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(5)} 
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Próximo <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 5 && (
                  // --- STEP 5: ENTREGA ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <h4 className="text-base font-serif font-bold text-gray-950">5. O Ponto Final (A Entrega)</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Como você sabe que a sua parte terminou de fato?</p>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">O que você gera no final desse fluxo de trabalho e para quem você envia esse produto/informação? (Ex: Um relatório PDF consolidado enviado por e-mail para o gerente; Um produto físico de fato embalado na esteira da empacotadora).</strong>
                    </div>
                    
                    <textarea
                      value={guidedEntrega}
                      onChange={e => setGuidedEntrega(e.target.value)}
                      placeholder="Ex: O faturamento termina quando o ERP emite a Nota Fiscal autorizada e o link é disparado automaticamente para o cliente e o PDF é anexado na pasta compartilhada da expedição."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-2">
                      <button type="button" onClick={() => setWizardStep(4)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(6)} 
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-mono font-bold uppercase py-2 px-5 cursor-pointer rounded flex items-center gap-1"
                      >
                        Próximo <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 6 && (
                  // --- STEP 6: REGRAS E GARGALOS ---
                  <div className="space-y-4 max-w-xl mx-auto bg-white border p-5 rounded animate-fadeIn shadow-xs">
                    <div className="border-l-4 border-[#C49746] pl-3.5 space-y-1 text-left">
                      <h4 className="text-base font-serif font-bold text-gray-950">6. Regras, Prazos e Gargalos</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">Existe algum prazo obrigatório (SLA) a ser cumprido por contrato ou acordo comercial? (Ex: Deve ser faturado em até 2 horas do recebimento).</p>
                      <strong className="text-[11px] text-indigo-900 font-sans block mt-1">Qual é o erro, problema sistêmico ou gargalo de atraso mais comum que costuma travar esse processo no cotidiano?</strong>
                    </div>
                    
                    <textarea
                      value={guidedRegras}
                      onChange={e => setGuidedRegras(e.target.value)}
                      placeholder="Ex: Temos um prazo de 4 horas após a chegada do pedido para emitir a NF. O problema mais comum é do SEFAZ demorar para retornar a homologação ou os dados cadastrais do cliente virem incorretos da equipe de vendas."
                      className="w-full border p-3 text-xs h-36 rounded focus:ring-1 focus:ring-indigo-600 bg-white"
                    />

                    <div className="flex justify-between items-center pt-4 border-t">
                      <button type="button" onClick={() => setWizardStep(5)} className="text-xs font-mono font-bold text-gray-500 hover:text-gray-800 uppercase px-4 py-2 cursor-pointer">Voltar</button>
                      <button 
                        type="button" 
                        onClick={handleGenerateGuidedPreview}
                        disabled={isGeneratingPreview}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-mono font-bold uppercase py-2.5 px-6 cursor-pointer rounded flex items-center gap-1.5 shadow"
                      >
                        {isGeneratingPreview ? (
                          <>
                            <RefreshCw size={14} className="animate-spin" /> Estruturando com IA...
                          </>
                        ) : (
                          <>
                            <Sparkles size={14} /> Gerar Prévia do Processo
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {wizardStep === 7 && (
                  // --- STEP 7: PREVIEW AND VALIDATE ---
                  <div className="space-y-6 animate-fadeIn">
                    <div className="bg-emerald-50 border border-emerald-300 p-4 font-sans text-xs text-emerald-950 rounded flex items-center gap-3 text-left">
                      <CheckCircle2 size={24} className="text-emerald-700 shrink-0" />
                      <div>
                        <strong>Prévia do seu Processo Estruturada com Sucesso!</strong><br />
                        Nossa IA analisou suas respostas integrando conceitos Lean Six Sigma e decodificou um rascunho de modelagem. Avalie abaixo antes de encaminhar aos nossos analistas seniores.
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                      {/* Left Side: Raw compiled text of answers */}
                      <div className="lg:col-span-6 bg-gray-50 border border-gray-300 rounded p-4 space-y-3 shadow-inner">
                        <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase tracking-wider pb-1.5 border-b">Relato do Processo Compilado</span>
                        <div className="bg-white border rounded p-3 font-mono text-[11px] text-gray-700 whitespace-pre-line max-h-[380px] overflow-y-auto leading-relaxed select-all" title="Clique para selecionar e copiar">
                          {previewCompiledText}
                        </div>
                      </div>

                      {/* Right Side: AI Structure preview */}
                      <div className="lg:col-span-6 bg-white border border-gray-300 rounded p-4 space-y-4">
                        <span className="text-[10.5px] font-mono font-extrabold text-indigo-800 block uppercase tracking-wider pb-1.5 border-b flex items-center gap-1.5">
                          <Cpu size={14} /> Rascunho do Fluxo Operacional Decodificado via IA (E3i)
                        </span>

                        {parsedAnalysisResult ? (
                          <div className="space-y-4 font-sans text-xs">
                            {/* SIPOC Decoded preview */}
                            <div className="space-y-1 bg-slate-50 border p-2.5 rounded text-left">
                              <span className="text-[9px] font-mono font-bold uppercase text-gray-400 block pb-1">Matriz SIPOC Preliminar Deduzida:</span>
                              <div className="grid grid-cols-5 gap-1 text-[8.5px] text-center font-bold">
                                <div className="bg-white border p-1 rounded-xs" title={parsedAnalysisResult.sipoc.Suppliers.join(', ')}>
                                  <span className="text-indigo-600 block">S (Forn)</span>
                                  <span className="text-gray-500 truncate block">{parsedAnalysisResult.sipoc.Suppliers[0] || "Insumo"}</span>
                                </div>
                                <div className="bg-white border p-1 rounded-xs" title={parsedAnalysisResult.sipoc.Inputs.join(', ')}>
                                  <span className="text-sky-600 block">I (Entr)</span>
                                  <span className="text-gray-500 truncate block">{parsedAnalysisResult.sipoc.Inputs[0] || "Dados"}</span>
                                </div>
                                <div className="bg-indigo-50 border border-indigo-200 p-1 rounded-xs" title={parsedAnalysisResult.sipoc.Process}>
                                  <span className="text-indigo-800 block font-black">P (Proc)</span>
                                  <span className="text-indigo-850 truncate block">{parsedAnalysisResult.sipoc.Process}</span>
                                </div>
                                <div className="bg-white border p-1 rounded-xs" title={parsedAnalysisResult.sipoc.Outputs.join(', ')}>
                                  <span className="text-amber-600 block">O (Said)</span>
                                  <span className="text-gray-500 truncate block">{parsedAnalysisResult.sipoc.Outputs[0] || "Valores"}</span>
                                </div>
                                <div className="bg-white border p-1 rounded-xs" title={parsedAnalysisResult.sipoc.Customers.join(', ')}>
                                  <span className="text-emerald-600 block">C (Clie)</span>
                                  <span className="text-gray-500 truncate block">{parsedAnalysisResult.sipoc.Customers[0] || "Gerente"}</span>
                                </div>
                              </div>
                            </div>

                            {/* Estimated parameters */}
                            <div className="grid grid-cols-3 gap-2 text-center text-xs">
                              <div className="bg-indigo-50/50 p-2 border border-indigo-100 rounded">
                                <span className="text-[9px] text-indigo-800 font-mono block">Rendimento Estimado</span>
                                <strong className="text-sm font-mono text-indigo-900">{100 - (parsedAnalysisResult.metrics.reworkEst || 15)}%</strong>
                              </div>
                              <div className="bg-[#FAF9F6] p-2 border border-gray-100 rounded">
                                <span className="text-[9px] text-[#C49746] font-mono block">Tempo Estimado Atividade</span>
                                <strong className="text-sm font-mono text-[#C49746]">{parsedAnalysisResult.metrics.tempoMedioCiclo}</strong>
                              </div>
                              <div className="bg-emerald-50/50 p-2 border border-emerald-100 rounded">
                                <span className="text-[9px] text-emerald-800 font-mono block">Confiança Operacional</span>
                                <strong className="text-sm font-mono text-emerald-950">{parsedAnalysisResult.metrics.confidenceScore}%</strong>
                              </div>
                            </div>

                            {/* Sequential Steps badging */}
                            <div className="space-y-1.5 bg-[#FAF9F6] p-3 rounded border text-left">
                              <span className="text-[10px] font-bold text-gray-700 block">Mapeamento de Etapas Sequenciais Identificadas (Simulação DMAIC):</span>
                              <div className="flex flex-wrap gap-1.5 pt-1">
                                {parsedAnalysisResult.steps.map((st: string, sIdx: number) => (
                                  <span key={sIdx} className="text-[9.5px] font-mono bg-white border border-gray-300 rounded px-2 py-0.5 text-gray-800 shadow-2xs flex items-center gap-1">
                                    <span className="text-[8.5px] text-indigo-700 font-black">{sIdx + 1}.</span> {st}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="p-12 text-center text-gray-400 italic">Preenchendo estimativas...</div>
                        )}
                      </div>
                    </div>

                    {/* Nav Actions */}
                    <div className="flex flex-wrap justify-between items-center gap-4 border-t pt-4">
                      <button 
                        type="button" 
                        onClick={() => setWizardStep(6)} 
                        className="bg-white border-2 border-slate-900 text-[#1A1A1A] text-xs font-mono font-bold uppercase px-6 py-2.5 hover:bg-slate-50 cursor-pointer"
                      >
                        ✏️ Ajustar / Editar Respostas
                      </button>

                      <button 
                        type="button" 
                        onClick={handleSubmitGuidedRequest}
                        disabled={isSubmittingGuided}
                        className="bg-indigo-700 text-white text-xs font-mono font-bold uppercase px-8 py-3 hover:bg-indigo-800 cursor-pointer flex items-center gap-2 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]"
                      >
                        {isSubmittingGuided ? (
                          <>
                            <RefreshCw size={14} className="animate-spin" /> Enviando Solicitação...
                          </>
                        ) : (
                          <>
                            <Send size={14} /> Validar e Enviar para Análise do Especialista na Ferramenta
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              // --- REGULAR FREE TEXT BOX ---
              <div className="space-y-4 text-left">
                <div className="space-y-4">
                  <input type="text" placeholder="Nome do Solicitante" value={clientName} onChange={e => setClientName(e.target.value)} className="w-full border p-2 text-sm" />
                  <textarea placeholder="Descreva o processo para estruturá-lo usando a IA..." value={interviewText} onChange={e => setInterviewText(e.target.value)} className="w-full border p-2 text-sm h-32" />
                  <button 
                    onClick={async () => {
                      if(!clientName || !interviewText) return;
                      
                      const newReq = {
                        id: "req_" + Date.now().toString(),
                        clientName: clientName.trim(),
                        text: interviewText.trim(),
                        status: "Em Análise",
                        timestamp: new Date().toISOString()
                      };
                      
                      const params = new URLSearchParams(window.location.search);
                      const urlToken = params.get("token");
                      if (urlToken) {
                        try {
                          const docId = urlToken.replace(/[^a-zA-Z0-9_\-]/g, "_");
                          if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
                            console.log("[Portal] [Modo de Treinamento] Firestore write bypassed inside Shared Portal. Simulating in state.");
                            setDbRequests((prev) => [...prev, newReq]);
                          } else {
                            await updateDoc(doc(db, "shared_portals", docId), {
                              requests: arrayUnion(newReq)
                            });
                          }
                          console.log("[Portal] Persistent request submitted to Firestore!");
                        } catch (e) {
                          console.error("[Portal] Error saving request to Firestore:", e);
                        }
                      } else {
                        const localReqs = JSON.parse(localStorage.getItem("lss_local_portal_requests") || "[]");
                        const updated = [...localReqs, newReq];
                        localStorage.setItem("lss_local_portal_requests", JSON.stringify(updated));
                        setDbRequests(updated);
                      }

                      // Let's also register a basic solicitation structured representation so it syncs to Admin Panel tab!
                      try {
                        const solId = "sol_" + Date.now().toString();
                        const clientCompany = companies.find(c => c.id === selectedCompanyId)?.name || lockedCompanyName || "Empresa Cliente";
                        const newSolicitation = {
                          id: solId,
                          clientCompany,
                          clientName: clientName.trim(),
                          clientEmail: "cliente@manual.com",
                          contactPhone: "",
                          processName: "Mapeamento Manual Recibido",
                          projectGoal: "Fluxo sob demanda",
                          urgency: "Média",
                          rawText: interviewText.trim(),
                          status: "Pendente",
                          createdAt: new Date().toISOString(),
                          analysisResult: {
                            sipoc: {
                              Suppliers: ["Fornecedores"],
                              Inputs: ["Insumos"],
                              Process: "Mapeamento Manual",
                              Outputs: ["Resultados"],
                              Customers: ["Clientes"]
                            },
                            metrics: {
                              confidenceScore: 78,
                              reworkEst: 15,
                              tempoMedioCiclo: "A calcular"
                            },
                            steps: ["Receber Solicitação Manual", "Triagem", "Mapeamento", "Aprovação"]
                          }
                        };
                        const existingSols = JSON.parse(localStorage.getItem("lss_project_solicitations") || "[]");
                        localStorage.setItem("lss_project_solicitations", JSON.stringify([...existingSols, newSolicitation]));
                      } catch (e) {
                        console.error("[Portal Error] Sync manual solicitation:", e);
                      }
                      
                      setSuccessMsg("Sua demanda foi enviada com sucesso para nossos Especialistas em Processos!");
                      setInterviewText("");
                    }} 
                    className="bg-[#1A1A1A] text-white font-mono font-bold px-6 py-2 uppercase cursor-pointer hover:bg-slate-800"
                  >
                    Enviar Demanda
                  </button>
                </div>
              </div>
            )}
            </div>
            )}

            {/* List of current active requests */}
            <div className="mt-8 pt-8 border-t border-gray-200 text-left">
              <h4 className="text-sm font-bold uppercase tracking-wider text-gray-800 mb-4 flex items-center gap-2">📂 Solicitações Registradas</h4>
              {dbRequests.length === 0 ? (
                <p className="text-xs text-gray-500 italic">Nenhuma solicitação em andamento para este projeto mapeado.</p>
              ) : (
                <div className="space-y-3.5">
                  {[...dbRequests].reverse().map((req: any) => (
                    <div key={req.id} className="p-4 bg-gray-50 border border-gray-300 rounded-sm shadow-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-bold text-gray-900">👤 {req.clientName}</span>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 uppercase ${
                          req.status === "Aprovada" ? "bg-emerald-100 text-emerald-800 border border-emerald-300" :
                          req.status === "Recusada" ? "bg-red-100 text-red-800 border border-[#f3a0a0] text-red-900" :
                          "bg-amber-100 text-amber-850 border border-[#fbd3a5]"
                        }`}>
                          {req.status}
                        </span>
                      </div>
                      <p className="text-xs text-gray-700 leading-relaxed font-sans whitespace-pre-wrap">{req.text}</p>
                      {req.answer && (
                        <div className="p-2.5 bg-amber-500/5 border-l-2 border-amber-500 space-y-1">
                          <span className="text-[10px] font-bold text-amber-900 block font-mono">💬 Resposta do Consultor:</span>
                          <p className="text-xs text-gray-700 italic">{req.answer}</p>
                        </div>
                      )}
                      <div className="text-[9px] text-gray-400 font-mono flex items-center justify-between">
                        <span>🕒 Enviado às: {new Date(req.timestamp).toLocaleString("pt-BR")}</span>
                        <span>Ref: {req.id}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
