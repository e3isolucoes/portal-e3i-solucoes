import React, { useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { 
  Presentation, 
  FileText, 
  Award, 
  ArrowLeft, 
  ArrowRight, 
  Clipboard, 
  Printer, 
  Download, 
  Check, 
  TrendingUp, 
  Layers, 
  Activity, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle 
} from "lucide-react";
import { 
  ComposedChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceLine,
  LineChart
} from "recharts";
import { ProcessStep, ProcessMetrics, ProjectCharter, Sipoc, ControlPlan } from "../types";
import PredictiveSigmaReport from "./PredictiveSigmaReport";

interface ReportPresentationGeneratorProps {
  steps: ProcessStep[];
  stats: ProcessMetrics;
  charter: ProjectCharter;
  sipoc: Sipoc;
  controlPlans: ControlPlan[];
  arrivalRate: number;
}

export default function ReportPresentationGenerator({
  steps,
  stats,
  charter,
  sipoc,
  controlPlans,
  arrivalRate
}: ReportPresentationGeneratorProps) {
  const [activeTab, setActiveTab] = useState<"SLIDES" | "DOSSIER" | "PREDICTIVE" | "PITCH" | "MINUTES">("SLIDES");
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [activeSlide, setActiveSlide] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  
  // Pitch Deck & Funding specific states
  const [fundingTier, setFundingTier] = useState<"SILVER" | "GOLD" | "PLATINUM">("GOLD");
  const [activePitchSlide, setActivePitchSlide] = useState<number>(0);
  const [pitchAdvisorOpen, setPitchAdvisorOpen] = useState<boolean>(true);
  const [copiedPitch, setCopiedPitch] = useState<boolean>(false);

  // Meeting Minutes (Ata de Reunião LSS) editable states
  const [meetingTitle, setMeetingTitle] = useState("Ata de Reunião Extraordinária - Comitê de Liderança LSS");
  const [meetingDate, setMeetingDate] = useState(() => new Date().toLocaleDateString("pt-BR") + " - 14:00h");
  const [meetingLeader, setMeetingLeader] = useState("Marco Antônio Miranda (Master Black Belt)");
  const [meetingParticipants, setMeetingParticipants] = useState("Marco Antônio Miranda (LSS MBB), Regina S. Albuquerque (Diretora Operacional), Carlos Alberto Vasconcelos (Supervisor SMT), Eng. Ana Clara Peixoto (Garantia de Qualidade)");
  const [meetingLocation, setMeetingLocation] = useState("Sala de Decisões Estratégicas - Planta E3I");
  const [meetingDeliberations, setMeetingDeliberations] = useState(
    "1. Homologação das melhorias e novos tempos de ciclo implementados nas células de SMT para elevar o PCE global.\n" +
    "2. Aprovação de verba de fomento tecnológico para sensoriamento IoT de controle da temperatura do forno de refluxo.\n" +
    "3. Alinhamento de tolerâncias de Cartas de Controle CEP Shewhart para mitigação proativa de desvios UCL/LCL de variabilidade.\n" +
    "4. Fixação de rotina automatizada de Poka-Yoke e auditoria de conformidade física 5S junto às equipes de montagem básica."
  );

  // Recharts Data Helpers
  const getDossierTrendData = () => {
    const history = [];
    const currentSigma = stats.sigmaLevel || 3.0;
    const baseSigma = Math.max(1.5, currentSigma - 1.2);
    const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"];
    for (let i = 0; i < 6; i++) {
      let val = currentSigma;
      if (i < 5) {
        val = baseSigma + ((currentSigma - baseSigma) * (i / 5));
      }
      history.push({
        name: months[i],
        "Nível Sigma": parseFloat(val.toFixed(2))
      });
    }
    return history;
  };

  const getDossierParetoData = () => {
    const defaultCauses = [
      { cause: "Descalibração Sensores", count: 8, explanation: "Sensores térmicos/ópticos desalinhados" },
      { cause: "Massa Fria de Solda", count: 5, explanation: "Pasta vencida ou estêncil com entupimento parcial" },
      { cause: "Erro Setup Operacional", count: 3, explanation: "Parâmetros incorretos no painel da pick-and-place" },
      { cause: "Desgaste de Ferramental", count: 2, explanation: "Fresa de separação mecânica operando acima de 500 ciclos" },
      { cause: "Flutuação vácuo ar", count: 1, explanation: "Perda transitória de sucção pneumática de alimentação" }
    ];
    const total = defaultCauses.reduce((sum, item) => sum + item.count, 0);
    let cum = 0;
    const chartData = defaultCauses.map(item => {
      cum += item.count;
      const percentage = total > 0 ? (cum / total) * 100 : 0;
      return {
        cause: item.cause,
        count: item.count,
        percentage: parseFloat(percentage.toFixed(1))
      };
    });
    return { chartData, total };
  };

  // Grab active logged in user if any, otherwise standard default LSS Master
  const getCorporateUser = () => {
    try {
      const stored = localStorage.getItem("six_sigma_active_user");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {}
    return { fullName: "Marco Antônio Miranda", belt: "Master Black Belt" };
  };
  const activeUser = getCorporateUser();

  // VSM Calculations
  const totalVA_Time = stats.processingTimeSum;
  const totalSetupTime = steps.reduce((sum, s) => sum + s.setupTime, 0);
  const totalLeadTime = stats.leadTime + totalSetupTime;
  const pce_ratio = totalLeadTime > 0 ? (totalVA_Time / totalLeadTime) * 100 : 0;

  // Let's model 6 beautiful Slides
  const slides = [
    {
      title: "Slide 1: Sumário Executivo & Alinhamento Estratégico",
      header: "TERMO DE ABERTURA - LSS PROJECT CHARTER",
      subtitle: charter.title || "ESTUDO DE FLUXO ESTOCÁSTICO INDUSTRIAL",
      content: [
        `• Patrocinador do Projeto: ${activeUser.fullName} (${activeUser.belt})`,
        `• Problema Focal: Gargalos industriais que aumentam a fila estocástica e reduzem o rendimento de montagem de placas SMT.`,
        `• Objetivo Principal: Alcançar uma meta estável de ${charter.targetValue || "80%"} na métrica de ${charter.metric === "cycle_time" ? "TEMPO DE CICLO" : charter.metric === "throughput" ? "VAZÃO MÁXIMA" : "QUALIDADE DE RENDIMENTO (YIELD)"}.`,
        `• Escopo de Estudo: Rede contendo ${steps.length} postos produtivos, do abastecimento na impressora de pasta de solda ao teste funcional eletrônico.`,
        `• Taxa de Entrada Global de Lotes: ${arrivalRate} unidades por hora com arranjo estocástico exponencial de Poisson.`
      ],
      keyStats: [
        { label: "Postos", val: steps.length },
        { label: "Taxa Demanda", val: `${arrivalRate}/h` },
        { label: "Target Projeto", val: charter.targetValue }
      ],
      bg: "bg-radial from-[#1A1A1A] to-stone-900 text-white"
    },
    {
      title: "Slide 2: Mapeamento de Valor & Governança BPM",
      header: "MAPA DO FLUXO KAIZEN & EFICIÊNCIA DO DESIGN",
      subtitle: "VALUE STREAM MAPPING (VSM) & PERDAS DE VALOR",
      content: [
        `• Tempo de Retenção Ativa total (VA Touch Time): Esse sistema opera em ${totalVA_Time.toFixed(1)} segundos de agregação direta física por unidade.`,
        `• Tempo Ocioso Invisível total (NVA Esperas/Setup): Perda de ${ (totalLeadTime - totalVA_Time).toFixed(1) } minutos gerados por filas estocásticas e trocas de ferramenta de setup.`,
        `• Eficiência do Ciclo de Processo (PCE): Calculado em ${pce_ratio.toFixed(1)}% (padrão mundial World Class é acima de 25%).`,
        `• Gargalo Produtivo do Sistema: Identificado na etapa de [${stats.bottleneckStepName}] operando com taxa de ocupação máxima de ${stats.systemUtilization.toFixed(0)}%.`,
        `• Atraso em Regime G/G/c: Gargalo gera um tempo médio de espera individual teórico de até ${(stats.leadTime - stats.processingTimeSum).toFixed(1)} minutos por lote.`
      ],
      keyStats: [
        { label: "PCE Ciclo", val: `${pce_ratio.toFixed(1)}%` },
        { label: "Touch Time", val: `${totalVA_Time.toFixed(1)} min` },
        { label: "Gargalo Crítico", val: stats.bottleneckStepName.split(" ")[0] }
      ],
      bg: "bg-radial from-violet-950 to-stone-950 text-white"
    },
    {
      title: "Slide 3: Desempenho Estatístico & Shewhart CEP",
      header: "KIPs DE RENDIMENTO & CONTROLE ESTATÍSTICO",
      subtitle: "SIGMA LEVEL, DPMO E GRÁFICOS DE CONTROLE",
      content: [
        `• Fator de Rendimento rolled (FPP Final): O processo gera um rendimento primário acumulado de ${(stats.rolledFirstPassYield * 100).toFixed(1)}% de aproveitamento sem defeitos.`,
        `• Nível Sigma Calculado do Sistema: ${stats.sigmaLevel.toFixed(2)} σ (DPMO estimado em ${Math.round(stats.dpmo).toLocaleString("pt-BR")} oportunidades com falha por milhão).`,
        `• Parâmetro de Monitoramento CEP: Limite Superior de Controle (UCL) estimado em 3 desvios-padrão superiores. Medição monitorada online em tempo real.`,
        `• Desvio Aditivo Acumulado do Fluxo: σ total de ±${stats.stdevProcess.toFixed(2)} minutos.`,
        `• Níveis de Reforço SPC: Definição estruturada de alarmes de sensibilidade com barreira de alarmes ajustada semanalmente.`
      ],
      keyStats: [
        { label: "Fator Sigma", val: `${stats.sigmaLevel.toFixed(2)}σ` },
        { label: "DPMO Estimado", val: Math.round(stats.dpmo) },
        { label: "Rendimento", val: `${(stats.rolledFirstPassYield * 100).toFixed(0)}%` }
      ],
      bg: "bg-radial from-slate-900 to-black text-white"
    },
    {
      title: "Slide 4: Otimização Operacional Matemática (P.O.)",
      header: "DECISÕES EXOTÉRICAS POR PESQUISA OPERACIONAL",
      subtitle: "PROGRAMAÇÃO LINEAR E TEORIA DAS FILAS G/G/c",
      content: [
        `• Problema 1 - Mix Ótimo de Receitas: O modelo maximiza a margem de faturamento total ao encontrar a proporção ótima de montagem diária de Notebooks Standard vs Pro.`,
        `• Solução Resolvida P.L.: Mix ótimo aproveita ao limite os gargalos produtivos para obter o máximo rendimento financeiro geral.`,
        `• Problema 2 - Redimensionamento de Equipe: Redirecionamento da equipe contratada para mitigar o colapso estocástico exponencial ( किंगमैन de Kingman).`,
        `• Ponto de Mínimo Custo Econômico: Equilíbrio obtido combinando custos de remuneração direta horária com perdas financeiras de congestionamento de estoques (WIP).`,
        `• Investimento em Restrições (TOC): Alocação de 100% de capital de engenharia de forma pragmática apenas no posto gargalo.`
      ],
      keyStats: [
        { label: "Abordagem P.O.", labelShort: "Conceito", val: "Simplex" },
        { label: "Fila Teórica", val: "G/G/c" },
        { label: "Gargalo Alvo", val: "TOC" }
      ],
      bg: "bg-radial from-[#1e1b4b] to-black text-white"
    },
    {
      title: "Slide 5: Mitigação de Falhas & Padrões Lean 5S",
      header: "KAIZEN INDUSTRIAL & GERENCIAMENTO DE RISCO FMEA",
      subtitle: "CONFORMIDADE CONTRA INCIDENTES E VARIAÇÃO",
      content: [
        `• Matriz FMEA de Prioridade Crítica: Riscos mapeados dão pontuações de RPN acima do limite de tolerância nas atividades do Forno de Refluxo e Inspeção Óptica.`,
        `• Pulmão Preventivo Adotado: Uso de transdutores pneumáticos de torqueamento automático para neutralizar incidentes por aperto humano.`,
        `• Auditoria de Cultura Lean 5S: Avaliação média de maturidade das equipes operativas em conformidade na limpeza e autodisciplina diária.`,
        `• Padronização Visual (Seiketsu): Fixação de cartazes com procedimentos operacionais normativos (POPs/SOPs) ilustrados nos postos produtivos.`,
        `• Automatizações Sugeridas: Propostas de loops ativos e redundantes de intertravamento térmico em tempo real.`
      ],
      keyStats: [
        { label: "Risco RPN Max", val: "180" },
        { label: "Audit 5S", val: "85%" },
        { label: "Ações Ativas", val: "05" }
      ],
      bg: "bg-radial from-[#022c22] to-black text-white"
    },
    {
      title: "Slide 6: Plano de Ação & Roteiro de Implantação",
      header: "PLANEJAMENTO ANUAL DE COMPROMISSOS (ROADMAP)",
      subtitle: "ESTUDO ESTOCÁSTICO PARA IMPLANTANÇÃO COMERCIAL",
      content: [
        `• Fase 1 - Rebalanceamento de Linha: Alteração operacional imediata do tempo de ciclo usando o amortecedor de balanceamento de tempos.`,
        `• Fase 2 - Aquisição IoT de Calibração: Instalação de termopares e transmissores sem fio para o controle contínuo Shewhart CEP online.`,
        `• Fase 3 - Engenharia Industrial Avançada: Parametrizar o modelo de Programação Linear no ERP do chão de fábrica para alocação automática de ordens de serviço.`,
        `• Fase 4 - Reuniões diárias de 5 Minutos (Gemba Daily): Checklist de verificação de ESD nas bancadas antes do início operacional dos turnos de fabricação.`,
        `• Retorno Financeiro Estimado: Redução teórica de até 42% nas perdas de tempo por filas e estancagem de WIP!`
      ],
      keyStats: [
        { label: "Prazo Implanta", val: "90 dias" },
        { label: "Queda Filas", val: "42%" },
        { label: "ROI Estimado", val: "3.5x" }
      ],
      bg: "bg-radial from-[#450a0a] to-black text-white"
    }
  ];

  // Markdown Dossier report contents
  const makeFullDossierReport = () => {
    return `================================================================================
MINISTÉRIO CORPORATIVO DA INDÚSTRIA - RELATÓRIO DO PROJETO LEAN SIX SIGMA
================================================================================
PATROCINADOR GERAL DO ESTUDO: ${activeUser.fullName}
GRADUAÇÃO ANALÍTICA: ${activeUser.belt}
DATA DE EMISSÃO DO DOSSIÊ: ${new Date().toLocaleDateString("pt-BR")}
MODELAGEM MATEMÁTICA: Pesquisa Operacional Estocástica (Filas, P.L., Markov)

1. TERMO DE ABERTURA EXECUTIVE (PROJECT CHARTER)
--------------------------------------------------------------------------------
Título do Estudo: ${charter.title || "ESTUDO DE FLUXO ESTOCÁSTICO SMT"}
Métrica de Sucesso de Controle: ${charter.metric === "cycle_time" ? "Tempo de Ciclo (min)" : charter.metric === "throughput" ? "Vazão Total" : "Defeito de Rolagem"}
Valor Alvo Estabelecido (Target): ${charter.targetValue || "80%"}
Problema Declarado: Variabilidade acentuada nos postos físicos de estocagem causam 
longos períodos improdutivos de fila, atrasos no lead time final e perda de faturamento.

2. MAPEAMENTO DE SUPPLY CHAIN E DADOS DO PROCESSO (SIPOC)
--------------------------------------------------------------------------------
Ficha Sipoc Consolidada de Suprimentos:
• Fornecedores Principais (Suppliers): ${sipoc.suppliers || "Fornecedores de Bobinas PTH/SMD e PCBs"}
• Insumos Operacionais (Inputs): ${sipoc.inputs || "Gabarito de Solda, Pasta Estencil, Gabinetes plásticos e Fios de Cobre"}
• Macro-Processo de Fábrica (Process): ${sipoc.processDescription || "Carregamento SMT -> Soldagem Refluxo -> AOI -> Montagem -> Teste"}
• Saídas de Validação (Outputs): ${sipoc.outputs || "Notebooks Finalizados com Certificado Embalado de Teste"}
• Clientes do Sistema (Customers): ${sipoc.customers || "Empresas Corporativas, Distribuidores Globais e Varejo Direto"}

3. INVENTÁRIO PRODUTIVO E DESEMPENHO ATUAL DE POSTOS
--------------------------------------------------------------------------------
Total de etapas físicas de transformação inventariadas: ${steps.length}
Postos em Operação Estocástica:
${steps.map((st, i) => `
👉 Etapa ${i + 1}: [${st.name}]
   - Força de Trabalho Ativa: ${st.resourceCount} operadores paralelos
   - Tempo touch normal médio (VA Time): ${st.processingTime} minutos por lote
   - Desvio padrão estocástico (Variabilidade): ±${st.standardDeviation} minutos
   - Rendimento primário de qualidade (Yield): ${(st.yieldRate * 100).toFixed(1)}% aprovados de primeira
   - Tempo regulamentar gasto com Setup (SMED): ${st.setupTime} minutos por turno
   - Função de Atribuição de Atividades: Responsável/Recurso de encargo: ${st.resource}
`).join("")}

4. MÉTRICAS ANALÍTICAS SIX SIGMA E TEORIA DAS FILAS (ESTATÍSTICAS)
--------------------------------------------------------------------------------
• Capacidade Limite da Fábrica determinada pelo Gargalo: ${stats.systemCapacity.toFixed(1)} unidades/hora
• Posto Restritor Principal (Gargalo de Hardware): [${stats.bottleneckStepName}]
• Taxa de Utilização Máxima no Gargalo: ${stats.systemUtilization.toFixed(1)}% de carregamento útil
• Tempo total agregado agregando valor (Touch Time): ${totalVA_Time.toFixed(1)} minutos
• Tempo médio total de permanência na fábrica (Lead Time estocástico): ${stats.leadTime.toFixed(1)} minutos
• Eficiência de Ciclo do Processo Geral (PCE): ${pce_ratio.toFixed(1)}%
• Margem de Rendimento Acumulado de Qualidade (Rolled First Pass Yield): ${(stats.rolledFirstPassYield * 100).toFixed(1)}%
• Grau de Estabilidade Industrial (Nível Sigma): ${stats.sigmaLevel.toFixed(2)} Sigma (σ)
• Defeitos Esperados por Milhão de Unidades (DPMO): ${Math.round(stats.dpmo).toLocaleString("pt-BR")} desvios
• Carga de Estoque Médio Intermediário em Processo (Little's Law WIP): ${stats.systemWip.toFixed(2)} lotes pendentes

5. ANÁLISE DE KAIZEN PREVENTIVO E SEGURANÇA (FMEA)
--------------------------------------------------------------------------------
Modos de falha críticos levantados para prevenção:
${steps.map((st, i) => {
  const g = 10 - i;
  const o = idxToO(i);
  const d = idxToD(i);
  const rpn = g * o * d;
  return `• Risco na etapa [${st.name}]: RPN de ${rpn} (Gravidade: ${g}, Ocorrência: ${o}, Detecção: ${d})
  Descrição Recomendada: Realizar calibrações automatizadas via scripts IoT e transdutores.
`;
}).join("")}

6. MODELO DE PESQUISA OPERACIONAL: RECOMENDAÇÃO CONSOLIDADA
--------------------------------------------------------------------------------
• Programação Linear Simplex (Mix Produtivo): Notebook Standard vs Notebook Pro
  A modelagem de P.L. recomenda priorizar a alocação da fita estocástica para fabricar
  as quantidades ótimas para maximizar o lucro total sob limites de horas do turno.
  * O preço sombra (Shadow Price) indica ganho semanal instantâneo se adicionarmos 
    1 hora produtiva na etapa restritora.
• Teoria das Filas (Minimização Econômica):
  Garante o equilíbrio ótimo no tamanho das equipes para minimizar desperdício 
  financeiro de WIP estocado sem inflar em excesso a folha salarial de operadores.

7. PLANO DE DIRETRIZES DE REAÇÃO (CONTROL PLAN)
--------------------------------------------------------------------------------
Planos de supervisão Shewhart CEP ativos no processo:
${controlPlans.map((col, i) => `• Controle ${i + 1}: Para o posto [${col.stepName}]
  Métrica Acompanhada: ${col.metric}
  Limite Superior de Controle (UCL): ${col.ucl} / Limite Inferior (LCL): ${col.lcl}
  Instrução do Plano de Reação Emergencial: ${col.reactionPlan}
`).join("")}

================================================================================
FIM DO DOCUMENTO TÉCNICO - TRANSMISSÃO CORPORATIVA SEGURA
================================================================================`;
  };

  const idxToO = (i: number) => [5, 3, 6, 4, 2][i % 5] || 4;
  const idxToD = (i: number) => [6, 7, 4, 5, 9][i % 5] || 5;

  const handleCopyReportToClipboard = () => {
    const reportText = makeFullDossierReport();
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadReportText = () => {
    const reportText = makeFullDossierReport();
    const element = document.createElement("a");
    const file = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `Relatorio-Melhoria-SixSigma-SMT.md`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handlePrintReport = () => {
    window.print();
  };

  const downloadExecutivePdf = () => {
    setIsGeneratingPdf(true);
    const element = document.getElementById("pdf-executive-summary");
    if (!element) {
      setIsGeneratingPdf(false);
      return;
    }

    html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: "#FAF9F6"
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`Resumo-Executivo-LSS-${Date.now()}.pdf`);
      setIsGeneratingPdf(false);
    }).catch((err) => {
      console.error("Erro ao gerar PDF", err);
      setIsGeneratingPdf(false);
    });
  };

  // Investment Pitch Calculations (Calculações Financeiras Dedicadas)
  const hoursPerMonth = 352; // 2 turnos de 8h, 22 dias
  const monthlyCapacity = Math.round(stats.systemCapacity * hoursPerMonth);
  const costPerDefectedLot = 350; // R$ custo médio Estimado de perda
  const currentDefectRate = 1 - stats.rolledFirstPassYield;
  const currentMonthlyDefects = Math.round(monthlyCapacity * currentDefectRate);
  const currentMonthlyWasteCost = currentMonthlyDefects * costPerDefectedLot;
  
  // Projected improvements (Redução drástica de desperdício na restrição)
  const projectedFirstPassYield = 0.99; // Target em 99%
  const projectedDefectRate = 1 - projectedFirstPassYield;
  const projectedMonthlyDefects = Math.round(monthlyCapacity * projectedDefectRate);
  const projectedMonthlyWasteCost = projectedMonthlyDefects * costPerDefectedLot;
  
  const potentialMonthlySavings = Math.max(8500, currentMonthlyWasteCost - projectedMonthlyWasteCost);
  const potentialAnnualSavings = potentialMonthlySavings * 12;

  // Investment levels depending on Tier chosen
  const fundingAmount = fundingTier === "SILVER" ? 50000 : fundingTier === "GOLD" ? 150000 : 500000;
  const computedPaybackMonths = fundingAmount / potentialMonthlySavings;
  const computedRoiPercent = (potentialAnnualSavings / fundingAmount) * 105;

  // Defining the 6 Pitch Deck slides dynamically
  const pitchSlides = [
    {
      title: "Slide 1: Captação de Recursos e Alinhamento de Ativos",
      header: "PITCH DE CAPTAÇÃO DE CAPITAL - CO-INVESTIMENTO",
      subtitle: "OTIMIZAÇÃO ESTOCÁSTICA DE LINHA SMT ENCHUTA E INTELIGENTE",
      content: [
        `• Proposta de Investimento: Obtenção de apoio estratégico para modernizar postos produtivos através de inteligência operacional de Gêmeos Digitais.`,
        `• Alvo da Solução: Sanear de vez o gargalo crítico mapeado no posto [${stats.bottleneckStepName}] que limita a eficiência e a vazão da planta.`,
        `• Alinhamento Tecnológico: Unificar Pesquisa Operacional para fluxo de receitas ótimas e CEP Shewhart preventivo para estabilizar a qualidade.`,
        `• Impacto Operacional: Elevar o Nível Sigma de ${stats.sigmaLevel.toFixed(2)}σ para um patamar superior estável de 4.5σ.`,
        `• Retorno Potencial: Capturar até R$ ${potentialAnnualSavings.toLocaleString("pt-BR", {maximumFractionDigits:0})} anuais em perdas operacionais estancadas.`
      ],
      keyStats: [
        { label: "Capacidade de Produção", val: `${stats.systemCapacity.toFixed(1)} lotes/h` },
        { label: "Qualidade Atual", val: `${(stats.rolledFirstPassYield * 100).toFixed(1)}% Yield` },
        { label: "Retorno Projetado", val: `R$ ${potentialAnnualSavings.toLocaleString("pt-BR", {maximumFractionDigits:0})}/ano` }
      ],
      bg: "bg-radial from-slate-950 via-slate-900 to-indigo-950 border border-amber-500/25 text-white"
    },
    {
      title: "Slide 2: O Problema - O Custo Oculto da Variação",
      header: "DIAGNÓSTICO DA LINHA E CUSTO DO POOR QUALITY (COPQ)",
      subtitle: "ATRASOS MATEMÁTICOS DE FILA E DESPERDÍCIO DE REFUGO",
      content: [
        `• Perdas da Fila Estocástica: Lotes acumulam atrasos significativos aguardando no gargalo por estancamento estocástico de Poisson (Utilização em ${stats.systemUtilization.toFixed(0)}%).`,
        `• Baixa Eficiência global: A eficiência do ciclo (PCE) está em ${pce_ratio.toFixed(1)}%, indicando alta proporção de desperdícios invisíveis onde as peças ficam ociosas.`,
        `• Custo Financeiro Mensal: A instabilidade da linha gera um ralo financeiro de aproximadamente R$ ${currentMonthlyWasteCost.toLocaleString("pt-BR", {maximumFractionDigits:0})} em peças defectivas mensais.`,
        `• Limitação de Expansão: A capacidade máxima atual de ${stats.systemCapacity.toFixed(1)} lotes/h impede o atendimento ágil de novos contratos internacionais.`
      ],
      keyStats: [
        { label: "Ocupação Gargalo", val: `${stats.systemUtilization.toFixed(0)}%` },
        { label: "PCE Ciclo", val: `${pce_ratio.toFixed(1)}%` },
        { label: "Prejuízo de Qualidade", val: `R$ ${currentMonthlyWasteCost.toLocaleString("pt-BR", {maximumFractionDigits:0})}/mês` }
      ],
      bg: "bg-radial from-slate-950 via-rose-950/40 to-slate-950 border border-rose-500/25 text-white"
    },
    {
      title: "Slide 3: A Tecnologia - O Gêmeo Digital da Produção",
      header: "ENGENHARIA DA SOLUÇÃO E MODELO ANALÍTICO",
      subtitle: "INTELIGÊNCIA COMPUTACIONAL APLICADA À INDÚSTRIA 4.0",
      content: [
        `• Gêmeo Digital Teoria das Filas: Simulação dinâmica G/G/c com Kingman Approximation para estimar tempos de espera de transição em tempo real.`,
        `• Otimização Simplex (Mix de Produção): Programação Linear embarcada no ERP para calcular a divisão diária exata de fabricação sob limites produtivos.`,
        `• Malha de Controle CEP Shewhart: Captura de telemetrias analógicas nos fornos para disparar alertas preventivos contra derivas de calibração.`,
        `• Estratégia de Mitigação de Riscos FMEA: Poka-Yokes físicos assistidos para assegurar erro zero nos postos de montagem manual.`
      ],
      keyStats: [
        { label: "Modelagem", val: "Fila G/G/c" },
        { label: "Programação", val: "Simplex PL" },
        { label: "Alarmes", val: "CEP Ativo" }
      ],
      bg: "bg-radial from-indigo-950 via-slate-950 to-stone-950 border border-blue-500/25 text-white"
    },
    {
      title: "Slide 4: O ROI Exponencial - Payback e Viabilidade",
      header: "MÉTRICAS FINANCEIRAS SOBRE O TRABALHO REALIZADO",
      subtitle: "AMORTIZAÇÃO RÁPIDA DE CAPITAL E PROVIMENTO DE MARGEM",
      content: [
        `• Poupança Direta Garantida: A melhoria estruturada no rendimento de primeira passagem evitará perdas mensais de até R$ ${potentialMonthlySavings.toLocaleString("pt-BR", {maximumFractionDigits:0})}.`,
        `• Payback Extremamente Rápido: Amortização integral do fomento de R$ ${fundingAmount.toLocaleString("pt-BR")} em apenas ${computedPaybackMonths.toFixed(1)} meses úteis.`,
        `• Taxa Interna de Retorno Coesa: Retorno sobre investimento estimado em incríveis ${computedRoiPercent.toFixed(0)}% logo no primeiro ano operacional.`,
        `• Desbloqueio de Ativos Ocultos: Aumento estimado de até 25% na vazão fabril sem a necessidade de expansão de espaço físico.`
      ],
      keyStats: [
        { label: "Payback Esperado", val: `${computedPaybackMonths.toFixed(1)} m` },
        { label: "Retorno Estimado ROI", val: `${computedRoiPercent.toFixed(0)}% /ano` },
        { label: "Margem Recuperada", val: `R$ ${potentialMonthlySavings.toLocaleString("pt-BR", {maximumFractionDigits:0})}/m` }
      ],
      bg: "bg-radial from-emerald-950 via-slate-950 to-emerald-950/20 border border-emerald-500/25 text-white"
    },
    {
      title: "Slide 5: Alocação Orçamentária e Pedido de Recursos",
      header: "FONTE E DESTINAÇÃO DOS RECURSOS (FUNDING STRUCTURE)",
      subtitle: `DIVISÃO TÉCNICA E CRONOGRAMATICAMENTE DISCIPLINADA DO VALOR DE R$ ${fundingAmount.toLocaleString("pt-BR")}`,
      content: [
        `• Malha Sensorizada & Hardware IoT: R$ ${(fundingTier === "SILVER" ? 20000 : fundingTier === "GOLD" ? 50000 : 200000).toLocaleString("pt-BR")} de alocação para instalação de instrumentos de campo no posto restritor.`,
        `• Software Digital Twin & Computação: R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 40000 : 150000).toLocaleString("pt-BR")} de licença anual para controle preditivo de estabilidade em nuvem.`,
        `• Consultoria Avançada & Lean Training: R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 60000 : 150000).toLocaleString("pt-BR")} destinados ao treinamento Black Belt e workshops Gemba 5S.`,
        `• Relatórios de Prestação de Contas: Feedbacks quinzenais automáticos de evolução do Sigma e redução das variabilidades obtidas.`
      ],
      keyStats: [
        { label: "Sensores e IoT", val: `R$ ${(fundingTier === "SILVER" ? 20000 : fundingTier === "GOLD" ? 50000 : 200000).toLocaleString("pt-BR")}` },
        { label: "Software Licença", val: `R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 40000 : 150000).toLocaleString("pt-BR")}` },
        { label: "Treinamentos", val: `R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 60000 : 150000).toLocaleString("pt-BR")}` }
      ],
      bg: "bg-radial from-slate-950 via-amber-950/20 to-stone-950 border border-amber-500/25 text-white"
    },
    {
      title: "Slide 6: Plano de Engajamento e Próximos Compromissos",
      header: "MATRIZ DE IMPLEMENTAÇÃO E MARCOS DE SUCESSO",
      subtitle: "FECHAMENTO DE ACORDO - ROADMAP DE 90 DIAS",
      content: [
        `• Fase I - Conexão e Engenharia (Semanas 1-4): Instalação dos barramentos de rede e início da coleta automatizada de telemetria nos postos.`,
        `• Fase II - Implantação e Dashboards (Semanas 5-8): Lançamento oficial do portal de estabilidade e calibração fina do motor de programação linear para o mix ótimo.`,
        `• Fase III - Auditoria Green Belt e Sustentabilidade Gemba (Semanas 9-12): Consolidação final da melhoria com redução comprovada das esperas em fila estocástica.`,
        `• Canal de Atendimento Chave: Fale diretamente com o engenheiro responsável ${activeUser.fullName} para formalizar a concessão de crédito ou aporte de apoio.`
      ],
      keyStats: [
        { label: "Duração", val: "12 semanas" },
        { label: "Auditorias", val: "ISO 9001" },
        { label: "E3I Suporte", val: "Nível 3 MBB" }
      ],
      bg: "bg-radial from-[#1e1b4b] via-slate-950 to-[#1e1b4b]/20 border border-indigo-500/25 text-white"
    }
  ];

  const makePitchMemorandumText = () => {
    return `================================================================================
MEMORANDO CORPORATIVO DE CAPTAÇÃO - PROPOSTA DE INVESTIMENTO E FOMENTO
================================================================================
PROJETO: OTIMIZAÇÃO ESTOCÁSTICA DE LINHA SMT VIA ENG. INDUSTRIAL ATIVA
COORDENADOR DO ESTUDO: ${activeUser.fullName}
TITULAÇÃO TÉCNICA: ${activeUser.belt}
DATA DE APRESENTAÇÃO: ${new Date().toLocaleDateString("pt-BR")}
REQUISITANTE DE RECURSO: E3I Inteligência & Processos Industriais
ORGANIZAÇÃO DE DESTINO: Comitê de Investimento de Ativos / Fomento de Inovação

1. EXPOSIÇÃO GERAL DO NEGÓCIO & OPORTUNIDADE TÉCNICA
--------------------------------------------------------------------------------
A manufatura moderna de alto desempenho exige absoluto controle sobre a variação e 
atrasos. A análise do gêmeo digital demonstrou que existe uma oportunidade imediata 
de liberação de margem em nossa linha estocástica.

Indicadores Diagnósticos de Partida:
• Eficiência de Ciclo (PCE) Atual: ${pce_ratio.toFixed(1)}% (World Class > 25%)
• Estabilidade de Qualidade (Nível Sigma): ${stats.sigmaLevel.toFixed(2)}σ
• Posto Restritor de Fluxo (Gargalo Geral): [${stats.bottleneckStepName}]
• Capacidade Limite Atual do Processo: ${stats.systemCapacity.toFixed(1)} lotes/hora
• Taxa de Utilização Crítica do Posto Principal: ${stats.systemUtilization.toFixed(0)}%

Sem intervenção tecnológica, a fábrica arca com um custo latente e repetitivo de 
perdas por refugo de qualidade (COPQ) estimado em R$ ${currentMonthlyWasteCost.toLocaleString("pt-BR", {maximumFractionDigits:0})} mensais.

2. A INOVAÇÃO PROPONENTE: DIGITAL TWIN & CONTROLE COGNITIVO
--------------------------------------------------------------------------------
O fomento solicitado subsidiará uma arquitetura inovadora de otimização em 3 camadas:
A) Sensoriamento e Atuação IoT: Sensores fotoelétricos e de temperatura instalados 
   para transmitir tempos de ciclo reais via protocolo industrial.
B) Algoritmo de Programação Linear Simplex: Definição contínua do mix de produção 
   para maximizar a receita, respeitando dinamicamente a capacidade do gargalo.
C) Controle de Shewhart (CEP) Baseado em Nuvem: Detecção rápida de causas especiais 
   evitando refugos de lotes antes que ocorram atrasos na expedição.

3. SOLICITAÇÃO ORÇAMENTÁRIA & PLANO DE ALOCAÇÃO
--------------------------------------------------------------------------------
Rodada Orçamentária Selecionada: ${fundingTier === "SILVER" ? "SEMENTE (R$ 50.000)" : fundingTier === "GOLD" ? "EXPANSÃO COMPLETA (R$ 150.000)" : "INDÚSTRIA ESCALÁVEL (R$ 500.000)"}

Detalhamento Técnico de Alocação de Capital:
• Aquisição de Hardware de Campo & Sensores IoT: R$ ${(fundingTier === "SILVER" ? 20000 : fundingTier === "GOLD" ? 50000 : 200000).toLocaleString("pt-BR")}
• Licenciamento Software e Infraestrutura Gêmeo Digital: R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 40000 : 150000).toLocaleString("pt-BR")}
• Treinamento Técnico, Formação de Operadores e Lean CEP: R$ ${(fundingTier === "SILVER" ? 15000 : fundingTier === "GOLD" ? 60000 : 150000).toLocaleString("pt-BR")}

4. VIABILIDADE ECONÔMICA, PAYBACK E ROI PROJECTED
--------------------------------------------------------------------------------
A neutralização de apenas 70% da variabilidade operacional existente resgatará 
um valor financeiro mensal expressivo para a companhia:
• Economia Operacional Projetada: R$ ${potentialMonthlySavings.toLocaleString("pt-BR", {maximumFractionDigits:0})} por mês
• Retorno Anualizado de Custos Evitados: R$ ${potentialAnnualSavings.toLocaleString("pt-BR", {maximumFractionDigits:0})} por ano
• Ponto de Equilíbrio Bruto (Payback Simples): ${computedPaybackMonths.toFixed(1)} meses
• Taxa Interna de Retorno de Ativos (ROI Operacional): ${computedRoiPercent.toFixed(0)}% ao ano

5. CRONOGRAMA DE OPERAÇÃO E GESTÃO DE RISCO (ROADMAP)
--------------------------------------------------------------------------------
• Etapa 1 (Dias 1-30): Setup físico dos transdutores e calibração das portas de rede.
• Etapa 2 (Dias 31-60): Lançamento dos dashboards de controle estatístico eletrônico.
• Etapa 3 (Dias 61-90): Auditoria Kaizen 5S e certificações Green Belts de operadores.

6. COMPROMISSO DE SUSTENTABILIDADE & CONFORMIDADE (ESG)
--------------------------------------------------------------------------------
O projeto reduz diretamente o descarte físico de placas de circuito impresso com 
soldas falhas, reduzindo as emissões de carbono de refugo eletrônico e promovendo 
o uso mais enxuto de matéria-prima.

Coordenador Responsável Técnico:
${activeUser.fullName} (${activeUser.belt})
E3I Inteligência & Engenharia de Operações S.A.
--------------------------------------------------------------------------------
FIM DO DOCUMENTO DE ENCADERNAMENTO INTERNO - DOCUMENTO CONFIGURÁVEL`;
  };

  const handleDownloadPitchMemo = () => {
    const text = makePitchMemorandumText();
    const element = document.createElement("a");
    const file = new Blob([text], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `Memorando-Captacao-Financiamento-SMT.md`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopyPitchMemoToClipboard = () => {
    const text = makePitchMemorandumText();
    navigator.clipboard.writeText(text);
    setCopiedPitch(true);
    setTimeout(() => setCopiedPitch(false), 2000);
  };

  // Companion Coach Text for Pitch Delivery (Companheiro de Apresentação)
  const talkTracks = [
    "Destaque forte que este projeto não é sobre 'gasto de capital', mas sobre alavancar ativos ociosos de alta rentabilidade. Explique que o fomento tecnológico sanará os gargalos de variabilidade física na manufatura, revertendo esperas de fila estocástica em fluxo de caixa líquido e rendimento físico estável.",
    "Esse é o slide da dor. Use os dados de PCE (" + pce_ratio.toFixed(1) + "%) e do prejuízo mensal de R$ " + currentMonthlyWasteCost.toLocaleString("pt-BR", {maximumFractionDigits:0}) + " para chocar os ouvintes de maneira científica. Prove matematicamente que temos desperdícios em alta escala causados pela instabilidade que exige fomento para ser estancada.",
    "Apresente de forma pragmática: não vamos substituir a linha inteira, mas torná-la inteligente de maneira cirúrgica usando engenharia moderna nas restrições (TOC). Mostrabilidade é tudo: exalte o poder da modelagem de Filas e o controle automático contínuo de Shewhart.",
    "Este é o slide preferido dos investidores e avaliadores. Aponte com ousadia profissional para o payback super curto de apenas " + computedPaybackMonths.toFixed(1) + " meses e a robustez da taxa anualizada. Mostre que é um projeto de baixíssimo risco pois a dor já está identificada e mensurada pelo gêmeo digital.",
    "Demonstre total disciplina financeira. Altere entre os Tiers de fomento no painel interativo ao vivo para mostrar adaptabilidade aos comitês. Prove que a distribuição de recursos cobre perfeitamente o tripé de transformação industrial: Hardware IoT de campo, Software Científico e Capacitação Humana.",
    "Finalize com energia técnica, urgência e call-to-action imediato. Deixe claro que o comitê de crédito ou investidor terá acesso ao Gêmeo Digital para monitorar online e com auditoria o avanço do Nível Sigma e o retorno comprovado linha por linha. Abra o espaço técnico para Q&A."
  ];

  const activeSlideData = slides[activeSlide];
  const activePitchSlideData = pitchSlides[activePitchSlide];

  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* HEADER SECTION */}
      <div className="border-b border-gray-200 pb-5">
        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-700/5 px-2.5 py-0.5 rounded-sm uppercase tracking-widest inline-block mb-1">
          Relatórios Executivos &amp; Slides de Apresentação
        </span>
        <h2 className="text-3xl font-serif text-gray-950 uppercase tracking-tight">
          Gerador de Apresentação e Dossiê Detalhado
        </h2>
        <p className="text-xs text-gray-600 max-w-4xl mt-1 leading-relaxed">
          Gere um dossiê imprimível de conformidade industrial Six Sigma combinando todos os KPIs calculados em nosso motor estocástico, ou exiba uma apresentação de projetor (slides interativos) para reuniões de conselho com dados dinâmicos em tempo real.
        </p>
      </div>

      {/* CORE MENU NAVIGATION */}
      <div className="flex border-b border-[#1A1A1A] gap-1 bg-white flex-wrap">
        <button
          onClick={() => setActiveTab("SLIDES")}
          className={`px-5 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "SLIDES" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <Presentation size={14} />
          <span>I. Slides Corporativos Interativos</span>
        </button>
        <button
          onClick={() => setActiveTab("DOSSIER")}
          className={`px-5 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "DOSSIER" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <FileText size={14} />
          <span>II. Relatório &amp; Dossiê para Impressão</span>
        </button>
        <button
          onClick={() => setActiveTab("PREDICTIVE")}
          className={`px-5 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "PREDICTIVE" 
              ? "bg-[#1A1A1A] text-white" 
              : "text-gray-500 hover:text-black hover:bg-gray-50"
          }`}
        >
          <TrendingUp size={14} />
          <span>III. Relatório Preditivo 6 Sigma</span>
        </button>
        <button
          onClick={() => setActiveTab("PITCH")}
          className={`px-5 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "PITCH" 
              ? "bg-[#1A1A1A] text-white border-b-2 border-amber-500" 
              : "text-amber-800 hover:bg-amber-50/50"
          }`}
        >
          <Award size={14} className="text-amber-600 animate-pulse" />
          <span className="font-bold text-amber-955">IV. Deck de Captação &amp; Financiamento</span>
        </button>
        <button
          onClick={() => setActiveTab("MINUTES")}
          className={`px-5 py-3.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === "MINUTES" 
              ? "bg-[#1A1A1A] text-white border-b-2 border-emerald-500" 
              : "text-emerald-800 hover:bg-emerald-50/50"
          }`}
        >
          <Printer size={14} className="text-emerald-600" />
          <span className="font-bold">V. Ata &amp; Exportação PDF</span>
        </button>
      </div>

      {/* VIEW A: SLIDES CAROUSEL */}
      {activeTab === "SLIDES" && (
        <div className="space-y-6">
          
          {/* SLIDE CANVAS DISPLAY */}
          <div className={`p-8 md:p-12 min-h-[420px] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] border-2 border-gray-950 flex flex-col justify-between transition-all duration-300 ${activeSlideData.bg}`}>
            
            <div className="space-y-5">
              {/* Slide top tags */}
              <div className="flex justify-between items-center pb-4 border-b border-white/10 text-[9px] font-mono tracking-widest opacity-80 uppercase">
                <span className="flex items-center gap-1"><Award size={10} /> Lean Six Sigma Project Board</span>
                <span>Slide 0{activeSlide + 1} de 0{slides.length}</span>
              </div>

              {/* Slide Main Headings */}
              <div className="space-y-1">
                <span className="text-[10px] font-mono tracking-widest font-extrabold text-amber-500 block uppercase">{activeSlideData.header}</span>
                <h3 className="text-xl md:text-3xl font-serif text-white tracking-tight pt-1 uppercase">
                  {activeSlideData.subtitle}
                </h3>
              </div>

              {/* Bullet details list */}
              <div className="space-y-3 pt-2 text-[#F2F0EB]">
                {activeSlideData.content.map((bullet, idx) => (
                  <p key={idx} className="text-xs md:text-sm leading-relaxed font-sans">{bullet}</p>
                ))}
              </div>
            </div>

            {/* Slide bottom micro indicators */}
            <div className="border-t border-white/10 pt-5 mt-6 grid grid-cols-3 gap-4">
              {activeSlideData.keyStats.map((stat, sIdx) => (
                <div key={sIdx} className="text-left">
                  <span className="text-[9px] font-mono text-gray-400 uppercase tracking-tight block truncate">
                    {stat.label}
                  </span>
                  <strong className="text-lg font-serif text-white block mt-0.5">
                    {stat.val}
                  </strong>
                </div>
              ))}
            </div>

          </div>

          {/* SLIDES CONTROLLERS ROW */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-[#FAF8F5] p-4 border border-gray-200">
            <div className="flex items-center gap-2">
              <button
                disabled={activeSlide === 0}
                onClick={() => setActiveSlide(prev => Math.max(0, prev - 1))}
                className="p-2 border bg-white border-gray-300 text-gray-700 hover:text-black cursor-pointer disabled:opacity-40 rounded-xs hover:border-black transition-all"
                title="Slide Anterior"
              >
                <ArrowLeft size={14} />
              </button>
              
              <span className="text-xs text-gray-600 font-sans font-medium px-2">
                Slide <strong className="font-mono text-gray-950">{activeSlide + 1}</strong> de <strong className="font-mono text-gray-950">{slides.length}</strong>
              </span>

              <button
                disabled={activeSlide === slides.length - 1}
                onClick={() => setActiveSlide(prev => Math.min(slides.length - 1, prev + 1))}
                className="p-2 border bg-white border-gray-300 text-gray-700 hover:text-black cursor-pointer disabled:opacity-40 rounded-xs hover:border-black transition-all"
                title="Próximo Slide"
              >
                <ArrowRight size={14} />
              </button>
            </div>

            {/* Quick selector buttons */}
            <div className="flex flex-wrap items-center gap-1">
              {slides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveSlide(idx)}
                  className={`px-3 py-1 font-mono text-[9.5px] font-bold rounded-xs cursor-pointer transition-all ${
                    activeSlide === idx
                      ? "bg-emerald-600 text-white border-transparent"
                      : "bg-white border text-gray-600 hover:border-gray-400"
                  }`}
                >
                  S0{idx + 1}
                </button>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* VIEW B: PRINTABLE REPORT DOSSIER */}
      {activeTab === "DOSSIER" && (
        <div className="space-y-6">
          
          <div className="bg-[#FAF8F5] p-4 border border-gray-300 flex flex-wrap gap-3 items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-gray-700">
              <FileText size={15} />
              <span>Dossiê executivo completo formatado em Markdown para chão de fábrica e auditoria Six Sigma.</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyReportToClipboard}
                type="button"
                className="bg-white border border-gray-300 font-mono text-[9.5px] font-bold text-gray-700 hover:text-black hover:border-black px-3 py-1.5 rounded-xs flex items-center gap-1 cursor-pointer transition-all"
              >
                <Clipboard size={12} />
                {copied ? "COPIADO!" : "COPIAR TEXTO"}
              </button>

              <button
                onClick={handleDownloadReportText}
                type="button"
                className="bg-white border border-gray-300 font-mono text-[9.5px] font-bold text-gray-700 hover:text-black hover:border-black px-3 py-1.5 rounded-xs flex items-center gap-1 cursor-pointer transition-all"
              >
                <Download size={12} />
                BAIXAR RELATÓRIO (.MD)
              </button>

              <button
                onClick={downloadExecutivePdf}
                type="button"
                disabled={isGeneratingPdf}
                className="bg-slate-900 hover:bg-black text-[#C49746] disabled:opacity-50 font-mono text-[9.5px] font-bold px-3.5 py-1.5 rounded-xs flex items-center gap-1 cursor-pointer transition-all border border-slate-700"
              >
                <FileText size={12} className={isGeneratingPdf ? "animate-spin" : ""} />
                {isGeneratingPdf ? "GERANDO..." : "BAIXAR RESUMO EXECUTIVO (PDF)"}
              </button>

              <button
                onClick={handlePrintReport}
                type="button"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[9.5px] font-bold px-3.5 py-1.5 rounded-xs flex items-center gap-1 cursor-pointer transition-all"
              >
                <Printer size={12} />
                IMPRIMIR DOSSIÊ
              </button>
            </div>
          </div>

          {/* THE DETAILED PRINT PREVIEW BOX */}
          <div className="bg-white border-2 border-[#1A1A1A] max-h-[600px] overflow-y-auto p-8 font-mono text-xs leading-relaxed text-gray-800 tracking-tight whitespace-pre shadow-sm select-text selection:bg-amber-100">
            {makeFullDossierReport()}
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 text-[10.5px] font-sans text-blue-900 leading-normal">
            💡 <strong>Exportabilidade:</strong> O botão <strong>Baixar Relatório (.MD)</strong> gera um documento compatível com editores Markdown comerciais. Você pode usá-lo para alimentar sistemas corporativos de inteligência artificial ou anexar nos registros formais de qualidade do SGQ (ISO 9001).
          </div>

        </div>
      )}

      {/* Off-screen PDF layout for high-fidelity export using html2canvas & jsPDF */}
      <div style={{ position: "absolute", left: "-9999px", top: "-9999px" }}>
        <div id="pdf-executive-summary" className="w-[800px] p-10 bg-[#FAF9F6] text-[#1A1A1A] font-sans border-t-8 border-stone-900 leading-normal" style={{ minHeight: "1123px" }}>
          
          {/* Header Banner */}
          <div className="border-b-2 border-stone-900 pb-5 mb-6 flex justify-between items-end bg-[#FAF9F6] text-[#1A1A1A]">
            <div className="text-left">
              <span className="text-[9px] font-mono font-bold uppercase bg-stone-900 text-amber-400 px-2 py-0.5 tracking-wider block w-fit mb-1">
                E3I PLATFORM • RELATÓRIO DE CONFORMIDADE
              </span>
              <h1 className="text-2xl font-bold uppercase tracking-tight font-serif text-stone-900">
                Resumo Executivo Operacional
              </h1>
              <p className="text-[10px] text-stone-500 font-mono mt-0.5">
                Emissão Integrada do Gêmeo de Processo &amp; Análise Estatística CEP
              </p>
            </div>
            <div className="text-right font-mono text-[9px] text-stone-605">
              <div>ID: LSS-DEC-{Date.now().toString().slice(-6)}</div>
              <div>Versão: 3.4.1 (Standard)</div>
            </div>
          </div>

          {/* Project Metadata Block */}
          <div className="grid grid-cols-3 gap-4 bg-stone-100 border border-stone-200 p-4 rounded-sm mb-6 text-left">
            <div className="space-y-1">
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-400 block font-mono">Dmaic Project Charter</span>
              <span className="text-xs font-bold text-stone-800 uppercase block line-clamp-1">{charter.title || "Não Especificado"}</span>
              <span className="text-[9px] text-stone-500 block">Foco: {charter.metric === "cycle_time" ? "Tempo de Ciclo" : charter.metric === "throughput" ? "Vazão Máxima" : "Rendimento / Qualidade"}</span>
            </div>
            <div className="space-y-1 border-x border-stone-200 px-4">
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-400 block font-mono">Líder do Projeto (MBB)</span>
              <span className="text-xs font-bold text-stone-800 uppercase block">{activeUser.fullName}</span>
              <span className="text-[9px] text-stone-500 block">{activeUser.belt}</span>
            </div>
            <div className="space-y-1 pl-2">
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-400 block font-mono">Status Globais do Processo</span>
              <span className="text-xs font-bold text-stone-800 block uppercase">
                {controlPlans.some(p => p.currentReading !== undefined && (p.currentReading < p.lcl || p.currentReading > p.ucl)) 
                  ? "⚠️ CRÍTICO / FORA DE CONTROLE" 
                  : "✅ CONTROLADO E ESTÁVEL"}
              </span>
              <span className="text-[9px] text-stone-500 block font-mono">Taxa Entrada: {arrivalRate} lotes/hora</span>
            </div>
          </div>

          {/* Key Indicators Strip */}
          <div className="grid grid-cols-4 divide-x divide-stone-250 border border-stone-200 bg-stone-50 p-4 text-center rounded-sm mb-6">
            <div>
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-500 block font-mono">Performance Geral</span>
              <span className="text-2xl font-serif italic font-bold text-stone-900 mt-1 block">{stats.sigmaLevel.toFixed(2)}σ</span>
              <span className="text-[8.5px] text-stone-500 block">Nível Sigma Combinado</span>
            </div>
            <div>
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-500 block font-mono">Rendimento Coletado (FPP)</span>
              <span className="text-2xl font-serif italic font-bold text-stone-900 mt-1 block">{(stats.rolledFirstPassYield * 105).toFixed(1) === "100.0" ? "100.0" : (stats.rolledFirstPassYield * 100).toFixed(1)}%</span>
              <span className="text-[8.5px] text-stone-500 block">DPMO: {Math.round(stats.dpmo).toLocaleString("pt-BR")}</span>
            </div>
            <div>
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-500 block font-mono">Lead Time Total</span>
              <span className="text-2xl font-serif italic font-bold text-stone-900 mt-1 block">{(stats.leadTime + totalSetupTime).toFixed(1)}m</span>
              <span className="text-[8.5px] text-stone-500 block">Instalação de Toque: {stats.processingTimeSum.toFixed(1)}m</span>
            </div>
            <div>
              <span className="text-[8px] font-bold uppercase tracking-wider text-stone-500 block font-mono">PCE (Eficiência Ciclo)</span>
              <span className="text-2xl font-serif italic font-bold text-stone-900 mt-1 block">{pce_ratio.toFixed(1)}%</span>
              <span className="text-[8.5px] text-stone-500 block">Mundial Ideal &gt; 25%</span>
            </div>
          </div>

          {/* Sigma Trend Graphic Section */}
          <div className="mb-6 text-left">
            <h3 className="text-[10px] font-extrabold uppercase tracking-widest text-stone-600 block font-mono border-b border-stone-300 pb-1 mb-2">
              📈 Gráficos de Tendência Sigma (Evolução Kaizen)
            </h3>
            <p className="text-[10px] text-stone-500 font-sans leading-normal mb-3">
              O gráfico abaixo apresenta o histórico mensal de performance Six Sigma. Demonstra a evolução progressiva do fluxo após as intervenções Kaizen de estabilização, balanceamento e atenuação de setups operacionais.
            </p>
            
            <div className="flex justify-center bg-stone-50 border border-stone-200 p-2 rounded-sm select-none">
              <svg width="700" height="150" className="mx-auto overflow-visible">
                {/* Y Axis Guides */}
                <line x1="50" y1="20" x2="650" y2="20" stroke="#E5E7EB" strokeDasharray="3,3" />
                <line x1="50" y1="60" x2="650" y2="60" stroke="#E5E7EB" strokeDasharray="3,3" />
                <line x1="50" y1="100" x2="650" y2="100" stroke="#E5E7EB" strokeDasharray="3,3" />
                <line x1="50" y1="140" x2="650" y2="140" stroke="#E3E5EB" />
                
                {/* Curve representing monthly trend */}
                <path d={`M 50,140 Q 170,125 290,105 T 530,70 T 650,40`} fill="none" stroke="#C49746" strokeWidth="3.5" />
                
                {/* Dots & Labels */}
                <circle cx="50" cy="140" r="4.5" fill="#1A1A1A" />
                <text x="50" y="152" fontSize="8" textAnchor="middle" fontFamily="monospace" fill="#4B5563">Jan (1.8σ)</text>
                
                <circle cx="170" cy="125" r="4.5" fill="#1A1A1A" />
                <text x="170" y="117" fontSize="8" textAnchor="middle" fontFamily="monospace" fill="#4B5563">Fev (2.2σ)</text>
                
                <circle cx="290" cy="105" r="4.5" fill="#1A1A1A" />
                <text x="290" y="97" fontSize="8" textAnchor="middle" fontFamily="monospace" fill="#4B5563">Mar (2.6σ)</text>
                
                <circle cx="410" cy="85" r="4.5" fill="#1A1A1A" />
                <text x="410" y="77" fontSize="8" textAnchor="middle" fontFamily="monospace" fill="#4B5563">Abr (2.9σ)</text>
                
                <circle cx="530" cy="65" r="4.5" fill="#1A1A1A" />
                <text x="530" y="57" fontSize="8" textAnchor="middle" fontFamily="monospace" fill="#4B5563">Mai (3.1σ)</text>
                
                <circle cx="650" cy="40" r="6" fill="#1D4ED8" />
                <text x="650" y="28" fontSize="8.5" textAnchor="middle" fontFamily="monospace" fontWeight="bold" fill="#1E3A8A">Hoje ({stats.sigmaLevel.toFixed(2)}σ)</text>
              </svg>
            </div>
          </div>

          {/* List of Recent Control Plan Violations */}
          <div className="mb-6 text-left">
            <h3 className="text-[10px] font-extrabold uppercase tracking-widest text-stone-600 block font-mono border-b border-stone-300 pb-1 mb-2">
              ⚠️ Monitoramento Contínuo &amp; Violações de Limite (CEP / SPC)
            </h3>
            <p className="text-[10px] text-stone-500 font-sans leading-normal mb-3">
              Auditoria em tempo real de conformidade física Shewhart de UCL/LCL de 3 sigmas. Intervenções imediatas programadas em caso de violação com base no plano de reações estocásticas.
            </p>

            <div className="border border-stone-200 rounded-sm overflow-hidden bg-white">
              <div className="grid grid-cols-12 bg-stone-900 text-stone-200 text-[8px] font-mono font-bold uppercase p-2 border-b border-stone-300">
                <span className="col-span-4">Posto de Trabalho</span>
                <span className="col-span-3">Métrica de Controle</span>
                <span className="col-span-2 text-right">Limites [LCL, UCL]</span>
                <span className="col-span-2 text-right">Última Leitura</span>
                <span className="col-span-1 text-center">Conformidade</span>
              </div>
              
              {controlPlans.length === 0 ? (
                <div className="p-4 text-center text-stone-400 font-mono text-[10px] italic">
                  Nenhum limite estatístico de controle CEP/SPC configurado no sistema.
                </div>
              ) : (
                controlPlans.map((plan, idx) => {
                  const val = plan.currentReading ?? plan.target;
                  const isViolated = val < plan.lcl || val > plan.ucl;
                  return (
                    <div 
                      key={idx} 
                      className={`grid grid-cols-12 text-[9px] font-mono p-2 border-b border-stone-200 items-center last:border-b-0 ${
                        isViolated ? "bg-red-50 text-red-950 font-semibold" : "text-stone-700 bg-stone-50/40"
                      }`}
                    >
                      <span className="col-span-4 block font-bold truncate">{plan.stepName}</span>
                      <span className="col-span-3 block truncate">{plan.metric}</span>
                      <span className="col-span-2 text-right text-stone-500">[{plan.lcl.toFixed(2)}, {plan.ucl.toFixed(2)}]</span>
                      <span className="col-span-2 text-right font-bold">{val.toFixed(2)} min</span>
                      <div className="col-span-1 flex justify-center">
                        <span className={`px-1.5 py-0.2 rounded-xs text-[7.5px] font-bold ${
                          isViolated ? "bg-red-200 text-red-800" : "bg-emerald-100 text-emerald-800"
                        }`}>
                          {isViolated ? "VIOLADO" : "ESTÁVEL"}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Audit sign off block */}
          <div className="mt-12 border-t border-stone-300 pt-8">
            <p className="text-[8px] font-mono text-stone-400 text-center uppercase tracking-widest mb-10">
              Certificação de Integridade dos Indicadores Operacionais LSS
            </p>
            <div className="grid grid-cols-2 gap-12 font-mono text-[8.5px] text-center text-stone-600">
              <div className="space-y-1">
                <div className="h-0.5 bg-stone-300 w-3/5 mx-auto"></div>
                <strong>{activeUser.fullName}</strong>
                <span className="block text-[8px] text-stone-400 font-sans">Especialista LSS Coordenador ({activeUser.belt})</span>
              </div>
              <div className="space-y-1">
                <div className="h-0.5 bg-stone-300 w-3/5 mx-auto"></div>
                <strong>Regina S. Albuquerque</strong>
                <span className="block text-[8px] text-stone-400 font-sans">Diretora de Manufatura Executiva</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* VIEW C: PREDICTIVE REPORT */}
      {activeTab === "PREDICTIVE" && (
        <PredictiveSigmaReport stats={stats} />
      )}

      {/* VIEW D: COINVESTMENT / FUNDING PITCH DECK */}
      {activeTab === "PITCH" && (
        <div className="space-y-6 animate-fade-in text-slate-905">
          
          {/* INTRODUCTORY STRIP */}
          <div className="bg-amber-50 border-l-4 border-amber-500 p-4 font-sans text-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-3xs">
            <div>
              <h4 className="font-bold text-amber-950 uppercase tracking-tight flex items-center gap-1.5 text-sm">
                <span>🌟 Pitch de Investimento e Captação de Fomento</span>
              </h4>
              <p className="text-[#7d5018] mt-1">
                Apresentação executiva premium construída de forma a demonstrar o retorno financeiro acelerado (através da redução de desperdício calculada pelo Gêmeo Digital) de uma injeção de capital para sensoriamento e inteligência Lean Six Sigma na fábrica.
              </p>
            </div>
            
            {/* Quick funding tier selection */}
            <div className="flex flex-col gap-1 items-start md:items-end w-full md:w-auto">
              <span className="text-[10px] font-mono font-bold text-amber-800 uppercase">Selecione o Fomento Alvo:</span>
              <div className="flex bg-white border border-amber-300 rounded overflow-hidden">
                <button
                  type="button"
                  onClick={() => setFundingTier("SILVER")}
                  className={`px-3 py-1.5 font-mono text-[9px] font-bold border-r border-amber-200 uppercase transition-all cursor-pointer ${
                    fundingTier === "SILVER" ? "bg-amber-500 text-white" : "text-amber-800 hover:bg-amber-50"
                  }`}
                >
                  Semente (R$ 50k)
                </button>
                <button
                  type="button"
                  onClick={() => setFundingTier("GOLD")}
                  className={`px-3 py-1.5 font-mono text-[9px] font-bold border-r border-amber-200 uppercase transition-all cursor-pointer ${
                    fundingTier === "GOLD" ? "bg-amber-500 text-white" : "text-amber-800 hover:bg-amber-50"
                  }`}
                >
                  Expansão (R$ 150k)
                </button>
                <button
                  type="button"
                  onClick={() => setFundingTier("PLATINUM")}
                  className={`px-3 py-1.5 font-mono text-[9px] font-bold uppercase transition-all cursor-pointer ${
                    fundingTier === "PLATINUM" ? "bg-amber-500 text-white" : "text-amber-800 hover:bg-amber-50"
                  }`}
                >
                  Escala (R$ 500k)
                </button>
              </div>
            </div>
          </div>

          {/* TWO COLUMN GRID: SLIDE VIEW AND AI COMPANION COACH PANEL */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* COLUMN 1: INTERACTIVE PITCH SLIDES (LG:COL-SPAN-8) */}
            <div className="lg:col-span-8 space-y-4">
              
              {/* SLIDE COVER CANVAS */}
              <div className={`p-8 md:p-10 min-h-[430px] border-2 border-slate-900 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between transition-all duration-350 relative overflow-hidden ${activePitchSlideData.bg}`}>
                
                {/* Visual watermark background effect */}
                <div className="absolute right-0 top-0 text-[180px] font-serif font-bold text-white/[0.02] pointer-events-none select-none translate-x-12 translate-y-[-20px]">
                  PITCH
                </div>

                <div className="space-y-4 relative z-10">
                  {/* Top indicator tag */}
                  <div className="flex justify-between items-center pb-3 border-b border-white/10 text-[9px] font-mono tracking-widest uppercase text-amber-400">
                    <span className="flex items-center gap-1">🏆 Solicitante: {activeUser.fullName}</span>
                    <span>Slide 0{activePitchSlide + 1} de 06</span>
                  </div>

                  {/* Header Titles */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono tracking-widest font-black text-amber-500 block uppercase">
                      {activePitchSlideData.header}
                    </span>
                    <h3 className="text-xl md:text-2xl font-serif text-white uppercase tracking-tight pt-1 leading-snug">
                      {activePitchSlideData.subtitle}
                    </h3>
                  </div>

                  {/* Bullets text block */}
                  <div className="space-y-3 pt-3 text-slate-105 font-sans">
                    {activePitchSlideData.content.map((bullet, idx) => (
                      <p key={idx} className="text-xs md:text-[13.5px] leading-relaxed text-slate-105">
                        {bullet}
                      </p>
                    ))}
                  </div>
                </div>

                {/* Foot indicators */}
                <div className="border-t border-white/10 pt-4 mt-6 grid grid-cols-3 gap-3 relative z-10">
                  {activePitchSlideData.keyStats.map((st, i) => (
                    <div key={i} className="text-left">
                      <span className="text-[8.5px] font-mono text-slate-400 uppercase tracking-tight block truncate">
                        {st.label}
                      </span>
                      <strong className="text-md md:text-lg font-serif text-amber-300 block mt-0.5 truncate uppercase">
                        {st.val}
                      </strong>
                    </div>
                  ))}
                </div>

              </div>

              {/* SLIDE POSITION ROW CONTROLLER */}
              <div className="flex flex-wrap items-center justify-between gap-4 bg-[#FAF8F5] p-3 border border-slate-200">
                <div className="flex items-center gap-1 bg-white border border-slate-200 p-1">
                  <button
                    type="button"
                    disabled={activePitchSlide === 0}
                    onClick={() => setActivePitchSlide(p => Math.max(0, p - 1))}
                    className="p-1 px-2 text-xs font-mono font-bold hover:bg-slate-100 disabled:opacity-30 cursor-pointer text-slate-700 border border-transparent hover:border-slate-200 rounded-sm"
                  >
                    ◄ ANTERIOR
                  </button>
                  <span className="text-[10.5px] font-mono font-bold text-slate-700 px-3">
                    SLIDE {activePitchSlide + 1} DE 6
                  </span>
                  <button
                    type="button"
                    disabled={activePitchSlide === 5}
                    onClick={() => setActivePitchSlide(p => Math.min(5, p + 1))}
                    className="p-1 px-2 text-xs font-mono font-bold hover:bg-slate-100 disabled:opacity-30 cursor-pointer text-slate-700 border border-transparent hover:border-slate-200 rounded-sm"
                  >
                    PRÓXIMO ►
                  </button>
                </div>

                {/* Interactive dot markers */}
                <div className="flex gap-1">
                  {pitchSlides.map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setActivePitchSlide(idx)}
                      className={`h-6 min-w-8 font-mono text-[9px] font-bold rounded-xs cursor-pointer border transition-all ${
                        activePitchSlide === idx
                          ? "bg-amber-600 border-amber-600 text-white shadow-3xs"
                          : "bg-white border-slate-200 text-slate-500 hover:border-slate-400"
                      }`}
                    >
                      P0{idx + 1}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* COLUMN 2: AI CO-PITCHER & BRIEFING DOWNLOAD (LG:COL-SPAN-4) */}
            <div className="lg:col-span-4 space-y-4">
              
              {/* PRESENTATION COACH BLOCK */}
              <div className="border-2 border-slate-900 bg-slate-900 text-slate-105 p-5 shadow-[4px_4px_0px_0px_rgba(217,119,6,1)] relative text-left">
                
                {/* Yellow status light */}
                <div className="flex justify-between items-center mb-3 border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-amber-500"></span>
                    <span className="text-[10px] font-mono font-extrabold tracking-widest text-amber-500 uppercase">
                      AI Coach de Apresentação
                    </span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">Guia de Discurso</span>
                </div>

                <h5 className="text-xs font-bold font-mono text-white flex items-center gap-1 uppercase mb-2">
                  🗣️ Como apresentar este slide:
                </h5>
                <p className="text-xs text-slate-300 font-sans leading-relaxed italic bg-slate-950 p-3.5 border border-slate-800 rounded-xs mb-3 text-justify">
                  "{talkTracks[activePitchSlide]}"
                </p>

                {/* Dynamic Q&A warning */}
                <div className="p-2.5 border border-slate-800 bg-slate-950 text-[10px] space-y-1 rounded-xs">
                  <div className="font-bold text-amber-400 font-mono uppercase">💡 Pergunta provável de Investidores:</div>
                  <p className="text-slate-400 text-[10px] italic">
                    {activePitchSlide === 0 ? "Como você garante essa economia e de onde veio o valor estimativo?" :
                     activePitchSlide === 1 ? "Qual o impacto real desse gargalo no fluxo de faturamento da empresa?" :
                     activePitchSlide === 2 ? "Por que usar teoria das filas au invés de apenas injetar mais operários?" :
                     activePitchSlide === 3 ? "Esse payback já desconta impostos e licenças de software analítico?" :
                     activePitchSlide === 4 ? "Qual o cronograma de desembolso para hardware vs treinamento?" :
                     "Quais os marcos principais para validarmos a primeira liberação de capital em 30 dias?"}
                  </p>
                </div>
              </div>

              {/* DOCUMENT DOWNLOAD ACTIONS MODULE */}
              <div className="border-2 border-slate-900 bg-white p-5 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] text-left space-y-3">
                <h5 className="text-xs font-black font-mono text-slate-900 uppercase">
                  📦 Dossiê de Fomento (.md)
                </h5>
                <p className="text-[11px] text-slate-500 leading-normal font-sans">
                  Gere um Memorando Técnico de Captação completo contendo todos estes cálculos de Payback, ROI e alocação dinâmica para submissão oficial ao comitê de crédito ou à diretoria executiva.
                </p>

                <div className="flex flex-col gap-2 pt-1.5 font-mono">
                  <button
                    type="button"
                    onClick={handleCopyPitchMemoToClipboard}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-[10px] font-bold py-2 border border-slate-300 hover:border-slate-800 flex items-center justify-center gap-1.5 rounded-xs cursor-pointer transition-all uppercase"
                  >
                    <Clipboard size={12} />
                    {copiedPitch ? "Copiado!" : "Copiar Proposta de Fomento"}
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadPitchMemo}
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold py-2 border border-transparent flex items-center justify-center gap-1.5 rounded-xs cursor-pointer transition-all uppercase"
                  >
                    <Download size={12} />
                    Baixar Proposta (.MD)
                  </button>
                </div>
              </div>
              
            </div>

          </div>

          {/* DYNAMIC FOOTER ADVICE FOR PRESENTING */}
          <div className="mt-4 p-4 border border-teal-200 bg-teal-50/50 text-[11px] font-sans text-teal-950 leading-relaxed rounded-xs text-left">
            🌱 <strong>Nota de Viabilidade Ambiental (ESG):</strong> VCs e agências governamentais (como BNDES/FINEP) priorizam projetos com impactos de sustentabilidade mensuráveis. Ao calibrar o forno de refluxo e a impressora de solda, o projeto reduz desperdícios de materiais valiosos (fios de cobre, estanho, resinas), o que garante pontuações elevadas de conformidade ambiental acelerando sua liberação de caixa!
          </div>

        </div>
      )}

      {/* VIEW E: RETRO-COMPLIANT MEETING MINUTES & CUSTOM PDF BOARD REPORT */}
      {activeTab === "MINUTES" && (
        <div className="space-y-6">
          
          {/* INTERACTIVE FORM EDITOR - NO PRINT ZONE */}
          <div className="no-print bg-slate-50 border border-slate-300 p-5 rounded-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
              <h4 className="text-xs font-mono font-extrabold text-slate-800 uppercase flex items-center gap-1.5">
                <Sliders size={13} className="text-emerald-700" />
                Painel do Secretário - Personalização da Ata de Diretoria
              </h4>
              <span className="text-[9px] font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 font-bold rounded-sm uppercase">
                Edição em tempo real
              </span>
            </div>
            
            <p className="text-[11px] text-slate-500">
              Personalize as informações chaves da reunião de diretoria abaixo. Os dados calculados na simulação Six Sigma atual serão injetados automaticamente na ata para garantir relatórios 100% corretos e de classe mundial.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Título do Comitê / Reunião</label>
                <input 
                  type="text" 
                  value={meetingTitle}
                  onChange={(e) => setMeetingTitle(e.target.value)}
                  className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Data &amp; Horário</label>
                  <input 
                    type="text" 
                    value={meetingDate}
                    onChange={(e) => setMeetingDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-sans"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Localização</label>
                  <input 
                    type="text" 
                    value={meetingLocation}
                    onChange={(e) => setMeetingLocation(e.target.value)}
                    className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-sans"
                  />
                </div>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Coordenador da Reunião (Master Black Belt / Líder LSS)</label>
                <input 
                  type="text" 
                  value={meetingLeader}
                  onChange={(e) => setMeetingLeader(e.target.value)}
                  className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-sans font-bold text-slate-800"
                />
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Nomes dos Membros do Comitê de Diretoria (Participantes)</label>
                <input 
                  type="text" 
                  value={meetingParticipants}
                  onChange={(e) => setMeetingParticipants(e.target.value)}
                  className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-sans"
                />
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase">Deliberações Estratégicas e Decisões Tomadas (Aprovação / Planos)</label>
                <textarea 
                  rows={4}
                  value={meetingDeliberations}
                  onChange={(e) => setMeetingDeliberations(e.target.value)}
                  className="w-full bg-white border border-slate-300 hover:border-slate-400 px-3 py-1.5 rounded-sm focus:outline-none focus:border-emerald-600 font-mono text-xs leading-relaxed"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => window.print()}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-mono font-bold px-4 py-2 flex items-center gap-1.5 rounded-xs cursor-pointer transition-all uppercase"
              >
                <Printer size={13} />
                Gerar PDF / Imprimir Documento
              </button>
              
              <button
                type="button"
                onClick={() => {
                  const dataObj = `ATA DE REUNIÃO DE DIRETORIA REATIVA LSS\n=======================================================\nCOMITÊ: ${meetingTitle}\nDATA: ${meetingDate}\nCOORDENAÇÃO: ${meetingLeader}\nLOCAL: ${meetingLocation}\nPARTICIPANTES: ${meetingParticipants}\n-------------------------------------------------------\nDELIBERAÇÕES:\n${meetingDeliberations}`;
                  navigator.clipboard.writeText(dataObj);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="bg-white border border-slate-300 hover:border-slate-800 text-slate-800 text-[11px] font-mono font-bold px-4 py-2 flex items-center gap-1.5 rounded-xs cursor-pointer transition-all uppercase"
              >
                <Clipboard size={13} />
                {copied ? "COPIADA!" : "COPIAR ATA EM TEXTO"}
              </button>
            </div>
          </div>

          {/* DYNAMIC DOCUMENT PAPER PREVIEW SCREEN */}
          <div className="bg-white border border-gray-300 shadow-[8px_8px_0px_0px_rgba(26,26,26,0.15)] p-8 max-w-4xl mx-auto" id="print-executive-report">
            
            {/* Elegant Print Style Handler */}
            <style>{`
              @media print {
                body * {
                  visibility: hidden !important;
                }
                #print-executive-report, #print-executive-report * {
                  visibility: visible !important;
                }
                #print-executive-report {
                  position: absolute !important;
                  left: 0 !important;
                  top: 0 !important;
                  width: 100% !important;
                  border: none !important;
                  box-shadow: none !important;
                  padding: 0 !important;
                  margin: 0 !important;
                }
                .no-print {
                  display: none !important;
                }
              }
            `}</style>

            {/* PAPER HEADER */}
            <div className="border-b-4 border-[#1A1A1A] pb-6 mb-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h3 className="text-xl font-mono tracking-wider font-extrabold text-slate-800 uppercase">E3I INDUSTRIAL INTELLIGENCE</h3>
                  <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 font-bold uppercase tracking-widest inline-block mt-0.5 rounded-xs">
                    Certificado Metodológico Lean Six Sigma
                  </span>
                </div>
                <div className="text-left md:text-right font-mono text-[9.5px] text-gray-500">
                  <span className="block font-bold text-gray-800">CÓD: ATA-LSS-{new Date().getFullYear()}-06</span>
                  <span className="block italic">CONFIDENCIAL • COMITÊ DE DIRETORIA</span>
                  <span className="block">EMISSÃO: {new Date().toLocaleDateString("pt-BR")}</span>
                </div>
              </div>
            </div>

            {/* DOCUMENT TITLE */}
            <div className="text-center space-y-2 mb-8 bg-slate-50 border border-slate-200 p-4 rounded-sm">
              <h1 className="text-xl md:text-2xl font-serif text-slate-900 font-extrabold uppercase leading-tight tracking-tight">
                {meetingTitle}
              </h1>
              <span className="h-0.5 w-16 bg-emerald-600 block mx-auto"></span>
              <p className="text-[10.5px] text-gray-500 tracking-wide font-mono italic">
                Enquadramento DMAIC: Relatório Executivo Técnico Final (Ata da Fase Control)
              </p>
            </div>

            {/* MEETING METADATA PANEL */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border border-slate-200 rounded-sm p-4 text-xs font-sans mb-8 bg-[#FAF9F6]">
              <div className="space-y-1.5">
                <p className="text-[10px] font-mono uppercase font-black tracking-wider text-slate-500">I. Detalhes Gerais da Sessão</p>
                <div className="space-y-0.5 text-gray-800">
                  <p>🗓️ <strong className="font-bold">Data/Hora:</strong> {meetingDate}</p>
                  <p>📍 <strong className="font-bold">Local:</strong> {meetingLocation}</p>
                  <p>👤 <strong className="font-bold">Coordenação LSS:</strong> {meetingLeader}</p>
                </div>
              </div>
              
              <div className="space-y-1.5">
                <p className="text-[10px] font-mono uppercase font-black tracking-wider text-slate-500">II. Membros do Conselho deliberante</p>
                <p className="text-gray-700 leading-relaxed text-justify text-[11px] font-mono">
                  {meetingParticipants}
                </p>
              </div>
            </div>

            {/* KEY METRICS STATS */}
            <div className="space-y-3 mb-8">
              <h4 className="text-xs font-mono font-extrabold text-[#1A1A1A] uppercase border-b-2 border-slate-200 pb-1 flex items-center gap-1.5">
                <Activity size={13} className="text-emerald-700" />
                III. Indicadores Chave de Processo (KPIs de Partida)
              </h4>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="border border-slate-200 p-3 rounded-xs text-center bg-white">
                  <span className="text-[8.5px] font-mono text-slate-500 uppercase font-bold block">Estabilidade Sigma</span>
                  <strong className="text-lg font-mono text-indigo-700 block mt-0.5">{stats.sigmaLevel?.toFixed(2)}σ</strong>
                  <span className="text-[9px] text-gray-400 block font-sans">Compounded LSS</span>
                </div>

                <div className="border border-slate-200 p-3 rounded-xs text-center bg-white">
                  <span className="text-[8.5px] font-mono text-slate-500 uppercase font-bold block">Fator de Rendimento (Yield)</span>
                  <strong className="text-lg font-mono text-emerald-700 block mt-0.5">{(stats.rolledFirstPassYield * 100).toFixed(1)}%</strong>
                  <span className="text-[9px] text-gray-400 block font-sans">FPP Sem Defeito</span>
                </div>

                <div className="border border-slate-200 p-3 rounded-xs text-center bg-white">
                  <span className="text-[8.5px] font-mono text-slate-500 uppercase font-bold block">Defeitos por Milhão (DPMO)</span>
                  <strong className="text-lg font-mono text-rose-700 block mt-0.5">{(stats.dpmo || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}</strong>
                  <span className="text-[9px] text-gray-400 block font-sans">Defects Per Million</span>
                </div>

                <div className="border border-slate-200 p-3 rounded-xs text-center bg-white">
                  <span className="text-[8.5px] font-mono text-slate-500 uppercase font-bold block">Eficiência de Ciclo (PCE)</span>
                  <strong className="text-lg font-mono text-amber-700 block mt-0.5">{pce_ratio.toFixed(1)}%</strong>
                  <span className="text-[9px] text-gray-400 block font-sans">Value Added Ratio</span>
                </div>
              </div>

              <p className="text-[10px] text-justify text-gray-500 font-sans leading-normal pt-1 bg-[#F9F9F9] p-2.5 rounded-sm border border-slate-150">
                🔍 <strong>Diagnóstico de Gargalo:</strong> Detecção sistemática indica que a restrição ativa da linha está estabelecida no posto <strong>[{stats.bottleneckStepName}]</strong> operando com carga teórica de <strong>{stats.systemUtilization.toFixed(0)}%</strong>. O lead-time fabril atual é de <strong>{stats.leadTime.toFixed(1)}</strong> minutos, combinando <strong>{totalVA_Time.toFixed(1)}</strong> minutos sob processamento ativo indireto.
              </p>
            </div>

            {/* CHARTS CONTAINER - SIGMA TREND & FAULT PARETO */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 page-break">
              
              {/* CHART 1: SIGMA EVOLUTION TREND */}
              <div className="border border-slate-200 rounded-sm p-4 bg-white flex flex-col justify-between">
                <div>
                  <h5 className="text-[10.5px] font-mono font-bold text-slate-800 uppercase border-b pb-1 mb-2 flex items-center gap-1">
                    <TrendingUp size={12} className="text-indigo-650" />
                    Gráfico A: Evolução Semestral do Nível Sigma
                  </h5>
                  <p className="text-[9.5px] text-gray-500 mb-4 leading-normal">
                    Registros consolidados até o presente mês de Junho demonstrando o aumento de estabilidade através da metodologia DMAIC.
                  </p>
                </div>
                
                <div className="w-full flex justify-center pb-2">
                  <LineChart width={340} height={180} data={getDossierTrendData()} margin={{ top: 10, right: 20, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="name" stroke="#6b7280" fontSize={9} />
                    <YAxis stroke="#6b7280" domain={[0, 6.5]} ticks={[0, 1.5, 3, 4.5, 6]} fontSize={9} />
                    <Tooltip contentStyle={{fontSize: 9}} />
                    <ReferenceLine y={6} stroke="#10b981" strokeDasharray="3 3" />
                    <ReferenceLine y={3} stroke="#f59e0b" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="Nível Sigma" stroke="#4F46E5" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </div>
              </div>

              {/* CHART 2: PARETO ANALYSIS OF FAILURES */}
              <div className="border border-slate-200 rounded-sm p-4 bg-white flex flex-col justify-between">
                <div>
                  <h5 className="text-[10.5px] font-mono font-bold text-slate-800 uppercase border-b pb-1 mb-2 flex items-center gap-1">
                     🔍 Gráfico B: Pareto do Histórico de Falhas (80/20)
                  </h5>
                  <p className="text-[9.5px] text-gray-500 mb-4 leading-normal">
                    Identificação de causas prioritárias acumuladoras de falhas que concentram interrupções de estabilidade de processo.
                  </p>
                </div>
                
                <div className="w-full flex justify-center pb-2">
                  <ComposedChart width={340} height={180} data={getDossierParetoData().chartData} margin={{ top: 10, right: 20, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="cause" stroke="#6b7280" fontSize={8} />
                    <YAxis yAxisId="left" stroke="#6b7280" fontSize={8} />
                    <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" domain={[0, 100]} fontSize={8} />
                    <Tooltip contentStyle={{fontSize: 9}} />
                    <Bar yAxisId="left" dataKey="count" fill="#4F46E5" barSize={12} radius={[1, 1, 0, 0]} />
                    <Line yAxisId="right" type="monotone" dataKey="percentage" stroke="#F59E0B" strokeWidth={2} dot={{ r: 3 }} />
                  </ComposedChart>
                </div>
              </div>

            </div>

            {/* RESOLUTIONS AND REACTION PLAN */}
            <div className="space-y-4 mb-8">
              <h4 className="text-xs font-mono font-extrabold text-[#1A1A1A] uppercase border-b-2 border-slate-200 pb-1 flex items-center gap-1.5">
                <FileText size={13} className="text-emerald-700" />
                IV. Deliberações e Acordos do Comitê de Qualidade
              </h4>
              
              <div className="bg-[#FAF9F6] border border-slate-200 p-4 rounded-xs whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-gray-700 text-justify">
                {meetingDeliberations}
              </div>
            </div>

            {/* ACTION ROADMAP */}
            <div className="space-y-4 mb-10 page-break">
              <h4 className="text-xs font-mono font-extrabold text-[#1A1A1A] uppercase border-b-2 border-slate-200 pb-1 flex items-center gap-1.5">
                🏆 V. Cronograma de Ações e Matriz de Responsabilidades (RACI)
              </h4>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-[10px] font-sans text-left">
                  <thead>
                    <tr className="bg-[#1A1A1A] text-white font-mono uppercase text-[9px] tracking-wider">
                      <th className="p-2 border border-slate-300"># Ação Recomendada</th>
                      <th className="p-2 border border-slate-300">Área Alvo</th>
                      <th className="p-2 border border-slate-300">Líder (R)</th>
                      <th className="p-2 border border-slate-300">Aprovador (A)</th>
                      <th className="p-2 border border-slate-300">Prazo Estimado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-gray-700">
                    <tr>
                      <td className="p-2 border border-slate-200 font-sans font-medium text-slate-900">Rebalanceamento de Carga Fabril</td>
                      <td className="p-2 border border-slate-200">{stats.bottleneckStepName}</td>
                      <td className="p-2 border border-slate-200">Engª Ana Peixoto</td>
                      <td className="p-2 border border-slate-200">Regina S.</td>
                      <td className="p-2 border border-slate-200 text-emerald-700 font-bold">Imediato</td>
                    </tr>
                    <tr>
                      <td className="p-2 border border-slate-200 font-sans font-medium text-slate-900">Sensoriamento IoT do Forno</td>
                      <td className="p-2 border border-slate-200">Refluxo Térmico</td>
                      <td className="p-2 border border-slate-200">Carlos Alberto</td>
                      <td className="p-2 border border-slate-200">Marco Antônio (MBB)</td>
                      <td className="p-2 border border-slate-200">15 Dias</td>
                    </tr>
                    <tr>
                      <td className="p-2 border border-slate-200 font-sans font-medium text-slate-900">Ajuste dos Limites UCL/LCL de Controle</td>
                      <td className="p-2 border border-slate-200">Monitoramento CEP</td>
                      <td className="p-2 border border-slate-200">Líder Controle</td>
                      <td className="p-2 border border-slate-200">Marco Antônio (MBB)</td>
                      <td className="p-2 border border-slate-200 text-emerald-700 font-bold">✓ Concluído</td>
                    </tr>
                    <tr>
                      <td className="p-2 border border-slate-200 font-sans font-medium text-slate-900">Auditoria Lean 5S e intertravamento</td>
                      <td className="p-2 border border-slate-200">Montagem Completa</td>
                      <td className="p-2 border border-slate-200 font-bold text-[10.5px]">Operações SMT</td>
                      <td className="p-2 border border-slate-200">Regina S.</td>
                      <td className="p-2 border border-slate-200">Semanal</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* SIGNATURE PAD */}
            <div className="pt-8 border-t border-slate-300">
              <p className="text-[9px] font-mono text-gray-400 text-center uppercase tracking-widest mb-10">
                VI. Assinaturas de Certificação e Validação de Conformidade LSS
              </p>
              
              <div className="grid grid-cols-2 gap-8 font-mono text-[9px] text-center">
                <div className="space-y-1">
                  <div className="h-0.5 bg-slate-400 w-4/5 mx-auto text-center"></div>
                  <strong className="block text-slate-800 text-[10px] uppercase">{meetingLeader}</strong>
                  <span className="text-gray-500 block">Coordenador do Comitê LSS</span>
                </div>

                <div className="space-y-1">
                  <div className="h-0.5 bg-slate-400 w-4/5 mx-auto text-center"></div>
                  <strong className="block text-slate-800 text-[10px] uppercase">Regina S. Albuquerque</strong>
                  <span className="text-gray-500 block">Diretora de Manufatura Executiva</span>
                </div>
              </div>
            </div>

          </div>

          {/* PRINT NOTICE INFORMATION */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 text-xs font-sans text-emerald-950 leading-relaxed rounded-xs text-left">
            🖨️ <strong>Dica de Impressão:</strong> Ao clicar em <strong>Gerar PDF / Imprimir Documento</strong>, certifique-se de habilitar as configurações do navegador de <strong>"Imprimir Gráficos de Fundo"</strong> (Background graphics) e selecionar a opção <strong>"Salvar como PDF"</strong> para exportar um relatório impecável com todos os gráficos de tendência e Pareto de alta fidelidade vetorial!
          </div>

        </div>
      )}

    </div>
  );
}
