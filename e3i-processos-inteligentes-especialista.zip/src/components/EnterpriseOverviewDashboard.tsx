import React, { useState, useMemo, useEffect } from "react";
import {
  ShieldCheck,
  Building2,
  FolderGit2,
  Clock,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Search,
  Download,
  Filter,
  BarChart3,
  Layers,
  Sparkles,
  ChevronRight,
  Zap,
  Info,
  Plus,
  X,
  Briefcase,
  Award,
  HeartPulse,
  Check,
  ExternalLink,
  PieChart as PieChartIcon,
  DollarSign,
  Users,
  Target,
  Cpu,
  FileText,
  ArrowUpRight,
  BarChart2
} from "lucide-react";
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  Cell,
  CartesianGrid,
  ReferenceLine
} from "recharts";
import { Company, WorkspaceProject, ProcessStep, ProjectCharter } from "../types";
import { useIsAdmin } from "../hooks/useIsAdmin";
import AccessDeniedBlock from "./AccessDeniedBlock";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";
import { db } from "../firebase";
import { doc, setDoc } from "firebase/firestore";

export interface EnterpriseOverviewDashboardProps {
  activeUser: any;
  currentCargo: string;
  companies: Company[];
  projects: WorkspaceProject[];
  projectDataStore: Record<string, any>;
  activeCompanyId: string | null;
  activeProjectId: string | null;
  onSelectCompany: (id: string | null) => void;
  onSelectProject: (id: string | null) => void;
  onNavigateToAdmin: () => void;
  onNavigateToProjectWorkspace?: (projectId: string, companyId: string) => void;
  onCreateProject?: (companyId: string, projectName: string, objective?: string, strategicTower?: string) => void;
  onCreateCompany?: (companyName: string, industry?: string) => void;
}

export interface EnterpriseDashboardKpiConfig {
  showSigma: boolean;       // Nível Sigma (σ)
  showLeadTime: boolean;    // Lead Time / Cycle Time
  showRolledYield: boolean; // Rolled Throughput Yield (FPY)
  showRoi: boolean;         // Impacto Financeiro (ROI)
  showHealthScore: boolean; // Índice de Saúde Operacional
}

export const DEFAULT_KPI_CONFIG: EnterpriseDashboardKpiConfig = {
  showSigma: true,
  showLeadTime: true,
  showRolledYield: true,
  showRoi: true,
  showHealthScore: true,
};

export type StrategicTowerId = "FINANCE" | "CUSTOMER" | "OPERATIONS" | "PEOPLE_INNOVATION";

interface StrategicTowerConfig {
  id: StrategicTowerId;
  title: string;
  shortTitle: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badgeColor: string;
  bgBorderClass: string;
  headerBgClass: string;
  badgeBgClass: string;
  badgeTextClass: string;
  iconColor: string;
  description: string;
  strategicGoals: string[];
}

const STRATEGIC_TOWERS: StrategicTowerConfig[] = [
  {
    id: "FINANCE",
    title: "1. Perspectiva Financeira & Valor (BSC Financeiro)",
    shortTitle: "Financeira & Valor",
    icon: DollarSign,
    badgeColor: "emerald",
    bgBorderClass: "bg-emerald-50/40 border-emerald-200/80 hover:border-emerald-300",
    headerBgClass: "bg-emerald-950 text-emerald-100 border-emerald-800",
    badgeBgClass: "bg-emerald-100",
    badgeTextClass: "text-emerald-800",
    iconColor: "text-emerald-500",
    description: "Geração de valor financeiro, redução de custos de não-qualidade, otimização de EBITDA e contenção de desperdícios.",
    strategicGoals: ["Maximização do ROI de projetos LSS", "Redução de custos operacionais diretos", "Eliminação de sobreprocessamento"]
  },
  {
    id: "CUSTOMER",
    title: "2. Perspectiva Clientes, SLA & Experiência (BSC Cliente)",
    shortTitle: "Clientes & SLA",
    icon: Users,
    badgeColor: "blue",
    bgBorderClass: "bg-blue-50/40 border-blue-200/80 hover:border-blue-300",
    headerBgClass: "bg-blue-950 text-blue-100 border-blue-800",
    badgeBgClass: "bg-blue-100",
    badgeTextClass: "text-blue-800",
    iconColor: "text-blue-500",
    description: "Cumprimento de prazos e SLAs de atendimento, melhoria do NPS, eliminação de erros ao cliente final.",
    strategicGoals: ["Redução do tempo de fila ao cliente", "Cumprimento estrito de SLA de entrega", "Erradicação de defeitos na entrega final"]
  },
  {
    id: "OPERATIONS",
    title: "3. Perspectiva Processos Internos & Operações (BSC Operações)",
    shortTitle: "Processos Internos",
    icon: Zap,
    badgeColor: "amber",
    bgBorderClass: "bg-slate-50 border-slate-200 hover:border-amber-400/80",
    headerBgClass: "bg-slate-900 text-amber-300 border-slate-800",
    badgeBgClass: "bg-amber-100",
    badgeTextClass: "text-amber-900",
    iconColor: "text-amber-500",
    description: "Estabilidade estatística de fluxo DMAIC, eliminação de gargalos, SMED, Poka-Yoke e elevação da maturidade Six Sigma.",
    strategicGoals: ["Aumento da taxa de First Pass Yield (FPY)", "Aumento da capacidade horária da linha", "Estabilização estatística da variabilidade"]
  },
  {
    id: "PEOPLE_INNOVATION",
    title: "4. Perspectiva Aprendizado, Pessoas & Inovação Tech (BSC Inovação)",
    shortTitle: "Inovação & Pessoas",
    icon: Sparkles,
    badgeColor: "purple",
    bgBorderClass: "bg-purple-50/40 border-purple-200/80 hover:border-purple-300",
    headerBgClass: "bg-purple-950 text-purple-100 border-purple-800",
    badgeBgClass: "bg-purple-100",
    badgeTextClass: "text-purple-800",
    iconColor: "text-purple-400",
    description: "Formação de Belts (Yellow/Green/Black), automação de rotinas, governança de dados e cultura de inovação.",
    strategicGoals: ["Capacitação em metodologias Lean Six Sigma", "Automação inteligente de etapas manuais", "Cultura orientada a dados e melhoria contínua"]
  }
];

interface ProjectMetrics {
  project: WorkspaceProject;
  companyName: string;
  strategicTower: StrategicTowerId;
  cycleTimeHours: number;
  targetCycleTimeHours: number;
  sigmaLevel: number;
  dpmo: number;
  yieldPercent: number;
  totalStepsCount: number;
  bottleneckName: string;
  expectedROI: number;
  status: string;
}

interface CompanyHealthSummary {
  company: Company;
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  avgCycleTime: number;
  avgTargetCycleTime: number;
  avgSigma: number;
  avgYield: number;
  avgDpmo: number;
  totalRoi: number;
  healthScore: number; // 0-100
  healthLabel: "Excelente" | "Saudável" | "Atenção" | "Crítica";
  healthColor: "emerald" | "blue" | "amber" | "red";
  mainBottleneck: string;
}

export const EnterpriseOverviewDashboard: React.FC<EnterpriseOverviewDashboardProps> = ({
  activeUser,
  currentCargo,
  companies,
  projects,
  projectDataStore,
  activeCompanyId,
  activeProjectId,
  onSelectCompany,
  onSelectProject,
  onNavigateToAdmin,
  onNavigateToProjectWorkspace,
  onCreateProject,
  onCreateCompany
}) => {
  // Check Administrator authorization
  const isAdmin = useIsAdmin(activeUser, currentCargo);

  // Active Company Selection for dashboard filtering
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState<string>(activeCompanyId || "ALL");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>(" ");

  // Modals state
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [isNewCompanyModalOpen, setIsNewCompanyModalOpen] = useState(false);
  const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
  const [selectedProjectForDetails, setSelectedProjectForDetails] = useState<ProjectMetrics | null>(null);

  // Enterprise Dashboard KPI Configuration state (local storage + Firestore backed)
  const [kpiConfig, setKpiConfig] = useState<EnterpriseDashboardKpiConfig>(() => {
    try {
      const saved = localStorage.getItem("enterprise_dashboard_kpi_config");
      if (saved) {
        return { ...DEFAULT_KPI_CONFIG, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn("Failed to load enterprise KPI config from localStorage:", e);
    }
    return DEFAULT_KPI_CONFIG;
  });

  // Sync kpiConfig state when selected company filter, active company, or companies list updates from Firestore
  useEffect(() => {
    const targetCompId = selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : activeCompanyId;
    if (targetCompId) {
      const comp = companies.find(c => c.id === targetCompId);
      if (comp && comp.kpiConfig) {
        setKpiConfig({ ...DEFAULT_KPI_CONFIG, ...comp.kpiConfig });
        return;
      }
    } else if (companies.length > 0) {
      const firstWithConfig = companies.find(c => c.kpiConfig);
      if (firstWithConfig && firstWithConfig.kpiConfig) {
        setKpiConfig({ ...DEFAULT_KPI_CONFIG, ...firstWithConfig.kpiConfig });
        return;
      }
    }
  }, [selectedCompanyFilter, activeCompanyId, companies]);

  const handleUpdateKpiConfig = async (newConfig: EnterpriseDashboardKpiConfig) => {
    setKpiConfig(newConfig);
    try {
      localStorage.setItem("enterprise_dashboard_kpi_config", JSON.stringify(newConfig));
    } catch (e) {
      console.warn("Failed to save enterprise KPI config to localStorage:", e);
    }

    // Persist to Firestore & CompanyProjectRepository for selected company or all companies
    const targetCompId = selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : activeCompanyId;
    const targetCompanies = targetCompId 
      ? companies.filter(c => c.id === targetCompId)
      : companies;

    if (companies.length > 0) {
      const updatedCompanies = companies.map(c => {
        if (!targetCompId || c.id === targetCompId) {
          return { ...c, kpiConfig: newConfig };
        }
        return c;
      });

      // Update in-memory repository cache & local storage & trigger listeners
      CompanyProjectRepository.saveCompanies(updatedCompanies);

      // Directly update company documents in Firestore for instant cloud persistence
      try {
        for (const comp of targetCompanies) {
          const companyRef = doc(db, "companies", comp.id);
          await setDoc(companyRef, { kpiConfig: newConfig }, { merge: true });
        }
      } catch (err) {
        console.warn("[EnterpriseOverviewDashboard] Error saving kpiConfig directly to Firestore:", err);
      }
    }
  };

  const handleToggleSingleKpi = (key: keyof EnterpriseDashboardKpiConfig) => {
    const updated = { ...kpiConfig, [key]: !kpiConfig[key] };
    handleUpdateKpiConfig(updated);
  };

  const handleResetKpiConfig = () => {
    handleUpdateKpiConfig(DEFAULT_KPI_CONFIG);
    showNotification("Configurações de KPIs restauradas para os valores padrão.");
  };

  // New Project Form state
  const [newProjectCompanyId, setNewProjectCompanyId] = useState<string>("");
  const [newProjectTower, setNewProjectTower] = useState<StrategicTowerId>("OPERATIONS");
  const [newProjectName, setNewProjectName] = useState<string>("");
  const [newProjectObjective, setNewProjectObjective] = useState<string>("");
  const [newProjectTargetCycleTime, setNewProjectTargetCycleTime] = useState<number>(24);
  const [openWorkspaceImmediately, setOpenWorkspaceImmediately] = useState<boolean>(true);

  // New Company Form state
  const [newCompanyName, setNewCompanyName] = useState<string>("");
  const [newCompanyIndustry, setNewCompanyIndustry] = useState<string>("Serviços & Operações");
  const [newCompanyCnpj, setNewCompanyCnpj] = useState<string>("");

  // Feedback notifications
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotificationMsg(msg);
    setTimeout(() => {
      setNotificationMsg(null);
    }, 4000);
  };

  // Helper to resolve Strategic Tower for a project
  const resolveProjectTower = (proj: WorkspaceProject): StrategicTowerId => {
    if (proj.strategicTower) {
      const t = proj.strategicTower.toUpperCase();
      if (t === "FINANCE" || t.includes("FINAN")) return "FINANCE";
      if (t === "CUSTOMER" || t.includes("CLIENT")) return "CUSTOMER";
      if (t === "OPERATIONS" || t.includes("OPER")) return "OPERATIONS";
      if (t === "PEOPLE_INNOVATION" || t.includes("INOV") || t.includes("PESSO")) return "PEOPLE_INNOVATION";
    }

    const text = `${proj.name} ${proj.objective || ""}`.toLowerCase();
    if (text.includes("custo") || text.includes("margem") || text.includes("financei") || text.includes("ebitda") || text.includes("desperdíc") || text.includes("roi")) {
      return "FINANCE";
    }
    if (text.includes("cliente") || text.includes("sla") || text.includes("nps") || text.includes("atendimento") || text.includes("prazo") || text.includes("sac")) {
      return "CUSTOMER";
    }
    if (text.includes("automa") || text.includes("treina") || text.includes("belt") || text.includes("ia") || text.includes("capacita") || text.includes("inov")) {
      return "PEOPLE_INNOVATION";
    }
    return "OPERATIONS";
  };

  // Helper to compute metrics per project
  const computedProjectMetrics = useMemo<ProjectMetrics[]>(() => {
    return projects.map((proj) => {
      const company = companies.find((c) => c.id === proj.companyId);
      const companyName = company?.name || "Empresa Não Especificada";

      const storeData = projectDataStore[proj.id] || {};
      const steps: ProcessStep[] = storeData.steps || [];
      const charter: ProjectCharter | undefined = storeData.charter;

      const strategicTower = resolveProjectTower(proj);

      // Cycle Time Calculation (sum of processingTime + queueTime in hours)
      let calculatedCycleTime = 0;
      let bottleneck = "Análise de Entrada";
      let maxStepTime = 0;

      if (steps.length > 0) {
        let totalMinutes = 0;
        steps.forEach((st) => {
          const pTime = st.processingTime || 10;
          const wTime = st.queueTime || st.setupTime || 5;
          const stepTotal = pTime + wTime;
          totalMinutes += stepTotal;

          if (stepTotal > maxStepTime) {
            maxStepTime = stepTotal;
            bottleneck = st.name || `Etapa #${st.id}`;
          }
        });
        calculatedCycleTime = Number((totalMinutes / 60).toFixed(1));
      } else {
        const hash = proj.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
        calculatedCycleTime = Number(((hash % 30) + 10).toFixed(1));
        bottleneck = "Fila de Triagem";
      }

      // Target cycle time calculation
      const targetCycleTime = charter?.targetValue
        ? Number(charter.targetValue)
        : Number((calculatedCycleTime * 0.8).toFixed(1));

      // Sigma Level & DPMO calculation
      let calculatedSigma = 3.8;
      let calculatedDpmo = 10000;
      let yieldPct = 95.0;

      if (steps.length > 0) {
        let totalDefectRate = 0;
        steps.forEach((st) => {
          const yRate = st.yieldRate !== undefined ? st.yieldRate : 0.95;
          const errRate = Math.max(0.001, 1 - yRate);
          totalDefectRate += errRate;
        });
        const avgDefectRate = Math.min(0.3, Math.max(0.001, totalDefectRate / steps.length));
        yieldPct = Number(((1 - avgDefectRate) * 100).toFixed(1));
        calculatedDpmo = Math.round(avgDefectRate * 1000000);

        if (avgDefectRate <= 0.0000034) calculatedSigma = 6.0;
        else if (avgDefectRate <= 0.00023) calculatedSigma = 5.0;
        else if (avgDefectRate <= 0.0062) calculatedSigma = 4.0;
        else if (avgDefectRate <= 0.0668) calculatedSigma = 3.0;
        else if (avgDefectRate <= 0.3085) calculatedSigma = 2.0;
        else calculatedSigma = 1.5;

        const logFactor = -Math.log10(avgDefectRate);
        calculatedSigma = Number((1.5 + logFactor * 0.95).toFixed(2));
        calculatedSigma = Math.min(6.0, Math.max(1.5, calculatedSigma));
      } else {
        const hash = proj.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
        calculatedSigma = Number((3.4 + (hash % 20) / 10).toFixed(2));
        calculatedDpmo = Math.round((1 - calculatedSigma / 6) * 40000);
        yieldPct = Number((88 + (calculatedSigma / 6) * 11).toFixed(1));
      }

      // ROI / Financial impact
      let expectedROI = 150000;
      if (charter?.goal || charter?.problemStatement) {
        const text = `${charter.goal || ""} ${charter.problemStatement || ""}`;
        const match = text.match(/\d[\d\.\,]*/);
        if (match) {
          const parsed = parseFloat(match[0].replace(/\./g, "").replace(",", "."));
          if (!isNaN(parsed) && parsed > 0) expectedROI = parsed;
        }
      } else {
        const hash = proj.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
        expectedROI = 100000 + (hash % 15) * 25000;
      }

      return {
        project: proj,
        companyName,
        strategicTower,
        cycleTimeHours: calculatedCycleTime,
        targetCycleTimeHours: targetCycleTime,
        sigmaLevel: calculatedSigma,
        dpmo: calculatedDpmo,
        yieldPercent: yieldPct,
        totalStepsCount: steps.length,
        bottleneckName: bottleneck,
        expectedROI,
        status: proj.status || "Em Andamento"
      };
    });
  }, [projects, companies, projectDataStore]);

  // Compute Health per Company
  const companyHealthList = useMemo<CompanyHealthSummary[]>(() => {
    return companies.map((comp) => {
      const compProjects = computedProjectMetrics.filter((m) => m.project.companyId === comp.id);
      const totalProjects = compProjects.length;
      const activeProjects = compProjects.filter((m) => m.status === "Em Andamento").length;
      const completedProjects = compProjects.filter((m) => m.status === "Concluído").length;

      if (totalProjects === 0) {
        return {
          company: comp,
          totalProjects: 0,
          activeProjects: 0,
          completedProjects: 0,
          avgCycleTime: 0,
          avgTargetCycleTime: 0,
          avgSigma: 3.5,
          avgYield: 95.0,
          avgDpmo: 10000,
          totalRoi: 0,
          healthScore: 75,
          healthLabel: "Saudável",
          healthColor: "blue",
          mainBottleneck: "Sem processos cadastrados"
        };
      }

      const sumCt = compProjects.reduce((acc, m) => acc + m.cycleTimeHours, 0);
      const sumTargetCt = compProjects.reduce((acc, m) => acc + m.targetCycleTimeHours, 0);
      const avgCycleTime = Number((sumCt / totalProjects).toFixed(1));
      const avgTargetCycleTime = Number((sumTargetCt / totalProjects).toFixed(1));

      const sumSigma = compProjects.reduce((acc, m) => acc + m.sigmaLevel, 0);
      const avgSigma = Number((sumSigma / totalProjects).toFixed(2));

      const sumYield = compProjects.reduce((acc, m) => acc + m.yieldPercent, 0);
      const avgYield = Number((sumYield / totalProjects).toFixed(1));

      const sumDpmo = compProjects.reduce((acc, m) => acc + m.dpmo, 0);
      const avgDpmo = Math.round(sumDpmo / totalProjects);

      const totalRoi = compProjects.reduce((acc, m) => acc + m.expectedROI, 0);

      // Bottleneck occurrence
      const bottleneckCounts: Record<string, number> = {};
      compProjects.forEach((m) => {
        if (m.bottleneckName && m.bottleneckName !== "Não Mapeado") {
          bottleneckCounts[m.bottleneckName] = (bottleneckCounts[m.bottleneckName] || 0) + 1;
        }
      });
      let mainBottleneck = "Aguardando mapeamento de fluxo";
      let maxBCount = 0;
      Object.entries(bottleneckCounts).forEach(([bName, count]) => {
        if (count > maxBCount) {
          maxBCount = count;
          mainBottleneck = bName;
        }
      });

      // Health Score Calculation (0-100)
      const sigmaPoints = (avgSigma / 6.0) * 45;
      const yieldPoints = (avgYield / 100) * 35;
      const ctVariance = avgTargetCycleTime > 0 ? ((avgCycleTime - avgTargetCycleTime) / avgTargetCycleTime) * 100 : 0;
      const ctPoints = ctVariance <= 0 ? 20 : Math.max(0, 20 - ctVariance * 0.3);

      const healthScore = Math.min(100, Math.round(sigmaPoints + yieldPoints + ctPoints));

      let healthLabel: "Excelente" | "Saudável" | "Atenção" | "Crítica" = "Saudável";
      let healthColor: "emerald" | "blue" | "amber" | "red" = "blue";

      if (healthScore >= 88) {
        healthLabel = "Excelente";
        healthColor = "emerald";
      } else if (healthScore >= 75) {
        healthLabel = "Saudável";
        healthColor = "blue";
      } else if (healthScore >= 60) {
        healthLabel = "Atenção";
        healthColor = "amber";
      } else {
        healthLabel = "Crítica";
        healthColor = "red";
      }

      return {
        company: comp,
        totalProjects,
        activeProjects,
        completedProjects,
        avgCycleTime,
        avgTargetCycleTime,
        avgSigma,
        avgYield,
        avgDpmo,
        totalRoi,
        healthScore,
        healthLabel,
        healthColor,
        mainBottleneck
      };
    });
  }, [companies, computedProjectMetrics]);

  // Selected Company Object & Health
  const currentSelectedCompanyHealth = useMemo(() => {
    if (selectedCompanyFilter === "ALL") return null;
    return companyHealthList.find((c) => c.company.id === selectedCompanyFilter) || null;
  }, [selectedCompanyFilter, companyHealthList]);

  // Filtered dataset for projects
  const filteredMetrics = useMemo(() => {
    return computedProjectMetrics.filter((item) => {
      // Company Filter
      if (selectedCompanyFilter !== "ALL" && item.project.companyId !== selectedCompanyFilter) {
        return false;
      }
      // Status Filter
      if (statusFilter !== "ALL" && item.status !== statusFilter) {
        return false;
      }
      // Search Query
      if (searchQuery.trim() !== "") {
        const q = searchQuery.toLowerCase();
        const matchesName = item.project.name.toLowerCase().includes(q);
        const matchesComp = item.companyName.toLowerCase().includes(q);
        const matchesObjective = (item.project.objective || "").toLowerCase().includes(q);
        if (!matchesName && !matchesComp && !matchesObjective) return false;
      }
      return true;
    });
  }, [computedProjectMetrics, selectedCompanyFilter, statusFilter, searchQuery]);

  // Aggregated KPIs
  const portfolioSummary = useMemo(() => {
    if (filteredMetrics.length === 0) {
      return {
        totalProjects: 0,
        activeProjectsCount: 0,
        completedProjectsCount: 0,
        avgCycleTime: 0,
        avgTargetCycleTime: 0,
        cycleTimeVariance: 0,
        avgSigma: 0,
        avgDpmo: 0,
        avgYield: 0,
        totalRoi: 0,
        healthScore: 75,
        healthLabel: "Saudável" as const,
        sigmaBandCounts: { critical: 0, acceptable: 0, advanced: 0, worldClass: 0 }
      };
    }

    const totalProjects = filteredMetrics.length;
    const activeProjectsCount = filteredMetrics.filter((m) => m.status === "Em Andamento").length;
    const completedProjectsCount = filteredMetrics.filter((m) => m.status === "Concluído").length;

    const sumCycleTime = filteredMetrics.reduce((acc, m) => acc + m.cycleTimeHours, 0);
    const sumTargetCycleTime = filteredMetrics.reduce((acc, m) => acc + m.targetCycleTimeHours, 0);
    const avgCycleTime = Number((sumCycleTime / totalProjects).toFixed(1));
    const avgTargetCycleTime = Number((sumTargetCycleTime / totalProjects).toFixed(1));

    const cycleTimeVariance = avgTargetCycleTime > 0
      ? Number((((avgCycleTime - avgTargetCycleTime) / avgTargetCycleTime) * 100).toFixed(1))
      : 0;

    const sumSigma = filteredMetrics.reduce((acc, m) => acc + m.sigmaLevel, 0);
    const avgSigma = Number((sumSigma / totalProjects).toFixed(2));

    const sumDpmo = filteredMetrics.reduce((acc, m) => acc + m.dpmo, 0);
    const avgDpmo = Math.round(sumDpmo / totalProjects);

    const sumYield = filteredMetrics.reduce((acc, m) => acc + m.yieldPercent, 0);
    const avgYield = Number((sumYield / totalProjects).toFixed(1));

    const totalRoi = filteredMetrics.reduce((acc, m) => acc + m.expectedROI, 0);

    const sigmaBandCounts = {
      critical: filteredMetrics.filter((m) => m.sigmaLevel < 3.0).length,
      acceptable: filteredMetrics.filter((m) => m.sigmaLevel >= 3.0 && m.sigmaLevel < 4.0).length,
      advanced: filteredMetrics.filter((m) => m.sigmaLevel >= 4.0 && m.sigmaLevel < 5.0).length,
      worldClass: filteredMetrics.filter((m) => m.sigmaLevel >= 5.0).length
    };

    const sigmaPoints = (avgSigma / 6.0) * 45;
    const yieldPoints = (avgYield / 100) * 35;
    const ctPoints = cycleTimeVariance <= 0 ? 20 : Math.max(0, 20 - cycleTimeVariance * 0.3);
    const healthScore = Math.min(100, Math.round(sigmaPoints + yieldPoints + ctPoints));

    let healthLabel: "Excelente" | "Saudável" | "Atenção" | "Crítica" = "Saudável";
    if (healthScore >= 88) healthLabel = "Excelente";
    else if (healthScore >= 75) healthLabel = "Saudável";
    else if (healthScore >= 60) healthLabel = "Atenção";
    else healthLabel = "Crítica";

    return {
      totalProjects,
      activeProjectsCount,
      completedProjectsCount,
      avgCycleTime,
      avgTargetCycleTime,
      cycleTimeVariance,
      avgSigma,
      avgDpmo,
      avgYield,
      totalRoi,
      healthScore,
      healthLabel,
      sigmaBandCounts
    };
  }, [filteredMetrics]);

  // Handle Project Creation
  const handleCreateNewProjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetCompId = newProjectCompanyId || (selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : companies[0]?.id);

    if (!targetCompId) {
      alert("Por favor, selecione uma empresa para o projeto.");
      return;
    }
    if (!newProjectName.trim()) {
      alert("Por favor, digite o nome do projeto/processo.");
      return;
    }

    const pid = "proj_" + Math.random().toString(36).substring(2, 8);
    const targetCompanyObj = companies.find((c) => c.id === targetCompId);

    const newProjObj: WorkspaceProject = {
      id: pid,
      companyId: targetCompId,
      name: newProjectName.trim(),
      objective: newProjectObjective.trim() || "Mapeamento DMAIC e otimização de capacidade operacional.",
      status: "Em Andamento",
      createdAt: new Date().toISOString(),
      strategicTower: newProjectTower
    };

    // Save project in repository
    const userEmail = activeUser?.email;
    const existingProjects = CompanyProjectRepository.getProjects(userEmail);
    CompanyProjectRepository.saveProjects([...existingProjects, newProjObj], userEmail);

    // Save initial datastore for project
    const existingStore = { ...CompanyProjectRepository.getProjectDataStore(userEmail) };
    existingStore[pid] = {
      steps: [
        {
          id: "step_init_1",
          name: "Entrada e Triagem do Processo",
          resource: "Operador / Analista",
          resourceCount: 1,
          processingTime: 12,
          standardDeviation: 2.0,
          setupTime: 3,
          yieldRate: 0.96
        },
        {
          id: "step_init_2",
          name: "Execução Principal do Fluxo",
          resource: "Sistema / Equipe",
          resourceCount: 2,
          processingTime: 28,
          standardDeviation: 4.5,
          setupTime: 5,
          yieldRate: 0.94
        }
      ],
      arrivalRate: 5,
      charter: {
        id: "char_" + pid,
        title: newProjectName.trim(),
        problemStatement: newProjectObjective.trim() || "Variabilidade e atraso no tempo de resposta identificado.",
        goal: "Estabilizar o processo e atingir nível de qualidade Six Sigma na torre de " + newProjectTower,
        metric: "cycle_time",
        targetValue: newProjectTargetCycleTime || 20
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(existingStore, userEmail);

    if (onCreateProject) {
      onCreateProject(targetCompId, newProjectName.trim(), newProjectObjective.trim(), newProjectTower);
    }

    setIsNewProjectModalOpen(false);
    setNewProjectName("");
    setNewProjectObjective("");

    showNotification(`Projeto "${newProjObj.name}" criado com sucesso em ${targetCompanyObj?.name || "Empresa"}!`);

    if (openWorkspaceImmediately) {
      onSelectCompany(targetCompId);
      onSelectProject(pid);
      if (onNavigateToProjectWorkspace) {
        onNavigateToProjectWorkspace(pid, targetCompId);
      }
    } else {
      setSelectedCompanyFilter(targetCompId);
    }
  };

  // Handle Company Creation
  const handleCreateNewCompanySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompanyName.trim()) {
      alert("Por favor, informe o nome da empresa.");
      return;
    }

    const cid = "comp_" + Math.random().toString(36).substring(2, 8);
    const newCompObj: Company = {
      id: cid,
      name: newCompanyName.trim(),
      industry: newCompanyIndustry || "Serviços & Operações",
      cnpj: newCompanyCnpj.trim() || "00.000.000/0001-00",
      createdAt: new Date().toISOString()
    };

    const userEmail = activeUser?.email;
    const existingCompanies = CompanyProjectRepository.getCompanies(userEmail);
    CompanyProjectRepository.saveCompanies([...existingCompanies, newCompObj], userEmail);

    if (onCreateCompany) {
      onCreateCompany(newCompanyName.trim(), newCompanyIndustry);
    }

    setIsNewCompanyModalOpen(false);
    setNewCompanyName("");
    setNewCompanyCnpj("");

    setSelectedCompanyFilter(cid);
    onSelectCompany(cid);
    showNotification(`Empresa "${newCompObj.name}" cadastrada com sucesso!`);
  };

  // Open workspace helper
  const handleOpenProjectWorkspace = (projectId: string, companyId: string) => {
    onSelectCompany(companyId);
    onSelectProject(projectId);
    if (onNavigateToProjectWorkspace) {
      onNavigateToProjectWorkspace(projectId, companyId);
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    const headers = ["ID", "Projeto", "Empresa", "Torre Estrategica", "Status", "Cycle Time (h)", "Meta Cycle Time (h)", "Nivel Sigma (σ)", "DPMO", "Yield (%)", "Gargalo", "ROI Estimado (R$)"];
    const rows = filteredMetrics.map((m) => [
      m.project.id,
      `"${m.project.name.replace(/"/g, '""')}"`,
      `"${m.companyName.replace(/"/g, '""')}"`,
      m.strategicTower,
      m.status,
      m.cycleTimeHours,
      m.targetCycleTimeHours,
      m.sigmaLevel,
      m.dpmo,
      m.yieldPercent,
      `"${m.bottleneckName.replace(/"/g, '""')}"`,
      m.expectedROI
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Enterprise_Overview_BSC_Report_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // If user is not an administrator, render access restriction card
  if (!isAdmin) {
    return (
      <AccessDeniedBlock
        moduleName="Painel Visão Geral Corporativa (Enterprise Overview)"
        userRole={currentCargo || activeUser?.role || "Usuário Não-Admin"}
        requiredRoles={["Administrador", "Diretoria LSS", "Master Black Belt"]}
        onNavigateToAdmin={onNavigateToAdmin}
      />
    );
  }

  return (
    <div className="space-y-8 animate-fade-in text-left p-4 md:p-6 bg-[#FAF9F6] min-h-screen border border-slate-200 shadow-3xs" id="enterprise-overview-container">
      
      {/* NOTIFICATION TOAST */}
      {notificationMsg && (
        <div className="fixed top-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-lg shadow-xl border border-amber-400/50 flex items-center gap-3 animate-slide-down">
          <Sparkles size={18} className="text-amber-400 shrink-0" />
          <span className="text-xs font-sans font-medium">{notificationMsg}</span>
          <button onClick={() => setNotificationMsg(null)} className="text-slate-400 hover:text-white ml-2">
            <X size={14} />
          </button>
        </div>
      )}

      {/* HEADER BAR */}
      <div className="border-b border-slate-200 pb-6 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[9.5px] font-mono font-bold uppercase tracking-widest bg-slate-900 text-amber-400 px-2.5 py-0.5 rounded-xs flex items-center gap-1.5 shadow-2xs">
              <ShieldCheck size={12} className="text-amber-400" />
              Painel Exclusivo de Gestão Corporativa
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              Sincronizado via Firestore em tempo real
            </span>
          </div>
          <h1 className="text-3xl font-serif font-black text-slate-900 tracking-tight flex items-center gap-3">
            <Building2 className="text-[#C49746] shrink-0" size={32} />
            Visão Geral Corporativa & Saúde das Empresas (BSC)
          </h1>
          <p className="text-xs text-slate-600 font-sans mt-1 max-w-3xl leading-relaxed">
            Selecione uma empresa para visualizar o consolidado estratégico de saúde operacional, desdobrado nas 4 torres do Balanced Scorecard (BSC). Acesse e trabalhe diretamente nos projetos vinculados ou crie novos fluxos por torre.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setNewProjectCompanyId(selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : companies[0]?.id || "");
              setIsNewProjectModalOpen(true);
            }}
            className="bg-[#C49746] hover:bg-[#a67c33] text-white px-4 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
          >
            <Plus size={15} />
            + Novo Projeto / Processo
          </button>
          
          <button
            onClick={() => setIsNewCompanyModalOpen(true)}
            className="bg-slate-800 hover:bg-slate-900 text-white px-3.5 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-2 shadow-2xs transition-all cursor-pointer"
          >
            <Building2 size={14} className="text-amber-400" />
            + Nova Empresa
          </button>

          <button
            onClick={() => setIsConfigPanelOpen(true)}
            className="bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 px-3.5 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-2 shadow-3xs transition-all cursor-pointer"
            title="Enterprise Dashboard Configuration - Personalizar visualização de KPIs"
          >
            <Sliders size={14} className="text-[#C49746]" />
            Configurar KPIs
          </button>

          <button
            onClick={handleExportCSV}
            className="bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 px-3.5 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-2 shadow-3xs transition-all cursor-pointer"
            title="Exportar dados agregados em formato CSV"
          >
            <Download size={14} className="text-[#C49746]" />
            Exportar CSV
          </button>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAMADA 1: CAMADA DE ESCOLHA DA EMPRESA                        */}
      {/* ------------------------------------------------------------- */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-mono font-bold text-slate-700 uppercase tracking-widest flex items-center gap-2">
            <Building2 size={16} className="text-[#C49746]" />
            1. SELEÇÃO DE EMPRESA / UNIDADE CORPORATIVA
          </h2>
          <span className="text-xs text-slate-500 font-sans">
            {companies.length} empresa(s) no ecossistema
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          
          {/* Card: TODAS AS EMPRESAS */}
          <div
            onClick={() => {
              setSelectedCompanyFilter("ALL");
              onSelectCompany(null);
            }}
            className={`p-4 rounded-lg border transition-all cursor-pointer flex flex-col justify-between ${
              selectedCompanyFilter === "ALL"
                ? "bg-slate-900 text-white border-amber-400 ring-2 ring-amber-400/30 shadow-md"
                : "bg-white text-slate-800 border-slate-200 hover:border-slate-300 hover:shadow-2xs"
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[9.5px] font-mono font-bold uppercase px-2 py-0.5 rounded-xs ${
                  selectedCompanyFilter === "ALL" ? "bg-amber-400 text-slate-950" : "bg-slate-100 text-slate-600"
                }`}>
                  Consolidado Global
                </span>
                <PieChartIcon size={16} className={selectedCompanyFilter === "ALL" ? "text-amber-400" : "text-slate-400"} />
              </div>
              <h3 className="font-serif font-black text-sm tracking-tight mb-1">
                Todas as Empresas
              </h3>
              <p className={`text-[11px] font-sans ${selectedCompanyFilter === "ALL" ? "text-slate-300" : "text-slate-500"}`}>
                Consolidação de todo o portfólio e torres operacionais.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200/20 flex items-center justify-between text-xs font-mono">
              <span>{computedProjectMetrics.length} Processos</span>
              <span className="font-bold text-amber-400">{portfolioSummary.avgSigma}σ Médio</span>
            </div>
          </div>

          {/* Cards for Individual Companies */}
          {companyHealthList.map((ch) => {
            const isSelected = selectedCompanyFilter === ch.company.id;
            
            return (
              <div
                key={ch.company.id}
                onClick={() => {
                  setSelectedCompanyFilter(ch.company.id);
                  onSelectCompany(ch.company.id);
                }}
                className={`p-4 rounded-lg border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                  isSelected
                    ? "bg-slate-900 text-white border-amber-400 ring-2 ring-amber-400/30 shadow-md"
                    : "bg-white text-slate-800 border-slate-200 hover:border-slate-400 hover:shadow-2xs"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-xs flex items-center gap-1 ${
                      ch.healthColor === "emerald"
                        ? "bg-emerald-100 text-emerald-800"
                        : ch.healthColor === "blue"
                        ? "bg-blue-100 text-blue-800"
                        : ch.healthColor === "amber"
                        ? "bg-amber-100 text-amber-800"
                        : "bg-red-100 text-red-800"
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        ch.healthColor === "emerald" ? "bg-emerald-500" : ch.healthColor === "blue" ? "bg-blue-500" : ch.healthColor === "amber" ? "bg-amber-500" : "bg-red-500"
                      }`} />
                      Saúde {ch.healthLabel} ({ch.healthScore}%)
                    </span>
                    <Building2 size={16} className={isSelected ? "text-amber-400" : "text-slate-400"} />
                  </div>

                  <h3 className="font-serif font-bold text-sm tracking-tight truncate" title={ch.company.name}>
                    {ch.company.name}
                  </h3>
                  <p className={`text-[10px] font-mono mt-0.5 truncate ${isSelected ? "text-slate-300" : "text-slate-500"}`}>
                    {ch.company.industry || "Serviços & Indústria"}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/20 flex items-center justify-between text-xs font-mono">
                  <span className={isSelected ? "text-slate-300" : "text-slate-600"}>
                    {ch.totalProjects} {ch.totalProjects === 1 ? "projeto" : "projetos"}
                  </span>
                  <span className="font-bold text-emerald-500">
                    {ch.avgSigma}σ
                  </span>
                </div>
              </div>
            );
          })}

          {/* Card: ADICIONAR NOVA EMPRESA */}
          <div
            onClick={() => setIsNewCompanyModalOpen(true)}
            className="p-4 rounded-lg border border-dashed border-slate-300 hover:border-[#C49746] bg-slate-50/50 hover:bg-amber-50/30 transition-all cursor-pointer flex flex-col items-center justify-center text-center group min-h-[120px]"
          >
            <div className="w-8 h-8 rounded-full bg-slate-200 group-hover:bg-[#C49746] group-hover:text-white text-slate-600 flex items-center justify-center transition-all mb-2">
              <Plus size={18} />
            </div>
            <span className="text-xs font-serif font-bold text-slate-800 group-hover:text-[#C49746]">
              Cadastrar Nova Empresa
            </span>
            <span className="text-[10px] font-mono text-slate-500 mt-0.5">
              Adicionar ao ecossistema
            </span>
          </div>

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAMADA 2: DIAGNÓSTICO E CONSOLIDADO ESTRATÉGICO DA EMPRESA    */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 md:p-6 shadow-3xs space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-100 text-amber-900 px-2 py-0.5 rounded-xs">
                {currentSelectedCompanyHealth ? "Empresa Selecionada" : "Consolidação Geral do Ecossistema"}
              </span>
              {currentSelectedCompanyHealth?.company.cnpj && (
                <span className="text-[10px] font-mono text-slate-400">
                  CNPJ: {currentSelectedCompanyHealth.company.cnpj}
                </span>
              )}
            </div>
            <h2 className="text-2xl font-serif font-black text-slate-900 mt-1 flex items-center gap-2">
              <HeartPulse className="text-red-500 shrink-0" size={24} />
              Saúde Estratégica & Consolidado da Empresa
              {currentSelectedCompanyHealth && (
                <span className="text-amber-700 font-normal">
                  - {currentSelectedCompanyHealth.company.name}
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500 font-sans mt-0.5">
              Diagnóstico consolidado de maturidade Six Sigma, tempo de ciclo e ROI de projetos para a empresa.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsConfigPanelOpen(true)}
              className="bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 px-3.5 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-2 shadow-3xs transition-all cursor-pointer"
              title="Enterprise Dashboard Configuration - Escolher quais KPIs exibir"
            >
              <Sliders size={14} className="text-[#C49746]" />
              Configurar KPIs
            </button>

            <button
              onClick={() => {
                setNewProjectCompanyId(selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : companies[0]?.id || "");
                setIsNewProjectModalOpen(true);
              }}
              className="bg-slate-900 hover:bg-black text-white px-3.5 py-2 rounded-md text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer shadow-3xs"
            >
              <Plus size={14} className="text-amber-400" />
              + Criar Projeto para {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.company.name : "Esta Empresa"}
            </button>
          </div>
        </div>

        {/* HERO HEALTH KPIS */}
        {(!kpiConfig.showHealthScore && !kpiConfig.showSigma && !kpiConfig.showLeadTime && !kpiConfig.showRolledYield && !kpiConfig.showRoi) ? (
          <div className="p-6 bg-slate-50 border border-dashed border-slate-300 rounded-lg text-center space-y-2">
            <Sliders size={24} className="mx-auto text-slate-400" />
            <h4 className="font-serif font-bold text-sm text-slate-800">
              Nenhum KPI de performance selecionado para exibição.
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Utilize o painel "Enterprise Dashboard Configuration" para escolher quais indicadores estatísticos e de negócio (Sigma, Lead Time, Rolled Yield, ROI) deseja visualizar.
            </p>
            <button
              onClick={() => setIsConfigPanelOpen(true)}
              className="mt-2 bg-[#C49746] hover:bg-[#a67c33] text-white px-4 py-1.5 rounded text-xs font-mono font-bold inline-flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Sliders size={13} />
              Configurar Exibição de KPIs
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            
            {/* 1. Health Index Score */}
            {kpiConfig.showHealthScore && (
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>Índice de Saúde Operacional</span>
                  <Activity size={16} className="text-amber-600" />
                </div>
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl font-serif font-black text-slate-900">
                    {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.healthScore : portfolioSummary.healthScore}%
                  </span>
                  <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-xs ${
                    (currentSelectedCompanyHealth?.healthScore || portfolioSummary.healthScore) >= 88
                      ? "bg-emerald-100 text-emerald-800"
                      : (currentSelectedCompanyHealth?.healthScore || portfolioSummary.healthScore) >= 75
                      ? "bg-blue-100 text-blue-800"
                      : "bg-amber-100 text-amber-800"
                  }`}>
                    {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.healthLabel : portfolioSummary.healthLabel}
                  </span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      (currentSelectedCompanyHealth?.healthScore || portfolioSummary.healthScore) >= 88
                        ? "bg-emerald-500"
                        : (currentSelectedCompanyHealth?.healthScore || portfolioSummary.healthScore) >= 75
                        ? "bg-blue-500"
                        : "bg-amber-500"
                    }`}
                    style={{ width: `${currentSelectedCompanyHealth ? currentSelectedCompanyHealth.healthScore : portfolioSummary.healthScore}%` }}
                  />
                </div>
              </div>
            )}

            {/* 2. Maturidade Sigma */}
            {kpiConfig.showSigma && (
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>Maturidade Six Sigma</span>
                  <Award size={16} className="text-emerald-600" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-serif font-black text-slate-900">
                    {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.avgSigma : portfolioSummary.avgSigma}σ
                  </span>
                </div>
                <p className="text-[10.5px] text-slate-500 font-sans pt-1">
                  DPMO Médio: <strong>{(currentSelectedCompanyHealth ? currentSelectedCompanyHealth.avgDpmo : portfolioSummary.avgDpmo).toLocaleString("pt-BR")}</strong>
                </p>
              </div>
            )}

            {/* 3. Cycle Time / Lead Time Desempenho */}
            {kpiConfig.showLeadTime && (
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>Lead Time / Cycle Time Médio</span>
                  <Clock size={16} className="text-blue-600" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-serif font-black text-slate-900">
                    {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.avgCycleTime : portfolioSummary.avgCycleTime}h
                  </span>
                  <span className="text-xs font-mono text-slate-500">
                    Meta: {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.avgTargetCycleTime : portfolioSummary.avgTargetCycleTime}h
                  </span>
                </div>
                <p className="text-[10.5px] text-slate-500 font-sans pt-1 truncate">
                  Gargalo: <strong className="text-slate-700">{currentSelectedCompanyHealth ? currentSelectedCompanyHealth.mainBottleneck : "Análise de Fila"}</strong>
                </p>
              </div>
            )}

            {/* 4. Rolled Yield (FPY) */}
            {kpiConfig.showRolledYield && (
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>Rolled Yield (FPY)</span>
                  <CheckCircle2 size={16} className="text-amber-600" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-serif font-black text-slate-900">
                    {currentSelectedCompanyHealth ? currentSelectedCompanyHealth.avgYield : portfolioSummary.avgYield}%
                  </span>
                </div>
                <p className="text-[10.5px] text-slate-500 font-sans pt-1">
                  Rendimento de Primeira Passagem sem Retrabalho
                </p>
              </div>
            )}

            {/* 5. ROI Acumulado */}
            {kpiConfig.showRoi && (
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>Impacto Financeiro (ROI)</span>
                  <TrendingUp size={16} className="text-purple-600" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-serif font-black text-slate-900">
                    R$ {((currentSelectedCompanyHealth ? currentSelectedCompanyHealth.totalRoi : portfolioSummary.totalRoi) / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 0 })}k
                  </span>
                </div>
                <p className="text-[10.5px] text-slate-500 font-sans pt-1">
                  Total de Processos Mapeados: <strong>{currentSelectedCompanyHealth ? currentSelectedCompanyHealth.totalProjects : portfolioSummary.totalProjects}</strong>
                </p>
              </div>
            )}

          </div>
        )}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAMADA 3: MÓDULOS ESTRATÉGICOS DA EMPRESA (TORRES DO BSC)     */}
      {/* ------------------------------------------------------------- */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-lg font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
              <Target size={22} className="text-[#C49746]" />
              2. Módulos & Torres Estratégicas da Empresa (BSC)
            </h2>
            <p className="text-xs text-slate-600 font-sans">
              Projetos e processos agrupados em suas respectivas perspectivas operacionais. Clique em um projeto para trabalhar no workspace ou crie novos fluxos por torre.
            </p>
          </div>

          {/* Search & Status Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md px-2.5 py-1 text-xs">
              <Filter size={13} className="text-slate-400 shrink-0" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-transparent text-slate-800 text-xs font-sans outline-none cursor-pointer"
              >
                <option value="ALL">Todos os Status</option>
                <option value="Em Andamento">⚡ Em Andamento</option>
                <option value="Planejado">📌 Planejado</option>
                <option value="Concluído">✅ Concluído</option>
              </select>
            </div>

            <div className="relative min-w-[200px]">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Filtrar por nome do projeto..."
                value={searchQuery.trim()}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-sans rounded-md pl-8 pr-2.5 py-1 focus:ring-2 focus:ring-[#C49746] outline-none"
              />
            </div>
          </div>
        </div>

        {/* STRATEGIC TOWERS GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {STRATEGIC_TOWERS.map((tower) => {
            const TowerIcon = tower.icon;
            const towerProjects = filteredMetrics.filter((m) => m.strategicTower === tower.id);
            const totalTowerROI = towerProjects.reduce((acc, m) => acc + m.expectedROI, 0);
            const avgTowerSigma = towerProjects.length > 0
              ? Number((towerProjects.reduce((acc, m) => acc + m.sigmaLevel, 0) / towerProjects.length).toFixed(2))
              : 3.5;

            return (
              <div
                key={tower.id}
                className={`border rounded-xl shadow-2xs overflow-hidden transition-all flex flex-col justify-between ${tower.bgBorderClass}`}
              >
                {/* Tower Header */}
                <div className={`p-4 border-b flex items-center justify-between ${tower.headerBgClass}`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-white/10 text-white shrink-0">
                      <TowerIcon size={20} />
                    </div>
                    <div>
                      <h3 className="font-serif font-black text-sm tracking-tight">
                        {tower.title}
                      </h3>
                      <p className="text-[10.5px] font-sans opacity-80 line-clamp-1">
                        {tower.description}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setNewProjectTower(tower.id);
                      setNewProjectCompanyId(selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : companies[0]?.id || "");
                      setIsNewProjectModalOpen(true);
                    }}
                    className="bg-amber-400 hover:bg-amber-300 text-slate-950 px-2.5 py-1.5 rounded-md text-[11px] font-mono font-bold flex items-center gap-1 shrink-0 shadow-2xs cursor-pointer transition-all"
                    title={`Criar novo projeto na torre ${tower.shortTitle}`}
                  >
                    <Plus size={13} />
                    + Projeto
                  </button>
                </div>

                {/* Tower KPI Sub-bar */}
                <div className="px-4 py-2 bg-white/80 border-b border-slate-200/60 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <FolderGit2 size={13} className="text-slate-400" />
                    <strong>{towerProjects.length}</strong> {towerProjects.length === 1 ? "projeto" : "projetos"} nesta torre
                  </span>
                  <div className="flex items-center gap-4 text-[11px]">
                    <span className="text-slate-600">Sigma Médio: <strong className="text-emerald-700">{avgTowerSigma}σ</strong></span>
                    <span className="text-slate-600">ROI: <strong className="text-slate-900">R$ {(totalTowerROI / 1000).toFixed(0)}k</strong></span>
                  </div>
                </div>

                {/* Projects List inside Tower */}
                <div className="p-4 space-y-3 flex-1">
                  {towerProjects.length === 0 ? (
                    <div className="py-8 text-center border border-dashed border-slate-300 rounded-lg bg-white/50 space-y-2">
                      <p className="text-xs text-slate-500 font-sans">
                        Nenhum projeto ou processo cadastrado nesta torre para o filtro selecionado.
                      </p>
                      <button
                        onClick={() => {
                          setNewProjectTower(tower.id);
                          setNewProjectCompanyId(selectedCompanyFilter !== "ALL" ? selectedCompanyFilter : companies[0]?.id || "");
                          setIsNewProjectModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-black text-amber-400 text-xs font-mono font-bold py-1.5 px-3 rounded-md transition-all cursor-pointer shadow-3xs"
                      >
                        <Plus size={13} />
                        + Cadastrar Projeto em {tower.shortTitle}
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {towerProjects.map((item) => {
                        const isWorkspaceActive = activeProjectId === item.project.id;
                        
                        return (
                          <div
                            key={item.project.id}
                            className={`p-3.5 rounded-lg border transition-all bg-white hover:shadow-xs flex flex-col justify-between space-y-3 ${
                              isWorkspaceActive ? "border-amber-400 ring-2 ring-amber-400/30 bg-amber-50/20" : "border-slate-200 hover:border-slate-300"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <div className="flex items-center gap-2 mb-0.5">
                                  <span className={`px-2 py-0.2 rounded-xs text-[9.5px] font-mono font-bold ${
                                    item.status === "Concluído"
                                      ? "bg-emerald-100 text-emerald-800"
                                      : item.status === "Em Andamento"
                                      ? "bg-blue-100 text-blue-800"
                                      : "bg-slate-100 text-slate-700"
                                  }`}>
                                    {item.status}
                                  </span>
                                  
                                  <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                                    <Building2 size={11} className="text-[#C49746]" />
                                    {item.companyName}
                                  </span>

                                  {isWorkspaceActive && (
                                    <span className="bg-amber-500 text-white text-[9px] font-mono font-bold px-1.5 py-0.2 rounded-xs">
                                      Workspace Ativo
                                    </span>
                                  )}
                                </div>

                                <h4 className="font-serif font-bold text-sm text-slate-900 tracking-tight">
                                  {item.project.name}
                                </h4>
                                <p className="text-[11px] text-slate-500 font-sans line-clamp-1 mt-0.5">
                                  {item.project.objective || "Otimização de fluxo operacional DMAIC"}
                                </p>
                              </div>

                              <div className="text-right shrink-0">
                                <span className={`inline-block px-2 py-0.5 rounded-md font-mono font-bold text-xs ${
                                  item.sigmaLevel >= 4.5
                                    ? "bg-emerald-100 text-emerald-800"
                                    : item.sigmaLevel >= 3.5
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-amber-100 text-amber-800"
                                }`}>
                                  {item.sigmaLevel} σ
                                </span>
                                <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                                  {item.yieldPercent}% Yield
                                </div>
                              </div>
                            </div>

                            {/* Secondary Metrics Bar */}
                            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-[10.5px] font-mono text-slate-600 bg-slate-50/70 p-2 rounded-md">
                              <div>
                                <span className="text-slate-400 block text-[9px]">Cycle Time</span>
                                <strong>{item.cycleTimeHours}h</strong> <span className="text-slate-400">/ Meta {item.targetCycleTimeHours}h</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block text-[9px]">Gargalo Mapeado</span>
                                <strong className="truncate block">{item.bottleneckName}</strong>
                              </div>
                              <div className="text-right">
                                <span className="text-slate-400 block text-[9px]">ROI Estimado</span>
                                <strong className="text-slate-900">R$ {(item.expectedROI / 1000).toFixed(0)}k</strong>
                              </div>
                            </div>

                            {/* Card Actions */}
                            <div className="flex items-center justify-between pt-1">
                              <button
                                onClick={() => setSelectedProjectForDetails(item)}
                                className="text-slate-600 hover:text-slate-900 text-xs font-mono font-medium flex items-center gap-1 cursor-pointer hover:underline"
                              >
                                <Info size={13} className="text-[#C49746]" />
                                Visualizar Detalhes
                              </button>

                              <button
                                onClick={() => handleOpenProjectWorkspace(item.project.id, item.project.companyId)}
                                className="bg-slate-900 hover:bg-black text-white text-xs font-mono font-bold py-1.5 px-3 rounded-md transition-all flex items-center gap-1.5 cursor-pointer shadow-3xs"
                              >
                                <Zap size={13} className="text-amber-400" />
                                Trabalhar no Projeto
                                <ChevronRight size={13} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Strategic goals footer */}
                <div className="p-3 bg-slate-100/60 border-t border-slate-200/80 text-[10px] font-sans text-slate-500 flex items-center gap-2">
                  <Target size={12} className="text-slate-400 shrink-0" />
                  <span className="truncate">
                    Metas: {tower.strategicGoals.join(" • ")}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAMADA 4: VISÃO DE PERFORMANCE & QUADRO DE PROJETOS COMPLETO  */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-3xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-serif font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
              <BarChart2 className="text-[#C49746]" size={18} />
              Quadro Geral de Projetos e Processos
            </h2>
            <p className="text-xs text-slate-500 font-sans">
              Visão tabular de todos os projetos cadastrados no ecossistema com atalhos de acesso.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-500">
              {filteredMetrics.length} registro(s) exibido(s)
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/80 text-[10px] font-mono uppercase tracking-wider text-slate-600 border-b border-slate-200">
                <th className="py-3 px-4 font-bold">Projeto / Processo</th>
                <th className="py-3 px-3 font-bold">Empresa</th>
                <th className="py-3 px-3 font-bold">Torre BSC</th>
                <th className="py-3 px-3 font-bold">Status</th>
                <th className="py-3 px-3 font-bold text-right">Cycle Time</th>
                <th className="py-3 px-3 font-bold text-center">Nível Sigma</th>
                <th className="py-3 px-3 font-bold text-right">Yield / DPMO</th>
                <th className="py-3 px-3 font-bold">Gargalo Crítico</th>
                <th className="py-3 px-3 font-bold text-right">ROI Estimado</th>
                <th className="py-3 px-4 font-bold text-center">Ação Workspace</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs font-sans">
              {filteredMetrics.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-500 font-sans space-y-3">
                    <p className="text-sm font-medium text-slate-700">Nenhum projeto encontrado para os filtros ativos.</p>
                  </td>
                </tr>
              ) : (
                filteredMetrics.map((item) => {
                  const isWorkspaceActive = activeProjectId === item.project.id;

                  return (
                    <tr
                      key={item.project.id}
                      className={`hover:bg-slate-50/80 transition-colors ${isWorkspaceActive ? "bg-amber-50/40" : ""}`}
                    >
                      <td className="py-3 px-4 max-w-[200px]">
                        <div className="font-bold text-slate-900 truncate" title={item.project.name}>
                          {item.project.name}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate">
                          {item.project.objective || "Sem descrição"}
                        </div>
                      </td>

                      <td className="py-3 px-3 font-medium text-slate-800 truncate max-w-[130px]">
                        {item.companyName}
                      </td>

                      <td className="py-3 px-3">
                        <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-xs">
                          {STRATEGIC_TOWERS.find((t) => t.id === item.strategicTower)?.shortTitle || "Operações"}
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded-xs text-[10px] font-mono font-bold ${
                          item.status === "Concluído"
                            ? "bg-emerald-100 text-emerald-800"
                            : item.status === "Em Andamento"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-slate-100 text-slate-700"
                        }`}>
                          {item.status}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        {item.cycleTimeHours}h <span className="text-[10px] text-slate-400 font-normal">({item.targetCycleTimeHours}h)</span>
                      </td>

                      <td className="py-3 px-3 text-center">
                        <span className="font-mono font-bold text-emerald-700">
                          {item.sigmaLevel}σ
                        </span>
                      </td>

                      <td className="py-3 px-3 text-right font-mono">
                        <div className="font-bold text-slate-800">{item.yieldPercent}%</div>
                        <div className="text-[9px] text-slate-400">{item.dpmo.toLocaleString("pt-BR")} DPMO</div>
                      </td>

                      <td className="py-3 px-3 text-slate-700 truncate max-w-[130px]">
                        {item.bottleneckName}
                      </td>

                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        R$ {(item.expectedROI / 1000).toFixed(0)}k
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleOpenProjectWorkspace(item.project.id, item.project.companyId)}
                          className="bg-slate-900 hover:bg-black text-white text-[10.5px] font-mono font-bold py-1.5 px-3 rounded-md transition-all flex items-center justify-center gap-1 cursor-pointer mx-auto shadow-3xs"
                        >
                          <Zap size={11} className="text-amber-400" />
                          Abrir
                          <ChevronRight size={11} />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* MODAL: DETALHES DO PROJETO / PROCESSO                          */}
      {/* ------------------------------------------------------------- */}
      {selectedProjectForDetails && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-300 shadow-2xl overflow-hidden animate-scale-up">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-400 text-slate-950 rounded-lg">
                  <Info size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-xs">
                      {STRATEGIC_TOWERS.find((t) => t.id === selectedProjectForDetails.strategicTower)?.title}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      ID: {selectedProjectForDetails.project.id}
                    </span>
                  </div>
                  <h3 className="font-serif font-black text-xl text-white tracking-tight mt-0.5">
                    {selectedProjectForDetails.project.name}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setSelectedProjectForDetails(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-all cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-5 text-xs font-sans text-slate-800 max-h-[75vh] overflow-y-auto">
              
              {/* Company & Status */}
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div>
                  <span className="text-[10px] font-mono text-slate-400 block">Empresa Vinculada</span>
                  <strong className="text-sm font-serif text-slate-900 flex items-center gap-1.5">
                    <Building2 size={14} className="text-[#C49746]" />
                    {selectedProjectForDetails.companyName}
                  </strong>
                </div>

                <div>
                  <span className="text-[10px] font-mono text-slate-400 block">Status do Projeto</span>
                  <span className="px-2.5 py-1 rounded-xs font-mono font-bold text-xs bg-blue-100 text-blue-800">
                    {selectedProjectForDetails.status}
                  </span>
                </div>
              </div>

              {/* Objective / Problem Statement */}
              <div>
                <h4 className="font-serif font-bold text-sm text-slate-900 mb-1">
                  Objetivo Estratégico & Problema
                </h4>
                <p className="bg-slate-50 p-3 rounded-md border border-slate-200 text-slate-700 leading-relaxed">
                  {selectedProjectForDetails.project.objective || "Mapeamento e otimização de fluxo de trabalho Six Sigma DMAIC para estabilização de processo."}
                </p>
              </div>

              {/* Diagnostic Grid */}
              <div>
                <h4 className="font-serif font-bold text-sm text-slate-900 mb-2">
                  Indicadores Chave do Diagnóstico (Six Sigma)
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 block">Nível Sigma</span>
                    <strong className="text-lg text-emerald-700">{selectedProjectForDetails.sigmaLevel} σ</strong>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 block">Yield (Qualidade)</span>
                    <strong className="text-lg text-slate-900">{selectedProjectForDetails.yieldPercent}%</strong>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 block">Cycle Time</span>
                    <strong className="text-lg text-slate-900">{selectedProjectForDetails.cycleTimeHours}h</strong>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 block">ROI Estimado</span>
                    <strong className="text-lg text-purple-700">R$ {(selectedProjectForDetails.expectedROI / 1000).toFixed(0)}k</strong>
                  </div>
                </div>
              </div>

              {/* Process Flow & Bottleneck */}
              <div className="bg-amber-50/60 p-4 rounded-lg border border-amber-200 space-y-1">
                <span className="text-xs font-serif font-bold text-amber-900 flex items-center gap-1.5">
                  <AlertTriangle size={15} className="text-amber-600" />
                  Gargalo Crítico de Processo Mapeado:
                </span>
                <p className="text-xs text-amber-900 font-medium">
                  Etapa: <strong>{selectedProjectForDetails.bottleneckName}</strong> ({selectedProjectForDetails.totalStepsCount} etapas no fluxo total).
                </p>
              </div>

            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setSelectedProjectForDetails(null)}
                className="px-4 py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-200 font-mono text-xs cursor-pointer"
              >
                Fechar
              </button>

              <button
                type="button"
                onClick={() => {
                  const pid = selectedProjectForDetails.project.id;
                  const cid = selectedProjectForDetails.project.companyId;
                  setSelectedProjectForDetails(null);
                  handleOpenProjectWorkspace(pid, cid);
                }}
                className="px-5 py-2 bg-slate-900 hover:bg-black text-white font-mono font-bold rounded-md text-xs flex items-center gap-2 shadow-sm cursor-pointer"
              >
                <Zap size={14} className="text-amber-400" />
                🚀 Entrar no Workspace de Trabalho
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODAL 1: CRIAR NOVO PROJETO / PROCESSO (POR TORRE/EMPRESA)    */}
      {/* ------------------------------------------------------------- */}
      {isNewProjectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full border border-slate-300 shadow-2xl overflow-hidden animate-scale-up">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-400 text-slate-950 rounded-lg">
                  <Plus size={18} />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg tracking-tight">
                    Criar Novo Projeto / Processo
                  </h3>
                  <p className="text-xs text-slate-300 font-sans">
                    Vincule um novo fluxo DMAIC à empresa e torre do BSC
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsNewProjectModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-all cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleCreateNewProjectSubmit} className="p-6 space-y-4 text-xs font-sans">
              
              {/* Target Company Select */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Empresa de Destino *
                </label>
                <select
                  value={newProjectCompanyId}
                  onChange={(e) => setNewProjectCompanyId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 font-medium focus:ring-2 focus:ring-[#C49746] outline-none"
                  required
                >
                  <option value="" disabled>Selecione a Empresa...</option>
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.industry || "Geral"})
                    </option>
                  ))}
                </select>
              </div>

              {/* Strategic Tower / BSC Perspective */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Torre / Perspectiva do BSC *
                </label>
                <select
                  value={newProjectTower}
                  onChange={(e) => setNewProjectTower(e.target.value as StrategicTowerId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 font-medium focus:ring-2 focus:ring-[#C49746] outline-none"
                  required
                >
                  {STRATEGIC_TOWERS.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
                </select>
              </div>

              {/* Project Name */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Nome do Projeto / Processo *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Otimização do Atendimento ao Cliente PJ"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 focus:ring-2 focus:ring-[#C49746] outline-none"
                  required
                />
              </div>

              {/* Objective */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Objetivo Estratégico / Problema a Resolver
                </label>
                <textarea
                  rows={3}
                  placeholder="Ex: Reduzir tempo de ciclo no processamento e eliminar erros de triagem..."
                  value={newProjectObjective}
                  onChange={(e) => setNewProjectObjective(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 focus:ring-2 focus:ring-[#C49746] outline-none"
                />
              </div>

              {/* Target Cycle Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                    Meta de Cycle Time (Horas)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={1000}
                    value={newProjectTargetCycleTime}
                    onChange={(e) => setNewProjectTargetCycleTime(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 font-mono focus:ring-2 focus:ring-[#C49746] outline-none"
                  />
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 cursor-pointer pb-2">
                    <input
                      type="checkbox"
                      checked={openWorkspaceImmediately}
                      onChange={(e) => setOpenWorkspaceImmediately(e.target.checked)}
                      className="rounded-xs border-slate-300 text-[#C49746] focus:ring-[#C49746]"
                    />
                    <span className="text-xs text-slate-700 font-medium">
                      Abrir workspace ao criar
                    </span>
                  </label>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsNewProjectModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-100 font-mono text-xs cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C49746] hover:bg-[#a67c33] text-white font-mono font-bold rounded-md text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Check size={15} />
                  Criar Projeto
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODAL 2: CADASTRAR NOVA EMPRESA                                */}
      {/* ------------------------------------------------------------- */}
      {isNewCompanyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full border border-slate-300 shadow-2xl overflow-hidden animate-scale-up">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-400 text-slate-950 rounded-lg">
                  <Building2 size={18} />
                </div>
                <div>
                  <h3 className="font-serif font-black text-lg tracking-tight">
                    Cadastrar Nova Empresa
                  </h3>
                  <p className="text-xs text-slate-300 font-sans">
                    Adicione uma nova unidade corporativa
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsNewCompanyModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-all cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleCreateNewCompanySubmit} className="p-6 space-y-4 text-xs font-sans">
              
              {/* Company Name */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Nome da Empresa / Razão Social *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Grupo Industrial Alfa S/A"
                  value={newCompanyName}
                  onChange={(e) => setNewCompanyName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 focus:ring-2 focus:ring-[#C49746] outline-none"
                  required
                />
              </div>

              {/* Industry / Sector */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  Setor / Indústria
                </label>
                <input
                  type="text"
                  placeholder="Ex: Bancário, Manufatura, Logística, Saúde..."
                  value={newCompanyIndustry}
                  onChange={(e) => setNewCompanyIndustry(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 focus:ring-2 focus:ring-[#C49746] outline-none"
                />
              </div>

              {/* CNPJ */}
              <div>
                <label className="block font-mono font-bold text-slate-700 uppercase mb-1">
                  CNPJ (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="00.000.000/0001-00"
                  value={newCompanyCnpj}
                  onChange={(e) => setNewCompanyCnpj(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-md p-2.5 text-slate-900 font-mono focus:ring-2 focus:ring-[#C49746] outline-none"
                />
              </div>

              {/* Modal Actions */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsNewCompanyModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-100 font-mono text-xs cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C49746] hover:bg-[#a67c33] text-white font-mono font-bold rounded-md text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Check size={15} />
                  Cadastrar Empresa
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODAL 3: ENTERPRISE DASHBOARD CONFIGURATION (CONFIG PAINEL)  */}
      {/* ------------------------------------------------------------- */}
      {isConfigPanelOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-xl w-full border border-slate-300 shadow-2xl overflow-hidden animate-scale-up">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-400 text-slate-950 rounded-lg shadow-sm">
                  <Sliders size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9.5px] font-mono font-bold uppercase tracking-wider bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-xs">
                      Painel do Administrador
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      KPI Customization
                    </span>
                  </div>
                  <h3 className="font-serif font-black text-xl text-white tracking-tight mt-0.5">
                    Enterprise Dashboard Configuration
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setIsConfigPanelOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-all cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-6 text-xs font-sans text-slate-800 max-h-[75vh] overflow-y-auto">
              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                <p className="text-slate-700 leading-relaxed font-medium">
                  Selecione quais indicadores de desempenho (KPIs) de performance Lean & Six Sigma devem ser exibidos na visão consolidada corporativa. As alterações são aplicadas e salvas no sistema em tempo real.
                </p>
              </div>

              {/* Presets */}
              <div>
                <label className="block font-mono font-bold text-slate-600 uppercase mb-2 text-[10px]">
                  Perfis de Visualização Rápidos
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono">
                  <button
                    type="button"
                    onClick={() => handleUpdateKpiConfig({ showSigma: true, showLeadTime: true, showRolledYield: true, showRoi: true, showHealthScore: true })}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-[10px] font-bold transition-colors cursor-pointer text-center"
                  >
                    Exibir Todos (5 KPIs)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleUpdateKpiConfig({ showSigma: true, showLeadTime: true, showRolledYield: true, showRoi: false, showHealthScore: false })}
                    className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 rounded text-[10px] font-bold transition-colors cursor-pointer text-center"
                  >
                    Foco Six Sigma & Yield
                  </button>
                  <button
                    type="button"
                    onClick={() => handleUpdateKpiConfig({ showSigma: false, showLeadTime: true, showRolledYield: false, showRoi: true, showHealthScore: true })}
                    className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded text-[10px] font-bold transition-colors cursor-pointer text-center"
                  >
                    Visão Executiva (ROI/SLA)
                  </button>
                </div>
              </div>

              {/* Toggles list */}
              <div className="space-y-3">
                <label className="block font-mono font-bold text-slate-600 uppercase text-[10px]">
                  Indicadores de Desempenho (KPIs) Individuais
                </label>

                {/* 1. Nível Sigma */}
                <div className={`p-3.5 rounded-lg border transition-all flex items-center justify-between ${kpiConfig.showSigma ? "bg-emerald-50/50 border-emerald-200" : "bg-slate-50 border-slate-200 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md ${kpiConfig.showSigma ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-500"}`}>
                      <Award size={18} />
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">
                        Nível / Maturidade Sigma (σ)
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Maturidade estatística do processo (1.5σ a 6.0σ) e taxa de defeitos DPMO.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleSingleKpi("showSigma")}
                    className={`px-3 py-1.5 rounded-md font-mono font-bold text-xs transition-all cursor-pointer ${
                      kpiConfig.showSigma
                        ? "bg-emerald-600 text-white shadow-3xs"
                        : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                    }`}
                  >
                    {kpiConfig.showSigma ? "Visível" : "Oculto"}
                  </button>
                </div>

                {/* 2. Lead Time / Cycle Time */}
                <div className={`p-3.5 rounded-lg border transition-all flex items-center justify-between ${kpiConfig.showLeadTime ? "bg-blue-50/50 border-blue-200" : "bg-slate-50 border-slate-200 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md ${kpiConfig.showLeadTime ? "bg-blue-100 text-blue-800" : "bg-slate-200 text-slate-500"}`}>
                      <Clock size={18} />
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">
                        Lead Time / Cycle Time Médio
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Tempo total de atravessamento em horas vs meta de SLA cadastrada no Charter.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleSingleKpi("showLeadTime")}
                    className={`px-3 py-1.5 rounded-md font-mono font-bold text-xs transition-all cursor-pointer ${
                      kpiConfig.showLeadTime
                        ? "bg-blue-600 text-white shadow-3xs"
                        : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                    }`}
                  >
                    {kpiConfig.showLeadTime ? "Visível" : "Oculto"}
                  </button>
                </div>

                {/* 3. Rolled Yield (FPY) */}
                <div className={`p-3.5 rounded-lg border transition-all flex items-center justify-between ${kpiConfig.showRolledYield ? "bg-amber-50/50 border-amber-200" : "bg-slate-50 border-slate-200 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md ${kpiConfig.showRolledYield ? "bg-amber-100 text-amber-800" : "bg-slate-200 text-slate-500"}`}>
                      <CheckCircle2 size={18} />
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">
                        Rolled Yield (FPY / Rendimento %)
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Percentual de itens processados do início ao fim de primeira sem nenhum retrabalho.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleSingleKpi("showRolledYield")}
                    className={`px-3 py-1.5 rounded-md font-mono font-bold text-xs transition-all cursor-pointer ${
                      kpiConfig.showRolledYield
                        ? "bg-amber-600 text-white shadow-3xs"
                        : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                    }`}
                  >
                    {kpiConfig.showRolledYield ? "Visível" : "Oculto"}
                  </button>
                </div>

                {/* 4. Impacto Financeiro (ROI) */}
                <div className={`p-3.5 rounded-lg border transition-all flex items-center justify-between ${kpiConfig.showRoi ? "bg-purple-50/50 border-purple-200" : "bg-slate-50 border-slate-200 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md ${kpiConfig.showRoi ? "bg-purple-100 text-purple-800" : "bg-slate-200 text-slate-500"}`}>
                      <TrendingUp size={18} />
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">
                        Impacto Financeiro (ROI)
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Consolidação dos ganhos financeiros estimados e eliminação de desperdícios em R$.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleSingleKpi("showRoi")}
                    className={`px-3 py-1.5 rounded-md font-mono font-bold text-xs transition-all cursor-pointer ${
                      kpiConfig.showRoi
                        ? "bg-purple-600 text-white shadow-3xs"
                        : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                    }`}
                  >
                    {kpiConfig.showRoi ? "Visível" : "Oculto"}
                  </button>
                </div>

                {/* 5. Índice de Saúde Operacional */}
                <div className={`p-3.5 rounded-lg border transition-all flex items-center justify-between ${kpiConfig.showHealthScore ? "bg-slate-100 border-slate-300" : "bg-slate-50 border-slate-200 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md ${kpiConfig.showHealthScore ? "bg-slate-800 text-amber-400" : "bg-slate-200 text-slate-500"}`}>
                      <Activity size={18} />
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">
                        Índice de Saúde Operacional
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Pontuação agregada da empresa (0-100%) combinando variabilidade, SLA e qualidade.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleSingleKpi("showHealthScore")}
                    className={`px-3 py-1.5 rounded-md font-mono font-bold text-xs transition-all cursor-pointer ${
                      kpiConfig.showHealthScore
                        ? "bg-slate-900 text-white shadow-3xs"
                        : "bg-slate-200 text-slate-600 hover:bg-slate-300"
                    }`}
                  >
                    {kpiConfig.showHealthScore ? "Visível" : "Oculto"}
                  </button>
                </div>

              </div>

            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetKpiConfig}
                className="px-3.5 py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-200 font-mono text-xs cursor-pointer flex items-center gap-1.5"
              >
                Restaurar Padrão
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsConfigPanelOpen(false);
                  showNotification("Configurações do Enterprise Dashboard atualizadas!");
                }}
                className="px-5 py-2 bg-[#C49746] hover:bg-[#a67c33] text-white font-mono font-bold rounded-md text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Check size={15} />
                Salvar & Aplicar
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};

export default EnterpriseOverviewDashboard;
