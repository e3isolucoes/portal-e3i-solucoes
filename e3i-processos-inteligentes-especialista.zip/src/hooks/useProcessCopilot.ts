import { useState, useMemo, useCallback } from "react";
import { calculateProcessMetrics } from "../utils";

export interface KaizenAction {
  id: string;
  message: string;
  dateStr: string; // YYYY-MM-DD format for simple range comparison
  timestamp: Date;
}

interface CopilotProps {
  steps: any[];
  setSteps: (steps: any[] | ((prev: any[]) => any[])) => void;
  arrivalRate: number;
  triggerFlash: (msg: string) => void;
}

export function useProcessCopilot({ steps, setSteps, arrivalRate, triggerFlash }: CopilotProps) {
  const [copilotHistory, setCopilotHistory] = useState<KaizenAction[]>(() => [
    {
      id: "hist-1",
      message: "Melhoria E3I: Balanceamento do gargalo crítico SMT-1. Tempo de ciclo reduzido.",
      dateStr: "2026-05-25",
      timestamp: new Date("2026-05-25T10:00:00")
    },
    {
      id: "hist-2",
      message: "Melhoria E3I: Otimizou os tempos de setup e reduziu a variabilidade do forno (SMED).",
      dateStr: "2026-06-10",
      timestamp: new Date("2026-06-10T14:30:00")
    },
    {
      id: "hist-3",
      message: "Melhoria E3I: Implantou blindagens automáticas de qualidade (Poka-Yoke) no teste funcional.",
      dateStr: "2026-06-14",
      timestamp: new Date("2026-06-14T11:15:00")
    }
  ]);

  const [copilotInput, setCopilotInput] = useState<string>("");
  const [isCopilotProcessing, setIsCopilotProcessing] = useState<boolean>(false);
  
  // Date range selectors for Optimization History filtering
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  const handleCopilotRequest = useCallback(async () => {
    if (!copilotInput.trim()) return;
    setIsCopilotProcessing(true);
    const text = copilotInput.toLowerCase();

    // Mathematically modify the Process Twin based on natural language inputs
    setTimeout(() => {
      let changeMsg = "Ajuste proativo realizado no gargalo atual.";
      
      setSteps(prev => {
        const stats_info = calculateProcessMetrics(prev, arrivalRate);
        const btlName = stats_info.bottleneckStepName;
        const btlStepObj = prev.find(s => s.name === btlName);

        if (text.includes("balance") || text.includes("otimiz") || text.includes("gargalo") || text.includes("reduzir tempo") || text.includes("equilibr")) {
          if (btlStepObj) {
            const newTime = Math.max(0.5, Math.round(btlStepObj.processingTime * 0.75 * 10) / 10);
            changeMsg = `Equilibrou o gargalo estocástico "${btlName}". Tempo de ciclo reduzido de ${btlStepObj.processingTime} min para ${newTime} min.`;
            return prev.map(s => s.name === btlName ? { ...s, processingTime: newTime } : s);
          }
        }
        
        if (text.includes("variabilid") || text.includes("desvio") || text.includes("smed") || text.includes("estabiliz") || text.includes("variacao")) {
          changeMsg = `Otimizou os tempos de setup e reduziu a variabilidade (desvios padrões) do sistema LSS em 27% (Análise SMED).`;
          return prev.map(s => {
            const newDev = Math.max(0.05, Math.round(s.standardDeviation * 0.73 * 100) / 100);
            const newSetup = Math.max(0, Math.round(s.setupTime * 0.5));
            return { ...s, standardDeviation: newDev, setupTime: newSetup };
          });
        }

        if (text.includes("qualidad") || text.includes("yield") || text.includes("defect") || text.includes("poka") || text.includes("defeito") || text.includes("acert")) {
          changeMsg = `Implantou blindagens automáticas de qualidade (Poka-Yoke) elevando a taxa de rendimento (Yield) de primeira passagem.`;
          return prev.map(s => {
            const newYield = Math.min(0.999, Math.round((s.yieldRate + 0.03) * 1000) / 1000);
            return { ...s, yieldRate: newYield };
          });
        }

        if (text.includes("operador") || text.includes("equipe") || text.includes("capacid") || text.includes("staff") || text.includes("contratar")) {
          if (btlStepObj) {
            changeMsg = `Aumentou a alocação de equipe no gargalo "${btlName}" (+1 Operador). Capacidade de vazão duplicada nesse posto.`;
            return prev.map(s => s.name === btlName ? { ...s, resourceCount: s.resourceCount + 1 } : s);
          }
        }

        // Default baseline optimization
        if (btlStepObj) {
          const newTime = Math.max(0.5, Math.round(btlStepObj.processingTime * 0.9 * 10) / 10);
          changeMsg = `Ajustou eficientemente a atividade de gargalo "${btlName}": tempo reduzido de ${btlStepObj.processingTime} min para ${newTime} min.`;
          return prev.map(s => s.name === btlName ? { ...s, processingTime: newTime } : s);
        }

        return prev;
      });

      const today = new Date();
      const year = today.getFullYear();
      const month = String(today.getMonth() + 1).padStart(2, "0");
      const day = String(today.getDate()).padStart(2, "0");
      const dateStr = `${year}-${month}-${day}`;

      setCopilotHistory(prev => [
        {
          id: `hist-${Date.now()}`,
          message: `Melhoria E3I: ${changeMsg}`,
          dateStr,
          timestamp: today
        },
        ...prev
      ]);
      setCopilotInput("");
      setIsCopilotProcessing(false);
      triggerFlash(`✓ Copiloto E3I: ${changeMsg}`);
    }, 1500);
  }, [copilotInput, arrivalRate, setSteps, triggerFlash]);

  const addCustomKaizenAction = useCallback((message: string) => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    const dateStr = `${year}-${month}-${day}`;

    setCopilotHistory(prev => [
      {
        id: `hist-${Date.now()}`,
        message,
        dateStr,
        timestamp: today
      },
      ...prev
    ]);
  }, []);

  // Derived filtered optimization history
  const filteredHistory = useMemo(() => {
    return copilotHistory.filter(action => {
      if (startDate && action.dateStr < startDate) {
        return false;
      }
      if (endDate && action.dateStr > endDate) {
        return false;
      }
      return true;
    });
  }, [copilotHistory, startDate, endDate]);

  return {
    copilotHistory,
    filteredHistory,
    copilotInput,
    setCopilotInput,
    isCopilotProcessing,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    handleCopilotRequest,
    addCustomKaizenAction,
    clearHistory: () => setCopilotHistory([])
  };
}
