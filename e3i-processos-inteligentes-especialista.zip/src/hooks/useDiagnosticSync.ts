import { useState, useCallback } from "react";
import { z } from "zod";
import { ProjectCharter } from "../types";
import { BusinessType } from "../App";
import { BUSINESS_TERMS } from "../shared/utils/initialStates";

// Zod validation schema for the 360 Diagnostic Wizard inputs
export const DiagnosticAnswersSchema = z.object({
  answers: z
    .array(z.number().int().min(0, "A resposta deve ser um índice válido (>= 0)").max(3, "A resposta deve ser um índice válido (<= 3)"))
    .min(1, "É necessário responder a pelo menos uma pergunta"),
  businessType: z.enum([
    "INDUSTRIAL",
    "SERVICES",
    "RETAIL",
    "LOGISTICS",
    "TECHNOLOGY",
    "HEALTHCARE",
    "FINANCE",
    "HUMAN_RESOURCES"
  ]),
  processName: z.string().min(1, "O nome do processo é obrigatório"),
  processObjective: z.string().optional()
});

export type DiagnosticWizardInput = z.infer<typeof DiagnosticAnswersSchema>;

export interface UseDiagnosticSyncProps {
  setCharter: (charter: ProjectCharter) => void;
}

export function useDiagnosticSync({ setCharter }: UseDiagnosticSyncProps) {
  const [validationErrors, setValidationErrors] = useState<string[] | null>(null);

  const validateAndSync = useCallback((input: unknown): { success: boolean; data?: ProjectCharter; errors?: string[] } => {
    const parseResult = DiagnosticAnswersSchema.safeParse(input);

    if (!parseResult.success) {
      const formattedErrors = parseResult.error.issues.map(err => {
        return `${err.path.join(".")}: ${err.message}`;
      });
      setValidationErrors(formattedErrors);
      return { success: false, errors: formattedErrors };
    }

    setValidationErrors(null);
    const { answers, businessType, processName, processObjective } = parseResult.data;

    const selectedMainConcernIdx = answers[0] ?? 0;
    const selectedGoalIdx = answers[2] ?? 0;
    const pName = processName;
    const TERMS = BUSINESS_TERMS[businessType] || BUSINESS_TERMS.INDUSTRIAL;

    let prefilledTitle = `Iniciativa de Melhoria LSS em ${pName}`;
    let prefilledProblem = `Instabilidade estatística no fluxo de ${pName}, provocando níveis altos de WIP e gargalos randômicos de vazão no ${TERMS.bottleneckDesc.toLowerCase()} principal.`;
    let prefilledGoal = processObjective || `Garantir o fluxo contínuo balanceado de ${pName}, estabilizando as taxas médias e reduzindo perdas e tempos de espera.`;
    let metricVal: "cycle_time" | "defect_rate" | "throughput" = "cycle_time";
    let targetVal = 12.0;

    if (selectedMainConcernIdx === 0) {
      prefilledTitle = `Projeto DMAIC - Redução de Variabilidade em ${pName}`;
      prefilledProblem = `Variação de qualidade excessiva e retrabalho recorrente nos postos de trabalho de ${pName}, reduzindo o rendimento de primeira passagem e aumentando os defeitos estatísticos.`;
    } else if (selectedMainConcernIdx === 1) {
      prefilledTitle = `Iniciativa Lean - Otimização de ${TERMS.wip.split(" ")[0]} e Fluxo Contínuo de ${pName}`;
      prefilledProblem = `Gargalos persistentes acumulando ${TERMS.wip.toLowerCase().split(" (")[0]} em nível crítico no fluxo de ${pName}, resultando em tempos de ciclo elevados e ociosidade.`;
    }

    if (selectedGoalIdx === 0) {
      metricVal = "throughput";
      prefilledGoal = processObjective || `Elevar a vazão média do sistema (${TERMS.throughput}) em pelo menos 20% com o balanceamento ótimo de postos de trabalho em "${pName}".`;
      targetVal = businessType === "INDUSTRIAL" ? 35.0 : businessType === "TECHNOLOGY" ? 15.0 : 25.0;
    } else if (selectedGoalIdx === 1) {
      metricVal = "defect_rate";
      prefilledGoal = processObjective || `Maximizar o rendimento operacional de "${pName}", reduzindo a taxa de não-conformidade física dos postos e visando yield superior a 98.5%.`;
      targetVal = 0.015;
    } else if (selectedGoalIdx === 2) {
      metricVal = "cycle_time";
      prefilledGoal = processObjective || `Diminuir drasticamente o lead time de ponta a ponta (${TERMS.cycleTime}) do processo de "${pName}" removendo tempos ociosos.`;
      targetVal = 8.5;
    }

    const filledCharter: ProjectCharter = {
      title: prefilledTitle,
      problemStatement: prefilledProblem,
      goal: prefilledGoal,
      metric: metricVal,
      targetValue: targetVal
    };

    setCharter(filledCharter);

    return { success: true, data: filledCharter };
  }, [setCharter]);

  return {
    validateAndSync,
    validationErrors,
    clearValidationErrors: useCallback(() => setValidationErrors(null), [])
  };
}
