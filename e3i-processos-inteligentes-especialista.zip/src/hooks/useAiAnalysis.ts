/**
 * useAiAnalysis.ts
 *
 * Encapsula todo o estado e lógica de chamada à IA que estava disperso em App.tsx:
 *   - aiResult, aiLoading, aiError (análise DMAIC)
 *   - sectorInput, isSuggesting, suggestError, orInsight (sugestão de estrutura)
 *   - handleSuggestStructure, handleAnalyzeProcess
 *
 * Segue o princípio SRP: este hook tem uma única responsabilidade — comunicar com o
 * AiService e expor o estado resultante para a UI.
 *
 * [PERF/UX FIX — v2]
 * 1. Guarda contra duplo clique: se já existe uma chamada em andamento, uma nova
 *    chamada do mesmo tipo é ignorada em vez de disparar uma requisição concorrente.
 * 2. Proteção contra resposta obsoleta (stale response): cada chamada recebe um
 *    requestId. Se uma chamada mais recente já foi iniciada quando a resposta
 *    chega, a resposta antiga é descartada — evita que uma requisição lenta
 *    sobrescreva o resultado de uma requisição mais nova que respondeu primeiro.
 */

import { useState, useCallback, useRef, FormEvent } from "react";
import { AiService } from "../services/AiService";
import {
  ProcessStep,
  ProjectCharter,
  Sipoc,
  AiOptimizationResult,
} from "../types";

// Tipo inline re-exportado de AiService para evitar importação cruzada
interface OrInsight {
  orModel: string;
  problemStatement: string;
  orSuggestions: string;
  recommendedConfiguration: string;
  operationalTip: string;
}

interface UseAiAnalysisOptions {
  steps: ProcessStep[];
  arrivalRate: number;
  charter: ProjectCharter;
  sipoc: Sipoc;
  authToken?: string | null;
  /** Callback chamado após sugestão de estrutura bem-sucedida */
  onStructureSuggested?: (params: {
    newSteps: ProcessStep[];
    newSipoc: Sipoc;
  }) => void;
}

interface UseAiAnalysisReturn {
  // Análise DMAIC
  aiResult: AiOptimizationResult | null;
  aiLoading: boolean;
  aiError: string | null;
  handleAnalyzeProcess: () => Promise<void>;

  // Sugestão de estrutura por setor
  sectorInput: string;
  setSectorInput: (v: string) => void;
  isSuggesting: boolean;
  suggestError: string | null;
  orInsight: OrInsight | null;
  handleSuggestStructure: (e?: FormEvent) => Promise<void>;

  /** Reseta todos os estados de IA ao trocar template/tipo de negócio */
  resetAiState: () => void;
}

export function useAiAnalysis({
  steps,
  arrivalRate,
  charter,
  sipoc,
  authToken,
  onStructureSuggested,
}: UseAiAnalysisOptions): UseAiAnalysisReturn {
  // --- Análise DMAIC ---
  const [aiResult, setAiResult] = useState<AiOptimizationResult | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // --- Sugestão de estrutura ---
  const [sectorInput, setSectorInput] = useState("Linha de montagem de notebooks");
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [suggestError, setSuggestError] = useState<string | null>(null);
  const [orInsight, setOrInsight] = useState<OrInsight | null>(null);

  // [PERF/UX FIX] Request IDs independentes para cada fluxo assíncrono —
  // permitem descartar respostas obsoletas sem precisar de AbortController
  // (que exigiria mudanças no AiService para aceitar signal).
  const analyzeRequestIdRef = useRef(0);
  const suggestRequestIdRef = useRef(0);

  const handleAnalyzeProcess = useCallback(async () => {
    if (aiLoading) return; // [FIX] ignora clique duplo enquanto uma análise está em andamento

    if (steps.length === 0) {
      setAiError("O processo deve conter ao menos 1 etapa antes de disparar a análise.");
      return;
    }

    const myRequestId = ++analyzeRequestIdRef.current;
    setAiLoading(true);
    setAiError(null);

    try {
      const data = await AiService.analyzeProcess(
        steps,
        arrivalRate,
        charter,
        sipoc,
        authToken ?? undefined
      );

      // [FIX] Se uma chamada mais recente já foi disparada, esta resposta
      // está obsoleta — descarta para não sobrescrever um resultado mais novo.
      if (myRequestId !== analyzeRequestIdRef.current) return;
      setAiResult(data);
    } catch (err: unknown) {
      if (myRequestId !== analyzeRequestIdRef.current) return;
      const message =
        err instanceof Error
          ? err.message
          : "Não foi possível conectar ao servidor de IA.";
      setAiError(message);
    } finally {
      if (myRequestId === analyzeRequestIdRef.current) setAiLoading(false);
    }
  }, [steps, arrivalRate, charter, sipoc, authToken, aiLoading]);

  const handleSuggestStructure = useCallback(
    async (e?: FormEvent) => {
      if (e) e.preventDefault();
      if (!sectorInput.trim()) return;
      if (isSuggesting) return; // [FIX] ignora clique duplo

      const myRequestId = ++suggestRequestIdRef.current;
      setIsSuggesting(true);
      setSuggestError(null);

      try {
        const data = await AiService.suggestStructure(sectorInput);

        if (myRequestId !== suggestRequestIdRef.current) return; // [FIX] resposta obsoleta

        const processedSteps: ProcessStep[] = (data.steps ?? []).map(
          (s, idx) => ({
            id: `step-${Date.now()}-${idx}`,
            name: s.name,
            resource: s.resource,
            resourceCount: s.resourceCount ?? 1,
            processingTime: s.processingTime ?? 4.0,
            standardDeviation: s.standardDeviation ?? 0.8,
            yieldRate: s.yieldRate ?? 0.95,
            setupTime: s.setupTime ?? 0,
            x: 100 + (idx % 3) * 240,
            y: 80 + Math.floor(idx / 3) * 160,
            shapeType:
              idx === 0
                ? "START"
                : idx === data.steps.length - 1
                ? "END"
                : "ACTIVITY",
          })
        );

        onStructureSuggested?.({
          newSteps: processedSteps,
          newSipoc: data.sipoc ?? sipoc,
        });

        if (data.orAnalysis) {
          setOrInsight(data.orAnalysis);
        }
      } catch (err: unknown) {
        if (myRequestId !== suggestRequestIdRef.current) return;
        const message =
          err instanceof Error
            ? err.message
            : "Não foi possível conectar ao serviço de sugestão de IA.";
        setSuggestError(message);
      } finally {
        if (myRequestId === suggestRequestIdRef.current) setIsSuggesting(false);
      }
    },
    [sectorInput, sipoc, onStructureSuggested, isSuggesting]
  );

  const resetAiState = useCallback(() => {
    // [FIX] invalida quaisquer requisições em andamento ao resetar o estado
    // (ex: ao trocar de template) — evita que uma resposta tardia reapareça
    // depois do reset.
    analyzeRequestIdRef.current++;
    suggestRequestIdRef.current++;
    setAiResult(null);
    setAiError(null);
    setOrInsight(null);
    setSuggestError(null);
  }, []);

  return {
    aiResult,
    aiLoading,
    aiError,
    handleAnalyzeProcess,
    sectorInput,
    setSectorInput,
    isSuggesting,
    suggestError,
    orInsight,
    handleSuggestStructure,
    resetAiState,
  };
}
