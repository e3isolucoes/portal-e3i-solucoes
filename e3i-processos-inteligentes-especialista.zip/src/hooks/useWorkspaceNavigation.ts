import { useState, useRef, useCallback, useEffect } from "react";

export type WorkspaceView =
  | "EXECUTIVE"
  | "PORTFOLIO"
  | "PROCESSES"
  | "IMPROVEMENTS"
  | "OPERATIONS"
  | "COMPLIANCE"
  | "REPORTS"
  | "ADMINISTRATION"
  | "PUBLIC_SALES";

export type ProcessSubView = "MAPPER" | "BPM";

export type ProjectsSubView =
  | "overview"
  | "define"
  | "measure"
  | "analyze"
  | "improve"
  | "control"
  | "results"
  | "evidences"
  | "history";

export type AnalyzeTab = "decision" | "queuing" | "spc";

interface NavigationState {
  view: WorkspaceView;
  processSubView: ProcessSubView;
  projectsSubView: ProjectsSubView;
  analyzeTab: AnalyzeTab;
}

interface UseWorkspaceNavigationReturn {
  currentWorkspaceView: WorkspaceView;
  processSubView: ProcessSubView;
  projectsSubView: ProjectsSubView;
  analyzeTab: AnalyzeTab;
  setCurrentWorkspaceView: (v: string | ((prev: WorkspaceView) => string), bypassScroll?: boolean) => void;
  setProjectsSubView: (v: ProjectsSubView) => void;
  setAnalyzeTab: (v: AnalyzeTab) => void;
  handleNavigateBack: () => void;
  navigateToWorksite: (view: string) => void;
  isWorkHighlighted: boolean;
}

/**
 * Mapeia aliases de view de entrada para o view canônico + sub-view correto.
 * Centraliza a lógica que estava espalhada dentro de setCurrentWorkspaceView.
 */
function resolveNavigation(
  alias: string,
  prev: NavigationState
): NavigationState {
  const aliasMap: Record<string, Partial<NavigationState>> = {
    DIAGNOSTIC: { view: "IMPROVEMENTS", projectsSubView: "define" },
    E3I_INTELLIGENCE: { view: "IMPROVEMENTS", projectsSubView: "define" },
    DMAIC: { view: "IMPROVEMENTS", projectsSubView: "improve" },
    BI_STUDIO: { view: "IMPROVEMENTS", projectsSubView: "improve" },
    MAP: { view: "PROCESSES", processSubView: "MAPPER" },
    BPM: { view: "PROCESSES", processSubView: "BPM" },
    KANBAN: { view: "OPERATIONS" },
    OR_HUB: { view: "IMPROVEMENTS", projectsSubView: "analyze", analyzeTab: "queuing" },
    SIGMA_TREND: { view: "IMPROVEMENTS", projectsSubView: "analyze", analyzeTab: "spc" },
    REPORT: { view: "REPORTS" },
    CLIENT_PROJECTS: { view: "PORTFOLIO" },
    ADMIN: { view: "ADMINISTRATION" },
    SUBSCRIPTION_MANAGEMENT: { view: "ADMINISTRATION" },
    ROI_DASHBOARD: { view: "IMPROVEMENTS", projectsSubView: "results" },
    DASHBOARD_LEIGO: { view: "IMPROVEMENTS", projectsSubView: "overview" },
    ENTERPRISE_STUDIO: { view: "IMPROVEMENTS", projectsSubView: "overview" },
  };

  const resolved = aliasMap[alias];
  if (resolved) {
    return { ...prev, ...resolved };
  }

  // Alias não encontrado → assume que já é um WorkspaceView canônico
  return { ...prev, view: alias as WorkspaceView };
}

const SCROLL_RESTORE_THRESHOLD = 50; // px mínimos para restaurar scroll

export function useWorkspaceNavigation(
  initialView: WorkspaceView = "PUBLIC_SALES"
): UseWorkspaceNavigationReturn {
  const [navState, setNavState] = useState<NavigationState>({
    view: initialView,
    processSubView: "MAPPER",
    projectsSubView: "overview",
    analyzeTab: "decision",
  });

  // [PERF/UX FIX] Mapa de scroll por view, em vez de um único ref global.
  // Evita que a posição de scroll de uma view "vaze" para outra não relacionada.
  const scrollPositions = useRef<Map<WorkspaceView, number>>(new Map());

  const [viewHistory, setViewHistory] = useState<WorkspaceView[]>([]);
  const [isMovingBack, setIsMovingBack] = useState(false);
  const [isWorkHighlighted, setIsWorkHighlighted] = useState(false);

  // Restaura scroll após mudança de view — agora lê a posição DA VIEW ATUAL,
  // não a última posição salva globalmente.
  useEffect(() => {
    const target = scrollPositions.current.get(navState.view) ?? 0;
    if (target > SCROLL_RESTORE_THRESHOLD) {
      window.scrollTo(0, target);
      requestAnimationFrame(() => window.scrollTo(0, target));
    } else {
      window.scrollTo(0, 0); // view nova ou sem histórico → sempre começa no topo
    }
  }, [navState.view]);

  // Registra histórico (exceto quando estamos navegando de volta)
  useEffect(() => {
    if (isMovingBack) {
      setIsMovingBack(false);
      return;
    }
    setViewHistory((prev) => {
      if (prev.at(-1) === navState.view) return prev;
      return [...prev, navState.view].slice(-10);
    });
  }, [navState.view, isMovingBack]);

  const setCurrentWorkspaceView = useCallback(
    (
      value: string | ((prev: WorkspaceView) => string),
      bypassScroll = false
    ) => {
      setNavState((prev) => {
        if (!bypassScroll) {
          // Salva o scroll NA PRÓPRIA view que está sendo deixada — não em
          // um slot global que a próxima view herdaria incorretamente.
          scrollPositions.current.set(prev.view, window.scrollY);
        } else {
          scrollPositions.current.delete(prev.view);
        }

        const alias =
          typeof value === "function" ? value(prev.view) : value;
        return resolveNavigation(alias, prev);
      });
    },
    []
  );

  const setProjectsSubView = useCallback((v: ProjectsSubView) => {
    setNavState((prev) => ({ ...prev, projectsSubView: v }));
  }, []);

  const setAnalyzeTab = useCallback((v: AnalyzeTab) => {
    setNavState((prev) => ({ ...prev, analyzeTab: v }));
  }, []);

  const handleNavigateBack = useCallback(() => {
    // [PERF/UX FIX] Antes, "voltar" pulava completamente o mecanismo de
    // scroll (mexia em navState diretamente). Agora salva a posição atual
    // antes de voltar, igual a qualquer outra navegação.
    setNavState((prev) => {
      scrollPositions.current.set(prev.view, window.scrollY);
      return prev;
    });

    if (viewHistory.length > 1) {
      const newHistory = viewHistory.slice(0, -1);
      const prevView = newHistory.at(-1) as WorkspaceView;
      setIsMovingBack(true);
      setViewHistory(newHistory);
      setNavState((prev) => ({ ...prev, view: prevView }));
    } else {
      setNavState((prev) => ({ ...prev, view: "PORTFOLIO" }));
    }
  }, [viewHistory]);

  const navigateToWorksite = useCallback((view: string) => {
    setNavState((prev) => {
      scrollPositions.current.delete(prev.view);
      return resolveNavigation(view, prev);
    });

    // [NOTA] Esse setTimeout ainda é heurístico — depende do elemento já
    // existir no DOM em 150ms. Combinado com o prefetch de chunk lazy
    // recomendado em App.refactored.tsx (onMouseEnter do menu), a chance de
    // falha cai bastante, mas não é eliminada em conexões muito lentas.
    // Se precisar de garantia total, trocar por um MutationObserver
    // aguardando o elemento aparecer antes de fazer o scrollIntoView.
    setTimeout(() => {
      const el = document.getElementById("active-work-viewport");
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
        setIsWorkHighlighted(true);
        setTimeout(() => setIsWorkHighlighted(false), 1800);
      }
    }, 150);
  }, []);

  return {
    currentWorkspaceView: navState.view,
    processSubView: navState.processSubView,
    projectsSubView: navState.projectsSubView,
    analyzeTab: navState.analyzeTab,
    setCurrentWorkspaceView,
    setProjectsSubView,
    setAnalyzeTab,
    handleNavigateBack,
    navigateToWorksite,
    isWorkHighlighted,
  };
}
