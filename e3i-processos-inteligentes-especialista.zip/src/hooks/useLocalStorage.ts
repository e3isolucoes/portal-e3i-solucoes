import { useState, useEffect, useCallback, useRef } from "react";

interface UseLocalStorageOptions<T> {
  /** Chave do localStorage */
  key: string;
  /** Valor padrão caso a chave não exista ou a leitura falhe */
  defaultValue: T;
  /** Serializer: converte T para string antes de salvar. Padrão: JSON.stringify */
  serialize?: (value: T) => string;
  /** Deserializer: converte string de volta para T. Padrão: JSON.parse */
  deserialize?: (raw: string) => T;
  /** Atraso (ms) antes de persistir no localStorage após uma mudança. Padrão: 300 */
  debounceMs?: number;
}

export function useLocalStorage<T>({
  key,
  defaultValue,
  serialize = JSON.stringify,
  deserialize = JSON.parse,
  debounceMs = 300,
}: UseLocalStorageOptions<T>): [T, (value: T | ((prev: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw === null) return defaultValue;
      return deserialize(raw);
    } catch {
      return defaultValue;
    }
  });

  // [PERF FIX] Debounce da escrita — evita gravação síncrona a cada keystroke.
  const writeTimeoutRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (writeTimeoutRef.current) clearTimeout(writeTimeoutRef.current);

    writeTimeoutRef.current = setTimeout(() => {
      try {
        localStorage.setItem(key, serialize(storedValue));
      } catch {
        // Ignora erros de escrita (ex: modo privado / cota excedida)
      }
    }, debounceMs);

    return () => {
      if (writeTimeoutRef.current) clearTimeout(writeTimeoutRef.current);
    };
  }, [key, storedValue, serialize, debounceMs]);

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      setStoredValue((prev) =>
        typeof value === "function" ? (value as (prev: T) => T)(prev) : value
      );
    },
    []
  );

  return [storedValue, setValue];
}

// ---------------------------------------------------------------------------
// Atalhos tipados para as chaves utilizadas no projeto
// (elimina strings mágicas espalhadas pelo codebase)
// ---------------------------------------------------------------------------

export const LS_KEYS = {
  TRAINING_MODE: "lss_training_mode",
  BUSINESS_TYPE: "lss_business_type",
  ENABLED_VIEWS: "lss_enabled_views",
  ONBOARDING_SHOWN: "e3i_onboarding_shown",
  CURRENT_CARGO: "lss_current_cargo",
  DELEGATIONS: "lss_delegations",
  USABILITY_MODE: "lss_usability_mode",
  USABILITY_LOCKED: "lss_usability_locked",
  ROLE_PERMISSIONS: "lss_role_permissions",
  ACTIVE_USER: "six_sigma_active_user",
  ACTIVE_COMPANY_ID: "lss_active_company_id",
  SMTP_ENABLED: "lss_smtp_enabled",
  SMTP_HOST: "lss_smtp_host",
  SMTP_PORT: "lss_smtp_port",
  SMTP_USER: "lss_smtp_user",
  // [SECURITY NOTE — fora do escopo de performance/UX, mas crítico]
  // SMTP_PASS é persistido em texto puro no localStorage do navegador.
  // Qualquer extensão de navegador ou script no mesmo domínio consegue lê-lo.
  // Recomendação: mover a senha SMTP para o backend (nunca trafegar para o
  // client) e o frontend apenas referenciar "configurado / não configurado".
  SMTP_PASS: "lss_smtp_pass",
  SMTP_FROM_NAME: "lss_smtp_from_name",
  SMTP_FROM_EMAIL: "lss_smtp_from_email",
  SMTP_SSL: "lss_smtp_ssl",
  SMTP_LOGS: "lss_smtp_logs",
  TWILIO_ENABLED: "lss_twilio_enabled",
  TWILIO_ACCOUNT_SID: "lss_twilio_account_sid",
  TWILIO_AUTH_TOKEN: "lss_twilio_auth_token",
  TWILIO_FROM_NUMBER: "lss_twilio_from_number",
} as const;

export type LsKey = (typeof LS_KEYS)[keyof typeof LS_KEYS];
