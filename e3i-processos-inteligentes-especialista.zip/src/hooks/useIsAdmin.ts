import { useMemo } from "react";
import { isAdmin } from "../config/adminConfig";

export function useIsAdmin(user: { email?: string; role?: string } | null, currentCargo?: string) {
  return useMemo(() => {
    return isAdmin(user, currentCargo);
  }, [user?.email, user?.role, currentCargo]);
}
