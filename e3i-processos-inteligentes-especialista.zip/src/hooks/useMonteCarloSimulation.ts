import { useState, useEffect, useCallback, useRef } from "react";
import { ProcessStep, SimulationLog } from "../types";
import { runMonteCarloSimulation } from "../utils";

export interface SimulationData {
  logs: SimulationLog[];
  dailyAverages: { day: number; cycleTime: number; defectRate: number; wip: number }[];
}

/**
 * Hook to manage Monte Carlo simulation state and automatic executions.
 * Isolates simulation concerns, prevents blocking the main UI thread during recalculation,
 * and encapsulates the lifecycle of simulation metrics.
 */
export function useMonteCarloSimulation(steps: ProcessStep[], arrivalRate: number) {
  const [simulationData, setSimulationData] = useState<SimulationData | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const runSimulation = useCallback(() => {
    setIsSimulating(true);

    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    // Debounce/delay the simulation execution slightly to prevent UI blocking during rapid updates
    timerRef.current = setTimeout(() => {
      try {
        const result = runMonteCarloSimulation(steps, arrivalRate);
        setSimulationData(result);
      } catch (error) {
        console.error("Failed to run Monte Carlo Simulation:", error);
      } finally {
        setIsSimulating(false);
      }
    }, 400);
  }, [steps, arrivalRate]);

  useEffect(() => {
    runSimulation();

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [runSimulation]);

  return {
    simulationData,
    isSimulating,
    runSimulation,
  };
}
