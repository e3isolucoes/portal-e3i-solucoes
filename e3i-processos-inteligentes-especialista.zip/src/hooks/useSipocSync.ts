import { useEffect, useRef, Dispatch, SetStateAction } from "react";
import { ProcessStep, Sipoc } from "../types";

/**
 * Hook to automatically synchronize the process step names with the SIPOC processDescription field.
 * This ensures that whenever process steps are added, removed, or updated in the VisualProcessMapper,
 * the macro process sequence remains perfectly aligned and updated.
 */
export function useSipocSync(
  steps: ProcessStep[],
  sipoc: Sipoc,
  setSipoc: Dispatch<SetStateAction<Sipoc>> | ((s: Sipoc | ((prev: Sipoc) => Sipoc)) => void)
) {
  const previousStepsStr = useRef("");

  useEffect(() => {
    if (!steps || steps.length === 0) return;

    // Generate a unified sequence of step names joined by ' -> '
    const stepNames = steps.map((s) => s.name.trim()).filter(Boolean);
    const formattedDescription = stepNames.join(" -> ");

    // Check if the steps sequence or names have actually changed to avoid unnecessary updates
    const currentStepsStr = JSON.stringify(stepNames);
    if (previousStepsStr.current === currentStepsStr) {
      return;
    }

    previousStepsStr.current = currentStepsStr;

    if (sipoc.processDescription !== formattedDescription) {
      setSipoc((prev) => {
        if (prev.processDescription === formattedDescription) return prev;
        return {
          ...prev,
          processDescription: formattedDescription,
        };
      });
    }
  }, [steps, sipoc.processDescription, setSipoc]);
}
