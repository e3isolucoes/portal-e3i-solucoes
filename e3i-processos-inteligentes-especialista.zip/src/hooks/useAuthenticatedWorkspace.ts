import { useEffect, useRef } from "react";
import { ProcessStep, ProjectCharter, Sipoc, ControlPlan } from "../types";
import { CompanyProjectRepository } from "../repositories/CompanyProjectRepository";
import { generateDefaultDeliverables, INITIAL_STEPS } from "../shared/utils/initialStates";
import { getInitialStepsForArea } from "../utils/areaPresets";
import { getInitialTemplate } from "../utils/templateHelper";

export interface UseAuthenticatedWorkspaceParams {
  activeCompanyId: string | null;
  activeWorkspaceProjectId: string | null;
  isTrainingModeActive: boolean;
  projectDataStore: Record<string, any>;
  globalCompanies: any[];
  globalProjects: any[];
  activeUser: any;
  setSteps: (steps: ProcessStep[] | ((prev: ProcessStep[]) => ProcessStep[])) => void;
  setArrivalRate: (rate: number | ((prev: number) => number)) => void;
  setCharter: (charter: ProjectCharter | ((prev: ProjectCharter) => ProjectCharter)) => void;
  setSipoc: (sipoc: Sipoc | ((prev: Sipoc) => Sipoc)) => void;
  setControlPlans: (plans: ControlPlan[] | ((prev: ControlPlan[]) => ControlPlan[])) => void;
  setProcessesByArea: (pba: any) => void;
  setActiveAreaId: (areaId: string) => void;
  setDeliverables: (deliverables: any) => void;
  setProjectActions: (actions: any) => void;
  setHistory: (history: any) => void;
  setProjectDetails: (details: any) => void;
}

export function useAuthenticatedWorkspace({
  activeCompanyId,
  activeWorkspaceProjectId,
  isTrainingModeActive,
  projectDataStore,
  globalCompanies,
  globalProjects,
  activeUser,
  setSteps,
  setArrivalRate,
  setCharter,
  setSipoc,
  setControlPlans,
  setProcessesByArea,
  setActiveAreaId,
  setDeliverables,
  setProjectActions,
  setHistory,
  setProjectDetails
}: UseAuthenticatedWorkspaceParams) {
  const loadedProjectIdRef = useRef<string | null>(null);
  const loadedCompanyIdRef = useRef<string | null>(null);

  useEffect(() => {
    // If the active project and company are ALREADY loaded in state for this project ID,
    // skip re-populating state when projectDataStore updates due to local edits.
    if (
      activeWorkspaceProjectId &&
      activeCompanyId &&
      loadedProjectIdRef.current === activeWorkspaceProjectId &&
      loadedCompanyIdRef.current === activeCompanyId &&
      projectDataStore[activeWorkspaceProjectId]
    ) {
      return;
    }

    // Fetch available companies and projects lists from global state or local repository
    const companies = globalCompanies && globalCompanies.length > 0
      ? globalCompanies
      : CompanyProjectRepository.getCompanies();

    const projects = globalProjects && globalProjects.length > 0
      ? globalProjects
      : CompanyProjectRepository.getProjects();

    const currentComp = activeCompanyId ? companies.find((c: any) => c.id === activeCompanyId) : null;
    const currentProj = activeWorkspaceProjectId ? projects.find((p: any) => p.id === activeWorkspaceProjectId) : null;

    const isCompanyValid = !!currentComp;
    const isProjectValid = !!currentProj && currentProj.companyId === activeCompanyId;

    // Reset workspace state variables to clean empty defaults when project/company is null or invalid
    const resetToEmptyState = () => {
      if (loadedProjectIdRef.current === null && loadedCompanyIdRef.current === activeCompanyId) {
        return;
      }
      loadedProjectIdRef.current = null;
      loadedCompanyIdRef.current = activeCompanyId;
      setSteps([]);
      setArrivalRate(10);
      setCharter({
        title: activeCompanyId ? "Nenhum Projeto Selecionado" : "Nenhuma Empresa Selecionada",
        problemStatement: activeCompanyId
          ? "Selecione ou crie um projeto para visualizar os dados."
          : "Selecione uma empresa e um projeto para iniciar.",
        goal: "-",
        metric: "cycle_time",
        targetValue: 0
      });
      setSipoc({ suppliers: "", inputs: "", processDescription: "", outputs: "", customers: "" });
      setControlPlans([]);
      setProjectActions([]);
      setDeliverables([]);
      setHistory([]);
      setActiveAreaId("core_ops");
      setProcessesByArea({
        finance: [],
        it_governance: [],
        hr: [],
        data_ai: [],
        legal_risk: [],
        core_inbound: [],
        core_ops: [],
        core_outbound: [],
        core_sales: []
      });
      setProjectDetails({
        companyName: currentComp?.name || "Nenhuma Empresa Selecionada",
        unitName: "-",
        processName: "Nenhum Projeto Ativo",
        responsibleName: activeUser?.fullName || "-",
        sponsorName: "-",
        startDate: "",
        deadlineDate: "",
        expectedImpact: "-",
        realizedImpact: "-",
        lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR"),
        status: "Em Progresso",
        isLocked: false
      });
    };

    // SCENARIO 1: Null or invalid activeCompanyId OR activeWorkspaceProjectId OR mismatched project
    if (!activeCompanyId || !activeWorkspaceProjectId || !isCompanyValid || !isProjectValid) {
      resetToEmptyState();
      return;
    }

    // SCENARIO 2: Valid active project belonging to active company
    const data = projectDataStore[activeWorkspaceProjectId];
    if (data && data.companyId === activeCompanyId) {
      setProcessesByArea(data.processesByArea || {
        finance: [], it_governance: [], hr: [], data_ai: [], legal_risk: [],
        core_inbound: [], core_ops: [], core_outbound: [], core_sales: []
      });
      setSteps(data.steps || []);
      setArrivalRate(data.arrivalRate || 10);
      setCharter(
        data.charter || {
          title: currentProj?.name || "Projeto DMAIC",
          problemStatement: currentProj?.objective || "Mapeamento inicial de oportunidades e causas raiz.",
          goal: "Otimizar o tempo de ciclo e a qualidade dos entregáveis.",
          metric: "cycle_time",
          targetValue: 30
        }
      );
      setSipoc(data.sipoc || { suppliers: "", inputs: "", processDescription: "", outputs: "", customers: "" });
      setControlPlans(data.controlPlans || []);
      setActiveAreaId(data.activeAreaId || "core_ops");
      setDeliverables(data.deliverables || generateDefaultDeliverables(activeWorkspaceProjectId));
      setProjectActions(data.projectActions || []);
      setHistory(data.projectHistory || []);
      setProjectDetails(
        data.projectDetails || {
          companyName: currentComp?.name || "Empresa Ativa",
          unitName: "Unidade Operacional Principal",
          processName: currentProj?.name || "Otimização de Processos DMAIC",
          responsibleName: activeUser?.fullName || "Líder LSS",
          sponsorName: "Diretoria de Operações",
          startDate: new Date().toISOString().split("T")[0],
          deadlineDate: new Date(Date.now() + 90 * 86400000).toISOString().split("T")[0],
          expectedImpact: "Otimização de capacidade e eliminação de desperdícios.",
          realizedImpact: "Medição em andamento.",
          lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR"),
          status: "Em Progresso",
          isLocked: false
        }
      );
      loadedProjectIdRef.current = activeWorkspaceProjectId;
      loadedCompanyIdRef.current = activeCompanyId;
    } else {
      // Project is not in projectDataStore yet
      if (isTrainingModeActive) {
        const initialPba = {
          finance: getInitialStepsForArea("finance", []),
          it_governance: getInitialStepsForArea("it_governance", []),
          hr: getInitialStepsForArea("hr", []),
          data_ai: getInitialStepsForArea("data_ai", []),
          legal_risk: getInitialStepsForArea("legal_risk", []),
          core_inbound: getInitialStepsForArea("core_inbound", []),
          core_ops: getInitialTemplate().steps,
          core_outbound: getInitialStepsForArea("core_outbound", []),
          core_sales: getInitialStepsForArea("core_sales", [])
        };
        setProcessesByArea(initialPba);
        setSteps(getInitialTemplate().steps);
        setArrivalRate(getInitialTemplate().arrivalRate);
        setCharter(getInitialTemplate().charter);
        setSipoc(getInitialTemplate().sipoc);
        setControlPlans(getInitialTemplate().controlPlans);
        setActiveAreaId("core_ops");
        setDeliverables(generateDefaultDeliverables(activeWorkspaceProjectId));
        setProjectActions([]);
        setHistory([
          {
            id: `hist-${Date.now()}`,
            timestamp: new Date().toLocaleDateString("pt-BR"),
            user: activeUser?.fullName || "Líder LSS",
            action: "Criou novo projeto [DEMO]",
            description: "Instanciou escopos para otimização do throughput.",
            type: "other",
            ip: "127.0.0.1"
          }
        ]);
        setProjectDetails({
          companyName: currentComp?.name || "Empresa Ativa (Demo)",
          unitName: "Planta Industrial 02 S/A",
          processName: currentProj?.name || "Linha de Processo Demo",
          responsibleName: activeUser?.fullName || "Líder LSS",
          sponsorName: "Diretoria de Operações",
          startDate: new Date().toISOString().split("T")[0],
          deadlineDate: new Date(Date.now() + 90 * 86400000).toISOString().split("T")[0],
          expectedImpact: "Ganhos de produtividade e redução de desperdícios.",
          realizedImpact: "Medição inicial.",
          lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR"),
          status: "Em Progresso",
          isLocked: false
        });
      } else {
        // Clean production initialization for new project
        const cleanPba = {
          finance: [], it_governance: [], hr: [], data_ai: [], legal_risk: [],
          core_inbound: [], core_ops: [], core_outbound: [], core_sales: []
        };
        setProcessesByArea(cleanPba as any);
        setSteps([]);
        setArrivalRate(10);
        setCharter({
          title: currentProj?.name || "Novo Projeto DMAIC",
          problemStatement: currentProj?.objective || "Mapeamento inicial de oportunidades e causas raiz.",
          goal: "Garantir previsibilidade e redução de desperdícios.",
          metric: "cycle_time",
          targetValue: 30
        });
        setSipoc({ suppliers: "", inputs: "", processDescription: "", outputs: "", customers: "" });
        setControlPlans([]);
        setActiveAreaId("core_ops");
        setDeliverables(generateDefaultDeliverables(activeWorkspaceProjectId));
        setProjectActions([]);
        setHistory([
          {
            id: `hist-${Date.now()}`,
            timestamp: new Date().toLocaleDateString("pt-BR"),
            user: activeUser?.fullName || "Líder LSS",
            action: "Projeto Criado",
            description: `Projeto ${currentProj?.name || ""} instanciado com sucesso.`,
            type: "other",
            ip: "127.0.0.1"
          }
        ]);
        setProjectDetails({
          companyName: currentComp?.name || "Empresa Ativa",
          unitName: "Unidade Operacional Principal",
          processName: currentProj?.name || "Mapeamento DMAIC",
          responsibleName: activeUser?.fullName || "Líder LSS",
          sponsorName: "Diretoria de Operações",
          startDate: new Date().toISOString().split("T")[0],
          deadlineDate: new Date(Date.now() + 90 * 86400000).toISOString().split("T")[0],
          expectedImpact: "Eliminação de desperdícios e ganho de qualidade.",
          realizedImpact: "Mapeamento inicial.",
          lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR"),
          status: "Em Progresso",
          isLocked: false
        });
      }
      loadedProjectIdRef.current = activeWorkspaceProjectId;
      loadedCompanyIdRef.current = activeCompanyId;
    }
  }, [
    activeCompanyId,
    activeWorkspaceProjectId,
    isTrainingModeActive,
    projectDataStore,
    globalCompanies,
    globalProjects,
    activeUser
  ]);

  return {
    loadedProjectId: loadedProjectIdRef.current,
    isWorkspaceValid: !!activeCompanyId && !!activeWorkspaceProjectId && loadedProjectIdRef.current === activeWorkspaceProjectId
  };
}
