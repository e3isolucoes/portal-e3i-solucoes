/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, FormEvent, lazy, Suspense, Fragment, useMemo, cloneElement } from "react";
import { buildAuthenticatedUser, hasPermission, PermissionGuard, Permission, AuthenticatedUser } from "./utils/rbac";
import {
  Play,
  Plus,
  Trash2,
  Cpu,
  Layers,
  Activity,
  FileText,
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  Sliders,
  Sparkles,
  Info,
  Check,
  ChevronRight,
  ChevronLeft,
  HelpCircle,
  Download,
  ArrowRight,
  Presentation,
  Kanban,
  X,
  Send,
  Briefcase,
  Target,
  Menu,
  Bell,
  BookOpen,
  UploadCloud,
  ShieldAlert,
  ShieldCheck,
  LayoutDashboard,
  ChevronDown,
  Search,
  Loader2,
  AlertCircle,
  Compass,
  Network,
  Users,
  Megaphone
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { ProcessStep, ProjectCharter, Sipoc, ControlPlan, SimulationLog, DmaicPhaseType, ScheduledAudit } from "./types";
import { PROCESS_TEMPLATES, ProcessTemplate } from "./presets";
import { AreaId, CORPORATE_AREAS, getInitialStepsForArea } from "./utils/areaPresets";
import { calculateProcessMetrics, runMonteCarloSimulation } from "./utils";
import CountUp from "./components/CountUp";
import { useProcessCopilot } from "./hooks/useProcessCopilot";
import { useSipocSync } from "./hooks/useSipocSync";
import { useMonteCarloSimulation } from "./hooks/useMonteCarloSimulation";
import { useAuthenticatedWorkspace } from "./hooks/useAuthenticatedWorkspace";
import { AssistenteE3I } from "./components/AssistenteE3I";
import { useToast } from "./shared/ui/Toast";
import EnterpriseTemplatesHub from "./components/EnterpriseTemplatesHub";

// Repositories & Services Layers (Sprint 3 Architecture Optimization)
import { UserRepository } from "./repositories/UserRepository";
import { CompanyProjectRepository } from "./repositories/CompanyProjectRepository";
import { AiService } from "./services/AiService";
import { useBusinessContext } from "./contexts/BusinessContext";
import { UsabilityMode, normalizeUsabilityMode } from "./domain/usabilityMode";
import {
  UserProfileRole,
  PermissionType,
  DelegationRecord,
  checkPermission,
  checkModuleAllowed,
  getCustomKpisForRole,
  getActiveDelegationForUser
} from "./utils/permissionMatrix";
import { RoleDashboards } from "./components/RoleDashboards";
import { mapIndustryToBusinessType, getIndustryIcon, BusinessType } from "./utils/industry";
export type { BusinessType };
import { LoadingFallback } from "./components/LoadingFallback";
import { getInitialTemplate } from "./utils/templateHelper";

// Static Loaded Components
import VisualProcessMapper from "./components/VisualProcessMapper";
import ProcessDesignRoom from "./components/ProcessDesignRoom";
import E3IProcessosInteligentes from "./components/E3IProcessosInteligentes";
import ProcessOptimizationWizardPage from "./features/process-optimization/pages/ProcessOptimizationWizardPage";
import SigmaTrendDashboard from "./components/SigmaTrendDashboard";
import BottleneckDetector from "./components/BottleneckDetector";
import DmaicWizard from "./components/DmaicWizard";
import DiagnosticWizard from "./components/DiagnosticWizard";
import StepDetailModal from "./components/StepDetailModal";
import OrQualityHub from "./components/OrQualityHub";
import ReportPresentationGenerator from "./components/ReportPresentationGenerator";
import WipKanbanBoard from "./components/WipKanbanBoard";
import PdcaFlowCoach from "./components/PdcaFlowCoach";
import EnterpriseArchitectureSuite from "./components/EnterpriseArchitectureSuite";
import EnterpriseOverviewDashboard from "./components/EnterpriseOverviewDashboard";
import MethodologyContractor from "./components/MethodologyContractor";
import AdminPanel from "./components/AdminPanel";
import BiStudio from "./components/BiStudio";
import AccessDeniedBlock from "./components/AccessDeniedBlock";
import ProcessRepositoryStudio from "./components/ProcessRepositoryStudio";
import StrategyPage from "./features/strategy/StrategyPage";
import OrganizationStructurePage from "./features/organization-structure/OrganizationStructurePage";
import GovernancePage from "./features/governance/GovernancePage";
import ChangeManagementPage from "./features/change-management/ChangeManagementPage";
import BusinessReorganizationPlan from "./features/business-reorganization/BusinessReorganizationPlan";
import EnterpriseExecutiveDashboard from "./features/results/EnterpriseExecutiveDashboard";
import EnterpriseExecutiveReport from "./features/results/EnterpriseExecutiveReport";
import ClientPortal from "./components/ClientPortal";
import SharePortalModal from "./components/SharePortalModal";
import CompanyProjectsModule from "./components/CompanyProjectsModule";
import GlobalCycleTimeHistogram from "./components/GlobalCycleTimeHistogram";
import AiMentorGuide from "./components/AiMentorGuide";
import DashboardLeigo from "./components/DashboardLeigo";
import ParetoControle from "./components/ParetoControle";
import AdvancedSimulationStudio from "./components/AdvancedSimulationStudio";

import OnboardingGuided from "./components/OnboardingGuided";
import RoiDashboard from "./components/RoiDashboard";
import SubscriptionModules from "./components/SubscriptionModules";
import PublicSalesLanding from "./components/PublicSalesLanding";
import ProcessExecutionMiner from "./components/ProcessExecutionMiner";
import BpmDocumentSuite from "./components/BpmDocumentSuite";
import AuditSuggestion from "./components/AuditSuggestion";
import InitialWorkspaceSetupCover from "./components/InitialWorkspaceSetupCover";
import ProcessesPage from "./components/ProcessesPage";

import Phase4ProjectPanel from "./components/Phase4ProjectPanel";
import E3ILogo from "./components/E3ILogo";
import EmptyState from "./components/EmptyState";

import AuthCover, { LoggedUser } from "./components/AuthCover";
import { User, LogOut, Award, Building2 } from "lucide-react";
import { auth } from "./firebase";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
  ScatterChart,
  Scatter,
  ZAxis,
  ComposedChart,
  PieChart,
  Pie,
} from "recharts";

const AnyBarChart = BarChart as any;
const AnyLineChart = LineChart as any;

import {
  BUSINESS_TERMS,
  getVisibleWorkspaceViews,
  INITIAL_STEPS,
  INITIAL_CHARTER,
  generateDefaultDeliverables,
  INITIAL_SIPOC,
  INITIAL_CONTROL_PLAN
} from "./shared/utils/initialStates";

export { BUSINESS_TERMS, getVisibleWorkspaceViews, INITIAL_STEPS, INITIAL_CHARTER, generateDefaultDeliverables, INITIAL_SIPOC, INITIAL_CONTROL_PLAN };

export default function App() {
  const toast = useToast();
  // Application states
  const [steps, setSteps] = useState<ProcessStep[]>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return getInitialTemplate().steps;
    }
    return [];
  });
  const [arrivalRate, setArrivalRate] = useState<number>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return getInitialTemplate().arrivalRate;
    }
    return 10;
  });
  const [charter, setCharter] = useState<ProjectCharter>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return getInitialTemplate().charter;
    }
    return {
      title: "Nenhum Projeto Selecionado",
      problemStatement: "Selecione ou crie um projeto para visualizar os dados.",
      goal: "-",
      metric: "cycle_time",
      targetValue: 0
    };
  });
  const [sipoc, setSipoc] = useState<Sipoc>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return getInitialTemplate().sipoc;
    }
    return { suppliers: "", inputs: "", processDescription: "", outputs: "", customers: "" };
  });
  const [controlPlans, setControlPlans] = useState<ControlPlan[]>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return getInitialTemplate().controlPlans;
    }
    return [];
  });

  // Synchronize process steps with SIPOC process description automatically
  useSipocSync(steps, sipoc, setSipoc);

  // Sidebar state (collapsed vs. expanded) with standard localStorage persistence
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("e3i_sidebar_collapsed");
      return saved === "true";
    }
    return false;
  });

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(prev => {
      const nextVal = !prev;
      if (typeof window !== "undefined") {
        localStorage.setItem("e3i_sidebar_collapsed", String(nextVal));
      }
      return nextVal;
    });
  };

  // Decoupled stochastic simulation and Monte Carlo recalculation state
  const {
    simulationData,
    isSimulating,
    runSimulation: handleRunSimulation
  } = useMonteCarloSimulation(steps, arrivalRate);

  const [isTemplatesHubOpen, setIsTemplatesHubOpen] = useState(false);

  const handleApplyTemplate = (
    newSteps: ProcessStep[],
    newCharter: ProjectCharter,
    newSipoc: Sipoc,
    newRaci: any[],
    bizType: "INDUSTRIAL" | "SERVICES" | "RETAIL" | "LOGISTICS" | "TECHNOLOGY" | "HEALTHCARE" | "FINANCE" | "HUMAN_RESOURCES"
  ) => {
    setSteps(newSteps);
    setCharter(newCharter);
    setSipoc(newSipoc);
    
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_raci_list", JSON.stringify(newRaci));
      window.dispatchEvent(new Event("storage"));
    }
    
    setBusinessType(bizType);
    setIsTemplatesHubOpen(false);
    setCurrentWorkspaceView("MAP");
  };

  const [activeUser, setActiveUser] = useState<LoggedUser | null>(null);
  const [isTrainingModeActive, setIsTrainingModeActive] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("lss_training_mode") === "true";
    }
    return false;
  });

  const handleToggleTrainingMode = (active: boolean) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("lss_training_mode", active ? "true" : "false");
      setIsTrainingModeActive(active);
      window.dispatchEvent(new Event("lss_training_mode_changed"));
      if (!active) {
        window.location.reload();
      }
    }
  };

  useEffect(() => {
    const unsubscribe = UserRepository.subscribeToAuth((profile, firebaseUser, workspaceData) => {
      if (firebaseUser && profile) {
        if (workspaceData) {
          if (workspaceData.activeCompanyId) {
            setActiveCompanyId(workspaceData.activeCompanyId);
          }
          if (workspaceData.activeProjectId) {
            setActiveWorkspaceProjectId(workspaceData.activeProjectId);
          }
        }
        
        // Decoupled admin check using structural Role/Belt properties
        const isAdmin = 
          profile.role === "Admin" || 
          profile.role === "Administrador" || 
          profile.belt === "Master Black Belt";
        
        CompanyProjectRepository.startFirestoreSync(firebaseUser.uid, isAdmin);
        setActiveUser(profile);
      } else {
        const loggedOut = localStorage.getItem("lss_logged_out") === "true";
        if (loggedOut) {
          setActiveUser(null);
        } else {
          const defaultUser: LoggedUser = {
            fullName: "Marco Antônio Miranda",
            email: "admin@sixsigma.com",
            role: "Especialista Master Black Belt",
            belt: "Master Black Belt",
            planHired: "Licença Premium Black Belt"
          };
          setActiveUser(defaultUser);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const [activeDetailStepId, setActiveDetailStepId] = useState<string | null>(null);
  const [selectedFocusStepId, setSelectedFocusStepId] = useState<string>("ALL");
  const [sharePortalModalOpen, setSharePortalModalOpen] = useState(false);

  const [showCopilot, setShowCopilot] = useState<boolean>(false);
  const [copilotFlash, setCopilotFlash] = useState<string | null>(null);

  const triggerFlash = (msg: string) => {
    setCopilotFlash(msg);
    setTimeout(() => {
      setCopilotFlash(null);
    }, 4000);
  };

  const {
    copilotHistory,
    filteredHistory,
    copilotInput,
    setCopilotInput,
    isCopilotProcessing,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    handleCopilotRequest,
    addCustomKaizenAction,
    clearHistory
  } = useProcessCopilot({
    steps,
    setSteps,
    arrivalRate,
    triggerFlash
  });

  const handleApplyBalanceamentoGargalo = () => {
    const stats_info = calculateProcessMetrics(steps, arrivalRate);
    const btlName = stats_info.bottleneckStepName;
    const bottleneck = steps.find(s => s.name === btlName);
    
    if (!bottleneck) {
      triggerFlash("Nenhum gargalo ativo pôde ser balanceado no momento.");
      return;
    }
    
    let fastest: ProcessStep | null = null;
    let minTime = 99999;
    steps.forEach(s => {
      if (s.id !== bottleneck.id && s.processingTime < minTime) {
        minTime = s.processingTime;
        fastest = s;
      }
    });

    if (!fastest) {
      triggerFlash("Processo possui poucas etapas para efetuar transferência de carga.");
      return;
    }

    const transferAmount = parseFloat(Math.min(bottleneck.processingTime * 0.2, 2.0).toFixed(1));
    if (bottleneck.processingTime - transferAmount < 0.5) {
      triggerFlash("O gargalo já opera no limite técnico mínimo de tempo.");
      return;
    }

    const updatedSteps = steps.map(s => {
      if (s.id === bottleneck.id) {
        return { ...s, processingTime: parseFloat((s.processingTime - transferAmount).toFixed(1)) };
      }
      if (fastest && s.id === fastest.id) {
        return { ...s, processingTime: parseFloat((s.processingTime + transferAmount).toFixed(1)) };
      }
      return s;
    });

    setSteps(updatedSteps);
    addCustomKaizenAction(`Balanceamento Kaizen de Fluxo: Transferida carga de tempo (${transferAmount} min) de '${bottleneck.name}' para '${fastest?.name}', reduzindo estresse estocástico no gargalo.`);
    triggerFlash(`⚡ Balanceamento Realizado! Transferido ${transferAmount} min de '${bottleneck.name}' para '${fastest?.name}'.`);
  };

  const handleApplyVariabilidadeKaizen = () => {
    const updatedSteps = steps.map(s => ({
      ...s,
      standardDeviation: parseFloat(Math.max(0.1, s.standardDeviation * 0.73).toFixed(2))
    }));
    setSteps(updatedSteps);
    addCustomKaizenAction("Variabilidade Mitigada (Kaizen / SMED): Reduzidos desvios padrão estocásticos de todas as etapas em 27% para mitigação de filas.");
    triggerFlash("⚙️ Estabilidade Garantida! Variabilidade (desvio padrão) reduzida em 27% em todo o fluxo.");
  };

  const handleApplyPokaYokeYield = () => {
    let count = 0;
    const updatedSteps = steps.map(s => {
      if (s.yieldRate < 0.985) {
        count++;
        return { ...s, yieldRate: parseFloat(Math.min(0.999, s.yieldRate + 0.03).toFixed(3)) };
      }
      return s;
    });

    if (count === 0) {
      triggerFlash("Todas as etapas já possuem rendimento (yield rate) excelente superior a 98.5%!");
      return;
    }

    setSteps(updatedSteps);
    addCustomKaizenAction(`Aprimoramento Poka-Yoke: Elevado yield rate em ${count} etapa(s) de qualidade crítica subpar.`);
    triggerFlash(`🔬 Poka-Yoke Aplicado! Yield rate incrementado em +3.0% em ${count} etapa(s) críticas de qualidade.`);
  };

  const handleApplyStaffSizingIncrement = () => {
    const stats_info = calculateProcessMetrics(steps, arrivalRate);
    const btlName = stats_info.bottleneckStepName;
    const bottleneck = steps.find(s => s.name === btlName);

    if (!bottleneck) {
      triggerFlash("Nenhum gargalo ativo pôde ser localizado.");
      return;
    }

    if (bottleneck.resourceCount >= 5) {
      triggerFlash(`O posto '${bottleneck.name}' já atingiu o limite máximo de 5 operadores paralelos.`);
      return;
    }

    const updatedSteps = steps.map(s => {
      if (s.id === bottleneck.id) {
        return { ...s, resourceCount: s.resourceCount + 1 };
      }
      return s;
    });

    setSteps(updatedSteps);
    addCustomKaizenAction(`Aceleração de Vazão: Adicionado +1 operador/servidor no posto gargalo '${bottleneck.name}' (Total: ${bottleneck.resourceCount + 1} operadores).`);
    triggerFlash(`👥 Staff Expandido! Adicionado +1 operador no gargalo '${bottleneck.name}' para maximizar vazão.`);
  };

  const handleAutoAddBottleneckControlPlan = () => {
    const stats_info = calculateProcessMetrics(steps, arrivalRate);
    const btlName = stats_info.bottleneckStepName;
    const bottleneck = steps.find(s => s.name === btlName);

    if (!bottleneck) {
      triggerFlash("Nenhum posto de trabalho gargalo pôde ser identificado.");
      return;
    }

    const targetVal = parseFloat(bottleneck.processingTime.toFixed(2));
    const stdDevVal = bottleneck.standardDeviation;
    // UCL is average + 3 * stdDev
    const uclVal = parseFloat((targetVal + 3 * stdDevVal).toFixed(2));
    // LCL is average - 3 * stdDev (capped at 0.1 to avoid negative times)
    const lclVal = parseFloat(Math.max(0.1, targetVal - 3 * stdDevVal).toFixed(2));

    const newPlan: ControlPlan = {
      id: `cp-gargalo-${Date.now()}`,
      stepName: `[GARGALO] ${bottleneck.name}`,
      metric: "Tempo de Ciclo Ocupado (min)",
      target: targetVal,
      lcl: lclVal,
      ucl: uclVal,
      frequency: "Automatizado / Contínuo",
      responsible: "Time Kaizen & CEP Integrado",
      reactionPlan: `Disparar Alarme no Co-Piloto! Remanejar operador secundário e mitigar gargalo no posto ${bottleneck.name}.`,
      currentReading: targetVal,
      enableAlarm: true
    };

    setControlPlans(prev => {
      // Avoid duplicate plans for the exact same step name to keep it clean
      const filtered = prev.filter(p => p.stepName !== newPlan.stepName);
      return [...filtered, newPlan];
    });

    triggerFlash(`📈 Plano de Controle focado em Gargalo (${bottleneck.name}) ativado com limites automatizados LCL: ${lclVal}min / UCL: ${uclVal}min baseados no Desvio Padrão atual σ: ${stdDevVal}min!`);
  };

  const INITIAL_PROCESSES_BY_AREA: Record<AreaId, ProcessStep[]> = {
    finance: [],
    it_governance: [],
    hr: [],
    data_ai: [],
    legal_risk: [],
    core_inbound: [],
    core_ops: typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true" ? getInitialTemplate().steps : [],
    core_outbound: [],
    core_sales: []
  };

  const [activeAreaId, setActiveAreaId] = useState<AreaId>("core_ops");
  const [processesByArea, setProcessesByArea] = useState<Record<AreaId, ProcessStep[]>>(() => INITIAL_PROCESSES_BY_AREA);

  // === FASE 3: ESTADOS DE NAVEGAÇÃO UNIFICADA E REPOSITÓRIO DE EVIDÊNCIAS ===
  const [processSubView, setProcessSubView] = useState<"MAPPER" | "BPM">("MAPPER");
  const [projectsSubView, setProjectsSubView] = useState<"overview" | "define" | "measure" | "analyze" | "improve" | "control" | "results" | "evidences" | "history">("overview");
  const [projectEvidences, setProjectEvidences] = useState<any[]>(() => {
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return [
        { id: "ev-101", name: "Project-Charter-Aprovado-v3.pdf", size: "320 KB", createdAt: "11/06/2026", by: "Fabiano Black Belt" },
        { id: "ev-102", name: "SIPOC-Inicial-SessaoCocriacao.png", size: "1.2 MB", createdAt: "12/06/2026", by: "Soraia Process Owner" }
      ];
    }
    return [];
  });
  const [analyzeTab, setAnalyzeTab] = useState<"decision" | "queuing" | "spc">("decision");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState<boolean>(false);

  const [scheduledAudits, setScheduledAudits] = useState<ScheduledAudit[]>(() => {
    try {
      const saved = localStorage.getItem("lss_scheduled_audits");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    if (typeof window !== "undefined" && localStorage.getItem("lss_training_mode") === "true") {
      return [
        {
          id: "aud-1",
          taskName: "Auditoria de Retrabalho na Linha 1",
          processName: "Coleta Física de Produtos",
          responsibleId: "usr-1",
          responsibleName: "Lucas Mendes",
          responsibleEmail: "lucas.mendes@industrial-lss.com",
          frequency: "Diária",
          startDate: "2026-06-27",
          status: "Pendente",
          createdAt: "2026-06-26T20:00:00Z"
        },
        {
          id: "aud-2",
          taskName: "Auditoria SOX - Fechamento Contábil",
          processName: "Revisão Analítica de Balancetes",
          responsibleId: "usr-2",
          responsibleName: "Ana Beatriz Rocha",
          responsibleEmail: "ana.beatriz@industrial-lss.com",
          frequency: "Semanal",
          startDate: "2026-06-28",
          status: "Pendente",
          createdAt: "2026-06-26T21:00:00Z"
        }
      ];
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem("lss_scheduled_audits", JSON.stringify(scheduledAudits));
  }, [scheduledAudits]);

  // --- FASE 4 STATES ---
  const [deliverables, setDeliverables] = useState<import("./types").Deliverable[]>([]);
  const [projectActions, setProjectActions] = useState<import("./types").Action[]>([]);
  const [projectHistory, setHistory] = useState<import("./types").ProjectHistoryItem[]>([]);
  const [projectDetails, setProjectDetailsState] = useState<{
    companyName: string;
    unitName: string;
    processName: string;
    responsibleName: string;
    sponsorName: string;
    startDate: string;
    deadlineDate: string;
    expectedImpact: string;
    realizedImpact: string;
    lastUpdateTimestamp: string;
    status?: "Em Progresso" | "Concluído";
    isLocked?: boolean;
    signedBy?: string;
    signatureDate?: string;
    signatureType?: "Typed" | "Drawn";
    signatureDrawnData?: string;
  }>({
    companyName: "Nenhuma Empresa Selecionada",
    unitName: "-",
    processName: "Nenhum Projeto Ativo",
    responsibleName: "-",
    sponsorName: "-",
    startDate: "",
    deadlineDate: "",
    expectedImpact: "-",
    realizedImpact: "-",
    lastUpdateTimestamp: new Date().toLocaleDateString("pt-BR"),
    status: "Em Progresso",
    isLocked: false
  });

  const setProjectDetails = (value: any) => {
    setProjectDetailsState(prev => typeof value === "function" ? value(prev) : value);
  };

  const isProjectLocked = projectDetails.status === "Concluído" || projectDetails.isLocked === true;

  const handleUpdateSteps = (value: any) => {
    if (isProjectLocked) {
      triggerFlash("🔒 Projeto Concluído e Assinado pelo Sponsor! Modificações nos dados do processo estão bloqueadas por governança.");
      return;
    }
    setSteps(value);
  };

  const handleUpdateArrivalRate = (value: any) => {
    if (isProjectLocked) {
      triggerFlash("🔒 Projeto Concluído e Assinado pelo Sponsor! Mudanças de demanda/taxa de chegada estão bloqueadas.");
      return;
    }
    setArrivalRate(value);
  };

  const handleUpdateCharter = (value: any) => {
    if (isProjectLocked) {
      triggerFlash("🔒 Projeto Concluído e Assinado pelo Sponsor! Alterações no Charter estão bloqueadas.");
      return;
    }
    setCharter(value);
  };

  const handleUpdateSipoc = (value: any) => {
    if (isProjectLocked) {
      triggerFlash("🔒 Projeto Concluído e Assinado pelo Sponsor! Modificações do SIPOC estão bloqueadas.");
      return;
    }
    setSipoc(value);
  };

  const handleUpdateControlPlans = (value: any) => {
    if (isProjectLocked) {
      triggerFlash("🔒 Projeto Concluído e Assinado pelo Sponsor! Planos de controle de limite estático estão bloqueados.");
      return;
    }
    setControlPlans(value);
  };

  // Helper interactive states for Phase 4
  const [headerEditing, setHeaderEditing] = useState<boolean>(false);
  const [editedProjectName, setEditedProjectName] = useState<string>("");
  const [editedProjectObj, setEditedProjectObj] = useState<string>("");
  const [editingDeliverable, setEditingDeliverable] = useState<import("./types").Deliverable | null>(null);
  const [editingAction, setEditingAction] = useState<import("./types").Action | null>(null);
  const [isActionModalOpen, setIsActionModalOpen] = useState<boolean>(false);
  const [qaTestReport, setQaTestReport] = useState<{ name: string; status: "PASS" | "FAIL"; msg: string }[] | null>(null);
  const [selectedControlPlanId, setSelectedControlPlanId] = useState<string>("");
  const [cepViewMode, setCepViewMode] = useState<"snapshot" | "monthly">("snapshot");
  const [financePieTab, setFinancePieTab] = useState<"category" | "step">("category");
  const [templatesList, setTemplatesList] = useState<ProcessTemplate[]>(PROCESS_TEMPLATES);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("manufacturing-pcb");
  const [isTopConfigExpanded, setIsTopConfigExpanded] = useState<boolean>(false);
  const [alertEvents, setAlertEvents] = useState<any[]>(() => [
    { id: "ev-1", timestamp: "2026-06-01 10:15", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 1.02, limitCrossed: "UCL", limitValue: 0.99, cause: "Descalibração de Sensores", explanation: "Sensores ópticos de laser 3D registraram desvio focal na medição da junta de solda." },
    { id: "ev-2", timestamp: "2026-06-01 11:30", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 0.85, limitCrossed: "LCL", limitValue: 0.88, cause: "Matéria-Prima Inadequada", explanation: "Lote de resistores metálicos importados com rugosidade acima do permissível." },
    { id: "ev-3", timestamp: "2026-06-01 12:45", stepName: "Montagem Mecânica", metric: "Lead time local da etapa", value: 8.1, limitCrossed: "UCL", limitValue: 7.5, cause: "Desgaste de Ferramental", explanation: "Ponteira pneumática de torque do alimentador automático apresentou desgaste por fricção." },
    { id: "ev-4", timestamp: "2026-06-01 14:00", stepName: "Montagem Mecânica", metric: "Lead time local da etapa", value: 8.4, limitCrossed: "UCL", limitValue: 7.5, cause: "Erro Operacional de Setup", explanation: "Operador de turno inseriu velocidade nominal linear inadequada na esteira." },
    { id: "ev-5", timestamp: "2026-06-01 15:20", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 1.05, limitCrossed: "UCL", limitValue: 0.99, cause: "Flutuação de Pressão/Ar", explanation: "Houve queda intermitente na linha principal de vácuo do atuador da ventosa." },
    { id: "ev-6", timestamp: "2026-06-01 16:10", stepName: "Montagem Mecânica", metric: "Lead time local da etapa", value: 7.9, limitCrossed: "UCL", limitValue: 7.5, cause: "Matéria-Prima Inadequada", explanation: "Substrato de fibra de vidro com espessura variável acima do LCL." },
    { id: "ev-7", timestamp: "2026-06-01 17:05", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 0.82, limitCrossed: "LCL", limitValue: 0.88, cause: "Descalibração de Sensores", explanation: "Diodo de aquisição laser de alta velocidade dessincronizou com o trigger mecânico." },
    { id: "ev-8", timestamp: "2026-05-31 09:30", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 1.01, limitCrossed: "UCL", limitValue: 0.99, cause: "Histerese Térmica Ativa", explanation: "Flutuação térmica na resistência de pré-aquecimento retardou a estabilização." },
    { id: "ev-9", timestamp: "2026-05-31 11:15", stepName: "Montagem Mecânica", metric: "Lead time local da etapa", value: 7.8, limitCrossed: "UCL", limitValue: 7.5, cause: "Desgaste de Ferramental", explanation: "Desgaste na ferramenta cortadora pneumática provocou rebarbas físicas no componente." },
    { id: "ev-10", timestamp: "2026-05-31 14:45", stepName: "AOI Inspeção", metric: "Fração de rejeito em primeira passagem (FPP)", value: 1.03, limitCrossed: "UCL", limitValue: 0.99, cause: "Erro Operacional de Setup", explanation: "Incorreção no set de tolerância mínima na rotina de validação visual automática." }
  ]);

  const handleSwitchArea = (newAreaId: AreaId) => {
    setProcessesByArea(prev => ({
      ...prev,
      [activeAreaId]: steps
    }));
    setActiveAreaId(newAreaId);
    setSteps(processesByArea[newAreaId] && processesByArea[newAreaId].length > 0 ? processesByArea[newAreaId] : getInitialStepsForArea(newAreaId, INITIAL_STEPS));
  };

  const currentTemplate = templatesList.find((t) => t.id === selectedTemplateId) || templatesList[0];
  const unitLabel = currentTemplate.unitLabel;
  const unitLabelPlural = currentTemplate.unitLabelPlural;

  const handleSelectTemplate = (templateId: string) => {
    const template = templatesList.find((t) => t.id === templateId);
    if (template) {
      setSteps(template.steps);
      setArrivalRate(template.arrivalRate);
      setCharter(template.charter);
      setSipoc(template.sipoc);
      setControlPlans(template.controlPlans);
      setSelectedTemplateId(templateId);
      setProcessesByArea(prev => ({
        ...prev,
        core_ops: template.steps
      }));
      setActiveAreaId("core_ops");
      // Reset AI results & errors when changing templates to keep everything pristine
      setAiResult(null);
      setAiError(null);
      setOrInsight(null);
    }
  };

  const handleSelectBusinessType = (type: BusinessType) => {
    setBusinessType(type);
    const defaults = getVisibleWorkspaceViews(type);
    setEnabledViews(defaults);
    let firstTplId = "manufacturing-pcb";
    if (type === "SERVICES") firstTplId = "financial-ap";
    else if (type === "RETAIL") firstTplId = "retail-checkout";
    else if (type === "LOGISTICS") firstTplId = "logistics-fulfillment";
    else if (type === "TECHNOLOGY") firstTplId = "saas-software-delivery";
    else if (type === "HEALTHCARE") firstTplId = "healthcare-patient-flow";
    else if (type === "FINANCE") firstTplId = "accounting-close";
    else if (type === "HUMAN_RESOURCES") firstTplId = "hr-recruitment-funnel";
    
    const template = templatesList.find((t) => t.id === firstTplId);
    if (template) {
      setSteps(template.steps);
      setArrivalRate(template.arrivalRate);
      setCharter(template.charter);
      setSipoc(template.sipoc);
      setControlPlans(template.controlPlans);
      setSelectedTemplateId(firstTplId);
      setProcessesByArea(prev => ({
        ...prev,
        core_ops: template.steps
      }));
      setActiveAreaId("core_ops");
      setAiResult(null);
      setAiError(null);
      setOrInsight(null);
    }
  };

  // DMAIC Phase & UI Tab
  const [activePhase, setActivePhaseRaw] = useState<DmaicPhaseType>("CONTROL");
  const [completedPhases, setCompletedPhases] = useState<DmaicPhaseType[]>(["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"]);

  // PDCA Flow states
  const [pdcaCompletedSteps, setCompletedPdcaSteps] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("lss_pdca_completed_steps");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [pdcaCycleCount, setPdcaCycleCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem("lss_pdca_cycle_count");
      return saved ? Number(saved) : 1;
    } catch {
      return 1;
    }
  });
  const [pdcaCoachOpen, setPdcaCoachOpen] = useState<boolean>(true);

  useEffect(() => {
    localStorage.setItem("lss_pdca_completed_steps", JSON.stringify(pdcaCompletedSteps));
  }, [pdcaCompletedSteps]);

  useEffect(() => {
    localStorage.setItem("lss_pdca_cycle_count", String(pdcaCycleCount));
  }, [pdcaCycleCount]);

  // Workspace layout and selected bottleneck project states
  const [businessType, setBusinessType] = useState<BusinessType>(() => {
    const saved = localStorage.getItem("lss_business_type");
    return (saved as BusinessType) || "SERVICES";
  });
  const [enabledViews, setEnabledViews] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("lss_enabled_views");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    const saved = localStorage.getItem("lss_business_type");
    return getVisibleWorkspaceViews((saved as BusinessType) || "SERVICES");
  });

  useEffect(() => {
    localStorage.setItem("lss_enabled_views", JSON.stringify(enabledViews));
  }, [enabledViews]);

  const [currentWorkspaceView, setCurrentWorkspaceViewRaw] = useState<"EXECUTIVE" | "PORTFOLIO" | "PROCESSES" | "IMPROVEMENTS" | "OPERATIONS" | "COMPLIANCE" | "REPORTS" | "ADMINISTRATION" | "ENTERPRISE_OVERVIEW" | "PUBLIC_SALES" | "STRATEGY" | "ORGANIZATION" | "GOVERNANCE" | "CHANGE_MANAGEMENT" | "REORGANIZATION" | "REORGANIZATION_DASHBOARD" | "REORGANIZATION_REPORT" | "DIAGNOSTIC">("STRATEGY");
  const [resultadosSubView, setResultadosSubView] = useState<"DASHBOARD" | "REPORT">("DASHBOARD");
  
  // Custom scroll preservation mechanism
  const savedScrollY = useRef<number>(0);

  const setCurrentWorkspaceView = (value: any, bypassScrollPreservation = false) => {
    if (bypassScrollPreservation) {
      savedScrollY.current = 0;
    } else {
      savedScrollY.current = window.scrollY;
    }
    
    const resolveValue = (v: any) => {
      if (v === "REORGANIZATION_REPORT") {
        setResultadosSubView("REPORT");
        return "REORGANIZATION_DASHBOARD";
      }
      if (v === "E3I_INTELLIGENCE" || v === "ENTERPRISE_STUDIO" || v === "DMAIC" || v === "BI_STUDIO") {
        setProjectsSubView(v === "DMAIC" ? "improve" : v === "E3I_INTELLIGENCE" ? "define" : v === "BI_STUDIO" ? "improve" : "overview");
        return "IMPROVEMENTS";
      }
      if (v === "MAP" || v === "BPM") {
        setProcessSubView(v === "MAP" ? "MAPPER" : "BPM");
        return "PROCESSES";
      }
      if (v === "KANBAN") {
        return "OPERATIONS";
      }
      if (v === "OR_HUB" || v === "SIGMA_TREND") {
        setProjectsSubView("analyze");
        setAnalyzeTab(v === "OR_HUB" ? "queuing" : "spc");
        return "IMPROVEMENTS";
      }
      if (v === "REPORT") {
        return "REPORTS";
      }
      if (v === "CLIENT_PROJECTS") {
        return "PORTFOLIO";
      }
      if (v === "ADMIN" || v === "SUBSCRIPTION_MANAGEMENT") {
        return "ADMINISTRATION";
      }
      if (v === "ROI_DASHBOARD" || v === "DASHBOARD_LEIGO") {
        setProjectsSubView(v === "ROI_DASHBOARD" ? "results" : "overview");
        return "IMPROVEMENTS";
      }
      return v;
    };

    if (typeof value === "function") {
      setCurrentWorkspaceViewRaw((prev: any) => {
        const nextVal = value(prev);
        return resolveValue(nextVal);
      });
    } else {
      setCurrentWorkspaceViewRaw(resolveValue(value));
    }
  };

  const setActivePhase = (value: any, bypassScrollPreservation = false) => {
    if (bypassScrollPreservation) {
      savedScrollY.current = 0;
    } else {
      savedScrollY.current = window.scrollY;
    }
    if (typeof value === "function") {
      setActivePhaseRaw((prev) => value(prev));
    } else {
      setActivePhaseRaw(value);
    }
  };

  // Automatically restore scroll position on view/phase change across 15 frames
  useEffect(() => {
    if (savedScrollY.current > 0) {
      const targetScroll = savedScrollY.current;
      
      // Immediate scroll restore
      window.scrollTo(0, targetScroll);
      
      // Continuous scroll frame updates as children finish layout paint
      let count = 0;
      const restore = () => {
        window.scrollTo(0, targetScroll);
        count++;
        if (count < 15) {
          requestAnimationFrame(restore);
        }
      };
      requestAnimationFrame(restore);
    }
  }, [currentWorkspaceView, activePhase]);
  
  // User navigation history for "Voltar para onde estava"
  const [viewHistory, setViewHistory] = useState<string[]>([]);
  const [isMovingBack, setIsMovingBack] = useState(false);

  useEffect(() => {
    if (isMovingBack) {
      setIsMovingBack(false);
      return;
    }
    setViewHistory(prev => {
      if (prev.length > 0 && prev[prev.length - 1] === currentWorkspaceView) return prev;
      return [...prev, currentWorkspaceView].slice(-10);
    });
  }, [currentWorkspaceView, isMovingBack]);

  const handleNavigateBack = () => {
    if (viewHistory.length > 1) {
      const newHistory = [...viewHistory];
      newHistory.pop(); // remove current view
      const prevView = newHistory[newHistory.length - 1];
      setIsMovingBack(true);
      setViewHistory(newHistory);
      setCurrentWorkspaceView(prevView as any);
    } else {
      setCurrentWorkspaceView("CLIENT_PROJECTS");
    }
  };

  const [isWorkHighlighted, setIsWorkHighlighted] = useState<boolean>(false);

  const navigateToWorksite = (view: any) => {
    setCurrentWorkspaceView(view, true);
    setTimeout(() => {
      const element = document.getElementById("active-work-viewport");
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
        setIsWorkHighlighted(true);
        setTimeout(() => {
          setIsWorkHighlighted(false);
        }, 1800);
      }
    }, 150);
  };
  const [diagnosticSubView, setDiagnosticSubView] = useState<"CHARTER" | "DMAIC">("CHARTER");
  const [modelagemSubView, setModelagemSubView] = useState<"MAPPER" | "SOP">("MAPPER");
  const [engenhariaSubView, setEngenhariaSubView] = useState<"QUEUES" | "SPC">("QUEUES");
  const [governancaSubView, setGovernancaSubView] = useState<"TENANTS" | "ROI_REPORTS" | "ADMIN_SETUP">("TENANTS");
  const [dynamicSigmaHover, setDynamicSigmaHover] = useState<{ value: number; label: string } | null>(null);
  const [dynamicBarHover, setDynamicBarHover] = useState<{ value: number; label: string } | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(() => {
    try {
      return !localStorage.getItem("e3i_onboarding_shown");
    } catch (_) {
      return true;
    }
  });
  const [isTemplateGalleryOpen, setIsTemplateGalleryOpen] = useState<boolean>(false);

  const handleCloseOnboarding = () => {
    setIsOnboardingOpen(false);
    try {
      localStorage.setItem("e3i_onboarding_shown", "true");
    } catch (_) {}
  };

  const isCleanIsolatedMode = !["DMAIC", "E3I_INTELLIGENCE", "ENTERPRISE_STUDIO", "DIAGNOSTIC", "MAP", "KANBAN", "OR_HUB", "SIGMA_TREND", "BI_STUDIO", "BPM", "REPORT", "DASHBOARD_LEIGO"].includes(currentWorkspaceView);
  const [activeWorkspaceHub, setActiveWorkspaceHub] = useState<"DMAIC" | "CLIENTS" | "ADMIN">("DMAIC");

  const handleSwitchWorkspaceHub = (hub: "DMAIC" | "CLIENTS" | "ADMIN") => {
    setActiveWorkspaceHub(hub);
    if (hub === "CLIENTS") {
      setCurrentWorkspaceView("CLIENT_PROJECTS", true);
    } else if (hub === "ADMIN") {
      setCurrentWorkspaceView("ADMIN", true);
    } else {
      const defaultViews: Record<DmaicPhaseType, any> = {
        DEFINE: "E3I_INTELLIGENCE",
        MEASURE: "MAP",
        ANALYZE: "OR_HUB",
        IMPROVE: "DMAIC",
        CONTROL: "REPORT"
      };
      setCurrentWorkspaceView(defaultViews[activePhase] || "E3I_INTELLIGENCE", true);
    }
    setTimeout(() => {
      const element = document.getElementById("active-work-viewport");
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 150);
  };

  useEffect(() => {
    if (currentWorkspaceView === "CLIENT_PROJECTS") {
      setActiveWorkspaceHub("CLIENTS");
    } else if (currentWorkspaceView === "ADMIN") {
      setActiveWorkspaceHub("ADMIN");
    } else {
      setActiveWorkspaceHub("DMAIC");
    }
  }, [currentWorkspaceView]);

  const {
    companyId: activeCompanyId,
    selectCompany: setActiveCompanyId,
    projectId: activeWorkspaceProjectId,
    selectProject: setActiveWorkspaceProjectId,
    segmentConfig,
  } = useBusinessContext();

  const [initTab, setInitTab] = useState<"select" | "create" | "demo">("select");
  const [tempCompName, setTempCompName] = useState("");
  const [tempCompIndustry, setTempCompIndustry] = useState("Varejo");
  const [tempProjName, setTempProjName] = useState("");
  const [tempProjObj, setTempProjObj] = useState("");
  const [tempBatchSize, setTempBatchSize] = useState<number>(15);
  const [tempSetupTime, setTempSetupTime] = useState<number>(5);
  const [isInlineCreatingProject, setIsInlineCreatingProject] = useState(false);
  const [projectDataStore, setProjectDataStore] = useState<Record<string, any>>({});

  const [isHeaderNewCompanyModalOpen, setIsHeaderNewCompanyModalOpen] = useState(false);
  const [headerNewCompanyName, setHeaderNewCompanyName] = useState("");
  const [headerNewCompanyIndustry, setHeaderNewCompanyIndustry] = useState("Varejo");

  const [globalCompanies, setGlobalCompanies] = useState<any[]>([]);
  const [globalProjects, setGlobalProjects] = useState<any[]>([]);

  const activeProject = globalProjects.find((p) => p.id === activeWorkspaceProjectId);
  const activeProjectName = activeProject ? activeProject.name : "Nenhum";

  const showsProjectMismatchAlert = !!activeCompanyId && 
    (!activeWorkspaceProjectId || !globalProjects.some(p => p.id === activeWorkspaceProjectId && p.companyId === activeCompanyId)) &&
    globalProjects.some(p => p.companyId === activeCompanyId);

  const [isHeaderHighlighted, setIsHeaderHighlighted] = useState(false);

  useEffect(() => {
    if (activeCompanyId || activeWorkspaceProjectId) {
      setIsHeaderHighlighted(true);
      const timer = setTimeout(() => {
        setIsHeaderHighlighted(false);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [activeCompanyId, activeWorkspaceProjectId]);

  const [isCompanyDropdownOpen, setIsCompanyDropdownOpen] = useState(false);
  const [isProjectDropdownOpen, setIsProjectDropdownOpen] = useState(false);
  const [companySearchQuery, setCompanySearchQuery] = useState("");
  const [isFetchingCompanies, setIsFetchingCompanies] = useState(false);
  const [companyFetchError, setCompanyFetchError] = useState<string | null>(null);

  const companyDropdownRef = useRef<HTMLDivElement>(null);
  const projectDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (companyDropdownRef.current && !companyDropdownRef.current.contains(event.target as Node)) {
        setIsCompanyDropdownOpen(false);
      }
      if (projectDropdownRef.current && !projectDropdownRef.current.contains(event.target as Node)) {
        setIsProjectDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleLoadCompaniesWithStates = async () => {
    setIsFetchingCompanies(true);
    setCompanyFetchError(null);
    try {
      const email = activeUser?.email;
      const listComps = CompanyProjectRepository.getCompanies(email);
      setGlobalCompanies(listComps);

      const isAdmin = 
        activeUser?.role === "Admin" || 
        activeUser?.role === "Administrador" || 
        activeUser?.belt === "Master Black Belt" ||
        currentCargo === "Admin";

      if (isAdmin) {
        // Fetch fresh list from server to simulate live loading
        const fullComps = await CompanyProjectRepository.fetchAllCompaniesImmediate();
        setGlobalCompanies(fullComps);
      } else {
        // Normal role: simulate brief network sync to make spinner visible
        await new Promise(resolve => setTimeout(resolve, 400));
      }
    } catch (err: any) {
      console.warn("Error loading companies list:", err);
      setCompanyFetchError(err?.message || "Erro de sincronização com o banco Firestore.");
    } finally {
      setIsFetchingCompanies(false);
    }
  };

  const filteredCompanies = useMemo(() => {
    if (!companySearchQuery.trim()) return globalCompanies;
    const lower = companySearchQuery.toLowerCase();
    return globalCompanies.filter(c => 
      (c.name && c.name.toLowerCase().includes(lower)) || 
      (c.industry && c.industry.toLowerCase().includes(lower)) || 
      (c.cnpj && c.cnpj.includes(lower))
    );
  }, [globalCompanies, companySearchQuery]);

  useEffect(() => {
    if (activeCompanyId && globalCompanies.length > 0) {
      const activeComp = globalCompanies.find(c => c.id === activeCompanyId);
      if (activeComp) {
        const defaultModules = ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "OR_HUB", "REPORT", "ENTERPRISE_STUDIO"];
        const modulesToLoad = (activeComp.enabledModules && activeComp.enabledModules.length > 0)
          ? activeComp.enabledModules
          : defaultModules;
        setEnabledViews(modulesToLoad);
        if (activeComp.industry) {
          const compSector = mapIndustryToBusinessType(activeComp.industry) as BusinessType;
          setBusinessType(compSector);
        }
      }
    }
  }, [activeCompanyId, globalCompanies]);

  const handleRefreshGlobalData = () => {
    try {
      const email = activeUser?.email;
      const listComps = CompanyProjectRepository.getCompanies(email);
      setGlobalCompanies(listComps);
      
      const listProjs = CompanyProjectRepository.getProjects(email);
      setGlobalProjects(listProjs);

      // Force instant fetch if admin to guarantee all companies are loaded immediately
      const isAdmin = 
        activeUser?.role === "Admin" || 
        activeUser?.role === "Administrador" || 
        activeUser?.belt === "Master Black Belt" ||
        currentCargo === "Admin";

      if (isAdmin) {
        CompanyProjectRepository.fetchAllCompaniesImmediate()
          .then((fullComps) => {
            setGlobalCompanies(fullComps);
          })
          .catch((err) => {
            console.warn("Failed to fetch full companies dynamically:", err);
          });
      }
    } catch (err) {
      console.error("Erro ao carregar listas globais no App:", err);
    }
  };

  const handleCreateCompanyFromHeader = () => {
    if (!canCreateCompany()) {
      toast.warning("Apenas Administrador e Dono do Processo possuem permissão para cadastrar novas empresas.");
      return;
    }
    if (!headerNewCompanyName.trim()) return;
    const email = activeUser?.email;
    
    const cid = "comp_" + Math.random().toString(36).substring(2, 6);
    const newCompany = {
      id: cid,
      name: headerNewCompanyName.trim(),
      cnpj: "00.000.000/0001-00",
      industry: headerNewCompanyIndustry,
      createdAt: new Date().toISOString(),
      enabledModules: []
    };

    const pid = "proj_" + Math.random().toString(36).substring(2, 6);
    const newProject = {
      id: pid,
      companyId: cid,
      name: "Melhoria de Processo - " + headerNewCompanyName.trim(),
      objective: "Diagnosticar capacidade de linha, variabilidade temporal e estabilidade Six Sigma.",
      status: "Em Andamento" as const,
      createdAt: new Date().toISOString()
    };

    // Save company using immutable copy arrays to avoid mutations
    const comps = CompanyProjectRepository.getCompanies(email);
    CompanyProjectRepository.saveCompanies([...comps, newCompany], email);

    // Save project using immutable copy arrays to avoid mutations
    const projs = CompanyProjectRepository.getProjects(email);
    CompanyProjectRepository.saveProjects([...projs, newProject], email);

    // Save project data store with initial template step so that it has valid initial state
    const store = { ...CompanyProjectRepository.getProjectDataStore(email) };
    store[pid] = {
      steps: [
        {
          id: "step_pre_1",
          name: "Atendimento Inicial",
          resource: "Atendente",
          resourceCount: 1,
          processingTime: 12,
          standardDeviation: 2.5,
          setupTime: 5,
          yieldRate: 0.95
        }
      ],
      arrivalRate: 4,
      charter: {
        id: "char_pre_" + Math.random().toString(36).substring(2, 6),
        title: "Melhoria de Processo - " + headerNewCompanyName.trim(),
        businessCase: "Diagnóstico inicial da eficiência e identificação de gargalos.",
        problemStatement: "Oscilações de atendimento perceptíveis pelos clientes.",
        goalStatement: "Garantir estabilidade estatística e adequação de SLA.",
        scopeIn: "Atendimento direto.",
        scopeOut: "Faturas e cobranças.",
        team: "Grupo DMAIC " + headerNewCompanyName.trim(),
        targetValue: 150
      },
      controlPlans: []
    };
    CompanyProjectRepository.saveProjectDataStore(store, email);

    // Update active states
    setActiveCompanyId(cid);
    setActiveWorkspaceProjectId(pid);
    setProjectDataStore(store);

    // Refresh lists
    setGlobalCompanies([...comps, newCompany]);
    setGlobalProjects([...projs, newProject]);

    // Reset and close
    setIsHeaderNewCompanyModalOpen(false);
    setHeaderNewCompanyName("");
    setHeaderNewCompanyIndustry("Varejo");
  };

  useEffect(() => {
    handleRefreshGlobalData();
  }, [activeUser?.email, activeCompanyId, activeWorkspaceProjectId, currentWorkspaceView]);

  // Reload states when user email changes to partition data correctly
  useEffect(() => {
    const savedStore = CompanyProjectRepository.getProjectDataStore(activeUser?.email);
    setProjectDataStore(savedStore);
  }, [activeUser?.email]);

  // Subscribe to real-time additions/deletions in the Firestore repository
  useEffect(() => {
    const unsubscribe = CompanyProjectRepository.addChangeListener(() => {
      const email = activeUser?.email;
      const comps = CompanyProjectRepository.getCompanies(email);
      setGlobalCompanies(prev => {
        if (JSON.stringify(prev) === JSON.stringify(comps)) return prev;
        return comps;
      });

      const projs = CompanyProjectRepository.getProjects(email);
      setGlobalProjects(prev => {
        if (JSON.stringify(prev) === JSON.stringify(projs)) return prev;
        return projs;
      });

      const remoteStore = CompanyProjectRepository.getProjectDataStore(email);
      setProjectDataStore(prev => {
        if (JSON.stringify(prev) === JSON.stringify(remoteStore)) return prev;
        return remoteStore;
      });
    });
    return unsubscribe;
  }, [activeUser?.email]);

  // Synchronize and filter activeWorkspaceProjectId based on activeCompanyId selection
  useEffect(() => {
    if (activeCompanyId) {
      try {
        const list = CompanyProjectRepository.getProjects(activeUser?.email);
        // If we have an active workspace project, but the list fetched from Firestore is still empty,
        // we are still asynchronously loading. Do NOT clear the active project ID yet.
        if (activeWorkspaceProjectId && list.length === 0) {
          return;
        }

        const currentProject = list.find((p: any) => p.id === activeWorkspaceProjectId);
        // Only reset if we are absolutely sure about a mismatch. If currentProject is not found in the list,
        // it may still be loading from Firestore, so do not clear it.
        if (activeWorkspaceProjectId && currentProject && currentProject.companyId !== activeCompanyId) {
          // If the project doesn't belong to the newly selected company, reset to null
          // so the user can be visually prompted to select a correct one.
          setActiveWorkspaceProjectId(null);
        }
      } catch (e) {
        console.error("Erro ao validar vinculo de projeto com empresa:", e);
      }
    } else {
      setActiveWorkspaceProjectId(null);
    }
  }, [activeCompanyId, activeUser?.email, globalProjects, activeWorkspaceProjectId]);

  useEffect(() => {
    if (activeUser?.email) {
      CompanyProjectRepository.saveProjectDataStore(projectDataStore, activeUser.email);
    }
  }, [projectDataStore, activeUser?.email]);

  // Synchronize workspace data across project switches and ensure state reset when project is null or company changes
  const { loadedProjectId } = useAuthenticatedWorkspace({
    activeCompanyId,
    activeWorkspaceProjectId,
    isTrainingModeActive,
    projectDataStore,
    globalCompanies,
    globalProjects,
    activeUser,
    setSteps,
    setArrivalRate,
    setCharter,
    setSipoc,
    setControlPlans,
    setProcessesByArea,
    setActiveAreaId,
    setDeliverables,
    setProjectActions,
    setHistory,
    setProjectDetails
  });

  // Save current project data continuously
  useEffect(() => {
    // Only persist if there is a valid active project and company AND the workspace hook has loaded this specific project ID
    if (!activeWorkspaceProjectId || !activeCompanyId || loadedProjectId !== activeWorkspaceProjectId) {
      return;
    }

    // Validate emails before committing to projectDataStore
    const isValidEmailFormat = (email?: string) => {
      if (!email || email.trim() === "") return true;
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    };
    const hasInvalid = controlPlans.some(
      (plan) =>
        (plan.warningEmail && plan.warningEmail.trim() !== "" && !isValidEmailFormat(plan.warningEmail)) ||
        (plan.criticalEmail && plan.criticalEmail.trim() !== "" && !isValidEmailFormat(plan.criticalEmail))
    );

    if (hasInvalid) {
      // Pause automatic persistence to Firestore until the emails are corrected to a valid format
      return;
    }

    setProjectDataStore(prev => {
      const existing = prev[activeWorkspaceProjectId];
      if (
        existing &&
        existing.companyId === activeCompanyId &&
        existing.processesByArea === processesByArea &&
        existing.steps === steps &&
        existing.arrivalRate === arrivalRate &&
        existing.charter === charter &&
        existing.sipoc === sipoc &&
        existing.controlPlans === controlPlans &&
        existing.activeAreaId === activeAreaId &&
        existing.deliverables === deliverables &&
        existing.projectActions === projectActions &&
        existing.projectHistory === projectHistory &&
        existing.projectDetails === projectDetails
      ) {
        return prev;
      }
      return {
        ...prev,
        [activeWorkspaceProjectId]: {
          ...existing,
          companyId: activeCompanyId,
          processesByArea,
          steps,
          arrivalRate,
          charter,
          sipoc,
          controlPlans,
          activeAreaId,
          // Phase 4 persistent states
          deliverables,
          projectActions,
          projectHistory,
          projectDetails
        }
      };
    });
  }, [activeWorkspaceProjectId, activeCompanyId, loadedProjectId, processesByArea, steps, arrivalRate, charter, sipoc, controlPlans, activeAreaId, deliverables, projectActions, projectHistory, projectDetails]);

  // Smooth scroll to active workspace viewport when a valid project is loaded/selected
  useEffect(() => {
    if (activeWorkspaceProjectId && currentWorkspaceView !== "PUBLIC_SALES" && currentWorkspaceView !== "CLIENT_PROJECTS") {
      savedScrollY.current = 0; // Bypass scroll lock
      const timer = setTimeout(() => {
        const element = document.getElementById("active-work-viewport");
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [activeWorkspaceProjectId, currentWorkspaceView]);

  // Auto-sync workspace data to Firestore Cloud for persistent client backing and cross-session restoration
  useEffect(() => {
    if (!activeUser || !auth?.currentUser) return;
    const uid = auth.currentUser.uid;
    
    // Save to local storage cache immediately for local session resilience
    try {
      localStorage.setItem(`lss_workspace_data_${uid}`, JSON.stringify({
        activeCompanyId: activeCompanyId || "",
        activeProjectId: activeWorkspaceProjectId || "",
        updatedAt: new Date().toISOString()
      }));
      if (activeCompanyId) localStorage.setItem("lss_active_company_id", activeCompanyId);
      else localStorage.removeItem("lss_active_company_id");

      if (activeWorkspaceProjectId) localStorage.setItem("lss_active_project_id", activeWorkspaceProjectId);
      else localStorage.removeItem("lss_active_project_id");
    } catch (e) {
      console.warn("Erro ao salvar contexto do workspace no localStorage:", e);
    }

    const timer = setTimeout(async () => {
      try {
        const workspaceData = {
          activeCompanyId: activeCompanyId || "",
          activeProjectId: activeWorkspaceProjectId || "",
          updatedAt: new Date().toISOString()
        };
        
        await UserRepository.syncWorkspaceData(uid, workspaceData);
        console.log("[Firestore Auto-Save] Contexto do workspace (empresa/projeto) salvo com sucesso!");
      } catch (err) {
        console.error("Erro ao sincronizar metadados do workspace com o Firestore:", err);
      }
    }, 300); // 300ms fast debounced auto-save to Firestore on header selection change
    
    return () => clearTimeout(timer);
  }, [activeUser, activeCompanyId, activeWorkspaceProjectId]);

  const [clientPortalActive, setClientPortalActive] = useState<boolean>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      return params.get("portal") === "client" || false;
    } catch {
      return false;
    }
  });

  const [currentCargo, setCurrentCargo] = useState<any>(() => {
    try {
      const saved = localStorage.getItem("lss_current_cargo");
      if (saved === "Admin") return "Administrador";
      if (saved === "Black Belt") return "Analista";
      if (saved === "Analista Júnior") return "Colaborador";
      return saved || "Administrador";
    } catch {
      return "Administrador";
    }
  });

  const authenticatedUser = useMemo(() => {
    return buildAuthenticatedUser(activeUser, currentCargo);
  }, [activeUser, currentCargo]);

  const adminFallback = useMemo(() => {
    return (
      <div className="p-12 text-center max-w-xl mx-auto space-y-4 bg-white border border-red-200 shadow-lg rounded-xl my-6">
        <div className="inline-flex p-3 bg-rose-50 text-rose-700 rounded-full text-xl">⚠️</div>
        <h3 className="text-sm font-serif font-bold text-slate-900 uppercase tracking-tight">Acesso Reservado</h3>
        <p className="text-xs text-slate-600 leading-relaxed font-sans select-none">
          Seu cargo atual (<strong>{currentCargo}</strong>) não possui as permissões regulatórias do perfil de <code>admin:view</code> fundamentais para gerenciar os setups corporativos desta infraestrutura. Entre em contato com seu consultor Master Black Belt para obter delegação de acessos habilitada.
        </p>
      </div>
    );
  }, [currentCargo]);

  const canSimulateRoles = useMemo(() => {
    if (!activeUser) return true;
    return (
      activeUser.role === "Admin" ||
      activeUser.role === "Administrador" ||
      activeUser.belt === "Master Black Belt" ||
      activeUser.belt === "Black Belt"
    );
  }, [activeUser]);

  const canCreateCompany = () => {
    const role = currentCargo || activeUser?.role || "Colaborador";
    const normalized = role.toLowerCase();
    const belt = activeUser?.belt || "";
    return (
      normalized === "admin" ||
      normalized === "administrador" ||
      normalized === "dono do processo" ||
      normalized.includes("dono") ||
      belt === "Master Black Belt" ||
      belt === "Black Belt"
    );
  };

  const [delegations, setDelegations] = useState<DelegationRecord[]>(() => {
    try {
      const saved = localStorage.getItem("lss_delegations");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: "del-default",
        grantorUser: "Marco Antonio Miranda",
        grantorRole: "Administrador",
        delegateeName: "Ana Clara Silva",
        delegateeRole: "Auditor",
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        status: "Ativa",
        reason: "Cobertura de licença maternidade e conformidade regulatória",
        delegatedPermissions: ["aprovar", "rejeitar", "auditar", "visualizar"]
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("lss_delegations", JSON.stringify(delegations));
  }, [delegations]);

  const [usabilityMode, setUsabilityMode] = useState<UsabilityMode>(() => {
    try {
      const saved = localStorage.getItem("lss_usability_mode");
      return normalizeUsabilityMode(saved);
    } catch {
      return "SIMPLE";
    }
  });

  const [usabilityLocked, setUsabilityLocked] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("lss_usability_locked");
      return saved === "true";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if ((import.meta as any).env.PROD && activeUser) {
      if (
        activeUser.belt === "Master Black Belt" ||
        activeUser.role === "Admin" ||
        activeUser.role === "Administrador"
      ) {
        setCurrentCargo("Admin");
      } else if (activeUser.belt === "Black Belt") {
        setCurrentCargo("Black Belt");
      } else {
        setCurrentCargo("Analista Júnior");
      }
    }
  }, [activeUser]);

  useEffect(() => {
    localStorage.setItem("lss_current_cargo", currentCargo);
  }, [currentCargo]);

  useEffect(() => {
    localStorage.setItem("lss_usability_mode", usabilityMode);
  }, [usabilityMode]);

  useEffect(() => {
    localStorage.setItem("lss_usability_locked", String(usabilityLocked));
  }, [usabilityLocked]);

  const [rolePermissions, setRolePermissions] = useState<Record<string, string[]>>(() => {
    try {
      const saved = localStorage.getItem("lss_role_permissions");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return {
      "Analista Júnior": ["CLIENT_PROJECTS", "E3I_INTELLIGENCE", "DIAGNOSTIC", "MAP", "KANBAN", "REPORT", "BI_STUDIO", "SIGMA_TREND"],
      "Black Belt": ["CLIENT_PROJECTS", "E3I_INTELLIGENCE", "DIAGNOSTIC", "MAP", "KANBAN", "REPORT", "DMAIC", "BPM", "BI_STUDIO", "SIGMA_TREND"],
      "Admin": ["CLIENT_PROJECTS", "E3I_INTELLIGENCE", "DIAGNOSTIC", "MAP", "KANBAN", "REPORT", "DMAIC", "BPM", "OR_HUB", "ENTERPRISE_STUDIO", "BI_STUDIO", "SIGMA_TREND"]
    };
  });

  useEffect(() => {
    localStorage.setItem("lss_role_permissions", JSON.stringify(rolePermissions));
  }, [rolePermissions]);

  const isModuleAllowed = (viewKey: string) => {
    // Map high-level workspace views back to logical module keys
    let keysToCheck = [viewKey];
    if (viewKey === "IMPROVEMENTS") {
      keysToCheck = ["DMAIC", "OR_HUB", "E3I_INTELLIGENCE", "BI_STUDIO", "ENTERPRISE_STUDIO", "SIGMA_TREND", "ROI_DASHBOARD", "DASHBOARD_LEIGO"];
    } else if (viewKey === "PROCESSES") {
      keysToCheck = ["MAP", "BPM"];
    } else if (viewKey === "OPERATIONS") {
      keysToCheck = ["KANBAN"];
    } else if (viewKey === "REPORTS") {
      keysToCheck = ["REPORT"];
    } else if (viewKey === "PORTFOLIO") {
      keysToCheck = ["CLIENT_PROJECTS"];
    } else if (viewKey === "ADMINISTRATION") {
      keysToCheck = ["ADMIN", "SUBSCRIPTION_MANAGEMENT"];
    }

    const checkSingleKey = (key: string) => {
      if (key === "PUBLIC_SALES") return true;
      if (key === "STRATEGY") return true;
      if (key === "ORGANIZATION") return true;
      if (key === "GOVERNANCE") return true;
      if (key === "CHANGE_MANAGEMENT") return true;
      if (key === "REORGANIZATION") return true;
      if (key === "REORGANIZATION_DASHBOARD") return true;
      if (key === "REORGANIZATION_REPORT") return true;
      if (key === "DIAGNOSTIC") return true;
      if (key === "PORTFOLIO") return true;
      if (key === "PROCESSES") return true;
      if (key === "EXECUTIVE") return true;
      if (key === "ENTERPRISE_OVERVIEW") return true;
      if (key === "REPORT") return true;
      if (key === "BI_STUDIO") return true;
      if (key === "OR_HUB") return true;
      if (key === "SIGMA_TREND") return true;
      if (key === "DMAIC") return true;

      // 1. Check general module contraction (licensing level constraints)
      if (key === "DIAGNOSTIC" && !enabledViews.includes("DIAGNOSTIC")) return false;
      if (key === "MAP" && !enabledViews.includes("MAP")) return false;
      if (key === "DMAIC" && !enabledViews.includes("DMAIC")) return false;
      if (key === "KANBAN" && !enabledViews.includes("KANBAN")) return false;
      if (key === "BPM" && !enabledViews.includes("BPM")) return false;
      if (key === "OR_HUB" && !enabledViews.includes("OR_HUB")) return false;
      if (key === "REPORT" && !enabledViews.includes("REPORT")) return false;
      if (key === "ENTERPRISE_STUDIO" && !enabledViews.includes("ENTERPRISE_STUDIO")) return false;
      if (key === "BI_STUDIO" && !enabledViews.includes("BI_STUDIO") && !enabledViews.includes("REPORT")) return false;
      if (key === "SIGMA_TREND" && !enabledViews.includes("OR_HUB") && !enabledViews.includes("SIGMA_TREND")) return false;
      if (key === "E3I_INTELLIGENCE" && !enabledViews.includes("DMAIC") && !enabledViews.includes("E3I_INTELLIGENCE")) return false;

      // 2. Map viewKey to multi-tenant user profile permissions
      const uName = activeUser?.fullName || "Usuário Atual";

      // Check dynamic custom matrix from rolePermissions first
      let activeCargoToCheck = currentCargo;
      const activeDel = getActiveDelegationForUser(currentCargo, uName, delegations);
      if (activeDel) {
        const mappedRole = activeDel.grantorRole === "Administrador" ? "Admin" : activeDel.grantorRole;
        if (rolePermissions && rolePermissions[mappedRole]) {
           activeCargoToCheck = mappedRole as any;
        }
      }

      if (rolePermissions && rolePermissions[activeCargoToCheck]) {
        return rolePermissions[activeCargoToCheck].includes(key);
      }

      return checkModuleAllowed(currentCargo, key, delegations, uName);
    };

    return keysToCheck.some(checkSingleKey);
  };


  const getActiveCompanyName = () => {
    if (!activeCompanyId) return "Nenhuma";
    try {
      const list = CompanyProjectRepository.getCompanies(activeUser?.email);
      const comp = list.find((c: any) => c.id === activeCompanyId);
      return comp ? comp.name : "Nenhuma";
    } catch {
      return "Nenhuma";
    }
  };

  useEffect(() => {
    localStorage.setItem("lss_business_type", businessType);
    if (!isModuleAllowed(currentWorkspaceView)) {
      if (enabledViews.includes("DIAGNOSTIC")) {
        setCurrentWorkspaceView("DIAGNOSTIC");
      } else if (enabledViews.length > 0) {
        setCurrentWorkspaceView(enabledViews[0] as any);
      }
    }
  }, [businessType, currentWorkspaceView, enabledViews]);
  const [selectedDmaicStep, setSelectedDmaicStep] = useState<ProcessStep | null>(null);
  const [bpmDocTab, setBpmDocTab] = useState<"docker" | "gcp" | "telemetry" | "cicd">("docker");

  // Form input states for adding steps
  const [newStepName, setNewStepName] = useState("");
  const [newStepResource, setNewStepResource] = useState("");
  const [newStepResourceCount, setNewStepResourceCount] = useState(1);
  const [newStepProcessingTime, setNewStepProcessingTime] = useState(4.0);
  const [newStepStdev, setNewStepStdev] = useState(0.8);
  const [newStepYield, setNewStepYield] = useState(95);
  const [newStepSetup, setNewStepSetup] = useState(0);

  // AI Assistant states
  const [aiResult, setAiResult] = useState<any>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Sector suggestion states for AI Data Collector & Operations Research assistant
  const [sectorInput, setSectorInput] = useState<string>("Linha de montagem de notebooks");
  const [isSuggesting, setIsSuggesting] = useState<boolean>(false);
  const [suggestError, setSuggestError] = useState<string | null>(null);
  const [orInsight, setOrInsight] = useState<{
    orModel: string;
    problemStatement: string;
    orSuggestions: string;
    recommendedConfiguration: string;
    operationalTip: string;
  } | null>(null);

  const handleSuggestStructure = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!sectorInput.trim()) return;

    setIsSuggesting(true);
    setSuggestError(null);

    try {
      const data = await AiService.suggestStructure(sectorInput);
      
      // Update SIPOC structure
      if (data.sipoc) {
        setSipoc(data.sipoc);
      }

      // Update Process Steps mapped cleanly
      if (data.steps && Array.isArray(data.steps)) {
        const processedSteps = data.steps.map((s: any, idx: number) => ({
          id: `step-${Date.now()}-${idx}`,
          name: s.name,
          resource: s.resource,
          resourceCount: s.resourceCount || 1,
          processingTime: s.processingTime || 4.0,
          standardDeviation: s.standardDeviation || 0.8,
          yieldRate: s.yieldRate || 0.95,
          setupTime: s.setupTime || 0,
          x: 100 + (idx % 3) * 240,
          y: 80 + Math.floor(idx / 3) * 160,
          shapeType: idx === 0 ? "START" : (idx === data.steps.length - 1 ? "END" : "ACTIVITY")
        }));
        setSteps(processedSteps);
      }

      // Store OR Analysis insights
      if (data.orAnalysis) {
        setOrInsight(data.orAnalysis);
      }

    } catch (err: any) {
      console.error(err);
      setSuggestError(err.message || "Não foi possível se conectar ao serviço de sugestão de IA.");
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleApplySipocToMap = () => {
    if (!sipoc.processDescription) return;
    const items = sipoc.processDescription
      .split(/->|-->|,|;/)
      .map(item => item.trim())
      .filter(item => item.length > 0);

    if (items.length === 0) return;

    const updatedSteps = items.map((name, index) => {
      const existing = steps.find(s => s.name.toLowerCase() === name.toLowerCase());
      if (existing) {
        return {
          ...existing,
          x: 100 + (index % 3) * 240,
          y: 85 + Math.floor(index / 3) * 160,
        };
      } else {
        return {
          id: `step-${Date.now()}-${index}`,
          name: name,
          resource: "Operador Geral",
          resourceCount: 1,
          processingTime: 5.0,
          standardDeviation: 1.0,
          yieldRate: 0.95,
          setupTime: 0,
          x: 100 + (index % 3) * 240,
          y: 85 + Math.floor(index / 3) * 160,
          shapeType: index === 0 ? "START" : (index === items.length - 1 ? "END" : "ACTIVITY")
        };
      }
    });

    setSteps(updatedSteps);
  };

  const handleSyncMapToSipoc = () => {
    const formatted = steps.map(s => s.name).join(" -> ");
    setSipoc(prev => ({ ...prev, processDescription: formatted }));
  };

  // Run initial calculations on load
  const stats = calculateProcessMetrics(steps, arrivalRate);

  // Sigma sensitivity for quality alarms (number of standard deviations, defaults to 3-sigma)
  const [alarmSigmaSensitivity, setAlarmSigmaSensitivity] = useState<number>(3.0);

  // Helper to calculate dynamic control limits based on sigma sensitivity (default 3-sigma)
  const getDynamicLimits = (plan: ControlPlan) => {
    const k = alarmSigmaSensitivity;
    const target = plan.target;
    // Lower side standard deviation (assuming standard limits represent 3-sigma dev from target)
    const sigLower = Math.max(0.001, target - plan.lcl) / 3;
    // Upper side standard deviation (assuming standard limits represent 3-sigma dev from target)
    const sigUpper = Math.max(0.001, plan.ucl - target) / 3;

    return {
      lcl: target - k * sigLower,
      ucl: target + k * sigUpper,
      sigLower,
      sigUpper
    };
  };

  const handleRegisterViolationIfNeeded = (planId: string, value: number, updatedPlansList?: ControlPlan[]) => {
    const list = updatedPlansList || controlPlans;
    const plan = list.find(p => p.id === planId);
    if (!plan) return;

    const limits = getDynamicLimits(plan);
    const isViolation = value < limits.lcl || value > limits.ucl;
    
    if (isViolation && plan.enableAlarm) {
      const causesByMetric: Record<string, { cause: string, explanation: string }[]> = {
        "Fração de rejeito em primeira passagem (FPP)": [
          { cause: "Descalibração de Sensores", explanation: "Sensores ópticos de laser 3D perderam a focalização mecânica" },
          { cause: "Matéria-Prima Inadequada", explanation: "Solda com contaminação química de óxidos no bico do forno" },
          { cause: "Flutuação de Pressão/Ar", explanation: "Perda imediata de fluxo de vácuo no bico de sucção pneumática" }
        ],
        "Lead time local da etapa": [
          { cause: "Erro Operacional de Setup", explanation: "Parâmetro incorreto linear na esteira de montagem eletrônica" },
          { cause: "Desgaste de Ferramental", explanation: "Engrenagem da esteira de roletes com desgaste por tração repetida" },
          { cause: "Histerese Térmica Ativa", explanation: "Tempo de resfriamento estendido por flutuação térmica mecânica" }
        ]
      };

      const defaultCauses = [
        { cause: "Descalibração de Sensores", explanation: "Sensores de validação perderam a sincronia de trigger" },
        { cause: "Matéria-Prima Inadequada", explanation: "Rugosidade variável na fita de insumo recebida" },
        { cause: "Desgaste de Ferramental", explanation: "Gabaritos mecânicos apresentando folga por atrito linear" },
        { cause: "Erro Operacional de Setup", explanation: "Velocidade nominal do transportador superior à nominal" }
      ];

      const pool = causesByMetric[plan.metric] || defaultCauses;
      const randIndex = Math.floor(Math.random() * pool.length);
      const chosen = pool[randIndex];

      const newEvent = {
        id: `ev-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        stepName: plan.stepName,
        metric: plan.metric,
        value: Number(value.toFixed(3)),
        limitCrossed: value < limits.lcl ? "LCL" : "UCL",
        limitValue: Number((value < limits.lcl ? limits.lcl : limits.ucl).toFixed(3)),
        cause: chosen.cause,
        explanation: chosen.explanation,
        severity: "high"
      };

      setAlertEvents(prev => [newEvent, ...prev]);
    }
  };

  // Computed state for active alarm monitor triggers (dynamic LCL/UCL violations based on Sigma sensitivity)
  const activeAlarms = controlPlans.filter(plan => {
    if (!plan.enableAlarm) return false;
    const reading = plan.currentReading !== undefined ? plan.currentReading : plan.target;
    const limits = getDynamicLimits(plan);
    return reading < limits.lcl || reading > limits.ucl;
  });

  const handleAddStep = (e: FormEvent) => {
    e.preventDefault();
    if (!newStepName.trim() || !newStepResource.trim()) return;

    const newStep: ProcessStep = {
      id: `step-${Date.now()}`,
      name: newStepName,
      resource: newStepResource,
      resourceCount: newStepResourceCount,
      processingTime: newStepProcessingTime,
      standardDeviation: Math.max(0.1, newStepStdev),
      yieldRate: newStepYield / 100,
      setupTime: newStepSetup,
    };

    setSteps([...steps, newStep]);
    
    // Clear form inputs
    setNewStepName("");
    setNewStepResource("");
    setNewStepResourceCount(1);
    setNewStepProcessingTime(4.0);
    setNewStepStdev(0.8);
    setNewStepYield(95);
    setNewStepSetup(0);
  };

  const handleDeleteStep = (id: string) => {
    if (steps.length <= 1) {
      alert("O processo deve counter pelo menos uma etapa.");
      return;
    }
    setSteps(steps.filter((s) => s.id !== id));
  };

  const handleUpdateStepField = (index: number, field: keyof ProcessStep, value: any) => {
    const updated = [...steps];
    updated[index] = { ...updated[index], [field]: value };
    setSteps(updated);
  };

  const handleDownloadSaturationCSV = () => {
    const saturatedSteps = steps.filter(step => {
      const stepCap = (60 / step.processingTime) * step.resourceCount;
      const utilization = (arrivalRate / stepCap) * 100;
      return utilization >= 100;
    });

    const escapeCSV = (val: string | number | undefined) => {
      if (val === undefined || val === null) return "";
      const s = String(val);
      if (s.includes(",") || s.includes('"') || s.includes("\n") || s.includes(";")) {
        return '"' + s.replace(/"/g, '""') + '"';
      }
      return s;
    };

    const rows = [];
    rows.push(["AUDITORIA DE PESQUISA OPERACIONAL - SNAPSHOT DE SATURACAO DE LINHA"]);
    rows.push(["Data do Snapshot", new Date().toISOString()]);
    rows.push(["Taxa de Chegada Geral (Arrival Rate)", `${arrivalRate} u/h`]);
    rows.push(["Utilizacao do Sistema (System Utilization)", `${stats.systemUtilization.toFixed(2)}%`]);
    rows.push(["Capacidade do Sistema (System Capacity)", `${stats.systemCapacity.toFixed(2)} u/h`]);
    rows.push(["Gargalo Master do Sistema (Bottleneck)", stats.bottleneckStepName]);
    rows.push([]);
    rows.push(["ETAPAS SATURADAS COM UTILIZACAO >= 100% (ALERTA DE FILAS INFINITAS)"]);
    rows.push(["ID", "Nome da Etapa", "Recurso", "Qtd Servidores", "Tempo de Toque (min)", "Desvio Padrao (min)", "Rendimento (Yield)", "Setup de Linha (min)", "Capacidade Maxima Local (u/h)", "Utilizacao (%)"]);
    
    if (saturatedSteps.length === 0) {
      rows.push(["Nenhuma etapa individual esta acima de 100% de utilizacao no momento."]);
    } else {
      saturatedSteps.forEach(step => {
        const stepCap = (60 / step.processingTime) * step.resourceCount;
        const utilization = (arrivalRate / stepCap) * 100;
        rows.push([
          step.id,
          step.name,
          step.resource,
          step.resourceCount,
          step.processingTime,
          step.standardDeviation,
          `${(step.yieldRate * 100).toFixed(1)}%`,
          step.setupTime,
          stepCap.toFixed(2),
          `${utilization.toFixed(2)}%`
        ]);
      });
    }

    rows.push([]);
    rows.push(["DEMAIS ETAPAS DO PROCESSO"]);
    rows.push(["ID", "Nome da Etapa", "Recurso", "Qtd Servidores", "Tempo de Toque (min)", "Desvio Padrao (min)", "Rendimento (Yield)", "Setup de Linha (min)", "Capacidade Maxima Local (u/h)", "Utilizacao (%)"]);
    
    steps.forEach(step => {
      const stepCap = (60 / step.processingTime) * step.resourceCount;
      const utilization = (arrivalRate / stepCap) * 100;
      if (utilization < 100) {
        rows.push([
          step.id,
          step.name,
          step.resource,
          step.resourceCount,
          step.processingTime,
          step.standardDeviation,
          `${(step.yieldRate * 100).toFixed(1)}%`,
          step.setupTime,
          stepCap.toFixed(2),
          `${utilization.toFixed(2)}%`
        ]);
      }
    });

    const csvContent = rows.map(r => r.map(escapeCSV).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `auditoria_saturacao_po_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Preset: apply Lean Optimization automatically to show dramatic Six Sigma improvement
  const handleApplyLeanOptimization = () => {
    // 1. Balanceamento: Reallocate operator to Step 4 (Assembly) increasing count, or reduce process times slightly
    // 2. SMED: reduce setup times drastically
    // 3. Poka-yoke / Quality improvement: elevate Step 3 yield from 93% to 99%
    const optimized = steps.map((step) => {
      let updated = { ...step };
      if (step.id === "step-3") {
        updated.yieldRate = 0.99; // poka-yoke
        updated.standardDeviation = 0.5; // low variability
      }
      if (step.id === "step-4") {
        updated.resourceCount = 2; // dual resources to increase capacity & eliminate the bottleneck!
        updated.setupTime = 2; // SMED reduced setup from 12 to 2 mins
        updated.processingTime = 4.8; // balanced workflow
      }
      if (step.id === "step-1") {
        updated.setupTime = 3; // SMED reduced setup from 15 to 3 mins
      }
      return updated;
    });

    setSteps(optimized);
    
    // Auto add complete markers to phase state
    if (!completedPhases.includes("IMPROVE")) {
      setCompletedPhases([...completedPhases, "MEASURE", "ANALYZE", "IMPROVE"]);
    }
    setActivePhase("IMPROVE");
  };

  const handleResetToBaseline = () => {
    setSteps(INITIAL_STEPS);
    setArrivalRate(10);
    setCharter(INITIAL_CHARTER);
    setSipoc(INITIAL_SIPOC);
    setControlPlans(INITIAL_CONTROL_PLAN);
    setCompletedPhases(["DEFINE"]);
    setActivePhase("DEFINE");
    setAiResult(null);
  };

  // Invoke Gemini API for intelligence and report generation
  const handleCallGeminiApi = async () => {
    if (!steps || steps.length === 0) {
      setAiError("O processo deve conter ao menos 1 etapa antes de disparar a análise cognitiva.");
      return;
    }
    setAiLoading(true);
    setAiError(null);
    try {
      const data = await AiService.analyzeProcess(steps, arrivalRate, charter, sipoc);
      setAiResult(data);
      
      // Auto complete DMAIC paths if analytical report is retrieved
      if (!completedPhases.includes("ANALYZE")) {
        setCompletedPhases([...completedPhases, "MEASURE", "ANALYZE"]);
      }
      setActivePhase("ANALYZE");
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "Não foi possível conectar ao servidor de IA.");
    } finally {
      setAiLoading(false);
    }
  };

  // Quick navigation helpers
  const handleNextPhase = () => {
    const phases: DmaicPhaseType[] = ["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"];
    const currentIndex = phases.indexOf(activePhase);
    if (currentIndex < phases.length - 1) {
      const next = phases[currentIndex + 1];
      setActivePhase(next);
      if (!completedPhases.includes(next)) {
        setCompletedPhases([...completedPhases, next]);
      }
    }
  };

  const handlePrevPhase = () => {
    const phases: DmaicPhaseType[] = ["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"];
    const currentIndex = phases.indexOf(activePhase);
    if (currentIndex > 0) {
      setActivePhase(phases[currentIndex - 1]);
    }
  };

  // Local helper calculations
  const totalRolledYieldPercent = (stats.rolledFirstPassYield * 100).toFixed(1);
  const dpmoFormatted = Math.round(stats.dpmo).toLocaleString("pt-BR");
  const sigmaLevelFormatted = stats.sigmaLevel.toFixed(2);
  const systemWipFormatted = stats.systemWip.toFixed(1);

  const getDynamicSubtitle = () => {
    return (
      <>
        Inteligência operacional para descobrir perdas, priorizar melhorias e comprovar resultados.
      </>
    );
  };

  if (clientPortalActive) {
    return <ClientPortal activeUser={activeUser} onBackToApp={() => setClientPortalActive(false)} />;
  }

  if (!activeUser) {
    if (currentWorkspaceView === "PUBLIC_SALES") {
      return (
        <PublicSalesLanding 
          onStartTrial={() => setCurrentWorkspaceView("PORTFOLIO")} 
          globalCompanies={globalCompanies}
          setGlobalCompanies={setGlobalCompanies}
          globalProjects={globalProjects}
          setProjects={setGlobalProjects}
          currentCargo={currentCargo}
          setCurrentCargo={setCurrentCargo}
          setCurrentWorkspaceView={setCurrentWorkspaceView}
          activeUser={activeUser}
          onLoginSuccess={(simulatedUser, permittedViews, companyInfo) => {
            localStorage.removeItem("lss_logged_out");
            setActiveUser(simulatedUser);
            if (permittedViews) {
              setEnabledViews(permittedViews);
            } else {
              setEnabledViews(["DIAGNOSTIC", "MAP", "KANBAN", "REPORT"]);
            }
            
            const cid = simulatedUser.companyId || "comp-itau";
            setActiveCompanyId(cid);
            setCurrentCargo(simulatedUser.role || "Analista Júnior");
            
            setCurrentWorkspaceView("PORTFOLIO");

            // Register/Mirror the corporate license configurations dynamically inside Cloud Firestore
            if (companyInfo) {
              try {
                const email = simulatedUser.email;
                const comps = CompanyProjectRepository.getCompanies(email);
                const exists = comps.some((c: any) => c.id === cid);
                if (!exists) {
                  const newCompany = {
                    id: cid,
                    name: companyInfo.name,
                    cnpj: companyInfo.cnpj || "91.833.102/0001-44",
                    industry: companyInfo.industry,
                    enabledModules: permittedViews || [],
                    createdAt: new Date().toISOString()
                  };
                  CompanyProjectRepository.saveCompanies([...comps, newCompany], email);
                  setGlobalCompanies([...comps, newCompany]);
                }
              } catch (e) {
                console.error("Erro ao registrar empresa licitante:", e);
              }
            }

            // Auto-provision a beautiful initial Lean Six Sigma project for this client in Firestore
            setTimeout(() => {
              try {
                const email = simulatedUser.email;
                const projs = CompanyProjectRepository.getProjects(email);
                const compProj = projs.filter((p: any) => p.companyId === cid);
                if (compProj.length === 0) {
                  const pid = "proj-" + cid + "-auto";
                  const defaultProjectName = cid === "comp-itau" 
                    ? "Otimização de Ordens de Atendimento PJ" 
                    : cid === "comp-ambev"
                      ? "Melhoria do Lead Time de Operações SMT"
                      : cid === "comp-petrobras"
                        ? "Efeito de Vazão e Estabilidade Volumétrica CEP"
                        : "Aceleração do Fluxo Lean Six Sigma S.A.";

                  const newProject = {
                    id: pid,
                    companyId: cid,
                    name: defaultProjectName,
                    objective: "Estabilizar e aprimorar a capacidade estatística do fluxo operacional corporativo.",
                    status: "Em Andamento" as const,
                    createdAt: new Date().toISOString()
                  };
                  CompanyProjectRepository.saveProjects([...projs, newProject], email);
                  setGlobalProjects([...projs, newProject]);

                  // Initialize some template process flow steps and metrics for this project
                  const store = { ...CompanyProjectRepository.getProjectDataStore(email) };
                  store[pid] = {
                    steps: [
                      { id: "step_def_1", name: "Ficha / Entrada Digital", resource: "Analista", resourceCount: 2, processingTime: 8, standardDeviation: 1.5, setupTime: 3, yieldRate: 0.98 },
                      { id: "step_def_2", name: "Análise PJ & Triagem", resource: "Sênior", resourceCount: 1, processingTime: 14, standardDeviation: 2.8, setupTime: 5, yieldRate: 0.94 },
                      { id: "step_def_3", name: "Execução & Liberação", resource: "Robô RPA", resourceCount: 1, processingTime: 5, standardDeviation: 0.5, setupTime: 1, yieldRate: 0.99 }
                    ],
                    arrivalRate: 4,
                    charter: {
                      id: "char_" + pid,
                      title: defaultProjectName,
                      businessCase: "Otimização operacional para aprimorar os indicadores de ANS e produtividade geral.",
                      problemStatement: "Variabilidade perceptível gerando atrasos em horários de pico.",
                      goalStatement: "Estabilizar a variabilidade e garantir o cumprimento de SLA com alto Sigma.",
                      scopeIn: "Processamento e triagem de carteiras.",
                      scopeOut: "Integrações terceiras e auditoria externa.",
                      team: "Equipe de Desempenho " + (companyInfo?.name || "E3I"),
                      targetValue: 250
                    },
                    controlPlans: []
                  };
                  CompanyProjectRepository.saveProjectDataStore(store, email);
                  setActiveWorkspaceProjectId(pid);
                } else {
                  setActiveWorkspaceProjectId(compProj[0].id);
                }
              } catch (e) {
                console.error("Erro ao auto-provisionar projetos corporativos:", e);
              }
            }, 600);
          }}
        />
      );
    }
    return (
      <AuthCover 
        onLoginSuccess={(user) => {
          localStorage.removeItem("lss_logged_out");
          setActiveUser(user);
        }} 
      />
    );
  }

  // FORCE SELECTION OF COMPANY ON STARTUP
  if (!activeCompanyId) {
    return (
      <InitialWorkspaceSetupCover
        activeUser={activeUser}
        setActiveCompanyId={setActiveCompanyId}
        setActiveWorkspaceProjectId={setActiveWorkspaceProjectId}
        onRefreshGlobalData={handleRefreshGlobalData}
      />
    );
  }

  const renderBreadcrumbs = () => {
    const parentCompany = globalCompanies.find((c) => c.id === activeCompanyId);
    const activeProject = globalProjects.find((p) => p.id === activeWorkspaceProjectId);

    const crumbs = [];

    if (parentCompany) {
      crumbs.push({ label: parentCompany.name, icon: "🏢" });
    } else {
      crumbs.push({ label: "Sem Empresa", icon: "🏢" });
    }

    if (activeWorkspaceProjectId && activeProject) {
      crumbs.push({ label: activeProject.name, icon: "🧪" });
    }

    const viewLabels: Record<string, string> = {
      EXECUTIVE: "Visão Executiva",
      PORTFOLIO: "Portfólio",
      PROCESSES: "Processos",
      IMPROVEMENTS: "Projetos de Melhoria",
      OPERATIONS: "Operação",
      COMPLIANCE: "Riscos e Controles",
      REPORTS: "Relatórios",
      ADMINISTRATION: "Administração",
      ENTERPRISE_OVERVIEW: "Visão Geral Corporativa",
      REORGANIZATION: "Plano Reorganização",
      REORGANIZATION_DASHBOARD: "Dashboard Executivo",
      REORGANIZATION_REPORT: "Relatório Executivo",
    };

    crumbs.push({
      label: viewLabels[currentWorkspaceView] || currentWorkspaceView,
      icon: "🧭",
    });

    if (currentWorkspaceView === "IMPROVEMENTS") {
      const subLabels: Record<string, string> = {
        overview: "Visão Geral",
        define: "Definir",
        measure: "Medir",
        analyze: "Analisar",
        improve: "Melhorar",
        control: "Controlar",
        results: "Resultados",
        evidences: "Evidências",
        history: "Histórico",
      };
      crumbs.push({ label: subLabels[projectsSubView] || projectsSubView, icon: "⚡" });
    }

    return (
      <div className="bg-slate-50 border-b border-[#1A1A1A]/10 px-6 py-2 md:px-12 flex items-center gap-1.5 text-[10.5px] font-sans font-semibold text-slate-500 overflow-x-auto whitespace-nowrap scrollbar-none text-left shrink-0">
        {crumbs.map((crumb, idx) => (
          <Fragment key={idx}>
            {idx > 0 && <span className="text-slate-350">›</span>}
            <div className="flex items-center gap-1">
              <span>{crumb.icon}</span>
              <span className={idx === crumbs.length - 1 ? "text-slate-805 font-extrabold" : ""}>
                {crumb.label}
              </span>
            </div>
          </Fragment>
        ))}
      </div>
    );
  };

  const renderMainWorkspaceViewport = () => {
    const legacyViews = [
      "EXECUTIVE",
      "PORTFOLIO",
      "PROCESSES",
      "IMPROVEMENTS",
      "OPERATIONS",
      "COMPLIANCE",
      "REPORTS",
      "ADMINISTRATION",
      "ENTERPRISE_OVERVIEW"
    ];

    if (!legacyViews.includes(currentWorkspaceView)) {
      return null;
    }

    if (!activeCompanyId && currentWorkspaceView !== "PORTFOLIO" && currentWorkspaceView !== "PUBLIC_SALES" && currentWorkspaceView !== "ENTERPRISE_OVERVIEW") {
      return (
        <EmptyState 
          type="no_company" 
          primaryAction={{
            label: "Ir para Gestão de Clientes / Empresas",
            onClick: () => setCurrentWorkspaceView("PORTFOLIO")
          }}
        />
      );
    }
    if (!activeWorkspaceProjectId && currentWorkspaceView !== "PORTFOLIO" && currentWorkspaceView !== "ADMINISTRATION" && currentWorkspaceView !== "PUBLIC_SALES" && currentWorkspaceView !== "ENTERPRISE_OVERVIEW") {
      return (
        <EnterpriseOverviewDashboard
          activeUser={activeUser}
          currentCargo={currentCargo}
          companies={globalCompanies}
          projects={globalProjects}
          projectDataStore={projectDataStore}
          activeCompanyId={activeCompanyId}
          activeProjectId={activeWorkspaceProjectId}
          onSelectCompany={setActiveCompanyId}
          onSelectProject={setActiveWorkspaceProjectId}
          onNavigateToAdmin={() => setCurrentWorkspaceView("ADMINISTRATION")}
          onNavigateToProjectWorkspace={(projectId, companyId) => {
            setActiveCompanyId(companyId);
            setActiveWorkspaceProjectId(projectId);
            setProcessSubView("MAPPER");
            setCurrentWorkspaceView("PROCESSES");
          }}
        />
      );
    }

    switch (currentWorkspaceView) {
      case "EXECUTIVE":
        return (
          <div className="space-y-6 animate-fade-in text-left">
            <div className="border-b border-[#1A1A1A]/10 pb-4 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4">
              <div>
                <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-wider font-mono">Governança Integrada E3I</p>
                <h2 className="text-2xl font-serif font-black text-slate-900 uppercase">Visões Decisórias e Nível de Saúde</h2>
              </div>
              <div className="flex flex-wrap bg-[#FAF9F5] border border-slate-200 rounded-lg p-0.5 shadow-3xs text-[10.5px] font-bold font-sans">
                <button
                  id="tab-btn-decision"
                  onClick={() => setAnalyzeTab("decision")}
                  className={`px-3 py-1.5 rounded-md cursor-pointer transition-all ${analyzeTab === "decision" ? "bg-[#C49746] text-white shadow-3xs" : "text-slate-600 hover:text-slate-805"}`}
                >
                  🛡️ Decisão por Função ({currentCargo})
                </button>
                <button
                  id="tab-btn-queuing"
                  onClick={() => setAnalyzeTab("queuing")}
                  className={`px-3 py-1.5 rounded-md cursor-pointer transition-all ${analyzeTab === "queuing" ? "bg-[#C49746] text-white shadow-3xs" : "text-slate-600 hover:text-slate-805"}`}
                >
                  🚥 Saúde Geral (Semáforos)
                </button>
                <button
                  id="tab-btn-spc"
                  onClick={() => setAnalyzeTab("spc")}
                  className={`px-3 py-1.5 rounded-md cursor-pointer transition-all ${analyzeTab === "spc" ? "bg-[#C49746] text-white shadow-3xs" : "text-slate-600 hover:text-slate-805"}`}
                >
                  📈 Tendências de Qualidade
                </button>
              </div>
            </div>

            {analyzeTab === "decision" ? (
              <RoleDashboards
                currentRole={currentCargo}
                steps={steps}
                stats={stats}
                arrivalRate={arrivalRate}
                activeCompanyId={activeCompanyId}
                activeCompanyName={getActiveCompanyName()}
                activeProjectId={activeWorkspaceProjectId}
                activeProjectName={activeProject?.name || "Nenhum"}
                delegations={delegations}
                setDelegations={setDelegations}
                onNavigateToView={(view) => setCurrentWorkspaceView(view as any)}
                onTriggerAction={(actionType) => {
                  if (actionType === "APPROVE_CHARTER") {
                    setCharter(prev => ({
                      ...prev,
                      businessCase: "APROVADO E HOMOLOGADO FINANCEIRAMENTE VIA PAINEL RBAC (" + currentCargo + ")\n" + (prev.businessCase || "")
                    }));
                    toast.success("Project Charter aprovado, assinado e homologado eletronicamente com sucesso nas políticas do atual perfil (" + currentCargo + ")!");
                  } else if (actionType === "SUBMIT_EVIDENCE") {
                    toast.info("Evidência técnica e manual SOP anexados com sucesso ao repositório do projeto!");
                  } else if (actionType === "RUN_SIMULATION") {
                    handleRunSimulation();
                    toast.success("Simulação Estocástica de Monte Carlo disparada com sucesso no balanceamento de filas!");
                  } else if (actionType === "LOG_NONCONFORMITY") {
                    toast.warning("Não conformidade de conformidade de Campo (SOP) registrada no livro de auditoria e enviada por e-mail!");
                  }
                }}
              />
            ) : analyzeTab === "queuing" ? (
              <DashboardLeigo
                stats={stats}
                steps={steps}
                setSteps={handleUpdateSteps}
                activeUser={activeUser}
                businessType={businessType}
                unitLabelPlural={unitLabelPlural}
                arrivalRate={arrivalRate}
                setArrivalRate={handleUpdateArrivalRate}
                onNavigateToView={(view) => setCurrentWorkspaceView(view as any)}
                globalCompanies={globalCompanies}
                activeCompanyId={activeCompanyId}
                setActiveCompanyId={setActiveCompanyId}
                globalProjects={globalProjects}
                activeWorkspaceProjectId={activeWorkspaceProjectId}
                setActiveWorkspaceProjectId={setActiveWorkspaceProjectId}
                charter={charter}
                setCharter={setCharter}
              />
            ) : (
              <SigmaTrendDashboard
                stats={stats}
                onNavigateHome={() => setCurrentWorkspaceView("EXECUTIVE")}
              />
            )}
          </div>
        );

      case "PORTFOLIO":
        return (
          <div className="animate-fade-in text-left">
            <CompanyProjectsModule
              activeUser={activeUser}
              currentCargo={currentCargo}
              activeCompanyId={activeCompanyId}
              setActiveCompanyId={setActiveCompanyId}
              activeProjectId={activeWorkspaceProjectId}
              setActiveProjectId={setActiveWorkspaceProjectId}
              onNavigateToMap={() => {
                setProcessSubView("MAPPER");
                setCurrentWorkspaceView("PROCESSES");
              }}
            />
          </div>
        );

      case "PROCESSES":
        return (
          <ProcessesPage
            activeCompanyId={activeCompanyId}
            setActiveCompanyId={setActiveCompanyId}
            activeWorkspaceProjectId={activeWorkspaceProjectId}
            setActiveWorkspaceProjectId={setActiveWorkspaceProjectId}
            globalCompanies={globalCompanies}
            globalProjects={globalProjects}
            steps={steps}
            setSteps={handleUpdateSteps}
            arrivalRate={arrivalRate}
            setArrivalRate={handleUpdateArrivalRate}
            activeUser={activeUser}
            currentCargo={currentCargo}
            setCurrentCargo={setCurrentCargo}
            onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
            charter={charter}
            setCharter={handleUpdateCharter}
            sipoc={sipoc}
            setSipoc={handleUpdateSipoc}
            businessType={businessType}
            setBusinessType={handleSelectBusinessType}
            setCurrentWorkspaceView={setCurrentWorkspaceView}
            onOpenAssistente={() => setShowCopilot(true)}
          />
        );

      case "IMPROVEMENTS":
        return (
          <Phase4ProjectPanel
            activeProjectName={activeProjectName}
            activeWorkspaceProjectId={activeWorkspaceProjectId}
            globalProjects={globalProjects}
            setGlobalProjects={setGlobalProjects}
            globalCompanies={globalCompanies}
            setGlobalCompanies={setGlobalCompanies}
            activeUser={activeUser}
            deliverables={deliverables}
            setDeliverables={setDeliverables}
            projectActions={projectActions}
            setProjectActions={setProjectActions}
            projectHistory={projectHistory}
            setHistory={setHistory}
            projectDetails={projectDetails}
            setProjectDetails={setProjectDetails}
            projectEvidences={projectEvidences}
            setProjectEvidences={setProjectEvidences}
            steps={steps}
            setSteps={handleUpdateSteps}
            charter={charter}
            setCharter={handleUpdateCharter}
            sipoc={sipoc}
            setSipoc={handleUpdateSipoc}
            controlPlans={controlPlans}
            setControlPlans={handleUpdateControlPlans}
            stats={stats}
            arrivalRate={arrivalRate}
            projectsSubView={projectsSubView}
            setProjectsSubView={setProjectsSubView}
            setCurrentWorkspaceView={setCurrentWorkspaceView}
            businessType={businessType}
            setBusinessType={handleSelectBusinessType}
            activeAreaId={activeAreaId}
            setActiveAreaId={setActiveAreaId}
            setActiveDetailStepId={setActiveDetailStepId}
            setActiveCompanyId={setActiveCompanyId}
            setActiveWorkspaceProjectId={setActiveWorkspaceProjectId}
            analyzeTab={analyzeTab}
            setAnalyzeTab={setAnalyzeTab}
            aiLoading={aiLoading}
            handleCallGeminiApi={handleCallGeminiApi}
            triggerFlash={triggerFlash}
            generateDefaultDeliverables={generateDefaultDeliverables}
          />
        );

      case "OPERATIONS":
        return (
          <div className="animate-fade-in text-left">
            <WipKanbanBoard
              steps={steps}
              stats={stats}
              arrivalRate={arrivalRate}
              defaultFilterStepId={selectedFocusStepId}
              activeAreaId={activeAreaId}
              onSwitchArea={handleSwitchArea}
              processesByArea={processesByArea}
              activeCompanyId={activeCompanyId}
              activeWorkspaceProjectId={activeWorkspaceProjectId}
              globalCompanies={globalCompanies}
              globalProjects={globalProjects}
            />
          </div>
        );

      case "COMPLIANCE":
        return (
          <div className="space-y-6 animate-fade-in text-left">
            <div className="border-b border-[#1A1A1A]/10 pb-4">
              <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-wider font-mono">Governança, Riscos e Prevenção</p>
              <h2 className="text-2xl font-serif font-black text-slate-900 uppercase">Riscos e Controles (Risk Auditor)</h2>
              <p className="text-xs text-slate-500 font-sans">Mapeamento dinâmico de inconsistências operacionais e gargalos de fluxo de processos.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-8 space-y-4">
                <div className="border border-slate-200 p-5 bg-white shadow-3xs rounded-xl text-left space-y-4">
                  <div className="flex items-center justify-between border-b pb-2">
                    <h3 className="font-serif font-black text-slate-950 uppercase text-xs">Mapeador de Impactos de Risco</h3>
                    <span className="text-[9.5px] font-mono text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full font-bold">SOX &amp; LGPD</span>
                  </div>

                  <div className="space-y-3">
                    {[
                      { t: "Risco de Saturamento de Gargalo", d: "Quando a taxa de chegada supera o throughput do gargalo.", p: "Crítico", s: "Impedir novos lotes por Kanban automático" },
                      { t: "Desvio Térmico SPC", d: "Variação de temperatura na refusão acima de 3 Sigma.", p: "Alto", s: "Acionar termopar extra e alertas sonoros" },
                      { t: "Fila Acumulada no Atendimento", d: "SLA estocástico ultrapassa limite regulatório.", p: "Médio", s: "Balancear capacidade com robôs de automação" }
                    ].map((r, i) => (
                      <div key={i} className="p-3 border rounded-xl hover:bg-slate-50 transition flex items-start gap-3">
                        <div className={`w-3 h-3 rounded-full mt-1 shrink-0 ${r.p === "Crítico" ? "bg-red-650 animate-ping" : r.p === "Alto" ? "bg-amber-550" : "bg-blue-550"}`}></div>
                        <div className="text-xs space-y-0.5">
                          <p className="font-bold text-slate-800 uppercase">{r.t}</p>
                          <p className="text-slate-505 font-sans">{r.d}</p>
                          <p className="text-[10px] text-indigo-705 font-semibold uppercase mt-1">Mitigação Recomendada: {r.s}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-4 space-y-4">
                <AuditSuggestion
                  steps={steps}
                  stats={stats}
                />
              </div>
            </div>
          </div>
        );

      case "REPORTS":
        return (
          <div className="animate-fade-in text-left">
            <ReportPresentationGenerator
              steps={steps}
              stats={stats}
              charter={charter}
              sipoc={sipoc}
              controlPlans={controlPlans}
              arrivalRate={arrivalRate}
            />
          </div>
        );

      case "ADMINISTRATION":
        return (
          <div className="animate-fade-in text-left">
            <PermissionGuard
              user={authenticatedUser}
              permission="admin:view"
              fallback={adminFallback}
            >
              <AdminPanel
                enabledViews={enabledViews}
                setEnabledViews={setEnabledViews}
                companies={globalCompanies}
                setCompanies={setGlobalCompanies}
                projects={globalProjects}
                setProjects={setGlobalProjects}
                charter={charter}
                setCharter={setCharter}
                sipoc={sipoc}
                setSipoc={setSipoc}
                controlPlans={controlPlans}
                setControlPlans={setControlPlans}
                activeWorkspaceProjectId={activeWorkspaceProjectId}
                activeCompanyId={activeCompanyId}
                arrivalRate={arrivalRate}
                setArrivalRate={setArrivalRate}
                steps={steps}
                setSteps={setSteps}
                currentWorkspaceView={currentWorkspaceView}
                setCurrentWorkspaceView={setCurrentWorkspaceView}
                currentCargo={currentCargo}
                setCurrentCargo={setCurrentCargo}
                rolePermissions={rolePermissions}
                setRolePermissions={setRolePermissions}
                onTriggerSharePortal={() => setSharePortalModalOpen(true)}
                usabilityMode={usabilityMode}
                setUsabilityMode={setUsabilityMode}
                usabilityLocked={usabilityLocked}
                setUsabilityLocked={setUsabilityLocked}
                onOpenOnboarding={() => setIsOnboardingOpen(true)}
                onOpenGallery={() => setIsTemplateGalleryOpen(true)}
                scheduledAudits={scheduledAudits}
                setScheduledAudits={setScheduledAudits}
              />
            </PermissionGuard>
          </div>
        );

      case "ENTERPRISE_OVERVIEW":
        return (
          <div className="animate-fade-in text-left">
            <EnterpriseOverviewDashboard
              activeUser={activeUser}
              currentCargo={currentCargo}
              companies={globalCompanies}
              projects={globalProjects}
              projectDataStore={projectDataStore}
              activeCompanyId={activeCompanyId}
              activeProjectId={activeWorkspaceProjectId}
              onSelectCompany={setActiveCompanyId}
              onSelectProject={setActiveWorkspaceProjectId}
              onNavigateToAdmin={() => setCurrentWorkspaceView("ADMINISTRATION")}
              onNavigateToProjectWorkspace={(projectId, companyId) => {
                setActiveCompanyId(companyId);
                setActiveWorkspaceProjectId(projectId);
                setCurrentWorkspaceView("IMPROVEMENTS");
              }}
            />
          </div>
        );

      default:
        return <EmptyState type="no_project" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-[#1A1A1A] font-sans flex flex-col antialiased selection:bg-[#C49746]/10 selection:text-[#C49746]">
      {isTrainingModeActive && (
        <div className="bg-[#D97706] text-white text-[11px] font-mono font-bold py-2.5 px-6 text-center flex items-center justify-center gap-3 tracking-wide border-b border-black z-50 shadow-md shrink-0">
          <span className="flex items-center gap-1.5">🔬 <strong className="uppercase">Modo de Treinamento Ativo (Sandbox)</strong> • As gravações no banco de dados estão inativadas para proteger os dados reais de seus clientes.</span>
          <button
            type="button"
            onClick={() => handleToggleTrainingMode(false)}
            className="bg-white hover:bg-neutral-100 text-[#D97706] px-3 py-1 rounded-sm text-[9px] font-bold tracking-tight uppercase cursor-pointer shadow-[2px_2px_0px_rgba(26,26,26,1)] transition active:translate-y-0.5 border border-amber-600 font-mono"
          >
            Retornar ao Modo Real ×
          </button>
        </div>
      )}
      
      {/* Editorial Decorative Frame Outer Border */}
      <div className="border-[6px] border-[#1A1A1A] flex-grow flex flex-col md:flex-row min-h-screen">
        
        {/* DESKTOP SIDEBAR NAVIGATION */}
        <aside className={`hidden md:flex flex-col ${isSidebarCollapsed ? "w-[60px]" : "w-64"} bg-[#1A1A1A] text-slate-100 border-r border-[#1A1A1A] shrink-0 font-sans justify-between text-left transition-all duration-300`}>
          <div className="flex flex-col flex-grow overflow-y-auto no-scrollbar">
            {/* Sidebar Brand Header */}
            <div className={`p-4 border-b border-slate-800 flex ${isSidebarCollapsed ? "flex-col items-center justify-center gap-3" : "flex-row items-center justify-between"} transition-all`}>
              {!isSidebarCollapsed ? (
                <>
                  <div className="flex items-center gap-2.5">
                    <div className="bg-white p-1 rounded-sm">
                      <E3ILogo width={85} height={38} variant="light" />
                    </div>
                    <div>
                      <h1 className="text-[12px] font-serif font-black tracking-tight text-[#C49746]">E3I PROCESSOS</h1>
                      <span className="text-[7.5px] font-mono text-slate-400 font-extrabold uppercase tracking-widest block leading-tight">Inteligentes</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleToggleSidebar}
                    className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                    title="Minimizar Menu"
                  >
                    <ChevronLeft size={15} />
                  </button>
                </>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <button
                    type="button"
                    onClick={handleToggleSidebar}
                    className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer mb-1"
                    title="Expandir Menu"
                  >
                    <ChevronRight size={15} />
                  </button>
                  <div className="bg-[#C49746] text-black w-8 h-8 rounded-md flex items-center justify-center font-serif font-black text-[10px] border border-amber-600 shadow-sm" title="E3I Processos Inteligentes">
                    E3I
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar Menu Navigation */}
            <nav className={`flex-grow space-y-1.5 text-left overflow-y-auto pr-1 select-none max-h-[calc(100vh-140px)] ${isSidebarCollapsed ? "p-1.5" : "p-3"}`}>
              {(() => {
                let lastCategory = "";
                return [
                  { id: "PORTFOLIO", category: "1. Estratégia da Empresa", label: "Estratégia & Projetos", expertLabel: "Estratégia & Projetos", subtitle: "Planejamento Estratégico & Projetos", icon: <Compass size={15} /> },
                  { id: "DIAGNOSTIC", category: "2. Diagnóstico Inicial", label: "Diagnóstico 360°", expertLabel: "Diagnóstico 7S", subtitle: "Maturidade e Diagnóstico 7S", icon: <HelpCircle size={15} /> },
                  { id: "STRATEGY", category: "3. Estruturar a Empresa", label: "Estratégia & OKRs", expertLabel: "BSC / OKRs", subtitle: "Desdobramento Estratégico", icon: <Target size={15} /> },
                  { id: "ORGANIZATION", category: "3. Estruturar a Empresa", label: "Organograma & Papéis", expertLabel: "Operating Model", subtitle: "Estrutura & Organização", icon: <Network size={15} /> },
                  { id: "GOVERNANCE", category: "3. Estruturar a Empresa", label: "Direitos de Decisão", expertLabel: "RACI / Governança", subtitle: "Matriz de Responsabilidades", icon: <ShieldCheck size={15} /> },
                  { id: "CHANGE_MANAGEMENT", category: "3. Estruturar a Empresa", label: "Gestão de Mudança", expertLabel: "Kotter / ADKAR", subtitle: "Prontidão e Transição", icon: <Megaphone size={15} /> },
                  { id: "PROCESSES", category: "4. Estruturar o Processo", label: "Mapeamento Processual", expertLabel: "BPMN & Cadeia de Valor", subtitle: "Mapeador de Processos", icon: <BookOpen size={15} /> },
                  { id: "BI_STUDIO", category: "5. Dados e BI", label: "Estúdio de BI & Simulação", expertLabel: "Simulador Estocástico", subtitle: "Simulador de Capacidade", icon: <Activity size={15} /> },
                  { id: "OR_HUB", category: "5. Dados e BI", label: "Pesquisa Operacional", expertLabel: "Teoria das Filas", subtitle: "Cálculos de Otimização", icon: <Sliders size={15} /> },
                  { id: "SIGMA_TREND", category: "5. Dados e BI", label: "Controle Estatístico", expertLabel: "SPC / Variabilidade", subtitle: "Desvios & Tendências CEP", icon: <TrendingUp size={15} /> },
                  { id: "DMAIC", category: "6. Otimizar", label: "Melhorias DMAIC", expertLabel: "Roteiro DMAIC", subtitle: "Assistente de Otimização", icon: <Sparkles size={15} /> },
                  { id: "REORGANIZATION", category: "6. Otimizar", label: "Plano de Ação 5W2H", expertLabel: "Plano Reorg & Kanban", subtitle: "Ações corretivas", icon: <Layers size={15} /> },
                  { id: "REORGANIZATION_DASHBOARD", category: "7. Resultados", label: "Indicadores de ROI", expertLabel: "ROI & Impacto de Negócio", subtitle: "Ganhos e Saúde de Negócio", icon: <TrendingUp size={15} /> },
                  { id: "EXECUTIVE", category: "7. Resultados", label: "Painel de Decisões", expertLabel: "Painel Executivo", subtitle: "Saúde e Visões Decisórias", icon: <ShieldCheck size={15} /> },
                  { id: "ENTERPRISE_OVERVIEW", category: "7. Resultados", label: "Visão Geral Corporativa", expertLabel: "Enterprise Overview", subtitle: "Cycle Time & Nível Sigma Portfolio", icon: <Briefcase size={15} /> },
                  { id: "REPORT", category: "7. Resultados", label: "Apresentação Executiva", expertLabel: "Relatório LSS", subtitle: "Relatório & Slides Prontos", icon: <FileText size={15} /> },
                  { id: "ADMINISTRATION", category: "Apoio", label: "Painel Administrativo", expertLabel: "Configurações Gerais", subtitle: "Mapeamento Multi-Tenant", icon: <Sliders size={15} /> }
                ].map((menuItem) => {
                  const isActive = currentWorkspaceView === menuItem.id;
                  const isAllowed = isModuleAllowed(menuItem.id);
                  if (!isAllowed) return null;

                  const isExp = usabilityMode === "EXPERT";
                  const displayLabel = isExp ? menuItem.expertLabel : menuItem.label;

                  const showHeader = !isSidebarCollapsed && lastCategory !== menuItem.category;
                  if (showHeader) {
                    lastCategory = menuItem.category;
                  }

                  return (
                    <Fragment key={menuItem.id}>
                      {showHeader && (
                        <div className="text-[9px] font-mono uppercase font-black text-[#C49746] px-3 pt-3.5 pb-1 tracking-wider border-t border-slate-800/40 mt-3 first:mt-0 first:border-0 block">
                          {menuItem.category}
                        </div>
                      )}
                      {isSidebarCollapsed ? (
                        <button
                          onClick={() => setCurrentWorkspaceView(menuItem.id as any)}
                          className="w-9 h-9 mx-auto flex items-center justify-center rounded-lg transition-all cursor-pointer relative group"
                          style={isActive ? { backgroundColor: "#C49746", color: "#000000" } : {}}
                          title={`${displayLabel}${isExp && menuItem.subtitle ? ` - ${menuItem.subtitle}` : ""}`}
                        >
                          <div className="flex items-center justify-center" style={isActive ? { color: "#000000" } : { color: isActive ? "#000000" : "#94A3B8" }}>
                            {cloneElement(menuItem.icon, { size: 18, className: "stroke-[2.5]" })}
                          </div>

                          <span className="absolute left-12 scale-0 group-hover:scale-100 transition-all duration-200 bg-[#141414] border border-slate-700/60 text-slate-100 text-[10px] uppercase font-mono font-black py-1.5 px-3.5 rounded shadow-2xl whitespace-nowrap z-50 pointer-events-none origin-left flex flex-col">
                            <span>{displayLabel}</span>
                            {isExp && menuItem.subtitle && (
                              <span className="text-[8px] font-mono text-[#C49746] normal-case font-bold mt-0.5 leading-tight">{menuItem.subtitle}</span>
                            )}
                          </span>
                        </button>
                      ) : (
                        <button
                          onClick={() => setCurrentWorkspaceView(menuItem.id as any)}
                          className="w-full flex items-start gap-3 px-3 py-1.5 rounded-lg transition-all cursor-pointer text-slate-400 hover:text-white hover:bg-slate-800/60"
                          style={isActive ? { backgroundColor: "#C49746", color: "#000000" } : {}}
                        >
                          <div className="mt-0.5" style={isActive ? { color: "#000000" } : {}}>
                            {menuItem.icon}
                          </div>
                          <div className="flex flex-col text-left">
                            <span className="text-xs font-black uppercase tracking-tight" style={isActive ? { color: "#000000", fontWeight: "950" } : {}}>
                              {displayLabel}
                            </span>
                            {isExp && menuItem.subtitle && (
                              <span className="text-[9px] font-mono leading-tight mt-0.5 font-semibold tracking-tighter" style={isActive ? { color: "#1A1A1A" } : { color: "#8A8A8A" }}>
                                {menuItem.subtitle}
                              </span>
                            )}
                          </div>
                        </button>
                      )}
                    </Fragment>
                  );
                });
              })()}
            </nav>
          </div>

          {/* Sidebar Footer User Info & Preferences */}
          <div className={`border-t border-slate-800 bg-black/10 text-left ${isSidebarCollapsed ? "p-2" : "p-4"}`}>
            {isSidebarCollapsed ? (
              <div className="flex flex-col items-center gap-3">
                {/* Profile Badge */}
                <div 
                  className="shrink-0 w-8 h-8 rounded-full bg-[#C49746]/15 border border-[#C49746]/30 text-[#C49746] flex items-center justify-center font-serif font-black text-xs cursor-pointer"
                  title={`${activeUser?.fullName || "Usuário"} (${activeUser?.belt || "Nível"})`}
                >
                  {activeUser?.fullName ? activeUser.fullName.charAt(0) : "U"}
                </div>

                {/* Preferences toggle as a simple button */}
                <button
                  type="button"
                  onClick={() => {
                    if (usabilityLocked && !hasPermission(authenticatedUser, "process:advanced-analysis")) {
                      alert("⚠️ Modo Especialista travado para visualização do cliente final.");
                      return;
                    }
                    const nextMode = usabilityMode === "SIMPLE" ? "EXPERT" : "SIMPLE";
                    setUsabilityMode(nextMode);
                    setCurrentWorkspaceView(nextMode === "SIMPLE" ? ("DASHBOARD_LEIGO" as any) : ("DIAGNOSTIC" as any));
                  }}
                  className="w-9 h-9 rounded-lg flex items-center justify-center text-xs transition-all cursor-pointer bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
                  title={`Alternar Modo: ${usabilityMode === "SIMPLE" ? "Mudar para Avançado ⚡" : "Mudar para Simples 🌱"}`}
                >
                  {usabilityMode === "SIMPLE" ? "🌱" : "⚡"}
                </button>

                {/* Guard Lock Control compact */}
                {authenticatedUser && (hasPermission(authenticatedUser, "admin:view") || hasPermission(authenticatedUser, "admin:manage-settings")) && (
                  <button
                    type="button"
                    onClick={() => {
                      setUsabilityLocked(!usabilityLocked);
                      if (!usabilityLocked) {
                        setUsabilityMode("SIMPLE");
                      }
                    }}
                    className={`w-9 h-9 rounded-lg flex items-center justify-center cursor-pointer border text-[11px] ${
                      usabilityLocked 
                        ? "bg-rose-950/40 text-rose-400 border-rose-900/40 hover:bg-rose-950/60" 
                        : "bg-emerald-950/20 text-emerald-400 border-emerald-950/40 hover:bg-emerald-950/40"
                    }`}
                    title={usabilityLocked ? "Sinal Verde p/ Cliente" : "Travar p/ Cliente"}
                  >
                    {usabilityLocked ? "🔒" : "🔓"}
                  </button>
                )}

                {/* Logout */}
                <button
                  onClick={async () => {
                    try {
                      await UserRepository.logout();
                    } catch (e) {
                      console.error("Erro logout:", e);
                    }
                    localStorage.setItem("lss_logged_out", "true");
                    localStorage.removeItem("six_sigma_active_user");
                    localStorage.removeItem("lss_active_company_id");
                    setActiveUser(null);
                    setActiveCompanyId(null);
                    setActiveWorkspaceProjectId(null);
                  }}
                  className="w-9 h-9 bg-slate-800/80 hover:bg-red-950/40 border border-slate-700/60 hover:border-red-900/60 rounded-lg flex items-center justify-center text-slate-400 hover:text-red-400 transition-all cursor-pointer"
                  title="Sair da Sessão"
                >
                  <LogOut size={12} />
                </button>
              </div>
            ) : (
              <div className="space-y-3.5">
                <div className="flex items-center gap-3">
                  <div className="shrink-0 w-8 h-8 rounded-full bg-[#C49746]/15 border border-[#C49746]/30 text-[#C49746] flex items-center justify-center font-serif font-black text-xs">
                    {activeUser?.fullName ? activeUser.fullName.charAt(0) : "U"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-extrabold text-white truncate leading-none mb-0.5">{activeUser?.fullName || "Usuário"}</p>
                    <span className="text-[8.5px] font-mono text-[#C49746] font-bold block uppercase tracking-tighter">{activeUser?.belt || "Nível"}</span>
                  </div>
                </div>

                {/* Preferências de Interface (FASE 15) */}
                <div className="pt-2 border-t border-slate-800/80 space-y-2">
                  <span className="text-[8px] font-mono tracking-widest font-black uppercase text-slate-500 block">PREFERÊNCIAS</span>
                  <div className="flex bg-slate-900 border border-slate-800 p-0.5 rounded-md gap-0.5 w-[215px] shrink-0">
                    <button
                      type="button"
                      id="usability-mode-layperson-sidebar"
                      onClick={() => {
                        setUsabilityMode("SIMPLE");
                        setCurrentWorkspaceView("DASHBOARD_LEIGO" as any);
                      }}
                      className={`flex-1 px-1.5 py-1 text-[9px] font-sans font-extrabold uppercase transition-all rounded-sm cursor-pointer border-0 ${
                        usabilityMode === "SIMPLE"
                          ? "bg-[#C49746] text-black shadow-xs font-black"
                          : "text-slate-400 hover:text-white bg-transparent"
                      }`}
                    >
                      🌱 Simples
                    </button>
                    <button
                      type="button"
                      id="usability-mode-professional-sidebar"
                      onClick={() => {
                        if (usabilityLocked && !hasPermission(authenticatedUser, "process:advanced-analysis")) {
                          alert("⚠️ Modo Especialista travado para visualização do cliente final.");
                          return;
                        }
                        setUsabilityMode("EXPERT");
                        setCurrentWorkspaceView("DIAGNOSTIC" as any);
                      }}
                      className={`flex-1 px-1.5 py-1 text-[9px] font-sans font-extrabold uppercase transition-all rounded-sm cursor-pointer border-0 ${
                        usabilityMode === "EXPERT"
                          ? "bg-slate-700 text-white font-black shadow-xs"
                          : "text-slate-400 hover:text-white bg-transparent"
                      } ${(usabilityLocked && !hasPermission(authenticatedUser, "process:advanced-analysis")) ? "opacity-30 cursor-not-allowed" : ""}`}
                    >
                      ⚡ Avançado
                    </button>
                  </div>

                  {/* Guard Lock Control */}
                  {authenticatedUser && (hasPermission(authenticatedUser, "admin:view") || hasPermission(authenticatedUser, "admin:manage-settings")) && (
                    <button
                      type="button"
                      onClick={() => {
                        setUsabilityLocked(!usabilityLocked);
                        if (!usabilityLocked) {
                          setUsabilityMode("SIMPLE");
                        }
                      }}
                      className={`w-[215px] text-[8.5px] font-mono font-bold uppercase py-1 border rounded-md cursor-pointer flex items-center justify-center gap-1.5 ${
                        usabilityLocked 
                          ? "bg-rose-950/40 text-rose-400 border-rose-900/40 hover:bg-rose-950/60" 
                          : "bg-emerald-950/20 text-emerald-400 border-emerald-950/40 hover:bg-emerald-950/40"
                      }`}
                    >
                      {usabilityLocked ? "🔒 Bloqueado p/ Cliente" : "🔓 Liberado p/ Cliente"}
                    </button>
                  )}
                </div>
                
                <button
                  onClick={async () => {
                    try {
                      await UserRepository.logout();
                    } catch (e) {
                      console.error("Erro logout:", e);
                    }
                    localStorage.setItem("lss_logged_out", "true");
                    localStorage.removeItem("six_sigma_active_user");
                    localStorage.removeItem("lss_active_company_id");
                    setActiveUser(null);
                    setActiveCompanyId(null);
                    setActiveWorkspaceProjectId(null);
                  }}
                  className="w-full bg-slate-800/80 hover:bg-red-950/40 border border-slate-700/60 hover:border-red-900/60 py-1.5 rounded-md text-[10px] uppercase font-mono font-bold text-slate-350 hover:text-red-400 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut size={11} />
                  <span>Sair da Sessão</span>
                </button>
              </div>
            )}
          </div>
        </aside>

        {/* MOBILE DRAWER NAV DRAWER OVERLAY */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 bg-black/55 z-45 md:hidden animate-fade-in text-left" onClick={() => setIsMobileMenuOpen(false)}>
            <div 
              className="w-64 bg-[#1A1A1A] h-full flex flex-col justify-between p-5 text-slate-100 animate-slide-in-left text-left"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="bg-white p-1 rounded-sm shrink-0">
                      <E3ILogo width={80} height={35} variant="light" />
                    </div>
                    <span className="text-xs font-serif font-black text-[#C49746] tracking-tight uppercase">E3I Processos</span>
                  </div>
                  <button onClick={() => setIsMobileMenuOpen(false)} className="text-slate-400 hover:text-white p-1.5 cursor-pointer">
                    <X size={16} />
                  </button>
                </div>

                <nav className="space-y-1 text-left overflow-y-auto max-h-[calc(100vh-160px)] select-none pr-1">
                  {(() => {
                    let lastCategory = "";
                    return [
                      { id: "PORTFOLIO", category: "1. Estratégia da Empresa", label: "Estratégia & Projetos", expertLabel: "Estratégia & Projetos", icon: <Compass size={14} /> },
                      { id: "DIAGNOSTIC", category: "2. Diagnóstico Inicial", label: "Diagnóstico 360°", expertLabel: "Diagnóstico 7S", icon: <HelpCircle size={14} /> },
                      { id: "STRATEGY", category: "3. Estruturar a Empresa", label: "Estratégia & OKRs", expertLabel: "BSC / OKRs", icon: <Target size={14} /> },
                      { id: "ORGANIZATION", category: "3. Estruturar a Empresa", label: "Organograma & Papéis", expertLabel: "Operating Model", icon: <Network size={14} /> },
                      { id: "GOVERNANCE", category: "3. Estruturar a Empresa", label: "Direitos de Decisão", expertLabel: "RACI / Governança", icon: <ShieldCheck size={14} /> },
                      { id: "CHANGE_MANAGEMENT", category: "3. Estruturar a Empresa", label: "Gestão de Mudança", expertLabel: "Kotter / ADKAR", icon: <Megaphone size={14} /> },
                      { id: "PROCESSES", category: "4. Estruturar o Processo", label: "Mapeamento Processual", expertLabel: "BPMN & Cadeia de Valor", icon: <BookOpen size={14} /> },
                      { id: "BI_STUDIO", category: "5. Dados e BI", label: "Estúdio de BI & Simulação", expertLabel: "Simulador Estocástico", icon: <Activity size={14} /> },
                      { id: "OR_HUB", category: "5. Dados e BI", label: "Pesquisa Operacional", expertLabel: "Teoria das Filas", icon: <Sliders size={14} /> },
                      { id: "SIGMA_TREND", category: "5. Dados e BI", label: "Controle Estatístico", expertLabel: "SPC / Variabilidade", icon: <TrendingUp size={14} /> },
                      { id: "DMAIC", category: "6. Otimizar", label: "Melhorias DMAIC", expertLabel: "Roteiro DMAIC", icon: <Sparkles size={14} /> },
                      { id: "REORGANIZATION", category: "6. Otimizar", label: "Plano de Ação 5W2H", expertLabel: "Plano Reorg & Kanban", icon: <Layers size={14} /> },
                      { id: "REORGANIZATION_DASHBOARD", category: "7. Resultados", label: "Indicadores de ROI", expertLabel: "ROI & Impacto de Negócio", icon: <TrendingUp size={14} /> },
                      { id: "EXECUTIVE", category: "7. Resultados", label: "Painel de Decisões", expertLabel: "Painel Executivo", icon: <ShieldCheck size={14} /> },
                      { id: "ENTERPRISE_OVERVIEW", category: "7. Resultados", label: "Visão Geral Corporativa", expertLabel: "Enterprise Overview", icon: <Briefcase size={14} /> },
                      { id: "REPORT", category: "7. Resultados", label: "Apresentação Executiva", expertLabel: "Relatório LSS", icon: <FileText size={14} /> },
                      { id: "ADMINISTRATION", category: "Apoio", label: "Painel Administrativo", expertLabel: "Configurações Gerais", icon: <Sliders size={14} /> }
                    ].map((menuItem) => {
                      const isActive = currentWorkspaceView === menuItem.id;
                      const isAllowed = isModuleAllowed(menuItem.id);
                      if (!isAllowed) return null;

                      const isExp = usabilityMode === "EXPERT";
                      const displayLabel = isExp ? menuItem.expertLabel : menuItem.label;

                      const showHeader = lastCategory !== menuItem.category;
                      if (showHeader) {
                        lastCategory = menuItem.category;
                      }

                      return (
                        <Fragment key={menuItem.id}>
                          {showHeader && (
                            <div className="text-[9px] font-mono uppercase font-black text-[#C49746] px-3 pt-3 pb-1 block border-t border-slate-800/40 mt-2 first:mt-0 first:border-0">
                              {menuItem.category}
                            </div>
                          )}
                          <button
                            onClick={() => {
                              setCurrentWorkspaceView(menuItem.id as any);
                              setIsMobileMenuOpen(false);
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold uppercase cursor-pointer text-slate-400 hover:text-white"
                            style={isActive ? { backgroundColor: "#C49746", color: "#000000", fontWeight: "900" } : {}}
                          >
                            <div style={isActive ? { color: "#000000" } : {}}>
                              {menuItem.icon}
                            </div>
                            <span>{displayLabel}</span>
                          </button>
                        </Fragment>
                      );
                    });
                  })()}
                </nav>
              </div>

              <div className="border-t border-slate-800 pt-4 space-y-3">
                <div className="text-xs text-left">
                  <p className="font-bold text-white">{activeUser?.fullName}</p>
                  <p className="text-[9.5px] text-[#C49746] font-mono uppercase">{activeUser?.belt}</p>
                </div>
                <button
                  onClick={() => {
                    localStorage.removeItem("six_sigma_active_user");
                    setActiveUser(null);
                  }}
                  className="w-full bg-slate-800 py-1.5 rounded text-[10px] uppercase font-mono font-bold text-slate-400 text-center cursor-pointer block"
                >
                  Desconectar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MAIN BODY AREA */}
        <div className="flex-grow flex flex-col bg-[#FDFCFB] overflow-x-hidden">
          
          {/* DESKTOP/MOBILE HEADER BAR */}
          {currentWorkspaceView !== "PROCESSES" && (
            <header className={`border-b py-3 px-6 md:px-12 shrink-0 transition-all duration-700 ease-out grid grid-cols-[auto_1fr_auto] items-center gap-4 w-full ${
              isHeaderHighlighted 
                ? "bg-[#FAF5EA] border-amber-400/50 ring-2 ring-amber-400/10" 
                : "bg-[#FDFCFB] border-[#1A1A1A]/10"
            }`}>
              {/* Mobile Bar Trigger & Logo */}
              <div className="flex items-center justify-between md:justify-start gap-4 shrink-0">
                <button 
                  type="button"
                  onClick={() => setIsMobileMenuOpen(true)}
                  className="p-2 -ml-2 rounded-md hover:bg-slate-100 text-slate-700 md:hidden cursor-pointer"
                  aria-label="Abrir menu móvel"
                >
                  <Menu size={20} />
                </button>

                <div className="md:hidden bg-white p-1 rounded-sm border shrink-0">
                  <E3ILogo width={85} height={35} variant="light" />
                </div>

                <div className="hidden md:block text-left">
                  <span className="text-[9px] font-bold text-slate-400 font-mono tracking-widest block uppercase">Plataforma Ativa</span>
                  <h2 className="text-sm md:text-base xl:text-lg font-serif font-black text-slate-900 leading-tight uppercase tracking-tight">E3I PROCESSOS INTELIGENTES</h2>
                </div>
              </div>

              {/* Hierarchy Layer & Drill Down Bar */}
              <div className="flex flex-wrap md:flex-nowrap items-center gap-2 text-left justify-start md:justify-center lg:justify-start min-w-0 flex-grow">
                
                {/* COMPANY SELECTOR DROPDOWN */}
                <div className="relative" ref={companyDropdownRef}>
                  <button
                    onClick={() => {
                      setIsCompanyDropdownOpen(!isCompanyDropdownOpen);
                      setIsProjectDropdownOpen(false);
                      if (!isCompanyDropdownOpen) {
                        handleLoadCompaniesWithStates();
                      }
                    }}
                    className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200/80 border border-slate-300 p-1.5 px-3 rounded-md text-xs font-bold text-slate-800 transition-all cursor-pointer shadow-3xs"
                    title="Selecionar ou Cadastrar Empresa Ativa"
                  >
                    <span className="p-0.5 bg-white border border-slate-200 rounded text-sm shadow-3xs">
                      {getIndustryIcon(globalCompanies.find(c => c.id === activeCompanyId)?.industry || "")}
                    </span>
                    <div className="flex flex-col text-left">
                      <span className="text-[8.5px] font-mono uppercase text-slate-400 font-bold tracking-wider leading-none">Empresa Ativa</span>
                      <span className="font-serif font-black uppercase text-slate-900 tracking-tight leading-tight max-w-[150px] truncate">
                        {globalCompanies.find(c => c.id === activeCompanyId)?.name || "Selecione a Empresa"}
                      </span>
                    </div>
                    <ChevronDown size={14} className={`text-slate-500 transition-transform ${isCompanyDropdownOpen ? "rotate-180" : ""}`} />
                  </button>

                  {/* POPUP COMPANY DROPDOWN MENU */}
                  {isCompanyDropdownOpen && (
                    <div className="absolute left-0 mt-1.5 w-80 bg-white border border-slate-300 rounded-lg shadow-xl z-50 p-2 space-y-2 animate-scale-up text-left">
                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 px-1">
                        <span className="text-[10px] font-mono font-bold uppercase text-slate-500">Selecionar Empresa</span>
                        <button
                          onClick={() => handleLoadCompaniesWithStates()}
                          disabled={isFetchingCompanies}
                          className="text-[10px] font-mono text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                          title="Atualizar lista de empresas do Firestore"
                        >
                          <RefreshCw size={11} className={isFetchingCompanies ? "animate-spin" : ""} />
                          {isFetchingCompanies ? "Sincronizando..." : "Sincronizar"}
                        </button>
                      </div>

                      {/* Search */}
                      <div className="relative">
                        <Search size={13} className="absolute left-2.5 top-2.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Buscar empresa..."
                          value={companySearchQuery}
                          onChange={(e) => setCompanySearchQuery(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 pl-8 pr-2 py-1.5 rounded text-xs font-mono text-slate-800 focus:outline-none focus:border-[#C49746]"
                        />
                      </div>

                      {/* List of Companies */}
                      <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
                        {globalCompanies
                          .filter(c => c.name.toLowerCase().includes(companySearchQuery.toLowerCase()) || (c.industry && c.industry.toLowerCase().includes(companySearchQuery.toLowerCase())))
                          .map(c => {
                            const isSelected = c.id === activeCompanyId;
                            const companyProjectsCount = globalProjects.filter(p => p.companyId === c.id).length;
                            return (
                              <button
                                key={c.id}
                                onClick={() => {
                                  setActiveCompanyId(c.id);
                                  setActiveWorkspaceProjectId(null);
                                  setIsCompanyDropdownOpen(false);
                                }}
                                className={`w-full flex items-center justify-between p-2 rounded text-left transition-colors cursor-pointer ${
                                  isSelected ? "bg-amber-50 border border-amber-200" : "hover:bg-slate-100"
                                }`}
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-base">{getIndustryIcon(c.industry || "")}</span>
                                  <div className="min-w-0">
                                    <div className="font-serif font-bold text-xs text-slate-900 truncate">{c.name}</div>
                                    <div className="text-[9.5px] font-mono text-slate-500 flex items-center gap-1">
                                      <span>{c.industry || "Serviços"}</span>
                                      <span>•</span>
                                      <span>{companyProjectsCount} projeto(s)</span>
                                    </div>
                                  </div>
                                </div>
                                {isSelected && <Check size={14} className="text-[#C49746] shrink-0" />}
                              </button>
                            );
                          })}

                        {globalCompanies.length === 0 && (
                          <div className="p-3 text-center text-xs text-slate-500 font-mono">
                            Nenhuma empresa cadastrada.
                          </div>
                        )}
                      </div>

                      {/* Footer Quick Action: Cadastrar Nova Empresa */}
                      <div className="pt-1.5 border-t border-slate-200">
                        <button
                          onClick={() => {
                            setIsCompanyDropdownOpen(false);
                            setIsHeaderNewCompanyModalOpen(true);
                          }}
                          className="w-full bg-[#C49746] hover:bg-[#a67c33] text-white p-2 rounded text-xs font-mono font-bold flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer transition-all"
                        >
                          <Plus size={14} />
                          Cadastrar Nova Empresa
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* DIVIDER / CHEVRON */}
                <ChevronRight size={14} className="text-slate-400 shrink-0 hidden sm:block" />

                {/* PROJECT SELECTOR DROPDOWN */}
                <div className="relative" ref={projectDropdownRef}>
                  <button
                    onClick={() => {
                      setIsProjectDropdownOpen(!isProjectDropdownOpen);
                      setIsCompanyDropdownOpen(false);
                    }}
                    className="flex items-center gap-2 bg-white hover:bg-slate-50 border border-slate-300 p-1.5 px-3 rounded-md text-xs font-bold text-slate-800 transition-all cursor-pointer shadow-3xs"
                    title="Selecionar Projeto Ativo ou Visão Geral"
                  >
                    <div className="flex flex-col text-left">
                      <span className="text-[8.5px] font-mono uppercase text-slate-400 font-bold tracking-wider leading-none">Projeto Vinculado</span>
                      <span className="font-sans font-extrabold text-slate-900 tracking-tight leading-tight max-w-[180px] truncate">
                        {activeWorkspaceProjectId
                          ? globalProjects.find(p => p.id === activeWorkspaceProjectId)?.name || "Projeto Selecionado"
                          : "🏢 Visão Geral da Empresa"}
                      </span>
                    </div>
                    <ChevronDown size={14} className={`text-slate-500 transition-transform ${isProjectDropdownOpen ? "rotate-180" : ""}`} />
                  </button>

                  {/* POPUP PROJECT DROPDOWN MENU */}
                  {isProjectDropdownOpen && (
                    <div className="absolute left-0 mt-1.5 w-72 bg-white border border-slate-300 rounded-lg shadow-xl z-50 p-2 space-y-1 animate-scale-up text-left">
                      <div className="text-[10px] font-mono font-bold uppercase text-slate-500 pb-1.5 border-b border-slate-200 px-1">
                        Selecionar Nível de Análise
                      </div>

                      {/* Option 1: Company Overview */}
                      <button
                        onClick={() => {
                          setActiveWorkspaceProjectId(null);
                          setIsProjectDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded text-left transition-colors cursor-pointer ${
                          !activeWorkspaceProjectId ? "bg-indigo-50 border border-indigo-200" : "hover:bg-slate-100"
                        }`}
                      >
                        <div>
                          <div className="font-serif font-bold text-xs text-indigo-950">🏢 Visão Geral Corporativa</div>
                          <div className="text-[9.5px] font-mono text-slate-500">Métricas consolidadas de todos os processos</div>
                        </div>
                        {!activeWorkspaceProjectId && <Check size={14} className="text-indigo-600 shrink-0" />}
                      </button>

                      <div className="text-[9.5px] font-mono font-bold uppercase text-slate-400 pt-1 px-1">
                        Projetos Vinculados ({globalProjects.filter(p => !activeCompanyId || p.companyId === activeCompanyId).length}):
                      </div>

                      {/* Projects List */}
                      <div className="max-h-48 overflow-y-auto space-y-1">
                        {globalProjects
                          .filter(p => !activeCompanyId || p.companyId === activeCompanyId)
                          .map(p => {
                            const isSelected = p.id === activeWorkspaceProjectId;
                            return (
                              <button
                                key={p.id}
                                onClick={() => {
                                  setActiveWorkspaceProjectId(p.id);
                                  if (p.companyId && p.companyId !== activeCompanyId) {
                                    setActiveCompanyId(p.companyId);
                                  }
                                  setIsProjectDropdownOpen(false);
                                }}
                                className={`w-full flex items-center justify-between p-2 rounded text-left transition-colors cursor-pointer ${
                                  isSelected ? "bg-emerald-50 border border-emerald-200" : "hover:bg-slate-100"
                                }`}
                              >
                                <div className="min-w-0">
                                  <div className="font-sans font-bold text-xs text-slate-900 truncate">{p.name}</div>
                                  <div className="text-[9.5px] font-mono text-slate-500">{p.status || "Em Andamento"}</div>
                                </div>
                                {isSelected && <Check size={14} className="text-emerald-600 shrink-0" />}
                              </button>
                            );
                          })}

                        {globalProjects.filter(p => !activeCompanyId || p.companyId === activeCompanyId).length === 0 && (
                          <div className="p-2 text-center text-xs text-slate-400 font-mono">
                            Nenhum projeto encontrado nesta empresa.
                          </div>
                        )}
                      </div>

                      {/* Link to Portfolio */}
                      <div className="pt-1.5 border-t border-slate-200">
                        <button
                          onClick={() => {
                            setCurrentWorkspaceView("PORTFOLIO");
                            setIsProjectDropdownOpen(false);
                          }}
                          className="w-full text-center text-xs font-mono font-bold text-slate-700 hover:text-slate-900 py-1 cursor-pointer"
                        >
                          Ir para Portfólio de Empresas & Projetos →
                        </button>
                      </div>
                    </div>
                  )}
                </div>

              </div>

            {/* Utility utilities */}
            <div className="flex items-center gap-1.5 shrink-0 justify-end md:border-l md:pl-3 border-slate-200">
              {/* Notification Bell */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 relative cursor-pointer flex items-center justify-center"
                  title="Avisos e Alertas"
                >
                  <Bell size={15} />
                  {scheduledAudits.filter(a => a.status === "Pendente").length > 0 && (
                    <span className="absolute -top-1 -right-1 bg-rose-600 text-white rounded-full text-[8px] font-mono font-bold px-1 min-w-[14px] h-[14px] flex items-center justify-center shadow-xs">
                      {scheduledAudits.filter(a => a.status === "Pendente").length}
                    </span>
                  )}
                </button>

                {showNotificationsDropdown && (
                  <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-350 rounded-xl shadow-lg z-50 p-3 text-left space-y-2">
                    <p className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">Auditorias Pendentes &amp; Alertas</p>
                    <div className="divide-y text-xs text-slate-600 max-h-64 overflow-y-auto font-sans">
                      {scheduledAudits.filter(a => a.status === "Pendente").length === 0 ? (
                        <div className="py-4 text-center text-slate-400 text-[11px]">
                          Não há auditorias pendentes no momento.
                        </div>
                      ) : (
                        scheduledAudits.filter(a => a.status === "Pendente").map((audit) => (
                          <div key={audit.id} className="py-2.5 space-y-1">
                            <div className="flex justify-between items-start gap-1">
                              <p className="font-bold text-slate-900 leading-tight">
                                📋 {audit.taskName}
                              </p>
                              <span className="text-[8.5px] font-mono font-bold uppercase text-[#C49746] bg-amber-50 px-1 border border-amber-200 shrink-0">
                                {audit.frequency}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-500 leading-normal">
                              Responsável: <strong>{audit.responsibleName}</strong>
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono">
                              Início: {audit.startDate}
                            </p>
                            <div className="pt-1 flex gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setScheduledAudits(prev => prev.map(a => 
                                    a.id === audit.id ? { ...a, status: "Concluída" as const } : a
                                  ));
                                }}
                                className="px-1.5 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-mono text-[9px] uppercase font-bold rounded-xs cursor-pointer"
                              >
                                ✓ Concluir
                              </button>
                            </div>
                          </div>
                        ))
                      )}

                      {/* Static backup for realism */}
                      <div className="py-2">
                        <p className="font-bold text-slate-900 border-[#C49746] pl-1">Acordo SOX Compliance</p>
                        <p className="text-[10px] text-slate-500">O log de auditoria cronológico de histórico do usuário foi persistido com sucesso.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Premium Usability Mode Switcher in Header */}
              <div className="flex items-center bg-slate-100 border border-slate-200 p-0.5 rounded-full select-none shadow-3xs" title="Modulação de Usabilidade: Simples ou Especialista">
                <button
                  type="button"
                  onClick={() => {
                    setUsabilityMode("SIMPLE");
                    setCurrentWorkspaceView("DASHBOARD_LEIGO" as any);
                  }}
                  className={`px-3 py-1 text-[10px] font-mono font-black uppercase tracking-tight rounded-full transition-all cursor-pointer flex items-center gap-1 ${
                    usabilityMode === "SIMPLE"
                      ? "bg-white text-emerald-800 border border-slate-250 shadow-3xs font-extrabold"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  🌱 Simples
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (usabilityLocked && !hasPermission(authenticatedUser, "process:advanced-analysis")) {
                      toast.error("⚠️ Modo Especialista travado para visualização do cliente final.");
                      return;
                    }
                    setUsabilityMode("EXPERT");
                    setCurrentWorkspaceView("DIAGNOSTIC" as any);
                  }}
                  className={`px-3 py-1 text-[10px] font-mono font-black uppercase tracking-tight rounded-full transition-all cursor-pointer flex items-center gap-1 ${
                    usabilityMode === "EXPERT"
                      ? "bg-slate-900 text-amber-500 border border-slate-900 shadow-3xs font-extrabold"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  ⚡ Avançado
                </button>
              </div>

              <button
                onClick={() => setIsOnboardingOpen(true)}
                className="p-1.5 rounded-lg hover:bg-slate-400/20 text-slate-550 hover:text-black cursor-pointer"
                title="Painel de Ajuda Integrada"
              >
                <HelpCircle size={15} />
              </button>

              {/* LOGGED IN USER & LOGOUT CONTAINER IN THE TOP RIGHT (AS REQUESTED) */}
              {activeUser && (
                <div className="flex items-center gap-2 border border-[#1A1A1A]/10 bg-[#FAF8F5] px-2.5 py-1 rounded-md text-left shadow-[1px_1px_0px_0px_rgba(26,26,26,1)] ml-1.5">
                  <div className="shrink-0 w-6 h-6 rounded-full bg-[#C49746]/10 text-[#C49746] flex items-center justify-center border border-[#C49746]/20 font-serif font-bold text-[10px] uppercase">
                    {activeUser.fullName ? activeUser.fullName.charAt(0) : "U"}
                  </div>
                  <div className="min-w-0 leading-none">
                    <div className="text-[9px] font-extrabold text-gray-950 truncate max-w-[100px]" title={activeUser.fullName}>
                      {activeUser.fullName}
                    </div>
                    <div className="text-[8px] text-[#C49746] font-mono font-bold flex items-center gap-0.5 mt-0.5 uppercase tracking-tighter">
                      <Award size={8} className="fill-[#C49746]/10" />
                      <span>{activeUser.belt || "Membro"}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await UserRepository.logout();
                      } catch (e) {
                        console.error("Erro ao efetuar logout no Firebase:", e);
                      }
                      localStorage.setItem("lss_logged_out", "true");
                      localStorage.removeItem("six_sigma_active_user");
                      localStorage.removeItem("lss_active_company_id");
                      setActiveUser(null);
                      setActiveCompanyId(null);
                      setActiveWorkspaceProjectId(null);
                      setCurrentWorkspaceView("PUBLIC_SALES");
                    }}
                    className="p-1 text-gray-400 hover:text-black hover:bg-gray-150 rounded transition-all cursor-pointer border border-transparent hover:border-gray-200 shrink-0 ml-1"
                    title="Sair da Sessão / Logout"
                  >
                    <LogOut size={12} />
                  </button>
                </div>
              )}
            </div>
        </header>
        )}

          {/* Breadcrumbs Section beneath Header */}
          {currentWorkspaceView !== "PROCESSES" && renderBreadcrumbs()}

          {/* TEMPORARY CONTAINER TO HOUSE REMOVED SECTION GENTLY */}
          <div className="hidden">
            <div className="lg:col-span-5 w-full border border-slate-200/80 p-4 bg-white shadow-3xs rounded-xl self-center transition-all hover:border-slate-300">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5 mb-1 text-left">
                <span className="text-[11px] font-sans font-bold text-slate-800 tracking-tight flex items-center gap-1.5 shrink-0">
                  <span className="text-sm">🏢</span> Seleção Corporativa Ativa
                </span>
                <div className="flex items-center gap-2 text-[9.5px] uppercase font-bold font-mono shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsHeaderNewCompanyModalOpen(true)}
                    className="text-[#C49746] hover:text-amber-800 transition-colors cursor-pointer hover:underline"
                    title="Adicionar uma nova empresa rápida"
                  >
                    + Nova Empresa
                  </button>
                  <span className="text-slate-200">|</span>
                  <button
                    type="button"
                    onClick={() => setCurrentWorkspaceView("CLIENT_PROJECTS")}
                    className="text-indigo-650 hover:text-indigo-850 transition-colors cursor-pointer hover:underline"
                    title="Acessar painel completo de gestão"
                  >
                    Configurações
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-left">
                {/* Company select dropdown */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="global-header-company-hidden" className="text-[9px] font-mono uppercase tracking-wider text-[#C49746] font-bold block">
                    Empresa / Cliente Ativo
                  </label>
                  <select
                    id="global-header-company-hidden"
                    data-icon={getIndustryIcon(globalCompanies.find(c => c.id === activeCompanyId)?.industry || tempCompIndustry || "")}
                    value={activeCompanyId || ""}
                    onFocus={handleRefreshGlobalData}
                    onChange={(e) => {
                      const cid = e.target.value || null;
                      setActiveCompanyId(cid);
                    }}
                    className="w-full bg-white hover:bg-slate-50 border-2 border-[#1A1A1A] px-2 py-1.5 font-sans text-xs font-bold text-gray-950 focus:outline-none focus:ring-2 focus:ring-[#C49746] focus:border-[#C49746] transition-all rounded-md shadow-3xs cursor-pointer truncate"
                  >
                    <option value="" className="text-gray-900 font-bold bg-white">-- Selecione uma Empresa --</option>
                    {globalCompanies.map((c) => (
                      <option key={c.id} value={c.id} className="text-gray-900 font-bold bg-white">
                        {getIndustryIcon(c.industry)} {c.name} {c.cnpj ? `(CNPJ: ${c.cnpj})` : ""}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Project select dropdown */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="global-header-project" className="text-[9px] font-mono uppercase tracking-wider font-bold text-slate-400">
                    <span>Projeto DMAIC Vinculado</span>
                  </label>
                  <select
                    id="global-header-project"
                    disabled={!activeCompanyId}
                    value={activeWorkspaceProjectId || ""}
                    onFocus={handleRefreshGlobalData}
                    onChange={(e) => {
                      const pid = e.target.value || null;
                      setActiveWorkspaceProjectId(pid);
                    }}
                    className="w-full px-2 py-1.5 font-sans text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-[#C49746] disabled:bg-slate-100 disabled:border-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed transition-all duration-300 rounded-md shadow-3xs cursor-pointer truncate bg-slate-50 hover:bg-slate-100/75 border border-slate-200 hover:border-slate-350 text-slate-800"
                  >
                    <option value="" className="text-slate-700 font-bold">
                      -- 🏢 Visão Geral da Empresa --
                    </option>
                    {globalProjects
                      .filter((p) => p.companyId === activeCompanyId)
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          📁 {p.name.length > 28 ? p.name.substring(0, 26) + "..." : p.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="lg:col-span-3 text-right lg:border-l lg:border-[#1A1A1A]/15 lg:pl-6 flex flex-row lg:flex-col justify-between items-center lg:items-end gap-3 shrink-0">
              {/* Logged in User Identity Card */}
              <div className="flex items-center gap-2 border border-[#1A1A1A]/10 bg-[#FAF8F5] p-2.5 rounded-sm lg:mb-1 text-left shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] self-start lg:self-end">
                <div className="shrink-0 w-7 h-7 rounded-full bg-[#C49746]/10 text-[#C49746] flex items-center justify-center border border-[#C49746]/20 font-serif font-bold text-xs uppercase">
                  {activeUser.fullName.charAt(0)}
                </div>
                <div className="min-w-0 pr-1 leading-none">
                  <div className="text-[10px] font-extrabold text-gray-950 truncate max-w-[110px]">{activeUser.fullName}</div>
                  <div className="text-[8.5px] text-[#C49746] font-mono font-bold flex items-center gap-0.5 mt-0.5 uppercase tracking-tighter">
                    <Award size={8} className="fill-[#C49746]/10" />
                    <span>{activeUser.belt}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await UserRepository.logout();
                    } catch (e) {
                      console.error("Erro ao efetuar logout no Firebase:", e);
                    }
                    localStorage.setItem("lss_logged_out", "true");
                    localStorage.removeItem("six_sigma_active_user");
                    localStorage.removeItem("lss_active_company_id");
                    setActiveUser(null);
                    setActiveCompanyId(null);
                    setActiveWorkspaceProjectId(null);
                    setCurrentWorkspaceView("PUBLIC_SALES");
                  }}
                  className="p-1 text-gray-400 hover:text-black hover:bg-gray-100 rounded transition-all cursor-pointer border border-transparent hover:border-gray-200 shrink-0"
                  title="Efetuar Logout Corporativo"
                >
                  <LogOut size={12} />
                </button>
              </div>

              <div className="flex flex-col items-end gap-1">
                <div className="text-[9px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest leading-none">Ambiente &amp; Status</div>
                <div className="flex items-center gap-2 mt-0.5">
                  <button
                    type="button"
                    onClick={() => handleToggleTrainingMode(!isTrainingModeActive)}
                    className={`px-2.5 py-1 text-[9.5px] font-mono font-extrabold uppercase transition-all rounded-sm border cursor-pointer flex items-center gap-1 ${
                      isTrainingModeActive
                        ? "bg-amber-600 hover:bg-amber-700 text-white border-amber-700 shadow-[2px_2px_0px_rgba(26,26,26,1)]"
                        : "bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300 shadow-[1px_1px_0px_rgba(26,26,26,1)]"
                    }`}
                    title={
                      isTrainingModeActive
                        ? "Modo Teste / Sandbox Ativo (Dados de Exemplo). Clique para alternar para Produção (Dados Reais)."
                        : "Ambiente de Produção Ativo (Dados Reais Limpos). Clique para alternar para Modo Teste / Sandbox."
                    }
                  >
                    <span>{isTrainingModeActive ? "🧪 Teste / Demo" : "🟢 Produção (Dados Reais)"}</span>
                  </button>
                  <span className="text-slate-200">|</span>
                  <div className="text-[10px] font-mono font-bold text-[#C49746] flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span> ONLINE
                  </div>
                </div>
              </div>
            </div>
          </div> {/* Close old header container wrapper */}

          {/* SECTOR & PROCESS TEMPLATE SWITCHER BLOCK */}
          {!isTopConfigExpanded ? (
            <div className="bg-[#0F172A] border-b border-slate-800 py-3 px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-3 text-slate-100 shadow-sm transition-all text-left">
              <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium tracking-wide">
                <span className="inline-flex items-center gap-1 bg-amber-600/20 text-[#C49746] border border-[#C49746]/30 px-2.5 py-0.5 rounded-md text-[9px] font-mono font-bold uppercase tracking-wider">
                  🎯 E3I Contexto
                </span>
                <span className="font-sans font-bold text-slate-200">
                  {BUSINESS_TERMS[businessType]?.title.split(" & ")[0] || "Operações"}
                </span>
                <span className="text-slate-600 font-bold mx-1">·</span>
                <span className="font-sans font-bold text-slate-100">
                  {globalCompanies.find(c => c.id === activeCompanyId)?.name || "Finanças"}
                </span>
                <span className="text-slate-600 font-bold mx-1">·</span>
                <span className="font-sans font-bold text-slate-200">
                  {globalProjects.find(p => p.id === activeWorkspaceProjectId)?.name || "Contas a pagar"}
                </span>
                <span className="text-slate-600 font-bold mx-1">·</span>
                <span className="font-sans text-slate-350 italic">
                  {templatesList.find(t => t.id === selectedTemplateId)?.name || "Procure-to-Pay"}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsTopConfigExpanded(true)}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 hover:text-white border border-slate-700/60 rounded-md text-[10.5px] uppercase font-mono font-bold text-[#C49746] tracking-wide cursor-pointer transition-all flex items-center gap-1 focus:ring-1 focus:ring-[#C49746]"
                title="Abrir configurações detalhadas de segmento, cenário e modelos iniciais"
              >
                ⚙️ Ajustar Diretrizes / Cenários
              </button>
            </div>
          ) : (
            <div className="bg-[#FAF8F5] border-b border-[#1A1A1A]/10 p-5 md:px-12 flex flex-col gap-5">
              <div className="flex justify-between items-center border-b border-gray-200 pb-2 mb-1">
                <h4 className="text-xs font-mono font-extrabold uppercase tracking-widest text-[#1A1A1A] flex items-center gap-2">
                  ⚙️ Painel Completo de Configuração &amp; Modelos
                </h4>
                <button
                  type="button"
                  onClick={() => setIsTopConfigExpanded(false)}
                  className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 rounded text-[10px] uppercase font-mono font-bold text-slate-750 cursor-pointer"
                >
                  Ocultar ▲
                </button>
              </div>

              {/* LSS Business Profile Selector */}
              <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                <div className="flex items-center gap-2.5 max-w-2xl text-left">
                  <span className="text-xl">💼</span>
                  <div className="text-left">
                    <h3 className="text-xs font-mono font-extrabold text-[#1A1A1A] uppercase tracking-wider">
                      Perfil de Negócio de Atuação
                    </h3>
                    <p className="text-[10px] text-gray-500 font-sans">
                      Filtre e adapte de forma modular todo o vocabulário, as abas ativas e os presets operacionais para a realidade da sua empresa.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {([
                    { type: "INDUSTRIAL", label: "Indústria & Fabricação", icon: "🏭", color: "hover:border-[#C49746] focus:ring-[#C49746]", activeBg: "bg-[#C49746]/5 border-[#C49746] text-[#C49746]" },
                    { type: "SERVICES", label: "Serviços & Escritórios", icon: "👥", color: "hover:border-[#4F46E5] focus:ring-[#4F46E5]", activeBg: "bg-[#4F46E5]/5 border-[#4F46E5] text-[#4F46E5]" },
                    { type: "RETAIL", label: "Comércio & Varejo", icon: "🛒", color: "hover:border-[#2563EB] focus:ring-[#2563EB]", activeBg: "bg-[#2563EB]/5 border-[#2563EB] text-[#2563EB]" },
                    { type: "LOGISTICS", label: "Logística & Distribuição", icon: "📦", color: "hover:border-[#059669] focus:ring-[#059669]", activeBg: "bg-[#059669]/5 border-[#059669] text-[#059669]" },
                    { type: "TECHNOLOGY", label: "Tecnologia & SaaS", icon: "💻", color: "hover:border-[#7C3AED] focus:ring-[#7C3AED]", activeBg: "bg-[#7C3AED]/10 border-[#7C3AED] text-[#7C3AED]" },
                    { type: "HEALTHCARE", label: "Saúde & Hospitalar", icon: "🏥", color: "hover:border-rose-600 focus:ring-rose-600", activeBg: "bg-rose-50 border-rose-600 text-rose-600" },
                    { type: "FINANCE", label: "Finanças & Contas", icon: "💰", color: "hover:border-amber-600 focus:ring-amber-600", activeBg: "bg-amber-50 border-amber-600 text-amber-600" },
                    { type: "HUMAN_RESOURCES", label: "RH / Gente & Gestão", icon: "🤝", color: "hover:border-teal-600 focus:ring-teal-600", activeBg: "bg-teal-50 border-teal-600 text-teal-600" }
                  ] as const)
                  .filter((profile) => {
                    if (activeCompanyId) {
                      const activeComp = globalCompanies.find(c => c.id === activeCompanyId);
                      if (activeComp && activeComp.industry) {
                        const companyBgType = mapIndustryToBusinessType(activeComp.industry);
                        return profile.type === companyBgType;
                      }
                    }
                    return true;
                  })
                  .map((profile) => {
                    const isActive = businessType === profile.type;
                    return (
                      <button
                        key={profile.type}
                        id={`btn-business-profile-${profile.type}`}
                        type="button"
                        onClick={() => handleSelectBusinessType(profile.type)}
                        className={`flex items-center gap-1.5 px-3 py-2 border-2 rounded-none text-xs font-bold transition-all duration-200 cursor-pointer ${
                          isActive
                            ? `${profile.activeBg} shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] font-serif italic scale-[1.02]`
                            : "border-gray-200 bg-white hover:bg-gray-50 text-gray-600 shadow-[1px_1px_0px_0px_rgba(26,26,26,0.05)]"
                        }`}
                      >
                        <span>{profile.icon}</span>
                        <span className="uppercase font-mono text-[9.5px] tracking-wider">{profile.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Template presets sub-selection */}
              <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 pt-3 border-t border-[#1A1A1A]/5 text-left">
                <div className="flex items-center gap-2">
                  <span className="text-xs">🎯</span>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">
                    Modelo Inicial de Cenário ({BUSINESS_TERMS[businessType]?.badge || "Módulo"}):
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {templatesList
                    .filter((tpl) => {
                      if (businessType === "INDUSTRIAL") return tpl.category === "manufatura";
                      if (businessType === "SERVICES") return ["financeiro", "contabil", "fiscal", "servicos"].includes(tpl.category);
                      if (businessType === "RETAIL") return tpl.category === "comercio";
                      if (businessType === "LOGISTICS") return tpl.category === "logistica";
                      return true;
                    })
                    .map((tpl) => {
                      const isSelected = selectedTemplateId === tpl.id;
                      let activeColor = "border-[#C49746] bg-amber-50 text-[#C49746]";
                      if (tpl.category === "financeiro") activeColor = "border-indigo-600 bg-indigo-50 text-indigo-950";
                      if (tpl.category === "contabil") activeColor = "border-emerald-600 bg-emerald-50 text-emerald-950";
                      if (tpl.category === "fiscal") activeColor = "border-blue-600 bg-blue-50 text-blue-950";
                      if (tpl.category === "comercio") activeColor = "border-blue-600 bg-blue-50 text-blue-950";
                      if (tpl.category === "logistica") activeColor = "border-emerald-600 bg-emerald-50 text-emerald-950";

                      return (
                        <button
                          key={tpl.id}
                          id={`btn-template-${tpl.id}`}
                          type="button"
                          onClick={() => handleSelectTemplate(tpl.id)}
                          className={`flex items-center gap-1.5 px-3 py-1 border rounded-sm text-[10.5px] font-medium transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? `${activeColor} border-2 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] scale-[1.01]`
                              : "border-gray-200 bg-white hover:bg-gray-50 text-gray-600"
                          }`}
                        >
                          <span>{tpl.icon}</span>
                          <span className="font-mono text-[9px] uppercase tracking-wider">{tpl.name}</span>
                        </button>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* DYNAMIC KPI STRIP (Editorial high-contrast design card) */}
          <section className="bg-[#F5F2ED] border-b border-[#1A1A1A]/10 grid grid-cols-2 lg:grid-cols-5 divide-y lg:divide-y-0 lg:divide-x divide-[#1A1A1A]/15">
            
            <div className="p-4 md:p-6 flex flex-col justify-between animate-fade-in">
              <div className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
                Performance Geral
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-3xl md:text-4xl font-serif leading-none italic font-semibold text-[#1A1A1A]">
                  <CountUp value={stats.sigmaLevel} decimals={2} />
                </span>
                <span className="text-xs text-[#1A1A1A]/60">σ</span>
              </div>
              <span className="text-[10px] text-[#1A1A1A]/60 mt-1 block">
                {BUSINESS_TERMS[businessType]?.sigmaSubtitle || "Nível Sigma combinado"}
              </span>
            </div>

            <div className="p-4 md:p-6 flex flex-col justify-between">
              <div className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
                {BUSINESS_TERMS[businessType]?.bottleneckDesc || "Gargalo do Processo"}
              </div>
              <div className="mt-2">
                <span className="text-sm md:text-base font-serif font-bold break-words line-clamp-1 text-[#C49746]">
                  {stats.bottleneckStepName || "Nenhum"}
                </span>
                <div className="text-[10px] text-[#1A1A1A]/60 mt-1 block">
                  Uso Máximo: <span className="font-bold"><CountUp value={stats.systemUtilization} decimals={1} useLocale={true} />%</span>
                </div>
              </div>
            </div>

            <div className="p-4 md:p-6 flex flex-col justify-between">
              <div className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
                {BUSINESS_TERMS[businessType]?.qualityTitle || "Qualidade Compilada FPP"}
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className={`text-2xl md:text-3xl font-serif font-semibold leading-none ${stats.rolledFirstPassYield < 0.90 ? "text-[#C49746]" : "text-[#10B981]"}`}>
                  <CountUp value={stats.rolledFirstPassYield * 100} decimals={1} useLocale={true} />%
                </span>
              </div>
              <span className="text-[9px] text-[#1A1A1A]/60 mt-1 block">
                DPMO: <CountUp value={stats.dpmo} decimals={0} useLocale={true} /> {BUSINESS_TERMS[businessType]?.dpmoLabel || "desvios"}
              </span>
            </div>

            <div className="p-4 md:p-6 flex flex-col justify-between animate-fade-in">
              <div className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
                {BUSINESS_TERMS[businessType]?.cycleTimeTitle || `${BUSINESS_TERMS[businessType]?.cycleTime} Total`}
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl md:text-3xl font-serif font-semibold leading-none">
                  <CountUp value={stats.leadTime} decimals={1} />
                </span>
                <span className="text-xs text-[#1A1A1A]/60">min</span>
              </div>
              <span className="text-[9px] text-[#1A1A1A]/60 mt-1 block">
                Trabalho Útil: <CountUp value={stats.processingTimeSum} decimals={1} useLocale={true} />m
              </span>
            </div>

            <div className="p-4 md:p-6 flex flex-col justify-between col-span-2 lg:col-span-1">
              <div className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
                {BUSINESS_TERMS[businessType]?.wip || "Estoque em Processo (WIP)"}
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl md:text-3xl font-serif font-semibold leading-none">
                  <CountUp value={stats.systemWip} decimals={1} useLocale={true} />
                </span>
                <span className="text-xs text-[#1A1A1A]/60">{unitLabelPlural || BUSINESS_TERMS[businessType]?.units || "itens"}</span>
              </div>
              <span className="text-[9px] text-[#1A1A1A]/60 mt-1 block">
                {BUSINESS_TERMS[businessType]?.littleLawSubtitle || "Pela Lei de Little estendida"}
              </span>
            </div>

          </section>

          {/* METHODOLOGY LANDSCAPE BRIEFING */}
          <div className="bg-[#FAF8F5] px-6 py-3 border-b border-[#1A1A1A]/10 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
            <div className="flex flex-col md:flex-row md:items-center gap-2 max-w-4xl text-[#1A1A1A]/80">
              <span className="text-[10px] font-mono font-bold bg-[#C49746]/10 text-[#C49746] px-2 py-0.5 rounded-sm uppercase tracking-wider shrink-0 whitespace-nowrap self-start md:self-auto">
                Multimétodo &amp; Excelência
              </span>
              <p className="text-[11px] leading-relaxed">
                Esta suíte integra metodologias para máxima eficiência organizacional: ela vai além do <strong>Six Sigma (DMAIC)</strong> ao incorporar o ecossistema de <strong>Gestão de Processos</strong>, <strong>Cultura Lean</strong>, governança <strong>BPMN</strong>, insights por <strong>Inteligência Artificial</strong>, <strong>Ciência de Dados</strong> e algoritmos de <strong>Pesquisa Operacional</strong>.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 justify-end">
              <span className="text-[9px] font-mono px-2 py-0.5 border border-gray-300 rounded-sm bg-white text-gray-650 font-medium">Gestão</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-indigo-200 rounded-sm bg-indigo-50 text-indigo-700 font-medium">Lean</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-amber-200 rounded-sm bg-amber-50 text-amber-800 font-medium">Six Sigma</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-blue-200 rounded-sm bg-blue-50 text-blue-700 font-medium font-medium">BPMN</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-fuchsia-200 rounded-sm bg-fuchsia-50 text-fuchsia-700 font-medium">I.A.</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-emerald-200 rounded-sm bg-emerald-50 text-emerald-800 font-medium">Dados</span>
              <span className="text-[9px] font-mono px-2 py-0.5 border border-purple-200 rounded-sm bg-purple-50 text-purple-700 font-medium">Pesq. Op.</span>
            </div>
          </div>

          {/* WARNING FOR Saturated Processes */}
          {stats.systemUtilization >= 100 && (
            <div id="saturation-banner" className="bg-[#C49746] text-white px-6 py-3 flex items-center justify-between text-xs font-medium tracking-wide">
              <div className="flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>
                  <strong>SATURAÇÃO ALIMENTAR!</strong> A taxa de chegada ({arrivalRate} u/h) excede a capacidade de processamento de uma das etapas. As filas crescem infinitamente até o colapso do sistema (Utilização de <strong>{stats.systemUtilization.toFixed(1)}%</strong>). Reduza a demanda ou aplique balanceamento.
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <div className="relative group flex items-center">
                  <span id="saturation-help-trigger" className="text-white/75 hover:text-white cursor-help p-1 transition-colors flex items-center justify-center">
                    <HelpCircle size={15} />
                  </span>
                  <div className="absolute right-0 bottom-full mb-2 w-72 bg-[#1A1A1A] text-white text-[11px] leading-relaxed p-3 rounded shadow-2xl border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-200 z-50">
                    <p className="font-bold mb-1 uppercase tracking-wider text-[#F59E0B]">Auditoria de Pesquisa Operacional</p>
                    <p className="text-white/90">
                      Este log snapshot registra o comportamento exato do sistema sob regime de saturação instável (tempo de fila infinito, Modelo G/G/c). É fundamental para auditar capacidades locais, validar tempos de ciclo teóricos e parametrizar simulações matemáticas que comprovem a necessidade científica da readequação de postos de trabalho.
                    </p>
                    <div className="absolute top-full right-3 border-4 border-transparent border-t-[#1A1A1A]"></div>
                  </div>
                </div>
                <button
                  id="download-saturation-report"
                  onClick={handleDownloadSaturationCSV}
                  title="Baixar Relatório de Auditoria de Saturação (CSV)"
                  className="bg-white/10 hover:bg-white/20 text-white transition p-1.5 rounded-sm border border-white/20 flex items-center justify-center cursor-pointer"
                >
                  <Download size={14} />
                </button>
                <button 
                  id="apply-balancing-quick"
                  onClick={handleApplyLeanOptimization} 
                  className="bg-white/10 hover:bg-white/20 transition px-3 py-1 rounded-sm border border-white/20 text-[10px] uppercase tracking-wide font-bold cursor-pointer"
                >
                  Aplicar Balanceamento
                </button>
              </div>
            </div>
          )}

          {/* BREADCRUMB / ACCESSIBLE WAY TO NAVIGATION RESET */}
          {currentWorkspaceView !== "DIAGNOSTIC" && (
            <div className="bg-[#FAF9F5] border-b border-[#1A1A1A]/10 px-6 py-2 flex items-center justify-between text-[11px] font-sans font-medium text-gray-700">
              <div className="flex items-center gap-1.5">
                <span className="text-gray-400 font-mono text-[10px]">📍 Navegação LSS</span>
                <span className="text-gray-300">/</span>
                <span className="text-gray-500 font-mono text-[10px]">{activeAreaId.toUpperCase()}</span>
                <span className="text-gray-300">/</span>
                <span className="font-bold text-gray-800 uppercase font-mono text-[10px]">{currentWorkspaceView}</span>
              </div>
              <button
                onClick={() => {
                  setCurrentWorkspaceView("DIAGNOSTIC");
                  setSelectedFocusStepId("ALL");
                }}
                className="text-amber-700 hover:text-amber-900 font-extrabold font-mono text-[10.5px] uppercase flex items-center gap-1 hover:underline transition-all cursor-pointer bg-white border border-gray-300 hover:border-amber-400 px-3 py-1 rounded-sm shadow-xs"
                title="Voltar para a página inicial de Diagnóstico, Seleção de Problemas e Project Charter"
              >
                ◀ Voltar ao Início (Diagnóstico)
              </button>
            </div>
          )}

          {/* SELETOR GLOBAL DE ABAS (HUB DE OPERAÇÃO VS GESTÃO ADMIN DE CLIENTES) */}
          {!isCleanIsolatedMode && (
            <div className="bg-[#FAF9F6] border-b-2 border-[#1A1A1A] px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-[#1A1A1A]/5 shadow-sm">
              <div className="flex items-center gap-2">
                <span className="text-[9.5px] font-mono font-bold uppercase text-[#C49746] bg-[#C49746]/10 px-2.5 py-0.5 rounded-xs">
                  Módulo Ativo
                </span>
                <span className="text-xs font-serif font-bold text-slate-800 tracking-tight uppercase">
                  {activeWorkspaceHub === "DMAIC" ? "🚀 Jornada de Processos Six Sigma" : activeWorkspaceHub === "CLIENTS" ? "🏢 Cadastro Geral de Clientes & Projetos" : "⚙️ Painel do Administrador Técnico"}
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => handleSwitchWorkspaceHub("DMAIC")}
                  className={`py-1.5 px-3.5 text-[10.5px] font-mono font-black uppercase transition-all rounded-xs cursor-pointer border-2 border-[#1A1A1A] flex items-center gap-1.5 ${
                    activeWorkspaceHub === "DMAIC"
                      ? "bg-[#1A1A1A] text-white shadow-[3px_3px_0px_0px_rgba(180,83,9,1)] scale-[1.02]"
                      : "bg-white hover:bg-amber-50 text-slate-700 hover:border-amber-700"
                  }`}
                >
                  🚀 Jornada DMAIC
                </button>

                <button
                  type="button"
                  onClick={() => handleSwitchWorkspaceHub("CLIENTS")}
                  className={`py-1.5 px-3.5 text-[10.5px] font-mono font-black uppercase transition-all rounded-xs cursor-pointer border-2 border-[#1A1A1A] flex items-center gap-1.5 ${
                    activeWorkspaceHub === "CLIENTS"
                      ? "bg-indigo-900 border-indigo-950 text-white shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] scale-[1.02]"
                      : "bg-white hover:bg-slate-50 text-indigo-900 hover:border-indigo-900"
                  }`}
                >
                  🏢 Gerenciar Clientes &amp; Projetos
                </button>
              </div>
            </div>
          )}

          {/* WORKSPACE VIEW SWITCHER - REORGANIZED FOR LAYPERSON DESIGN (SEQUENTIAL DMAIC JOURNEY ACCORDING TO SYSTEM SCOPE) */}
          {activeWorkspaceHub === "DMAIC" && !isCleanIsolatedMode && (
            <div className="bg-[#FCFAF8] border-b border-[#1A1A1A]/15 px-6 py-6 space-y-5">
            
            {/* Header Title with explanation of current status for Laypersons */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1A1A1A]/10 pb-4">
              <div>
                <h3 className="text-sm font-serif font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#C49746] inline-block animate-pulse"></span>
                  Roteiro de Excelência Lean Six Sigma (D-M-A-I-C)
                </h3>
                <p className="text-[11px] text-slate-500 font-sans mt-0.5">
                  Preparamos um fluxo sequencial de 5 passos simples para leigos e especialistas seguirem o ciclo de vida rigorosamente sem se perderem:
                </p>
              </div>

              {/* Side controls - Admin, Share and Focus view consolidated into clean secondary row */}
              <div className="flex flex-wrap items-center gap-2">
                {currentCargo === "Admin" && (
                  <button
                    id="toggle-view-client-portal-btn"
                    onClick={() => setSharePortalModalOpen(true)}
                    className="py-1 px-3 text-[10px] font-extrabold uppercase transition-all rounded-xs flex items-center gap-1 text-amber-700 hover:text-white bg-amber-50 hover:bg-[#C49746] border border-amber-300 font-sans shadow-3xs cursor-pointer"
                    title="Configurar acesso, copiar link seguro ou simular o portal para o cliente"
                  >
                    🌐 Compartilhar Portal de Clientes
                  </button>
                )}

                {currentWorkspaceView !== "ADMIN" && (
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="text-[9.5px] uppercase font-bold text-slate-400 font-sans">
                      🎯 Filtrar Etapa:
                    </span>
                    <select
                      id="global-target-step-selector"
                      value={selectedFocusStepId}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSelectedFocusStepId(val);
                        if (val !== "ALL") {
                          const step = steps.find(s => s.id === val);
                          if (step) {
                            setSelectedDmaicStep(step);
                          }
                        }
                      }}
                      className="bg-white border border-[#1A1A1A]/15 py-0.5 px-2 font-serif text-[10.5px] font-bold focus:outline-none focus:border-indigo-600 rounded-2xs"
                      title="Ajuste os módulos abaixo para focar apenas nas prioridades, cartões, e fluxos da etapa selecionada"
                    >
                      <option value="ALL">🔍 Todos os Postos (Consol.)</option>
                      {steps.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} {s.name === stats.bottleneckStepName ? "(⚠️ Gargalo)" : ""}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>

            {/* ESTAÇÃO DE TRABALHO DMAIC UNIFICADA & FOCO ATIVO */}
            <div className="bg-white border-2 border-slate-900 rounded-sm p-5 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-5 text-left">
              {/* Header com os controles e o Botão de Voltar para onde estava */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">⚡</span>
                  <div>
                    <h3 className="text-xs font-mono font-black uppercase text-slate-800 tracking-wider">
                      Estação de Foco Ativo • Metodologia LSS
                    </h3>
                    <p className="text-[10px] text-slate-500 font-sans">
                      Acompanhamento cronológico do ciclo de melhoria contínua adaptado ao seu segmento.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleNavigateBack}
                    className="bg-white hover:bg-slate-50 border border-slate-300 hover:border-slate-800 text-slate-800 font-sans text-[11px] font-extrabold uppercase py-1.5 px-3 rounded-sm transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
                    title="Retornar para a tela ou etapa anterior acessada recentemente neste projeto"
                  >
                    <span>◀ Voltar para onde estava</span>
                    {viewHistory.length > 1 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C49746] animate-ping"></span>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      setCurrentWorkspaceView("CLIENT_PROJECTS");
                    }}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-600 font-sans text-[11px] font-bold uppercase py-1.5 px-3 rounded-sm transition-all flex items-center gap-1 cursor-pointer"
                    title="Voltar ao início do gerenciador corporativo de clientes e projetos"
                  >
                    📂 Outro Projeto
                  </button>
                </div>
              </div>

              {/* Linha Fina de Progresso de Fluxo - Agora elegante, não-repetitiva */}
              <div className="bg-slate-50 p-3 rounded-xs border border-slate-200">
                <div className="flex items-center justify-between text-[9px] font-mono uppercase font-semibold text-slate-400 mb-2 px-1">
                  <span>Trilha de Melhoria Lean Six Sigma (Focalizada)</span>
                  <span>Fase Atual: {activePhase}</span>
                </div>
                <div className="grid grid-cols-5 gap-2 relative">
                  {[
                    { id: "DEFINE" as DmaicPhaseType, label: "Definir", defaultView: "E3I_INTELLIGENCE" as const, details: "Inteligência & IA" },
                    { id: "MEASURE" as DmaicPhaseType, label: "Medir", defaultView: "MAP" as const, details: "Mapeamento Processo" },
                    { id: "ANALYZE" as DmaicPhaseType, label: "Analisar", defaultView: "OR_HUB" as const, details: "Saturação & CEP" },
                    { id: "IMPROVE" as DmaicPhaseType, label: "Melhorar", defaultView: "DMAIC" as const, details: "Melhorias Lean" },
                    { id: "CONTROL" as DmaicPhaseType, label: "Controlar", defaultView: "REPORT" as const, details: "Normativas & Relatório" }
                  ].map((ph, index) => {
                    const activeIndex = ["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"].indexOf(activePhase);
                    const isCurrent = ph.id === activePhase;
                    const isFinished = activeIndex > index;

                    return (
                      <button
                        key={ph.id}
                        onClick={() => {
                          setActivePhase(ph.id, true);
                          if (ph.id === "DEFINE" && activeWorkspaceProjectId) {
                            setCurrentWorkspaceView("E3I_INTELLIGENCE", true);
                          } else {
                            setCurrentWorkspaceView(ph.defaultView, true);
                          }
                          setTimeout(() => {
                            const element = document.getElementById("active-work-viewport");
                            if (element) {
                              element.scrollIntoView({ behavior: "smooth", block: "start" });
                              setIsWorkHighlighted(true);
                              setTimeout(() => {
                                setIsWorkHighlighted(false);
                              }, 1800);
                            }
                          }, 150);
                        }}
                        className={`flex items-center gap-1.5 p-1.5 border-2 transition-all text-left justify-center sm:justify-start cursor-pointer group rounded-xs relative ${
                          isCurrent 
                            ? "bg-[#C49746] border-slate-900 text-white shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] font-extrabold -translate-y-1.5 scale-[1.07] z-10" 
                            : isFinished 
                              ? "bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200" 
                              : "bg-white/55 border-slate-200 text-slate-400 hover:bg-slate-50 hover:text-slate-600"
                        }`}
                      >
                        {isCurrent && (
                          <span className="absolute -top-2 right-1.5 bg-slate-900 text-white font-mono text-[6.5px] px-1 py-0.2 rounded-2xs border border-slate-800 font-bold tracking-wider animate-bounce">
                            EM TRABALHO
                          </span>
                        )}
                        <span className={`w-4 h-4 rounded-full font-mono text-[9px] font-black flex items-center justify-center border ${
                          isCurrent 
                            ? "bg-white text-slate-900 border-white" 
                            : isFinished 
                              ? "bg-slate-800 text-white border-slate-800"
                              : "bg-slate-150 text-slate-500 border-slate-300"
                        }`}>
                          {isFinished ? "✓" : index + 1}
                        </span>
                        <div className="hidden sm:flex flex-col text-left leading-none">
                          <span className="text-[10px] font-extrabold uppercase tracking-tight">{ph.label}</span>
                          <span className={`text-[8px] font-normal truncate max-w-[90px] ${
                            isCurrent ? "text-amber-100 group-hover:text-white" : "text-slate-400 group-hover:text-slate-500"
                          }`}>{ph.details}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* CARD DE DESTAQUE TRIDIMENSIONAL: "Fase ativa em trabalho" - Muito à frente das outras */}
              {(() => {
                const phaseConfig: Record<DmaicPhaseType, {
                  letter: string;
                  label: string;
                  title: string;
                  goal: string;
                  instructions: string;
                  themeBg: string;
                  accentTextColor: string;
                  accentBadge: string;
                }> = {
                  DEFINE: {
                    letter: "D",
                    label: "Definir",
                    title: "Alinhamento Estratégico & Escopo do Projeto",
                    goal: "Vincular o projeto aos requisitos do cliente, formalizar o diagnóstico geral de gargalos e estruturar o contrato corporativo (Project Charter).",
                    instructions: "Selecione prioridades chaves, defina metas financeiras claras e preencha as cláusulas do contrato na aba de Diagnóstico.",
                    themeBg: "from-indigo-50/75 to-indigo-100/30 border-indigo-600",
                    accentTextColor: "text-indigo-800",
                    accentBadge: "bg-indigo-150 text-indigo-800"
                  },
                  MEASURE: {
                    letter: "M",
                    label: "Medir",
                    title: "Fluxograma de Operações & Tempos Reais",
                    goal: "Representar a trilha de atividades, coletar taxas médias de chegada, registrar desvios de processo e organizar o quadro tático de andamento.",
                    instructions: "Acesse o Mapeador Visual para ajustar os postos de processamento. Configure tempos e inspecione cartões Kanban.",
                    themeBg: "from-blue-50/75 to-blue-100/30 border-blue-600",
                    accentTextColor: "text-blue-800",
                    accentBadge: "bg-blue-150 text-blue-800"
                  },
                  ANALYZE: {
                    letter: "A",
                    label: "Analisar",
                    title: "Investigação Estatística & Saturação",
                    goal: "Medir filas acumuladas, localizar gargalos sistêmicos de fluxo através da Pesquisa Operacional e avaliar capabilidade sigma baseada em falhas.",
                    instructions: "Observe no CEP a flutuação estatística. Estude a relação de saturação de equipes na Pesquisa Operacional.",
                    themeBg: "from-purple-50/75 to-purple-100/30 border-purple-600",
                    accentTextColor: "text-purple-800",
                    accentBadge: "bg-purple-150 text-purple-800"
                  },
                  IMPROVE: {
                    letter: "I",
                    label: "Melhorar",
                    title: "Simulação de Cenários & Recomendador Inteligente",
                    goal: "Utilizar consultoria artificial especialista sobre as métricas do lote, realizar simulações estocásticas de redistribuição de tarefas e planejar a otimização de layout.",
                    instructions: "Invoque o Co-piloto Inteligente para criar propostas preventivas ou clique em Equilíbrio Automático de Capacidade.",
                    themeBg: "from-amber-50/75 to-amber-100/30 border-amber-600",
                    accentTextColor: "text-amber-800",
                    accentBadge: "bg-amber-150 text-amber-800"
                  },
                  CONTROL: {
                    letter: "C",
                    label: "Controlar",
                    title: "Normatização, Manuais Normativos & Ganhos Estabilizados",
                    goal: "Padronizar o redesenho vencedor via Manuais de Instrução Padrão (SOPs), redigir o sumário de retorno de investimento (ROI) e gerar o Relatório Executivo final da rodada.",
                    instructions: "Verifique os POPs, assine a rotina de conformidade diária e baixe a matriz executiva consolidada.",
                    themeBg: "from-emerald-50/75 to-emerald-100/30 border-emerald-600",
                    accentTextColor: "text-emerald-800",
                    accentBadge: "bg-emerald-150 text-emerald-800"
                  }
                };

                const currentCfg = phaseConfig[activePhase];

                return (
                  <div className={`p-5 rounded-sm border-2 bg-gradient-to-br ${currentCfg.themeBg} shadow-sm transition-all relative flex flex-col lg:flex-row justify-between gap-5 scale-[1.015]`}>
                    {/* Badge lateral 3D que indica área primária */}
                    <div className="absolute top-0 left-6 -translate-y-1/2 bg-slate-900 border border-slate-950 text-white font-mono text-[9px] px-2.5 py-0.5 tracking-widest font-black uppercase rounded-xs">
                      Área em Trabalho Ativo 📌
                    </div>

                    <div className="space-y-3 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`w-8 h-8 rounded-full flex items-center justify-center font-serif italic text-lg font-black bg-slate-900 text-white`}>
                          {currentCfg.letter}
                        </span>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] tracking-wider uppercase font-extrabold text-[#C49746] font-mono">
                              Fase atual do DMAIC
                            </span>
                            <span className="text-slate-350">•</span>
                            <span className="text-[10px] font-mono font-bold bg-slate-800 text-slate-100 px-1.5 py-0.2 rounded-2xs">
                              {BUSINESS_TERMS[businessType].badge}
                            </span>
                          </div>
                          <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">
                            {currentCfg.label.toUpperCase()}: {currentCfg.title}
                          </h4>
                        </div>
                      </div>

                      <div className="space-y-1 bg-white/50 border border-white/80 p-3 rounded-xs text-xs">
                        <p className="text-slate-800 font-medium leading-relaxed font-sans">
                          <strong>Objetivo Consolidado:</strong> {currentCfg.goal}
                        </p>
                        <div className="text-[10.5px] text-slate-600 flex items-center gap-1.5 pt-1 border-t border-slate-300/30 font-mono">
                          <span className="text-amber-700">💡 CONSELHO PRÁTICO:</span>
                          <span>{currentCfg.instructions}</span>
                        </div>
                      </div>
                    </div>

                    {/* Lado Direito do Foco Ativo: Ações Diretas */}
                    <div className="flex flex-col justify-between items-stretch lg:items-end gap-3 shrink-0 lg:w-72 bg-white/70 p-3 border border-slate-200/60 rounded-xs">
                      <div className="space-y-1 text-left lg:text-right">
                        <span className="text-[8px] font-mono font-bold text-slate-400 uppercase tracking-widest block">Guia de Encaminhamento</span>
                        <p className="text-[10px] text-slate-500 font-sans leading-tight">
                          Após realizar as análises e metas desta etapa de {BUSINESS_TERMS[businessType].unitSingular}, avance de fase:
                        </p>
                      </div>

                      {(() => {
                        const getFirstAllowedViewForPhase = (phase: DmaicPhaseType) => {
                          const phaseViews: Record<DmaicPhaseType, string[]> = {
                            DEFINE: ["E3I_INTELLIGENCE", "ENTERPRISE_STUDIO", "DIAGNOSTIC"],
                            MEASURE: ["MAP", "KANBAN"],
                            ANALYZE: ["OR_HUB", "SIGMA_TREND"],
                            IMPROVE: ["DMAIC", "BI_STUDIO"],
                            CONTROL: ["BPM", "REPORT"]
                          };
                          const views = phaseViews[phase] || [];
                          return views.find(v => isModuleAllowed(v)) || null;
                        };

                        const getNextPhaseNav = (current: DmaicPhaseType) => {
                          const phasesOrder: DmaicPhaseType[] = ["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"];
                          const currentIndex = phasesOrder.indexOf(current);

                          for (let i = currentIndex + 1; i < phasesOrder.length; i++) {
                            const nextPhase = phasesOrder[i];
                            const firstAllowedView = getFirstAllowedViewForPhase(nextPhase);
                            if (firstAllowedView) {
                              return {
                                id: nextPhase,
                                label: `Avançar para Passo ${i + 1}: ${
                                  nextPhase === "MEASURE" ? "Medir" :
                                  nextPhase === "ANALYZE" ? "Analisar" :
                                  nextPhase === "IMPROVE" ? "Melhorar" : "Controlar"
                                } ➔`,
                                defaultView: firstAllowedView
                              };
                            }
                          }
                          return null;
                        };

                        const nextPhaseInfo = getNextPhaseNav(activePhase);
                        if (!nextPhaseInfo) {
                          return (
                            <div className="text-[9.5px] font-mono font-black text-emerald-800 bg-emerald-50 border border-emerald-300 py-2 px-3.5 rounded-xs uppercase tracking-wider block text-center shadow-xs">
                              🏆 Ciclo de Ganhos Concluído!
                            </div>
                          );
                        }
                        return (
                          <button
                            onClick={() => {
                              setActivePhase(nextPhaseInfo.id, true);
                              setCurrentWorkspaceView(nextPhaseInfo.defaultView, true);
                              setTimeout(() => {
                                const element = document.getElementById("active-work-viewport");
                                if (element) {
                                  element.scrollIntoView({ behavior: "smooth", block: "start" });
                                  setIsWorkHighlighted(true);
                                  setTimeout(() => {
                                    setIsWorkHighlighted(false);
                                  }, 1800);
                                }
                              }, 150);
                            }}
                            className="bg-amber-600 hover:bg-slate-900 border-2 border-slate-950 text-white font-sans text-[11px] font-black uppercase tracking-wider py-2 px-3.5 shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:shadow-none transition-all cursor-pointer rounded-xs flex items-center justify-center gap-1 text-center"
                          >
                            <span>{nextPhaseInfo.label}</span>
                          </button>
                        );
                      })()}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Necessary Sub-tools to be active in the chosen phase */}
            <div className="flex flex-wrap items-center gap-2 bg-[#FAF9F5]/40 p-2 rounded-xs border border-slate-200">
              <span className="text-[8.5px] uppercase font-sans font-bold text-slate-500 tracking-wider pr-1">Módulos desta Fase:</span>
              
              <button
                type="button"
                onClick={() => setIsTemplatesHubOpen(true)}
                className="py-1 px-2.5 text-[9.5px] font-black uppercase transition-all rounded-xs cursor-pointer flex items-center gap-1 bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold border border-slate-950 shadow-3xs"
              >
                <Sparkles size={11} className="text-amber-400" />
                Templates de Segmento
              </button>

              {usabilityMode === "SIMPLE" && (
                <button
                  type="button"
                  onClick={() => navigateToWorksite("DASHBOARD_LEIGO")}
                  className={`py-1 px-2.5 text-[9.5px] font-black uppercase transition-all rounded-xs cursor-pointer flex items-center gap-1 ${
                    currentWorkspaceView === "DASHBOARD_LEIGO" 
                      ? "bg-amber-600 text-white shadow-3xs" 
                      : "bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold"
                  }`}
                >
                  🚥 Semáforo de Saúde
                </button>
              )}
              
            {activePhase === "DEFINE" && (
              <>
                {isModuleAllowed("E3I_INTELLIGENCE") && (
                  <button
                    onClick={() => navigateToWorksite("E3I_INTELLIGENCE")}
                    className={`py-1 px-2.5 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "E3I_INTELLIGENCE" ? "bg-[#C49746] text-white shadow-3xs animate-pulse" : "bg-slate-100 hover:bg-slate-200 text-[#C49746] border border-amber-200"
                    }`}
                  >
                    💡 1. Co-Piloto de IA E3I
                  </button>
                )}
                {isModuleAllowed("ENTERPRISE_STUDIO") && (
                  <button
                    onClick={() => navigateToWorksite("ENTERPRISE_STUDIO")}
                    className={`py-1 px-2.5 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "ENTERPRISE_STUDIO" ? "bg-indigo-600 text-white shadow-3xs animate-pulse" : "bg-slate-100 hover:bg-slate-200 text-indigo-600 border border-indigo-200"
                    }`}
                  >
                    🏆 2. Estrutura de Negócio &amp; Maturidade Lean
                  </button>
                )}
                {isModuleAllowed("DIAGNOSTIC") && (
                  <button
                    onClick={() => navigateToWorksite("DIAGNOSTIC")}
                    className={`py-1 px-2.5 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "DIAGNOSTIC" ? "bg-[#1A1A1A] text-white shadow-3xs hover:bg-[#252525]" : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-350"
                    }`}
                  >
                    📋 3. Diagnóstico &amp; Project Charter
                  </button>
                )}
                {isModuleAllowed("STRATEGY") && (
                  <button
                    onClick={() => navigateToWorksite("STRATEGY")}
                    className={`py-1 px-2.5 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "STRATEGY" ? "bg-[#C49746] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-350"
                    }`}
                  >
                    🏆 4. Estratégia &amp; OKRs
                  </button>
                )}
              </>
            )}

            {activePhase === "MEASURE" && (
              <>
                {isModuleAllowed("MAP") && (
                  <button
                    onClick={() => navigateToWorksite("MAP")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "MAP" ? "bg-[#1A1A1A] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-350"
                    }`}
                  >
                    🗺️ 1. Mapeador de Layout Estocástico
                  </button>
                )}
                {isModuleAllowed("KANBAN") && (
                  <button
                    onClick={() => navigateToWorksite("KANBAN")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "KANBAN" ? "bg-[#4F46E5] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-[#4F46E5] border border-indigo-100"
                    }`}
                  >
                    📊 2. Quadro Kanban WIP
                  </button>
                )}
              </>
            )}

            {activePhase === "ANALYZE" && (
              <>
                {isModuleAllowed("OR_HUB") && (
                  <button
                    onClick={() => navigateToWorksite("OR_HUB")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "OR_HUB" ? "bg-[#7C3AED] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-[#7C3AED] border border-purple-100"
                    }`}
                  >
                    🧮 1. Pesquisa Operacional &amp; Filas G/G/c
                  </button>
                )}
                {isModuleAllowed("SIGMA_TREND") && (
                  <button
                    onClick={() => navigateToWorksite("SIGMA_TREND")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "SIGMA_TREND" ? "bg-indigo-900 text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-indigo-900 border border-indigo-150"
                    }`}
                  >
                    📈 2. Desvios &amp; Tendência Sigma (SPC)
                  </button>
                )}
              </>
            )}

            {activePhase === "IMPROVE" && (
              <>
                {isModuleAllowed("DMAIC") && (
                  <button
                    onClick={() => {
                      navigateToWorksite("DMAIC");
                      if (!selectedDmaicStep) {
                        const mainBtl = steps.find(s => s.name === stats.bottleneckStepName) || steps[0];
                        setSelectedDmaicStep(mainBtl);
                      }
                    }}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "DMAIC" ? "bg-[#C49746] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-amber-905 border border-amber-200"
                    }`}
                  >
                    🚀 1. Central de Melhorias DMAIC
                  </button>
                )}
                {isModuleAllowed("BI_STUDIO") && (
                  <button
                    onClick={() => navigateToWorksite("BI_STUDIO")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "BI_STUDIO" ? "bg-indigo-600 text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-indigo-700 border border-indigo-200"
                    }`}
                  >
                    ⚙️ 2. Estúdio de BI &amp; Simulação Real
                  </button>
                )}
              </>
            )}

            {activePhase === "CONTROL" && (
              <>
                {isModuleAllowed("BPM") && (
                  <button
                    onClick={() => navigateToWorksite("BPM")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "BPM" ? "bg-[#2563EB] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-[#2563EB] border border-blue-200"
                    }`}
                  >
                    📜 1. Rotina de Padronização (SOP) &amp; DevOps
                  </button>
                )}
                {isModuleAllowed("REPORT") && (
                  <button
                    onClick={() => navigateToWorksite("REPORT")}
                    className={`py-1 px-2 text-[9.5px] font-bold uppercase transition-all rounded-xs cursor-pointer ${
                      currentWorkspaceView === "REPORT" ? "bg-[#059669] text-white shadow-3xs" : "bg-slate-100 hover:bg-slate-200 text-[#059669] border border-green-200"
                    }`}
                  >
                    📄 2. Relatório de Desvios &amp; Apresentação
                  </button>
                )}
              </>
            )}
          </div>
            </div>
          )}

          {/* PHASE TAB SELECTOR HEADER */}
          {currentWorkspaceView === "DMAIC" && (
            <nav className="flex overflow-x-auto border-b border-[#1A1A1A]/10 bg-white sticky top-0 z-30 justify-between items-center px-4 md:px-12 md:h-12">
              <div className="flex divide-x divide-[#1A1A1A]/10 my-1">
                {(["DEFINE", "MEASURE", "ANALYZE", "IMPROVE", "CONTROL"] as DmaicPhaseType[]).map((phase) => {
                  const isActive = activePhase === phase;
                  const isCompleted = completedPhases.includes(phase);
                  
                  const phaseNamesPt: Record<DmaicPhaseType, string> = {
                    DEFINE: "1. Definir",
                    MEASURE: "2. Medir",
                    ANALYZE: "3. Analisar",
                    IMPROVE: "4. Melhorar",
                    CONTROL: "5. Controlar"
                  };

                  return (
                    <button
                      key={phase}
                      id={`nav-phase-${phase}`}
                      onClick={() => {
                        setActivePhase(phase, true);
                        const defaultViews: Record<DmaicPhaseType, any> = {
                          DEFINE: "E3I_INTELLIGENCE",
                          MEASURE: "MAP",
                          ANALYZE: "OR_HUB",
                          IMPROVE: "DMAIC",
                          CONTROL: "REPORT"
                        };
                        const targetView = defaultViews[phase];
                        setCurrentWorkspaceView(targetView, true);
                        setTimeout(() => {
                          const element = document.getElementById("active-work-viewport");
                          if (element) {
                            element.scrollIntoView({ behavior: "smooth", block: "start" });
                          }
                        }, 150);
                      }}
                      className={`py-2 px-3 md:px-5 text-[11px] uppercase tracking-widest font-bold transition-all relative whitespace-nowrap ${
                        isActive 
                          ? "text-[#C49746] font-serif italic" 
                          : "text-[#1A1A1A]/60 hover:text-[#1A1A1A]"
                      }`}
                    >
                      <span>{phaseNamesPt[phase]}</span>
                      {isCompleted && <span className="ml-1 text-[#C49746] text-[9px]">●</span>}
                      {isActive && (
                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#C49746]"></div>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="hidden lg:flex items-center gap-3">
                <span className="text-[10px] italic text-[#1A1A1A]/50">
                  Ação DMAIC Recomendada:
                </span>
                <button
                  id="header-ai-analyze-btn"
                  onClick={handleCallGeminiApi}
                  disabled={aiLoading}
                  className="bg-[#1A1A1A] hover:opacity-90 disabled:opacity-50 text-white text-[9px] uppercase tracking-widest font-bold py-1.5 px-3 rounded-none flex items-center gap-1.5 transition-opacity"
                >
                  <Sparkles size={11} className="text-[#C49746]" />
                  {aiLoading ? "Analisando..." : "Análise Cognitiva AI"}
                </button>
              </div>
            </nav>
          )}

          {/* MAIN WORKING SUB-SCREEN AREA BASED ON TABS */}
          <main className={currentWorkspaceView === "PROCESSES" ? "flex-grow flex flex-col p-0" : "p-6 md:p-12 flex-grow"}>
            {renderMainWorkspaceViewport()}
            
            {/* Omitted legacy blocks */}
            <div className="hidden">
              
              {/* INSTRUÇÕES E ORIENTAÇÕES COMPASS PARA CONTROLE SIMPLIFICADO */}
            {usabilityMode === "SIMPLE" && (
              <div className="mb-8 border-2 border-amber-500/30 bg-gradient-to-br from-amber-50/25 to-orange-50/10 p-5 rounded-sm relative text-left shadow-xs">
                {/* Visual Title / Guide Status */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1A1A1A]/10 pb-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🧭</span>
                    <h3 className="text-xs font-mono font-black uppercase text-[#C49746] tracking-wider">
                      Guia de Bolso &amp; Roteiro do Cliente em Modo Simplificado
                    </h3>
                  </div>
                  <div className="flex items-center gap-1.5 self-start sm:self-auto select-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="text-[9px] font-mono uppercase text-slate-400 font-bold">Assistente Proativo • Tradução Linguística Ativa</span>
                  </div>
                </div>

                {/* SIMPLIFIED PHASE STATE - NO REPETITIVE GRID BUTTONS */}
                <div className="mb-4 bg-white border border-amber-500/10 p-4 rounded-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[9px] font-mono font-bold text-[#C49746] uppercase block">Foco Ativo do Projeto</span>
                    <h4 className="text-xs font-serif font-bold text-slate-800 uppercase mt-0.5">
                      Fase {
                        activePhase === "DEFINE" ? "01: DEFINIR" :
                        activePhase === "MEASURE" ? "02: MEDIR" :
                        activePhase === "ANALYZE" ? "03: ANALISAR" :
                        activePhase === "IMPROVE" ? "04: MELHORAR" : "05: CONTROLAR"
                      }
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-0.5 max-w-xl leading-tight">
                      {
                        activePhase === "DEFINE" ? "Nesta etapa, o foco é o alinhamento de escopos e metas do Project Charter." :
                        activePhase === "MEASURE" ? "Nesta etapa, o foco é o mapeamento visual do layout e dos tempos de atendimento." :
                        activePhase === "ANALYZE" ? "Nesta etapa, o foco é encontrar acúmulos de fila, desvios CEP ou gargalos de fluxo." :
                        activePhase === "IMPROVE" ? "Nesta etapa, o foco é o equilíbrio de capacidades auxiliado pelo Co-piloto de melhorias." :
                        "Nesta etapa, o foco é a formalização normatizada de POPs e apuração geral de resultados do negócio."
                      }
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 bg-slate-50 p-2.5 rounded border border-slate-200">
                    <span className="text-[9px] font-mono font-bold text-slate-400 block sm:text-right">Progresso</span>
                    <span className="text-xs font-extrabold text-[#C49746]">
                      {
                        activePhase === "DEFINE" ? "20% Concluído" :
                        activePhase === "MEASURE" ? "40% Concluído" :
                        activePhase === "ANALYZE" ? "60% Concluído" :
                        activePhase === "IMPROVE" ? "80% Concluído" :
                        "100% Concluído (Garantia)"
                      }
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                  
                  {/* Active Screen Goal in plain Portuguese */}
                  <div className="lg:col-span-8 space-y-2">
                    {currentWorkspaceView === "CLIENT_PROJECTS" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">🏢 Passo de Inicialização: Cadastrando seu Negócio</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Tudo começa aqui! Para simular cenários de faturamento e qualidade, você precisa de uma "Empresa" e um "Projeto" cadastrados nos formulários abaixo.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Cadastre sua Empresa informando o ramo no formulário abaixo.</li>
                          <li>Crie um Projeto para essa empresa (ex: "Otimização de Faturamento Hospitalar").</li>
                          <li>Ao selecionar o projeto ativo, repare que as metas do ciclo se carregarão automaticamente.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "DIAGNOSTIC" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">📋 Diagnóstico de Problema &amp; Acordo de Metas (Project Charter)</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          O "Project Charter" é como um contrato simples de melhoria. Aqui você define o problema que está doendo no dia a dia e estima qual o resultado desejado.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Escreva o problema de forma sincera (ex: "Demoramos muito no atendimento inicial").</li>
                          <li>Defina sua meta no formulário abaixo (ex: diminuir tempo de atendimento de 20 para 8 minutos).</li>
                          <li>Esta meta guiará todos os simuladores automáticos que propõem balanceamento nas próximas fases!</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "MAP" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">🗺️ Mapeamento Visual dos Postos e Filas Físicas</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          O Mapeador é onde você desenha os passos físicos do trabalho. Cada caixa é uma pessoa ou máquina atendendo clientes ou tarefas de negócios de forma sequencial.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Altere os servidores (quantas pessoas trabalham em cada posto) e os tempos (quanto tempo leva cada atendimento).</li>
                          <li>O posto com círculo ou tarja vermelha representa o seu <strong>Gargalo (o posto mais lento)</strong>, que está atrasando toda a empresa!</li>
                          <li>Ajuste a "Taxa de Demanda" no topo para ver como o acúmulo de novos pedidos provoca filas intermináveis.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "KANBAN" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">📊 Quadro Kanban de Trabalho Acumulado (WIP)</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          "WIP" significa Trabalho em Andamento. Esta tela mostra as tarefas físicas que estão paradas aguardando atendimento de forma didática.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Veja onde os cartões vermelhos se empilham: isso mostra visualmente as gavetas ou salas de recepção superlotadas.</li>
                          <li>Reduzir o WIP significa fazer o trabalho fluir mais rápido para o cliente final, gerando satisfação e recebimento ágil.</li>
                          <li>Monitore o tempo de fila gerado automaticamente em cada posto físico de fluxo.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "DMAIC" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">🚀 Assistente DMAIC Passo-a-Passo</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          O ciclo DMAIC (Definir, Medir, Analisar, Melhorar, Controlar) é o método científico usado pelas melhores empresas mundiais para eliminar atrasos e erros de faturamento de forma direcionada.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Acompanhe seu avanço clicando nas fases no menu superior.</li>
                          <li>Escreva suas notas e planos de contingência para guardar o histórico do que foi investigado e resolvido.</li>
                          <li>Marque atividades como concluídas para preencher seu selo de governança Lean.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "OR_HUB" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">🧮 Otimização Matemática de Filas (Pesquisa Operacional)</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Embora pareça matemática pesada, a Pesquisa Operacional calcula com precisão o risco de as pessoas desistirem do atendimento pela espera na fila.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Veja a probabilidade de saturação do sistema: se estiver em 100%, os clientes estão aguardando tempo demais.</li>
                          <li>O assistente faz cálculos sem você precisar programar. O segredo é alocar mais pessoas nos postos com alto desvio de tempo!</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "SIGMA_TREND" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">📈 Controle de Variabilidade e Estabilidade SPC</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Mais prejudicial do que um atendimento lento é um atendimento imprevisível! Se o seu tempo oscila de 2 minutos até 2 horas, seu cliente perde a confiança em você.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>As linhas pontilhadas representam o limite máximo tolerável de segurança.</li>
                          <li>Cada círculo representa uma amostra real. Se algum círculo sair das linhas de segurança, significa que houve uma falha de operação no dia correspondente!</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "E3I_INTELLIGENCE" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">💡 Diagnóstico de Gargalos por Inteligência Artificial</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Nossa Inteligência Artificial atua como um consultor certificado de plantão. Ela lê e compreende as configurações de tempos que você desenhou.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Clique na barra de sugestões abaixo para que a IA analise qual seu verdadeiro gargalo de negócio.</li>
                          <li>A IA rascunhará planos de balanceamento automáticos específicos para o seu setor comercial ou industrial.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "BI_STUDIO" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">⚙️ Simulações de Resultados e Ganhos Financeiros</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Antes de fazer reformas físicas na sua loja, fábrica ou escritório, simule as alterações aqui e economize somas expressivas, evitando riscos!
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Use o botão "Aplicar Balanceamento Saudável" para mover os funcionários automaticamente para locais onde há filas.</li>
                          <li>Veja o aumento projetado na capacidade final do processo (quantidade de pedidos que você passa a faturar por hora).</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "BPM" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">📜 Manuais e Manuais de Instrução de Trabalho Estágio Padrão (SOP)</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Para consolidar as vitórias e evitar o retorno a rotinas ineficientes, você precisa redigir um "SOP" — o manual do funcionário explicando cada detalhe.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Crie instruções de trabalho para o seu operador no posto de trabalho crítico.</li>
                          <li>Acesse guias e templates recomendados de governança corporativa no painel abaixo.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "REPORT" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">📄 Geração de Relatório de Lotes e Slides Executivos</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          A melhor parte do projeto: mostrar os resultados financeiros à diretoria e consolidar seus créditos de liderança!
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Navegue pelas abas abaixo para ver gráficos simples de Antes vs. Depois.</li>
                          <li>Imprima a ata do lote ou salve o relatório corporativo LSS pronto para suas apresentações de negócios.</li>
                        </ul>
                      </>
                    )}

                    {currentWorkspaceView === "STRATEGY" && (
                      <>
                        <h4 className="text-sm font-serif font-black text-slate-900 uppercase">🏆 Desdobramento Estratégico &amp; OKRs de Alto Impacto</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          Conecte o rumo de longo prazo da empresa com as prioridades imediatas. Reduza o achismo e garanta que cada membro do time tenha metas e responsabilidades numéricas transparentes.
                        </p>
                        <ul className="text-[11px] text-[#C49746] space-y-1 pl-4 list-disc font-semibold">
                          <li>Perspectiva Balanceada: equilibre metas financeiras com melhorias nos processos e no treinamento das pessoas.</li>
                          <li>OKRs de Curto Prazo: estabeleça metas de 30 a 90 dias com responsáveis e prazos claros para evitar dispersão.</li>
                          <li>Planos de Ação: crie listas de etapas para as iniciativas mais importantes e as execute semanalmente.</li>
                        </ul>
                      </>
                    )}
                  </div>

                  {/* Translator and Glossary Reference */}
                  <div className="lg:col-span-4 bg-[#C49746]/5 border border-[#C49746]/20 p-4 rounded-sm space-y-3">
                    <span className="text-[9px] font-mono tracking-widest font-black uppercase text-[#C49746] block leading-none">
                      📖 Tradutor de Palavras Difíceis
                    </span>
                    <div className="space-y-2.5 text-xs text-slate-700 leading-relaxed">
                      <div>
                        <strong className="text-slate-900 text-[11px] font-mono block">⏳ Tempo de Toque / Ciclo (Cycle Time):</strong>
                        <p className="text-[11px] text-slate-500 mt-0.5">Média de minutos que se leva para terminar uma tarefa individual.</p>
                      </div>
                      <div className="border-t border-dashed border-[#1A1A1A]/10 pt-2">
                        <strong className="text-slate-900 text-[11px] block">⚠️ Gargalo (Bottleneck):</strong>
                        <p className="text-[11px] text-slate-500 mt-0.5">A etapa mais devagar que segura toda a produtividade de sua organização.</p>
                      </div>
                      <div className="border-t border-dashed border-[#1A1A1A]/10 pt-2">
                        <strong className="text-slate-900 text-[11px] block">🎯 Nível Sigma (Índice de Qualidade):</strong>
                        <p className="text-[11px] text-slate-500 mt-0.5">Nota técnica do processo (1 a 6). Quanto maior, menos erros ocorrem.</p>
                      </div>
                      <div className="border-t border-dashed border-[#1A1A1A]/10 pt-2">
                        <strong className="text-slate-900 text-[11px] block">📈 Variabilidade (Desvio Padrão):</strong>
                        <p className="text-[11px] text-slate-500 mt-0.5">Indica se o atendimento é estável e previsível ou instável e flutuante.</p>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            )}
            </div> {/* Closing legacy hidden container */}

            {currentWorkspaceView !== "CLIENT_PROJECTS" &&
            currentWorkspaceView !== "ADMIN" &&
            currentWorkspaceView !== "ROI_DASHBOARD" &&
            currentWorkspaceView !== "SUBSCRIPTION_MANAGEMENT" &&
            currentWorkspaceView !== "PUBLIC_SALES" &&
            !activeWorkspaceProjectId ? (
              <div className="max-w-2xl mx-auto my-12 bg-[#FAF9F6] border-4 border-[#1A1A1A] p-10 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] rounded-sm text-left font-sans space-y-6">
                <div className="flex items-center gap-3 border-b-2 border-[#1A1A1A]/15 pb-4">
                  <Building2 size={32} className="text-[#C49746]" />
                  <div>
                    <h2 className="text-xl font-serif text-slate-900 font-extrabold uppercase tracking-tight">Ativação de Empresa &amp; Projeto</h2>
                    <p className="text-[10px] text-slate-500 font-mono tracking-widest uppercase">Motor Analítico DMAIC / SPC Selecionador</p>
                  </div>
                </div>
                
                <p className="text-sm text-slate-700 leading-relaxed font-sans">
                  Para analisar métricas estatísticas, rodar simulações de Monte Carlo ou preencher os formulários DMAIC, é necessário selecionar uma <strong>empresa ativa</strong> e um de seus <strong>projetos</strong> associados.
                </p>

                {/* Tab Navigation */}
                <div className="flex border-b-2 border-[#1A1A1A]">
                  <button
                    onClick={() => setInitTab("select")}
                    className={`px-4 py-2 text-xs font-mono font-bold uppercase cursor-pointer transition-all ${
                      initTab === "select"
                        ? "bg-[#1A1A1A] text-white"
                        : "bg-gray-150 text-slate-600 hover:bg-gray-200"
                    }`}
                  >
                    📂 Selecionar Existente
                  </button>
                  <button
                    onClick={() => setInitTab("create")}
                    className={`px-4 py-2 text-xs font-mono font-bold uppercase cursor-pointer transition-all ${
                      initTab === "create"
                        ? "bg-[#1A1A1A] text-white"
                        : "bg-gray-150 text-slate-600 hover:bg-gray-200"
                    }`}
                  >
                    ➕ Cadastro Rápido
                  </button>
                  <button
                    onClick={() => setInitTab("demo")}
                    className={`px-4 py-2 text-xs font-mono font-bold uppercase cursor-pointer transition-all ${
                      initTab === "demo"
                        ? "bg-[#1A1A1A] text-white"
                        : "bg-gray-150 text-slate-600 hover:bg-gray-200"
                    }`}
                  >
                    ⚡ Ambiente Demo (1-Click)
                  </button>
                </div>

                {/* Tab 1: Select Existing */}
                {initTab === "select" && (() => {
                  const currentCompanies = CompanyProjectRepository.getCompanies(activeUser?.email);
                  const currentProjects = CompanyProjectRepository.getProjects(activeUser?.email);

                  return (
                    <div className="space-y-4 animate-fade-in text-left">
                      <div>
                        <label className="block text-[11px] font-extrabold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">
                          🏢 Empresa / Cliente:
                        </label>
                        <select
                          value={activeCompanyId || ""}
                          onChange={(e) => {
                            const val = e.target.value || null;
                            setActiveCompanyId(val);
                            setActiveWorkspaceProjectId(null); // Clear project on company switch
                          }}
                          className="w-full bg-white border-2 border-[#1A1A1A] px-3 py-2.5 font-mono text-xs font-bold text-[#1A1A1A] outline-none rounded-none"
                        >
                          <option value="">-- Selecione uma Empresa --</option>
                          {currentCompanies.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name} ({c.industry || "Outros"})
                            </option>
                          ))}
                        </select>
                      </div>

                      {activeCompanyId ? (
                        <div className="space-y-4 animate-fade-in">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="block text-[11px] font-extrabold uppercase tracking-widest text-[#1A1A1A]/60">
                                📋 Selecionar Projeto LSS Existente:
                              </label>
                              <button
                                type="button"
                                onClick={() => setIsInlineCreatingProject(!isInlineCreatingProject)}
                                className="text-[10px] font-mono font-bold uppercase text-[#C49746] hover:text-[#9e7631] underline cursor-pointer flex items-center gap-1"
                              >
                                {isInlineCreatingProject ? "✖ Fechar Formulário" : "➕ Criar Projeto nesta Empresa"}
                              </button>
                            </div>

                            {(!isInlineCreatingProject || currentProjects.filter((p) => p.companyId === activeCompanyId).length > 0) && (
                              <select
                                value={activeWorkspaceProjectId || ""}
                                onChange={(e) => {
                                  const val = e.target.value || null;
                                  setActiveWorkspaceProjectId(val);
                                }}
                                className="w-full bg-white border-2 border-[#1A1A1A] px-3 py-2.5 font-mono text-xs font-bold text-[#1A1A1A] outline-none rounded-none"
                              >
                                <option value="">-- Selecione um Projeto --</option>
                                {currentProjects
                                  .filter((p) => p.companyId === activeCompanyId)
                                  .map((p) => (
                                    <option key={p.id} value={p.id}>
                                      {p.name} ({p.status || "Ativo"})
                                    </option>
                                  ))}
                              </select>
                            )}
                          </div>

                          {(isInlineCreatingProject || currentProjects.filter((p) => p.companyId === activeCompanyId).length === 0) && (
                            <div className="bg-amber-50/60 border-2 border-[#1A1A1A] p-4 space-y-3 animate-fade-in rounded-sm">
                              <div className="flex items-center justify-between border-b border-amber-200/80 pb-2">
                                <div className="flex items-center gap-1.5 text-xs font-bold font-serif text-slate-900 uppercase">
                                  <Plus size={14} className="text-[#C49746]" />
                                  <span>Novo Projeto em: {currentCompanies.find((c) => c.id === activeCompanyId)?.name || "Empresa Selecionada"}</span>
                                </div>
                                {currentProjects.filter((p) => p.companyId === activeCompanyId).length > 0 && (
                                  <button
                                    type="button"
                                    onClick={() => setIsInlineCreatingProject(false)}
                                    className="text-[10px] text-slate-500 hover:text-slate-800 uppercase font-mono cursor-pointer"
                                  >
                                    Cancelar
                                  </button>
                                )}
                              </div>

                              {currentProjects.filter((p) => p.companyId === activeCompanyId).length === 0 && (
                                <p className="text-xs text-amber-900 bg-amber-100/70 p-2.5 border border-amber-300/50 font-sans leading-relaxed">
                                  Esta empresa ainda não possui nenhum projeto cadastrado. Preencha o nome abaixo para cadastrar e ativar o primeiro projeto em poucos segundos:
                                </p>
                              )}

                              <div className="space-y-2.5 text-left">
                                <div>
                                  <label className="block text-[10px] font-bold uppercase text-slate-700 mb-1">
                                    Nome do Projeto DMAIC / LSS *
                                  </label>
                                  <input
                                    type="text"
                                    placeholder={`Ex: Otimização do Processo - ${currentCompanies.find((c) => c.id === activeCompanyId)?.name || ""}`}
                                    value={tempProjName}
                                    onChange={(e) => setTempProjName(e.target.value)}
                                    className="w-full bg-white border border-[#1A1A1A] p-2 text-xs font-mono font-semibold text-slate-900 focus:outline-none"
                                  />
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold uppercase text-slate-700 mb-1">
                                    Objetivo Principal do Projeto (Opcional)
                                  </label>
                                  <textarea
                                    placeholder="Descreva o objetivo estatístico ou meta de redução de desperdícios..."
                                    value={tempProjObj}
                                    onChange={(e) => setTempProjObj(e.target.value)}
                                    className="w-full bg-white border border-[#1A1A1A] p-2 text-xs font-sans text-slate-900 h-16 resize-none focus:outline-none"
                                  />
                                </div>

                                {/* Painel de Configuração Rápida */}
                                <div className="bg-amber-100/60 border border-amber-300 p-2.5 rounded-sm space-y-2 text-left">
                                  <div className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-amber-950">
                                    <Sliders size={13} className="text-[#C49746]" />
                                    <span>Painel de Configuração Rápida (Parâmetros Iniciais LSS)</span>
                                  </div>
                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                    <div>
                                      <label className="block text-[9.5px] font-bold uppercase text-slate-700 mb-1">
                                        Tamanho do Lote Inicial (unid.)
                                      </label>
                                      <input
                                        type="number"
                                        min={1}
                                        max={10000}
                                        value={tempBatchSize}
                                        onChange={(e) => setTempBatchSize(Math.max(1, parseInt(e.target.value) || 1))}
                                        className="w-full bg-white border border-[#1A1A1A] p-1.5 text-xs font-mono font-bold text-slate-900 focus:outline-none"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9.5px] font-bold uppercase text-slate-700 mb-1">
                                        Tempo de Setup Padrão (min)
                                      </label>
                                      <input
                                        type="number"
                                        min={0}
                                        max={1440}
                                        value={tempSetupTime}
                                        onChange={(e) => setTempSetupTime(Math.max(0, parseFloat(e.target.value) || 0))}
                                        className="w-full bg-white border border-[#1A1A1A] p-1.5 text-xs font-mono font-bold text-slate-900 focus:outline-none"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => {
                                  const comp = currentCompanies.find((c) => c.id === activeCompanyId);
                                  if (!comp) return;
                                  const pName = tempProjName.trim() || ("Melhoria de Processo - " + comp.name);
                                  const pid = "proj_" + Math.random().toString(36).substring(2, 6);
                                  const newProj = {
                                    id: pid,
                                    companyId: activeCompanyId,
                                    name: pName,
                                    objective: tempProjObj.trim() || "Diagnosticar capacidade de linha, variabilidade temporal e estabilidade Six Sigma.",
                                    status: "Em Andamento" as const,
                                    createdAt: new Date().toISOString(),
                                  };

                                  const email = activeUser?.email;
                                  const projs = CompanyProjectRepository.getProjects(email);
                                  projs.push(newProj);
                                  CompanyProjectRepository.saveProjects(projs, email);

                                  const store = CompanyProjectRepository.getProjectDataStore(email);
                                  store[pid] = {
                                    companyId: activeCompanyId,
                                    initialBatchSize: tempBatchSize,
                                    defaultSetupTime: tempSetupTime,
                                    steps: [
                                      {
                                        id: "step_pre_1",
                                        name: "Atendimento Inicial",
                                        resource: "Atendente",
                                        resourceCount: 1,
                                        processingTime: 12,
                                        standardDeviation: 2.5,
                                        setupTime: tempSetupTime,
                                        yieldRate: 0.95,
                                      },
                                    ],
                                    arrivalRate: 4,
                                    charter: {
                                      id: "char_" + pid,
                                      title: pName,
                                      businessCase: "Diagnóstico inicial de eficiência e identificação de gargalos.",
                                      problemStatement: "Oscilações de atendimento perceptíveis pelos clientes.",
                                      goalStatement: "Garantir estabilidade estatística e adequação de SLA.",
                                      scopeIn: "Atendimento direto.",
                                      scopeOut: "Faturas e cobranças.",
                                      team: "Grupo DMAIC " + comp.name,
                                      targetValue: 150,
                                    },
                                    controlPlans: [],
                                  };
                                  CompanyProjectRepository.saveProjectDataStore(store, email);

                                  setTempProjName("");
                                  setTempProjObj("");
                                  setIsInlineCreatingProject(false);
                                  setActiveWorkspaceProjectId(pid);
                                  handleRefreshGlobalData();
                                }}
                                className="w-full py-2.5 bg-[#1A1A1A] hover:bg-[#C49746] text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-2xs"
                              >
                                <Plus size={14} />
                                <span>⚡ Cadastrar e Ativar Projeto Agora</span>
                              </button>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500 italic">Selecione uma empresa corporativa acima para visualizar os projetos LSS disponíveis para ativação.</p>
                      )}

                      {currentCompanies.length === 0 && (
                        <div className="p-4 bg-slate-50 border border-slate-200 text-xs text-slate-600 text-center">
                          Nenhuma empresa cadastrada localmente ainda. Mude para a aba <strong>Cadastro Rápido</strong> para registrar sua primeira empresa em poucos segundos.
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Tab 2: Quick Create */}
                {initTab === "create" && (
                  <div className="space-y-4 animate-fade-in">
                    {!canCreateCompany() ? (
                      <div className="p-4 bg-amber-50 border-2 border-amber-500/30 text-amber-950 font-sans space-y-2">
                        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-amber-800">
                          <Lock size={14} className="shrink-0" />
                          <span>Acesso para Cadastro Restrito</span>
                        </div>
                        <p className="text-xs leading-relaxed">
                          Seu perfil funcional atual (<strong>{currentCargo}</strong>) possui direitos restritos de visualização. Apenas usuários logados com nível de acesso **Administrador (Admin)** ou **Dono do Processo** possuem permissões para cadastrar novas empresas corporativas no sistema.
                        </p>
                      </div>
                    ) : (
                      <>
                        <p className="text-xs text-slate-600">Cadastre uma empresa e o sistema gerará automaticamente um projeto operacional de partida já ativado.</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-widest text-slate-500 mb-1">Nome da Empresa / Cliente:</label>
                            <input
                              type="text"
                              placeholder="Ex: Alfa Transportadora S.A."
                              value={tempCompName}
                              onChange={(e) => setTempCompName(e.target.value)}
                              className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-widest text-slate-500 mb-1">Segmento de Mercado:</label>
                            <select
                              value={tempCompIndustry}
                              onChange={(e) => setTempCompIndustry(e.target.value)}
                              className="w-full bg-white border-2 border-[#1A1A1A] p-2 text-xs font-mono"
                            >
                              <option value="Industrial">Industrial &amp; Manufatura</option>
                              <option value="Serviços">Prestação de Serviços &amp; Consultoria</option>
                              <option value="Logística">Logística &amp; Cadeia de Suprimentos</option>
                              <option value="Tecnologia">Tecnologia &amp; Software SaaS</option>
                              <option value="Saúde">Saúde &amp; Clínicas</option>
                              <option value="Varejo">Varejo &amp; E-commerce</option>
                              <option value="Construção">Construção &amp; Infraestrutura</option>
                              <option value="Educação">Educação &amp; EdTech</option>
                              <option value="Energia">Energia &amp; Utilities</option>
                              <option value="Agronegócio">Agronegócio &amp; Agro</option>
                              <option value="Público">Setor Público &amp; Governo</option>
                            </select>
                          </div>
                        </div>

                        {/* Painel de Configuração Rápida do Projeto Inicial */}
                        <div className="bg-amber-100/60 border border-amber-300 p-3 rounded-sm space-y-2 text-left">
                          <div className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-amber-950">
                            <Sliders size={13} className="text-[#C49746]" />
                            <span>Painel de Configuração Rápida do Projeto Inicial</span>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[9.5px] font-bold uppercase text-slate-700 mb-1">
                                Tamanho do Lote Inicial (unid.)
                              </label>
                              <input
                                type="number"
                                min={1}
                                max={10000}
                                value={tempBatchSize}
                                onChange={(e) => setTempBatchSize(Math.max(1, parseInt(e.target.value) || 1))}
                                className="w-full bg-white border border-[#1A1A1A] p-2 text-xs font-mono font-bold text-slate-900 focus:outline-none"
                              />
                            </div>
                            <div>
                              <label className="block text-[9.5px] font-bold uppercase text-slate-700 mb-1">
                                Tempo de Setup Padrão (min)
                              </label>
                              <input
                                type="number"
                                min={0}
                                max={1440}
                                value={tempSetupTime}
                                onChange={(e) => setTempSetupTime(Math.max(0, parseFloat(e.target.value) || 0))}
                                className="w-full bg-white border border-[#1A1A1A] p-2 text-xs font-mono font-bold text-slate-900 focus:outline-none"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="pt-2 flex justify-end">
                          <button
                            onClick={() => {
                              if (!tempCompName.trim()) return;
                              const uSuffix = activeUser?.email ? `_${activeUser.email}` : "_anonymous";
                              
                              const cid = "comp_" + Math.random().toString(36).substring(2, 6);
                              const newCompany = {
                                id: cid,
                                name: tempCompName,
                                cnpj: "00.000.000/0001-00",
                                industry: tempCompIndustry, enabledModules: [],
                                createdAt: new Date().toISOString()
                              };

                              const pid = "proj_" + Math.random().toString(36).substring(2, 6);
                              const newProject = {
                                id: pid,
                                companyId: cid,
                                name: "Melhoria de Processo - " + tempCompName,
                                objective: "Diagnosticar capacidade de linha, variabilidade temporal e estabilidade Six Sigma.",
                                status: "Em Andamento" as const,
                                createdAt: new Date().toISOString()
                              };

                              const email = activeUser?.email;
                              const comps = CompanyProjectRepository.getCompanies(email);
                              comps.push(newCompany);
                              CompanyProjectRepository.saveCompanies(comps, email);

                              const projs = CompanyProjectRepository.getProjects(email);
                              projs.push(newProject);
                              CompanyProjectRepository.saveProjects(projs, email);

                          const store = CompanyProjectRepository.getProjectDataStore(email);
                          store[pid] = {
                            companyId: cid,
                            initialBatchSize: tempBatchSize,
                            defaultSetupTime: tempSetupTime,
                            steps: [
                              {
                                id: "step_pre_1",
                                name: "Atendimento Inicial",
                                resource: "Atendente",
                                resourceCount: 1,
                                processingTime: 12,
                                standardDeviation: 2.5,
                                setupTime: tempSetupTime,
                                yieldRate: 0.95
                              }
                            ],
                            arrivalRate: 4,
                            charter: {
                              id: "char_pre",
                              title: "Melhoria de Processo - " + tempCompName,
                              businessCase: "Diagnóstico inicial da eficiência e identificação de gargalos.",
                              problemStatement: "Oscilações de atendimento perceptíveis pelos clientes.",
                              goalStatement: "Garantir estabilidade estatística e adequação de SLA.",
                              scopeIn: "Atendimento direto.",
                              scopeOut: "Faturas e cobranças.",
                              team: "Grupo DMAIC " + tempCompName,
                              targetValue: 150
                            },
                            controlPlans: []
                          };
                          CompanyProjectRepository.saveProjectDataStore(store, email);

                          setActiveCompanyId(cid);
                          setActiveWorkspaceProjectId(pid);
                          setProjectDataStore(store);
                          setTempCompName("");
                        }}
                        disabled={!tempCompName.trim()}
                        className="bg-[#1A1A1A] hover:bg-[#C49746] text-white px-5 py-2 font-mono font-bold uppercase text-xs cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,0.2)] disabled:opacity-55 disabled:cursor-not-allowed"
                      >
                        ⚡ Cadastrar Empresa &amp; Criar Projeto
                      </button>
                    </div>
                      </>
                    )}
                  </div>
                )}

                {/* Tab 3: Demo Load */}
                {initTab === "demo" && (
                  <div className="space-y-4 animate-fade-in bg-amber-50/50 p-5 border border-amber-500/20">
                    <h3 className="font-serif text-sm font-bold text-amber-900">🚀 Ambiente Alta Fidelidade DeltaTech (Recomendado)</h3>
                    <p className="text-xs text-amber-800 leading-relaxed">
                      Instancie imediatamente um cliente de simulação contendo uma cadeia de 4 postos industriais complexos (SMT), variabilidade normal recalcitrante, métricas de balanceamento, Project Charter realista e planos de controle Shewhart CEP.
                    </p>
                    <div className="flex justify-end pt-2">
                      <button
                        onClick={() => {
                          const uSuffix = activeUser?.email ? `_${activeUser.email}` : "_anonymous";
                          
                          const demoCompany = {
                            id: "comp_demo_" + Math.random().toString(36).substring(2, 6),
                            name: "Deltatech Soluções Industriais S.A.",
                            cnpj: "12.345.678/0001-90", enabledModules: ["DIAGNOSTIC", "MAP", "DMAIC", "KANBAN", "BPM", "OR_HUB", "REPORT", "ENTERPRISE_STUDIO", "BI_STUDIO", "SIGMA_TREND", "E3I_INTELLIGENCE"],
                            industry: "Industrial & Manufatura",
                            createdAt: new Date().toISOString()
                          };
                          
                          const demoProject = {
                            id: "proj_demo_" + Math.random().toString(36).substring(2, 6),
                            companyId: demoCompany.id,
                            name: "Otimização de Linha SMT de Placas Eletrônicas",
                            objective: "Reduzir o lead time de montagem e calibração de placas especiais em 40% e elevar a estabilidade estatística acima de 4σ.",
                            status: "Em Andamento" as const,
                            createdAt: new Date().toISOString()
                          };

                           const email = activeUser?.email;
                           const companies = CompanyProjectRepository.getCompanies(email);
                           companies.push(demoCompany);
                           CompanyProjectRepository.saveCompanies(companies, email);

                           const projects = CompanyProjectRepository.getProjects(email);
                           projects.push(demoProject);
                           CompanyProjectRepository.saveProjects(projects, email);

                           const store = CompanyProjectRepository.getProjectDataStore(email);
                          
                          const demoSteps = [
                            {
                              id: "step_1",
                              name: "Triagem & Configuração",
                              resource: "Técnico SMT",
                              resourceCount: 2,
                              processingTime: 6,
                              standardDeviation: 1.2,
                              setupTime: 12,
                              yieldRate: 0.98
                            },
                            {
                              id: "step_2",
                              name: "Inserção de Componentes",
                              resource: "Operador de Máquina",
                              resourceCount: 1,
                              processingTime: 8,
                              standardDeviation: 1.5,
                              setupTime: 20,
                              yieldRate: 0.96
                            },
                            {
                              id: "step_3",
                              name: "Inspeção Óptica Automática (AOI)",
                              resource: "Inspetor da Qualidade",
                              resourceCount: 1,
                              processingTime: 4,
                              standardDeviation: 0.5,
                              setupTime: 5,
                              yieldRate: 0.99
                            },
                            {
                              id: "step_4",
                              name: "Embalagem & Despacho",
                              resource: "Auxiliar Logístico",
                              resourceCount: 2,
                              processingTime: 5,
                              standardDeviation: 1,
                              setupTime: 10,
                              yieldRate: 1.0
                            }
                          ];

                          const demoControlPlans = [
                            {
                              id: "cp_1",
                              stepId: "step_3",
                              metric: "Taxa de Falha AOI (DPMO)",
                              ucl: 1000,
                              lcl: 100,
                              target: 200,
                              enableAlarm: true,
                              currentReading: 150
                            }
                          ];

                          store[demoProject.id] = {
                            companyId: demoCompany.id,
                            steps: demoSteps,
                            arrivalRate: 5,
                            charter: {
                              id: "charter_demo",
                              title: "Otimização de Linha SMT de Placas Eletrônicas",
                              businessCase: "A linha de montagem SMT apresenta gargalos na máquina de inserção que atrasam toda a liberação diária.",
                              problemStatement: "Atrasos recorrentes somam tempo improdutivo de faturamento elevado e variação na qualidade.",
                              goalStatement: "Equilibrar a capacidade do posto restritivo SMT e estabilizar erros com cartas de controle.",
                              scopeIn: "Processamento e monitoramento estatístico na área produtiva de montagem.",
                              scopeOut: "Áreas satélites administrativas e comerciais.",
                              team: "Green/Black Belts Força Tarefa",
                              targetValue: 400
                            },
                            controlPlans: demoControlPlans
                          };

                          CompanyProjectRepository.saveProjectDataStore(store, email);

                          setActiveCompanyId(demoCompany.id);
                          setActiveWorkspaceProjectId(demoProject.id);
                          setProjectDataStore(store);
                        }}
                        className="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2.5 font-mono font-bold uppercase text-xs tracking-wider transition-all cursor-pointer shadow-[3px_3px_0px_0px_rgba(180,83,9,0.3)] animate-pulse"
                      >
                        ⚡ Carregar DeltaTech SMT (Um Clique)
                      </button>
                    </div>
                  </div>
                )}

                <div className="pt-4 flex justify-between border-t border-[#1A1A1A]/10 text-xs">
                  <span className="text-slate-500 self-center">Prefere a interface de árvore completa?</span>
                  <button
                    onClick={() => setCurrentWorkspaceView("CLIENT_PROJECTS")}
                    className="text-indigo-600 hover:text-indigo-800 font-mono font-bold uppercase underline tracking-wider cursor-pointer"
                  >
                    📂 Portal Geral de Empresas &amp; Projetos
                  </button>
                </div>
              </div>
            ) : (
              <div
                id="active-work-viewport"
                className={`transition-all duration-700 p-2 md:p-6 rounded-md ${
                  isWorkHighlighted
                    ? "ring-[4px] ring-[#C49746] shadow-[0_0_30px_rgba(196,151,70,0.65)] scale-[1.005] bg-white z-10"
                    : "border border-[#1A1A1A]/10 bg-transparent"
                }`}
              >
                {!isModuleAllowed(currentWorkspaceView) ? (
                  <AccessDeniedBlock
                moduleName={
                  currentWorkspaceView === "DMAIC"
                    ? "Roteiro Lean Six Sigma (DMAIC)"
                    : currentWorkspaceView === "OR_HUB"
                    ? "Pesquisa Operacional & Qualidade (OR Hub)"
                    : currentWorkspaceView === "BPM"
                    ? "Governança BPM & Procedimentos"
                    : currentWorkspaceView === "ENTERPRISE_STUDIO"
                    ? "Arquitetura & Sucesso (Enterprise Studio)"
                    : currentWorkspaceView
                }
                userRole={currentCargo}
                requiredRoles={
                  currentWorkspaceView === "OR_HUB"
                    ? ["Admin"]
                    : ["Black Belt", "Admin"]
                }
                onNavigateToAdmin={() => setCurrentWorkspaceView("ADMIN")}
              />
            ) : (!activeCompanyId && currentWorkspaceView !== "CLIENT_PROJECTS" && currentWorkspaceView !== "PUBLIC_SALES") ? (
              <EmptyState type="no_company" />
            ) : (!activeWorkspaceProjectId && currentWorkspaceView !== "CLIENT_PROJECTS" && currentWorkspaceView !== "ADMIN" && currentWorkspaceView !== "PUBLIC_SALES" && currentWorkspaceView !== "DIAGNOSTIC") ? (
              <EnterpriseOverviewDashboard
                activeUser={activeUser}
                currentCargo={currentCargo}
                companies={globalCompanies}
                projects={globalProjects}
                projectDataStore={projectDataStore}
                activeCompanyId={activeCompanyId}
                activeProjectId={activeWorkspaceProjectId}
                onSelectCompany={setActiveCompanyId}
                onSelectProject={setActiveWorkspaceProjectId}
                onNavigateToAdmin={() => setCurrentWorkspaceView("ADMIN")}
                onNavigateToProjectWorkspace={(projectId, companyId) => {
                  setActiveCompanyId(companyId);
                  setActiveWorkspaceProjectId(projectId);
                  setProcessSubView("MAPPER");
                  setCurrentWorkspaceView("PROCESSES");
                }}
              />
            ) : currentWorkspaceView === "BPM" ? (
              <div className="space-y-12 animate-fade-in text-left" id="bpm-workspace-viewport">
                
                {/* BPM SECTION HEADER */}
                <div className="border-b border-[#1A1A1A]/10 pb-6">
                  <span className="text-[10px] font-bold text-[#2563EB] bg-[#2563EB]/5 px-2.5 py-0.5 rounded-sm uppercase tracking-widest inline-block mb-1">
                    Enterprise BPM &amp; Governance Center
                  </span>
                  <h2 className="text-4xl font-serif tracking-tight text-[#1A1A1A]">Hub de Governança BPM &amp; Produção</h2>
                  <p className="text-xs text-[#1A1A1A]/70 leading-relaxed mt-2 max-w-3xl">
                    Este ecossistema consolida o gerenciamento de processos de negócio (BPM) sob preceitos científicos de Pesquisa Operacional e Six Sigma, alinhando a modelagem das atividades à conformidade operacional, correlação de variáveis estocásticas e diretrizes de deploy corporativo em escala industrial.
                  </p>
                </div>

                {/* SECTION 1: BPM LIFECYCLE PHASES */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#2563EB] uppercase tracking-widest block mb-1">Pilar 1 / Alinhamento de Metodologia</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">As 5 Fases do Ciclo de Vida do BPM</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      O ciclo BPM gerencia o ciclo contínuo de design, digitalização e controle operacional das atividades de negócio de forma cíclica e estruturada.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 pt-2">
                    {[
                      {
                        title: "1. Planejamento & Design",
                        badge: "Estratégia",
                        color: "border-blue-200 bg-blue-50/10",
                        textBg: "text-blue-800",
                        desc: "Mapeamento dos objetivos corporativos de vazão e tempos máximos estipulados no Project Charter."
                      },
                      {
                        title: "2. Modelagem (As-Is / To-Be)",
                        badge: "Visualização",
                        color: "border-indigo-200 bg-indigo-50/10",
                        textBg: "text-indigo-800",
                        desc: "Sincronização entre o Diagrama SIPOC e o mapa estocástico digital do simulador em tempo de design."
                      },
                      {
                        title: "3. Execução / Simulação",
                        badge: "Fila Estocástica",
                        color: "border-amber-200 bg-amber-50/10",
                        textBg: "text-amber-800",
                        desc: "Cálculos probabilísticos de Monte Carlo e Teoria das Filas para simular gargalos e estresse extremo antes do chão de fábrica."
                      },
                      {
                        title: "4. Monitoramento (KPIs)",
                        badge: "Shewhart CEP",
                        color: "border-emerald-200 bg-emerald-50/10",
                        textBg: "text-emerald-800",
                        desc: "Instalação de alarmes automáticos baseados no limite teórico de controle UCL/LCL para capturar variações do processo."
                      },
                      {
                        title: "5. Otimização & Governança",
                        badge: "Pesquisa Operacional",
                        color: "border-rose-200 bg-rose-50/10",
                        textBg: "text-rose-800",
                        desc: "Balanceamento constante via algoritmos matemáticos de Teoria das Restrições e reconfiguração dinâmica de recursos."
                      }
                    ].map((phase, idx) => (
                      <div key={idx} className={`border p-4 rounded-none flex flex-col justify-between ${phase.color} transition-all hover:translate-y-[-2px] duration-300`}>
                        <div>
                          <span className={`inline-block text-[8px] uppercase font-mono font-bold px-1.5 py-0.2 rounded-xs border ${phase.textBg} border-current mb-2`}>
                            {phase.badge}
                          </span>
                          <h4 className="font-bold text-xs text-[#1A1A1A] font-serif uppercase tracking-tight mb-1">{phase.title}</h4>
                          <p className="text-[10px] text-[#1A1A1A]/70 leading-relaxed">{phase.desc}</p>
                        </div>
                        <div className="text-[9px] font-mono font-bold text-[#1A1A1A]/30 mt-3 text-right">0{idx + 1}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* PILAR EXTRA: SIMULADOR DE EVENTOS DISCRETOS E GATEWAYS (FASE 10) */}
                <div id="pilar-simulacao-estocastica-avancada" className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest block mb-1">Pilar Científico / Simulação Estocástica de Alta Fidelidade (Fase 10)</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Estúdio de Simulação Estocástica &amp; Teoria das Filas</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Avalie estatisticamente o comportamento dinâmico de roteamento, gateways de bifurcação (XOR, AND, OR), taxas de refugo e restrições de filas com amostragem matemática avançada de Monte Carlo.
                    </p>
                  </div>
                  <AdvancedSimulationStudio />
                </div>

                {/* PILAR EXTRA: DESIGN DE PROCESSOS COM DRILL DOWN & SIPOC */}
                <div id="pilar-design-processos-sipoc" className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-widest block mb-1">Pilar de Co-Design &amp; Modelorização (Drill Down)</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Arquitetura de Modelos de Negócio &amp; Capa SIPOC</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Configure verticalmente o seu modelo de processos corporativos. Chaveie os níveis de SIPOC Inicial (Capa), Atividades e Tarefas Operacionais para detalhar cada etapa de ponta a ponta com as terminologias exatas de comércio, devops SaaS, finanças, saúde ou manufatura industrial tradicional.
                    </p>
                  </div>
                  <ProcessDesignRoom
                    steps={steps}
                    setSteps={setSteps}
                    activeAreaId={activeAreaId}
                    onSwitchArea={handleSwitchArea}
                    businessType={businessType}
                    onOpenStepDetail={(stepId) => setActiveDetailStepId(stepId)}
                  />
                </div>

                {/* PILAR EXTRA: BASE DE PROCESSOS INTEGRADOS & CENTRALIZADOS */}
                <div id="pilar-repositorio-processos-corporativos" className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#1D4ED8] uppercase tracking-widest block mb-1">Pilar 1.5 / Repositório Unificado &amp; Indexador</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Centro de Repositório de Processos de Negócio</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Pesquise, explore, catalogue e vincule instantaneamente fluxos operacionais setoriais de fácil localização e acesso sob governança unificada.
                    </p>
                  </div>
                  <ProcessRepositoryStudio
                    activeTemplateId={selectedTemplateId}
                    onSelectTemplate={handleSelectTemplate}
                    allTemplates={templatesList}
                    onRegisterCustomTemplate={(newTemplate) => {
                      setTemplatesList(prev => [...prev, newTemplate]);
                    }}
                  />
                </div>

                {/* SECTION 2: ACTIVE PROCESS LIST AND CHARACTERISTICS */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#2563EB] uppercase tracking-widest block mb-1">Pilar 2 / Inventário de Atividades</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Lista de Processos Ativos &amp; Características Operacionais</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Abaixo estão descritos todos os subprocessos estocásticos de ponta cadastrados em tempo real na bancada de simulação e suas respectivas capacidades de fluxo mapeadas.
                    </p>
                  </div>

                  <div className="overflow-x-auto border border-[#1A1A1A]/10 bg-white">
                    <table className="w-full text-left text-xs border-collapse divide-y divide-[#1A1A1A]/15">
                      <thead className="bg-[#FAF8F5] text-[9px] font-sans uppercase font-bold tracking-wider text-gray-500">
                        <tr>
                          <th className="p-3">Processo / Etapa</th>
                          <th className="p-3">Dono / Recurso Executor</th>
                          <th className="p-3 text-right">Tempo de Ciclo (Ts)</th>
                          <th className="p-3 text-right">Desvio Padrão (σp)</th>
                          <th className="p-3 text-right">Rendimento (FPP)</th>
                          <th className="p-3 text-right">Servidores (c)</th>
                          <th className="p-3 text-right">Capacidade de Fluxo</th>
                          <th className="p-3 text-center">Setup Residual</th>
                          <th className="p-3 text-center">Uso / Severidade</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 text-[11px] font-mono">
                        {steps.map((st, sIdx) => {
                          const cycle = st.processingTime;
                          const count = st.resourceCount || 1;
                          const capacity = (60 / cycle) * count;
                          const isBtl = st.name === stats.bottleneckStepName;
                          
                          // Determine status color based on bottleneck and yield
                          let statusBadge = "text-emerald-700 bg-emerald-50 border-emerald-200";
                          let statusLabel = "Estável / Otimizado";
                          
                          if (isBtl) {
                            statusBadge = "text-red-700 bg-red-50 border-red-200 font-bold";
                            statusLabel = "Crítico (Restrição)";
                          } else if (st.utilization && st.utilization > 80) {
                            statusBadge = "text-amber-700 bg-amber-50 border-amber-200";
                            statusLabel = "Saturado (Alerta)";
                          } else if (st.yieldRate < 0.95) {
                            statusBadge = "text-indigo-700 bg-indigo-50 border-indigo-200";
                            statusLabel = "Rendimento Fraco";
                          }

                          return (
                            <tr 
                              key={st.id} 
                              onDoubleClick={() => setActiveDetailStepId(st.id)}
                              className={`hover:bg-amber-50/25 transition-colors cursor-pointer select-none ${isBtl ? "bg-red-50/10" : ""}`}
                              title="Dê um clique duplo para detalhar a etapa e ver instruções POP"
                            >
                              <td className="p-3 font-sans font-bold text-gray-950 flex items-center gap-1.5">
                                <span className="text-[10px] text-gray-400 font-mono">0{sIdx + 1}.</span>
                                <span onClick={() => setActiveDetailStepId(st.id)} className="cursor-pointer hover:underline hover:text-[#C49746] transition-all flex items-center gap-1" title="Clique para ver especificações e automações">{st.name} <FileText size={10} className="opacity-40" /></span>
                              </td>
                              <td className="p-3 font-sans text-gray-700 italic">{st.resource}</td>
                              <td className="p-3 text-right text-gray-900 font-serif font-bold">{cycle.toFixed(1)} mins</td>
                              <td className="p-3 text-right text-gray-500">± {st.standardDeviation.toFixed(2)}m</td>
                              <td className="p-3 text-right text-emerald-600 font-bold">{(st.yieldRate * 100).toFixed(1)}%</td>
                              <td className="p-3 text-right text-gray-900 font-bold">{count}x</td>
                              <td className="p-3 text-right text-[#C49746] font-bold">{capacity.toFixed(1)} un/h</td>
                              <td className="p-3 text-center text-gray-500">{st.setupTime || 0}m de ajuste</td>
                              <td className="p-3 text-center">
                                <span className={`inline-block px-2 py-0.5 text-[8px] uppercase tracking-wider font-sans font-extrabold border ${statusBadge}`}>
                                  {statusLabel}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* PAINEL DE CONTROLE DE AUDITORIA ESTOCÁSTICA */}
                  <AuditSuggestion 
                    steps={steps} 
                    stats={stats}
                  />
                </div>

                {/* SECTION 3: PROCESS VARIABLE CORRELATION METRICS */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#2563EB] uppercase tracking-widest block mb-1">Pilar 3 / Métricas Analíticas Avançadas</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Métricas de Correlação &amp; Sensibilidade de Processo / Atividades</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Abaixo é apresentada a matriz de correlação cruzada e sensibilidade ($R$ de Pearson e correlações estocásticas lineares/não-lineares), estimando o impacto de alterações das variáveis independentes (tempos, variabilidade, setups) no resultado final de entrega do sistema.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                    {[
                      {
                        factors: "Taxa de Ocupação do Gargalo vs Lead Time",
                        nature: "Não-linear / Exponencial",
                        formula: "Fórmula de Kingman (G/G/c)",
                        tip: "À medida que a taxa de chegada satura o gargalo (U > 90%), a correlação converge a +0,99 de forma assintótica, criando colapso e aumento infinito das filas.",
                        coef: 0.94,
                        color: "border-orange-200 bg-orange-50/10 text-orange-700"
                      },
                      {
                        factors: "Variabilidade de Tempo (σ) vs Tempo de Fila",
                        nature: "Proporcional Direta (Linear)",
                        formula: "Variância Aditiva Estatística",
                        tip: "Reduzir o desvio padrão da atividade gargalo tem correlação estável de +0,87 com a queda brusca no tempo total de espera de lotes (WIP).",
                        coef: 0.87,
                        color: "border-amber-200 bg-amber-50/10 text-amber-700"
                      },
                      {
                        factors: "Rendimento Local de Qualidade vs FPP Final",
                        nature: "Composição Multiplicativa",
                        formula: "FTR = Y1 × Y2 × ... × Yn",
                        tip: "Perda infinitesimal de rendimento em qualquer bloco do fluxo tem correlação de -0,99 na taxa acumulada de qualidade final entregue.",
                        coef: -0.99,
                        color: "border-blue-200 bg-blue-50/10 text-blue-700"
                      },
                      {
                        factors: "Intervalo de Setup de Atividade vs OEE Geral",
                        nature: "Inversamente Proporcional",
                        formula: "Análise SMED Lean",
                        tip: "O aumento do tempo de setup consome tempo de produção disponível. Correlação de -0,74 com a produtividade e throughput final da célula.",
                        coef: -0.74,
                        color: "border-red-200 bg-red-50/10 text-red-700"
                      }
                    ].map((m, idx) => (
                      <div key={idx} className="bg-white border border-[#1A1A1A]/10 p-4 shrink-0 flex flex-col justify-between">
                        <div className="space-y-2">
                          <span className="text-[7.5px] uppercase tracking-wider font-mono font-bold font-sans text-gray-400 block">Correlação {idx + 1}</span>
                          <h4 className="font-serif font-bold text-xs text-gray-900 leading-tight block">{m.factors}</h4>
                          <span className="inline-block px-1.5 py-0.2 bg-gray-100 text-gray-700 text-[8px] uppercase tracking-tight font-bold font-mono">
                            {m.nature} • {m.formula}
                          </span>
                          <p className="text-[10px] text-gray-600 leading-relaxed font-sans mt-2">{m.tip}</p>
                        </div>
                        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                          <span className="text-[8px] uppercase tracking-widest font-bold text-gray-400">Coeficiente R</span>
                          <span className="font-mono text-sm font-bold bg-[#FAF8F5] border px-2 py-0.5 text-gray-800">
                            {m.coef > 0 ? "+" : ""}{m.coef.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 4: PROCESS GOVERNANCE & COLLECTION TOOLS RECOMMENDATION */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#2563EB] uppercase tracking-widest block mb-1">Pilar 4 / Caixa de Ferramentas Sugeridas</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Tecnologias de Apoio: Coleta, Organização &amp; Governança de Processos</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Para além do nosso simulador digital estocástico, conecte esses padrões líderes de mercado para elevar a maturidade do BPM e Six Sigma de sua organização:
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Pilar 1: Coleta & Process Mining */}
                    <div className="bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-[#1A1A1A]/10 pb-2">
                        <span className="p-1 bg-amber-100 text-amber-800 text-[9px] font-bold uppercase rounded-sm">Pilar I</span>
                        <h4 className="text-[11px] font-bold text-gray-900 uppercase tracking-widest">Coleta &amp; Process Mining</h4>
                      </div>
                      <p className="text-[10.5px] text-gray-700 leading-relaxed">
                        Ferramentas especializadas em mineração para extrair logs reais de ERPs (SAP, Salesforce, Oracle) de modo a reconstruir digitalmente o fluxo idêntico à realidade.
                      </p>
                      <ul className="text-[10px] space-y-2 text-gray-600 font-sans">
                        <li className="flex items-start gap-1">
                          <span className="text-amber-600 font-bold shrink-0">✔</span>
                          <div><strong>Celonis Process Intelligence</strong>: Líder absoluto em reconstrução corporativa e auditoria contínua de processos produtivos estocásticos.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-amber-600 font-bold shrink-0">✔</span>
                          <div><strong>Fluxicon Disco</strong>: Plataforma de mineração ágil para engenheiros Six Sigma que preferem processar arquivos CSV/Excel de forma local e veloz.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-amber-600 font-bold shrink-0">✔</span>
                          <div><strong>ProM Academic Core</strong>: Plataforma de pesquisa open-source repleta de algoritmos avançados de mineração de filas e descoberta de restrições.</div>
                        </li>
                      </ul>
                    </div>

                    {/* Pilar 2: Organização & Fluxos */}
                    <div className="bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-[#1A1A1A]/10 pb-2">
                        <span className="p-1 bg-blue-100 text-blue-800 text-[9px] font-bold uppercase rounded-sm">Pilar II</span>
                        <h4 className="text-[11px] font-bold text-gray-900 uppercase tracking-widest">Organização &amp; Modelagem BPMN</h4>
                      </div>
                      <p className="text-[10.5px] text-gray-700 leading-relaxed">
                        Ambientes dedicados a desenhar, padronizar e versionar o catálogo das atividades em padrão BPMN 2.0 mundialmente aceito, gerando o repositório de governança.
                      </p>
                      <ul className="text-[10px] space-y-2 text-gray-600 font-sans">
                        <li className="flex items-start gap-1">
                          <span className="text-blue-600 font-bold shrink-0">✔</span>
                          <div><strong>Bizagi Modeler</strong>: Ferramenta excepcional para modelagem de fluxos visuais em grupo de forma intuitiva, robusta e limpa.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-blue-600 font-bold shrink-0">✔</span>
                          <div><strong>SAP Signavio</strong>: Suite robusta integrada para organizar toda a arquitetura de processos corporativos com análise de valor agregado.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-blue-600 font-bold shrink-0">✔</span>
                          <div><strong>Cawemo / Camunda Modeler</strong>: Editor leve focado em desenvolvedores de software para alinhar a TI ao negócio técnico de forma unificada.</div>
                        </li>
                      </ul>
                    </div>

                    {/* Pilar 3: Governança & Execução */}
                    <div className="bg-[#FAF8F5] border border-[#1A1A1A]/10 p-5 space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-[#1A1A1A]/10 pb-2">
                        <span className="p-1 bg-emerald-100 text-emerald-800 text-[9px] font-bold uppercase rounded-sm">Pilar III</span>
                        <h4 className="text-[11px] font-bold text-gray-900 uppercase tracking-widest">Governança &amp; Execução BPMS</h4>
                      </div>
                      <p className="text-[10.5px] text-gray-700 leading-relaxed">
                        Motores de orquestração automatizada (BPMS) que gerenciam a fila de trabalho de sistemas e humanos, validando SLA, desvios na mesa e gerando auditorias à risca.
                      </p>
                      <ul className="text-[10px] space-y-2 text-gray-600 font-sans">
                        <li className="flex items-start gap-1">
                          <span className="text-emerald-600 font-bold shrink-0">✔</span>
                          <div><strong>Camunda Platform 8</strong>: Orquestrador BPMN ultra-veloz baseado em nuvem para automação completa de fluxos e monitoramento micro-serviços.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-emerald-600 font-bold shrink-0">✔</span>
                          <div><strong>Bonita BPM Soft</strong>: Suite open-source rica em extensões para integrar bancos SQL, automações e roteamento inteligente de cargos.</div>
                        </li>
                        <li className="flex items-start gap-1">
                          <span className="text-emerald-600 font-bold shrink-0">✔</span>
                          <div><strong>JIRA Enterprise Workflows</strong>: Adaptação excelente para modelar e governar o fluxo de tarefas humanas e tickets de compliance.</div>
                        </li>
                      </ul>
                    </div>

                  </div>
                </div>

                {/* SECTION 5: ENTERPRISE PRODUCTION APPLICATION DOCUMENTATION GUIDE */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#2563EB] uppercase tracking-widest block mb-1">Pilar 5 / Manual Técnico Industrial</span>
                    <h3 className="text-2xl font-serif tracking-tight text-[#1A1A1A]">Manual de Implantação e Deploy em Produção</h3>
                    <p className="text-xs text-[#1A1A1A]/70 mt-1">
                      Configure um host de alta confiabilidade corporativa para a aplicação de Engenharia de Processos Lean Six Sigma com este guia passo-a-passo.
                    </p>
                  </div>

                  {/* MINI INTERNAL NAV FOR DOCS TABS */}
                  <div className="bg-white border border-[#1A1A1A]/10 p-2.5 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setBpmDocTab("docker")}
                      className={`text-[9.5px] uppercase font-bold tracking-wider py-1.5 px-3 cursor-pointer select-none transition-all ${
                        bpmDocTab === "docker"
                          ? "bg-[#2563EB] text-white"
                          : "bg-[#1A1A1A]/5 text-[#1A1A1A] hover:bg-gray-100"
                      }`}
                    >
                      🐳 1. Dockerfile Multi-Stage
                    </button>
                    <button
                      type="button"
                      onClick={() => setBpmDocTab("gcp")}
                      className={`text-[9.5px] uppercase font-bold tracking-wider py-1.5 px-3 cursor-pointer select-none transition-all ${
                        bpmDocTab === "gcp"
                          ? "bg-[#2563EB] text-white"
                          : "bg-[#1A1A1A]/5 text-[#1A1A1A] hover:bg-gray-100"
                      }`}
                    >
                      ☁ 2. Cloud Run &amp; Kubernetes
                    </button>
                    <button
                      type="button"
                      onClick={() => setBpmDocTab("telemetry")}
                      className={`text-[9.5px] uppercase font-bold tracking-wider py-1.5 px-3 cursor-pointer select-none transition-all ${
                        bpmDocTab === "telemetry"
                          ? "bg-[#2563EB] text-white"
                          : "bg-[#1A1A1A]/5 text-[#1A1A1A] hover:bg-gray-100"
                      }`}
                    >
                      📊 3. Métricas CEP &amp; Telemetria
                    </button>
                    <button
                      type="button"
                      onClick={() => setBpmDocTab("cicd")}
                      className={`text-[9.5px] uppercase font-bold tracking-wider py-1.5 px-3 cursor-pointer select-none transition-all ${
                        bpmDocTab === "cicd"
                          ? "bg-[#2563EB] text-white"
                          : "bg-[#1A1A1A]/5 text-[#1A1A1A] hover:bg-gray-100"
                      }`}
                    >
                      🔄 4. Pipeline CI/CD GitHub Actions
                    </button>
                  </div>

                  {/* DOC VALUE CONTENT CONTAINER */}
                  <div className="bg-white border border-[#1A1A1A]/10 p-6 min-h-[350px]">
                    {bpmDocTab === "docker" && (
                      <div className="space-y-4 animate-fade-in text-left">
                        <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                          <h4 className="font-serif font-bold text-md text-gray-900 uppercase">🐳 Dockerfile de Produção Otimizado (Multi-Stage)</h4>
                          <span className="text-[9px] font-mono text-gray-400">Ambiente de Baixa Pegada de Carbono</span>
                        </div>
                        <p className="text-[11px] text-gray-600 leading-relaxed font-sans">
                          Para empacotar nosso simulador de engenharia estocástica e painel BPM de forma leve e estritamente segura para produção, salve o arquivo abaixo na raiz do projeto (como <code className="font-mono bg-gray-100 px-1 text-red-650">Dockerfile</code>) para construir uma imagem ultra compacta (menos de 150MB) baseada em Alpine Linux de múltiplos estágios.
                        </p>
                        <pre className="p-3 bg-gray-950 text-emerald-400 text-[10px] font-mono leading-relaxed overflow-x-auto text-left shadow-inner rounded-xs">
{`# ETAPA 1: Construção estática dos ativos de front-end React/Vite
FROM node:18-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# ETAPA 2: Container final enxuto para execução de produção em container seguro (Distroless / Minimal Alpine)
FROM node:18-alpine AS production
ENV NODE_ENV=production
WORKDIR /app

# Instala apenas as dependências mínimas necessárias de execução de servidor Node
COPY package*.json ./
RUN npm ci --only=production

# Copia servidor compilado e distribuições React da etapa 1
COPY --from=build /app/dist ./dist
COPY --from=build /app/server.ts /app/server.js ./ 

# Expõe a porta obrigatória 3000 do container para o proxy do Cloud Run / GKE
EXPOSE 3000
ENV PORT=3000

# Executa o aplicativo através de um sinalizador que de-referencia processos órfãos
CMD ["node", "dist/server.cjs"]`}
                        </pre>
                        <div className="bg-blue-50/50 p-2 border-l-2 border-blue-500 text-[10px] leading-relaxed text-blue-900">
                          <strong>Comando de Build Local:</strong> Execute <code className="bg-white px-1 py-0.2 border rounded-xs">docker build -t lss-bpm-suite:latest .</code> para validar a compilação local de sua imagem unificada Express + Vite.
                        </div>
                      </div>
                    )}

                    {bpmDocTab === "gcp" && (
                      <div className="space-y-4 animate-fade-in text-left">
                        <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                          <h4 className="font-serif font-bold text-md text-gray-900 uppercase">☁ GCP Cloud Run / Kubernetes (GKE) Orchestration</h4>
                          <span className="text-[9px] font-mono text-[#2563EB]">Google Cloud Certified Guide</span>
                        </div>
                        <p className="text-[11px] text-gray-600 leading-relaxed font-sans">
                          O Google Cloud {`Run`} é o ambiente mais ideal para suportar micro-serviços que operam simulações estocásticas, escalando até 100 instâncias instantaneamente para absolver múltiplos engenheiros de qualidade logados no painel.
                        </p>
                        <div className="space-y-3 pt-1">
                          <div className="space-y-1 text-left">
                            <span className="block text-[9.5px] uppercase font-mono font-bold text-gray-500">Fluxo I - Deploy de Alta Disponibilidade (Google Cloud CLI)</span>
                            <pre className="p-3 bg-gray-950 text-gray-200 text-[10px] font-mono leading-relaxed overflow-x-auto text-left">
{`# 1. Autenticar no CLI oficial do Google Cloud
gcloud auth login

# 2. Configurar o identificador do projeto corporativo ativo
gcloud config set project SEU_PROJETO_ID

# 3. Compilar a imagem utilizando o Cloud Build de maneira serverless
gcloud builds submit --tag gcr.io/SEU_PROJETO_ID/lss-bpm-suite:1.0.0

# 4. Implantar sob o Cloud Run, configurando memória de simulação robusta
gcloud run deploy lss-bpm-suite \\
  --image gcr.io/SEU_PROJETO_ID/lss-bpm-suite:1.0.0 \\
  --platform managed \\
  --region us-east1 \\
  --allow-unauthenticated \\
  --port 3000 \\
  --memory 512Mi \\
  --cpu 1 \\
  --set-env-vars GEMINI_API_KEY=sua_chave_de_servidor`}
                            </pre>
                          </div>

                          <div className="space-y-1 text-left">
                            <span className="block text-[9.5px] uppercase font-mono font-bold text-gray-500">Fluxo II - Manifesto Kubernetes (K8s Deployment / GKE)</span>
                            <pre className="p-3 bg-gray-950 text-yellow-300 text-[9.5px] font-mono leading-relaxed overflow-x-auto text-left">
{`apiVersion: apps/v1
kind: Deployment
metadata:
  name: lss-bpm-deployment
  labels:
    app: lean-six-sigma-bpm
spec:
  replicas: 3
  selector:
    matchLabels:
      app: lean-six-sigma-bpm
  template:
    metadata:
      labels:
        app: lean-six-sigma-bpm
    spec:
      containers:
      - name: bpm-app
        image: gcr.io/SEU_PROJETO_ID/lss-bpm-suite:1.0.0
        ports:
        - containerPort: 3000
        resources:
          limits:
            memory: "1Gi"
            cpu: "1.0"
          requests:
            memory: "256Mi"
            cpu: "0.2"
        env:
        - name: PORT
          value: "3000"
        - name: GEMINI_API_KEY
          valueFrom:
            secretKeyRef:
              name: gcp-gemini-secret
              key: api-key`}
                            </pre>
                          </div>
                        </div>
                      </div>
                    )}

                    {bpmDocTab === "telemetry" && (
                      <div className="space-y-4 animate-fade-in text-left">
                        <div className="flex items-center justify-between border-b pb-2 border-gray-105">
                          <h4 className="font-serif font-bold text-md text-gray-900 uppercase">📊 Telemetria de Produção (OpenTelemetry &amp; Prometheus)</h4>
                          <span className="text-[9px] font-mono text-emerald-600">SLA &amp; Observabilidade Estatística</span>
                        </div>
                        <p className="text-[11px] text-gray-600 leading-relaxed font-sans">
                          Em ambientes de manufatura automatizada e conformidade BPM, os desvios de filas, interrupções inesperadas (outliers), e alertas de Nível Sigma do Processo precisam ser exportados continuamente para dashboards centralizados no Datadog, Grafana ou GCP Cloud Monitoring.
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1 text-left">
                            <span className="block text-[9px] uppercase font-mono font-bold text-[#2563EB]">Instrumentação do Node.js (Prometheus Endpoint)</span>
                            <pre className="p-3 bg-gray-950 text-emerald-300 text-[9px] font-mono leading-tight overflow-x-auto text-left rounded-xs">
{`// server.ts - Expondo métricas CEP para o Prometheus
import express from "express";
import client from "prom-client"; // npm i prom-client

const app = express();
const register = new client.Registry();

// Habilita as métricas default do sistema corporativo
client.collectDefaultMetrics({ register });

// Define métrica customizada para analisar tempos de fila estocástica
const queueDelayGauge = new client.Gauge({
  name: "process_queue_delay_minutes",
  help: "Atraso médio estimado na fila G/G/c em minutos por etapa",
  labelNames: ["step_name", "resource"]
});
register.registerMetric(queueDelayGauge);

// Rota de monitoramento que o Prometheus consome a cada 10 segundos
app.get("/api/metrics", async (req, res) => {
  res.setHeader("Content-Type", register.contentType);
  res.send(await register.metrics());
});`}
                            </pre>
                          </div>

                          <div className="space-y-2 text-left">
                            <span className="block text-[9px] uppercase font-mono font-bold text-gray-500">Métricas Críticas Monitoradas (SLA &amp; CEP)</span>
                            <div className="border border-gray-100 p-3 rounded-xs space-y-2 bg-gray-50 text-[10px] text-gray-700">
                              <div>
                                <span className="font-bold text-red-700">1. Rate saturado (Throughput Limit):</span>
                                <p className="text-gray-600 mt-0.5">Dispare alertas de página urgente caso a taxa de chegada (<code className="font-mono bg-white px-0.5 text-xs text-red-650">arrivalRate</code>) iguale ou supere em 98% a capacidade do gargalo físico sistêmico.</p>
                              </div>
                              <div className="border-t pt-2">
                                <span className="font-bold text-emerald-800">2. Alarme de Shewhart (Regras de Western Electric):</span>
                                <p className="text-gray-600 mt-0.5">Colete amostras agregadas de processamento (<code className="font-mono bg-white px-0.5 text-xs text-red-650">currentReading</code>) e notifique a equipe de controle se o desvio médio ultrapassar a raia de {alarmSigmaSensitivity.toFixed(1)}σ.</p>
                              </div>
                              <div className="border-t pt-2">
                                <span className="font-bold text-indigo-800">3. Rastreabilidade de Amostras por Lote:</span>
                                <p className="text-gray-600 mt-0.5">Monitore desvios na variabilidade real calculada dividindo tempos de ciclo históricos observados na simulação pelo limite nominal esperado no Project Charter.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {bpmDocTab === "cicd" && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between border-b pb-2 border-gray-100">
                          <h4 className="font-serif font-bold text-md text-gray-900 uppercase">🔄 Pipeline CI/CD com GitHub Actions</h4>
                          <span className="text-[9px] font-mono text-gray-400">Entrega Contínua e Segura do Aplicativo</span>
                        </div>
                        <p className="text-[11px] text-gray-600 leading-relaxed font-sans">
                          Para automatizar os testes, certificar o linting corporativo do TypeScript e compilar a imagem de produção no Docker Container Registry a cada commit aceito na branch principal (como <code className="font-mono bg-gray-100 px-1 text-red-650">master</code> ou <code className="font-mono bg-[#E2E8F0] px-1 text-red-650">main</code>), salve o seguinte manifesto YAML em <code className="font-mono bg-gray-100 px-1 text-red-650">.github/workflows/deploy.yml</code>.
                        </p>
                        <pre className="p-3 bg-gray-950 text-[#60A5FA] text-[10px] font-mono leading-relaxed overflow-x-auto text-left shadow-inner rounded-xs">
{`name: Pipeline Lean Six Sigma & BPM CI/CD

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main" ]

jobs:
  test-and-lint:
    name: Validação de Qualidade de Código
    runs-on: ubuntu-latest
    steps:
    - name: Checkout do Código Fonte
      uses: actions/checkout@v3

    - name: Configurar Node.js Runtime 18
      uses: actions/setup-node@v3
      with:
        node-version: 18
        cache: 'npm'

    - name: Instalar Dependências Gerais (Dev)
      run: npm ci

    - name: Executar Auditoria de Validação (Linter TypeScript)
      run: npm run lint

    - name: Executar Build de Teste da Aplicação React/Vite
      run: npm run build

  build-and-push-gcp:
    name: Build Docker & GCP Container Registry
    needs: test-and-lint
    runs-on: ubuntu-latest
    if: github.event_name == 'push'
    steps:
    - name: Checkout do Código Fonte
      uses: actions/checkout@v3

    - name: Autenticar no GCP Service Account
      uses: 'google-github-actions/auth@v1'
      with:
        credentials_json: '\${{ secrets.GCP_SA_KEY }}'

    - name: Configurar GCP CLI Utilities
      uses: 'google-github-actions/setup-gcloud@v1'

    - name: Configurar Docker Helper para GCP
      run: gcloud auth configure-docker

    - name: Compilar imagem de contêiner & Enviar para GCR
      run: |
        docker build -t gcr.io/\${{ secrets.GCP_PROJECT_ID }}/lss-bpm-suite:\${{ github.sha }} .
        docker tag gcr.io/\${{ secrets.GCP_PROJECT_ID }}/lss-bpm-suite:\${{ github.sha }} gcr.io/\${{ secrets.GCP_PROJECT_ID }}/lss-bpm-suite:latest
        docker push gcr.io/\${{ secrets.GCP_PROJECT_ID }}/lss-bpm-suite:\--all-tags`}
                        </pre>
                        <div className="bg-blue-50/50 p-2.5 border-l-2 border-blue-500 text-[10px] leading-relaxed text-blue-900">
                          <strong>Vantagem Organizacional:</strong> Garante que nenhum engenheiro quebre os cálculos do simulador estocástico com variáveis indefinidas, impedindo deploys falhos e assegurando alta estrita de governança nos processos de negócio.
                        </div>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            ) : currentWorkspaceView === "ORGANIZATION" ? (
              <OrganizationStructurePage
                mode={usabilityMode}
                onNavigateToStep={(stepId) => {
                  if (stepId === "processos") {
                    setCurrentWorkspaceView("MAP");
                    setActivePhase("MEASURE");
                  } else if (stepId === "governanca") {
                    setCurrentWorkspaceView("GOVERNANCE");
                  } else {
                    setCurrentWorkspaceView("DMAIC");
                  }
                }}
              />
            ) : currentWorkspaceView === "STRATEGY" ? (
              <StrategyPage
                mode={usabilityMode}
                onNavigateToStep={(stepId) => {
                  if (stepId === "processos") {
                    setCurrentWorkspaceView("MAP");
                    setActivePhase("MEASURE");
                  } else if (stepId === "governanca") {
                    setCurrentWorkspaceView("GOVERNANCE");
                  } else {
                    setCurrentWorkspaceView("DMAIC");
                  }
                }}
              />
            ) : currentWorkspaceView === "GOVERNANCE" ? (
              <GovernancePage
                mode={usabilityMode}
                openTemplatesHub={() => setIsTemplatesHubOpen(true)}
              />
            ) : currentWorkspaceView === "CHANGE_MANAGEMENT" ? (
              <ChangeManagementPage
                mode={usabilityMode}
              />
            ) : currentWorkspaceView === "REORGANIZATION" ? (
              <BusinessReorganizationPlan
                mode={usabilityMode}
              />
            ) : currentWorkspaceView === "REORGANIZATION_DASHBOARD" ? (
              <div className="space-y-6">
                {/* Segmented Control for Resultados views */}
                <div className="bg-slate-100 p-1 rounded-xl flex items-center max-w-lg shadow-xs border border-slate-200 font-sans">
                  <button
                    onClick={() => setResultadosSubView("DASHBOARD")}
                    className={`flex-1 text-center py-2 px-3 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
                      resultadosSubView === "DASHBOARD"
                        ? "bg-slate-900 text-[#C49746] shadow-xs"
                        : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
                    }`}
                  >
                    📊 {usabilityMode === "EXPERT" ? "ROI e Indicadores" : "Resultados (Dashboard)"}
                  </button>
                  <button
                    onClick={() => setResultadosSubView("REPORT")}
                    className={`flex-1 text-center py-2 px-3 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
                      resultadosSubView === "REPORT"
                        ? "bg-slate-900 text-[#C49746] shadow-xs"
                        : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
                    }`}
                  >
                    📄 {usabilityMode === "EXPERT" ? "Relatório de Estruturação" : "Relatório Executivo"}
                  </button>
                </div>

                {resultadosSubView === "DASHBOARD" ? (
                  <EnterpriseExecutiveDashboard mode={usabilityMode} />
                ) : (
                  <EnterpriseExecutiveReport mode={usabilityMode} />
                )}
              </div>
            ) : currentWorkspaceView === "REORGANIZATION_REPORT" ? (
              <EnterpriseExecutiveReport
                mode={usabilityMode}
              />
            ) : currentWorkspaceView === "E3I_INTELLIGENCE" ? (
              <ProcessOptimizationWizardPage />
            ) : currentWorkspaceView === "DMAIC" ? (
              <DmaicWizard
                selectedStep={selectedDmaicStep || steps[0]}
                steps={steps}
                setSteps={setSteps}
                arrivalRate={arrivalRate}
                activePhase={activePhase}
                setActivePhase={setActivePhase}
              />
            ) : currentWorkspaceView === "DASHBOARD_LEIGO" ? (
              <DashboardLeigo
                stats={stats}
                steps={steps}
                setSteps={setSteps}
                activeUser={activeUser}
                businessType={businessType}
                unitLabelPlural={unitLabelPlural}
                arrivalRate={arrivalRate}
                setArrivalRate={setArrivalRate}
                onNavigateToView={(view) => setCurrentWorkspaceView(view as any)}
                globalCompanies={globalCompanies}
                activeCompanyId={activeCompanyId}
                setActiveCompanyId={setActiveCompanyId}
                globalProjects={globalProjects}
                activeWorkspaceProjectId={activeWorkspaceProjectId}
                setActiveWorkspaceProjectId={setActiveWorkspaceProjectId}
                charter={charter}
                setCharter={setCharter}
                onOpenOnboarding={() => setIsOnboardingOpen(true)}
              />
            ) : currentWorkspaceView === "CLIENT_PROJECTS" ? (
              <CompanyProjectsModule
                activeUser={activeUser}
                currentCargo={currentCargo}
                activeCompanyId={activeCompanyId}
                setActiveCompanyId={setActiveCompanyId}
                activeProjectId={activeWorkspaceProjectId}
                setActiveProjectId={setActiveWorkspaceProjectId}
                onNavigateToMap={() => setCurrentWorkspaceView("MAP")}
              />
            ) : currentWorkspaceView === "OR_HUB" ? (
              <OrQualityHub
                steps={steps}
                setSteps={setSteps}
                stats={stats}
                arrivalRate={arrivalRate}
              />
            ) : currentWorkspaceView === "REPORT" ? (
              <ReportPresentationGenerator
                steps={steps}
                stats={stats}
                charter={charter}
                sipoc={sipoc}
                controlPlans={controlPlans}
                arrivalRate={arrivalRate}
              />
            ) : currentWorkspaceView === "ADMIN" ? (
              <PermissionGuard
                user={authenticatedUser}
                permission="admin:view"
                fallback={adminFallback}
              >
                <AdminPanel
                  enabledViews={enabledViews}
                  setEnabledViews={setEnabledViews}
                  companies={globalCompanies}
                  setCompanies={setGlobalCompanies}
                  projects={globalProjects}
                  setProjects={setGlobalProjects}
                  charter={charter}
                  setCharter={setCharter}
                  sipoc={sipoc}
                  setSipoc={setSipoc}
                  controlPlans={controlPlans}
                  setControlPlans={setControlPlans}
                  activeWorkspaceProjectId={activeWorkspaceProjectId}
                  activeCompanyId={activeCompanyId}
                  arrivalRate={arrivalRate}
                  setArrivalRate={setArrivalRate}
                  steps={steps}
                  setSteps={setSteps}
                  currentWorkspaceView={currentWorkspaceView}
                  setCurrentWorkspaceView={setCurrentWorkspaceView}
                  currentCargo={currentCargo}
                  setCurrentCargo={setCurrentCargo}
                  rolePermissions={rolePermissions}
                  setRolePermissions={setRolePermissions}
                  onTriggerSharePortal={() => setSharePortalModalOpen(true)}
                  usabilityMode={usabilityMode}
                  setUsabilityMode={setUsabilityMode}
                  usabilityLocked={usabilityLocked}
                  setUsabilityLocked={setUsabilityLocked}
                  onOpenOnboarding={() => setIsOnboardingOpen(true)}
                  onOpenGallery={() => setIsTemplateGalleryOpen(true)}
                  scheduledAudits={scheduledAudits}
                  setScheduledAudits={setScheduledAudits}
                />
              </PermissionGuard>
            ) : currentWorkspaceView === "ENTERPRISE_STUDIO" ? (
              <div className="space-y-10 animate-fade-in text-left">
                <EnterpriseArchitectureSuite
                  steps={steps}
                  stats={stats}
                  activeTemplateId={selectedTemplateId}
                  onNavigateToProcess={(areaId) => {
                    handleSwitchArea(areaId);
                    setCurrentWorkspaceView("MAP");
                    setActivePhase("DEFINE"); // Mapper lives inside DEFINE phase
                  }}
                  onNavigateToView={(view) => {
                    setCurrentWorkspaceView(view);
                  }}
                  onNavigateToDmaicPhase={(phase) => {
                    setActivePhase(phase);
                    setCurrentWorkspaceView("DMAIC");
                  }}
                  arrivalRate={arrivalRate}
                  charter={charter}
                />
                
                <MethodologyContractor 
                  currentCargo={currentCargo}
                  activeCompanyId={activeCompanyId}
                  globalCompanies={globalCompanies}
                  setGlobalCompanies={setGlobalCompanies}
                />
              </div>
            ) : currentWorkspaceView === "KANBAN" ? (
              <WipKanbanBoard
                steps={steps}
                stats={stats}
                arrivalRate={arrivalRate}
                defaultFilterStepId={selectedFocusStepId}
                activeAreaId={activeAreaId}
                onSwitchArea={handleSwitchArea}
                processesByArea={processesByArea}
                activeCompanyId={activeCompanyId}
                activeWorkspaceProjectId={activeWorkspaceProjectId}
                globalCompanies={globalCompanies}
                globalProjects={globalProjects}
              />
            ) : currentWorkspaceView === "BI_STUDIO" ? (
              <BiStudio
                steps={steps}
                stats={stats}
                arrivalRate={arrivalRate}
                onNavigateHome={() => setCurrentWorkspaceView("DIAGNOSTIC")}
                onOpenStepDetails={(stepId) => setActiveDetailStepId(stepId)}
              />
            ) : currentWorkspaceView === "SIGMA_TREND" ? (
              <SigmaTrendDashboard
                stats={stats}
                onNavigateHome={() => setCurrentWorkspaceView("DIAGNOSTIC")}
              />
            ) : currentWorkspaceView === "ROI_DASHBOARD" ? (
              <RoiDashboard
                steps={steps}
                stats={stats}
                arrivalRate={arrivalRate}
                projectDetails={projectDetails}
                setProjectDetails={setProjectDetails}
                activeUser={activeUser}
              />
            ) : currentWorkspaceView === "SUBSCRIPTION_MANAGEMENT" ? (
              <SubscriptionModules />
            ) : currentWorkspaceView === "PUBLIC_SALES" ? (
              <PublicSalesLanding 
                onStartTrial={() => setCurrentWorkspaceView("DIAGNOSTIC")} 
                globalCompanies={globalCompanies}
                setGlobalCompanies={setGlobalCompanies}
                globalProjects={globalProjects}
                setProjects={setGlobalProjects}
                currentCargo={currentCargo}
                setCurrentCargo={setCurrentCargo}
                setCurrentWorkspaceView={setCurrentWorkspaceView}
                activeUser={activeUser}
                onLoginSuccess={(simulatedUser, permittedViews) => {
                  setActiveUser(simulatedUser);
                  if (permittedViews) {
                    setEnabledViews(permittedViews);
                  } else {
                    setEnabledViews(["DIAGNOSTIC", "MAP", "KANBAN", "REPORT"]);
                  }
                  setActiveCompanyId(simulatedUser.companyId || "comp-itau");
                  setCurrentCargo(simulatedUser.role || "Analista Júnior");
                  
                  if (simulatedUser.role === "Admin") {
                    setCurrentWorkspaceView("ADMIN");
                  } else {
                    const firstView = permittedViews && permittedViews[0];
                    setCurrentWorkspaceView(firstView || "DIAGNOSTIC");
                  }
                  setActiveWorkspaceProjectId("proj-auto-01");
                }}
              />
            ) : currentWorkspaceView === "DIAGNOSTIC" ? (
              <DiagnosticWizard
                steps={steps}
                setSteps={setSteps}
                charter={charter}
                setCharter={setCharter}
                sipoc={sipoc}
                setSipoc={setSipoc}
                setView={setCurrentWorkspaceView}
                businessType={businessType}
                openTemplatesHub={() => setIsTemplatesHubOpen(true)}
                activeProjectName={globalProjects.find(p => p.id === activeWorkspaceProjectId)?.name || projectDetails.processName}
                activeProjectObjective={globalProjects.find(p => p.id === activeWorkspaceProjectId)?.objective || projectDetails.expectedImpact}
                projectDetails={projectDetails}
                setProjectDetails={setProjectDetails}
                setBusinessType={handleSelectBusinessType}
              />
            ) : currentWorkspaceView === "MAP" ? (
              <div className="space-y-12 animate-fade-in" id="map-workspace-viewport">
                {/* Visual Mapeador de Processos */}
                <div className="space-y-4">
                  <div className="border-t border-[#1A1A1A] pt-4">
                    <span className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest block mb-1">Mapeamento de Postos de Trabalho &amp; Cadeia de Valor</span>
                    <h2 className="text-3xl font-serif tracking-tight text-[#1A1A1A]">Mapeador Visual de Layout Estocástico</h2>
                    <p className="text-xs text-[#1A1A1A]/70 leading-relaxed mt-1">
                      Desenhe seu fluxograma de fabricação, documente etapas operacionais, estabeleça encadeamentos lógicos de decisão e adicione descrições/responsáveis diretamente. O simulador e cálculo estocástico se atualizam de forma instantânea.
                    </p>
                  </div>
                  <VisualProcessMapper
                    steps={steps}
                    setSteps={setSteps}
                    bottleneckStepName={stats.bottleneckStepName}
                    onOpenDetails={(stepId) => setActiveDetailStepId(stepId)}
                    activeAreaId={activeAreaId}
                    onSwitchArea={handleSwitchArea}
                    usabilityMode={usabilityMode}
                    businessType={businessType}
                    openTemplatesHub={() => setIsTemplatesHubOpen(true)}
                  />
                </div>
              </div>
            ) : (
              <>
                {/* ==================== 1. DEFINE PHASE ==================== */}
                {activePhase === "DEFINE" && (
                  <div className="space-y-12 animate-fade-in" id="define-phase-viewport">
                    
                    {/* Visual Mapeador de Processos */}
                    <div className="space-y-4">
                      <div className="border-t border-[#1A1A1A] pt-4">
                        <span className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest block mb-1">Passo 0 / Mapeamento de Layout</span>
                        <h2 className="text-3xl font-serif tracking-tight text-[#1A1A1A]">Mapeador Visual de Processos</h2>
                        <p className="text-xs text-[#1A1A1A]/70 leading-relaxed mt-1">
                          Desenhe seu fluxograma de fabricação, documente etapas operacionais, estabeleça encadeamentos lógicos de decisão e adicione descrições/responsáveis diretamente. O simulador e cálculo estocástico se atualizam de forma instantânea.
                        </p>
                      </div>
                      <VisualProcessMapper
                        steps={steps}
                        setSteps={setSteps}
                        bottleneckStepName={stats.bottleneckStepName}
                        onOpenDetails={(stepId) => setActiveDetailStepId(stepId)}
                        activeAreaId={activeAreaId}
                        onSwitchArea={handleSwitchArea}
                        usabilityMode={usabilityMode}
                        businessType={businessType}
                        openTemplatesHub={() => setIsTemplatesHubOpen(true)}
                      />
                    </div>
                
                {/* Visual Intro row */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  <div className="lg:col-span-8 space-y-6">
                    <div className="border-t border-[#1A1A1A] pt-4">
                      <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest mb-1">01 / Fase DEFINE</p>
                      <h2 className="text-3xl font-serif tracking-tight pr-4">Termo de Abertura do Projeto (Project Charter)</h2>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#F5F2ED] p-6 rounded-sm border-l-4 border-[#C49746]">
                      <div className="space-y-4">
                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Título do Estudo</label>
                          <input
                            type="text"
                            value={charter.title}
                            onChange={(e) => setCharter({ ...charter, title: e.target.value })}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2.5 py-1.5 focus:border-[#C49746] focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Métrica de Sucesso Prioritária</label>
                          <select
                            value={charter.metric}
                            onChange={(e: any) => setCharter({ ...charter, metric: e.target.value })}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2.5 py-1.5 focus:border-[#C49746] focus:outline-none"
                          >
                            <option value="cycle_time">Lead Time de Processo (Tempo total, minutos)</option>
                            <option value="throughput">Vazão Máxima Estabilizada (Unidades por hora)</option>
                            <option value="defect_rate">Minimização de Defeitos (Elevação de Yield)</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Valor Alvo (Target)</label>
                          <input
                            type="number"
                            value={charter.targetValue}
                            onChange={(e) => setCharter({ ...charter, targetValue: Number(e.target.value) })}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2.5 py-1.5 focus:border-[#C49746] focus:outline-none font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Meta Organizacional</label>
                          <input
                            type="text"
                            value={charter.goal}
                            onChange={(e) => setCharter({ ...charter, goal: e.target.value })}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2.5 py-1.5 focus:border-[#C49746] focus:outline-none"
                          />
                        </div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <label className="block text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Declaração Científica do Problema</label>
                        <textarea
                          rows={3}
                          value={charter.problemStatement}
                          onChange={(e) => setCharter({ ...charter, problemStatement: e.target.value })}
                          className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2.5 py-1.5 focus:border-[#C49746] focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Operational research sidebar note */}
                  <div className="lg:col-span-4 border border-[#1A1A1A]/15 p-6 bg-white shrink-0 space-y-4">
                    <h4 className="text-[11px] font-bold uppercase tracking-widest">O Clássico Conceito DMAIC</h4>
                    <p className="text-[11px] leading-relaxed text-[#1A1A1A]/80">
                      O <strong>Define</strong> estabelece acordos entre os engenheiros, pesquisadores e gestores. Aqui delimitamos o que o algoritmo de Machine Learning buscará otimizar: minimização do gargalo, máxima eficiência ou controle estrito de variabilidade.
                    </p>
                    <div className="p-3 bg-[#F5F2ED] text-[10px] italic border-l-2 border-[#1A1A1A]">
                      "Se você não puder descrever o que está fazendo como um processo, você não sabe o que está fazendo." <br/>
                      <span className="font-sans font-bold not-italic block text-right mt-1">— W. Edwards Deming</span>
                    </div>
                  </div>
                </div>

                {/* VISUAL DIAGRAM: SIPOC MODEL (Supplier, Input, Process, Output, Customer) */}
                <div className="border-t border-[#1A1A1A] pt-8">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-widest">Diagrama de Transparência de Processo: SIPOC</h3>
                      <p className="text-[11px] text-[#1A1A1A]/60">Fluxo estendido de valor para governança organizacional e engenharia.</p>
                    </div>
                    <span className="text-[10px] font-serif italic text-[#C49746]">Mapeamento Six Sigma</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    
                    <div className="border border-[#1A1A1A]/15 p-4 bg-white hover:border-[#C49746] transition-all">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-[#C49746] mb-2 border-b border-[#1A1A1A]/10 pb-1">S _ Suppliers</div>
                      <textarea
                        rows={5}
                        value={sipoc.suppliers}
                        onChange={(e) => setSipoc({ ...sipoc, suppliers: e.target.value })}
                        className="w-full bg-transparent text-[11px] leading-relaxed focus:outline-none resize-none"
                        placeholder="Para cada insumo, quem fornece?"
                      />
                    </div>

                    <div className="border border-[#1A1A1A]/15 p-4 bg-white hover:border-[#C49746] transition-all">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-[#C49746] mb-2 border-b border-[#1A1A1A]/10 pb-1">I _ Inputs</div>
                      <textarea
                        rows={5}
                        value={sipoc.inputs}
                        onChange={(e) => setSipoc({ ...sipoc, inputs: e.target.value })}
                        className="w-full bg-transparent text-[11px] leading-relaxed focus:outline-none resize-none"
                        placeholder="Quais materiais e informações iniciam?"
                      />
                    </div>

                    <div className="border border-[#1A1A1A]/15 p-4 bg-[#F5F2ED] border-dashed hover:border-[#C49746] transition-all flex flex-col justify-between">
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-[#1A1A1A] mb-2 border-b border-[#1A1A1A]/10 pb-1 flex justify-between items-center">
                          <span>P _ Process</span>
                          <span className="text-[7.5px] font-sans font-bold bg-[#C49746]/10 text-[#C49746] px-1 py-0.2 rounded-xs">Sincronizável</span>
                        </div>
                        <textarea
                          rows={4}
                          value={sipoc.processDescription}
                          onChange={(e) => setSipoc({ ...sipoc, processDescription: e.target.value })}
                          className="w-full bg-transparent text-[11px] leading-relaxed font-serif italic focus:outline-none resize-none"
                          placeholder="Quais as etapas macro de transformação?"
                        />
                      </div>

                      <div className="mt-3 pt-2 border-t border-[#1A1A1A]/10 flex flex-col gap-1.5">
                        <button
                          type="button"
                          onClick={handleSyncMapToSipoc}
                          className="w-full bg-[#1A1A1A]/5 hover:bg-[#1A1A1A]/10 text-[#1A1A1A] text-[9px] uppercase font-bold tracking-widest py-1 px-1.5 transition-all text-center flex items-center justify-center gap-1 cursor-pointer"
                          title="Sincroniza do Mapa para o SIPOC"
                        >
                          <RefreshCw size={9} /> Sincronizar do Mapa
                        </button>
                        <button
                          type="button"
                          onClick={handleApplySipocToMap}
                          className="w-full bg-[#C49746]/10 hover:bg-[#C49746]/20 text-[#C49746] text-[9px] uppercase font-bold tracking-widest py-1 px-1.5 transition-all text-center flex items-center justify-center gap-1 cursor-pointer"
                          title="Atualiza o mapa de processo estocástico com as etapas escritas acima (separadas por ->)"
                        >
                          <ArrowRight size={9} /> Refletir no Mapa
                        </button>
                      </div>
                    </div>

                    <div className="border border-[#1A1A1A]/15 p-4 bg-white hover:border-[#C49746] transition-all">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-[#C49746] mb-2 border-b border-[#1A1A1A]/10 pb-1">O _ Outputs</div>
                      <textarea
                        rows={5}
                        value={sipoc.outputs}
                        onChange={(e) => setSipoc({ ...sipoc, outputs: e.target.value })}
                        className="w-full bg-transparent text-[11px] leading-relaxed focus:outline-none resize-none"
                        placeholder="Insumo transformado gerando valor?"
                      />
                    </div>

                    <div className="border border-[#1A1A1A]/15 p-4 bg-white hover:border-[#C49746] transition-all">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-[#C49746] mb-2 border-b border-[#1A1A1A]/10 pb-1">C _ Customers</div>
                      <textarea
                        rows={5}
                        value={sipoc.customers}
                        onChange={(e) => setSipoc({ ...sipoc, customers: e.target.value })}
                        className="w-full bg-transparent text-[11px] leading-relaxed focus:outline-none resize-none"
                        placeholder="Quem consome o resultado final?"
                      />
                    </div>

                  </div>
                </div>

                {/* Progression button */}
                <div className="flex justify-end pt-4 border-t border-[#1A1A1A]/10">
                  <button
                    onClick={handleNextPhase}
                    className="bg-[#1A1A1A] text-white py-3 px-6 text-xs uppercase tracking-widest font-bold hover:opacity-90 flex items-center gap-2 transition"
                  >
                    Prosseguir para Medição (MEASURE) <ChevronRight size={14} />
                  </button>
                </div>

              </div>
            )}

            {/* ==================== 2. MEASURE PHASE ==================== */}
            {activePhase === "MEASURE" && (
              <div className="space-y-12 animate-fade-in" id="measure-phase-viewport">
                
                {/* Introduction / Data collector board */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Parameter Panel: Operational Data Collection & Customization */}
                  <div className="lg:col-span-8 space-y-6">
                    <div className="border-t border-[#1A1A1A] pt-4 flex justify-between items-center">
                      <div>
                        <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest mb-1">02 / Fase MEASURE</p>
                        <h2 className="text-3xl font-serif tracking-tight text-[#1A1A1A]">Arquitetura e Coleta Estatística do Processo</h2>
                      </div>
                      
                      <button
                        onClick={handleRunSimulation}
                        disabled={isSimulating}
                        className="bg-[#1A1A1A] hover:bg-black text-white text-[10px] uppercase tracking-widest font-bold px-4 py-2 flex items-center gap-1"
                      >
                        <RefreshCw size={11} className={isSimulating ? "animate-spin" : ""} />
                        Forçar Simulação Estocástica
                      </button>
                    </div>

                    <p className="text-xs text-[#1A1A1A]/75 leading-relaxed">
                      Insira tempos reais, operadores integrados, taxas de defeitos e variabilidade para alimentar nossa simulação de Monte Carlo. Ao alterar os parâmetros, o modelo de filas recalcula instantaneamente.
                    </p>

                    {/* ASSISTENTE DE COLETA COM IA & PESQUISA OPERACIONAL */}
                    <div className="bg-[#FAF8F5] border border-[#1A1A1A] p-5 my-4 space-y-4">
                      <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="bg-[#C49746]/10 text-[#C49746] text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-sm">
                            IA + Pesquisa Operacional
                          </span>
                          <h4 className="text-[11px] font-bold uppercase tracking-wider text-gray-900">
                            Assistência de IA na Coleta de Informações do Processo
                          </h4>
                        </div>
                        <span className="text-[10px] font-mono text-[#1A1A1A]/40 flex items-center gap-1">
                          PO Solver Online
                        </span>
                      </div>

                      <p className="text-[11.5px] text-[#1A1A1A]/80 leading-relaxed text-left">
                        Apoie-se na IA e nos modelos de Pesquisa Operacional para desenhar seu plano de coleta. Escreva seu ramo ou setor para gerar automaticamente as etapas do processo, as variáveis estatísticas de capabilidade e estimar os parâmetros do SIPOC.
                      </p>

                      <form onSubmit={handleSuggestStructure} className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={sectorInput}
                          onChange={(e) => setSectorInput(e.target.value)}
                          placeholder="Ex: Laboratório Clínico de Coletas, Linha de Montagem de Placas, Triagem de UTI"
                          className="flex-grow bg-white border border-[#1A1A1A]/20 px-3 py-2 text-xs focus:outline-none focus:border-[#C49746] font-sans"
                        />
                        <button
                          type="submit"
                          disabled={isSuggesting}
                          className="bg-[#C49746] hover:bg-[#92400E] text-white text-[10px] uppercase tracking-widest font-bold px-4 py-2 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
                        >
                          <Sparkles size={12} className={isSuggesting ? "animate-spin" : ""} />
                          {isSuggesting ? "Estruturando..." : "Estruturar com IA & PO"}
                        </button>
                      </form>

                      {suggestError && (
                        <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-[10px] uppercase font-bold text-left">
                          {suggestError}
                        </div>
                      )}

                      {isSuggesting && (
                        <div className="p-3 bg-white border border-[#1A1A1A]/10 space-y-2 text-[10px] font-mono text-[#1A1A1A]/60 animate-pulse text-left">
                          <div className="flex items-center gap-2">
                            <span className="animate-spin text-[#C49746]">⌛</span>
                            <span>Executando algoritmos industriais...</span>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[8px] text-gray-500">
                            <div>• Solucionando Teoria de Filas...</div>
                            <div>• Mapeando Colunas SIPOC...</div>
                            <div>• Gerando Variabilidade Teórica...</div>
                          </div>
                        </div>
                      )}

                      {orInsight && !isSuggesting && (
                        <div className="bg-white border border-[#1A1A1A]/10 p-4 space-y-3">
                          <h5 className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest border-b border-gray-100 pb-1 text-left">
                            Análise Estrutural e Sugestões de Pesquisa Operacional (PO):
                          </h5>
                          
                          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
                            <div className="md:col-span-4 space-y-1 text-left">
                              <span className="block text-[8px] uppercase tracking-wider text-gray-400 font-bold text-left">Modelo Científico Utilizado</span>
                              <div className="font-mono text-[10.5px] font-bold text-[#1A1A1A]/90 bg-gray-50 p-1.5 border border-gray-200/50 text-left">
                                {orInsight.orModel}
                              </div>
                            </div>
                            
                            <div className="md:col-span-8 space-y-1 text-left">
                              <span className="block text-[8px] uppercase tracking-wider text-gray-400 font-bold text-left">Gargalo / Oportunidade Sob PO</span>
                              <p className="text-[10px] text-gray-700 leading-normal text-left">
                                {orInsight.problemStatement}
                              </p>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[10.5px] pt-2 border-t border-dashed border-gray-100 text-left">
                            <div className="space-y-1 text-left">
                              <span className="block text-[8px] uppercase tracking-wider text-[#C49746] font-bold text-left">Diretriz da Otimização de Filas (PO)</span>
                              <div className="text-gray-800 leading-normal bg-[#FAF8F5] p-2 border-l border-[#C49746] text-left">
                                {orInsight.orSuggestions}
                              </div>
                            </div>
                            
                            <div className="space-y-1 text-left">
                              <span className="block text-[8px] uppercase tracking-wider text-emerald-700 font-bold text-left">Configuração Ótima Recomendada</span>
                              <div className="text-gray-800 leading-normal bg-emerald-50/50 p-2 border-l border-emerald-600 text-left">
                                {orInsight.recommendedConfiguration}
                              </div>
                            </div>
                          </div>

                          <div className="bg-indigo-50/50 border border-indigo-100 p-2 rounded-xs text-[10px] flex items-start gap-2 text-left">
                            <span className="text-indigo-600 font-bold text-left font-sans shrink-0 uppercase tracking-wide">💡 Dica Lean + PO:</span>
                            <span className="text-indigo-950 font-sans leading-relaxed text-left">
                              {orInsight.operationalTip}
                            </span>
                          </div>

                          <div className="text-[8px] uppercase text-[#1A1A1A]/40 text-center font-mono pt-1">
                            Valores estatísticos e macro SIPOC atualizados com sucesso e refletidos no topo do painel principal.
                          </div>
                        </div>
                      )}
                    </div>

                    {/* PROCESS STEPS REAL-TIME ADJUSTMENT GRID */}
                    {selectedFocusStepId !== "ALL" && (
                      <div className="bg-amber-50/40 border-l-4 border-[#C49746] p-3 mb-2 flex items-center justify-between text-xs font-sans">
                        <span className="text-[#1A1A1A] font-medium">
                          🎯 Tabela filtrada para a etapa: <strong className="font-bold text-[#C49746]">{steps.find(s => s.id === selectedFocusStepId)?.name}</strong> (Clique duplo para abrir POP e especificações)
                        </span>
                        <button
                          type="button"
                          onClick={() => setSelectedFocusStepId("ALL")}
                          className="text-[10px] uppercase font-bold text-red-600 hover:text-red-800 underline tracking-wide cursor-pointer ml-4"
                        >
                          Limpar Filtro (Mostrar Todas)
                        </button>
                      </div>
                    )}
                    <div className="overflow-x-auto border-t border-b border-[#1A1A1A]/20">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-[#1A1A1A] bg-[#F5F2ED] text-[9px] font-bold uppercase tracking-widest">
                            <th className="py-2 px-3"># Etapa</th>
                            <th className="py-2 px-2">Recursos Disponíveis</th>
                            <th className="py-2 px-2">Tempo Ciclo (min)</th>
                            <th className="py-2 px-2">Desvio σ (Var.)</th>
                            <th className="py-2 px-2">Rendimento (Yield %)</th>
                            <th className="py-2 px-2">Setup (min)</th>
                            <th className="py-2 px-3 text-center">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#1A1A1A]/10">
                          {steps
                            .map((step, idx) => ({ step, idx }))
                            .filter(({ step }) => selectedFocusStepId === "ALL" || step.id === selectedFocusStepId)
                            .map(({ step, idx }) => (
                            <tr 
                              key={step.id} 
                              onDoubleClick={() => setActiveDetailStepId(step.id)}
                              className="hover:bg-amber-50/25 transition-colors cursor-pointer select-none"
                              title="Dê um clique duplo para ver especificações adicionais de qualidade e instruções POP desta etapa"
                            >
                              <td className="py-2.5 px-3">
                                <div className="flex flex-col gap-1 w-full min-w-[140px]">
                                  <div className="flex items-center gap-1">
                                    <span className="text-[10px] font-mono font-bold text-[#C49746]">{idx + 1}.</span>
                                    <input
                                      type="text"
                                      value={step.name}
                                      onChange={(e) => handleUpdateStepField(idx, "name", e.target.value)}
                                      className="font-bold text-[11.5px] text-slate-800 bg-[#FAF9F5]/40 hover:bg-white focus:bg-white border-b border-dashed border-transparent focus:border-[#C49746] focus:outline-none w-full p-0.5 rounded-sm"
                                      title="Clique para editar o nome da etapa diretamente"
                                    />
                                    <button 
                                      type="button"
                                      onClick={() => setActiveDetailStepId(step.id)}
                                      className="text-gray-400 hover:text-[#C49746] p-0.5 cursor-pointer bg-transparent border-none"
                                      title="Abrir detalhes avançados/POP"
                                    >
                                      <FileText size={11} />
                                    </button>
                                  </div>
                                  <div className="flex items-center gap-1 pl-3.5">
                                    <User size={9} className="text-gray-400 shrink-0" />
                                    <input
                                      type="text"
                                      value={step.resource}
                                      onChange={(e) => handleUpdateStepField(idx, "resource", e.target.value)}
                                      className="text-[9.5px] text-[#1A1A1A]/60 bg-transparent focus:border-b focus:border-gray-300 focus:outline-none w-full font-medium"
                                      placeholder="Recurso principal"
                                      title="Editar recurso executor"
                                    />
                                  </div>
                                </div>
                              </td>
                              
                              <td className="py-2.5 px-2">
                                <div className="flex items-center gap-1">
                                  <input
                                    type="number"
                                    min={1}
                                    max={10}
                                    value={step.resourceCount}
                                    onChange={(e) => handleUpdateStepField(idx, "resourceCount", Number(e.target.value))}
                                    className="w-10 bg-white border border-[#1A1A1A]/10 p-1 text-center font-mono rounded-none"
                                  />
                                  <span className="text-[10px] text-[#1A1A1A]/50 font-serif">serv.</span>
                                </div>
                              </td>

                              <td className="py-2.5 px-2">
                                <input
                                  type="number"
                                  step="0.1"
                                  min="0.1"
                                  value={step.processingTime}
                                  onChange={(e) => handleUpdateStepField(idx, "processingTime", parseFloat(e.target.value) || 0.1)}
                                  className="w-12 bg-white border border-[#1A1A1A]/10 p-1 text-center font-mono rounded-none"
                                />
                              </td>

                              <td className="py-2.5 px-2">
                                <input
                                  type="number"
                                  step="0.1"
                                  min="0.05"
                                  value={step.standardDeviation}
                                  onChange={(e) => handleUpdateStepField(idx, "standardDeviation", parseFloat(e.target.value) || 0.1)}
                                  className="w-12 bg-white border border-[#1A1A1A]/10 p-1 text-center font-mono rounded-none"
                                />
                              </td>

                              <td className="py-2.5 px-2">
                                <div className="flex items-center gap-1">
                                  <input
                                    type="number"
                                    min="10"
                                    max="100"
                                    value={Math.round(step.yieldRate * 100)}
                                    onChange={(e) => handleUpdateStepField(idx, "yieldRate", parseFloat(e.target.value) / 100)}
                                    className="w-12 bg-white border border-[#1A1A1A]/10 p-1 text-center font-mono rounded-none"
                                  />
                                  <span>%</span>
                                </div>
                              </td>

                              <td className="py-2.5 px-2">
                                <input
                                  type="number"
                                  min="0"
                                  value={step.setupTime}
                                  onChange={(e) => handleUpdateStepField(idx, "setupTime", Number(e.target.value))}
                                  className="w-12 bg-white border border-[#1A1A1A]/10 p-1 text-center font-mono rounded-none"
                                />
                              </td>

                              <td className="py-2.5 px-3 text-center">
                                <button
                                  id={`delete-step-${step.id}`}
                                  onClick={() => handleDeleteStep(step.id)}
                                  className="text-red-600 hover:text-red-800 p-1 rounded-sm"
                                  title="Remover etapa"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* ADD NEW STEP FORM */}
                    <form onSubmit={handleAddStep} className="bg-[#F5F2ED] p-4 border border-[#1A1A1A]/10 grid grid-cols-1 md:grid-cols-4 gap-3">
                      <div className="md:col-span-2">
                        <label className="block text-[8px] font-bold uppercase tracking-widest mb-1 text-[#1A1A1A]/60">Nome da Nova Etapa</label>
                        <input
                          type="text"
                          placeholder="Ex: Inspeção Final"
                          value={newStepName}
                          onChange={(e) => setNewStepName(e.target.value)}
                          className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[8px] font-bold uppercase tracking-widest mb-1 text-[#1A1A1A]/60">Recurso/Cargo</label>
                        <input
                          type="text"
                          placeholder="Ex: Operador"
                          value={newStepResource}
                          onChange={(e) => setNewStepResource(e.target.value)}
                          className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-end">
                        <button
                          type="submit"
                          id="add-step-btn"
                          className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-widest font-bold py-2"
                        >
                          + Adicionar Etapa
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-5 gap-2 md:col-span-4 mt-1 border-t border-[#1A1A1A]/5 pt-2">
                        <div>
                          <label className="block text-[8px] uppercase tracking-tighter text-[#1A1A1A]/60">Operadores (Ex: 1)</label>
                          <input
                            type="number"
                            min="1"
                            value={newStepResourceCount}
                            onChange={(e) => setNewStepResourceCount(Number(e.target.value))}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1"
                          />
                        </div>
                        <div>
                          <label className="block text-[8px] uppercase tracking-tighter text-[#1A1A1A]/60">Tempo Médio (min)</label>
                          <input
                            type="number"
                            step="0.1"
                            value={newStepProcessingTime}
                            onChange={(e) => setNewStepProcessingTime(parseFloat(e.target.value) || 1)}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1"
                          />
                        </div>
                        <div>
                          <label className="block text-[8px] uppercase tracking-tighter text-[#1A1A1A]/60">Desvio Padrão σ (min)</label>
                          <input
                            type="number"
                            step="0.1"
                            value={newStepStdev}
                            onChange={(e) => setNewStepStdev(parseFloat(e.target.value) || 0.1)}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1"
                          />
                        </div>
                        <div>
                          <label className="block text-[8px] uppercase tracking-tighter text-[#1A1A1A]/60">Qualidade Yield %</label>
                          <input
                            type="number"
                            min="10"
                            max="100"
                            value={newStepYield}
                            onChange={(e) => setNewStepYield(Number(e.target.value))}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1"
                          />
                        </div>
                        <div>
                          <label className="block text-[8px] uppercase tracking-tighter text-[#1A1A1A]/60">Setup/Ajuste (min)</label>
                          <input
                            type="number"
                            min="0"
                            value={newStepSetup}
                            onChange={(e) => setNewStepSetup(Number(e.target.value))}
                            className="w-full bg-white border border-[#1A1A1A]/10 text-xs px-2 py-1"
                          />
                        </div>
                      </div>
                    </form>
                  </div>

                  {/* Right Parameter Panel: Dynamic Arrival Rate / Demand Controls */}
                  <div className="lg:col-span-4 space-y-6 flex flex-col justify-between">
                    <div className="border-t border-[#1A1A1A] pt-4 space-y-4">
                      <h3 className="text-xs font-bold uppercase tracking-widest">A Taxa de Chegada de Demanda (Takt)</h3>
                      <p className="text-[11px] leading-relaxed text-[#1A1A1A]/80">
                        O motor estocástico avalia o tempo de fila gerado pela concorrência das ordens de trabalho. Ajuste o controle deslizante abaixo para regular a taxa horária do processo.
                      </p>

                      <div className="bg-[#F5F2ED] p-4 text-center border border-[#1A1A1A]/15 space-y-2">
                        <div className="text-[9px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest">Taxa Requerida</div>
                        <div className="text-3xl font-serif italic text-[#C49746]">{arrivalRate} un / hora</div>
                        <input
                          id="arrival-rate-slider"
                          type="range"
                          min="1"
                          max="25"
                          value={arrivalRate}
                          onChange={(e) => setArrivalRate(Number(e.target.value))}
                          className="w-full h-1 bg-[#1A1A1A]/10 rounded-lg appearance-none cursor-pointer accent-[#C49746] mt-2"
                        />
                        <div className="flex justify-between text-[8px] text-[#1A1A1A]/40 uppercase">
                          <span>1 u/h</span>
                          <span>Estável: ≤ 10 u/h</span>
                          <span>Crítico: ≥ 15 u/h</span>
                          <span>25 u/h</span>
                        </div>
                      </div>
                    </div>

                    <div className="border border-[#1A1A1A]/10 p-4 bg-white text-[10px] space-y-2 mt-4">
                      <div className="font-bold flex items-center gap-1">
                        <Info size={12} className="text-[#C49746]" />
                        Ciência de Dados de Operação:
                      </div>
                      <p className="leading-relaxed">
                        Os processos de manufatura ou serviços não operam isolados de variabilidade. O tempo de ciclo representativo é governado pela média estocástica e variabilidade (desvio padrão). Quanto maior a variação de tempos, maior será o fator de congestionamento e filas.
                      </p>
                    </div>
                  </div>

                </div>

                {/* Global Cycle Time Histogram for step-by-step 2σ variability analysis */}
                <GlobalCycleTimeHistogram 
                  steps={steps} 
                  selectedStepId={selectedFocusStepId}
                  onSelectStep={(stepId) => {
                    setSelectedFocusStepId(stepId || "ALL");
                    if (stepId && stepId !== "ALL") {
                      const foundStep = steps.find(s => s.id === stepId);
                      if (foundStep) {
                        setSelectedDmaicStep(foundStep);
                      }
                    }
                  }}
                />

                {/* HISTORICAL MONTE CARLO RANDOM VARIABILITY PLOT (Editorial Styled Charts) */}
                <div className="border-t border-[#1A1A1A] pt-8 space-y-6">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-widest">Simulação de Monte Carlo dos Últimos 20 Ciclos</h3>
                      <p className="text-[11px] text-[#1A1A1A]/60">Análise estocástica de flutuações e variabilidade de Lead Time em tempo de execução real.</p>
                    </div>

                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 bg-[#C49746] rounded-none"></span>
                        <span className="text-[9px] uppercase tracking-widest text-[#1A1A1A]/60">Retardo Acumulado</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 bg-[#1A1A1A] rounded-none"></span>
                        <span className="text-[9px] uppercase tracking-widest text-[#1A1A1A]/60">Média Estável</span>
                      </div>
                    </div>
                  </div>

                  {simulationData ? (
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-end">
                      
                      {/* Interactive Visual Graph Grid (SVG based for bulletproof layout) */}
                      <div className="lg:col-span-8 bg-white border border-[#1A1A1A]/15 p-4">
                        <div className="relative h-60 w-full flex items-end justify-between px-2 pt-6 pb-2">
                          
                          {/* Grid line guidelines */}
                          <div className="absolute inset-x-0 top-1/4 border-t border-[#1A1A1A]/5 text-[8px] text-[#1A1A1A]/30 pt-1 pointer-events-none">Estresse de Capacidade (Alto)</div>
                          <div className="absolute inset-x-0 top-2/4 border-t border-[#1A1A1A]/5 text-[8px] text-[#1A1A1A]/30 pt-1 pointer-events-none">Zona Estável Operacional</div>
                          <div className="absolute inset-x-0 top-3/4 border-t border-[#1A1A1A]/5 text-[8px] text-[#1A1A1A]/30 pt-1 pointer-events-none">Fluxo Rápido</div>

                          {/* Render visual bars representing daily cycles */}
                          {simulationData.dailyAverages.map((dayData: any, i: number) => {
                            // Max cycle time is usually ~120 mins for scaling
                            const maxScaleValue = Math.max(...simulationData.dailyAverages.map((d: any) => d.cycleTime), 60);
                            const percentHeight = (dayData.cycleTime / maxScaleValue) * 100;

                            return (
                              <div key={dayData.day} className="flex-1 flex flex-col items-center group relative px-0.5 md:px-1 h-full justify-end">
                                
                                {/* Dynamic bar */}
                                <div 
                                  className={`w-full transition-all duration-500 rounded-none cursor-pointer ${
                                    dayData.cycleTime > charter.targetValue 
                                      ? "bg-[#C49746] hover:bg-[#C49746]/80" 
                                      : "bg-[#1A1A1A]/80 hover:bg-[#1A1A1A]"
                                  }`}
                                  style={{ height: `${percentHeight}%` }}
                                ></div>

                                {/* Micro popover tooltip */}
                                <div className="absolute opacity-0 group-hover:opacity-100 transition-opacity bg-[#1A1A1A] text-white text-[9px] p-2 rounded-none -top-12 shadow-md z-40 pointer-events-none whitespace-nowrap">
                                  <div className="font-bold font-serif">Ciclo #{dayData.day}</div>
                                  <div>Lead Time: <span className="font-mono">{dayData.cycleTime} min</span></div>
                                  <div>Defeito: <span className="font-mono">{dayData.defectRate}%</span></div>
                                </div>
                              </div>
                            );
                          })}

                        </div>
                        <div className="flex justify-between text-[8px] font-bold uppercase tracking-widest text-[#1A1A1A]/40 mt-1 pl-1">
                          <span>Ciclo Inicial (Lote 1)</span>
                          <span>Metade de Campanha</span>
                          <span>Último Lote Amostrado (Lote 20)</span>
                        </div>
                      </div>

                      {/* Side Stat Analysis Container */}
                      <div className="lg:col-span-4 bg-[#F5F2ED] p-6 space-y-4 h-full flex flex-col justify-between">
                        <div>
                          <h4 className="text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A]/60">Análise de Amostra</h4>
                          <p className="text-[11px] leading-relaxed mt-1 text-[#1A1A1A]">
                            Os relatórios mostram que as variações nos ciclos são provocadas por problemas de setup e gargalos na <strong>{stats.bottleneckStepName}</strong>. 
                          </p>
                        </div>
                        
                        <div className="border-t border-[#1A1A1A]/10 pt-3">
                          <div className="flex justify-between py-1 text-xs text-[#1A1A1A]/80">
                            <span>Melhor Lead Time Sim.:</span>
                            <span className="font-mono font-bold text-emerald-700">
                              {Math.min(...simulationData.dailyAverages.map((d: any) => d.cycleTime)).toFixed(1)} min
                            </span>
                          </div>
                          <div className="flex justify-between py-1 text-xs text-[#1A1A1A]/80">
                            <span>Pior Lead Time Sim.:</span>
                            <span className="font-mono font-bold text-[#C49746]">
                              {Math.max(...simulationData.dailyAverages.map((d: any) => d.cycleTime)).toFixed(1)} min
                            </span>
                          </div>
                           <div className="flex justify-between py-1 text-xs text-[#1A1A1A]/80">
                            <span>Desvio Amostral Médio:</span>
                            <span className="font-mono font-bold">
                              {stats.stdevProcess.toFixed(2)} min
                            </span>
                          </div>
                        </div>
                      </div>

                    </div>
                  ) : (
                    <div className="h-40 flex items-center justify-center bg-[#F5F2ED] text-xs uppercase tracking-widest">
                      Nenhum dado simulado. Ajuste os parâmetros acima.
                    </div>
                  )}
                </div>

                {/* REAL-TIME TELEMETRY LOGS GENERATION */}
                {simulationData && simulationData.logs.length > 0 && (
                  <div className="border-t border-[#1A1A1A] pt-8 space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Registro de Amostragem (Telemetry Live View)</h4>
                        <p className="text-[11px] text-[#1A1A1A]/60">Rastreabilidade pontual de unidades pelo fluxo produtivo estocástico.</p>
                      </div>
                      <span className="text-[10px] font-mono text-[#C49746]">Amostras do Lote Corrente</span>
                    </div>

                    <div className="bg-white border border-[#1A1A1A]/10 overflow-hidden">
                      <div className="grid grid-cols-6 bg-[#F5F2ED] text-[9px] font-bold uppercase tracking-wider py-1.5 px-3 border-b border-[#1A1A1A]/10">
                        <div>Hora do Registro</div>
                        <div>Placa / ID Código</div>
                        <div>Etapa de Passagem</div>
                        <div className="text-right">Tempo Próprio</div>
                        <div className="text-right">Tempo em Fila</div>
                        <div className="text-center">Controle de Qualidade</div>
                      </div>
                      <div className="divide-y divide-[#1A1A1A]/5 max-h-48 overflow-y-auto text-xs">
                        {simulationData.logs.map((log: SimulationLog, idx: number) => (
                          <div key={idx} className="grid grid-cols-6 py-2 px-3 hover:bg-[#F5F2ED]/30 transition">
                            <div className="font-mono text-[#1A1A1A]/60">{log.timestamp}</div>
                            <div className="font-mono font-bold text-[#1A1A1A]">#UNIT-{log.unitId}</div>
                            <div className="truncate pr-2">{log.stepName}</div>
                            <div className="text-right font-mono">{log.duration.toFixed(2)} min</div>
                            <div className="text-right font-mono text-[#C49746]">{log.queueDuration.toFixed(2)} min</div>
                            <div className="text-center">
                              {log.defect ? (
                                <span className="bg-red-100 text-red-800 text-[9px] font-bold px-1.5 py-0.5 rounded-sm">RETRABALHO</span>
                              ) : (
                                <span className="text-emerald-700 text-[10px]">Aprovado</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Progression button */}
                <div className="flex justify-between pt-4 border-t border-[#1A1A1A]/10">
                  <button
                    onClick={handlePrevPhase}
                    className="border border-[#1A1A1A]/20 hover:border-[#1A1A1A] py-3 px-6 text-xs uppercase tracking-widest font-bold transition"
                  >
                    Voltar para DEFINE
                  </button>
                  <button
                    onClick={handleNextPhase}
                    className="bg-[#1A1A1A] text-white py-3 px-6 text-xs uppercase tracking-widest font-bold hover:opacity-90 flex items-center gap-2 transition"
                  >
                    Prosseguir para Análise (ANALYZE) <ChevronRight size={14} />
                  </button>
                </div>

              </div>
            )}

            {/* ==================== 3. ANALYZE PHASE ==================== */}
            {activePhase === "ANALYZE" && (
              <div className="space-y-12 animate-fade-in" id="analyze-phase-viewport">
                
                {/* Introduction & Queue calculations */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Process bottlenecks and statistical queue analytics */}
                  <div className="lg:col-span-7">
                    <BottleneckDetector
                      steps={steps}
                      arrivalRate={arrivalRate}
                      selectedStepId={selectedFocusStepId}
                      onClearFilter={() => setSelectedFocusStepId("ALL")}
                      onInitiateDmaic={(step) => {
                        setSelectedDmaicStep(step);
                        setCurrentWorkspaceView("DMAIC");
                      }}
                    />
                  </div>

                  {/* AI INSIGHT COMPONENT USING GEMINI WITH DYNAMIC TRIGGER */}
                  <div className="lg:col-span-5 bg-white border border-[#1A1A1A]/15 p-6 space-y-4 shadow-sm relative">
                    <div className="flex items-center justify-between border-b border-[#1A1A1A]/10 pb-3">
                      <div className="flex items-center gap-2">
                        <Sparkles className="text-[#C49746]" size={18} />
                        <h4 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Análise Cognitiva de IA</h4>
                      </div>
                      <span className="text-[10px] uppercase font-mono text-[#C49746]">Gemini 3.5 Flash</span>
                    </div>

                    <p className="text-[11px] leading-relaxed text-[#1A1A1A]/80">
                      Dispare a inteligência generativa estrutural do Gemini para examinar a correlação deste processo com as práticas mundiais da Toyota, aplicando Teoria das Filas e Engenharia Industrial Avançada.
                    </p>

                    <button
                      id="gemini-trigger-btn"
                      onClick={handleCallGeminiApi}
                      disabled={aiLoading}
                      className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[10px] uppercase tracking-widest font-bold py-3 px-4 flex items-center justify-center gap-2 transition"
                    >
                      {aiLoading ? (
                        <>
                          <RefreshCw className="animate-spin text-[#C49746]" size={12} />
                          Engrenando recomendator de dados...
                        </>
                      ) : (
                        <>
                          <Cpu size={12} className="text-[#C49746]" />
                          Consultar Especialista LSS IA
                        </>
                      )}
                    </button>

                    {aiError && (
                      <div className="p-3 bg-red-100 text-red-800 text-[10px] font-medium rounded-none border-l-2 border-red-800">
                        {aiError}
                      </div>
                    )}

                    {aiResult ? (
                      <div className="space-y-4 animate-fade-in text-[11px] pt-2" id="ai-results-pane">
                        <div className="border-t border-[#1A1A1A]/10 pt-3">
                          <h5 className="font-serif font-bold text-sm mb-1">Diagnóstico Executivo da IA</h5>
                          <p className="leading-relaxed text-[#1A1A1A]/80">{aiResult.executiveSummary}</p>
                        </div>

                        {/* DMAIC Plan detail extracted dynamically */}
                        <div className="space-y-2">
                          <h6 className="font-bold text-[9px] uppercase tracking-widest text-[#C49746]">Ações Recomendadas por Fase DMAIC:</h6>
                          <div className="bg-[#F5F2ED] p-3 text-[10.5px] leading-relaxed rounded-none border-l-2 border-[#1A1A1A] space-y-1">
                            <div><strong>Define:</strong> {aiResult.dmaicApproach?.define}</div>
                            <div><strong>Measure:</strong> {aiResult.dmaicApproach?.measure}</div>
                            <div><strong>Analyze:</strong> {aiResult.dmaicApproach?.analyze}</div>
                            <div><strong>Improve:</strong> {aiResult.dmaicApproach?.improve}</div>
                            <div><strong>Control:</strong> {aiResult.dmaicApproach?.control}</div>
                          </div>
                        </div>

                        {/* List of custom Lean/PO tactics */}
                        <div className="space-y-2 mt-4">
                          <h6 className="font-bold text-[9px] uppercase tracking-widest text-[#1A1A1A]">Contra-medidas Táticas Propostas:</h6>
                          {aiResult.orRecommendations?.map((rec: any, i: number) => (
                            <div key={i} className="border-b border-[#1A1A1A]/5 pb-2">
                              <span className="bg-[#1A1A1A] text-white text-[8px] font-bold px-1.5 py-0.5 uppercase mr-1.5 inline-block">
                                {rec.leanPrinciple}
                              </span>
                              <strong className="text-xs text-[#1A1A1A] block mt-1">{rec.title}</strong>
                              <p className="text-[#1A1A1A]/70 mt-0.5 leading-snug">{rec.description}</p>
                              <span className="text-[#C49746] text-[9.5px] italic block mt-0.5">Impacto: {rec.expectedImpact}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 bg-[#F5F2ED] text-center border border-dashed border-[#1A1A1A]/20 text-[11px] italic text-[#1A1A1A]/60 rounded-none">
                        Clique acima para gerar o estudo estruturado de Pesquisa Operacional gerado pela Inteligência Artificial.
                      </div>
                    )}
                  </div>

                </div>

                {/* Progression button */}
                <div className="flex justify-between pt-4 border-t border-[#1A1A1A]/10">
                  <button
                    onClick={handlePrevPhase}
                    className="border border-[#1A1A1A]/20 hover:border-[#1A1A1A] py-3 px-6 text-xs uppercase tracking-widest font-bold transition"
                  >
                    Voltar para MEASURE
                  </button>
                  <button
                    onClick={handleNextPhase}
                    className="bg-[#1A1A1A] text-white py-3 px-6 text-xs uppercase tracking-widest font-bold hover:opacity-90 flex items-center gap-2 transition"
                  >
                    Prosseguir para Melhoria (IMPROVE) <ChevronRight size={14} />
                  </button>
                </div>

              </div>
            )}

            {/* ==================== 4. IMPROVE PHASE ==================== */}
            {activePhase === "IMPROVE" && (
              <div className="space-y-12 animate-fade-in" id="improve-phase-viewport">
                
                {/* Visual Intro row */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  <div className="lg:col-span-8 space-y-6">
                    <div className="border-t border-[#1A1A1A] pt-4">
                      <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest mb-1">04 / Fase IMPROVE</p>
                      <h2 className="text-3xl font-serif tracking-tight pr-4">Melhoramento de Capacidade e Neutralização Kaizen</h2>
                    </div>

                    <p className="text-xs text-[#1A1A1A]/75 leading-relaxed">
                      A fase <strong>Improve</strong> atua diretamente na eliminação de desperdícios das sete perdas clássicas Lean (Overproduction, Waiting, Transport, Overprocessing, Inventory, Motion e Defects). Oferecemos um módulo de simulação interativo onde você pode testar o impacto imediato das táticas mais consagradas industriais.
                    </p>

                    {/* Presets and options dashboard card */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      
                      <div className="border border-[#1A1A1A]/15 p-4 bg-white flex flex-col justify-between">
                        <div>
                          <div className="text-[9px] font-bold uppercase tracking-widest text-[#C49746] mb-1">Princípio 01</div>
                          <h4 className="font-serif font-bold text-sm mb-2 text-[#1A1A1A]">Poka-Yoke na AOI</h4>
                          <p className="text-[11px] text-[#1A1A1A]/70 leading-snug">
                            Implementação de gabarito digital e travamento à prova de falhas na inspeção óptica, elevando a qualidade de primeira passagem para 99% e mitigando o tempo de retrabalho amostral.
                          </p>
                        </div>
                        <button
                          id="poka-yoke-btn"
                          onClick={() => {
                            const updated = steps.map((s) => s.id === "step-3" ? { ...s, yieldRate: 0.99, standardDeviation: 0.5 } : s);
                            setSteps(updated);
                          }}
                          className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-wider font-bold py-2 mt-4"
                        >
                          Habilitar Poka-Yoke
                        </button>
                      </div>

                      <div className="border border-[#1A1A1A]/15 p-4 bg-[#F5F2ED] flex flex-col justify-between">
                        <div>
                          <div className="text-[9px] font-bold uppercase tracking-widest text-[#C49746] mb-1">Princípio 02</div>
                          <h4 className="font-serif font-bold text-sm mb-2 text-[#1A1A1A]">SMED (Setup 15m → 2m)</h4>
                          <p className="text-[11px] text-[#1A1A1A]/70 leading-snug">
                            Estudo de setup rápido (Single Minute Exchange of Die) convertendo setups internos em externos. Zera praticamente o tempo ocioso o que previne flutuações de lead time.
                          </p>
                        </div>
                        <button
                          id="smed-btn"
                          onClick={() => {
                            const updated = steps.map((s) => ({ ...s, setupTime: Math.max(0, Math.round(s.setupTime * 0.2)) }));
                            setSteps(updated);
                          }}
                          className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-wider font-bold py-2 mt-4"
                        >
                          Aplicar SMED Rápido
                        </button>
                      </div>

                      <div className="border border-[#1A1A1A]/15 p-4 bg-white flex flex-col justify-between">
                        <div>
                          <div className="text-[9px] font-bold uppercase tracking-widest text-[#C49746] mb-1">Princípio 03</div>
                          <h4 className="font-serif font-bold text-sm mb-2 text-[#1A1A1A]">Balanceamento Operadores</h4>
                          <p className="text-[11px] text-[#1A1A1A]/70 leading-snug">
                            Remodelação do layout operacional adicionando operadores especializados nas etapas críticas como montagem final mecânica, mitigando a gargalo estatístico da linha.
                          </p>
                        </div>
                        <button
                          id="balancing-btn"
                          onClick={() => {
                            const updated = steps.map((s) => s.id === "step-4" ? { ...s, resourceCount: 2 } : s);
                            setSteps(updated);
                          }}
                          className="w-full bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-wider font-bold py-2 mt-4"
                        >
                          Balancear Postos (2 Op)
                        </button>
                      </div>

                    </div>
                  </div>

                  {/* Operational impact summary card */}
                  <div className="lg:col-span-4 bg-[#1A1A1A] text-white p-6 space-y-6">
                    <div className="border-b border-white/20 pb-3">
                      <h4 className="text-[10px] uppercase tracking-widest font-bold text-[#C49746]">Painel Unificado Lean</h4>
                      <h3 className="text-lg font-serif italic mt-1 text-white">Otimização DMAIC em 1-Clique</h3>
                    </div>

                    <p className="text-[11px] text-white/80 leading-relaxed">
                      Ative uma transformação estruturada imediata. Essa rotina reajusta os buffers de variabilidade de forma a converter o processo atual em um fluxo estável de classe mundial.
                    </p>

                    <div className="bg-white/10 p-4 border border-white/20 text-xs text-center space-y-2">
                      <div className="text-[9px] uppercase tracking-widest text-[#C49746] font-bold">Otimização Total Recomendada</div>
                      <p className="text-[10px]">Poka-Yoke + Setup Rápido + Redutor de Variabilidade</p>
                      
                      <button
                        id="apply-lean-full-btn"
                        onClick={handleApplyLeanOptimization}
                        className="w-full bg-[#C49746] hover:bg-[#C49746]/90 text-white text-[10px] uppercase tracking-widest font-bold py-2.5 mt-2 shadow-sm transition-all"
                      >
                        Aplicar Estrutura Otimizada
                      </button>
                    </div>

                    <div className="text-[9px] text-white/60 space-y-1">
                      <div className="flex justify-between">
                        <span>Almoço de Capacidade:</span>
                        <span className="font-mono text-white font-bold">{stats.systemCapacity.toFixed(1)} u/h</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Meta de Prazo:</span>
                        <span className="font-mono text-white font-bold">{charter.targetValue} min</span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* COMPARATIVE METRICAL ANALYSIS (Current vs Recommended Future State) */}
                <div className="border-t border-[#1A1A1A] pt-8 space-y-6">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Análise Comparativa de Capacidade (Controle Estatístico de Processo)</h3>
                    <p className="text-[11px] text-[#1A1A1A]/60">Mudanças dinâmicas de métricas cruciais sob ações de engenharia.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    
                    <div className="border border-[#1A1A1A]/10 p-4 bg-white">
                      <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest mb-1">Estabilidade de Lead Time</div>
                      <div className="flex items-baseline justify-between">
                        <span className="text-2xl font-serif font-semibold">{stats.leadTime.toFixed(1)} min</span>
                        <span className={`text-[10px] font-bold ${stats.leadTime <= charter.targetValue ? "text-emerald-700" : "text-[#C49746]"}`}>
                          {stats.leadTime <= charter.targetValue ? "Meta Atingida" : "Fora da Meta"}
                        </span>
                      </div>
                      <div className="text-[9.5px] text-[#1A1A1A]/50 mt-1">Limite do Charter: {charter.targetValue}m</div>
                    </div>

                    <div className="border border-[#1A1A1A]/10 p-4 bg-white">
                      <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest mb-1">Qualidade de Primeira Passagem</div>
                      <div className="flex items-baseline justify-between">
                        <span className="text-2xl font-serif font-semibold">{totalRolledYieldPercent}%</span>
                        <span className={`text-[10px] font-bold ${stats.rolledFirstPassYield >= 0.95 ? "text-emerald-700" : "text-[#C49746]"}`}>
                          {stats.rolledFirstPassYield >= 0.95 ? "Classe Mundial" : "Retrabalho Alto"}
                        </span>
                      </div>
                      <div className="text-[9.5px] text-[#1A1A1A]/50 mt-1">DPMO Atual: {dpmoFormatted}</div>
                    </div>

                    <div className="border border-[#1A1A1A]/10 p-4 bg-white">
                      <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest mb-1">Capacidade de Entrega (Thruput)</div>
                      <div className="flex items-baseline justify-between">
                        <span className="text-2xl font-serif font-semibold">{stats.systemCapacity.toFixed(1)} u/h</span>
                        <span className="text-[10px] font-bold text-[#1A1A1A]/80">Demanda: {arrivalRate}</span>
                      </div>
                      <div className="text-[9.5px] text-[#1A1A1A]/50 mt-1">Fator Saturação: {stats.systemUtilization.toFixed(0)}%</div>
                    </div>

                    <div className="border border-[#1A1A1A]/10 p-4 bg-white">
                      <div className="text-[8px] font-bold text-[#1A1A1A]/40 uppercase tracking-widest mb-1">WIP Ativo no Piso</div>
                      <div className="flex items-baseline justify-between">
                        <span className="text-2xl font-serif font-semibold">{systemWipFormatted} un.</span>
                        <span className="text-[10px] font-mono text-emerald-700">Fluxo Contínuo</span>
                      </div>
                      <div className="text-[9.5px] text-[#1A1A1A]/50 mt-1">Processamento Útil: {stats.processingTimeSum.toFixed(1)}m</div>
                    </div>

                  </div>
                </div>

                {/* Progression button */}
                <div className="flex justify-between pt-4 border-t border-[#1A1A1A]/10">
                  <button
                    onClick={handlePrevPhase}
                    className="border border-[#1A1A1A]/20 hover:border-[#1A1A1A] py-3 px-6 text-xs uppercase tracking-widest font-bold transition"
                  >
                    Voltar para ANALYZE
                  </button>
                  <button
                    onClick={handleNextPhase}
                    className="bg-[#1A1A1A] text-white py-3 px-6 text-xs uppercase tracking-widest font-bold hover:opacity-90 flex items-center gap-2 transition"
                  >
                    Prosseguir para Controle (CONTROL) <ChevronRight size={14} />
                  </button>
                </div>

              </div>
            )}

            {/* ==================== 5. CONTROL PHASE ==================== */}
            {activePhase === "CONTROL" && (
              <div className="space-y-12 animate-fade-in" id="control-phase-viewport">

                {/* GLOBAL AUTOMATIC CEP ALARM NOTIFICATIONS PANEL */}
                <div id="control-alerts-panel" className={`border p-6 rounded-sm shadow-sm space-y-6 transition-all duration-300 ${activeAlarms.length > 0 ? 'bg-[#FEF2F2]/90 border-red-200/80 border-l-4 border-l-red-600 text-[#1A1A1A]' : 'bg-[#FAFDF9]/90 border-emerald-200/80 border-l-4 border-l-emerald-600 text-[#1A1A1A]'}`}>
                  
                  {/* HEADER */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A]/10 pb-4">
                    <div className="space-y-1 text-left">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full animate-pulse shrink-0 ${activeAlarms.length > 0 ? 'bg-red-650' : 'bg-emerald-600'}`}></span>
                        <h4 className="text-xs font-bold uppercase tracking-wider font-mono text-slate-800">
                          {activeAlarms.length > 0 ? `ALERTA CEP ATIVO • VIOLAÇÃO DE LIMITES (${activeAlarms.length})` : "CONTROLE DE QUALIDADE ESTÁVEL • NENHUMA ANOMALIA (0)"}
                        </h4>
                      </div>
                      <p className="text-[11px] text-gray-650">Painel Unificado de Modelagem SPC, Cartas de Controle & Diretrizes de Reação</p>
                    </div>

                    {/* Sensitivity Scale Tweak */}
                    <div className="bg-[#FAF8F5] border border-amber-250 p-2.5 flex items-center gap-3 shrink-0 rounded-sm">
                      <div className="text-left leading-tight">
                        <span className="text-[8px] uppercase tracking-wide text-[#C49746] font-bold block">Sensibilidade Geral</span>
                        <span className="text-[10px] text-slate-650">Shewhart σ Multiplier</span>
                      </div>
                      <div className="flex items-center gap-1 bg-white border border-[#1A1A1A]/10 px-2 py-1 rounded-sm">
                        <input
                          id="dashboard-sigma-multiplier-input"
                          type="number"
                          step="0.1"
                          min="1.0"
                          max="5.0"
                          value={alarmSigmaSensitivity}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setAlarmSigmaSensitivity(isNaN(val) ? 3.0 : Math.max(0.5, val));
                          }}
                          className="w-10 text-center font-mono text-xs font-bold text-[#C49746] focus:outline-none"
                        />
                        <span className="text-[10px] font-bold text-[#C49746] font-mono pr-0.5">σ</span>
                      </div>
                    </div>
                  </div>

                  {/* MASTER GRID */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
                    
                    {/* LEFT COLUMN: DEFINIÇÃO DE LIMITES DE CONTROLE (SPC Limits) */}
                    <div className="space-y-4 bg-white/70 p-4 border border-[#1A1A1A]/10 rounded-sm text-left">
                      <div className="flex items-center justify-between border-b pb-2">
                        <div className="space-y-0.5">
                          <h5 className="text-[10.5px] font-bold uppercase tracking-wider text-slate-800 font-sans flex items-center gap-1.5">
                            📐 Seção A: Definição de Limites de Controle
                          </h5>
                          <p className="text-[9px] text-gray-500">Mapeamento estocástico de tolerâncias operacionais e calibração das cartas 3-Sigma</p>
                        </div>
                        <span className="text-[8px] font-mono bg-indigo-50 border border-indigo-100 text-indigo-750 px-2 py-0.5 font-bold uppercase rounded-2xs">Shewhart Stats</span>
                      </div>

                      <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                        {controlPlans.map((plan, index) => {
                          const limits = getDynamicLimits(plan);
                          const currentVal = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                          const isOutside = currentVal < limits.lcl || currentVal > limits.ucl;
                          
                          return (
                            <div key={`param-${plan.id}`} className={`p-3 border rounded-sm transition-all text-xs space-y-2 ${isOutside && plan.enableAlarm ? 'bg-red-50/70 border-red-300' : 'bg-white/90 border-slate-200'}`}>
                              <div className="flex items-center justify-between font-sans shadow-3xs">
                                <span className="font-bold text-slate-900 text-[11px] truncate max-w-[200px]" title={plan.stepName}>
                                  {plan.stepName}
                                </span>
                                <span className={`text-[8.5px] font-mono px-1.5 py-0.5 rounded-xs font-black select-none ${isOutside && plan.enableAlarm ? 'bg-red-100 text-red-800 animate-pulse' : 'bg-emerald-100 text-emerald-800'}`}>
                                  {isOutside && plan.enableAlarm ? "VIOLAÇÃO" : "DENTRO DOS LIMITES"}
                                </span>
                              </div>

                              {/* Grid parameter editor inputs */}
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono">
                                <div className="space-y-1 text-left">
                                  <span className="text-[7.5px] uppercase font-bold text-slate-400 block tracking-tight">LCL (Min)</span>
                                  <input 
                                    type="number" 
                                    step="0.01" 
                                    value={plan.lcl}
                                    onChange={(e) => {
                                      const updated = [...controlPlans];
                                      updated[index].lcl = parseFloat(e.target.value) || 0;
                                      setControlPlans(updated);
                                    }}
                                    className="w-full bg-[#FAF9F5] border border-gray-255 p-1 font-bold text-center focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm"
                                  />
                                </div>
                                <div className="space-y-1 text-left">
                                  <span className="text-[7.5px] uppercase font-bold text-slate-400 block tracking-tight">Méd Alvo</span>
                                  <input 
                                    type="number" 
                                    step="0.01" 
                                    value={plan.target}
                                    onChange={(e) => {
                                      const updated = [...controlPlans];
                                      updated[index].target = parseFloat(e.target.value) || 0;
                                      setControlPlans(updated);
                                    }}
                                    className="w-full bg-[#FAF9F5] border border-gray-255 p-1 font-bold text-center focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm"
                                  />
                                </div>
                                <div className="space-y-1 text-left">
                                  <span className="text-[7.5px] uppercase font-bold text-slate-400 block tracking-tight">UCL (Max)</span>
                                  <input 
                                    type="number" 
                                    step="0.01" 
                                    value={plan.ucl}
                                    onChange={(e) => {
                                      const updated = [...controlPlans];
                                      updated[index].ucl = parseFloat(e.target.value) || 0;
                                      setControlPlans(updated);
                                    }}
                                    className="w-full bg-[#FAF9F5] border border-gray-255 p-1 font-bold text-center focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm"
                                  />
                                </div>
                                <div className="space-y-1 text-left">
                                  <span className="text-[7.5px] uppercase font-bold text-slate-400 block tracking-tight">Leitura</span>
                                  <input 
                                    type="number" 
                                    step="0.01" 
                                    value={plan.currentReading !== undefined ? plan.currentReading : plan.target}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      const updated = [...controlPlans];
                                      updated[index].currentReading = val;
                                      setControlPlans(updated);
                                      handleRegisterViolationIfNeeded(plan.id, val, updated);
                                    }}
                                    className="w-full bg-amber-50 border border-amber-300 text-[#C49746] p-1 font-bold text-center focus:outline-none focus:ring-1 focus:ring-[#C49746] rounded-sm"
                                  />
                                </div>
                              </div>

                              {/* Calculated Limits display indicator */}
                              <div className="flex justify-between items-center text-[8.5px] font-mono bg-[#FAF9F5] p-1.5 border border-slate-100 text-gray-500">
                                <span>Calculado LCL ({alarmSigmaSensitivity.toFixed(1)}σ): <strong className="text-gray-700">{limits.lcl.toFixed(3)}</strong></span>
                                <span>Calculado UCL ({alarmSigmaSensitivity.toFixed(1)}σ): <strong className="text-gray-700">{limits.ucl.toFixed(3)}</strong></span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* RIGHT COLUMN: CONFIGURAÇÃO DE REAÇÕES AUTOMÁTICAS (Autonomous Contingency / Reaction Plan) */}
                    <div className="space-y-4 bg-white/70 p-4 border border-[#1A1A1A]/10 rounded-sm text-left">
                      <div className="flex items-center justify-between border-b pb-2">
                        <div className="space-y-0.5">
                          <h5 className="text-[10.5px] font-bold uppercase tracking-wider text-slate-800 font-sans flex items-center gap-1.5">
                            🤖 Seção B: Configuração de Reações Automáticas
                          </h5>
                          <p className="text-[9px] text-gray-500">Diretrizes de contingência operacional autônoma e responsáveis técnicos vinculados</p>
                        </div>
                        <span className="text-[8px] font-mono bg-amber-50 border border-[#B7924F]/30 text-amber-800 px-2 py-0.5 font-bold uppercase rounded-2xs">Autonomous Plan</span>
                      </div>

                      {/* GLOBAL EMAIL VALIDATION WARNING BANNER */}
                      {(() => {
                        const hasInvalid = controlPlans.some(
                          (plan) =>
                            (plan.warningEmail && plan.warningEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(plan.warningEmail.trim())) ||
                            (plan.criticalEmail && plan.criticalEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(plan.criticalEmail.trim()))
                        );
                        if (hasInvalid) {
                          return (
                            <div className="p-2.5 bg-red-50 border border-red-200 text-red-800 rounded-sm text-[10px] space-y-1 animate-fade-in font-sans">
                              <p className="font-bold flex items-center gap-1">
                                ⚠️ Validação de E-mail Pendente
                              </p>
                              <p className="text-gray-600">
                                Existem endereços de e-mail inválidos configurados. O salvamento automático do plano de reação está temporariamente pausado até que todos os campos de e-mail sejam corrigidos para um formato válido (ex: <strong>nome@dominio.com</strong>).
                              </p>
                            </div>
                          );
                        }
                        return null;
                      })()}

                      <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
                        {controlPlans.map((plan, index) => {
                          const limits = getDynamicLimits(plan);
                          const currentVal = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                          
                          // Sigma measurements
                          const sigLower = Math.max(0.001, plan.target - plan.lcl) / 3;
                          const sigUpper = Math.max(0.001, plan.ucl - plan.target) / 3;
                          
                          const isCritical3s = currentVal < plan.lcl || currentVal > plan.ucl;
                          const isWarning2s = !isCritical3s && (currentVal < (plan.target - 2 * sigLower) || currentVal > (plan.target + 2 * sigUpper));
                          
                          const isAlarmEnabled = plan.enableAlarm ?? false;
                          const isFired = (isCritical3s || isWarning2s) && isAlarmEnabled;

                          return (
                            <div key={`reaction-${plan.id}`} className={`p-4 border rounded-sm transition-all text-xs space-y-3.5 ${isFired ? (isCritical3s ? 'bg-red-50/80 border-red-300' : 'bg-amber-50/80 border-amber-300') : 'bg-white/90 border-slate-200'}`}>
                              <div className="flex items-center justify-between gap-2 border-b border-dashed pb-2">
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox"
                                    id={`dash-alarm-enable-${plan.id}`}
                                    checked={isAlarmEnabled}
                                    onChange={(e) => {
                                      const updated = [...controlPlans];
                                      updated[index].enableAlarm = e.target.checked;
                                      setControlPlans(updated);
                                    }}
                                    className="w-3.5 h-3.5 accent-[#C49746] rounded-xs cursor-pointer"
                                  />
                                  <label htmlFor={`dash-alarm-enable-${plan.id}`} className="text-[10px] uppercase font-black text-slate-700 font-mono cursor-pointer select-none">
                                    {plan.stepName}
                                  </label>
                                </div>
                                <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.5 rounded-2xs ${isAlarmEnabled ? 'bg-amber-100 text-amber-950 border border-amber-200/50' : 'bg-gray-150 text-gray-500'}`}>
                                  {isAlarmEnabled ? "MONITOR LOGADO" : "MONITOR SILENCIADO"}
                                </span>
                              </div>

                              {/* Editable Reaction inputs */}
                              <div className="space-y-2">
                                <div className="text-left">
                                  <span className="block text-[7.5px] uppercase font-bold tracking-tight text-slate-400">Diretriz de Reação (Plano Operacional)</span>
                                  <input 
                                    type="text" 
                                    value={plan.reactionPlan}
                                    onChange={(e) => {
                                      const updated = [...controlPlans];
                                      updated[index].reactionPlan = e.target.value;
                                      setControlPlans(updated);
                                    }}
                                    className="w-full bg-[#FAF9F5] border border-gray-255 p-1 py-1.5 font-bold italic text-[#C49746] focus:outline-none focus:ring-1 focus:ring-[#C49746] rounded-sm text-[10.5px]"
                                  />
                                </div>

                                <div className="grid grid-cols-2 gap-2 text-[9px] text-left">
                                  <div>
                                    <span className="block text-[7.5px] uppercase font-bold tracking-tight text-slate-400">Responsável Notificado</span>
                                    <input 
                                      type="text" 
                                      value={plan.responsible}
                                      onChange={(e) => {
                                        const updated = [...controlPlans];
                                        updated[index].responsible = e.target.value;
                                        setControlPlans(updated);
                                      }}
                                      className="w-full bg-[#FAF9F5] border border-gray-255 p-1 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm text-slate-800 font-medium"
                                    />
                                  </div>
                                  <div>
                                    <span className="block text-[7.5px] uppercase font-bold tracking-tight text-slate-400">Frequência Amostral</span>
                                    <input 
                                      type="text" 
                                      value={plan.frequency}
                                      onChange={(e) => {
                                        const updated = [...controlPlans];
                                        updated[index].frequency = e.target.value;
                                        setControlPlans(updated);
                                      }}
                                      className="w-full bg-[#FAF9F5] border border-gray-255 p-1 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm text-slate-800"
                                    />
                                  </div>
                                </div>

                                {/* SEVERITY-LEVEL EMAIL NOTIFICATION CONFIGURATION */}
                                <div className="pt-2 border-t border-gray-100">
                                  <span className="block text-[8px] uppercase tracking-wider font-extrabold text-indigo-950 font-mono mb-1.5">📯 E-mails de Alerta por Severidade</span>
                                  {(() => {
                                    const isWarningEmailInvalid = plan.warningEmail && plan.warningEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(plan.warningEmail.trim());
                                    const isCriticalEmailInvalid = plan.criticalEmail && plan.criticalEmail.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(plan.criticalEmail.trim());
                                    return (
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                        <div>
                                          <span className="block text-[7.5px] uppercase font-bold text-amber-800 tracking-tight">E-mail Moderado (&gt; 2σ)</span>
                                          <input 
                                            type="email" 
                                            value={plan.warningEmail || ""}
                                            placeholder="qualidade@empresa.com"
                                            onChange={(e) => {
                                              const updated = [...controlPlans];
                                              updated[index].warningEmail = e.target.value;
                                              setControlPlans(updated);
                                            }}
                                            className={`w-full bg-[#FAF9F5] border p-1 text-[10.5px] focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-sm text-slate-700 ${isWarningEmailInvalid ? 'border-red-500 ring-1 ring-red-500' : 'border-amber-200/50'}`}
                                          />
                                          {isWarningEmailInvalid && (
                                            <span className="block text-[8px] text-red-600 font-bold mt-0.5">⚠️ E-mail inválido</span>
                                          )}
                                        </div>
                                        <div>
                                          <span className="block text-[7.5px] uppercase font-bold text-red-750 tracking-tight">E-mail Crítico (&gt; 3σ)</span>
                                          <input 
                                            type="email" 
                                            value={plan.criticalEmail || ""}
                                            placeholder="alerta.critico@empresa.com"
                                            onChange={(e) => {
                                              const updated = [...controlPlans];
                                              updated[index].criticalEmail = e.target.value;
                                              setControlPlans(updated);
                                            }}
                                            className={`w-full bg-[#FAF9F5] border p-1 text-[10.5px] focus:outline-none focus:ring-1 focus:ring-red-500 rounded-sm text-slate-700 font-bold ${isCriticalEmailInvalid ? 'border-red-500 ring-1 ring-red-500' : 'border-red-200/50'}`}
                                          />
                                          {isCriticalEmailInvalid && (
                                            <span className="block text-[8px] text-red-600 font-bold mt-0.5">⚠️ E-mail inválido</span>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })()}
                                </div>

                              </div>

                              {/* REAL-TIME ENVELOPE / SIMULATED ALERT STATUS DISPLAY */}
                              {isAlarmEnabled && (() => {
                                const smtpIsActive = localStorage.getItem("lss_smtp_enabled") === "true";
                                const smtpServerHost = localStorage.getItem("lss_smtp_host") || "smtp.empresa.com";
                                return (
                                  <div className="pt-1.5">
                                    {isCritical3s ? (
                                      <div className="bg-red-950 text-red-100 border border-red-800 text-[10px] font-mono p-2.5 rounded-sm shadow-xs space-y-1">
                                        <div className="flex items-center gap-1.5 font-bold">
                                          <span className="w-2 h-2 rounded-full bg-red-500 id-critical-bullet animate-ping"></span>
                                          <span>🚨 DISPARO CRÍTICO IMEDIATO (&gt;3σ)</span>
                                        </div>
                                        <p className="text-[9px] text-red-200 leading-tight">
                                          Vento crítico Shewhart de ±3σ violado (Leitura: {currentVal.toFixed(3)} vs faixa limite [{plan.lcl.toFixed(2)}, {plan.ucl.toFixed(2)}]).
                                        </p>
                                        <div className="bg-red-900/60 p-1.5 rounded-xs flex flex-col sm:flex-row sm:items-center justify-between text-[8px] text-red-100 gap-1 leading-normal">
                                          <div>
                                            <span>Notificação e-mail disparada para: </span>
                                            <span className="underline text-amber-300 font-extrabold">{plan.criticalEmail || "alerta.critico@empresa.com"}</span>
                                          </div>
                                          <span className={`px-1.5 py-0.2 uppercase font-black text-[7.5px] tracking-wide rounded-sm font-mono shrink-0 select-none ${
                                            smtpIsActive ? "bg-emerald-800 text-emerald-100 border border-emerald-600" : "bg-red-800 text-red-250 border border-red-700"
                                          }`}>
                                            {smtpIsActive ? `via SMTP: ${smtpServerHost}` : "via e-mail do sistema"}
                                          </span>
                                        </div>
                                      </div>
                                    ) : isWarning2s ? (
                                      <div className="bg-amber-50 text-amber-900 border border-amber-300 text-[10px] font-mono p-2.5 rounded-sm shadow-xs space-y-1">
                                        <div className="flex items-center gap-1.5 font-bold text-amber-800">
                                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                                          <span>⚠️ ALERTA PREVENTIVO MODERADO (&gt;2σ)</span>
                                        </div>
                                        <p className="text-[9px] text-amber-955 leading-tight">
                                          Desvio estatístico acima de ±2σ mas dentro de ±3σ (Leitura: {currentVal.toFixed(3)}).
                                        </p>
                                        <div className="bg-amber-100/80 p-1.5 rounded-xs flex flex-col sm:flex-row sm:items-center justify-between text-[8px] text-amber-900 gap-1 leading-normal">
                                          <div>
                                            <span>Notificação enviada para: </span>
                                            <span className="underline font-bold text-slate-800">{plan.warningEmail || "qualidade@empresa.com"}</span>
                                          </div>
                                          <span className={`px-1.5 py-0.2 uppercase font-black text-[7.5px] tracking-wide rounded-sm font-mono shrink-0 select-none ${
                                            smtpIsActive ? "bg-emerald-255 text-emerald-800 border border-emerald-300" : "bg-slate-300 text-slate-700 border-slate-400"
                                          }`}>
                                            {smtpIsActive ? `via SMTP: ${smtpServerHost}` : "via e-mail do sistema"}
                                          </span>
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="bg-emerald-50 text-emerald-900 border border-emerald-250 text-[9px] font-mono p-1.5 rounded-sm flex items-center justify-between">
                                        <span className="flex items-center gap-1.5">
                                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                          Monitoramento em tempo real ativo (Estabilidade total)
                                        </span>
                                        <span className="text-[8px] text-slate-400 italic">Pronto para reações {smtpIsActive && "via SMTP Próprio"}</span>
                                      </div>
                                    )}
                                  </div>
                                );
                              })()}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                  </div>

                  {/* INTERACTIVE SCATTER PLOT AND HISTORICAL TELEMETRY SEGMENT */}
                  <div className="border-t border-[#1A1A1A]/10 pt-4 mt-2 space-y-3">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white/40 p-2 border border-[#1A1A1A]/5 rounded-sm">
                      <div className="space-y-1">
                        <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 font-sans block">Análise de Tendência de Qualidade</span>
                        <div className="flex flex-wrap items-center gap-2">
                          <h5 className="text-[11px] font-bold text-slate-800 leading-none">
                            {cepViewMode === "snapshot" ? "Histórico de Dispersão CEP (Últimas 20 Leituras)" : "Tendência Mensal de Violações (SMA-5)"}
                          </h5>
                          <span className="bg-[#1E293B] text-white text-[8px] font-mono font-black tracking-wider px-2 py-0.5 rounded-sm uppercase shrink-0">
                            ⏱️ {cepViewMode === "snapshot" ? "Snapshot CEP: 2026-06-01 18:24:49 (UTC)" : "Período: Últimos 30 Dias"}
                          </span>
                        </div>
                      </div>

                      {/* Interactive Legend for SPC/CEP Zones */}
                      <div className="flex flex-wrap items-center gap-3 bg-white/50 px-2 py-1 border border-slate-200/45 rounded-sm text-[9px] font-sans">
                        {cepViewMode === "snapshot" ? (
                          <>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="w-2 h-2 rounded-full bg-[#10B981] inline-block border border-emerald-800"></span>
                              <span className="text-slate-600 font-bold">Estável</span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="w-2 h-2 rounded-full bg-[#F59E0B] inline-block border border-amber-800"></span>
                              <span className="text-slate-600 font-bold">Alerta (Zone 2σ)</span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="w-2 h-2 rounded-full bg-[#EF4444] inline-block border border-red-950"></span>
                              <span className="text-slate-600 font-bold">Violação (&gt;3σ)</span>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="w-3.5 h-2.5 bg-[#F59E0B]/75 inline-block border border-amber-600 rounded-2xs"></span>
                              <span className="text-slate-600 font-bold">Violações Diárias</span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="w-4 h-[2px] bg-[#EF4444] inline-block rounded-full"></span>
                              <span className="text-slate-600 font-bold">Média Móvel (MA-5)</span>
                            </div>
                          </>
                        )}
                      </div>

                      {/* Segmented View Mode Toggle */}
                      <div className="flex border border-slate-300 rounded overflow-hidden text-[9.5px] font-sans font-bold bg-white shrink-0 shadow-xs">
                        <button
                          type="button"
                          onClick={() => setCepViewMode("snapshot")}
                          className={`px-3 py-1 cursor-pointer transition-all ${cepViewMode === "snapshot" ? "bg-[#1A1A1A] text-white" : "text-gray-600 hover:bg-slate-50"}`}
                        >
                          Snapshot Atual
                        </button>
                        <button
                          type="button"
                          onClick={() => setCepViewMode("monthly")}
                          className={`px-3 py-1 cursor-pointer transition-all ${cepViewMode === "monthly" ? "bg-[#1A1A1A] text-white" : "text-gray-600 hover:bg-slate-50"}`}
                        >
                          Tendência Mensal
                        </button>
                      </div>
                      
                      {/* Monitored plan selector */}
                      {controlPlans.length > 0 && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          <label className="text-[10px] font-bold text-slate-600 font-sans shrink-0">Visualizar Etapa:</label>
                          <select 
                            value={selectedControlPlanId || (controlPlans[0] ? controlPlans[0].id : "")}
                            onChange={(e) => setSelectedControlPlanId(e.target.value)}
                            className="bg-white border border-gray-300 rounded-sm text-xs p-1 focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                          >
                            {controlPlans.map(plan => (
                              <option key={plan.id} value={plan.id}>
                                {plan.stepName} ({plan.metric})
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>

                    {controlPlans.length === 0 ? (
                      <div className="p-4 text-center text-xs text-gray-500 italic font-mono bg-white/50 border border-dashed rounded-sm">
                        Nenhum Plano de Controle ativo para monitoramento no momento. Adicione planos de controle abaixo.
                      </div>
                    ) : (() => {
                      const activePlan = controlPlans.find(p => p.id === selectedControlPlanId) || controlPlans[0];
                      if (!activePlan) return null;

                      const planLimits = getDynamicLimits(activePlan);
                      const lcl = planLimits.lcl;
                      const ucl = planLimits.ucl;
                      const target = activePlan.target;
                      const range = Math.max(0.01, ucl - lcl);
                      const currentVal = activePlan.currentReading !== undefined ? activePlan.currentReading : target;

                      // Generate 20 readings with multi-tier classifications
                      const scatterData: any[] = [];
                      const warningTolerance = 0.67; // 67% distance to limits (Zone B / 2-Sigma Boundary overlay)
                      const distUCL = ucl - target;
                      const distLCL = target - lcl;

                      for (let i = 1; i <= 20; i++) {
                        let val = target;
                        let isViolation = false;
                        let isWarning = false;
                        let sampleName = `Amostra #${i}`;

                        if (i === 20) {
                          val = currentVal;
                          sampleName = `Amostra #20 (Leitura Atual)`;
                          isViolation = val < lcl || val > ucl;
                        } else {
                          // Deterministic pseudo-randomness based on activePlan id hash
                          const hash = Math.sin(activePlan.id.charCodeAt(0) + i * 5) * 10000;
                          const fraction = hash - Math.floor(hash);
                          
                          if (i === 6) {
                            val = ucl + range * 0.12; // Out of bounds high
                            isViolation = true;
                          } else if (i === 14) {
                            val = lcl - range * 0.12; // Out of bounds low
                            isViolation = true;
                          } else {
                            val = target + (fraction - 0.5) * (range * 0.8);
                            isViolation = val < lcl || val > ucl;
                          }
                        }

                        // Determine if warning (Zone B threshold exceeded)
                        if (!isViolation) {
                          const deviationPercentage = val > target ? (val - target) / (distUCL || 1) : (target - val) / (distLCL || 1);
                          if (deviationPercentage > warningTolerance) {
                            isWarning = true;
                          }
                        }

                        let statusLabel = "Estável (Zona C)";
                        let fillCol = "#10B981"; // Emerald green
                        if (isViolation) {
                          statusLabel = "Violação Crítica (&gt;3σ)";
                          fillCol = "#EF4444"; // Vivid red
                        } else if (isWarning) {
                          statusLabel = "Alerta Preventivo (Zona B)";
                          fillCol = "#F59E0B"; // Vivid amber
                        }

                        scatterData.push({
                          index: i,
                          sample: sampleName,
                          value: Number(val.toFixed(3)),
                          isViolation,
                          isWarning,
                          fill: fillCol,
                          status: statusLabel
                        });
                      }

                      const recentViolations = scatterData.filter(d => d.isViolation).length;
                      const recentWarnings = scatterData.filter(d => d.isWarning).length;

                      // Generate 30 days of monthly trend data
                      const monthlyTrendData: any[] = [];
                      const activePlanIdSeed = activePlan.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                      
                      for (let day = 1; day <= 30; day++) {
                        const sineVal = Math.sin((activePlanIdSeed + day) * 0.4);
                        const cosVal = Math.cos((activePlanIdSeed * 1.5 + day) * 0.25);
                        const baseViolationCount = (activePlan.currentReading !== undefined && (activePlan.currentReading < lcl || activePlan.currentReading > ucl)) ? 1.6 : 0.6;
                        const randomFactor = Math.abs(sineVal * 1.6 + cosVal * 0.8);
                        const violations = Math.max(0, Math.round(baseViolationCount + randomFactor));
                        
                        monthlyTrendData.push({
                          day: `${day}/05`,
                          dayNum: day,
                          violations: violations,
                        });
                      }
                      
                      monthlyTrendData.forEach((item, index) => {
                        let sum = 0;
                        let count = 0;
                        const start = Math.max(0, index - 4);
                        for (let i = start; i <= index; i++) {
                          sum += monthlyTrendData[i].violations;
                          count++;
                        }
                        item.movingAverage = parseFloat((sum / count).toFixed(2));
                      });

                      const totalMonthlyViolations = monthlyTrendData.reduce((acc, d) => acc + d.violations, 0);
                      const avgMonthlyViolations = parseFloat((totalMonthlyViolations / 30).toFixed(2));
                      const maxViolationsInSingleDay = Math.max(...monthlyTrendData.map(d => d.violations));
                      
                      const lastMA = monthlyTrendData[29]?.movingAverage || 0;
                      const initialMA = monthlyTrendData[10]?.movingAverage || 0;
                      const trendStatus = lastMA < initialMA ? "Melhoria Contínua" : lastMA > initialMA ? "Desvio Crescente" : "Estável";
                      const trendColor = lastMA < initialMA ? "text-emerald-700 bg-emerald-50 border-emerald-100" : lastMA > initialMA ? "text-red-700 bg-red-50 border-red-100" : "text-amber-700 bg-amber-50 border-amber-100";

                      // Dynamic Pareto causes calculated from the reactive alertEvents history
                      const getParetoDataFromHistory = () => {
                        const causeCounts: Record<string, { count: number, explanation: string }> = {
                          "Descalibração de Sensores": { count: 3, explanation: "Sensores eletromecânicos ou ópticos de medição dessincronizados" },
                          "Matéria-Prima Inadequada": { count: 2, explanation: "Variação na densidade, pureza ou liga química do lote de insumos" },
                          "Desgaste de Ferramental": { count: 2, explanation: "Fresas, moldes físicos ou bicos de extrusão desgastados por atrito" },
                          "Erro Operacional de Setup": { count: 2, explanation: "Operador configurou parâmetros de velocidade ou de temperatura errados" },
                          "Flutuação de Pressão/Ar": { count: 1, explanation: "Compressor pneumático falhando em manter o vácuo ou pressão nominal" },
                          "Histerese Térmica Ativa": { count: 0, explanation: "Demora no tempo de resposta do aquecedor acarretando variação de calor" },
                          "Acúmulo de Resíduos": { count: 0, explanation: "Sujeira ou cavacos físicos obstruindo passagens mecânicas" }
                        };

                        // Aggregate counts from active state
                        alertEvents.forEach(evt => {
                          const causeName = evt.cause;
                          if (causeCounts[causeName]) {
                            causeCounts[causeName].count += 1;
                          } else {
                            causeCounts[causeName] = { count: 1, explanation: evt.explanation || "Causalidade identificada em tempo real." };
                          }
                        });

                        // Convert to array and sort descending
                        const sortedList = Object.entries(causeCounts).map(([cause, info]) => {
                          return {
                            cause,
                            count: info.count,
                            explanation: info.explanation
                          };
                        }).sort((a, b) => b.count - a.count);

                        // Take top 5
                        const top5 = sortedList.slice(0, 5);
                        const total = top5.reduce((sum, item) => sum + item.count, 0);

                        let cum = 0;
                        const dataWithPercentage = top5.map(item => {
                          cum += item.count;
                          const percentage = total > 0 ? (cum / total) * 100 : 0;
                          return {
                            cause: item.cause,
                            count: item.count,
                            explanation: item.explanation,
                            percentage: parseFloat(percentage.toFixed(1))
                          };
                        });

                        return {
                          chartData: dataWithPercentage,
                          totalCount: total
                        };
                      };

                      const { chartData: paretoChartData, totalCount: totalParetoCount } = getParetoDataFromHistory();
                      
                      // Generate 30 days of 3 samples each for the historical scatter plot (90 points total)
                      const historicalScatterPoints: any[] = [];
                      const planIdSeed = activePlan.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                      for (let d = 1; d <= 30; d++) {
                        for (let s = 1; s <= 3; s++) {
                          const sinSeed = Math.sin(planIdSeed + d * 7 + s * 13) * 10000;
                          const fraction = sinSeed - Math.floor(sinSeed);
                          
                          let val = target;
                          let isViolation = false;
                          
                          if (d === 6 && s === 2) {
                            val = ucl + range * 0.14;
                            isViolation = true;
                          } else if (d === 14 && s === 1) {
                            val = lcl - range * 0.14;
                            isViolation = true;
                          } else if (d === 22 && s === 3) {
                            val = ucl + range * 0.08;
                            isViolation = true;
                          } else {
                            const amplitude = fraction > 0.88 ? 1.05 : 0.65;
                            val = target + (fraction - 0.5) * (range * amplitude);
                            isViolation = val < lcl || val > ucl;
                          }

                          const distUCL = ucl - target;
                          const distLCL = target - lcl;
                          const isWarning = !isViolation && (val > target ? (val - target) / (distUCL || 1) : (target - val) / (distLCL || 1)) > 0.67;
                          
                          let statusLabel = "Sob Controle (±2σ)";
                          let fillCol = "#10B981";
                          if (isViolation) {
                            statusLabel = "Violação Crítica (>3σ)";
                            fillCol = "#EF4444";
                          } else if (isWarning) {
                            statusLabel = "Alerta Preventivo (Zona B)";
                            fillCol = "#F59E0B";
                          }

                          historicalScatterPoints.push({
                            day: d,
                            sample: `Amostra #${s} (Dia ${d}/05)`,
                            value: Number(val.toFixed(3)),
                            fill: fillCol,
                            isViolation,
                            isWarning,
                            status: statusLabel
                          });
                        }
                      }

                      return (
                        <div className="space-y-4">
                          {/* Row 1: Info Panel & Interactive Shewhart SPC Chart */}
                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
                            {/* Info panel */}
                            <div className="lg:col-span-4 bg-white/60 p-3 border border-[#1A1A1A]/5 rounded-sm flex flex-col justify-between text-xs space-y-3 font-sans">
                              {cepViewMode === "snapshot" ? (
                                <div className="space-y-1.5">
                                  <div>
                                    <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Etapa Selecionada</span>
                                    <strong className="text-slate-900 font-serif text-[13px]">{activePlan.stepName}</strong>
                                  </div>
                                  <div>
                                    <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Parâmetro Monitorado</span>
                                    <span className="text-slate-700 font-mono text-[11px] block">{activePlan.metric}</span>
                                  </div>
                                  <div className="grid grid-cols-3 gap-1 pt-1.5 border-t border-slate-200">
                                    <div className="text-center bg-red-50 p-1 border border-red-100 rounded-sm">
                                      <span className="text-[8px] text-red-700 uppercase font-black block">LCL (Dyn)</span>
                                      <span className="font-mono font-bold text-[10px] text-red-900">{lcl.toFixed(3)}</span>
                                    </div>
                                    <div className="text-center bg-blue-50 p-1 border border-blue-100 rounded-sm">
                                      <span className="text-[8px] text-blue-700 uppercase font-black block">Meta</span>
                                      <span className="font-mono font-bold text-[10px] text-blue-900">{target.toFixed(3)}</span>
                                    </div>
                                    <div className="text-center bg-red-50 p-1 border border-red-100 rounded-sm">
                                      <span className="text-[8px] text-red-700 uppercase font-black block">UCL (Dyn)</span>
                                      <span className="font-mono font-bold text-[10px] text-red-900">{ucl.toFixed(3)}</span>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="space-y-1.5">
                                  <div>
                                    <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Visão de Tendência Ativa</span>
                                    <strong className="text-slate-900 font-serif text-[13px]">{activePlan.stepName}</strong>
                                  </div>
                                  <div>
                                    <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Parâmetro Histórico</span>
                                    <span className="text-slate-700 font-mono text-[11px] block">{activePlan.metric}</span>
                                  </div>
                                  <div className="pt-1.5 border-t border-slate-200">
                                    <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Janela Analítica</span>
                                    <div className="flex items-center justify-between text-[11px] mt-0.5 font-mono text-slate-850">
                                      <span>Dias Monitorados:</span>
                                      <span className="font-bold">30 dias</span>
                                    </div>
                                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-850">
                                      <span>Filtro Média Móvel:</span>
                                      <span className="font-bold text-indigo-700">SMA-5 (Suave)</span>
                                    </div>
                                  </div>
                                </div>
                              )}

                              <div className="space-y-1.5 bg-[#FAF9F6]/50 p-2 border border-slate-200/60 rounded-xs">
                                {cepViewMode === "snapshot" ? (
                                  <>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600">Leitura Atual (Nº 20):</span>
                                      <span className={`font-mono font-bold text-xs ${currentVal < lcl || currentVal > ucl ? 'text-red-650' : 'text-emerald-700'}`}>
                                        {currentVal.toFixed(3)}
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600 font-sans">Violações de Limite:</span>
                                      <span className={`font-mono font-bold text-xs ${recentViolations > 0 ? 'text-red-650 font-black' : 'text-emerald-700'}`}>
                                        {recentViolations} de 20
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600 font-sans">Alertas Zona 2σ:</span>
                                      <span className={`font-mono font-bold text-xs ${recentWarnings > 0 ? 'text-amber-600' : 'text-emerald-700'}`}>
                                        {recentWarnings} de 20
                                      </span>
                                    </div>
                                  </>
                                ) : (
                                  <>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600">Total Violações:</span>
                                      <span className="font-mono font-bold text-xs text-red-650">
                                        {totalMonthlyViolations} eventos
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600">Média de Violações:</span>
                                      <span className="font-mono font-bold text-xs text-[#C49746]">
                                        {avgMonthlyViolations}/dia
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[9px] uppercase font-bold text-slate-600">Pico de Ocorrência:</span>
                                      <span className="font-mono font-bold text-xs text-red-800">
                                        {maxViolationsInSingleDay} num dia
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/50">
                                      <span className="text-[9px] uppercase font-bold text-slate-600">Tendência SPC:</span>
                                      <span className={`font-mono font-bold text-[10px] px-1.5 py-0.5 rounded-2xs border ${trendColor}`}>
                                        {trendStatus.toUpperCase()}
                                      </span>
                                    </div>
                                  </>
                                )}
                                <div className="text-[9.5px] leading-relaxed text-slate-600 pt-1 border-t border-dashed border-slate-200">
                                  <strong>Reação:</strong> <span className="italic">{activePlan.reactionPlan || "Nenhuma ação definida."}</span>
                                </div>
                              </div>
                            </div>

                            {/* Scatter Plot or Monthly Trend Chart */}
                            <div className="lg:col-span-8 bg-white p-3 border border-slate-150 rounded-sm h-[220px]">
                              {cepViewMode === "snapshot" ? (
                                <ResponsiveContainer width="100%" height="100%">
                                  <ScatterChart margin={{ top: 10, right: 10, bottom: -5, left: -25 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                                    <XAxis 
                                      type="number" 
                                      dataKey="index" 
                                      name="Amostra" 
                                      domain={[1, 20]}
                                      tickCount={20}
                                      tick={{ fontSize: 8, fill: "#64748B" }}
                                      axisLine={{ stroke: "#E2E8F0" }}
                                      tickLine={false}
                                    />
                                    <YAxis 
                                      type="number" 
                                      dataKey="value" 
                                      name="Leitura" 
                                      domain={[lcl - range * 0.3, ucl + range * 0.3]}
                                      tick={{ fontSize: 8, fill: "#64748B" }}
                                      axisLine={{ stroke: "#E2E8F0" }}
                                      tickLine={false}
                                    />
                                    <ZAxis type="number" range={[65, 65]} />
                                    <Tooltip
                                      cursor={{ strokeDasharray: '3 3', stroke: '#94A3B8' }}
                                      content={({ active, payload }) => {
                                        if (active && payload && payload.length) {
                                          const d = payload[0].payload;
                                          return (
                                            <div className="bg-white border border-gray-200 p-2 shadow-sm rounded-none text-[10px] font-mono space-y-0.5">
                                              <p className="font-sans font-bold text-slate-900 border-b pb-0.5 mb-1">{d.sample}</p>
                                              <p className="font-sans text-slate-600">Valor: <strong className="font-mono text-slate-900">{d.value}</strong></p>
                                              <p className="font-sans text-slate-600">Status: <strong style={{ color: d.fill }}>{d.status}</strong></p>
                                            </div>
                                          );
                                        }
                                        return null;
                                      }}
                                    />
                                    <ReferenceLine y={target} stroke="#3B82F6" strokeDasharray="3 3" label={{ value: `Meta: ${target.toFixed(2)}`, position: "insideLeft", fill: "#3B82F6", fontSize: 7, fontWeight: "bold" }} />
                                    <ReferenceLine y={ucl} stroke="#EF4444" strokeDasharray="4 4" label={{ value: `UCL: ${ucl.toFixed(2)}`, position: "insideLeft", fill: "#EF4444", fontSize: 7, fontWeight: "bold" }} />
                                    <ReferenceLine y={lcl} stroke="#EF4444" strokeDasharray="4 4" label={{ value: `LCL: ${lcl.toFixed(2)}`, position: "insideLeft", fill: "#EF4444", fontSize: 7, fontWeight: "bold" }} />
                                    <Scatter name="Leituras" data={scatterData}>
                                      {scatterData.map((entry, idx) => (
                                        <Cell 
                                          key={`cell-${idx}`} 
                                          fill={entry.fill} 
                                          stroke={entry.isViolation ? '#7F1D1D' : entry.isWarning ? '#78350F' : '#047857'} 
                                          strokeWidth={1.5}
                                          style={{ filter: entry.isViolation ? 'drop-shadow(0 0 3px rgba(239,68,68,0.5))' : entry.isWarning ? 'drop-shadow(0 0 2px rgba(245,158,11,0.4))' : 'none' }}
                                        />
                                      ))}
                                    </Scatter>
                                  </ScatterChart>
                                </ResponsiveContainer>
                              ) : (
                                <ResponsiveContainer width="100%" height="100%">
                                  <ComposedChart data={monthlyTrendData} margin={{ top: 10, right: 10, bottom: -5, left: -25 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                                    <XAxis 
                                      dataKey="day" 
                                      tick={{ fontSize: 8, fill: "#64748B" }}
                                      axisLine={{ stroke: "#E2E8F0" }}
                                      tickLine={false}
                                    />
                                    <YAxis 
                                      tick={{ fontSize: 8, fill: "#64748B" }}
                                      axisLine={{ stroke: "#E2E8F0" }}
                                      tickLine={false}
                                      label={{ value: 'Quantidade de Violações', angle: -90, position: 'insideLeft', offset: 10, fontSize: 8, fill: '#64748B' }}
                                    />
                                    <Tooltip
                                      content={({ active, payload }) => {
                                        if (active && payload && payload.length) {
                                          const d = payload[0].payload;
                                          return (
                                            <div className="bg-white border border-gray-200 p-2 shadow-sm rounded-none text-[10px] font-mono space-y-1">
                                              <p className="font-sans font-bold text-slate-900 border-b pb-0.5 mb-1">Dia: {d.day}</p>
                                              <p className="font-sans text-slate-600">Violações Diárias: <strong className="font-mono text-[#F59E0B]">{d.violations}</strong></p>
                                              <p className="font-sans text-slate-600">Média Móvel (5 Dias): <strong className="font-mono text-[#EF4444]">{d.movingAverage}</strong></p>
                                            </div>
                                          );
                                        }
                                        return null;
                                      }}
                                    />
                                    <Bar dataKey="violations" name="Violações Diárias" fill="#F59E0B" fillOpacity={0.65} barSize={12} radius={[2, 2, 0, 0]} />
                                    <Line type="monotone" dataKey="movingAverage" name="Média Móvel (5 d)" stroke="#EF4444" strokeWidth={2.5} dot={{ r: 2, stroke: '#B91C1C', strokeWidth: 1 }} activeDot={{ r: 4 }} />
                                  </ComposedChart>
                                </ResponsiveContainer>
                              )}
                            </div>
                          </div>

                          {/* Row 2: PARETO ANALYSIS DE CAUSA-RAIZ BELOW THE SCATTER PLOT */}
                          <ParetoControle
                            alertEvents={alertEvents}
                            activeStepName={activePlan.stepName}
                            onAddSimulatedEvent={() => {
                              const causes = [
                                { cause: "Descalibração de Sensores", explanation: "Sensores ópticos de laser 3D perderam a focalização mecânica" },
                                { cause: "Matéria-Prima Inadequada", explanation: "Solda com contaminação química de óxidos no bico do forno" },
                                { cause: "Desgaste de Ferramental", explanation: "Engrenagem da esteira de roletes com desgaste por tração repetida" },
                                { cause: "Erro Operacional de Setup", explanation: "Parâmetro incorreto linear na esteira de montagem eletrônica" },
                                { cause: "Flutuação de Pressão/Ar", explanation: "Perda imediata de fluxo de vácuo no bico de sucção pneumática" },
                                { cause: "Histerese Térmica Ativa", explanation: "Tempo de resfriamento estendido por flutuação térmica mecânica" },
                                { cause: "Acúmulo de Resíduos", explanation: "Cavacos de corte ou excesso de lubrificante acumulados obstruindo dutos" }
                              ];
                              const randCause = causes[Math.floor(Math.random() * causes.length)];
                              const stepsList = ["AOI Inspeção", "Montagem Mecânica", "Cura UV", "Soldagem Seletiva"];
                              const randStep = stepsList[Math.floor(Math.random() * stepsList.length)];
                              
                              const newEvent = {
                                id: `ev-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                                stepName: randStep,
                                metric: "Simulação de Campo",
                                value: parseFloat((Math.random() * 4 + 6).toFixed(2)),
                                limitCrossed: Math.random() > 0.5 ? "UCL" : "LCL",
                                limitValue: 5.0,
                                cause: randCause.cause,
                                explanation: randCause.explanation,
                                severity: "high"
                              };
                              setAlertEvents(prev => [newEvent, ...prev]);
                              triggerFlash("⚡ Alerta simulado adicionado com sucesso! Gráfico de Pareto atualizado.");
                            }}
                            onClearEvents={() => {
                              setAlertEvents([]);
                              triggerFlash("🧹 Histórico de incidentes do lote limpo! Pareto de desvios redefinido.");
                            }}
                            triggerFlash={triggerFlash}
                          />

                          {/* Dynamic SPC Log History panel */}
                          <div id="control-alert-logs-block" className="bg-[#FAF9F6]/50 border border-slate-200/60 p-3 rounded-sm space-y-2 mt-3 font-mono text-[10px]">
                            <div className="flex justify-between items-center border-b border-slate-200 pb-1.5 font-sans">
                              <span className="font-bold uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
                                Log de Violacoes Recentes / Historico SPC
                              </span>
                              <span className="text-[9px] text-[#C49746] font-mono font-bold uppercase">
                                Ativos na Fila: {alertEvents.length}
                              </span>
                            </div>
                            
                            {alertEvents.length === 0 ? (
                              <div className="p-3 text-center text-slate-400 italic font-mono bg-white/30 border border-dashed rounded-xs text-[9px]">
                                Sistema estável. Nenhuma violação ativa registrada no lote.
                              </div>
                            ) : (
                              <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1 font-mono font-bold">
                                {alertEvents.slice(0, 5).map((evt) => (
                                  <div key={evt.id} className="bg-white border border-slate-100 p-2 rounded-xs flex flex-col md:flex-row md:items-center justify-between gap-1.5 text-[9.5px] leading-relaxed transition-all hover:bg-slate-50">
                                    <div className="space-y-0.5 animate-fade-in text-left">
                                      <div className="flex flex-wrap items-center gap-1.5">
                                        <span className="text-[8.5px] bg-slate-100 text-slate-655 px-1 py-0.2 rounded-2xs font-bold font-mono">{evt.timestamp}</span>
                                        <span className="text-slate-800 font-bold font-sans">{evt.stepName}</span>
                                        <span className="text-slate-500 font-sans">— {evt.metric}</span>
                                      </div>
                                      <p className="text-slate-600 font-sans text-[9px]">
                                        Causa Estimada: <strong className="text-[#C49746]">{evt.cause}</strong>. <span>{evt.explanation}</span>
                                      </p>
                                    </div>
                                    <div className="shrink-0 flex items-center gap-1.5 font-mono">
                                      <span className="bg-red-50 text-red-700 border border-red-100 font-bold px-1.5 py-0.5 rounded-2xs text-[8.5px]">
                                        {evt.limitCrossed} violado ({evt.value} vs lim {evt.limitValue})
                                      </span>
                                    </div>
                                  </div>
                                ))}
                                {alertEvents.length > 5 && (
                                  <div className="text-[8.5px] text-center text-slate-400 font-sans pt-1">
                                    Exibindo os 5 eventos mais recentes de {alertEvents.length} no lote de SPC.
                                  </div>
                                )}
                              </div>
                            )}
                          </div>

                          {/* HISTORICAL PROCESS DEVIATION SCATTER PLOT - LAST 30 DAYS */}
                          <div id="control-historical-scatter-container" className="bg-white border border-[#1A1A1A]/10 p-5 rounded-sm space-y-4 mt-4 font-sans text-[#1A1A1A]">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-150 pb-2.5 gap-2">
                              <div className="text-left">
                                <span className="text-[9px] uppercase font-bold text-amber-600 tracking-wider font-mono block">
                                  📊 CONTROLE DE QUALIDADE ACUMULADO • CEP 30 DIAS
                                </span>
                                <h4 className="text-xs font-bold text-slate-800 leading-tight">
                                  Dispersão Histórica de Desvios — Etapa: <span className="text-[#C49746] font-serif pr-1">{activePlan.stepName}</span> ({activePlan.metric})
                                </h4>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0 bg-slate-50 border border-slate-200 px-2 py-1 text-[9px] font-mono text-slate-500 rounded-2xs">
                                <span>Janela Analítica: <strong className="text-slate-800">Últimos 30 Dias</strong></span>
                                <span>•</span>
                                <span>Amostras Totais: <strong className="text-slate-800">90 leituras (3/dia)</strong></span>
                              </div>
                            </div>

                            <p className="text-[11px] text-slate-600 leading-relaxed font-sans text-left">
                              O gráfico abaixo apresenta a dispersão de todas as amostras registradas ao longo dos últimos 30 dias na etapa selecionada. Cada ponto representa uma medição individual do parâmetro crítico de qualidade (CTQ) (<strong className="text-slate-800">{activePlan.metric}</strong>), permitindo identificar visualmente anomalias de centralização de processo, aproximações perigosas das faixas de alerta ou violações críticas fora dos limites Shewhart de UCL/LCL (<strong className="text-red-655 font-bold">±3 Sigma</strong>).
                            </p>

                            <div className="h-[240px] w-full bg-white border border-slate-150 rounded-xs p-2">
                              <ResponsiveContainer width="100%" height="100%">
                                <ScatterChart margin={{ top: 15, right: 20, bottom: 5, left: -25 }}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                                  <XAxis 
                                    type="number" 
                                    dataKey="day" 
                                    name="Dia do Mês" 
                                    domain={[1, 30]} 
                                    tickCount={15} 
                                    tickFormatter={(v) => `D${v}`}
                                    tick={{ fontSize: 8, fill: "#64748B" }}
                                    axisLine={{ stroke: "#E2E8F0" }}
                                    tickLine={false}
                                  />
                                  <YAxis 
                                    type="number" 
                                    dataKey="value" 
                                    name="Leitura" 
                                    domain={[lcl - range * 0.35, ucl + range * 0.35]}
                                    tick={{ fontSize: 8, fill: "#64748B" }}
                                    axisLine={{ stroke: "#E2E8F0" }}
                                    tickLine={false}
                                  />
                                  <ZAxis type="number" range={[45, 45]} />
                                  <Tooltip 
                                    cursor={{ strokeDasharray: '3 3', stroke: '#94A3B8' }}
                                    content={({ active, payload }) => {
                                      if (active && payload && payload.length) {
                                        const d = payload[0].payload;
                                        return (
                                          <div className="bg-[#1A1A1A] text-white border border-gray-800 p-2.5 text-[10px] font-mono space-y-1 rounded-xs shadow-md text-left max-w-[215px]">
                                            <p className="font-sans font-bold text-amber-300 border-b border-white/20 pb-0.5 mb-1">{d.sample}</p>
                                            <p className="font-sans text-slate-300">Valor Medido: <strong className="font-mono text-white">{d.value}</strong></p>
                                            <p className="font-sans text-slate-300">Status CEP: <strong style={{ color: d.fill }}>{d.status}</strong></p>
                                          </div>
                                        );
                                      }
                                      return null;
                                    }}
                                  />
                                  <ReferenceLine y={target} stroke="#3B82F6" strokeDasharray="3 3" label={{ value: `Meta: ${target.toFixed(2)}`, position: "insideLeft", fill: "#3B82F6", fontSize: 7, fontWeight: "bold" }} />
                                  <ReferenceLine y={ucl} stroke="#EF4444" strokeDasharray="4 4" label={{ value: `UCL: ${ucl.toFixed(2)}`, position: "insideLeft", fill: "#EF4444", fontSize: 7, fontWeight: "bold" }} />
                                  <ReferenceLine y={lcl} stroke="#EF4444" strokeDasharray="4 4" label={{ value: `LCL: ${lcl.toFixed(2)}`, position: "insideLeft", fill: "#EF4444", fontSize: 7, fontWeight: "bold" }} />
                                  
                                  <Scatter name="Leituras Históricas" data={historicalScatterPoints}>
                                    {historicalScatterPoints.map((entry, idx) => (
                                      <Cell 
                                        key={`cell-hist-${idx}`} 
                                        fill={entry.fill}
                                        stroke={entry.isViolation ? '#7F1D1D' : entry.isWarning ? '#78350F' : '#047857'} 
                                        strokeWidth={1}
                                        style={{ filter: entry.isViolation ? 'drop-shadow(0 0 3px rgba(239,68,68,0.45))' : entry.isWarning ? 'drop-shadow(0 0 2px rgba(245,158,11,0.35))' : 'none' }}
                                      />
                                    ))}
                                  </Scatter>
                                </ScatterChart>
                              </ResponsiveContainer>
                            </div>

                            {/* Legend / Metrics summary footer */}
                            <div className="flex flex-wrap items-center justify-between text-[9px] text-slate-500 font-mono pt-1.5 border-t border-slate-100 gap-2">
                              <div className="flex flex-wrap items-center gap-4">
                                <div className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] inline-block border border-emerald-800"></span>
                                  <span className="text-slate-600 font-bold">Instabilidade Natural (±2σ)</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B] inline-block border border-amber-800"></span>
                                  <span className="text-slate-600 font-bold">Zona de Alerta Preventivo (2σ a 3σ)</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444] inline-block border border-red-950 animate-pulse"></span>
                                  <span className="text-slate-600 font-bold">Violação Crítica (&gt;3σ)</span>
                                </div>
                              </div>
                              <span className="text-slate-450 uppercase font-bold text-[8.5px] font-sans">
                                PROTOCOLO DE PREPARO CEP • SHEWHART STATS
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                </div>
                
                {/* Visual Intro row */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  <div className="lg:col-span-8 space-y-6">
                    <div className="border-t border-[#1A1A1A] pt-4">
                      <p className="text-[10px] font-bold text-[#C49746] uppercase tracking-widest mb-1">05 / Fase CONTROL</p>
                      <h2 className="text-3xl font-serif tracking-tight pr-4">Plano de Controle Estatístico de Processo (SPC)</h2>
                    </div>

                    <p className="text-xs text-[#1A1A1A]/75 leading-relaxed">
                      Para que as melhorias implementadas na fase <strong>Improve</strong> perpetuem, é imperioso estabelecer um Plano de Controle e cartas estatísticas de CQ. As cartas Shewhart monitoram desvios padrões fora dos limites calculados para cessar flutuações.
                    </p>

                    {/* GLOBAL ALARM SENSITIVITY CONFIGURATION */}
                    <div id="alarm-sensitivity-box" className="p-4 bg-[#F2ECE4] border border-[#1A1A1A]/10 rounded-sm space-y-2.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="space-y-0.5">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-[#C49746] flex items-center gap-1.5 font-sans">
                            Configuração de Sensibilidade dos Alarmes CEP (Shewhart σ)
                          </h4>
                          <p className="text-[10px] text-gray-600 leading-normal max-w-xl">
                            Ajuste o número de desvios-padrão (multiplicador Sigma) para contrair ou expandir as margens de disparo do alarme. Uma sensibilidade menor (ex: 2.0σ) torna os alertas rígidos e frequentes; uma sensibilidade maior (ex: 4.5σ) confere tolerância para regimes de alta variabilidade inerente.
                          </p>
                        </div>
                        <div className="flex items-center gap-2 bg-white border border-[#1A1A1A]/10 px-2.5 py-1.5 shadow-2xs shrink-0">
                          <label htmlFor="alarm-sigma-sensitivity-input" className="text-[9px] uppercase font-bold text-[#1A1A1A]/70 shrink-0 select-none">Multiplicador (Sigma):</label>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              id="alarm-sigma-sensitivity-input"
                              step="0.1"
                              min="0.5"
                              max="6.0"
                              value={alarmSigmaSensitivity}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                setAlarmSigmaSensitivity(isNaN(val) ? 3.0 : Math.max(0.1, val));
                              }}
                              className="w-14 text-center font-mono text-xs font-bold text-[#C49746] focus:outline-none bg-transparent"
                            />
                            <span className="text-[10px] font-bold text-[#C49746] font-mono">σ</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* DYNAMIC CONTROL PLAN LIST EDITORS */}
                    <div className="border border-[#1A1A1A]/15 bg-[#F5F2ED] p-6 rounded-sm space-y-4">
                      <div className="flex justify-between items-center border-b border-[#1A1A1A]/10 pb-2">
                        <h4 className="text-xs font-bold uppercase tracking-widest">Matriz de Monitoramento CEP / CEP (Control Plan)</h4>
                        <div className="flex items-center gap-2">
                          <button
                            id="autocalibrate-bottleneck-control-plan"
                            onClick={handleAutoAddBottleneckControlPlan}
                            className="bg-indigo-600 hover:bg-indigo-750 text-white text-[9px] uppercase tracking-wider font-extrabold p-1.5 px-3 flex items-center gap-1 cursor-pointer transition-all"
                            title="Auto-detecta o gargalo do sistema e adiciona uma linha de controle estatístico (SPC) com limites LCL/UCL calculados por desvio padrão."
                          >
                            ⚡ Auto-Calibrar Gargalo (SPC)
                          </button>
                          <button
                            id="add-control-plan-row"
                            onClick={() => {
                              const newPlan: ControlPlan = {
                                id: `cp-${Date.now()}`,
                                stepName: "Nova Etapa Monitorada",
                                metric: "Defeitos visuais amostrados",
                                lcl: 0,
                                ucl: 10,
                                target: 2,
                                frequency: "Por turno produtivo",
                                responsible: "Supervisor de Linha",
                                reactionPlan: "Alertar engenharia de processos e recomeçar calibração dos bicos.",
                                currentReading: 2,
                                enableAlarm: true,
                              };
                              setControlPlans([...controlPlans, newPlan]);
                            }}
                            className="bg-[#1A1A1A] hover:bg-black text-white text-[9px] uppercase tracking-wider font-bold p-1.5 px-3 cursor-pointer"
                          >
                            + Nova Linha de Controle
                          </button>
                        </div>
                      </div>

                      {/* QUICK SUGGESTION ASSISTANT FOR SIX SIGMA */}
                      <div className="p-3.5 bg-white border border-[#1A1A1A]/10 rounded-sm text-[10.5px] leading-relaxed text-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-3 font-sans">
                        <div className="space-y-0.5 text-left">
                          <p className="font-bold text-slate-900 flex items-center gap-1.5 text-xs text-indigo-700">
                            🤖 Assistente de Capabilidade & CEP (Controle de Gargalos)
                          </p>
                          <p className="text-xs text-gray-600">
                            O posto gargalo atual <strong className="text-red-600">{stats.bottleneckStepName}</strong> opera com desvio padrão de <strong>{(steps.find(s => s.name === stats.bottleneckStepName)?.standardDeviation ?? 0.0).toFixed(2)} min</strong>. Deseja registrar este gargalo no Plano de Controle com limites estocásticos de Controle Estatístico de Processo (SPC) calculados automaticamente?
                          </p>
                        </div>
                        <button
                          onClick={handleAutoAddBottleneckControlPlan}
                          className="px-3.5 py-1.5 md:ml-auto text-[9.5px] uppercase font-mono font-bold bg-[#1A1A1A] text-white hover:bg-black transition-all shrink-0 border border-transparent rounded-sm cursor-pointer"
                        >
                          Calcular & Gerar Limites
                        </button>
                      </div>

                      <div className="space-y-4">
                        {controlPlans.map((plan, index) => (
                          <div key={plan.id} className="bg-white border p-4 space-y-3 relative">
                            <button
                              id={`delete-control-${plan.id}`}
                              onClick={() => {
                                setControlPlans(controlPlans.filter((p) => p.id !== plan.id));
                              }}
                              className="absolute top-3 right-3 text-red-600 hover:text-red-800"
                              title="Deletar plano"
                            >
                              <Trash2 size={12} />
                            </button>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                              <div>
                                <label className="block text-[8px] uppercase font-bold text-[#1A1A1A]/50">Etapa Crítica do Processo</label>
                                <input
                                  type="text"
                                  value={plan.stepName}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].stepName = e.target.value;
                                    setControlPlans(updated);
                                  }}
                                  className="w-full bg-transparent font-serif font-bold text-xs border-b border-[#1A1A1A]/10 focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="block text-[8px] uppercase font-bold text-[#1A1A1A]/50">Métrica CEP (Ex: FPP)</label>
                                <input
                                  type="text"
                                  value={plan.metric}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].metric = e.target.value;
                                    setControlPlans(updated);
                                  }}
                                  className="w-full bg-transparent text-xs border-b border-[#1A1A1A]/10 focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="block text-[8px] uppercase font-bold text-[#1A1A1A]/50 font-sans">Responsável pela Medição</label>
                                <input
                                  type="text"
                                  value={plan.responsible}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].responsible = e.target.value;
                                    setControlPlans(updated);
                                  }}
                                  className="w-full bg-transparent text-xs border-b border-[#1A1A1A]/10 focus:outline-none"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-[10px] pt-1.5 border-t border-[#1A1A1A]/5">
                              <div>
                                <label className="block text-[7px] uppercase font-bold text-[#1A1A1A]/50">LCL Base (3σ)</label>
                                <input
                                  type="number"
                                  step="0.01"
                                  value={plan.lcl}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].lcl = parseFloat(e.target.value) || 0;
                                    setControlPlans(updated);
                                  }}
                                  className="w-16 bg-transparent font-mono focus:outline-none"
                                />
                                <div className="text-[7.5px] text-[#C49746] font-mono mt-0.5 font-bold">
                                  Destaque: {getDynamicLimits(plan).lcl.toFixed(3)} ({alarmSigmaSensitivity.toFixed(1)}σ)
                                </div>
                              </div>
                              <div>
                                <label className="block text-[7px] uppercase font-bold text-[#1A1A1A]/50 font-sans">Média Alvo (Target)</label>
                                <input
                                  type="number"
                                  step="0.01"
                                  value={plan.target}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].target = parseFloat(e.target.value) || 0;
                                    setControlPlans(updated);
                                  }}
                                  className="w-16 bg-transparent font-mono focus:outline-none font-bold"
                                />
                              </div>
                              <div>
                                <label className="block text-[7px] uppercase font-bold text-[#1A1A1A]/50">UCL Base (3σ)</label>
                                <input
                                  type="number"
                                  step="0.01"
                                  value={plan.ucl}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].ucl = parseFloat(e.target.value) || 0;
                                    setControlPlans(updated);
                                  }}
                                  className="w-16 bg-transparent font-mono focus:outline-none"
                                />
                                <div className="text-[7.5px] text-[#C49746] font-mono mt-0.5 font-bold">
                                  Destaque: {getDynamicLimits(plan).ucl.toFixed(3)} ({alarmSigmaSensitivity.toFixed(1)}σ)
                                </div>
                              </div>
                              <div className="col-span-3">
                                <label className="block text-[7px] uppercase font-bold text-[#1A1A1A]/50">Plano de Reação Operacional / Alerta</label>
                                <input
                                  type="text"
                                  value={plan.reactionPlan}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].reactionPlan = e.target.value;
                                    setControlPlans(updated);
                                  }}
                                  className="w-full bg-transparent focus:outline-none italic text-[#C49746]"
                                />
                              </div>
                            </div>

                            {/* DYNAMIC ALARM CONFIGURATION AND LIVE READING PANEL FOR THIS CP ROW */}
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2.5 border-t border-dashed border-[#1A1A1A]/10 text-[10px] items-center">
                              <div className="md:col-span-4 flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  id={`enable-alarm-${plan.id}`}
                                  checked={plan.enableAlarm ?? false}
                                  onChange={(e) => {
                                    const updated = [...controlPlans];
                                    updated[index].enableAlarm = e.target.checked;
                                    setControlPlans(updated);
                                  }}
                                  className="accent-[#C49746]"
                                />
                                <label htmlFor={`enable-alarm-${plan.id}`} className="text-[8px] uppercase font-bold text-[#1A1A1A]/70 cursor-pointer select-none">
                                  Habilitar Alarme Automático
                                </label>
                              </div>
                              <div className="md:col-span-4 flex items-center gap-2">
                                <label className="block text-[8px] uppercase font-bold text-[#1A1A1A]/70 shrink-0">Leitura Atual:</label>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="number"
                                    step="0.01"
                                    value={plan.currentReading !== undefined ? plan.currentReading : plan.target}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value) || 0;
                                      const updated = [...controlPlans];
                                      updated[index].currentReading = val;
                                      setControlPlans(updated);
                                      handleRegisterViolationIfNeeded(plan.id, val, updated);
                                    }}
                                    className="w-16 bg-transparent font-mono font-bold border-b border-[#1A1A1A]/15 focus:outline-none text-[#C49746]"
                                  />
                                  <span className="text-[8px] text-gray-400">frente ao Alvo ({plan.target})</span>
                                </div>
                              </div>
                              
                              <div className="md:col-span-4 flex items-center justify-end">
                                {(() => {
                                  const current = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                                  const dynamicLimits = getDynamicLimits(plan);
                                  const isOutLCL = current < dynamicLimits.lcl;
                                  const isOutUCL = current > dynamicLimits.ucl;
                                  const isOutside = isOutLCL || isOutUCL;
                                  if (plan.enableAlarm && isOutside) {
                                    return (
                                      <div className="flex items-center gap-1.5 text-[9px] text-red-700 bg-red-50 border border-red-200 px-2.5 py-1 rounded-xs font-bold animate-pulse">
                                        <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
                                        <span>MARGEM EXCEDIDA ({isOutLCL ? "LCL" : "UCL"} Dinâmico)</span>
                                      </div>
                                    );
                                  } else {
                                    return (
                                      <div className="text-[9px] text-emerald-800 bg-emerald-50 px-2 py-1 border border-emerald-100 uppercase tracking-widest font-bold font-mono">
                                        ✓ Sob Controle
                                      </div>
                                    );
                                  }
                                })()}
                              </div>
                            </div>

                            {/* THEORETICAL SIGMA LEVEL NOTIFICATION & METRIC BOX */}
                            <div className="mt-2.5 bg-[#FAF8F5] border border-[#1A1A1A]/5 p-2.5 rounded-xs grid grid-cols-1 sm:grid-cols-12 gap-3 items-center text-[10px]">
                              <div className="sm:col-span-8 space-y-1 text-left">
                                <span className="inline-block px-1 py-0.2 bg-[#C49746]/10 text-[#C49746] rounded-xs font-mono text-[7.5px] font-bold uppercase">
                                  CEP Dinâmico
                                </span>
                                <h5 className="font-bold text-[#1A1A1A]/80 uppercase text-[8px] inline-block ml-1.5">
                                  Análise do Nível Sigma do Processo
                                </h5>
                                <p className="text-[9px] text-[#1A1A1A]/70 leading-relaxed font-sans text-left">
                                  O <strong>Nível Sigma Operacional</strong> mede a distância padrão em que a leitura atual ({plan.currentReading !== undefined ? plan.currentReading : plan.target}) se encontra em relação aos limites de controle estimados. A meta teórica do processo é ser centrada no alvo (<strong className="text-gray-900">{plan.target}</strong>) com variabilidade de até {alarmSigmaSensitivity.toFixed(1)}σ.
                                </p>
                              </div>

                              <div className="sm:col-span-4 bg-white border border-[#1A1A1A]/5 p-2 rounded-sm text-center flex flex-col items-center justify-center space-y-1 shrink-0 shadow-2xs">
                                {(() => {
                                  const current = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                                  const target = plan.target;
                                  const ucl = plan.ucl;
                                  const lcl = plan.lcl;
                                  const sigma = Math.max(0.0001, (ucl - lcl) / 6);
                                  const deviation = current - target;
                                  
                                  // Calculate current position sigma-level
                                  let sigmaLevel = 0;
                                  if (current >= target) {
                                    sigmaLevel = (ucl - current) / sigma;
                                  } else {
                                    sigmaLevel = (current - lcl) / sigma;
                                  }

                                  // Format color scale
                                  let colorClasses = "text-emerald-700 bg-emerald-50 border-emerald-200";
                                  let statusText = "Excelente (Meta)";
                                  if (sigmaLevel < 0) {
                                    colorClasses = "text-red-700 bg-red-50 border-red-200";
                                    statusText = "Fora de Limite (Defeito)";
                                  } else if (sigmaLevel < 1.5) {
                                    colorClasses = "text-amber-700 bg-amber-50 border-amber-200 font-bold";
                                    statusText = "Instável (Ajustar)";
                                  } else if (sigmaLevel < 2.5) {
                                    colorClasses = "text-indigo-700 bg-indigo-50 border-indigo-200";
                                    statusText = "Satisfatório";
                                  }

                                  return (
                                    <>
                                      <span className="text-[7.5px] uppercase font-bold tracking-wider text-gray-500">Nível Sigma Teórico</span>
                                      <div className={`px-2 py-0.5 border rounded-xs font-mono font-bold text-xs ${colorClasses} w-full`}>
                                        {sigmaLevel.toFixed(2)} σ
                                      </div>
                                      <div className="text-[7px] uppercase font-extrabold text-[#1A1A1A]/60 font-sans tracking-tight">
                                        {statusText} • Shift: {deviation >= 0 ? "+" : ""}{deviation.toFixed(2)}
                                      </div>
                                    </>
                                  );
                                })()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Sidebar with instructions */}
                  <div className="lg:col-span-4 border border-[#1A1A1A]/15 p-6 bg-white space-y-4">
                    <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#C49746]">Padronização de Ganhos</h4>
                    <p className="text-[11px] leading-relaxed text-[#1A1A1A]/80">
                      O plano de reação evita a negligência do operador ou instabilidade das ferramentas. Em manutenções programadas, use Pokayokes mecânicos de encaixe duplo.
                    </p>
                    <div className="bg-[#F5F2ED] p-4 text-[10px] space-y-1">
                      <div className="font-bold uppercase tracking-tighter">Regras Clássicas de Nelson:</div>
                      <p className="leading-snug">Se um ponto exceder o Limite de UCL ou LCL, ou se 9 pontos consecutivos orbitarem de um lado único da linha média, há uma <strong>Causa Especial</strong> necessitando reação operacional imediata.</p>
                    </div>
                  </div>

                </div>

                {/* SIGMA LEVEL COMPARATIVE BAR CHART (RECHARTS) */}
                <div className="border-t border-[#1A1A1A] pt-8 space-y-4 animate-fade-in" id="sigma-benchmarking-panel">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Gráfico Comparativo de Capabilidade (Nível Sigma por Etapa)</h4>
                      <p className="text-[11px] text-[#1A1A1A]/60 font-sans">Análise holística da robustez estatística frente às variações de curto prazo.</p>
                      {dynamicBarHover && (
                        <div className="mt-2 inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3 py-1 text-xs text-indigo-800 font-mono font-bold animate-fade-in shadow-xs rounded-sm">
                          <span className="w-2 h-2 bg-indigo-600 rounded-full animate-ping"></span>
                          Amostra Selecionada (Etapa): <strong className="text-gray-900">{dynamicBarHover.label}</strong> ➜ <span className="text-indigo-900 font-black">{dynamicBarHover.value.toFixed(2)}σ</span>
                        </div>
                      )}
                    </div>
                    <span className="text-[8.5px] font-sans font-bold bg-[#2563EB]/10 text-[#2563EB] px-2 py-0.5 rounded-sm uppercase tracking-wide shrink-0">
                      Benchmarking Six Sigma
                    </span>
                  </div>

                  <div className="bg-white border border-[#1A1A1A]/10 p-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-8 h-72 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AnyBarChart
                          onMouseMove={(state: any) => {
                            if (state && state.activePayload && state.activePayload.length) {
                              const val = state.activePayload[0].value;
                              const label = state.activeLabel || "";
                              setDynamicBarHover({ value: typeof val === 'number' ? val : parseFloat(String(val)), label });
                            } else {
                              setDynamicBarHover(null);
                            }
                          }}
                          onMouseOver={(state: any) => {
                            if (state && state.activePayload && state.activePayload.length) {
                              const val = state.activePayload[0].value;
                              const label = state.activeLabel || "";
                              setDynamicBarHover({ value: typeof val === 'number' ? val : parseFloat(String(val)), label });
                            }
                          }}
                          onMouseLeave={() => {
                            setDynamicBarHover(null);
                          }}
                          data={controlPlans.map((plan) => {
                            const current = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                            const target = plan.target;
                            const ucl = plan.ucl;
                            const lcl = plan.lcl;
                            const sigma = Math.max(0.0001, (ucl - lcl) / 6);
                            let sigmaLevel = 0;
                            if (current >= target) {
                              sigmaLevel = (ucl - current) / sigma;
                            } else {
                              sigmaLevel = (current - lcl) / sigma;
                            }
                            return {
                              name: plan.stepName.length > 22 ? plan.stepName.substring(0, 22) + "..." : plan.stepName,
                              fullName: plan.stepName,
                              metric: plan.metric,
                              "Nível Sigma": parseFloat(sigmaLevel.toFixed(2)),
                              current: current,
                              target: target,
                              lcl: lcl,
                              ucl: ucl,
                            };
                          })}
                          margin={{ top: 15, right: 15, left: -25, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                          <XAxis 
                            dataKey="name" 
                            tick={{ fontSize: 9, fill: "#475569", fontWeight: "bold" }}
                            axisLine={{ stroke: "#E2E8F0" }}
                            tickLine={false}
                          />
                          <YAxis 
                            tick={{ fontSize: 9, fill: "#475569" }}
                            axisLine={{ stroke: "#E2E8F0" }}
                            tickLine={false}
                          />
                          <Tooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const data = payload[0].payload;
                                return (
                                  <div className="bg-white border border-gray-200 p-3 shadow-md rounded-none text-[10.5px] font-mono space-y-1">
                                    <p className="font-sans font-bold text-gray-950 border-b pb-1 mb-1 text-[11px]">{data.fullName}</p>
                                    <p><span className="text-gray-500 font-sans">Métrica:</span> <span className="text-amber-700 font-sans">{data.metric}</span></p>
                                    <p><span className="text-gray-500 font-sans">Leitura Atual:</span> <strong>{data.current}</strong></p>
                                    <p><span className="text-gray-500 font-sans">Alvo (Target):</span> <span>{data.target}</span></p>
                                    <p><span className="text-gray-500 font-sans">Limites:</span> <span className="text-[9.5px] text-gray-400">[{data.lcl} - {data.ucl}]</span></p>
                                    <p className="pt-1 border-t mt-1 font-sans font-extrabold text-[#2563EB]">
                                      Nível Sigma: {data["Nível Sigma"].toFixed(2)} σ
                                    </p>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <ReferenceLine y={1.5} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: "1.5σ Limiar Crítico", position: "insideLeft", fill: "#F59E0B", fontSize: 8, fontWeight: "bold" }} />
                          <ReferenceLine y={3.0} stroke="#10B981" strokeDasharray="3 3" label={{ value: "3.0σ Controle Padrão", position: "insideLeft", fill: "#10B981", fontSize: 8, fontWeight: "bold" }} />
                          
                          <Bar dataKey="Nível Sigma" radius={[2, 2, 0, 0]}>
                            {controlPlans.map((plan, index) => {
                              const current = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                              const target = plan.target;
                              const ucl = plan.ucl;
                              const lcl = plan.lcl;
                              const sigma = Math.max(0.0001, (ucl - lcl) / 6);
                              let sigmaLevel = 0;
                              if (current >= target) {
                                sigmaLevel = (ucl - current) / sigma;
                              } else {
                                sigmaLevel = (current - lcl) / sigma;
                              }

                              let fillColor = "#10B981"; // Excellent (Emerald)
                              if (sigmaLevel < 0) {
                                fillColor = "#EF4444"; // Out of bounds (Red)
                              } else if (sigmaLevel < 1.5) {
                                fillColor = "#F59E0B"; // Unstable (Orange)
                              } else if (sigmaLevel < 2.5) {
                                fillColor = "#6366F1"; // Satisfactory (Indigo)
                              }
                              return <Cell key={`cell-${index}`} fill={fillColor} />;
                            })}
                          </Bar>
                        </AnyBarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="lg:col-span-4 bg-[#FAF8F5] border border-gray-100 p-4 space-y-3 flex flex-col justify-between">
                      <div className="space-y-2">
                        <span className="text-[8px] uppercase tracking-wider text-[#1A1A1A]/50 font-mono font-bold">Diagnóstico de Capabilidade</span>
                        <h5 className="text-[11px] font-bold text-gray-900 uppercase tracking-tight">Análise de Pontos de Atenção</h5>
                        <p className="text-[10px] text-gray-600 leading-normal font-sans">
                          A altura de cada barra quantifica em desvios-padrão a folga restante até o limite desfavorável. Etapas com menor nível sigma sofrem maior risco de gerar retrabalhos e rejeitos.
                        </p>

                        <div className="space-y-1.5 pt-2">
                          <div className="flex items-center gap-1.5 text-[9.5px]">
                            <span className="w-2.5 h-2.5 bg-[#EF4444] rounded-xs shrink-0"></span>
                            <span className="text-gray-700 font-bold">&lt; 0σ: Fora de Controle (Gera Defeitos)</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[9.5px]">
                            <span className="w-2.5 h-2.5 bg-[#F59E0B] rounded-xs shrink-0"></span>
                            <span className="text-gray-700 font-bold">0σ - 1.5σ: Instabilidade Alta (Ajustar Parâmetro)</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[9.5px]">
                            <span className="w-2.5 h-2.5 bg-[#6366F1] rounded-xs shrink-0"></span>
                            <span className="text-gray-700">1.5σ - 2.5σ: Regulagem Atável (Tolerável)</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[9.5px]">
                            <span className="w-2.5 h-2.5 bg-[#10B981] rounded-xs shrink-0"></span>
                            <span className="text-gray-750">⚡ &gt; 2.5σ: Excelente (Estabilidade Alta)</span>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-gray-200/60 pt-3">
                        {(() => {
                          const processed = controlPlans.map(plan => {
                            const current = plan.currentReading !== undefined ? plan.currentReading : plan.target;
                            const target = plan.target;
                            const ucl = plan.ucl;
                            const lcl = plan.lcl;
                            const sigma = Math.max(0.0001, (ucl - lcl) / 6);
                            let sigmaLevel = 0;
                            if (current >= target) {
                              sigmaLevel = (ucl - current) / sigma;
                            } else {
                              sigmaLevel = (current - lcl) / sigma;
                            }
                            return { name: plan.stepName, sigmaValue: sigmaLevel };
                          });

                          const minSigmaStep = processed.reduce((prev, curr) => (prev.sigmaValue < curr.sigmaValue) ? prev : curr, { name: "Nenhuma", sigmaValue: 99 });

                          if (minSigmaStep.sigmaValue < 1.5) {
                            return (
                              <div className="bg-red-50 border border-red-100 p-2.5 text-[9px] text-red-950 font-sans leading-relaxed rounded-xs">
                                <span className="font-extrabold uppercase text-red-700 block mb-0.5">⚠️ Restrição Crítica Identificada</span>
                                A etapa <strong>{minSigmaStep.name}</strong> apresenta nível sigma alarmante de <strong>{minSigmaStep.sigmaValue.toFixed(2)}σ</strong>. Aplique ferramentas de contenção (Poka-yoke ou recalibração) imediatamente para resgatar a capabilidade ótima.
                              </div>
                            );
                          } else {
                            return (
                              <div className="bg-emerald-50 border border-emerald-100 p-2.5 text-[9px] text-emerald-950 font-sans leading-relaxed rounded-xs">
                                <span className="font-extrabold uppercase text-emerald-700 block mb-0.5">✔ Capabilidade Sob Controle</span>
                                Todas as etapas monitoradas estão operando com nível de capabilidade superior a 1.5σ. Continue monitorando via gráficos de Shewhart para prevenir causas especiais de flutuação.
                              </div>
                            );
                          }
                        })()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 30-DAY HISTORICAL PROCESS SIGMA LEVEL TREND CHART (RECHARTS) */}
                <div className="border-t border-[#1A1A1A] pt-8 space-y-4 animate-fade-in" id="sigma-trend-temporal-panel">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Gráfico de Sustentabilidade: Tendência de Nível Sigma (30 Dias de Operação)</h4>
                      <p className="text-[11px] text-[#1A1A1A]/60 font-sans">Evolução do Nível Sigma correlacionada com as intervenções e melhorias DMAIC aplicadas.</p>
                      {dynamicSigmaHover && (
                        <div className="mt-2 inline-flex items-center gap-2 bg-blue-50 border border-blue-200 px-3 py-1 text-xs text-blue-800 font-mono font-bold animate-fade-in shadow-xs rounded-sm">
                          <span className="w-2 h-2 bg-blue-600 rounded-full animate-ping"></span>
                          Amostra Selecionada (Resultado): <strong className="text-gray-900">{dynamicSigmaHover.label}</strong> ➜ <span className="text-blue-900 font-black">{dynamicSigmaHover.value.toFixed(2)}σ</span>
                        </div>
                      )}
                    </div>
                    <span className="text-[8.5px] font-sans font-bold bg-[#10B981]/10 text-[#10B981] px-2 py-0.5 rounded-sm uppercase tracking-wide shrink-0">
                      Monitoramento Temporal
                    </span>
                  </div>

                  <div className="bg-white border border-[#1A1A1A]/10 p-5 grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                    <div className="lg:col-span-8 h-72 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AnyLineChart
                          onMouseMove={(state: any) => {
                            if (state && state.activePayload && state.activePayload.length) {
                              const val = state.activePayload[0].value;
                              const label = state.activeLabel || "";
                              setDynamicSigmaHover({ value: typeof val === 'number' ? val : parseFloat(String(val)), label });
                            } else {
                              setDynamicSigmaHover(null);
                            }
                          }}
                          onMouseOver={(state: any) => {
                            if (state && state.activePayload && state.activePayload.length) {
                              const val = state.activePayload[0].value;
                              const label = state.activeLabel || "";
                              setDynamicSigmaHover({ value: typeof val === 'number' ? val : parseFloat(String(val)), label });
                            }
                          }}
                          onMouseLeave={() => {
                            setDynamicSigmaHover(null);
                          }}
                          data={Array.from({ length: 30 }, (_, index) => {
                            const day = index + 1;
                            // Pre-DMAIC baseline (~2.0σ) with some stable wave fluctuations
                            const baseline = 2.0 + Math.sin(day * 1.7) * 0.08;
                            
                            // To-Be target is the current calculated process metrics sigma level
                            const currentTarget = stats.sigmaLevel;
                            
                            // S-curve interpolation representing the ramp-up from Day 11 to Day 20
                            let sigma = baseline;
                            if (day <= 10) {
                              sigma = baseline;
                            } else if (day <= 20) {
                              const t = (day - 10) / 10;
                              const ease = t * t * (3 - 2 * t); // smoothstep
                              sigma = baseline + (currentTarget - baseline) * ease;
                            } else {
                              // Stable post-DMAIC state matching current sigmaLevel with simulated process noise
                              sigma = currentTarget + Math.cos(day * 2.1) * 0.04;
                            }
                            
                            const boundedSigma = Math.max(1.0, Math.min(6.0, sigma));
                            return {
                              day: `Dia ${day}`,
                              dayNum: day,
                              "Nível Sigma": parseFloat(boundedSigma.toFixed(2)),
                              "Meta do Projeto": 3.5,
                            };
                          })}
                          margin={{ top: 15, right: 15, left: -25, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                          <XAxis 
                            dataKey="day" 
                            tick={{ fontSize: 9, fill: "#475569" }}
                            axisLine={{ stroke: "#E2E8F0" }}
                            tickLine={false}
                          />
                          <YAxis 
                            domain={[0, 6]}
                            tick={{ fontSize: 9, fill: "#475569" }}
                            axisLine={{ stroke: "#E2E8F0" }}
                            tickLine={false}
                          />
                          <Tooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const data = payload[0].payload;
                                return (
                                  <div className="bg-white border border-gray-200 p-3 shadow-md rounded-none text-[10.5px] font-mono space-y-1">
                                    <p className="font-sans font-bold text-gray-950 border-b pb-1 mb-1 text-[11px]">{data.day}</p>
                                    <p className="font-sans"><span className="text-gray-500 font-sans">Nível Sigma:</span> <strong className="text-[#2563EB] font-sans">{data["Nível Sigma"].toFixed(2)} σ</strong></p>
                                    <p className="font-sans"><span className="text-gray-500 font-sans">Meta do Projeto:</span> <span className="text-amber-700 font-sans">3.50 σ</span></p>
                                    <p className="pt-1 border-t mt-1 font-sans text-[9px] text-gray-400">
                                      {data.dayNum <= 10 ? "Período As-Is (Baseline)" : data.dayNum <= 20 ? "Implementação DMAIC" : "Operação Controlada"}
                                    </p>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'sans-serif' }} />
                          <ReferenceLine y={3.5} stroke="#C49746" strokeDasharray="4 4" label={{ value: "Meta (3.5σ)", position: "insideLeft", fill: "#C49746", fontSize: 8, fontWeight: "bold" }} />
                          <ReferenceLine y={1.5} stroke="#EF4444" strokeDasharray="4 4" label={{ value: "Mínimo Crítico (1.5σ)", position: "insideLeft", fill: "#EF4444", fontSize: 8, fontWeight: "bold" }} />
                          
                          <Line 
                            type="monotone" 
                            dataKey="Nível Sigma" 
                            stroke="#2563EB" 
                            strokeWidth={3}
                            activeDot={{ r: 6 }} 
                            dot={{ stroke: '#2563EB', strokeWidth: 1, r: 2, fill: '#FFFFFF' }}
                          />
                        </AnyLineChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="lg:col-span-4 bg-[#FAF8F5] border border-gray-100 p-5 space-y-4 flex flex-col justify-between text-left">
                      <div className="space-y-2">
                        <span className="text-[8px] uppercase tracking-wider text-[#1A1A1A]/50 font-mono font-bold">Relatório de Sustentabilidade</span>
                        <h5 className="text-[11px] font-bold text-gray-900 uppercase tracking-tight">Análise de Eficácia Temporal</h5>
                        <p className="text-[10px] text-gray-600 leading-relaxed font-sans">
                          Este gráfico correlaciona a evolução cronológica do Nível Sigma do processo inteiro ao longo dos últimos 30 dias de operação:
                        </p>
                        
                        <div className="space-y-3 pt-2 text-[10px] text-gray-700 font-sans leading-relaxed">
                          <div className="border-l-2 border-red-400 pl-2">
                            <strong>Dias 01 - 10 (Mapeamento As-Is):</strong>
                            <p className="text-gray-500 text-[9px]">Capabilidade restrita (média de ~2.0σ), operando rotineiramente abaixo do limiar aceitável de conformidade.</p>
                          </div>
                          <div className="border-l-2 border-amber-500 pl-2">
                            <strong>Dias 11 - 20 (Fase IMPROVE):</strong>
                            <p className="text-gray-500 text-[9px]">Rollout gradual das soluções integradas de balanceamento de linha e mitigação de setups operacionais.</p>
                          </div>
                          <div className="border-l-2 border-emerald-500 pl-2">
                            <strong>Dias 21 - 30 (Sustentação CONTROL):</strong>
                            <p className="text-gray-500 text-[9px]">Fase de controle estatístico mantendo as melhorias ativas. O patamar atual de <strong>{stats.sigmaLevel.toFixed(2)}σ</strong> demonstra a eficácia sustentada.</p>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-gray-200/60 pt-3">
                        {stats.sigmaLevel >= 3.5 ? (
                          <div className="bg-emerald-50 border border-emerald-100 p-3 text-[9px] text-emerald-950 font-sans leading-relaxed rounded-xs">
                            <span className="font-extrabold uppercase text-emerald-700 block mb-0.5">⭐ Meta Atingida de Forma Sustentada</span>
                            O processo estabilizou acima de <strong>3.5σ</strong>. A padronização de ganhos via Pokayoke e as cartas de controle CEP evitam a degradação temporal do Nível Sigma.
                          </div>
                        ) : (
                          <div className="bg-amber-50 border border-amber-100 p-3 text-[9px] text-amber-950 font-sans leading-relaxed rounded-xs">
                            <span className="font-extrabold uppercase text-[#C49746] block mb-0.5">⚠️ Alerta de Capabilidade Temporal</span>
                            O nível atual de <strong>{stats.sigmaLevel.toFixed(2)}σ</strong> está abaixo do alvo de 3.5σ no final da curva de controle. Recomendamos aplicar a <strong>Otimização Total</strong> na fase IMPROVE.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* SPC CHART RENDERER (SIMULATED CONTROL CHART OVER TIME) */}
                {simulationData && (
                  <div className="border-t border-[#1A1A1A] pt-8 space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A]">Carta de Controle Estatístico de Processo (SPC)</h4>
                        <p className="text-[11px] text-[#1A1A1A]/60">Monitoramento dinâmico de variabilidade com intervalos de confiança de 3σ.</p>
                      </div>
                      <span className="text-[9px] uppercase tracking-widest text-[#C49746] font-bold">Variabilidade Estocástica Shewhart</span>
                    </div>

                    <div className="bg-white border border-[#1A1A1A]/10 p-4">
                      <div className="relative h-48 w-full">
                        
                        {/* Upper Control Limit (UCL) Line */}
                        <div className="absolute top-[15%] inset-x-0 border-t-2 border-dashed border-red-500/60 flex justify-between px-2 pt-1 z-10 pointer-events-none">
                          <span className="text-[8px] text-red-600 font-bold bg-white/80 uppercase px-1">LSC / UCL ({charter.targetValue ? (charter.targetValue * 1.3).toFixed(1) : 45}m)</span>
                        </div>

                        {/* Middle Average/Target Line */}
                        <div className="absolute top-[50%] inset-x-0 border-t border-emerald-600 flex justify-between px-2 pt-1 z-10 pointer-events-none">
                          <span className="text-[8px] text-emerald-800 font-bold bg-white/80 uppercase px-1">Alvo do Processo ({charter.targetValue}m)</span>
                        </div>

                        {/* Lower Control Limit (LCL) Line */}
                        <div className="absolute top-[85%] inset-x-0 border-t-2 border-dashed border-red-500/60 flex justify-between px-2 pt-1 z-10 pointer-events-none">
                          <span className="text-[8px] text-red-600 font-bold bg-white/80 uppercase px-1">LIC / LCL ({charter.targetValue ? (charter.targetValue * 0.7).toFixed(1) : 15}m)</span>
                        </div>

                        {/* Visual SVG line representing actual readings */}
                        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                          <path
                            d={(() => {
                              const days = simulationData.dailyAverages;
                              const minVal = Math.min(...days.map((d: any) => d.cycleTime));
                              const maxVal = Math.max(...days.map((d: any) => d.cycleTime));
                              // We scale from 15% top to 85% bottom
                              return days.map((v: any, index: number) => {
                                const x = (index / (days.length - 1)) * 100;
                                // Convert value to percentage height
                                const scaledY = 15 + ((v.cycleTime - minVal) / (maxVal - minVal || 1)) * 70;
                                return `${index === 0 ? "M" : "L"} ${x} ${100 - scaledY}`;
                              }).join(" ");
                            })()}
                            fill="none"
                            stroke="#1A1A1A"
                            strokeWidth="2"
                          />
                          {/* Dot markers */}
                          {simulationData.dailyAverages.map((v: any, idx: number) => {
                            const x = (idx / (simulationData.dailyAverages.length - 1)) * 100;
                            const minVal = Math.min(...simulationData.dailyAverages.map((d: any) => d.cycleTime));
                            const maxVal = Math.max(...simulationData.dailyAverages.map((d: any) => d.cycleTime));
                            const scaledY = 15 + ((v.cycleTime - minVal) / (maxVal - minVal || 1)) * 70;
                            return (
                              <circle
                                key={idx}
                                cx={x}
                                cy={100 - scaledY}
                                r="2.5"
                                fill="#C49746"
                                stroke="#1A1A1A"
                                strokeWidth="1"
                              />
                            );
                          })}
                        </svg>

                      </div>
                      <div className="flex justify-between text-[8px] font-bold uppercase tracking-widest text-[#1A1A1A]/40 mt-3 pt-1 border-t border-[#1A1A1A]/5">
                        <span>Dia 1 (Amostragem Inicial)</span>
                        <span>Dia 10 (Campanha Normal)</span>
                        <span>Dia 20 (Atualidade de Controle)</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Final report download trigger action */}
                <div className="bg-[#F5F2ED] border-t border-[#1A1A1A] p-6 text-center space-y-4">
                  <h4 className="font-serif italic text-lg text-[#1A1A1A]">“O preço de dar início é o plano de controle corporativo continuado.”</h4>
                  <p className="text-xs text-[#1A1A1A]/70 max-w-xl mx-auto leading-relaxed">
                    Você completou o ciclo de análise DMAIC e gerou subsídios para sustentação dos ganhos Lean Six Sigma nas frentes de Pesquisa Operacional e Gestão por Processos.
                  </p>
                  <button
                    id="finish-study-btn"
                    onClick={() => {
                      alert("Excelente! Relatório DMAIC arquivado na memória local com Sucesso. Compartilhe o link do Dev Server para demonstração ao Comitê Lean Six Sigma.");
                    }}
                    className="bg-[#1A1A1A] hover:bg-black text-white text-[10px] uppercase tracking-widest font-bold py-3 px-8 transition-all"
                  >
                    Encerrar Estudo e Emitir POPs de Manufatura
                  </button>
                </div>

              </div>
            )}
          </>
          )}
        </div>
      )}

          </main>

          {/* FOOTER BRANDING SIGNATURE */}
          <footer className="mt-auto border-t border-[#1A1A1A]/10 py-6 px-6 md:px-12 bg-[#F5F2ED] flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap gap-4 md:gap-8 justify-center text-[9px] uppercase tracking-widest font-bold text-[#1A1A1A]/50">
              <span>Pesquisa Operacional</span>
              <span>•</span>
              <span>Lean Six Sigma</span>
              <span>•</span>
              <span>Gestão por Processos</span>
              <span>•</span>
              <span>Ciência de Dados</span>
            </div>
            <div className="text-[10px] font-serif italic text-[#1A1A1A]/50">
              Teoria de Filas G/G/c • Otimizador Editorial © 2026
            </div>
          </footer>

        </div>

      </div>

      {/* Floating Sparkles Trigger Button */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end animate-fade-in">
        {copilotFlash && (
          <div className="mb-3 animate-bounce bg-slate-900 border border-[#C49746] text-white text-xs px-4 py-3 shadow-[4px_4px_0px_0px_rgba(180,83,9,1)] flex items-center gap-2 max-w-sm rounded">
            <span className="text-lg">🌟</span>
            <p className="font-serif leading-snug">{copilotFlash}</p>
          </div>
        )}

        <button
          id="floating-lss-copilot-trigger"
          onClick={() => setShowCopilot(prev => !prev)}
          className={`flex items-center gap-2 px-4 py-3 ${
            showCopilot 
              ? "bg-slate-900 border-[#C49746]" 
              : "bg-[#C49746] hover:bg-amber-800"
          } text-white border-2 border-slate-950 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:translate-x-0.5 hover:translate-y-0.5 transition-all cursor-pointer font-serif font-bold text-xs uppercase tracking-wider rounded-lg`}
          title="Abrir o Assistente de Inteligência E3I"
        >
          <Sparkles size={14} className={showCopilot ? "text-amber-400 animate-pulse" : "text-white animate-pulse"} />
          <span>Assistente Inteligente E3I</span>
        </button>
      </div>

      {/* Unified B2B Drawer: AssistenteE3I */}
      <AssistenteE3I
        isOpen={showCopilot}
        onClose={() => setShowCopilot(false)}
        steps={steps}
        arrivalRate={arrivalRate}
        stats={stats}
        charter={charter}
        sipoc={sipoc}
        completedPhases={completedPhases}
        setCompletedPhases={setCompletedPhases}
        setActivePhase={setActivePhaseRaw}
        aiLoading={aiLoading}
        aiError={aiError}
        aiResult={aiResult}
        setAiResult={setAiResult}
        setAiError={setAiError}
        handleCallGeminiApi={handleCallGeminiApi}
        copilotInput={copilotInput}
        setCopilotInput={setCopilotInput}
        isCopilotProcessing={isCopilotProcessing}
        startDate={startDate}
        setStartDate={setStartDate}
        endDate={endDate}
        setEndDate={setEndDate}
        handleCopilotRequest={handleCopilotRequest}
        filteredHistory={filteredHistory}
        clearHistory={clearHistory}
        onApplyBalanceamentoGargalo={handleApplyBalanceamentoGargalo}
        onApplyVariabilidadeKaizen={handleApplyVariabilidadeKaizen}
        onApplyPokaYokeYield={handleApplyPokaYokeYield}
        onApplyStaffSizingIncrement={handleApplyStaffSizingIncrement}
      />

      {(() => {
        if (!activeDetailStepId) return null;
        const detailStep = steps.find(s => s.id === activeDetailStepId);
        if (!detailStep) return null;
        return (
          <StepDetailModal
            step={detailStep}
            onClose={() => setActiveDetailStepId(null)}
            onUpdateStep={(updatedStep) => {
              setSteps(prev => prev.map(s => s.id === updatedStep.id ? updatedStep : s));
            }}
            onNavigateToArea={(areaId) => {
              handleSwitchArea(areaId as any);
              setActiveDetailStepId(null);
            }}
          />
        );
      })()}

      <SharePortalModal
        isOpen={sharePortalModalOpen}
        onClose={() => setSharePortalModalOpen(false)}
        currentProcessName={charter.title || "Mapeamento Operacional"}
        onPreviewPortal={() => {
          setSharePortalModalOpen(false);
          setClientPortalActive(true);
        }}
      />

      {currentWorkspaceView !== "PROCESSES" && (
        <AiMentorGuide
          currentWorkspaceView={currentWorkspaceView}
          setCurrentWorkspaceView={setCurrentWorkspaceView}
          activePhase={activePhase}
          setActivePhase={setActivePhase}
          steps={steps}
          arrivalRate={arrivalRate}
          charter={charter}
          sipoc={sipoc}
          controlPlans={controlPlans}
          activeAlarms={activeAlarms}
        />
      )}

      {/* GLOBAL HEADER NEW COMPANY MODAL */}
      {isHeaderNewCompanyModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-[999] animate-fade-in">
          <div className="bg-[#FAF9F6] border-4 border-[#1A1A1A] p-6 md:p-8 max-w-md w-full shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] rounded-sm text-left">
            <div className="flex items-center justify-between border-b-2 border-[#1A1A1A]/15 pb-3.5 mb-5">
              <div className="flex items-center gap-2">
                <span className="text-xl">🏢</span>
                <strong className="text-base text-slate-800 uppercase font-mono tracking-widest">Nova Empresa / Cliente</strong>
              </div>
              <button
                type="button"
                onClick={() => setIsHeaderNewCompanyModalOpen(false)}
                className="text-gray-400 hover:text-black font-semibold text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleCreateCompanyFromHeader(); }} className="space-y-4 font-sans">
              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">
                  Nome da Empresa / Cliente:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Alfa Transportadora S.A."
                  value={headerNewCompanyName}
                  onChange={(e) => setHeaderNewCompanyName(e.target.value)}
                  className="w-full bg-white border-2 border-[#1A1A1A] px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#C49746]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-widest text-[#1A1A1A]/60 mb-1">
                  Segmento de Mercado:
                </label>
                <select
                  value={headerNewCompanyIndustry}
                  onChange={(e) => setHeaderNewCompanyIndustry(e.target.value)}
                  className="w-full bg-white border-2 border-[#1A1A1A] px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#C49746]"
                >
                  <option value="Industrial">Industrial &amp; Manufatura</option>
                  <option value="Serviços">Prestação de Serviços &amp; Consultoria</option>
                  <option value="Logística">Logística &amp; Cadeia de Suprimentos</option>
                  <option value="Tecnologia">Tecnologia &amp; Software SaaS</option>
                  <option value="Saúde">Saúde &amp; Clínicas</option>
                  <option value="Varejo">Varejo &amp; E-commerce</option>
                  <option value="Construção">Construção &amp; Infraestrutura</option>
                  <option value="Educação">Educação &amp; EdTech</option>
                  <option value="Energia">Energia &amp; Utilities</option>
                  <option value="Agronegócio">Agronegócio &amp; Agro</option>
                  <option value="Público">Setor Público &amp; Governo</option>
                  <option value="Outros">Outro Segmento</option>
                </select>
              </div>

              <div className="bg-amber-50/70 p-3 border border-amber-300/30 text-[10px] text-amber-800 leading-normal rounded-xs font-sans">
                💡 <strong>Nota sobre isolamento:</strong> Ao cadastrar uma nova empresa, um novo projeto DMAIC padrão contendo fluxos do tipo Six Sigma será criado e ativado automaticamente para garantir que você possua dados analíticos de simulação imediatos para trabalhar.
              </div>

              <div className="border-t border-[#1A1A1A]/10 pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsHeaderNewCompanyModalOpen(false)}
                  className="px-4 py-2 border-2 border-[#1A1A1A] font-mono text-[10px] font-bold uppercase hover:bg-gray-100 cursor-pointer text-gray-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#C49746] border-2 border-[#1A1A1A] text-white font-mono text-[10px] font-bold uppercase transition-transform active:translate-y-[1px] hover:bg-amber-800 cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
                >
                  Confirmar Cadastro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* INTERACTIVE ONBOARDING GUIDED MODAL */}
      <OnboardingGuided
        isOpen={isOnboardingOpen}
        onClose={handleCloseOnboarding}
        onSelectView={setCurrentWorkspaceView}
        onSelectTemplate={handleSelectTemplate}
      />

      {/* CORPORATE AREAS TEMPLATE SELECTION HUB */}
      {isTemplateGalleryOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-[999] animate-fade-in text-left">
          <div className="bg-[#FAF9F6] border-4 border-slate-950 p-6 md:p-8 max-w-3xl w-full shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] rounded-sm flex flex-col justify-between max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b-2 border-slate-350 pb-3 mb-5">
              <div className="flex items-center gap-2">
                <span className="text-2xl">📂</span>
                <div>
                  <strong className="text-base text-slate-800 uppercase font-mono tracking-widest block leading-none">Galeria de Presets por Área Corporativa</strong>
                  <span className="text-[10px] font-sans text-slate-500 italic mt-1 block">Carregue processos estruturados recomendados pelas melhores práticas internacionais</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsTemplateGalleryOpen(false)}
                className="text-gray-400 hover:text-black font-semibold text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-6">
              {([
                { id: "it_governance", areaLabel: "TI & Desenvolvimento SaaS", icon: "🖥️", desc: "Processo estruturado de DevOps, gestão de infraestrutura de nuvem, compliance com a LGPD e deploys estocásticos baseados no NIST/COBIT.", templateId: "saas-software-delivery", title: "SaaS Software Delivery Cycle" },
                { id: "finance", areaLabel: "Contabilidade PJ & FP&A", icon: "💸", desc: "Fluxo completo de auditoria fiscal e encerramento de balanço consolidado mensal com roteiros de melhoria Lean baseados no COSO ERM.", templateId: "accounting-close", title: "Monthly Accounting Financial Close" },
                { id: "finance", areaLabel: "Financeiro & Contas (AP/AR)", icon: "📈", desc: "Mapeamento estruturado de Contas a Pagar e Contas a Receber com análise profunda de queue delays usando VSM e Teoria de Filas.", templateId: "financial-ap", title: "Accounts Payable Validation" },
                { id: "hr", areaLabel: "Recursos Humanos (RH)", icon: "👥", desc: "Funil de atração e onboarding de novos talentos para cargos de gerência de tecnologia operados através de Kanban ágil sustentável.", templateId: "hr-recruitment-funnel", title: "Technical Recruitment Funnel" },
                { id: "legal_risk", areaLabel: "Jurídico & Compliance de Contratos", icon: "⚖️", desc: "Auditoria preventiva em faturamento e minutas de contratos complexos orientados por análise estocástica Shewhart de riscos de terceiros.", templateId: "legal_risk", title: "Legal Compliance Assessment Plan" },
                { id: "core_ops", areaLabel: "Operações Core (Manufatura)", icon: "⚙️", desc: "Postos industriais sequenciais de soldagem e inspeção óptica automática (AOI) sob regime contínuo ajustado para Green/Black Belts.", templateId: "manufacturing-pcb", title: "Electro-Mechanical Assembly Line" }
              ] as const).map((area) => (
                <div 
                  key={area.id + area.areaLabel}
                  className="bg-white border-2 border-slate-900 p-4 rounded-sm flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_rgba(26,26,26,0.1)] transition-all h-60"
                >
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 border-b border-dashed border-gray-150 pb-1.5">
                      <span className="text-xl">{area.icon}</span>
                      <h4 className="text-[11.5px] font-mono font-extrabold uppercase text-[#1A1A1A] tracking-tight">{area.areaLabel}</h4>
                    </div>
                    <span className="text-[9px] text-[#C49746] font-mono block uppercase">Roteiro Ativo: {area.title}</span>
                    <p className="text-[10px] text-slate-500 leading-normal font-sans line-clamp-3">
                      {area.desc}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      // Trigger template mapping load
                      if (area.id === "legal_risk") {
                        // Custom legal preset load
                        const legalSteps = getInitialStepsForArea("legal_risk", []);
                        setSteps(legalSteps);
                        setProcessesByArea(prev => ({
                          ...prev,
                          legal_risk: legalSteps
                        }));
                        setActiveAreaId("legal_risk");
                        triggerFlash("⚖️ Processo Jurídico & Compliance carregado de forma personalizada com sucesso!");
                      } else {
                        handleSelectTemplate(area.templateId);
                        triggerFlash(`📂 Preset setorial de '${area.areaLabel}' espelhado de forma integral em seu painel.`);
                      }
                      setIsTemplateGalleryOpen(false);
                      setCurrentWorkspaceView("DIAGNOSTIC"); // navigate back
                    }}
                    className="w-full mt-3 py-1.5 bg-slate-950 hover:bg-[#C49746] text-white font-mono text-[9.5px] font-bold uppercase transition-all tracking-wider text-center cursor-pointer rounded-xs"
                  >
                    Ativar Processo da Área
                  </button>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-200 pt-4 flex justify-between items-center text-xs">
              <span className="text-slate-400 font-serif italic text-[11px]">Consulte Master Black Belts para templates customizados via IA</span>
              <button
                type="button"
                onClick={() => setIsTemplateGalleryOpen(false)}
                className="px-4 py-2 border-2 border-[#1A1A1A] font-mono text-[10px] font-bold uppercase hover:bg-gray-100 cursor-pointer text-gray-700 rounded-xs"
              >
                Voltar ao Painel
              </button>
            </div>

          </div>
        </div>
      )}

      {isTemplatesHubOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="max-w-5xl w-full max-h-[90vh] overflow-hidden my-auto">
            <EnterpriseTemplatesHub 
              onApplyTemplate={handleApplyTemplate} 
              onClose={() => setIsTemplatesHubOpen(false)} 
            />
          </div>
        </div>
      )}

      <PdcaFlowCoach
        currentWorkspaceView={currentWorkspaceView}
        setCurrentWorkspaceView={setCurrentWorkspaceView}
        completedSteps={pdcaCompletedSteps}
        setCompletedSteps={setCompletedPdcaSteps}
        cycleCount={pdcaCycleCount}
        setCycleCount={setPdcaCycleCount}
        isOpen={pdcaCoachOpen}
        setIsOpen={setPdcaCoachOpen}
      />

    </div>
  );
}
