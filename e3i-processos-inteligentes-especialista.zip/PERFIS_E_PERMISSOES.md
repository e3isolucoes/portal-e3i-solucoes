# 👥 Perfis e Permissões (RBAC) — E3I Processos Inteligentes

A plataforma E3I Processos Inteligentes utiliza um modelo rígido de controle de acesso baseado em papéis de usuário (**RBAC - Role-Based Access Control**). Cada usuário possui um papel associado ao seu cadastro com privilégios restritos.

---

## 🎭 Os Papéis de Usuário (Roles)

Nosso ecossistema gerencia **9 Perfis de Acesso**:

1. **Administrador**: Possui acesso irrestrito e soberano a todos os módulos operacionais, técnicos, logs de auditoria e parametrizações globais de licenças.
2. **Executivo**: Focado na tomada de decisão estratégica. Visualiza portfólios corporativos, relatórios consolidados de ROI, e possui poderes formais para **aprovar** ou **rejeitar** entregáveis.
3. **Gestor de Portfólio**: Supervisiona múltiplos projetos paralelos. Pode criar e atribuir líderes a projetos específicos e exportar dados estatísticos.
4. **Dono do Processo**: Responsável direto pela engenharia operacional. Edita o BPMN das áreas sob sua tutela, acompanha o WIP Kanban e diagnostica gargalos.
5. **Líder do Projeto**: O principal executor da metodologia DMAIC em campo. Cria etapas de melhoria contínua, edita o Project Charter, SIPOC de alto nível e define planos de controle.
6. **Analista**: Responsável por alimentar estatisticamente o sistema, gerar cartas de controle CEP, e simular cenários de Monte Carlo.
7. **Colaborador**: Membro técnico de ponta. Possui poder exclusivo de executar check-lists em tarefas de campo delegadas e fazer upload de evidências físicas.
8. **Auditor**: Agente técnico externo ou interno responsável exclusivo por avaliar conformidades legais, vistoriar o repositório central e conceder aprovações estatísticas (não edita as fórmulas nem o escopo dos projetos).
9. **Visualizador**: Perfil somente-leitura. Ideal para terceiros ou investidores que acompanham relatórios sem poder de interferência.

---

## 🗺️ Matriz de Acesso de Módulos (Visualizações de Menu)

Os acessos de telas e views secundárias são filtrados dinamicamente via `MODULE_ACCESS_BY_ROLE`:

| Papel de Usuário | Mapeamento (BPMN) | Simulações | Otimização PO | Auditoria e DMAIC | Configuração e Admin |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Administrador** | Sim | Sim | Sim | Sim | Sim |
| **Executivo** | Sim | Não | Não | Sim (Aprovações) | Não |
| **Gestor de Portfólio**| Sim | Sim | Não | Sim | Não |
| **Dono do Processo** | Sim | Sim | Não | Sim | Não |
| **Líder do Projeto** | Sim | Sim | Não | Sim | Não |
| **Analista** | Sim | Sim | Sim | Sim | Não |
| **Colaborador** | Sim | Não | Não | Sim (Atividades) | Não |
| **Auditor** | Sim | Não | Não | Sim (Vistorias) | Não |
| **Visualizador** | Sim (Leitura) | Não | Não | Sim (Leitura) | Não |

---

## 🔗 Modelo de Delegação Temporária e Cobertura de Ausências

Para garantir a continuidade operacional das transações corporativas (ex: um Líder de Projeto sai de férias e precisa que um Analista aprove entregáveis em seu nome temporariamente), a plataforma disponibiliza um motor inteligente de **Delegações**:

### Estrutura do Registro de Delegação (`DelegationRecord`)
* **grantorUser**: Usuário outorgador.
* **grantorRole**: Papel outorgador (ex: "Líder do Projeto").
* **delegateeName/delegateeRole**: Usuário ou Papel outorgado.
* **startDate / endDate**: Janela temporal estrita de validade da delegação.
* **status**: Estado atual da delegação (`Ativa`, `Agendada`, `Expirada`, `Cancelada`).
* **delegatedPermissions**: Lista explícita de privilégios cedidos.

O método `checkPermission()` examina em tempo de execução:
1. Se o papel atual do usuário possui permissão direta para a transação.
2. Se existe alguma delegação ativa na data de hoje que outorgue essa permissão específica a esse operador. Se sim, a ação é prontamente autorizada especificando sua origem por delegação técnica, gravando o evento correspondente no Log de Auditoria.
