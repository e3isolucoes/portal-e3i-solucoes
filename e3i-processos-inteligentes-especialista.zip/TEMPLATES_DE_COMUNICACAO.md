# Biblioteca de Templates de Comunicação (Fase 13)

Os comunicados emitidos pelo motor de mensageria central utilizam templates formatados em Markdown ou HTML, garantindo padronização corporativa e legibilidade em múltiplos dispositivos.

## 1. Variáveis de Substituição Homologadas

Os templates compilam dinamicamente as seguintes variáveis baseadas no contexto de execução do projeto Six Sigma:

* `{{empresa}}` - Razão Social da Holding correspondente.
* `{{projeto}}` - Nome do Projeto DMAIC ativo.
* `{{processo}}` - Esboço/etapa do SIPOC afetada.
* `{{fase}}` - Fase corrente (Define, Measure, Analyze, Improve, Control).
* `{{tarefa}}` - Nome da tarefa ou alteração de controle.
* `{{responsavel}}` - Nome ou e-mail do encarregado responsável.
* `{{prazo}}` - Data limite designada.
* `{{dias_em_atraso}}` - Número inteiro correspondente ao estouro do cronograma.
* `{{link}}` - URL direta de encaminhamento seguro para ação.

---

## 2. Exemplos de Templates Ativos

### Tarefa Atribuída (`TEMP-TAREFA-CTR`)
* **Assunto**: `Olá {{responsavel}}, você foi designado responsável por uma nova atividade operacional`
* **Corpo**:
```markdown
Olá {{responsavel}},

Identificamos a necessidade de sua atuação no processo de melhoria contínua.

* **Holding**: {{empresa}}
* **Projeto**: {{projeto}}
* **Fase Ativa**: {{fase}}
* **Ação designada**: {{tarefa}}
* **Prazo Limite**: {{prazo}}

Para visualizar e preencher as evidências correspondentes, por favor acesse o painel seguro no seguinte endereço:
{{link}}

Atenciosamente,
Gestão de Mudança e3i
```
