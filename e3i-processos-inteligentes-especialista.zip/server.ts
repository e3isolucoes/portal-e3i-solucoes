/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { z } from "zod";
import crypto from "crypto";
import { verifyIdToken, getUserProfile } from "./src/services/firebaseAdmin";

dotenv.config();

// Load active firebase-applet-config.json dynamically for ID token lookup and REST fetching
let firebaseConfig: any = null;
try {
  const configFile = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configFile)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configFile, "utf-8"));
  }
} catch (err) {
  console.warn("[Backend Config] Could not load active firebase-applet-config.json:", err);
}

// Helper to authenticate user role using Firebase Admin SDK (centralized secure authentication & authorization checks)
async function getUserProfileFromAuthToken(authHeader: string | undefined) {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }
  const idToken = authHeader.split(" ")[1];
  if (!idToken || idToken === "null" || idToken === "undefined") {
    return null;
  }
  
  try {
    const decodedToken = await verifyIdToken(idToken);
    const uid = decodedToken.uid;
    const email = decodedToken.email;
    
    // Retrieve fortified user profile data from central Firestore DB using Firebase Admin
    const profile = await getUserProfile(uid);
    return {
      uid,
      email: email || profile.email,
      role: profile.role || "Visitante",
      belt: profile.belt || "Yellow Belt"
    };
  } catch (error) {
    console.error("[Backend Auth Error] Firebase Admin SDK verification failed:", error);
    return null;
  }
}

// Zod payload schemas
const stepSchema = z.object({
  name: z.string().min(1, "O nome da etapa é obrigatório.").max(200),
  resource: z.string().min(1, "O recurso associado à etapa é obrigatório.").max(200),
  resourceCount: z.number().int().positive("A quantidade de recursos deve ser maior que 0.").max(100),
  processingTime: z.number().nonnegative("O tempo de processamento não pode ser negativo."),
  standardDeviation: z.number().nonnegative("O desvio padrão não pode ser negativo."),
  yieldRate: z.number().min(0, "O rendimento deve estar entre 0 e 1.").max(1, "O rendimento deve estar entre 0 e 1."),
  setupTime: z.number().nonnegative("O tempo de setup não pode ser negativo.")
});

const charterSchema = z.object({
  title: z.string().optional().default(""),
  problemStatement: z.string().optional().default(""),
  goal: z.string().optional().default(""),
  metric: z.string().optional().default(""),
  targetValue: z.number().optional().default(0)
}).default({
  title: "",
  problemStatement: "",
  goal: "",
  metric: "",
  targetValue: 0
});

const sipocSchema = z.object({
  suppliers: z.string().optional().default(""),
  inputs: z.string().optional().default(""),
  processDescription: z.string().optional().default(""),
  outputs: z.string().optional().default(""),
  customers: z.string().optional().default("")
}).default({
  suppliers: "",
  inputs: "",
  processDescription: "",
  outputs: "",
  customers: ""
});

const analyzePayloadSchema = z.object({
  steps: z.array(stepSchema).nonempty("O processo deve conter ao menos 1 etapa."),
  arrivalRate: z.number().positive("A taxa de chegada de demanda deve ser positiva.").max(100000),
  charter: charterSchema,
  sipoc: sipocSchema
});

const suggestStructureSchema = z.object({
  sectorDescription: z.string().min(3, "A descrição do setor deve possuir pelo menos 3 caracteres.").max(1000, "Descrição excessivamente longa.")
});

const generatePitchSchema = z.object({
  projectName: z.string().min(1, "O nome do projeto ou negócio é obrigatório."),
  niche: z.string().min(1, "O nicho/ramo de atuação de mercado é obrigatório."),
  pain: z.string().min(1, "A descrição da dor/problema do cliente é obrigatória."),
  solution: z.string().min(1, "A proposta de valor ou solução é obrigatória."),
  secret: z.string().min(1, "O diferencial competitivo ou segredo é obrigatório."),
  traction: z.string().min(1, "A atração/dados de validação ou mercado são obrigatórios."),
  cta: z.string().min(1, "O chamado para ação (CTA) é obrigatório.")
});

const parseProcessSchema = z.object({
  text: z.string().min(1, "A descrição do processo é obrigatória.").max(5000, "Descrição excessivamente longa."),
  feedback: z.string().optional().default(""),
  history: z.array(z.object({
    role: z.string(),
    content: z.string()
  })).optional().default([])
});

const laypersonChatSchema = z.object({
  message: z.string().min(1, "A mensagem do chat não pode ser vazia.").max(2000, "Mensagem excessivamente longa."),
  dmaicStep: z.string().optional().default("Definir")
});

// Lazy initialization of Gemini API to avoid module-load crashes if the key isn't set yet
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error(
        "Chave do Gemini (GEMINI_API_KEY) não encontrada. Configure a chave nas configurações do AI Studio para habilitar a análise de IA."
      );
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// In-memory cache for Gemini API requests to increase efficiency and prevent rate limits
const geminiCache = new Map<string, { response: any; timestamp: number }>();
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes Cache TTL

function getCacheKey(contents: any, systemInstruction?: string, model?: string): string {
  const contentStr = typeof contents === 'string' ? contents : JSON.stringify(contents);
  const sysStr = systemInstruction || "";
  const modelStr = model || "";
  return crypto.createHash("sha256").update(`${modelStr}:${sysStr}:${contentStr}`).digest("hex");
}

// Authentication & multi-tenant/client-portal context attachment middleware
async function requireAuth(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    logSecurityEvent("UNAUTHORIZED_ACCESS_ATTEMPT", { ip: req.ip, path: req.path });
    return res.status(401).json({ error: "Sessão corporativa inválida. Por favor, autentique-se para consultar os serviços de IA." });
  }

  const token = authHeader.split(" ")[1];
  if (!token || token === "null" || token === "undefined") {
    logSecurityEvent("UNAUTHORIZED_ACCESS_ATTEMPT", { ip: req.ip, path: req.path });
    return res.status(401).json({ error: "Sessão corporativa inválida. Por favor, autentique-se para consultar os serviços de IA." });
  }

  // 1. Detect if it is a signed portal token (two base64 segments separated by dot)
  if (token.includes(".")) {
    const parts = token.split(".");
    if (parts.length === 2) {
      try {
        const [payloadStr, signature] = parts;
        const expectedSignature = crypto
          .createHmac("sha256", CLIENT_PORTAL_SECRET)
          .update(payloadStr)
          .digest("base64");

        if (safeCompare(signature, expectedSignature)) {
          const payload = JSON.parse(Buffer.from(payloadStr, "base64").toString("utf8"));
          const isExpired = Date.now() > payload.expiresAt;
          if (isExpired) {
            logSecurityEvent("EXPIRED_PORTAL_TOKEN_USED", { company: payload.companyName });
            return res.status(401).json({ error: "O link de convite seguro utilizado expirou. Solicite um novo link ao seu consultor." });
          }

          if (payload.scopes && payload.scopes.includes("client:portal")) {
            req.user = {
              uid: payload.tenantId || "portal_client_user",
              email: `client@${payload.companyName.toLowerCase().replace(/[^a-z0-9]/g, "")}.com`,
              role: "Cliente",
              belt: "Client Belt",
              companyName: payload.companyName,
              isPortalClient: true,
            };
            return next();
          }
        }
      } catch (err: any) {
        console.warn("[Backend Auth] Error trying to parse and verify portal token:", err.message);
      }
    }
  }

  // 2. Otherwise verify with Firebase Admin
  try {
    const decodedToken = await verifyIdToken(token);
    const uid = decodedToken.uid;
    const email = decodedToken.email;
    const profile = await getUserProfile(uid);

    req.user = {
      uid,
      email: email || profile.email,
      role: profile.role || "Visitante",
      belt: profile.belt || "Yellow Belt",
      fullName: profile.fullName || "Usuário",
      isPortalClient: false,
    };
    return next();
  } catch (error: any) {
    logSecurityEvent("FIREBASE_ID_TOKEN_FAILED", { error: error.message });
    return res.status(401).json({ error: "Sessão inválida ou expirada. Por favor, faça login novamente." });
  }
}

// User role/belt/permission checking helper
function requirePermission(allowedBelts: string[], allowPortalClient = false) {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ error: "Usuário não autenticado." });
    }

    // Direct access allowance for validated portal clients if applicable
    if (req.user.isPortalClient && allowPortalClient) {
      return next();
    }

    if (req.user.isPortalClient && !allowPortalClient) {
      logSecurityEvent("ACCESS_DENIED_PORTAL_CLIENT", { email: req.user.email, path: req.path });
      return res.status(403).json({ error: "Acesso negado. Clientes externos do portal não possuem permissão para realizar esta operação." });
    }

    // Admins have total permissions
    if (req.user.role === "Admin") {
      return next();
    }

    // Check level/belt
    const hasAccess = allowedBelts.includes(req.user.belt);
    if (!hasAccess) {
      logSecurityEvent("ACCESS_DENIED_INSUFFICIENT_BELT", { 
        email: req.user.email, 
        belt: req.user.belt, 
        path: req.path 
      });
      return res.status(403).json({ 
        error: `Acesso negado. Esta operação de IA requer nível de certificação mínimo: ${allowedBelts.join(", ")}. Seu nível atual é ${req.user.belt}.` 
      });
    }

    next();
  };
}

// Custom in-memory rate limiter per authenticated user/tenant/portal-client
const userAiRequestTracker = new Map<string, { count: number; resetTime: number }>();

function aiRateLimiter(limit: number, windowMs: number) {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ error: "Sessão inválida para rate-limiting de IA." });
    }
    const key = `${req.user.uid || req.user.email}:${req.path}`;
    const now = Date.now();

    const entry = userAiRequestTracker.get(key);
    if (!entry || now > entry.resetTime) {
      userAiRequestTracker.set(key, { count: 1, resetTime: now + windowMs });
    } else {
      entry.count++;
      if (entry.count > limit) {
        logSecurityEvent("AI_USER_RATE_LIMIT_EXCEEDED", { 
          uid: req.user.uid, 
          email: req.user.email, 
          isPortal: req.user.isPortalClient, 
          path: req.path,
          count: entry.count
        });
        return res.status(429).json({ 
          error: "Limite de requisições de Inteligência Artificial excedido para o seu perfil. Por favor, aguarde alguns minutos antes de tentar novamente." 
        });
      }
    }
    next();
  };
}

// Secure log structuring that avoids leaking PII or raw prompts
function logSafeAiRequest(endpoint: string, user: any, payload: any) {
  const logDetails: any = {
    endpoint,
    userEmail: user?.email,
    userRole: user?.role,
    userBelt: user?.belt,
    isPortalClient: !!user?.isPortalClient,
    timestamp: new Date().toISOString()
  };

  if (endpoint === "/api/analyze") {
    logDetails.stepsCount = payload.steps?.length;
    logDetails.arrivalRate = payload.arrivalRate;
    logDetails.charterTitleLength = payload.charter?.title?.length || 0;
  } else if (endpoint === "/api/suggest-structure") {
    logDetails.sectorLength = payload.sectorDescription?.length || 0;
  } else if (endpoint === "/api/parse-process") {
    logDetails.textLength = payload.text?.length || 0;
    logDetails.feedbackLength = payload.feedback?.length || 0;
    logDetails.historyLength = payload.history?.length || 0;
  } else if (endpoint === "/api/generate-pitch") {
    logDetails.projectName = payload.projectName;
    logDetails.niche = payload.niche;
  } else if (endpoint === "/api/layperson-improve") {
    logDetails.stepsCount = payload.steps?.length;
    logDetails.arrivalRate = payload.arrivalRate;
  } else if (endpoint === "/api/layperson-chat") {
    logDetails.messageLength = payload.message?.length || 0;
    logDetails.dmaicStep = payload.dmaicStep;
  }

  console.log(`[AI OPERATION LOG] ${JSON.stringify(logDetails)}`);
}

// Unified security and generic error handler to prevent stack traces or API leaks
function handleSecureAiError(res: any, error: any, endpoint: string, user: any) {
  console.error(`[AI EXCEPTION] Error in ${endpoint} for user ${user?.email || "anonymous"}:`, error);

  let errorMessage = "Ocorreu um erro interno de processamento na Inteligência Artificial. Por favor, tente novamente mais tarde.";
  const errString = String(error?.message || error).toLowerCase();

  if (errString.includes("leaked") || errString.includes("api key has been compromised")) {
    errorMessage = "A chave de API do Gemini foi suspensa por motivos de segurança. Contate o administrador do sistema.";
  } else if (errString.includes("permission_denied") || errString.includes("403")) {
    errorMessage = "Acesso recusado ao modelo de Inteligência Artificial. Certifique-se de que a GEMINI_API_KEY do workspace está ativa.";
  } else if (errString.includes("429") || errString.includes("too many requests") || errString.includes("quota")) {
    errorMessage = "Limite de requisições do provedor de IA atingido. Por favor, tente novamente em alguns instantes.";
  }

  return res.status(500).json({ error: errorMessage });
}

// Resilient wrapper with local cache, Fallback models, and Exponential Backoff for 429 rate limit handling
async function generateContentWithResilience(
  client: GoogleGenAI,
  params: {
    model: string;
    contents: any;
    config?: any;
  }
): Promise<any> {
  const systemInstruction = params.config?.systemInstruction || "";
  const model = params.model || "gemini-2.0-flash";
  const cacheKey = getCacheKey(params.contents, systemInstruction, model);

  // Check cache
  const cached = geminiCache.get(cacheKey);
  if (cached && (Date.now() - cached.timestamp < CACHE_TTL_MS)) {
    console.log(`[Gemini Cache] Hit for key: ${cacheKey}`);
    return cached.response;
  }

  // Robust fallback model selection (chosen model first, then compliant/supported fallbacks)
  const modelsToTry = [
    model,
    "gemini-3.5-flash",
    "gemini-flash-latest"
  ];
  const uniqueModels = Array.from(new Set(modelsToTry.filter(Boolean)));
  let lastError: any = null;
  const maxRetries = 3;

  for (const targetModel of uniqueModels) {
    let attempts = 0;
    let currentDelay = 1000;

    while (attempts < maxRetries) {
      try {
        console.log(`[Gemini Call] Attempting generation with model ${targetModel} (Attempt ${attempts + 1}/${maxRetries})...`);
        const response = await client.models.generateContent({
          ...params,
          model: targetModel,
        });

        // Store successful response in cache
        geminiCache.set(cacheKey, {
          response,
          timestamp: Date.now()
        });

        return response;
      } catch (err: any) {
        lastError = err;
        const errMessage = String(err.message || err).toLowerCase();
        
        // Handle Rate Limit Errors (429) with Exponential Backoff
        const isRateLimit = errMessage.includes("429") || errMessage.includes("too many requests") || errMessage.includes("quota");
        if (isRateLimit) {
          attempts++;
          if (attempts >= maxRetries) {
            console.warn(`[Gemini Error] Rate limit exceeded (429) for ${targetModel} after ${attempts} attempts.`);
            break;
          }
          console.warn(`[Gemini Warning] Rate limit hit (429). Retrying in ${currentDelay}ms (Exponential Backoff)...`);
          await new Promise(resolve => setTimeout(resolve, currentDelay));
          currentDelay *= 2;
          continue;
        }

        // Handle Unsupported or Missing Models gracefully by trying next fallback
        const isModelError = errMessage.includes("not found") || 
                             errMessage.includes("invalid") || 
                             errMessage.includes("not supported") || 
                             errMessage.includes("not enabled") ||
                             errMessage.includes("unregistered") ||
                             errMessage.includes("model");

        if (isModelError) {
          console.warn(`[Gemini Warning] Model ${targetModel} is not supported or not found. Moving to fallback model...`);
          break;
        }

        // Standard retry for other temporary/network issues
        attempts++;
        if (attempts >= maxRetries) {
          break;
        }
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  }

  throw lastError || new Error("Falha ao gerar resposta utilizando o Gemini API.");
}

const CLIENT_PORTAL_SECRET = process.env.CLIENT_PORTAL_SECRET || "optima-lss-secret-key-2026-corporate";

// Timing-safe comparison helper to prevent side-channel timing attacks
function safeCompare(a: string, b: string): boolean {
  try {
    const bufA = Buffer.from(a);
    const bufB = Buffer.from(b);
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

// Trusted CORS origins check
function isOriginAllowed(origin: string | undefined): boolean {
  if (!origin) return true;
  if (origin.startsWith("http://localhost:") || origin === "http://localhost") return true;
  const isMatch = origin.endsWith(".run.app") || origin.endsWith(".google.com") || origin.endsWith("ai.studio") || origin.toLowerCase().includes("googleusercontent.com");
  return isMatch;
}

// Centralized immutable security logger
function logSecurityEvent(event: string, details: any) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    event,
    details,
    pid: process.pid
  };
  console.log(`[SECURITY AUDIT LOG] ${JSON.stringify(logEntry)}`);
}

// In-memory rate limiter to prevent quota/resource attacks
const ipRequestCounts = new Map<string, { count: number; resetTime: number }>();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Custom CORS & Secure Response Headers
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && isOriginAllowed(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
    } else if (!origin) {
      // Direct request / non-browser, set no wildcard
      res.setHeader("Access-Control-Allow-Origin", "null");
    } else {
      res.setHeader("Access-Control-Allow-Origin", "null");
    }
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Credentials", "true");

    // Enterprise Security Headers
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
    
    // Custom fine-tuned CSP that allows ai.studio preview frame embedding and script styles
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'self' https:; " +
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; " +
      "style-src 'self' 'unsafe-inline' https:; " +
      "img-src 'self' data: https:; " +
      "frame-ancestors 'self' https://ai.studio https://*.google.com https://*.googleusercontent.com;"
    );

    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Custom rate-limiter for /api
  app.use((req, res, next) => {
    if (req.path.startsWith("/api/")) {
      const ip = (req.headers["x-forwarded-for"] as string || req.socket.remoteAddress || "anonymous").split(",")[0].trim();
      const now = Date.now();
      const limit = 120; // 120 requests/min
      const windowMs = 60000;

      const entry = ipRequestCounts.get(ip);
      if (!entry || now > entry.resetTime) {
        ipRequestCounts.set(ip, { count: 1, resetTime: now + windowMs });
      } else {
        entry.count++;
        if (entry.count > limit) {
          logSecurityEvent("RATE_LIMIT_EXCEEDED", { ip, path: req.path });
          return res.status(429).json({ 
            error: "Muitas requisições. Por favor, aguarde um minuto e tente novamente." 
          });
        }
      }
    }
    next();
  });

  app.use(express.json({ limit: "10mb" }));

  // PORTAL SECURE SIGNING ENDPOINTS
  app.post("/api/portal/generate-token", async (req, res) => {
    try {
      // 1. Exigir autenticação para geração de convites (RBAC)
      const authHeader = req.headers.authorization;
      const profile = await getUserProfileFromAuthToken(authHeader);
      
      if (!profile) {
        logSecurityEvent("UNAUTHORIZED_TOKEN_GENERATION_FAILED", { ip: req.ip, reason: "Missing or invalid session auth token." });
        return res.status(401).json({ error: "Sessão inválida. Você precisa estar autenticado como Admin ou Black Belt para gerar convites." });
      }

      if (profile.role !== "Admin" && profile.belt !== "Black Belt") {
        logSecurityEvent("FORBIDDEN_TOKEN_GENERATION_FAILED", { uid: profile.uid, email: profile.email, role: profile.role, belt: profile.belt });
        return res.status(403).json({ error: "Acesso negado. Apenas coordenadores de melhoria Black Belt ou Administradores corporativos podem gerar links para clientes." });
      }

      const { companyName, passcode, expirationDays } = req.body;
      if (!companyName || !passcode) {
        return res.status(400).json({ error: "Nome da empresa e código/passcode são obrigatórios." });
      }

      // Evitar uso de senhas ou PINs fracos conhecidos
      const normalizedPasscode = passcode.trim().toUpperCase();
      if (normalizedPasscode === "LSS-2026") {
        return res.status(400).json({ error: "O uso do PIN público padrão 'LSS-2026' foi bloqueado por políticas de segurança empresariais. Crie um PIN corporativo robusto personalizado." });
      }
      
      const days = expirationDays ? Number(expirationDays) : 7;
      const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;
      
      // Nunca incluir o PIN dentro do token. Armazenamos o HMAC-SHA256 do PIN para validação offline de alta entropia.
      const passcodeHash = crypto
        .createHmac("sha256", CLIENT_PORTAL_SECRET)
        .update(normalizedPasscode)
        .digest("base64");

      const payloadObj = {
        tenantId: profile.uid, // Isola o inquilino com base no criador do convite
        companyName: companyName.trim().toUpperCase(),
        passcodeHash, // PIN mascarado de forma irreversível fora de brute force
        expiresAt,
        scopes: ["client:portal"]
      };
      
      const payloadStr = Buffer.from(JSON.stringify(payloadObj)).toString("base64");
      const signature = crypto
        .createHmac("sha256", CLIENT_PORTAL_SECRET)
        .update(payloadStr)
        .digest("base64");
        
      const token = `${payloadStr}.${signature}`;

      logSecurityEvent("CLIENT_PORTAL_TOKEN_GENERATED", {
        issuerEmail: profile.email,
        companyName: payloadObj.companyName,
        expiresAt: new Date(expiresAt).toISOString(),
        tenantId: payloadObj.tenantId
      });

      return res.json({ token });
    } catch (err: any) {
      logSecurityEvent("PORTAL_GENERATION_ERROR", { error: err.message });
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/portal/verify-token", (req, res) => {
    try {
      const { token, passcode } = req.body;
      if (!token) {
        return res.status(400).json({ error: "O token seguro é obrigatório." });
      }
      
      const parts = token.split(".");
      if (parts.length !== 2) {
        return res.json({ isValid: false, companyName: null, isExpired: false });
      }
      
      const [payloadStr, signature] = parts;
      const expectedSignature = crypto
        .createHmac("sha256", CLIENT_PORTAL_SECRET)
        .update(payloadStr)
        .digest("base64");
        
      // Timing-safe comparison de assinaturas para evitar "forjabilidade por cronometragem"
      if (!safeCompare(signature, expectedSignature)) {
        logSecurityEvent("SIGNATURE_VERIFICATION_TAMPERED", { tokenLength: token.length });
        return res.json({ isValid: false, companyName: null, isExpired: false });
      }
      
      const payload = JSON.parse(Buffer.from(payloadStr, "base64").toString("utf8"));
      const isExpired = Date.now() > payload.expiresAt;
      
      if (isExpired) {
        return res.json({ isValid: false, companyName: payload.companyName, isExpired: true });
      }

      // Verificação de escopo extra
      if (!payload.scopes || !payload.scopes.includes("client:portal")) {
        logSecurityEvent("INVALID_SCOPE_ERROR", { company: payload.companyName });
        return res.json({ isValid: false, companyName: null, isExpired: false });
      }
      
      if (passcode) {
        const normalizedPasscode = passcode.trim().toUpperCase();
        if (normalizedPasscode === "LSS-2026") {
          logSecurityEvent("WEAK_PIN_USED_REJECTED", { company: payload.companyName });
          return res.json({ isValid: false, companyName: payload.companyName, isExpired });
        }

        // Timing-safe comparison do PIN hash
        const incomingHash = crypto
          .createHmac("sha256", CLIENT_PORTAL_SECRET)
          .update(normalizedPasscode)
          .digest("base64");
          
        if (!safeCompare(incomingHash, payload.passcodeHash)) {
          logSecurityEvent("PIN_VERIFICATION_INVALID", { company: payload.companyName });
          return res.json({ isValid: false, companyName: payload.companyName, isExpired });
        }
      }
      
      return res.json({
        isValid: true,
        companyName: payload.companyName,
        tenantId: payload.tenantId,
        isExpired: false
      });
    } catch (err: any) {
      logSecurityEvent("PORTAL_VERIFICATION_EXCEPTION", { error: err.message });
      return res.json({ isValid: false, companyName: null, isExpired: false });
    }
  });

  // API: Analyze operational process using Gemini
  app.post("/api/analyze", requireAuth, requirePermission(["Green Belt", "Black Belt"], false), aiRateLimiter(10, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      // 1. Validate payload with Zod
      const parsedPayload = analyzePayloadSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados de payload inválidos: ${errorMessages}` });
      }
      
      const { steps, arrivalRate, charter, sipoc } = parsedPayload.data;

      // 2. Log safe audit trail metadata
      logSafeAiRequest("/api/analyze", req.user, parsedPayload.data);

      const client = getGeminiClient();

      const prompt = `
Você é um consultor sênior de excelência operacional especializado em Lean Six Sigma, Pesquisa Operacional, Gestão de Processos e Ciência de Dados.
Analise a seguinte estrutura de processo operacional fornecida pelo usuário, identifique gargalos estatística e logicamente, e gere um estudo aprofundado utilizando DMAIC (Define, Measure, Analyze, Improve, Control).

TAXA DE CHEGADA DE DEMANDA: ${arrivalRate} unidades por hora

ETAPAS DO PROCESSO:
${steps
  .map(
    (s, index) =>
      `${index + 1}. Etapa: "${s.name}"
   - Recurso: ${s.resource} (Quantidade disponível: ${s.resourceCount})
   - Tempo de processamento médio (Cicle Time): ${s.processingTime} minutos/unidade
   - Desvio Padrão (Variabilidade): ${s.standardDeviation} minutos
   - Taxa de Rendimento (Yield Rate): ${(s.yieldRate * 100).toFixed(1)}% (indica qualidade de primeira passagem)
   - Tempo de Setup/Configuração: ${s.setupTime} minutos`
  )
  .join("\n")}

CONVENÇÃO DO PROJETO (PROJECT CHARTER):
- Título do Projeto: ${charter.title || "Otimização de Fluxo Operacional"}
- Declaração do Problema: ${charter.problemStatement || "Gargalos não identificados gerando lead time alto e falhas."}
- Goal do Projeto (Objetivo): ${charter.goal || "Reduzir desperdícios, elevar Sigma e estabilizar vazão."}
- Métrica Principal: ${charter.metric} (Alvo: ${charter.targetValue})

ESTRUTURA SIPOC ATUAL:
- Fornecedores (Suppliers): ${sipoc.suppliers || "Não especificado"}
- Entradas (Inputs): ${sipoc.inputs || "Não especificado"}
- Processo: ${sipoc.processDescription || "Passos descritos nas etapas."}
- Saídas (Outputs): ${sipoc.outputs || "Não especificado"}
- Clientes (Customers): ${sipoc.customers || "Não especificado"}

INSTRUÇÃO IMPORTANTE:
Sua análise de Pesquisa Operacional (Teoria das Filas) deve verificar se alguma etapa tem Taxa de Atendimento < Taxa de Chegada (${arrivalRate} u/h), o que cria uma fila que cresce indefinidamente (Saturação / Utilização >= 100%).
Calcule ou valide o desempenho de Six Sigma (DPMO e Nível Sigma combinado do processo) - note que o rendimento total de primeira passagem (Rolled First Pass Yield) é o produto das taxas de rendimento de cada etapa.
Formule recomendações específicas de Lean (ex: SMED para tempos de setup, Kaizen, 5S, Poka-Yoke para etapas com baixo yield, balanceamento de linha para realocar recursos dos gargalos).

Retorne sua resposta estritamente em Português do Brasil seguindo o schema JSON fornecido.
`;

      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          systemInstruction:
            "Você é um consultor de elite em Engenharia de Produção e Pesquisa Operacional. Suas análises são tecnicamente ricas, baseadas em dados e conceitos reais como Teoria das Filas, Estatística, Lean Manufacturing e Six Sigma (DMAIC). Retorne sempre um JSON válido no formato solicitado.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              executiveSummary: {
                type: Type.STRING,
                description:
                  "Um resumo executivo detalhado em português, avaliando o estado atual, a gravidade dos gargalos achados e os riscos de variabilidade.",
              },
              dmaicApproach: {
                type: Type.OBJECT,
                properties: {
                  define: {
                    type: Type.STRING,
                    description: "Detalhamento da fase DEFINE para esse processo conceitualmente.",
                  },
                  measure: {
                    type: Type.STRING,
                    description: "Detalhamento da fase MEASURE com indicadores chave e plano de coleta.",
                  },
                  analyze: {
                    type: Type.STRING,
                    description: "Detalhamento da fase ANALYZE justificando os gargalos e variações estatísticas encontrada.",
                  },
                  improve: {
                    type: Type.STRING,
                    description: "Ações práticas da fase IMPROVE (ex: balanceamento, redução de setup, Poka-Yoke).",
                  },
                  control: {
                    type: Type.STRING,
                    description: "Ações da fase CONTROL como cartas de controle SPC e POPs.",
                  },
                },
                required: ["define", "measure", "analyze", "improve", "control"],
              },
              orRecommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING, description: "Título da recomendação Lean/Pesquisa Operacional" },
                    description: { type: Type.STRING, description: "Explicação prática de como operacionalizar" },
                    expectedImpact: { type: Type.STRING, description: "Impacto quantitativo ou qualitativo esperado nos indicadores" },
                    leanPrinciple: { type: Type.STRING, description: "Princípio Lean associado (ex: SMED, Balanceamento, Poka-Yoke, Kanban)" },
                  },
                  required: ["title", "description", "expectedImpact", "leanPrinciple"],
                },
                description: "Lista de 3 a 5 recomendações cirúrgicas de otimização operacional.",
              },
            },
            required: ["executiveSummary", "dmaicApproach", "orRecommendations"],
          },
        },
      });

      const responseText = response.text || "{}";
      const analysisJson = JSON.parse(responseText.trim());

      return res.json(analysisJson);
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/analyze", req.user);
    }
  });

  // API: Suggest operational structure & SIPOC based on sector description using Operations Research principles
  app.post("/api/suggest-structure", requireAuth, requirePermission(["Green Belt", "Black Belt", "Yellow Belt"], true), aiRateLimiter(20, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      // 1. Validate payload with Zod
      const parsedPayload = suggestStructureSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados de payload inválidos: ${errorMessages}` });
      }

      const { sectorDescription } = parsedPayload.data;
      logSafeAiRequest("/api/suggest-structure", req.user, parsedPayload.data);

      const client = getGeminiClient();

      const prompt = `
Você é um Engenheiro de Produção especialista em Pesquisa Operacional e Excelência Operacional (Lean Six Sigma).
Gere uma estrutura de processo realista e um modelo SIPOC completo com base na seguinte descrição do setor/operação fornecida pelo usuário:

DESCRIÇÃO DO SETOR/OPERAÇÃO: "${sectorDescription}"

Seu objetivo é propor:
1. Um diagrama SIPOC estruturado (Fornecedores, Entradas, Processo Macro, Saídas, Clientes).
2. Uma lista de 4 a 6 etapas de processo detalhadas para o mapa operacional. Cada etapa deve possuir parâmetros realistas (recursos adequados, tempo de ciclo em minutos, desvio padrão, taxa de rendimento/yield entre 0.80 e 1.00, e tempo de setup).
3. Uma decisão/sugestão fundamentada em Pesquisa Operacional (Teoria das Filas, Teoria das Restrições, Balanceamento de Linha ou Programação Linear) para otimizar esse fluxo específico de forma ideal.

Retorne estritamente em Português do Brasil seguindo o schema de resposta JSON.
`;

      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          systemInstruction:
            "Você é um cientista de dados e engenheiro de manufatura de elite especializado em Pesquisa Operacional e Six Sigma. Ajude a estruturar dados realistas para processos industriais e de serviços.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              sipoc: {
                type: Type.OBJECT,
                properties: {
                  suppliers: { type: Type.STRING, description: "Lista de fornecedores típicos separados por vírgula" },
                  inputs: { type: Type.STRING, description: "Lista de insumos típicos separados por vírgula" },
                  processDescription: { type: Type.STRING, description: "Nomes das etapas macro separadas por ' -> '" },
                  outputs: { type: Type.STRING, description: "Lista de saídas / produtos / relatórios gerados" },
                  customers: { type: Type.STRING, description: "Quem são os clientes finais do processo" },
                },
                required: ["suppliers", "inputs", "processDescription", "outputs", "customers"],
              },
              steps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "Nome curto e direto da etapa" },
                    resource: { type: Type.STRING, description: "Recurso ou cargo executor primário" },
                    resourceCount: { type: Type.INTEGER, description: "Quantidade inicial sugerida de servidores/operadores (típico de 1 a 3)" },
                    processingTime: { type: Type.NUMBER, description: "Tempo médio de processamento/ciclo em minutos por unidade" },
                    standardDeviation: { type: Type.NUMBER, description: "Desvio padrão do tempo de ciclo em minutos (variabilidade real)" },
                    yieldRate: { type: Type.NUMBER, description: "Fração de rendimento de qualidade (entre 0.80 e 1.00)" },
                    setupTime: { type: Type.INTEGER, description: "Tempo de setup ou ajuste de máquina em minutos" },
                  },
                  required: ["name", "resource", "resourceCount", "processingTime", "standardDeviation", "yieldRate", "setupTime"],
                },
                description: "Etapas sequenciais de transformação correspondentes ao processo do SIPOC.",
              },
              orAnalysis: {
                type: Type.OBJECT,
                properties: {
                  orModel: { type: Type.STRING, description: "Modelo ou classe de Pesquisa Operacional aplicada, ex: Teoria das Filas de Jackson, Programação Linear para Mix, Otimização de Gargalo por TOC" },
                  problemStatement: { type: Type.STRING, description: "O problema latente no fluxo sob foco de PO" },
                  orSuggestions: { type: Type.STRING, description: "Ações corretivas sugeridas usando Pesquisa Operacional" },
                  recommendedConfiguration: { type: Type.STRING, description: "Configuração de operadores ou buffers ideal sugerida pelas fórmulas de PO" },
                  operationalTip: { type: Type.STRING, description: "Dica valiosa Lean + PO para elevar o nível Sigma da atividade" },
                },
                required: ["orModel", "problemStatement", "orSuggestions", "recommendedConfiguration", "operationalTip"],
              },
            },
            required: ["sipoc", "steps", "orAnalysis"],
          },
        },
      });

      const responseText = response.text || "{}";
      const resultJson = JSON.parse(responseText.trim());
      return res.json(resultJson);
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/suggest-structure", req.user);
    }
  });

  // API: Interpret client's unstructured process description and return structured interface data (with iterative feedback)
  app.post("/api/parse-process", requireAuth, requirePermission(["Green Belt", "Black Belt", "Yellow Belt"], true), aiRateLimiter(30, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      // 1. Validate payload with Zod
      const parsedPayload = parseProcessSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados de payload inválidos: ${errorMessages}` });
      }

      const { text, feedback, history } = parsedPayload.data;
      logSafeAiRequest("/api/parse-process", req.user, parsedPayload.data);

      const client = getGeminiClient();

      let prompt = `Analise o seguinte relato ou descrição de processo comercial/operacional enviado por um cliente.
Sua tarefa é interpretar essa descrição, extrair os elementos-chave estruturados, gerar um fluxograma em formato Mermaid.js, e fazer uma análise de lacunas (Gap Analysis) construtiva, focada em apontar pontos de atenção operacionais, riscos ou omissões lógicas.

Além disso, forneça 3 perguntas de esclarecimento ou aprofundamento interativo (interactiveQuestions) muito específicas e provocativas com base no fluxo descrito, para que o usuário possa responder e enriquecer ainda mais a modelagem do seu processo.

Texto original do processo fornecido pelo usuário:
"${text}"
`;

      if (feedback && typeof feedback === "string" && feedback.trim().length > 0) {
        prompt += `\n\nATENÇÃO: O usuário forneceu o seguinte feedback/complemento/correção ou resposta a perguntas anteriores:
"${feedback}"
Incorpore esse novo feedback para atualizar e enriquecer a extração de elementos, o fluxograma, os passos, os desvios e o diagnóstico de lacunas.`;
      }

      if (history && Array.isArray(history) && history.length > 0) {
        prompt += `\n\nHistórico de iterações anteriores para contexto adicional:
${history.map((msg: any) => `- ${msg.role === 'user' ? 'Usuário' : 'IA'}: ${msg.content}`).join("\n")}
`;
      }

      prompt += `\n\nPor favor, retorne uma resposta estruturada em JSON contendo os seguintes campos:
1. gatilho: O gatilho ou evento inicial que inicia o processo.
2. atores: Uma lista de atores, cargos ou responsáveis envolvidos nas ações.
3. sistemas: Uma lista de sistemas, ferramentas, planilhas ou softwares utilizados.
4. entregavelFinal: O entregável final ou resultado do processo.
5. mermaidDiagram: Um fluxograma em Mermaid.js descrevendo o fluxo sequencial e lógico de forma simplificada e profissional (utilize sintaxe 'graph TD' ou 'graph LR'). Use IDs simples para os nós e rótulos curtos. Certifique-se de que a sintaxe Mermaid seja 100% válida.
6. flowchartSteps: Uma lista de objetos representando os nós do fluxograma para que o frontend possa renderizar um fluxograma interativo próprio. Cada objeto deve conter:
   - id: ID único (ex: 'step1', 'step2')
   - label: Nome curto e legível da atividade/etapa
   - actor: Quem faz essa etapa (se mencionado)
   - system: Sistema ou ferramenta usada nessa etapa (se mencionado)
   - type: Tipo do nó ('start' | 'step' | 'decision' | 'end')
   - next: Array de strings contendo IDs dos próximos passos
7. gapAnalysis: Uma lista de Pontos de Atenção (Gap Analysis Rápido) construtivos, apontando falhas lógicas ou omissões lógicas (ex: decisões sem saída de negação, falta de prazos, riscos em processos manuais).
8. interactiveQuestions: Uma lista de exatamente 3 perguntas de esclarecimento ou sugestões de aprimoramento específicas para este processo.`;

      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              gatilho: {
                type: Type.STRING,
                description: "O evento inicial ou gatilho que inicia o processo."
              },
              atores: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Cargos, pessoas ou atores que executam tarefas."
              },
              sistemas: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Sistemas, planilhas, softwares ou ferramentas utilizadas."
              },
              entregavelFinal: {
                type: Type.STRING,
                description: "O entregável final ou resultado do processo."
              },
              mermaidDiagram: {
                type: Type.STRING,
                description: "Código do diagrama Mermaid.js representando o processo."
              },
              flowchartSteps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    label: { type: Type.STRING },
                    actor: { type: Type.STRING },
                    system: { type: Type.STRING },
                    type: { type: Type.STRING }, // 'start', 'step', 'decision', 'end'
                    next: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING }
                    }
                  },
                  required: ["id", "label", "type", "next"]
                },
                description: "Nós estruturados do fluxograma para renderização visual."
              },
              gapAnalysis: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Alertas operacionais, falhas lógicas ou pontos de atenção (Gap Analysis)."
              },
              interactiveQuestions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Três perguntas específicas de refinamento para o usuário."
              }
            },
            required: ["gatilho", "atores", "sistemas", "entregavelFinal", "mermaidDiagram", "flowchartSteps", "gapAnalysis", "interactiveQuestions"]
          }
        }
      });

      const responseText = response.text || "{}";
      const resultJson = JSON.parse(responseText.trim());
      return res.json(resultJson);
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/parse-process", req.user);
    }
  });

  // API: Generate highly aligned 5-block pitch based on user responses and business reality
  app.post("/api/generate-pitch", requireAuth, requirePermission(["Green Belt", "Black Belt", "Yellow Belt"], false), aiRateLimiter(15, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      const parsedPayload = generatePitchSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados de payload inválidos: ${errorMessages}` });
      }

      const { projectName, niche, pain, solution, secret, traction, cta } = parsedPayload.data;
      logSafeAiRequest("/api/generate-pitch", req.user, parsedPayload.data);

      const client = getGeminiClient();

      const prompt = `
Você é um consultor de marketing de negócios e copywriter especialista em Pitch Decks corporativos de alto impacto e Storytelling para startups e grandes corporações.
A sua tarefa é construir um pitch comercial altamente persuasivo, polido e profissional que se adeque perfeitamente à realidade do negócio do usuário.

Para isso, você deve seguir estritamente o formato de ouro de 5 blocos essenciais descritos a seguir:

1. O Gancho (A Dor / O Problema): Comece com uma pergunta provocativa, desconfortável ou fato surpreendente sobre a dor informada. Deve fazer o cliente/investidor concordar na hora de forma visceral.
   Dados da dor: "${pain}"

2. A Solução (A Proposta de Valor): Explique o que a solução faz de forma simples, objetiva, eliminando jargões e atacando diretamente o gancho.
   Dados da solução: "${solution}"

3. O Diferencial (O Segredo): Explique o segredo especial ou diferencial tecnológico ("molho secreto"), posicionando como superior ao mercado.
   Dados do segredo/diferencial: "${secret}"

4. A Tração e o Mercado (A Prova): Destaque números, clientes, crescimento ou validações de mercado reais informados pelo usuário.
   Dados de tração: "${traction}"

5. O Chamado para Ação (Call to Action / CTA): Termine com um fechamento e pedido inquestionável e claro alinhado com o perfil do solicitante.
   Dados do chamado: "${cta}"

CONTEXTO ADICIONAL DO NEGÓCIO:
- Nome do Negócio/Produto: "${projectName}"
- Ramo/Nicho: "${niche}"

Gere uma resposta em JSON contendo um título cativante, uma versão resumida/texto corrido de cada bloco, e um "script de fala em primeira pessoa" dramático e impactante calibrado para prender a atenção.
Seja criativo e persuasivo nos textos. Retorne estritamente em Português do Brasil seguindo o schema de resposta JSON.
`;

      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          systemInstruction:
            "Você é um copywriter de elite especialista em estruturação de pitch, narrativas persuasivas e storytelling executivo corporativo.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              globalTitle: { type: Type.STRING, description: "Título magnético do pitch" },
              gancho: {
                type: Type.OBJECT,
                properties: {
                  titulo: { type: Type.STRING, description: "Título do bloco 1 (ex: 'A Sangria Silenciosa')" },
                  conteudo: { type: Type.STRING, description: "Resumo explicativo do problema e dor latente" },
                  scriptFala: { type: Type.STRING, description: "Script de fala em primeira pessoa ideal para esta parte do pitch" }
                },
                required: ["titulo", "conteudo", "scriptFala"]
              },
              solucao: {
                type: Type.OBJECT,
                properties: {
                  titulo: { type: Type.STRING, description: "Título do bloco 2 (ex: 'A Resposta: E3I Suite')" },
                  conteudo: { type: Type.STRING, description: "Resumo explicativo da proposta de valor" },
                  scriptFala: { type: Type.STRING, description: "Script de fala em primeira pessoa para a proposta de valor" }
                },
                required: ["titulo", "conteudo", "scriptFala"]
              },
              diferencial: {
                type: Type.OBJECT,
                properties: {
                  titulo: { type: Type.STRING, description: "Título do bloco 3 (ex: 'O Motor de Diferenciação')" },
                  conteudo: { type: Type.STRING, description: "Resumo explicativo do molho secreto competitivo" },
                  scriptFala: { type: Type.STRING, description: "Script de fala em primeira pessoa ideal para o segredo competitivo" }
                },
                required: ["titulo", "conteudo", "scriptFala"]
              },
              tracao: {
                type: Type.OBJECT,
                properties: {
                  titulo: { type: Type.STRING, description: "Título do bloco 4 (ex: 'Validação e Mercado')" },
                  conteudo: { type: Type.STRING, description: "Resumo dos números e evidências de crescimento" },
                  scriptFala: { type: Type.STRING, description: "Script de fala em primeira pessoa detalhando números e tração" }
                },
                required: ["titulo", "conteudo", "scriptFala"]
              },
              cta: {
                type: Type.OBJECT,
                properties: {
                  titulo: { type: Type.STRING, description: "Título do bloco 5 (ex: 'O Próximo Passo')" },
                  conteudo: { type: Type.STRING, description: "Fechamento/Chamado para ação prático" },
                  scriptFala: { type: Type.STRING, description: "Script de fala em primeira pessoa para o encerramento memorável" }
                },
                required: ["titulo", "conteudo", "scriptFala"]
              },
              fullScript: { type: Type.STRING, description: "Roteiro consolidado completo corrido" }
            },
            required: ["globalTitle", "gancho", "solucao", "diferencial", "tracao", "cta", "fullScript"]
          }
        }
      });

      const responseText = response.text || "{}";
      const resultJson = JSON.parse(responseText.trim());
      return res.json(resultJson);
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/generate-pitch", req.user);
    }
  });

  // API: Layperson process improvement via Gemini
  app.post("/api/layperson-improve", requireAuth, requirePermission(["Green Belt", "Black Belt", "Yellow Belt"], true), aiRateLimiter(25, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      const laypersonStepSchema = z.object({
        id: z.string().optional(),
        name: z.string().min(1, "O nome da etapa é obrigatório."),
        resource: z.string().optional().default("Equipe"),
        resourceCount: z.number().int().positive("Número de pessoas inválido."),
        processingTime: z.number().positive("Tempo médio gasto inválido."),
        yieldRate: z.number().min(0).max(1),
        description: z.string().optional().default("")
      });

      const laypersonImproveSchema = z.object({
        steps: z.array(laypersonStepSchema).nonempty("O fluxo deve ter pelo menos uma etapa para ser otimizado."),
        arrivalRate: z.number().positive("O volume de clientes deve ser maior que zero.")
      });

      const parsedPayload = laypersonImproveSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados inválidos: ${errorMessages}` });
      }

      const { steps, arrivalRate } = parsedPayload.data;
      logSafeAiRequest("/api/layperson-improve", req.user, parsedPayload.data);

      const client = getGeminiClient();

      const prompt = `
Você é uma assistente de IA especialista em Gestão de Processos (Lean Six Sigma) voltada inteiramente para explicar termos complexos a empresários leigos de forma extremamente amigável, clara e objetiva.

Analise o seguinte processo desenhado por um cliente leigo:

VOLUME DE CLIENTES/DEMANDA POR HORA: ${arrivalRate} pedidos/hora

ETAPAS CORRENTES DO FLUXO:
${steps.map((s, idx) => `
${idx + 1}. Etapa: "${s.name}"
   - Quem faz: ${s.resource} (Quantidade: ${s.resourceCount} pessoas)
   - Tempo que gasta por item: ${s.processingTime} minutos
   - Chance de erros/retrabalho nesta etapa: ${Math.round((1 - s.yieldRate) * 100)}%
   - Descrição da rotina: ${s.description || "Nenhuma descrição informada."}
`).join("\n")}

Por favor, faça um diagnóstico em linguagem simples (Dicionário de Negócios Prático), sem usar termos difíceis como DPMO, Desvio Padrão, Little's Law, Variabilidade Quadrática, TOC ou Pesquisa Operacional complexa.
Use termos como "Instabilidade", "Posto Lento (Gargalo)", "Caixa Acumulada", "Risco de Cansaço" e "Padrão de Trabalho".

Retorne um JSON contendo:
{
  "diagnostic": "Uma avaliação muito simpática e clara sobre a situação atual das etapas desenhadas, apontando qual é o maior monstrinho/atraso do fluxo e onde a equipe está cansando.",
  "recommendations": [
    {
      "title": "Título prático e direto para a ação de melhoria",
      "description": "Explicação detalhada e simples de como implementar essa melhoria hoje mesmo na empresa.",
      "expectedBenefit": "Benefício claro e mensurável que o cliente vai sentir (ex: menos filas, clientes felizes, equipe descansada)"
    }
  ],
  "funnyAnalogy": "Uma analogia divertida do dia a dia (ex: trânsito, copa do mundo, churrasco, padaria, engarrafamento) para o dono entender perfeitamente o problema do seu gargalo."
}

Retorne estritamente em Português do Brasil seguindo o schema de resposta JSON.
`;

      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          systemInstruction:
            "Você é um consultor carismático especialista em Gestão Fácil de Processos (LSS). Suas sugestões ajudam pessoas leigas sem termos técnicos complicados. Retorne um JSON válido.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              diagnostic: { type: Type.STRING, description: "Diagnóstico simpático do processo em português" },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    expectedBenefit: { type: Type.STRING }
                  },
                  required: ["title", "description", "expectedBenefit"]
                }
              },
              funnyAnalogy: { type: Type.STRING, description: "Analogia engraçada do cotidiano" }
            },
            required: ["diagnostic", "recommendations", "funnyAnalogy"]
          }
        }
      });

      const responseText = response.text || "{}";
      const resultJson = JSON.parse(responseText.trim());
      return res.json(resultJson);
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/layperson-improve", req.user);
    }
  });

  // API: Layperson interactive help assistant chatbot via Gemini
  app.post("/api/layperson-chat", requireAuth, requirePermission(["Green Belt", "Black Belt", "Yellow Belt"], true), aiRateLimiter(40, 15 * 60 * 1000), async (req: any, res: any) => {
    try {
      // 1. Validate payload with Zod
      const parsedPayload = laypersonChatSchema.safeParse(req.body);
      if (!parsedPayload.success) {
        const errorMessages = parsedPayload.error.issues.map(err => `${err.path.join(".")}: ${err.message}`).join(", ");
        return res.status(400).json({ error: `Dados de payload inválidos: ${errorMessages}` });
      }

      const { message, dmaicStep } = parsedPayload.data;
      logSafeAiRequest("/api/layperson-chat", req.user, parsedPayload.data);

      const client = getGeminiClient();
      const prompt = `
Você é o assistente virtual da E3I Soluções, especialista em simplificar conceitos Lean Six Sigma (BPM, Kanban, diagramas de causa-raiz, metas e desperdícios) para donos de pequenas empresas, gerentes e colaboradores leigos que estão modelando ou melhorando seus processos de trabalho.

O usuário atual está na etapa: "${dmaicStep || "Definir"}".
Mensagem do usuário: "${message}"

Responda em Português do Brasil de forma extremamente carismática, didática e clara, num tom muito positivo de apoio. Seja conciso (máximo de 2-3 parágrafos curtos) e use analogias excelentes do cotidiano (como padaria, oficina, churrasco, restaurante, rotinas de escritório). Nunca use jargões complicados de consultoria sem traduzi-los primeiro de forma bem-humorada.
`;
      const response = await generateContentWithResilience(client, {
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          systemInstruction: "Você é um consultor carismático e atencioso especialista em Gestão Fácil de Processos (LSS). Explique conceitos de forma que qualquer leigo entenda, sem complicar.",
        }
      });
      return res.json({ reply: response.text || "Desculpe, não consegui processar a resposta agora!" });
    } catch (error: any) {
      return handleSecureAiError(res, error, "/api/layperson-chat", req.user);
    }
  });

  // Mount Vite middleware for development, serve static for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[LSS Server] Servidor executando em http://0.0.0.0:${PORT}`);
  });
}

startServer();
