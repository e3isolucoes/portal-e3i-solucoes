# 📋 Checklist de Validação Técnica e Funcional — E3I Enterprise
**Plataforma de Diagnóstico e Modelagem de Processos Lean Six Sigma**

Este documento estabelece o roteiro de homologação, auditoria de qualidade e testes de usabilidade para validar a evolução e o estado de saúde do sistema **E3I Enterprise**. Ele garante que tanto usuários iniciantes (`SIMPLE`) quanto especialistas (`EXPERT`) possuam jornadas fluidas, à prova de falhas, sem quebras de compatibilidade com projetos antigos e livre de alertas intrusivos do navegador (`window.alert`).

---

## 🗺️ 1. Matriz de Cobertura de Testes por Perfil de Usuário

### 👥 1.1 Jornada do Usuário Iniciante (`SIMPLE`)
*Foco: Terminologia de negócios simplificada, interfaces visuais intuitivas, fluxos guiados e assistidos por IA.*

- [ ] **Iniciar Diagnóstico 360°:**
  - [ ] Usuário consegue navegar até o fluxo de diagnóstico sem se deparar com termos matemáticos complexos.
  - [ ] Resposta amigável ao selecionar notas e submeter o formulário passo a passo.
  - [ ] Impedimento de avançar sem nota selecionada gerenciado via **Toasts elegantes** (sem utilizar `window.alert`).
  - [ ] Modal de confirmação amigável ao tentar reiniciar um diagnóstico concluído para evitar perda acidental de progresso.

- [ ] **Compreender Nível de Maturidade:**
  - [ ] Exibição clara e visual do nível atual (por exemplo, "Maturidade Nível 1 — Inicial/Gárgula" a "Nível 5 — Otimizado").
  - [ ] Gráfico de radar ou mapa térmico de dimensões estruturais (Estratégia, Processos, Tecnologia) legível, com explicações didáticas em português simples.

- [ ] **Descobrir e Entender Recomendações:**
  - [ ] Recomendações automáticas baseadas em gargalos geradas de forma simples (ex: "Otimizar tempo de triagem do atendimento de chamados para reduzir perdas de fila").
  - [ ] Sugestões de melhores práticas ordenadas por impacto estimado e esforço de implementação.

- [ ] **Criar Plano de Ação (Project Charter amigável):**
  - [ ] Possibilidade de definir o patrocinador, a equipe de melhorias (Sponsor, Black/Green Belts) e objetivos em um formulário intuitivo.
  - [ ] Validação visual contra erros de digitação e ausência de campos críticos de forma sutil.

- [ ] **Acompanhar Execução:**
  - [ ] Visualização das atividades e metas em formato Kanban ou lista tátil simplificada.
  - [ ] Opção de arrastar cartões ou atualizar status com retornos imediatos na interface de usuário.

- [ ] **Gerar Visão de Resultados:**
  - [ ] Apresentação simplificada dos KPIs financeiros de economia (ROI), redução de desperdício em horas e ganho de capacidade produtiva em formato de painel executivo (sem termos estatísticos obscuros).

---

### 🎓 1.2 Jornada do Usuário Especialista (`EXPERT`)
*Foco: Rigor metodológico (Lean Six Sigma, DMAIC, SIPOC, RACI, Porter), dados brutos, simulação matemática estocástica e controle granular.*

- [ ] **Visualizar Frameworks de Referência:**
  - [ ] Grade de visualização de Porter (Cadeia de Valor) estruturando Atividades de Suporte vs. Atividades Core perfeitamente alinhadas.
  - [ ] Painel explicativo em gaveta lateral (`DetailDrawer`) definindo conceitos avançados como a *Margem Integrada DMAIC*, evitando alertas nativos de navegador.

- [ ] **Acessar Detalhes Técnicos de Etapas:**
  - [ ] Acessar modal avançado (`StepDetailModal`) para visualizar os parâmetros estocásticos (tempo médio, variabilidade, desvio padrão).
  - [ ] Gerenciamento de relacionamentos de subprocessos e dependências mútuas sem permissões redundantes ou conflito de dados.

- [ ] **Auditar Decisões e Cálculos Coerentes:**
  - [ ] Fórmulas e taxas de chegada de fila (Fórmula de Kingman, Teoria de Filas) auditáveis.
  - [ ] Gráfico estatístico sobrepostos exibindo simulação estocástica (Ex: histogramas ou curvas de distribuição Gaussiana).

- [ ] **Configurar Indicadores e Acordo de Nível de Serviço (SLA):**
  - [ ] Painel para cadastrar e recalibrar limites superiores e inferiores de controle (UCL/LCL).
  - [ ] Flexibilidade de alterar taxas de chegada semanais/mensais e simular o impacto imediato no Lead Time geral do processo.

- [ ] **Analisar Riscos Operacionais:**
  - [ ] Matriz de riscos integrada associando riscos a etapas, permitindo catalogar controle de planos sob regime contínuo.
  - [ ] Detecção automatizada de duplicidades e travamento de redundâncias críticas bloqueados de forma segura e visível com toast de aviso (`warning`).

- [ ] **Configurar Processos e Matrizes de Responsabilidade (RACI/SIPOC):**
  - [ ] Edição dinâmica da matriz RACI associando papéis específicos (Sponsor, Process Owner, Operador, etc.).
  - [ ] Mapeamento de SIPOC (Suppliers, Inputs, Process, Outputs, Customers) com formulário interativo atualizando dinamicamente a estrutura de persistência local ou integrada.

---

## 🛠️ 2. Checklist Técnico e Integridade do Produto

### 💻 2.1 Compilação e Código Limpo (TypeScript)
- [ ] **Execução com Sucesso de Build de Produção:**
  - [ ] Executar `npm run build` ou `compile_applet` e garantir retorno limpo, sem erros de transpilação.
- [ ] **Estatuto de Tipagem Estrita (Forte e Seguro):**
  - [ ] Sem declarações de tipo `any` genéricas implícitas que escondam propriedades do banco.
  - [ ] Enums nativos do TypeScript utilizados para controle de estados, cargos e papéis sistêmicos.
  - [ ] Arquivos de importação colocados exclusivamente no topo de cada módulo, utilizando sintaxe limpa e sem importação direta de valores de tipos em enums.

### 🧭 2.2 Navegação e Fluxos Funcionais
- [ ] **Transição Fluida de Telas e Abas:**
  - [ ] Trocas de painéis (Ex: de visão "Porter" para visão "BPMN" ou "Estúdio de Simulação") sem perda de estados de filtros do usuário.
  - [ ] Modais, gavetas de detalhes (`DetailDrawer`) e popups de diálogos fechando apropriadamente com teclas (`Esc`), cliques fora ou botões Dedicados.
- [ ] **Sem Telas Vazias sem Orientação (`Empty States` Amigáveis):**
  - [ ] Quando um projeto novo é criado do zero, todas as seções (KPIs, Gráficos, Matrizes) exibem uma ilustração amigável com um botão claro indicando o próximo passo (Ex: "Cadastre sua primeira etapa" ou "Selecione um template de segmento").

### 🔐 2.3 Matriz de Permissões e Segurança de Operação
- [ ] **Regras baseadas em Perfis (`Cargo/Role`):**
  - [ ] Modificações de configurações contratuais, faturamento ou ativação de módulos centrais restritas a perfis do tipo `Admin` ou `Dono do Processo`.
  - [ ] Perfis operacionais (`Analista`, `Operador`) que tentarem realizar ações administrativas são educadamente barrados por **Toast de Alerta** com sugestão de contato com a chefia.
- [ ] **Dados Antigos e Retrocompatibilidade:**
  - [ ] Projetos locais que já estavam persistidos no `localStorage` sob versões antigas do código continuam carregando sem travar a renderização devido a campos indefinidos (`undefined` guards).

### 🎨 2.4 UX, Consistência Visual e Responsividade
- [ ] **Substituição Completa de window.alert e confirm:**
  - [ ] Todas as chamadas de alertas nativos foram substituídas por instâncias reativas integradas do `useToast` (`info`, `success`, `warning`, `error`).
  - [ ] Confirmações estruturadas e destrutivas utilizam o componente reativo `ConfirmModal` (Ex: reset de diagnósticos, exclusão de postos operacionais).
- [ ] **Responsividade Multi-tela:**
  - [ ] Grades e fluxogramas se adaptam dinamicamente para exibição aceitável em tablets e notebooks compactos (resoluções a partir de `1024px` de largura).
  - [ ] Diálogos e gavetas laterais de formulários usam rolagem interna sob alturas máximas configuradas apropriadamente (`max-h-screen overflow-y-auto`).

---

## 📈 3. Plano de Expansão e Evolução Futura
Como a plataforma **E3I Enterprise** está preparada para receber novos módulos:
1. **Novos Modelos de Negócio:** Pasta dedicada para templates (`src/domain/templates/`) estruturada em arquivos isolados facilitando adições de novos segmentos como "Agronegócio", "Indústria de Alimentos", etc.
2. **APIs e Microsserviços:** Abstrações preparadas para conectar a backends centralizados conectando faturamento, autorização via OAuth e logs de auditoria do comitê LSS.
3. **Módulos de IA (Gemini):** Prompt de engenharia encapsulado de forma a permitir análise preditiva estocástica avançada.

---
*Assinado pela Equipe de Arquitetura de Software — E3I Suite* (2026)
