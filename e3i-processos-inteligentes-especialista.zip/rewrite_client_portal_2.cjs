const fs = require('fs');

let content = fs.readFileSync('src/components/ClientPortal.tsx', 'utf-8');

// 1. Add states for company and project
const stateVars = `
  const [activePortalTab, setActivePortalTab] = useState<"NEW" | "TRACK" | "MAP" | "REPORT" | "DASHBOARD">("NEW");
  
  const [companies, setCompanies] = useState<Company[]>(() => {
    try { return JSON.parse(localStorage.getItem("lss_companies") || "[]"); } catch { return []; }
  });
  const [projects, setProjects] = useState<WorkspaceProject[]>(() => {
    try { return JSON.parse(localStorage.getItem("lss_workspace_projects") || "[]"); } catch { return []; }
  });
  const [projectDataStore, setProjectDataStore] = useState<Record<string, any>>(() => {
    try { return JSON.parse(localStorage.getItem("lss_project_data_store") || "{}"); } catch { return {}; }
  });
  
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
`;

content = content.replace(/const \[activePortalTab, setActivePortalTab\] = useState<"NEW" \| "TRACK">\("NEW"\);/, stateVars);

// 2. Auth screen: add company dropdown
const authDropdown = `
                <div className="space-y-1.5 pb-2">
                  <label className="text-[9px] font-mono font-bold tracking-widest text-[#B45309] uppercase block text-center">
                    Sua Empresa:
                  </label>
                  <select
                    value={selectedCompanyId}
                    onChange={(e) => setSelectedCompanyId(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-amber-500/30 focus:border-amber-500 p-3 text-center font-mono font-bold text-[#F5F2ED] uppercase text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 rounded-xs"
                    required
                  >
                    <option value="">-- SELECIONE SUA EMPRESA --</option>
                    {companies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold tracking-widest text-[#B45309] uppercase block text-center">
                    Código de Acesso Corporativo:
                  </label>
`;

content = content.replace(/<div className="space-y-1\.5">\s*<label className="text-\[9px\] font-mono font-bold tracking-widest text-\[#B45309\] uppercase block text-center">\s*Código de Acesso Corporativo:/, authDropdown);

content = content.replace(/if \(authenticated\) \{/, `if (authenticated && selectedCompanyId) {`);
content = content.replace(/let authenticated = false;/, `
    if (!selectedCompanyId) {
      setPasscodeError("Por favor, selecione sua empresa na lista antes de autenticar.");
      return;
    }
    let authenticated = false;
`);

// To wrap the entire content area, we can find:
// {activePortalTab === "TRACK" ? ( ... ) : ( ... )}
// and replace it with:
/*
  {activePortalTab === "TRACK" ? ( ... ) : activePortalTab === "NEW" ? ( ... ) : (
    <ProjectDataView />
  )}
*/

content = content.replace(/\{activePortalTab === "TRACK" \? \(/, `
        {/* Portal sub navigation tabs */}
        <div className="flex flex-wrap gap-2 border-b-2 border-gray-300 pb-1 mt-4">
          <button
            type="button"
            onClick={() => setActivePortalTab("NEW")}
            className={\`px-4 py-2 text-xs font-mono font-bold uppercase border-2 transition-all cursor-pointer \${
              activePortalTab === "NEW"
                ? "bg-[#B45309] text-white border-[#B45309] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]"
                : "bg-white text-gray-700 border-gray-300 hover:border-gray-500"
            }\`}
          >
            🛠️ Submeter Demanda
          </button>
          <button
            type="button"
            onClick={() => setActivePortalTab("TRACK")}
            className={\`px-4 py-2 text-xs font-mono font-bold uppercase border-2 transition-all cursor-pointer relative \${
              activePortalTab === "TRACK"
                ? "bg-[#B45309] text-white border-[#B45309] shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]"
                : "bg-white text-gray-700 border-gray-300 hover:border-gray-500"
            }\`}
          >
            📊 Andamento
          </button>
          
          <div className="w-px h-8 bg-gray-300 hidden sm:block mx-2"></div>
          
          <button
            type="button"
            onClick={() => setActivePortalTab("MAP")}
            className={\`px-3 py-2 text-xs font-mono font-bold uppercase border-2 transition-all cursor-pointer \${
              activePortalTab === "MAP"
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-gray-700 border-gray-300"
            }\`}
          >
            🗺️ Desenho do Processo
          </button>
          <button
            type="button"
            onClick={() => setActivePortalTab("DASHBOARD")}
            className={\`px-3 py-2 text-xs font-mono font-bold uppercase border-2 transition-all cursor-pointer \${
              activePortalTab === "DASHBOARD"
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-gray-700 border-gray-300"
            }\`}
          >
            📈 Dashboards Sigma
          </button>
          <button
            type="button"
            onClick={() => setActivePortalTab("REPORT")}
            className={\`px-3 py-2 text-xs font-mono font-bold uppercase border-2 transition-all cursor-pointer \${
              activePortalTab === "REPORT"
                ? "bg-[#1A1A1A] text-white border-[#1A1A1A]"
                : "bg-white text-gray-700 border-gray-300"
            }\`}
          >
            📑 Relatórios
          </button>
        </div>

        {["MAP", "REPORT", "DASHBOARD"].includes(activePortalTab) && (
          <div className="bg-indigo-50 border border-indigo-200 p-4 flex flex-col md:flex-row items-center gap-4 animate-fade-in shadow-sm w-full mb-4">
            <span className="font-bold text-sm uppercase text-indigo-900 flex items-center gap-2">
              <Briefcase size={16} /> Selecione o Projeto Ativo:
            </span>
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="px-4 py-2 border border-indigo-300 rounded shadow-sm text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white min-w-[300px]"
            >
              <option value="">-- Selecione o Projeto (Nenhum Selecionado) --</option>
              {projects.filter(p => p.companyId === selectedCompanyId).map(p => (
                <option key={p.id} value={p.id}>{p.name} - ({p.status})</option>
              ))}
            </select>
          </div>
        )}

        {(() => {
          if (["MAP", "REPORT", "DASHBOARD"].includes(activePortalTab) && !selectedProjectId) {
            return (
              <div className="bg-white p-12 text-center text-gray-400 italic border-4 border-dashed border-gray-200 mt-4 h-[400px] flex items-center justify-center">
                Por favor, selecione um projeto acima para visualizar os dados consolidados da sua empresa.
              </div>
            );
          }

          if (["MAP", "REPORT", "DASHBOARD"].includes(activePortalTab) && selectedProjectId) {
            const currentData = projectDataStore[selectedProjectId] || {};
            const stepsData = currentData.steps || [];
            const arrivalRateData = currentData.arrivalRate || 10;
            const charterData = currentData.charter || {
              name: "Nenhum mapeado", objective: "Nenhum mapeado", scope: "Nenhum", 
              timeline: "0", budget: 0, roitarget: 0, 
              team: { champion: "", blackBelt: "", greenBelts: [], members: [] }
            };
            const sipocData = currentData.sipoc || { suppliers: [], inputs: [], process: [], outputs: [], customers: [] };
            const statsData = calculateProcessMetrics(stepsData, arrivalRateData);

            if (activePortalTab === "MAP") {
              return (
                <div className="bg-[#FAF9F6] border-2 border-gray-300 p-4 w-full">
                  <VisualProcessMapper 
                    steps={stepsData}
                    setSteps={() => {}} 
                    bottleneckStepName={statsData.bottleneckStepName}
                    onOpenDetails={() => {}}
                    activeAreaId={"core_ops"}
                    onSwitchArea={() => {}}
                  />
                </div>
              );
            }
            if (activePortalTab === "DASHBOARD") {
              return (
                <div className="space-y-6 w-full">
                  <SigmaTrendDashboard stats={statsData} onNavigateHome={() => setActivePortalTab("NEW")} />
                  <div className="pt-8 border-t-4 border-gray-300">
                    <BiStudio steps={stepsData} stats={statsData} arrivalRate={arrivalRateData} onNavigateHome={() => setActivePortalTab("NEW")} onOpenStepDetails={() => {}} />
                  </div>
                </div>
              );
            }
            if (activePortalTab === "REPORT") {
              return (
                <div className="bg-white p-2 border-2 border-[#1A1A1A] shadow-lg w-full">
                  <ReportPresentationGenerator 
                    steps={stepsData}
                    stats={statsData}
                    charter={charterData}
                    sipoc={sipocData}
                    controlPlans={currentData.controlPlans || []}
                    arrivalRate={arrivalRateData}
                  />
                </div>
              );
            }
          }

          if (activePortalTab === "TRACK") {
            return (
`);

content = content.replace(/\{activePortalTab === "TRACK" \? \(/, ` `); // Remove redundant as I injected it inside IIFE

// But I need to also close the TRACK view IF tab is TRACK.
content = content.replace(/\) : \(/, `); } if (activePortalTab === "NEW") { return (`);
// Add the closing of the IIFE at the very end of the main tag
content = content.replace(/<\/main>/, `); } return null; })()} </main>`);

// Also, the old portal sub navigation tabs need to be scrubbed.
content = content.replace(/<div className="flex gap-2 border-b-2 border-gray-300 pb-1">.*?<\/div>\s*\{activePortalTab === "TRACK" \? \(/s, ` {activePortalTab === "TRACK" ? (`);

fs.writeFileSync('src/components/ClientPortal.tsx', content, 'utf-8');
