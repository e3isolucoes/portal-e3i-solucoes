# Configuração SMTP Descentralizada por Empresa (Fase 13)

A plataforma e3i permite aos administradores configurarem servidores de mensageria dedicados por holding (ex. `ALGAR_TECH`, `VALE_SA`). Isso assegura a correta entrega dos alertas e previne problemas com filtros anti-spam corporativos.

## 1. Parâmetros Configuráveis por Holding

Cada empresa conta com as seguintes propriedades operacionais:

- **Host (Servidor SMTP)**: IP ou domínio do gateway de mensageria (ex. `smtp.algartech.com.br`).
- **Porta**: 587 (TLS preferencial) ou 465 (SSL implícito).
- **TLS Ativo**: Forçamento de criptografia em trânsito.
- **Usuário**: Credencial de login do provedor.
- **Remetente Proprietário**: Endereço From que aparecerá na mensagem.
- **Nome de Exibição**: Rótulo amigável (ex: `Qualidade Corporativa Algar Tech`).
- **Limites de Envio (Rate Limiter)**: Limite de rajadas por segundo para proteção de spam.
- **Domínios Autorizados**: Lista branca estruturada para impedir envio acidental a concorrentes.
- **Política de Tentativas**: Opção entre `Backoff Exponencial` (dobro do tempo a cada falha) ou linear fixo.

---

## 2. Cofragem e Segurança KMS

> [!IMPORTANT]
> **Nenhuma senha de disparo SMTP trafega ou é gravada de forma vulnerável no frontend.**

As senhas e tokens de acesso são mantidos em uma estrutura de Key Storage simulada que mimetiza um Key Management Service (KMS) ou Vault. 
- O painel de administração masca visualmente as senhas salvas como `••••••••••••••`.
- O motor de envio recupera a credencial em tempo de execução no backend imediatamente antes de abrir a conexão TLS para o despacho.
