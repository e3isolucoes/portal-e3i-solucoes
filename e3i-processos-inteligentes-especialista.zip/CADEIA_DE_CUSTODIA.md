# Protocolo de Cadeia de Custódia e Governança de Eventos (E3I)

De acordo com as boas práticas de segurança corporativa e governança ISO 27001, a integridade do processo de melhoria contínua depende de uma trilha de auditoria completa e inviolável. O sistema **E3I** registra cronologicamente todas as transições operacionais no histórico de vida de um documento.

---

## 1. Ciclo de Vida do Registro e Estados de Custódia

Toda movimentação, consulta ou modificação em um procedimento padrão dispara a geração síncrona de um evento de cadeia de custódia (`CustodyLog`), registrando metadados do operador:

```typescript
export interface CustodyLog {
  id: string;              // Identificador unívoco do log de custódia (ex: CUST-D78B2)
  documentId: string;      // ID do procedimento associado
  version: number;         // Versão exata sob a qual o fato ocorreu
  timestamp: string;       // Carimbo de data/hora em UTC
  user: string;            // Email autenticado do operador responsável ou ID do sistema
  action: CustodyAction;   // Operação efetuada
  description: string;     // Narrativa técnica detalhada sobre o contexto operacional
  ip: string;              // Endereço IP do terminal de origem que requisitou a ação
}
```

---

## 2. Ações de Custódia Mapeadas

O sistema assegura o rastreamento preciso das seguintes ações vitais:

1. **Criação (`Criação`)**: Registro inicial do escopo, objetivo e instruções do POP ou checklist elaborados a partir do Kanban ou desenhados na prancheta.
2. **Alteração (`Alteração`)**: Qualquer modificação pontual de texto ou passo operacional. Ocorre obrigatoriamente sob o incremento de número de versão para evitar sobreposições de chaves de assinatura.
3. **Aprovação (`Aprovação`)**: Aceite técnico por parte de um Black/Master Black Belt do projeto.
4. **Assinatura (`Assinatura`)**: Aplicação de carimbo criptográfico usando HSM sob certificados integrados e ativos no KMS.
5. **Download (`Download`)**: Exportação do documento com carimbo visual complementar. Monitorar e registrar downloads previne vazamento de propriedade industrial crítica.
6. **Compartilhamento (`Compartilhamento`)**: Geração de chaves externas para verificação de autoria e envio para comissões julgadoras de auditoria externa.
7. **Revogação (`Revogação`)**: Declaração formal de desuso ou substituição por método operacional posterior e mais produtivo.
8. **Substituição (`Substituição`)**: Publicação de nova versão estável, arquivando a anterior com preservação total de históricos.
9. **Arquivamento (`Arquivamento`)**: Reposicionamento do procedimento padrão em pasta histórica de inativos, permanecendo bloqueado para edições rotineiras.
10. **Exclusão Autorizada (`Exclusão autorizada`)**: Descarte seguro mitigando a existência do arquivo, ativado estritamente após expiração regulatória e aprovação de direitos.

---

## 3. Preservação de Históricos e Imutabilidade do Ledger

Mesmo após o descarte e exclusão seguros de um procedimento padrão para atendimento à Lei Geral de Proteção de Dados (LGPD) ou políticas internas, as linhas de custódia daquele documento **permanecem intactas e blindadas contra exclusão ou alteração**. 

Essa camada garante que auditorias externas possam examinar toda a evolução de capabilidade de processos no horizonte produtivo da holding sem perder os rastros de autoria de planos de controle históricos.
