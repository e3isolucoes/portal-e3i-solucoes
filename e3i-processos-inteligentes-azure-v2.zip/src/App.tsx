/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './components/ui';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { ToolHub } from './components/ToolHub';
import { TenantManager } from './components/TenantManager';
import { UserManager } from './components/UserManager';
import { RbacManager } from './components/RbacManager';
import { AuditLogsView } from './components/AuditLogsView';
import { DesignSystem } from './components/DesignSystem';
import { ArchitectureView } from './components/ArchitectureView';
import { OrganizationSettingsView } from './components/OrganizationSettingsView';
import { DiscoveryView } from './components/DiscoveryView';
import { DiscoveryReviewView } from './components/DiscoveryReviewView';
import { BusinessContextView } from './components/BusinessContextView';
import { StrategyCanvasView } from './components/StrategyCanvasView';
import { OrganizationMapView } from './components/OrganizationMapView';
import { SystemsDiscoveryView } from './components/SystemsDiscoveryView';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { MailboxModal } from './components/MailboxModal';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { ErrorBoundary } from './components/ErrorBoundary';

const MainContent: React.FC = () => {
  const { 
    user, 
    currentView, 
    setCurrentView, 
    profileModalOpen, 
    setProfileModalOpen, 
    mailboxModalOpen, 
    setMailboxModalOpen,
    shortcutsModalOpen,
    setShortcutsModalOpen 
  } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(() => localStorage.getItem('e3i_sidebar_collapsed') === 'true');
  const waitingForKeyRef = useRef(false);

  useEffect(() => {
    const handleStorage = () => {
      setIsCollapsed(localStorage.getItem('e3i_sidebar_collapsed') === 'true');
    };
    window.addEventListener('storage', handleStorage);
    const interval = setInterval(() => {
      const val = localStorage.getItem('e3i_sidebar_collapsed') === 'true';
      if (val !== isCollapsed) setIsCollapsed(val);
    }, 200);
    return () => {
      window.removeEventListener('storage', handleStorage);
      clearInterval(interval);
    };
  }, [isCollapsed]);

  // Global keyboard shortcuts listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in input/textarea/select
      const target = e.target as HTMLElement;
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable || target.closest('input, textarea, select, [contenteditable="true"]')) {
        if (e.key === 'Escape') {
          target.blur();
        }
        return;
      }

      // Esc closes modals
      if (e.key === 'Escape') {
        setProfileModalOpen(false);
        setMailboxModalOpen(false);
        setShortcutsModalOpen(false);
        return;
      }

      // ? opens shortcuts modal
      if (e.key === '?') {
        e.preventDefault();
        setShortcutsModalOpen(true);
        return;
      }

      // Cmd/Ctrl + K for search
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
        if (searchInput) searchInput.focus();
        return;
      }

      // 'g' sequence for navigation
      if (e.key.toLowerCase() === 'g' && !waitingForKeyRef.current) {
        waitingForKeyRef.current = true;
        setTimeout(() => {
          waitingForKeyRef.current = false;
        }, 1000);
        return;
      }

      if (waitingForKeyRef.current) {
        waitingForKeyRef.current = false;
        const key = e.key.toLowerCase();
        if (key === 'd') {
          setCurrentView('dashboard');
        } else if (key === 'i') {
          setCurrentView('discovery');
        } else if (key === 'c') {
          setCurrentView('businessContext');
        } else if (key === 's') {
          setCurrentView('strategyCanvas');
        } else if (key === 't') {
          setCurrentView('tenants');
        } else if (key === 'u') {
          setCurrentView('users');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setCurrentView, setProfileModalOpen, setMailboxModalOpen, setShortcutsModalOpen]);

  const hasSidebar = user && currentView !== 'landing';

  return (
    <div className="min-h-screen bg-canvas text-text-primary">
      <Navbar />
      <main className={`transition-all duration-300 ${hasSidebar ? (isCollapsed ? 'lg:pl-20' : 'lg:pl-72') : ''}`}>
        {(!user || currentView === 'landing') && <LandingPage />}
        {user && currentView === 'dashboard' && <Dashboard />}
        {user && currentView === 'tools' && <ToolHub />}
        {user && currentView === 'tenants' && <TenantManager />}
        {user && currentView === 'users' && <UserManager />}
        {user && currentView === 'rbac' && <RbacManager />}
        {user && currentView === 'audit' && <AuditLogsView />}
        {user && currentView === 'organizationSettings' && <OrganizationSettingsView />}
        {user && currentView === 'discovery' && <DiscoveryView />}
        {user && currentView === 'discoveryReview' && <DiscoveryReviewView />}
        {user && currentView === 'businessContext' && <BusinessContextView />}
        {user && currentView === 'strategyCanvas' && <StrategyCanvasView />}
        {user && currentView === 'organizationMap' && <OrganizationMapView />}
        {user && currentView === 'systems' && <SystemsDiscoveryView />}
        {currentView === 'designSystem' && <DesignSystem />}
        {currentView === 'architecture' && <ArchitectureView />}
      </main>
      <AuthModal />
      <ProfileModal isOpen={profileModalOpen} onClose={() => setProfileModalOpen(false)} />
      <MailboxModal isOpen={mailboxModalOpen} onClose={() => setMailboxModalOpen(false)} />
      <KeyboardShortcutsModal isOpen={shortcutsModalOpen} onClose={() => setShortcutsModalOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ToastProvider>
          <MainContent />
        </ToastProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
