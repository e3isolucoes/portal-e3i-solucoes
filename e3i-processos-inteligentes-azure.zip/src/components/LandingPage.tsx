import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Button, Card } from './ui';
import { 
  Satellite, 
  ShieldCheck, 
  Building2, 
  Cpu, 
  Lock, 
  ArrowRight,
  Shield,
  Layers,
  Zap
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setAuthModalOpen, setAuthMode } = useAuth();

  return (
    <div className="min-h-screen bg-canvas text-text-primary flex flex-col justify-between">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gold/10 via-canvas to-surface pointer-events-none" />
        
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-bold uppercase tracking-widest mb-6">
            <Satellite className="w-4 h-4 animate-spin" style={{ animationDuration: '12s' }} />
            <span>E3I Soluções • Automação Corporativa</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-text-primary mb-6 leading-tight font-display">
            E³I Processos <span className="e3i-gold-gradient">Inteligentes</span>
          </h1>

          <p className="max-w-3xl mx-auto text-base sm:text-lg text-text-secondary font-normal leading-relaxed mb-10">
            A fundação definitiva para automação de processos corporativos de alto padrão. 
            Gestão multi-empresa, controle rigoroso de acessos e segurança com padrão bancário para empresas líderes de mercado.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              variant="gold"
              size="lg"
              onClick={() => {
                setAuthMode('register');
                setAuthModalOpen(true);
              }}
              icon={<ArrowRight className="w-5 h-5" />}
            >
              Cadastrar Minha Empresa
            </Button>

            <Button
              variant="secondary"
              size="lg"
              onClick={() => {
                setAuthMode('login');
                setAuthModalOpen(true);
              }}
              icon={<Lock className="w-4 h-4 text-gold" />}
            >
              Acessar Plataforma
            </Button>
          </div>

          {/* Quick stats / trust */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <Card elevation="flat" className="p-4 text-center">
              <div className="text-2xl font-black text-gold">Multi-Empresa</div>
              <div className="text-xs text-text-secondary mt-1">Isolamento Completo</div>
            </Card>
            <Card elevation="flat" className="p-4 text-center">
              <div className="text-2xl font-black text-accent">Controle Total</div>
              <div className="text-xs text-text-secondary mt-1">Governança por Papéis</div>
            </Card>
            <Card elevation="flat" className="p-4 text-center">
              <div className="text-2xl font-black text-gold">Alta Resiliência</div>
              <div className="text-xs text-text-secondary mt-1">Disponibilidade 99.9%</div>
            </Card>
            <Card elevation="flat" className="p-4 text-center">
              <div className="text-2xl font-black text-accent">Segurança Ativa</div>
              <div className="text-xs text-text-secondary mt-1">Criptografia de Ponta</div>
            </Card>
          </div>

        </div>
      </section>

      {/* Features Grid */}
      <section id="recursos" className="py-24 bg-surface border-t border-border-subtle px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
            <h2 className="text-3xl font-bold font-display text-text-primary">Plataforma Corporativa de Classe Mundial</h2>
            <p className="text-text-secondary text-sm leading-relaxed">
              Cada módulo foi rigorosamente desenhado para atender diretores, gestores e operadores com extrema fluidez e segurança.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <Card elevation="raised" className="p-8 group hover:border-gold transition-all">
              <div className="w-12 h-12 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center text-accent mb-6 group-hover:scale-110 transition-transform">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold font-display text-text-primary mb-2">Gestão Multi-Empresa</h3>
              <p className="text-xs text-text-secondary leading-relaxed">
                Gerenciamento isolado e corporativo por empresa. Alternância de filiais com contexto de dados segregados e seguros.
              </p>
            </Card>

            <Card elevation="raised" className="p-8 group hover:border-gold transition-all">
              <div className="w-12 h-12 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold font-display text-text-primary mb-2">Controle de Acesso Avançado</h3>
              <p className="text-xs text-text-secondary leading-relaxed">
                Permissões granulares divididas em Administrador, Gestor, Operador e Auditor para proteger operações sensíveis.
              </p>
            </Card>

            <Card elevation="raised" className="p-8 group hover:border-gold transition-all">
              <div className="w-12 h-12 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center text-accent mb-6 group-hover:scale-110 transition-transform">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold font-display text-text-primary mb-2">Automação Inteligente</h3>
              <p className="text-xs text-text-secondary leading-relaxed">
                Processos automatizados com rastreabilidade completa, logs auditáveis e máxima eficiência operacional.
              </p>
            </Card>

          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="bg-canvas border-t border-border-subtle py-12 px-4 sm:px-6 lg:px-8 text-center text-xs text-text-muted">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Satellite className="w-4 h-4 text-gold" />
            <span className="font-bold text-text-primary">E³I Soluções Corporativas</span>
          </div>
          <div>
            © {new Date().getFullYear()} E3I Processos Inteligentes. Todos os direitos reservados.
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gold">Solução Enterprise</span>
            <span>•</span>
            <span>Alta Segurança</span>
          </div>
        </div>
      </footer>

    </div>
  );
};
