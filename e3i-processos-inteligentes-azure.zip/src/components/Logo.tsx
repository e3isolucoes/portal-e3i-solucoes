import React from 'react';
import { useAuth } from '../context/AuthContext';

interface LogoProps {
  className?: string;
  customLogoUrl?: string;
  companyName?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = "", customLogoUrl, companyName }) => {
  const { tenant } = useAuth();
  
  const logoUrl = customLogoUrl || tenant?.customLogoUrl || '/logo.png';
  const name = companyName || tenant?.name;

  return (
    <div className={`flex items-center space-x-3 group select-none ${className}`}>
      <div className="relative flex items-center bg-[#070D1B] px-3.5 py-2 rounded-xl border border-[#D4AF37]/70 shadow-lg">
        <img 
          src={logoUrl} 
          alt={name || 'E3I Soluções'} 
          className="h-10 w-auto max-h-12 object-contain filter drop-shadow"
          onError={(e) => {
            // Fallback text if image isn't loaded
            const parent = e.currentTarget.parentElement;
            if (parent) {
              e.currentTarget.style.display = 'none';
            }
          }}
        />
        <span className="text-sm font-bold text-[#D4AF37] tracking-wider uppercase font-serif ml-2">
          E3I Soluções
        </span>
      </div>
    </div>
  );
};






