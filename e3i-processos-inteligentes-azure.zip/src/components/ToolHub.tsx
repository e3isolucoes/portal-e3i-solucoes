import React, { useEffect, useState } from 'react';
import { Boxes, ExternalLink, LockKeyhole, RefreshCw, ShieldCheck } from 'lucide-react';
import { ClientTool } from '../types';
import { useAuth } from '../context/AuthContext';
import { Button, Card, PageHeader, Badge, useToast } from './ui';
import { getAuthHeaders, getErrorMessage } from '../utils';

export const ToolHub: React.FC = () => {
  const { tenant, user } = useAuth();
  const { showToast } = useToast();
  const [tools, setTools] = useState<ClientTool[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);
  const canManage = user?.role === 'ADMIN' || user?.role === 'E3I_ADMIN';

  const loadTools = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/client-tools', { headers: getAuthHeaders(), credentials: 'include' });
      const data = await res.json();
      if (!res.ok) throw new Error(getErrorMessage(data, 'Não foi possível carregar as ferramentas.'));
      setTools(data.tools || []);
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Erro ao carregar ferramentas.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadTools(); }, [tenant?.id]);

  const toggleGrant = async (tool: ClientTool) => {
    setSavingId(tool.id);
    try {
      const res = await fetch(`/api/admin/organizations/${tenant?.id}/client-tools/${tool.id}`, {
        method: tool.granted ? 'DELETE' : 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(getErrorMessage(data, 'Não foi possível alterar a concessão.'));
      setTools(current => current.map(item => item.id === tool.id ? { ...item, granted: !tool.granted } : item));
      showToast(tool.granted ? 'Acesso revogado.' : 'Acesso concedido.', 'success');
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Erro ao alterar acesso.', 'error');
    } finally {
      setSavingId(null);
    }
  };

  const openTool = async (tool: ClientTool) => {
    if (!tool.granted) return;
    if (tool.internal) {
      window.location.hash = '#dashboard';
      return;
    }
    const res = await fetch(`/api/client-tools/${tool.id}/launch`, {
      method: 'POST', headers: getAuthHeaders(), credentials: 'include'
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(getErrorMessage(data, 'Acesso não autorizado.'), 'error');
      return;
    }
    window.open(data.url, '_blank', 'noopener,noreferrer');
  };

  const visibleTools = canManage ? tools : tools.filter(tool => tool.granted);

  return (
    <div className="min-h-[calc(100vh-80px)] py-8 px-4 sm:px-6 lg:px-8 space-y-8 max-w-7xl mx-auto">
      <PageHeader
        eyebrow={{ icon: <ShieldCheck className="w-3.5 h-3.5" />, text: 'Acesso por concessão' }}
        title="Minhas ferramentas"
        description={`Aplicações liberadas para ${tenant?.tradeName || tenant?.name || 'sua organização'}. As permissões são verificadas novamente no servidor ao abrir.`}
        actions={<Button variant="secondary" size="sm" icon={<RefreshCw className="w-4 h-4" />} onClick={loadTools}>Atualizar</Button>}
      />

      {loading ? (
        <Card className="p-10 text-center text-text-secondary">Carregando concessões…</Card>
      ) : visibleTools.length === 0 ? (
        <Card className="p-10 text-center">
          <LockKeyhole className="w-9 h-9 text-gold mx-auto mb-3" />
          <h2 className="font-display font-bold text-text-primary">Nenhuma ferramenta liberada</h2>
          <p className="text-sm text-text-secondary mt-2">Solicite ao responsável E³I a concessão de acesso para sua organização.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {visibleTools.map(tool => (
            <Card key={tool.id} elevation="raised" className={`p-6 flex flex-col ${tool.granted ? 'border-accent/30' : 'opacity-75'}`}>
              <div className="flex items-start justify-between gap-3 mb-5">
                <div className="w-11 h-11 rounded-xl bg-gold/10 border border-gold/30 grid place-items-center"><Boxes className="w-5 h-5 text-gold" /></div>
                <Badge variant={tool.granted ? 'success' : 'default'}>{tool.granted ? 'Liberada' : 'Bloqueada'}</Badge>
              </div>
              <p className="text-[10px] uppercase tracking-wider font-bold text-text-muted mb-2">{tool.category}</p>
              <h2 className="text-lg font-display font-bold text-text-primary">{tool.name}</h2>
              <p className="text-sm text-text-secondary mt-2 mb-6 flex-1">{tool.description}</p>
              {tool.granted && <Button variant="primary" className="w-full justify-center" icon={<ExternalLink className="w-4 h-4" />} onClick={() => openTool(tool)}>Acessar ferramenta</Button>}
              {canManage && <Button variant={tool.granted ? 'danger' : 'gold'} className="w-full justify-center mt-2" loading={savingId === tool.id} onClick={() => toggleGrant(tool)}>{tool.granted ? 'Revogar acesso' : 'Conceder acesso'}</Button>}
            </Card>
          ))}
        </div>
      )}
      <p className="text-xs text-text-muted">Concessões são vinculadas à organização ativa, não ao navegador. Revogações passam a valer imediatamente.</p>
    </div>
  );
};
