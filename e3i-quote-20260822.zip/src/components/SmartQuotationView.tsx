import React, { FormEvent, useMemo, useState } from 'react';
import { ArrowLeft, BadgeCheck, BarChart3, Building2, Calculator, Check, ChevronRight, CircleDollarSign, Clock3, FileText, Info, PackageSearch, Search, ShieldCheck, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

type QuoteForm = {
  item: string;
  category: string;
  quantity: number;
  budget: number;
  deadline: string;
  payment: string;
  notes: string;
};

type Offer = {
  supplier: string;
  unitPrice: number;
  deliveryDays: number;
  score: number;
  installments: number;
  highlight: string;
};

const categories = ['Tecnologia', 'Escritório', 'Operações', 'Manutenção', 'Serviços', 'Outros'];

const initialForm: QuoteForm = {
  item: '', category: 'Tecnologia', quantity: 1, budget: 0, deadline: '', payment: 'À vista', notes: ''
};

const hashText = (value: string) => Array.from(value).reduce((total, char) => ((total * 31) + char.charCodeAt(0)) >>> 0, 2166136261);

const buildDemoOffers = (form: QuoteForm): Offer[] => {
  const seed = hashText(`${form.item}|${form.category}|${form.quantity}`);
  const reference = form.budget > 0 ? form.budget / form.quantity : 275 + (seed % 725);
  const factors = [0.91, 0.97, 1.04];
  return factors.map((factor, index) => ({
    supplier: `Fornecedor demonstrativo ${String.fromCharCode(65 + index)}`,
    unitPrice: Number((reference * factor).toFixed(2)),
    deliveryDays: 3 + ((seed + index * 5) % 9),
    score: Number((9.2 - index * 0.4).toFixed(1)),
    installments: index === 0 ? 1 : index + 1,
    highlight: index === 0 ? 'Melhor custo estimado' : index === 1 ? 'Equilíbrio entre prazo e valor' : 'Condição de pagamento flexível'
  }));
};

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export const SmartQuotationView: React.FC = () => {
  const { tenant, user, setCurrentView } = useAuth();
  const [form, setForm] = useState<QuoteForm>(initialForm);
  const [submitted, setSubmitted] = useState<QuoteForm | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState('');
  const offers = useMemo(() => submitted ? buildDemoOffers(submitted) : [], [submitted]);
  const bestTotal = offers.length ? offers[0].unitPrice * (submitted?.quantity || 1) : 0;
  const budgetDifference = submitted?.budget ? submitted.budget - bestTotal : null;

  const update = <K extends keyof QuoteForm>(key: K, value: QuoteForm[K]) => setForm(current => ({ ...current, [key]: value }));

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (form.item.trim().length < 3 || form.quantity < 1) {
      setError('Informe o item com pelo menos 3 caracteres e uma quantidade válida.');
      return;
    }
    setError('');
    setSearching(true);
    window.setTimeout(() => {
      setSubmitted({ ...form, item: form.item.trim() });
      setSearching(false);
    }, 700);
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-[#F0F2EC] text-[#0E1A29]">
      <header className="border-b border-[#CFD6C6] bg-[#E6EAE0] px-6 py-8">
        <div className="mx-auto max-w-[1180px]">
          <button onClick={() => setCurrentView('tools')} className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-[#17395C] hover:text-[#8F6A11]"><ArrowLeft className="h-4 w-4" /> Voltar às ferramentas</button>
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.16em] text-[#8F6A11]"><PackageSearch className="h-4 w-4" /> Gestão de Compras</p>
              <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">Cotação Inteligente</h1>
              <p className="mt-3 max-w-2xl leading-7 text-[#5C6672]">Estruture a necessidade, compare cenários e prepare uma decisão de compra com critérios claros.</p>
            </div>
            <div className="rounded border border-[#D9A925] bg-[#FBFBF8] px-4 py-3 text-sm text-[#5C6672]"><span className="font-semibold text-[#8F6A11]">Modo demonstração</span><br />Sem consulta externa a fornecedores</div>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1180px] gap-6 px-6 py-8 xl:grid-cols-[390px_1fr]">
        <form onSubmit={submit} className="h-fit rounded border border-[#CFD6C6] bg-[#FBFBF8] p-6 shadow-sm">
          <div className="flex items-center gap-3 border-b border-[#DDE2D7] pb-5"><span className="grid h-10 w-10 place-items-center rounded-sm bg-[#17395C] text-white"><FileText className="h-5 w-5" /></span><div><p className="font-display text-xl font-semibold">Solicitação de compra</p><p className="text-xs text-[#5C6672]">Dados usados na análise</p></div></div>
          <label className="mt-5 block text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Item ou serviço *</label>
          <input value={form.item} onChange={e => update('item', e.target.value)} placeholder="Ex.: 10 notebooks para a equipe" className="mt-2 w-full rounded-sm border border-[#C7CFC1] bg-white px-3.5 py-3 outline-none focus:border-[#8F6A11]" />

          <label className="mt-5 block text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Categoria</label>
          <div className="mt-2 grid grid-cols-2 gap-2">{categories.map(category => <button type="button" key={category} onClick={() => update('category', category)} className={`rounded-sm border px-3 py-2 text-left text-xs font-semibold ${form.category === category ? 'border-[#17395C] bg-[#E8EDF1] text-[#17395C]' : 'border-[#D5DBD0] bg-white text-[#5C6672]'}`}>{category}</button>)}</div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            <label className="text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Quantidade<input type="number" min="1" value={form.quantity} onChange={e => update('quantity', Math.max(1, Number(e.target.value)))} className="mt-2 w-full rounded-sm border border-[#C7CFC1] bg-white px-3 py-3 text-base font-normal outline-none focus:border-[#8F6A11]" /></label>
            <label className="text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Orçamento total<input type="number" min="0" step="0.01" value={form.budget || ''} onChange={e => update('budget', Math.max(0, Number(e.target.value)))} placeholder="Opcional" className="mt-2 w-full rounded-sm border border-[#C7CFC1] bg-white px-3 py-3 text-base font-normal outline-none focus:border-[#8F6A11]" /></label>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <label className="text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Prazo desejado<input type="date" value={form.deadline} onChange={e => update('deadline', e.target.value)} className="mt-2 w-full rounded-sm border border-[#C7CFC1] bg-white px-3 py-3 text-base font-normal outline-none" /></label>
            <label className="text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Pagamento<select value={form.payment} onChange={e => update('payment', e.target.value)} className="mt-2 w-full rounded-sm border border-[#C7CFC1] bg-white px-3 py-3 text-base font-normal outline-none"><option>À vista</option><option>Faturado</option><option>Parcelado</option></select></label>
          </div>
          <label className="mt-4 block text-xs font-bold uppercase tracking-[.08em] text-[#465568]">Observações</label>
          <textarea value={form.notes} onChange={e => update('notes', e.target.value)} rows={3} placeholder="Marca, especificações ou restrições" className="mt-2 w-full resize-none rounded-sm border border-[#C7CFC1] bg-white px-3.5 py-3 outline-none focus:border-[#8F6A11]" />
          {error && <p className="mt-3 rounded-sm border border-[#E3AAA5] bg-[#FFF2F1] p-3 text-sm text-[#93261F]">{error}</p>}
          <button disabled={searching} className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-sm bg-[#9F7E16] px-5 py-3.5 font-semibold text-white shadow-sm transition hover:bg-[#80630F] disabled:opacity-60">{searching ? <><Clock3 className="h-4 w-4 animate-spin" /> Analisando cenário…</> : <><Search className="h-4 w-4" /> Gerar comparativo</>}</button>
          <p className="mt-3 flex gap-2 text-xs leading-5 text-[#68727C]"><Info className="mt-0.5 h-4 w-4 shrink-0" /> Os valores desta versão são exemplos calculados para demonstração e não constituem cotação comercial.</p>
        </form>

        <section className="space-y-6">
          {!submitted ? <div className="grid min-h-[560px] place-items-center rounded border border-dashed border-[#B9C1B3] bg-[#F8F9F5] p-10 text-center"><div className="max-w-md"><span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#E6EAE0] text-[#17395C]"><BarChart3 className="h-8 w-8" /></span><h2 className="mt-5 font-display text-3xl font-semibold">Prepare sua análise de compra</h2><p className="mt-3 leading-7 text-[#5C6672]">Preencha a solicitação para visualizar um comparativo demonstrativo de custo, prazo e condições.</p><div className="mt-7 grid grid-cols-3 gap-3 text-xs font-semibold text-[#465568]"><span>01 · Necessidade</span><span>02 · Comparação</span><span>03 · Decisão</span></div></div></div>
          : <>
            <div className="rounded border border-[#B9CDBF] bg-[#F4F8F3] p-5"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#2C5A3C]">Cenário gerado</p><h2 className="mt-1 font-display text-2xl font-semibold">{submitted.item}</h2><p className="mt-1 text-sm text-[#5C6672]">{submitted.quantity} unidade(s) · {submitted.category} · {submitted.payment}</p></div><span className="inline-flex items-center gap-2 self-start rounded-sm border border-[#B9CDBF] bg-white px-3 py-2 text-xs font-semibold text-[#2C5A3C]"><ShieldCheck className="h-4 w-4" /> Simulação identificada</span></div></div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded border border-[#CFD6C6] bg-[#FBFBF8] p-5"><Calculator className="h-5 w-5 text-[#8F6A11]" /><p className="mt-3 text-xs uppercase tracking-[.08em] text-[#5C6672]">Melhor total estimado</p><p className="mt-1 font-display text-2xl font-semibold">{money.format(bestTotal)}</p></div>
              <div className="rounded border border-[#CFD6C6] bg-[#FBFBF8] p-5"><Building2 className="h-5 w-5 text-[#8F6A11]" /><p className="mt-3 text-xs uppercase tracking-[.08em] text-[#5C6672]">Cenários comparados</p><p className="mt-1 font-display text-2xl font-semibold">{offers.length}</p></div>
              <div className="rounded border border-[#CFD6C6] bg-[#FBFBF8] p-5"><CircleDollarSign className="h-5 w-5 text-[#8F6A11]" /><p className="mt-3 text-xs uppercase tracking-[.08em] text-[#5C6672]">Diferença do orçamento</p><p className={`mt-1 font-display text-2xl font-semibold ${budgetDifference !== null && budgetDifference < 0 ? 'text-[#93261F]' : 'text-[#2C5A3C]'}`}>{budgetDifference === null ? 'Não informado' : money.format(budgetDifference)}</p></div>
            </div>

            <div className="overflow-hidden rounded border border-[#CFD6C6] bg-[#FBFBF8]">
              <div className="flex items-center justify-between border-b border-[#DDE2D7] px-5 py-4"><div><h3 className="font-display text-xl font-semibold">Comparativo demonstrativo</h3><p className="text-xs text-[#5C6672]">Referências fictícias — sem contato ou consulta externa</p></div><Sparkles className="h-5 w-5 text-[#9F7E16]" /></div>
              <div className="divide-y divide-[#DDE2D7]">{offers.map((offer, index) => {
                const total = offer.unitPrice * submitted.quantity;
                return <article key={offer.supplier} className={`p-5 ${index === 0 ? 'bg-[#F6F8F1]' : ''}`}><div className="flex flex-col gap-5 lg:flex-row lg:items-center"><div className="flex flex-1 gap-4"><span className={`grid h-11 w-11 shrink-0 place-items-center rounded-sm ${index === 0 ? 'bg-[#9F7E16] text-white' : 'bg-[#E6EAE0] text-[#17395C]'}`}>{index === 0 ? <Check className="h-5 w-5" /> : <Building2 className="h-5 w-5" />}</span><div><div className="flex flex-wrap items-center gap-2"><h4 className="font-semibold">{offer.supplier}</h4>{index === 0 && <span className="rounded-sm bg-[#E7EDDB] px-2 py-1 text-[10px] font-bold uppercase text-[#4E662C]">Recomendação da simulação</span>}</div><p className="mt-1 text-sm text-[#5C6672]">{offer.highlight}</p><div className="mt-2 flex flex-wrap gap-3 text-xs text-[#465568]"><span className="flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5" /> Nota demonstrativa {offer.score}</span><span>Entrega estimada: {offer.deliveryDays} dias</span></div></div></div><div className="min-w-[190px] lg:text-right"><p className="text-xs text-[#5C6672]">{money.format(offer.unitPrice)} por unidade</p><p className="font-display text-2xl font-semibold">{money.format(total)}</p><p className="text-xs text-[#5C6672]">{offer.installments === 1 ? 'Pagamento à vista' : `${offer.installments}x de ${money.format(total / offer.installments)}`}</p></div></div></article>;
              })}</div>
            </div>

            <div className="rounded border border-[#D9A925] bg-[#FFF9E9] p-5 text-sm leading-6 text-[#5C6672]"><p className="flex items-center gap-2 font-semibold text-[#70530C]"><Info className="h-4 w-4" /> Próxima etapa para operação real</p><p className="mt-1">Conectar fornecedores homologados ou APIs de marketplaces, registrar evidências de preço e submeter a recomendação ao fluxo de aprovação da organização.</p></div>
          </>}
        </section>
      </div>
    </div>
  );
};
